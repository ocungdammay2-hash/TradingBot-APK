#!/usr/bin/env python3
"""Dựng KHOÁ KÝ APK từ một «hạt giống» bí mật: cùng hạt giống => cùng khoá, từng bit một, ở MỌI lần build.

Vì sao cần: Android chỉ cho cài đè khi APK mới ký CÙNG khoá với bản đang cài. Máy chủ build GitHub Actions là máy mới mỗi lần, nên khoá phải nằm ở đâu đó bền:
secret PYEA_KEYSTORE_B64 (phải tự tạo keystore rồi mã hoá base64 - khó với người chỉ có điện thoại), nhánh trong repo (chỉ an toàn khi repo RIÊNG TƯ), cache (hết hạn sau 7 ngày không
dùng, không thấy được từ tag). Cách này chỉ cần MỘT secret là một chuỗi chữ bất kỳ đủ dài (PYEA_KEY_SEED); khoá không nằm trong repo, cache hay nhánh nào, nên dùng được cả với repo công khai
và không bao giờ «mất» miễn là secret còn.

Cách làm (tất định, không dùng bộ sinh số ngẫu nhiên của hệ điều hành):
  1. master = PBKDF2-HMAC-SHA256(hạt giống, muối cố định, 200 000 vòng) -> làm chậm việc dò hạt giống yếu;
  2. dòng byte giả ngẫu nhiên = HMAC-SHA256(master, nhãn || bộ đếm);
  3. hai số nguyên tố 1024 bit (hai bit cao đặt 1, bit thấp đặt 1, Miller-Rabin 40 cơ số) -> khoá RSA 2048 bit, e = 65537;
  4. chứng chỉ tự ký: tên + số sê-ri suy ra từ master, hạn cố định (2024-01-01 → 2054-01-01), ký RSA PKCS#1 v1.5 SHA-256 (chữ ký RSA PKCS#1 v1.5 là tất định) => cùng hạt giống cho
     cùng chứng chỉ (Android so sánh nguyên chứng chỉ);
  5. ghi PKCS#12 bí danh `androiddebugkey`, mật khẩu `android` (đúng khoá debug mà Gradle/buildozer dùng).
AN TOÀN: ai biết hạt giống dựng lại được đúng khoá và có thể ký APK «cập nhật» đè lên app của bạn (app nhận dữ liệu giao dịch!). Đặt hạt giống DÀI (>= 32 ký tự, ngẫu nhiên) và chỉ trong
Settings → Secrets của repo; đừng đưa vào mã. Đổi hạt giống = khoá khác = phải gỡ app cũ MỘT lần.

Dùng:  python3 tools/ci_derive_keystore.py <đường dẫn ra .keystore>   (hạt giống lấy từ biến môi trường KS_SEED; KHÔNG nhận qua tham số dòng lệnh để khỏi lộ trong danh sách tiến trình)
       in ra dấu vân tay SHA-256 của chứng chỉ (cùng định dạng keytool -list) trên stdout.
Cần: pip install cryptography (>= 3.0)."""
import datetime
import hashlib
import hmac
import os
import sys

MIN_SEED = 32
SALT = b"pyea-apk-signing-key/v1"
ALIAS = b"androiddebugkey"
PASSWORD = b"android"
E = 65537
_SMALL = [p for p in range(3, 2000, 2) if all(p % q for q in range(3, int(p ** 0.5) + 1, 2))]
_BASES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173]


class SeedError(ValueError):
    pass


def master_key(seed):
    s = str(seed or "").strip()
    if len(s) < MIN_SEED:
        raise SeedError("hạt giống quá ngắn (%d ký tự): cần ít nhất %d ký tự ngẫu nhiên" % (len(s), MIN_SEED))
    return hashlib.pbkdf2_hmac("sha256", s.encode("utf-8"), SALT, 200000, 32)


class Stream:
    """Dòng byte giả ngẫu nhiên tất định từ khoá chủ."""

    def __init__(self, master, label):
        self.m, self.label, self.ctr, self.buf = master, label.encode(), 0, b""

    def read(self, n):
        while len(self.buf) < n:
            self.buf += hmac.new(self.m, self.label + b"|" + self.ctr.to_bytes(8, "big"), hashlib.sha256).digest()
            self.ctr += 1
        out, self.buf = self.buf[:n], self.buf[n:]
        return out


def is_probable_prime(n):
    if n < 2:
        return False
    if n < 4:
        return True
    if n % 2 == 0:
        return False
    for p in _SMALL:
        if n == p:
            return True
        if n % p == 0:
            return False
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in _BASES:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def derive_prime(stream, bits=1024):
    nbytes = bits // 8
    while True:
        c = int.from_bytes(stream.read(nbytes), "big")
        c |= (3 << (bits - 2)) | 1                      # hai bit cao: tích hai số luôn đủ 2048 bit; bit thấp: số lẻ
        if (c - 1) % E and is_probable_prime(c):
            return c


def derive_rsa_numbers(master):
    st = Stream(master, "rsa")
    p = derive_prime(st)
    q = derive_prime(st)
    while q == p:
        q = derive_prime(st)
    if p < q:
        p, q = q, p
    n, lam = p * q, (p - 1) * (q - 1) // _gcd(p - 1, q - 1)
    return p, q, n, pow(E, -1, lam)


def _gcd(a, b):
    while b:
        a, b = b, a % b
    return a


def build(seed):
    """-> (khoá riêng, chứng chỉ) của `cryptography`; tất định theo hạt giống."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    m = master_key(seed)
    p, q, n, d = derive_rsa_numbers(m)
    key = rsa.RSAPrivateNumbers(p, q, d, rsa.rsa_crt_dmp1(d, p), rsa.rsa_crt_dmq1(d, q), rsa.rsa_crt_iqmp(p, q), rsa.RSAPublicNumbers(E, n)).private_key()
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "PyEA Debug"), x509.NameAttribute(NameOID.ORGANIZATION_NAME, "PyEA"), x509.NameAttribute(NameOID.COUNTRY_NAME, "VN")])
    serial = int.from_bytes(Stream(m, "serial").read(15), "big") | (1 << 119)       # dương, 120 bit, cố định theo hạt giống
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(serial)
            .not_valid_before(datetime.datetime(2024, 1, 1)).not_valid_after(datetime.datetime(2054, 1, 1))
            .sign(key, hashes.SHA256()))
    return key, cert


def fingerprint(cert):
    from cryptography.hazmat.primitives import hashes
    return ":".join("%02X" % b for b in cert.fingerprint(hashes.SHA256()))


def write_keystore(seed, path):
    from cryptography.hazmat.primitives.serialization import BestAvailableEncryption, pkcs12
    key, cert = build(seed)
    blob = pkcs12.serialize_key_and_certificates(ALIAS, key, cert, None, BestAvailableEncryption(PASSWORD))
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(blob)
    os.replace(tmp, path)
    return fingerprint(cert)


def main(argv):
    if len(argv) != 2:
        print("Dùng: KS_SEED=<hạt giống> %s <đường dẫn keystore>" % argv[0], file=sys.stderr)
        return 2
    try:
        print(write_keystore(os.environ.get("KS_SEED", ""), argv[1]))
    except SeedError as e:
        print("LỖI: %s" % e, file=sys.stderr)
        return 3
    except ImportError:
        print("LỖI: thiếu thư viện cryptography (pip install cryptography)", file=sys.stderr)
        return 4
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
