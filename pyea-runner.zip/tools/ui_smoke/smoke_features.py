"""Chạy Kivy THẬT (xvfb) cho các tính năng 1.9.50: ô «hôm nay»/«giới hạn lỗ ngày» trên tab Giao dịch, nhật ký lệnh (hộp thoại + thống kê theo thẻ + xuất CSV),
máy chủ webhook trong app (thanh trạng thái, POST thật vào cổng), trạng thái «thị trường đóng» của thanh sức khoẻ, mục sổ xuống Webhook trong Cài đặt.
Phiên: sàn «simulated» + paper (giá giả lập nội bộ, không cần mạng).
Chạy: PYEA_SCRATCH=<thư mục tạm> xvfb-run -a python tools/ui_smoke/smoke_features.py <thư mục dự án>"""
import json, os, sys, time, traceback, urllib.request
os.environ.setdefault("KIVY_NO_ARGS", "1")
S = os.environ["PYEA_SCRATCH"]
os.environ["KIVY_HOME"] = os.path.join(S, "kivyhome_f_%d" % os.getpid())
os.environ["PYEA_DATA_DIR"] = os.path.join(S, "data_f_%d" % os.getpid())
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, os.path.join(sys.argv[1], "tests"))
from kivy.config import Config
Config.set("graphics", "width", "720"); Config.set("graphics", "height", "1440")
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
import pyea.ui as U
from pyea import ui_journal

SECRET = "Smoke-Secret-0123456789ab"
PORT = 18787
out = os.path.join(S, "shots_f"); os.makedirs(out, exist_ok=True)
app = U.PyEAApp(); errs = []; log = []


def walk(w):
    yield w
    for c in w.children: yield from walk(c)
def btns(text): return [x for x in walk(Window) if isinstance(x, Button) and text in (x.text or "")]
def texts(root=None): return " | ".join((x.text or "").replace("\n", " ") for x in walk(root or Window) if isinstance(x, Label) and x.text)
def shot(n): Window.screenshot(name=os.path.join(out, n + ".png"))
def fail(e): errs.append(e); app.stop()
def dismiss():
    for t in ("ồng ý", "Bỏ qua"):
        for b in btns(t): b.dispatch("on_release")
def post(body):
    req = urllib.request.Request("http://127.0.0.1:%d/v1/webhook/tradingview" % PORT, data=json.dumps(body).encode(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=5) as r: return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read().decode() or "{}")


def step_start(dt):
    try:
        dismiss(); dismiss()
        app.settings.update({"exchange": "simulated", "mode": "paper", "daily_loss_pct": 5.0, "webhook_enabled": True, "webhook_secret": SECRET,
                             "webhook_port": PORT, "webhook_dry_run": True})
        app.settings_tab.build(app.settings)
        log.append(("co_muc_webhook_trong_cai_dat", "webhook" in app.settings_tab.folds))
        app.start_session(run_bots=False)
        Clock.schedule_once(step_running, 4.0)
    except Exception: fail(traceback.format_exc())


def step_running(dt):
    try:
        dismiss()
        log.append(("da_ket_noi", app.is_connected()))
        snap = app.last_snap or {}
        wh = snap.get("webhook") or {}
        log.append(("snapshot_webhook_bat", bool(wh.get("on")) and wh.get("port") == PORT and wh.get("dry_run") is True))
        t = texts()
        log.append(("thanh_trang_thai_webhook", "WEBHOOK :%d (chỉ kiểm tra)" % PORT in t))
        tp = next(w for w in walk(app.root) if w.__class__.__name__ == "TabbedPanel")
        tp.switch_to([x for x in reversed(tp.tab_list) if "Giao dịch" in x.text][0])        # tab chỉ cập nhật khi đang mở
        Clock.schedule_once(step_boxes, 2.0)

        st, r = post({"secret": SECRET, "id": "s1", "action": "buy", "symbol": "BTCUSDT", "volume": 0.01})
        log.append(("post_that_dry_run", st == 200 and r.get("dry_run") is True))
        st, r = post({"secret": "wrong-wrong-wrong-1", "id": "s2", "action": "buy", "symbol": "BTCUSDT", "volume": 0.01})
        log.append(("sai_secret_401", st == 401))
        sess = app.ctl.session
        log.append(("dry_run_khong_dat_lenh", len(sess.account.positions) == 0))
    except Exception: fail(traceback.format_exc())


def step_boxes(dt):
    try:
        sb = app.trade_tab.s; snap = app.last_snap or {}
        shot("0_trade_tab")
        t = texts()
        log.append(("o_hom_nay_va_gioi_han_nhan", "Lãi/lỗ HÔM NAY" in t and "Giới hạn lỗ ngày" in t))
        log.append(("o_hom_nay_co_so", sb["today"].v.text not in ("-", "")))
        log.append(("o_gioi_han_ngay_dung_0pct", "dùng 0%" in sb["dayguard"].v.text and "tối đa" in sb["dayguard"].v.text))
        sess = app.ctl.session
        sess.open_position("BTCUSDT", "buy", 0.01, owner="manual")
        time.sleep(0.2)
        sess.close_all("manual", "smoke")
        Clock.schedule_once(step_trade, 2.5)
    except Exception: fail(traceback.format_exc())


def step_trade(dt):
    try:
        snap = app.last_snap or {}
        trades = list(snap.get("trades") or [])
        log.append(("co_lenh_da_dong", len(trades) >= 1))
        app.open_trade_detail(trades[-1])
        Clock.schedule_once(lambda d: step_journal(trades[-1]), 0.8)
    except Exception: fail(traceback.format_exc())


def step_journal(trade):
    try:
        shot("1_detail")
        t = texts()
        log.append(("chi_tiet_co_nhat_ky", "NHẬT KÝ CỦA BẠN" in t))
        btns("Nhật ký")[0].dispatch("on_release")
        Clock.schedule_once(lambda d: step_entry(trade), 0.8)
    except Exception: fail(traceback.format_exc())


def step_entry(trade):
    try:
        shot("2_entry")
        ins = [w for w in walk(Window) if isinstance(w, TextInput)]
        note = [w for w in ins if w.multiline][0]; tags = [w for w in ins if not w.multiline][-1]
        note.text = "=cmd|' /C calc'!A0 vào vì thủng đỉnh"; tags.text = "FOMO, đúng kế hoạch"
        btns("Lưu")[0].dispatch("on_release")
        e = app.journal.get(trade)
        log.append(("luu_nhat_ky", e["tags"] == ["fomo", "đúng-kế-hoạch"] and "thủng đỉnh" in e["note"] and e["note"].startswith("=cmd")))
        ui_journal.show_stats(app)
        Clock.schedule_once(lambda d: step_stats(trade), 0.6)
    except Exception: fail(traceback.format_exc())


def step_stats(trade):
    try:
        shot("3_stats")
        t = texts()
        log.append(("thong_ke_theo_the", "THEO THẺ" in t and "fomo" in t and "đúng-kế-hoạch" in t))
        for b in btns("Đóng"): b.dispatch("on_release")
        ui_journal.export(app)
        d = app.store.exports_dir
        files = sorted((f for f in os.listdir(d) if f.startswith("trade-journal-")), key=lambda f: os.path.getmtime(os.path.join(d, f)))   # thư mục exports có thể còn file của lần chạy trước
        txt = open(os.path.join(d, files[-1]), encoding="utf-8-sig").read() if files else ""
        log.append(("xuat_csv_chong_cong_thuc", bool(files) and "'=cmd" in txt and ',=cmd' not in txt and ',"=cmd' not in txt))
        # thanh sức khoẻ: trạng thái «thị trường đóng» (DNSE ngoài giờ) hiển thị đúng chữ
        bar = app.trade_tab.bar
        snap = dict(app.last_snap or {}); snap["health"] = {"state": "market_closed", "market_closed": ["HPG", "FPT"], "stale": [], "failing": []}
        bar.update(snap)
        log.append(("thanh_suc_khoe_thi_truong_dong", "đóng cửa theo lịch" in bar.l_health.text))
        snap["health"] = {"state": "connected", "max_age": 2.0, "market_closed": ["HPG"], "stale": [], "failing": []}
        bar.update(snap)
        log.append(("thanh_suc_khoe_hon_hop", "ngoài giờ/nghỉ: HPG" in bar.l_health.text))
        app.stop_session() if hasattr(app, "stop_session") else None
        Clock.schedule_once(step_end, 1.5)
    except Exception: fail(traceback.format_exc())


def step_end(dt):
    try:
        log.append(("cong_webhook_dong_sau_khi_dung", (lambda: (lambda s: (s.connect_ex(("127.0.0.1", PORT)) != 0))(__import__("socket").socket()))()))
    except Exception: errs.append(traceback.format_exc())
    app.stop()


Clock.schedule_once(step_start, 2.0)
Clock.schedule_once(lambda dt: (errs.append("QUÁ GIỜ"), app.stop()), 90)
try:
    app.run()
except Exception:
    errs.append(traceback.format_exc())
bad = [k for k, v in log if v is not True and v]
print(json.dumps({"log": log, "errors": errs}, ensure_ascii=False, indent=1, default=str))
sys.exit(1 if errs or any(not v for k, v in log) else 0)
