#!/usr/bin/env bash
# Trình giám sát MT5 tối giản trên điện thoại (Termux/proot): chạy MT5 (Box64+Wine+Xvfb), tự khởi động lại khi chết, lùi dần (backoff),
# báo người dùng khi chết/lặp lỗi, giữ máy thức. Chỉ để chạy EA cầu nối PyEABridge. CHƯA kiểm trên máy thật (phần giám sát đã test với lệnh giả: tests/test_mt5_phone_tools.py).
#
# Dùng:  MT5_DIR=/đường/dẫn/MetaTrader5 bash run_mt5_termux.sh [run|setup|provision|compile]
#   run (mặc định)  giám sát MT5 như trên
#   provision       lấy PyEABridge.mq5, bridge.set, startup.ini TỪ APP (cổng cục bộ) và ghi vào MT5_DIR - không cần chép tay
#   compile         biên dịch EA bằng MetaEditor dòng lệnh (/compile /log), báo kết quả + dòng lỗi về app - không cần mở MetaEditor
#   setup           provision rồi compile
# LỖI CHẢY RA APP: nếu có PYEA_TOKEN (hoặc PYEA_TOKEN_FILE) script báo về app (127.0.0.1:PYEA_PORT, mặc định 18765): MT5 thoát (mã + lý do), bỏ cuộc,
#   kết quả biên dịch, và các dòng log MT5 (Experts/Journal) đáng chú ý. App hiện thành cảnh báo và gom vào «Xuất chẩn đoán». Không có token thì chỉ ghi log máy như cũ.
# Biến (đều tuỳ chọn):
#   MT5_CMD          lệnh chạy MT5 (mặc định: box64 wine64 terminal64.exe /portable /config:startup.ini, chạy trong MT5_DIR)
#   MIN_UP           số giây chạy liên tục được coi là «ổn định», lúc đó đặt lại bộ đếm lỗi (mặc định 60)
#   BACKOFF_START    giây chờ trước lần khởi động lại đầu (mặc định 5), nhân đôi tới BACKOFF_MAX (mặc định 300)
#   MAX_FAST_CRASHES số lần chết nhanh liên tiếp thì BỎ CUỘC và báo (mặc định 8) - tránh vòng lặp đốt pin
#   STATUS_FILE      file trạng thái (mặc định $HOME/.pyea_mt5_status), LOG_FILE (mặc định $HOME/.pyea_mt5.log, tự cắt khi > 2 MB)
#   NOTIFY_CMD       lệnh báo: gọi "$NOTIFY_CMD" "tiêu đề" "nội dung" (mặc định dùng termux-notification nếu có)
#   NO_XVFB=1        bỏ qua bước bật Xvfb (test hoặc đã có màn hình ảo)
#   PYEA_PORT / PYEA_HOST / PYEA_TOKEN / PYEA_TOKEN_FILE   kênh báo về app (token = «mt5ea_token» trong Cài đặt)
#   METAEDITOR_CMD   lệnh MetaEditor (mặc định: box64 wine64 metaeditor64.exe); COMPILE_TIMEOUT giây (mặc định 180)
#   LOG_POLL         giây giữa các lần đọc log MT5 (mặc định 5; 0 = không đọc log)
#   PYEA_PROFILE     lean | stable (mặc định stable). lean = ÍT CPU/RAM (MT5 nhúng dùng): để Box64 ở mặc định của nó (không ép STRONGMEM/SAFEFLAGS), BIGBLOCK=3 (khối
#                    DynaRec lớn, hợp chương trình Wine), BOX64_MAXCPU=PYEA_CPUS (mặc định 2), bỏ cuộc sau 3 lần chết nhanh thay vì 8 để app còn kịp chuyển sang stable.
#                    stable = ưu tiên ổn định (STRONGMEM=1, SAFEFLAGS=2) - chậm hơn/tốn CPU hơn. Mức giảm CPU/RAM của lean CHƯA đo trên máy thật. Biến BOX64_* đặt tay luôn thắng.
#   PYEA_ENV_OVERRIDE  file nạp SAU PYEA_ENV (app ghi: cổng/hồ sơ có thể đổi sau khi cài). PYEA_STOP_FILE  nếu file này xuất hiện thì script tự dọn (tắt Wine) và thoát - dừng DỊU.
#   PYEA_RELAY       0 = không chạy relay tệp (mặc định 1). Relay (pyea_relay.py, cần python3) là ĐƯỜNG DỰ PHÒNG khi MT5 chặn socket của EA tới 127.0.0.1:
#                    danh sách địa chỉ cho phép của MT5 không đặt được bằng ini, nên EA tự chuyển sang ghi tệp MQL5/Files và relay chuyển tới app. PYEA_RELAY_PY = đường dẫn script.
set -u
# Trình cài (install_mt5_termux.sh) tạo file này: đường dẫn Wine/Box64, MT5_DIR, kênh về app, bật theo dõi đăng nhập. Không có file thì chạy như cũ.
[ -n "${PYEA_ENV:-}" ] && [ -r "$PYEA_ENV" ] && . "$PYEA_ENV"
[ -n "${PYEA_ENV_OVERRIDE:-}" ] && [ -r "$PYEA_ENV_OVERRIDE" ] && . "$PYEA_ENV_OVERRIDE"
PYEA_PROFILE="${PYEA_PROFILE:-stable}"
case "$PYEA_PROFILE" in lean) _FAST_DEFAULT=3;; *) _FAST_DEFAULT=8;; esac
MIN_UP="${MIN_UP:-60}"; BACKOFF_START="${BACKOFF_START:-5}"; BACKOFF_MAX="${BACKOFF_MAX:-300}"; MAX_FAST_CRASHES="${MAX_FAST_CRASHES:-$_FAST_DEFAULT}"
STATUS_FILE="${STATUS_FILE:-$HOME/.pyea_mt5_status}"; LOG_FILE="${LOG_FILE:-$HOME/.pyea_mt5.log}"
MT5_DIR="${MT5_DIR:-}"; MT5_CMD="${MT5_CMD:-box64 wine64 terminal64.exe /portable /config:startup.ini}"

export WINEPREFIX="${WINEPREFIX:-$HOME/.wine-mt5}" WINEARCH=win64 WINEDEBUG=-all
export WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=d"
apply_profile() {   # tên biến Box64 theo docs/USAGE.md của Box64; BOX64_* người dùng đã đặt thì giữ nguyên
  case "$PYEA_PROFILE" in
    lean)
      export BOX64_DYNAREC_STRONGMEM="${BOX64_DYNAREC_STRONGMEM:-0}" BOX64_DYNAREC_SAFEFLAGS="${BOX64_DYNAREC_SAFEFLAGS:-1}" BOX64_DYNAREC_BIGBLOCK="${BOX64_DYNAREC_BIGBLOCK:-3}"
      export BOX64_MAXCPU="${BOX64_MAXCPU:-${PYEA_CPUS:-2}}" ;;
    *)
      export BOX64_DYNAREC_STRONGMEM="${BOX64_DYNAREC_STRONGMEM:-1}" BOX64_DYNAREC_SAFEFLAGS="${BOX64_DYNAREC_SAFEFLAGS:-2}" ;;   # ưu tiên ổn định hơn tốc độ; cần đo
  esac
}
apply_profile
export DISPLAY="${DISPLAY:-:99}"
PYEA_HOST="${PYEA_HOST:-127.0.0.1}"; PYEA_PORT="${PYEA_PORT:-18765}"; LOG_POLL="${LOG_POLL:-5}"
METAEDITOR_CMD="${METAEDITOR_CMD:-box64 wine64 metaeditor64.exe /portable}"; COMPILE_TIMEOUT="${COMPILE_TIMEOUT:-600}"
if [ -z "${PYEA_TOKEN:-}" ] && [ -n "${PYEA_TOKEN_FILE:-}" ] && [ -r "$PYEA_TOKEN_FILE" ]; then PYEA_TOKEN="$(tr -d '\r\n' < "$PYEA_TOKEN_FILE")"; fi
PYEA_TOKEN="${PYEA_TOKEN:-}"
RELAY_PY="${PYEA_RELAY_PY:-$(dirname "$0")/pyea_relay.py}"

ws_kill() {
  if [ -n "${WINE_DIR:-}" ] && [ -e "$WINE_DIR/bin/wineserver" ] && command -v box64 >/dev/null 2>&1; then box64 "$WINE_DIR/bin/wineserver" -k >/dev/null 2>&1
  elif command -v wineserver >/dev/null 2>&1; then wineserver -k >/dev/null 2>&1; fi
  return 0
}
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG_FILE"; }
status() { printf 'state=%s restarts=%s fast_crashes=%s last_exit=%s ts=%s\n' "$1" "$restarts" "$fast" "${last_exit:-}" "$(date +%s)" > "$STATUS_FILE"; }
notify() {
  log "BÁO: $1 - $2"
  if [ -n "${NOTIFY_CMD:-}" ]; then "$NOTIFY_CMD" "$1" "$2" >/dev/null 2>&1 || true
  elif command -v termux-notification >/dev/null 2>&1; then termux-notification --title "$1" --content "$2" --priority high >/dev/null 2>&1 || true
  fi
}
trim_log() { [ -f "$LOG_FILE" ] && [ "$(wc -c < "$LOG_FILE")" -gt 2097152 ] && tail -n 2000 "$LOG_FILE" > "$LOG_FILE.tmp" && mv "$LOG_FILE.tmp" "$LOG_FILE"; return 0; }

# ---- kênh báo về app (giao thức PyEA-EA v1: dòng "LOẠI|k=v|..."; chỉ 127.0.0.1) ----
# >>> pyea-common (BẢN SAO y hệt trong run_mt5_termux.sh; tests/test_mt5_install.py kiểm hai bản giống nhau)
pesc() { local v="$1"; v=${v//%/%25}; v=${v//|/%7C}; v=${v//=/%3D}; v=${v//$'\r'/%0D}; v=${v//$'\n'/%0A}; printf '%s' "$v"; }
punesc() { local v="$1"; v=${v//%0A/$'\n'}; v=${v//%0D/$'\r'}; v=${v//%3D/=}; v=${v//%7C/|}; v=${v//%25/%}; printf '%s' "$v"; }
# sup_send "SEVT|kind=x|..." ...   (mỗi lần mở một kết nối ngắn; thất bại thì bỏ qua, không làm hỏng giám sát)
sup_send() {
  [ -n "$PYEA_TOKEN" ] || return 0
  ( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" || exit 1
    printf 'SUPHELLO|v=1|token=%s\n' "$PYEA_TOKEN" >&3
    for l in "$@"; do printf '%s\n' "$l" >&3; done
    sleep 0.2 ) 2>/dev/null
  return 0
}
sup_event() { local kind="$1"; shift; local m="SEVT|kind=$kind" kv; for kv in "$@"; do m="$m|${kv%%=*}=$(pesc "${kv#*=}")"; done; sup_send "$m"; }
sup_log() { sup_send "SLOG|lvl=$1|m=$(pesc "$2")"; }
# sup_get tên_file đích  -> 0 nếu lấy và ghi được
sup_get() {
  local name="$1" dest="$2" line b64 err
  [ -n "$PYEA_TOKEN" ] || { echo "thiếu PYEA_TOKEN"; return 2; }
  line=$( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" 2>/dev/null || exit 1
          printf 'SUPHELLO|v=1|token=%s\nGET|name=%s\n' "$PYEA_TOKEN" "$name" >&3
          while IFS= read -r -t 10 -u 3 l; do case "$l" in FILE\|*) printf '%s' "$l"; break;; esac; done ) || { echo "không nối được app ($PYEA_HOST:$PYEA_PORT)"; return 1; }
  [ -n "$line" ] || { echo "app không trả lời (sai token? app chưa bật nguồn mt5ea?)"; return 1; }
  err=""; b64=""
  case "$line" in *"|err="*) err="${line#*|err=}"; err="${err%%|*}";; esac
  case "$line" in *"|b64="*) b64="${line#*|b64=}"; b64="${b64%%|*}"; b64="$(punesc "$b64")";; esac
  [ -z "$err" ] || { echo "app từ chối: $(punesc "$err")"; return 1; }
  mkdir -p "$(dirname "$dest")" && printf '%s' "$b64" | base64 -d > "$dest.tmp" && mv "$dest.tmp" "$dest" || { echo "không ghi được $dest"; return 1; }
  return 0
}
# <<< pyea-common

# ---- cấp file từ app ----
do_provision() {
  [ -n "$MT5_DIR" ] || { echo "cần MT5_DIR"; return 2; }
  local rc=0 r
  for spec in "PyEABridge.mq5|MQL5/Experts/PyEABridge.mq5" "bridge.set|MQL5/Profiles/Tester/bridge.set" "bridge.set|MQL5/Presets/bridge.set" "startup.ini|startup.ini"; do
    r=$(sup_get "${spec%%|*}" "$MT5_DIR/${spec#*|}") && { log "provision ${spec#*|}: ok"; sup_event provision name="${spec%%|*}" ok=1; } \
      || { rc=1; log "provision ${spec#*|}: LỖI $r"; sup_event provision name="${spec%%|*}" ok=0 detail="$r"; echo "LỖI ${spec%%|*}: $r"; }
  done
  [ "$rc" = 0 ] && echo "provision: ok"
  return $rc
}

# ---- biên dịch EA bằng MetaEditor dòng lệnh (cờ /compile và /log theo tài liệu MetaEditor; mã thoát KHÔNG được tài liệu nêu nên đọc file .log + kiểm .ex5) ----
is_utf16() { [ "$(head -c2 "$1" 2>/dev/null | od -An -tx1 | tr -d ' \n')" = "fffe" ] || [ "$(head -c64 "$1" 2>/dev/null | tr -cd '\000' | wc -c)" -gt 4 ]; }   # có BOM hoặc nhiều byte NUL
read_text() { if is_utf16 "$1"; then iconv -f UTF-16 -t UTF-8 "$1" 2>/dev/null || iconv -f UTF-16LE -t UTF-8 "$1" 2>/dev/null; else cat "$1" 2>/dev/null; fi; }
do_compile() {
  [ -n "$MT5_DIR" ] || { echo "cần MT5_DIR"; return 2; }
  local src="$MT5_DIR/MQL5/Experts/PyEABridge.mq5" lg ex5 stamp win errs warn excerpt ok
  lg="${src%.mq5}.log"; ex5="${src%.mq5}.ex5"; stamp="$(mktemp)"
  [ -f "$src" ] || { echo "chưa có $src (chạy provision trước)"; sup_event compile ok=0 errors=1 warnings=0 excerpt="chưa có PyEABridge.mq5 trong Experts"; return 1; }
  win="Z:${src//\//\\}"                                    # Wine ánh xạ / thành ổ Z:
  rm -f "$lg"
  # MetaEditor PHẢI chạy với thư mục làm việc = thư mục MT5: «wine64 metaeditor64.exe» (tên trần) chỉ tìm trong thư mục hiện tại; không thấy thì Wine rơi sang «start.exe» và in
  # «ShellExecuteEx failed: File not found» (log thật Cat S52 2026-11-27: bước compile lỗi vì chế độ compile chạy TRƯỚC dòng «cd $MT5_DIR» của vòng giám sát).
  # (chỉ kiểm khi lệnh dùng TÊN TRẦN metaeditor64.exe như mặc định; lệnh tuỳ biến/đường dẫn tuyệt đối thì để nó tự chạy)
  if [[ "$METAEDITOR_CMD" =~ (^|[[:space:]])metaeditor64\.exe($|[[:space:]]) ]] && [ -z "$(find -L "$MT5_DIR" -maxdepth 1 -iname metaeditor64.exe 2>/dev/null | head -1)" ]; then
    excerpt="thư mục MT5 ($MT5_DIR) không có metaeditor64.exe (tệp .zip/bản cài thiếu MetaEditor?): không biên dịch được EA"
    sup_event compile ok=0 errors=1 warnings=0 excerpt="$excerpt"; rm -f "$stamp"
    echo "biên dịch LỖI (1): $excerpt"; log "biên dịch LỖI: $excerpt"; return 1
  fi
  # Log thật Cat S52 2026-11-27 15:00: MetaEditor đã KHỞI CHẠY (hết lỗi «File not found») nhưng 180 s không ra file log -> không biết chậm hay kẹt. Nay: (1) chờ tối đa
  # COMPILE_TIMEOUT (600 s; Box64 trên máy này rất chậm: tạo tiền tố Wine mất hơn một giờ) nhưng THOÁT SỚM ngay khi file log xuất hiện (MetaEditor đôi khi không tự thoát);
  # (2) ghi vết Wine (lỗi + các DLL nạp, có giờ) vào COMPILE_TRACE_F để xem nó dừng ở đâu; trình cài còn đo CPU/cửa sổ X song song (compile_watch).
  local trace="${COMPILE_TRACE_F:-$HOME/.pyea/compile_trace.txt}" cpid t0 seen="" el
  mkdir -p "$(dirname "$trace")" 2>/dev/null; : > "$trace" 2>/dev/null
  log "biên dịch (trong $MT5_DIR, tối đa ${COMPILE_TIMEOUT}s): $METAEDITOR_CMD /compile:\"$win\" /log"
  ( cd "$MT5_DIR" || exit 1; ulimit -f 65536 2>/dev/null; export WINEDEBUG="${COMPILE_WINEDEBUG:-err+all,fixme-all,+timestamp,+loaddll}"
    exec timeout -k 10 "$COMPILE_TIMEOUT" bash -c "exec $METAEDITOR_CMD /compile:\"$win\" /log" >> "$LOG_FILE" 2> "$trace" ) &
  cpid=$!; t0=$(date +%s)
  while kill -0 "$cpid" 2>/dev/null; do
    if [ -f "$lg" ]; then                                    # MetaEditor đã ghi log: cho nó vài giây tự thoát (COMPILE_GRACE) rồi dọn
      [ -n "$seen" ] || seen=$(date +%s)
      if [ $(( $(date +%s) - seen )) -ge "${COMPILE_GRACE:-8}" ]; then kill "$cpid" 2>/dev/null; ws_kill; break; fi
    fi
    sleep 1
  done
  wait "$cpid" 2>/dev/null
  el=$(( $(date +%s) - t0 ))
  errs=0; warn=0; excerpt=""
  if [ -f "$lg" ]; then
    excerpt=$(read_text "$lg" | grep -aiE '\berror\b' | head -6 | tr '\n' ';' | cut -c1-600)
    errs=$(read_text "$lg" | grep -aiEc '\berror\b'); warn=$(read_text "$lg" | grep -aiEc '\bwarning\b')
  else
    excerpt="không thấy file log biên dịch sau ${el}s (MetaEditor không chạy được/kẹt/quá chậm?) - xem $trace; cuối vết: $(tr -d '\r\000' < "$trace" 2>/dev/null | grep -av 'Error initializing native lib' | tail -n 3 | cut -c1-150 | tr '\n' ';')"
    [ -s "$trace" ] || excerpt="$excerpt [vết Wine TRỐNG: Wine/Box64 chưa in gì]"
    excerpt=${excerpt:0:600}; errs=1
  fi
  ok=0; [ "$errs" = 0 ] && [ -f "$ex5" ] && [ "$ex5" -nt "$stamp" ] && ok=1
  [ "$ok" = 1 ] || { [ "$errs" != 0 ] || { errs=1; excerpt="${excerpt:-không sinh ra file .ex5 mới}"; }; }
  rm -f "$stamp"
  sup_event compile ok="$ok" errors="$errs" warnings="$warn" excerpt="$excerpt"
  [ "$ok" = 1 ] && { echo "biên dịch ok ($warn cảnh báo)"; log "biên dịch ok"; return 0; }
  echo "biên dịch LỖI ($errs): $excerpt"; log "biên dịch LỖI: $excerpt"; return 1
}

# ---- đọc log MT5 (Experts: MQL5/Logs, Journal: logs) và đẩy dòng đáng chú ý về app ----
declare -A OFF
tail_one() {   # src file
  local src="$1" f="$2" size off n chunk first=0 lines
  size=$(wc -c < "$f" 2>/dev/null) || return 0
  if [ -z "${OFF[$f]:-}" ]; then OFF[$f]=0; first=1; fi
  off=${OFF[$f]}
  [ "$size" -gt "$off" ] || { [ "$size" -lt "$off" ] && OFF[$f]=0; return 0; }
  n=$(( size - off )); [ $(( n % 2 )) = 0 ] || n=$(( n - 1 ))   # UTF-16: luôn tiến theo cặp byte
  [ "$n" -gt 0 ] || return 0
  OFF[$f]=$(( off + n ))
  if is_utf16 "$f"; then
    chunk=$(tail -c +$(( off + 1 )) "$f" | head -c "$n" | iconv -f UTF-16LE -t UTF-8 2>/dev/null)
  else
    chunk=$(tail -c +$(( off + 1 )) "$f" | head -c "$n")
  fi
  lines=$(printf '%s\n' "$chunk" | tr -d '\r\000' | grep -aiE 'pyea|fail|error|invalid|authoriz|not allowed|cannot|denied|disconnect|no connection|4014' | { [ "$first" = 1 ] && tail -n 40 || tail -n 25; })
  [ -n "$lines" ] || return 0
  local args=() l
  while IFS= read -r l; do args+=("LOGLINE|src=$src|text=$(pesc "${l:0:300}")"); done <<< "$lines"
  sup_send "${args[@]}"
}
tail_logs_loop() {
  [ "$LOG_POLL" != 0 ] && [ -n "$PYEA_TOKEN" ] && [ -n "$MT5_DIR" ] || return 0
  local f
  while true; do
    for spec in "experts|$MT5_DIR/MQL5/Logs" "journal|$MT5_DIR/logs"; do
      f=$(ls -1t "${spec#*|}"/*.log 2>/dev/null | head -1)
      [ -z "$f" ] || tail_one "${spec%%|*}" "$f"
    done
    sleep "$LOG_POLL"
  done
}

# ---- chỉ bật khi trình cài đặt PYEA_LOGIN_WATCH=1 / PYEA_SYNC_CFG=1 trong file môi trường ----
# new_text file offset: phần log MỚI (sau offset byte) đã đổi sang UTF-8; log MT5 thường là UTF-16
new_text() {
  local f="$1" off="$2"
  [ $(( off % 2 )) = 0 ] || off=$(( off + 1 ))
  if is_utf16 "$f"; then tail -c +$(( off + 1 )) "$f" | iconv -f UTF-16LE -t UTF-8 2>/dev/null; else tail -c +$(( off + 1 )) "$f" 2>/dev/null; fi | tr -d '\r\000'
}
# Đợi MT5 báo đăng nhập (log Journal mới sinh trong LẦN CHẠY NÀY) và báo kết quả về app để màn hình «Kết nối MT5 nhanh» hiện đúng. Mẫu câu theo TRÍ NHỚ log MT5
# tiếng Anh («authorized on <máy chủ>»), CHƯA kiểm với log thật; vì vậy kết luận cuối cùng vẫn là việc EA nối được vào app, không phải dòng log này.
login_watch() {
  [ -n "$PYEA_TOKEN" ] && [ -n "$MT5_DIR" ] || return 0
  local end=$(( $(date +%s) + ${LOGIN_WAIT:-600} )) f txt hit declared=0
  declare -A base
  for f in "$MT5_DIR"/logs/*.log; do [ -f "$f" ] && base[$f]=$(wc -c < "$f"); done
  sup_event install stage=login state=wait detail="chờ MT5 đăng nhập tài khoản"
  while [ "$(date +%s)" -lt "$end" ]; do
    for f in "$MT5_DIR"/logs/*.log; do
      [ -f "$f" ] || continue
      txt=$(new_text "$f" "${base[$f]:-0}")
      if printf '%s' "$txt" | grep -aiqE 'authorized on'; then
        hit=$(printf '%s' "$txt" | grep -aiE 'authorized on' | tail -n 1 | cut -c1-200)
        sup_event install stage=login state=ok detail="$hit"; return 0
      fi
      hit=$(printf '%s' "$txt" | grep -aiE 'authorization .*failed|invalid account|invalid password|wrong password|account disabled|no connection' | tail -n 1 | cut -c1-200)
      if [ -n "$hit" ] && [ "$declared" = 0 ]; then
        declared=1; sup_event install stage=login state=fail detail="MT5 báo: $hit"
      fi
    done
    sleep "${LOGIN_POLL:-3}"
  done
  [ "$declared" = 1 ] || sup_event install stage=login state=fail detail="sau ${LOGIN_WAIT:-600}s MT5 chưa báo đăng nhập được (có thể sai server/mật khẩu, hoặc MT5 chưa lên). Xem «Xuất chẩn đoán EA»."
}
# Cứ vài giây hỏi app bản startup.ini/bridge.set mới nhất và ghi đè nếu khác: khi EA đã nối được, app thôi cấp mật khẩu, nên dòng Password= TỰ BIẾN MẤT khỏi máy
# (MT5 đã tự lưu mật khẩu theo KeepPrivate=1). App đóng/không trả lời thì giữ nguyên file cũ.
sync_cfg() {
  local i=0 d tmp
  [ -n "$PYEA_TOKEN" ] && [ -n "$MT5_DIR" ] || return 0
  tmp="$(mktemp)"
  while true; do
    for spec in "startup.ini|startup.ini" "bridge.set|MQL5/Presets/bridge.set"; do
      d="$MT5_DIR/${spec#*|}"
      if sup_get "${spec%%|*}" "$tmp" >/dev/null 2>&1 && [ -s "$tmp" ] && ! cmp -s "$tmp" "$d"; then cp "$tmp" "$d" && log "đồng bộ ${spec#*|} từ app"; fi
    done
    i=$(( i + 1 ))
    if [ "$i" -lt 40 ]; then sleep "${SYNC_FAST:-15}"; else sleep "${SYNC_SLOW:-120}"; fi
  done
}

# ---- relay tệp <-> app (đường dự phòng khi MT5 chặn socket); chết thì dựng lại ----
relay_loop() {
  [ "${PYEA_RELAY:-1}" != 0 ] && [ -n "$MT5_DIR" ] || return 0
  [ -f "$RELAY_PY" ] || { log "relay: không thấy $RELAY_PY (chạy lại lệnh cài để lấy)"; return 0; }
  command -v python3 >/dev/null 2>&1 || { log "relay: thiếu python3 trong Debian (apt-get install -y python3); đường tệp dự phòng KHÔNG chạy"; return 0; }
  mkdir -p "$MT5_DIR/MQL5/Files"
  while true; do
    python3 "$RELAY_PY" --dir "$MT5_DIR/MQL5/Files" --host "$PYEA_HOST" --port "$PYEA_PORT" >> "$LOG_FILE" 2>&1
    sleep 5
  done
}

case "${1:-run}" in
  provision) do_provision; exit $? ;;
  compile)   do_compile; exit $? ;;
  setup)     do_provision && do_compile; exit $? ;;
  run) ;;
  *) echo "lệnh không rõ: $1 (run|setup|provision|compile)"; exit 64 ;;
esac

child=""; tailer=""
kill_bg() {   # dừng các tiến trình nền của giám sát (relay, đọc log, theo dõi đăng nhập, đồng bộ cấu hình)
  [ -n "${relayer:-}" ] && { pkill -P "$relayer" 2>/dev/null; kill "$relayer" 2>/dev/null; }
  [ -n "$tailer" ] && kill "$tailer" 2>/dev/null; [ -n "${watcher:-}" ] && kill "$watcher" 2>/dev/null; [ -n "${syncer:-}" ] && kill "$syncer" 2>/dev/null
  [ -n "${stopper:-}" ] && kill "$stopper" 2>/dev/null
  return 0
}
stop_watch() {   # dừng DỊU: app tạo PYEA_STOP_FILE -> gửi TERM cho chính script (cleanup tắt Wine) thay vì giết cả cây
  local mainpid="$1"
  [ -n "${PYEA_STOP_FILE:-}" ] || return 0
  while true; do
    if [ -e "$PYEA_STOP_FILE" ]; then rm -f "$PYEA_STOP_FILE"; log "nhận yêu cầu dừng từ app"; kill -TERM "$mainpid" 2>/dev/null; return 0; fi
    sleep 1
  done
}
cleanup() { kill_bg; [ -n "$child" ] && kill "$child" 2>/dev/null; ws_kill; status stopped; exit 0; }
trap cleanup INT TERM

restarts=0; fast=0; last_exit=""; backoff="$BACKOFF_START"
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
if [ "${NO_XVFB:-}" != "1" ]; then
  pgrep Xvfb >/dev/null 2>&1 || { Xvfb "$DISPLAY" -screen 0 800x600x16 -nolisten tcp >/dev/null 2>&1 & sleep 1; }
fi
[ -n "$MT5_DIR" ] && cd "$MT5_DIR"
if [ "${PYEA_SYNC_CFG:-0}" = 1 ] && [ -n "$MT5_DIR" ]; then
  for spec in "startup.ini|startup.ini" "bridge.set|MQL5/Presets/bridge.set"; do     # lần đầu có Password= (nếu app còn giữ); các lần sau đã không còn
    sup_get "${spec%%|*}" "$MT5_DIR/${spec#*|}" >/dev/null 2>&1 && log "làm mới ${spec#*|} từ app"
  done
fi
log "giám sát bắt đầu: $MT5_CMD (hồ sơ $PYEA_PROFILE)"
sup_log I "giám sát bắt đầu: $MT5_CMD (hồ sơ $PYEA_PROFILE, Box64 STRONGMEM=$BOX64_DYNAREC_STRONGMEM SAFEFLAGS=$BOX64_DYNAREC_SAFEFLAGS BIGBLOCK=${BOX64_DYNAREC_BIGBLOCK:-mặc định} MAXCPU=${BOX64_MAXCPU:-mặc định})"
tail_logs_loop & tailer=$!
watcher=""; syncer=""; relayer=""; stopper=""
[ -n "${PYEA_STOP_FILE:-}" ] && { stop_watch $$ & stopper=$!; }
relay_loop & relayer=$!
[ "${PYEA_LOGIN_WATCH:-0}" = 1 ] && { login_watch & watcher=$!; }
[ "${PYEA_SYNC_CFG:-0}" = 1 ] && { sync_cfg & syncer=$!; }
while true; do
  trim_log
  status running
  start=$(date +%s)
  bash -c "exec $MT5_CMD" >> "$LOG_FILE" 2>&1 &            # exec: $! là chính tiến trình MT5, giữ đúng dấu nháy của MT5_CMD
  child=$!
  sup_event started restarts="$restarts"
  wait "$child"; last_exit=$?
  child=""
  up=$(( $(date +%s) - start ))
  restarts=$(( restarts + 1 ))
  if [ "$up" -ge "$MIN_UP" ]; then
    fast=0; backoff="$BACKOFF_START"
    notify "MT5 trong giả lập đã dừng" "Thoát mã $last_exit sau ${up}s. Đang khởi động lại. Kiểm tra vị thế trên sàn."
  else
    fast=$(( fast + 1 ))
    if [ "$fast" -ge "$MAX_FAST_CRASHES" ]; then
      status gave_up
      sup_event mt5_exit code="$last_exit" up="$up" restarts="$restarts" will_restart=0
      sup_send "SLOG|lvl=E|m=$(pesc "đuôi log giả lập: $(tail -n 12 "$LOG_FILE" | tr '\n' ';' | cut -c1-900)")"
      sup_event gave_up code="$last_exit" fast="$fast"
      notify "MT5 liên tục chết - ĐÃ BỎ CUỘC" "Chết nhanh $fast lần liên tiếp (mã $last_exit). Bot KHÔNG còn kết nối. Xem $LOG_FILE."
      kill_bg
      exit 2
    fi
  fi
  ws_kill
  status backoff
  if [ "$fast" -lt "$MAX_FAST_CRASHES" ]; then
    sup_event mt5_exit code="$last_exit" up="$up" restarts="$restarts" will_restart=1 wait="$backoff"
    sup_send "SLOG|lvl=W|m=$(pesc "đuôi log giả lập: $(tail -n 8 "$LOG_FILE" | tr '\n' ';' | cut -c1-600)")"
  fi
  log "MT5 dừng (mã $last_exit, sống ${up}s); chờ ${backoff}s rồi chạy lại (lần $restarts, chết nhanh $fast)"
  sleep "$backoff"
  backoff=$(awk -v b="$backoff" -v m="$BACKOFF_MAX" 'BEGIN{b=b*2; if(b>m) b=m; print b}')
done
