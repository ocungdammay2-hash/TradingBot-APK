#!/usr/bin/env bash
# Giữ KHOÁ KÝ APK qua các lần build của GitHub Actions (build-apk.yml). Android chỉ cho cài đè khi APK mới ký CÙNG khoá với bản đang cài; mất khoá = phải gỡ app =
# mất cả hệ Ubuntu + Wine + MT5 đã cài trong app (20+ phút cài lại). Máy chủ build là máy mới mỗi lần nên khoá phải nằm ở đâu đó bền.
#
# Thứ tự dùng khoá (xem build-apk.yml): (1) secret PYEA_KEYSTORE_B64 (bền nhất, người dùng tự đặt) -> (2) NHÁNH `pyea-signing-key` của chính repo (script này; chỉ repo RIÊNG TƯ)
# -> (3) cache Actions (chỉ thấy được từ cùng nhánh/nhánh mặc định, và bị xoá nếu 7 ngày không dùng) -> (4) tạo mới (phải gỡ app cũ MỘT lần).
# Vì sao có (2): cache KHÔNG sống sót khi (a) build đầu tiên tạo khoá bị lỗi giữa chừng (cache chỉ lưu khi cả job thành công), (b) build chạy từ tag `v*` (cache của tag không
# thấy được từ nơi khác), (c) cách nhau hơn 7 ngày. Nhánh trong repo không bị ba điều đó.
# AN TOÀN: khoá nằm TRONG repo nên chỉ dùng khi repo RIÊNG TƯ (REPO_PRIVATE=true, lấy từ github.event.repository.private). Repo công khai -> bỏ qua và nhắc đặt secret:
# ai đọc được nhánh này có thể ký APK "cập nhật" đè lên app của bạn. Đây là khoá debug của app cài tay (không phải khoá Play Store).
#
# Dùng:  ci_signing_key.sh restore <đường dẫn keystore>   # ghi restored=true|false vào $GITHUB_OUTPUT
#        ci_signing_key.sh save    <đường dẫn keystore>   # không ghi đè nếu nhánh đã có khoá khác
# Biến:  REPO_PRIVATE (phải = true) · GH_TOKEN (quyền ghi repo, chỉ khi remote là github.com) · GITHUB_REPOSITORY · KS_BRANCH (mặc định pyea-signing-key) · KS_REMOTE (thử nghiệm)
# KHÔNG BAO GIỜ làm hỏng build: mọi lỗi chỉ thành cảnh báo, thoát 0.
set -u
BRANCH="${KS_BRANCH:-pyea-signing-key}"
REMOTE="${KS_REMOTE:-https://github.com/${GITHUB_REPOSITORY:-}.git}"
OUT="${GITHUB_OUTPUT:-/dev/null}"
FILE="debug.keystore.b64"
TMP="$(mktemp -d 2>/dev/null || echo "/tmp/pyea_ks_$$")"; mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT

warn() { echo "::warning::$*"; }
git_auth() {   # đăng nhập bằng GH_TOKEN chỉ khi remote là github.com (đúng cách actions/checkout làm; token tự bị che trong log)
  if [ -n "${GH_TOKEN:-}" ]; then
    case "$REMOTE" in https://github.com/*) git -c "http.extraheader=AUTHORIZATION: basic $(printf 'x-access-token:%s' "$GH_TOKEN" | base64 -w0)" "$@"; return;; esac
  fi
  git "$@"
}
keystore_ok() {   # đúng khoá debug mà Gradle dùng (alias androiddebugkey, mật khẩu android); không có keytool thì chỉ kiểm file không rỗng
  [ -s "$1" ] || return 1
  command -v keytool >/dev/null 2>&1 || return 0
  keytool -list -keystore "$1" -storepass android -alias androiddebugkey >/dev/null 2>&1
}
fetch_branch() { git_auth clone -q --depth 1 --branch "$BRANCH" --single-branch "$REMOTE" "$TMP/r" >/dev/null 2>&1; }

cmd_restore() {
  local ks="$1" res=false
  if [ "${REPO_PRIVATE:-}" != true ]; then
    echo "Repo không phải riêng tư (hoặc không rõ): KHÔNG đọc khoá ký từ nhánh $BRANCH."
  elif fetch_branch && [ -s "$TMP/r/$FILE" ] && base64 -d < "$TMP/r/$FILE" > "$TMP/ks" 2>/dev/null && keystore_ok "$TMP/ks"; then
    mkdir -p "$(dirname "$ks")" && cp "$TMP/ks" "$ks" && res=true && echo "Đã lấy khoá ký từ nhánh $BRANCH của repo."
  else
    echo "Nhánh $BRANCH chưa có khoá ký dùng được."
  fi
  echo "restored=$res" >> "$OUT"
}

cmd_save() {
  local ks="$1" b64
  if [ "${REPO_PRIVATE:-}" != true ]; then
    warn "Repo không phải riêng tư (hoặc không rõ) nên khoá ký KHÔNG được ghi vào repo. Để khoá không bao giờ mất hãy đặt secret PYEA_KEYSTORE_B64 (docs/MT5_QUICK.md)."
    return 0
  fi
  keystore_ok "$ks" || { warn "Không ghi khoá ký vào nhánh $BRANCH: file khoá không hợp lệ."; return 0; }
  b64="$(base64 -w0 < "$ks")"
  if fetch_branch; then
    if [ "$(tr -d '\r\n' < "$TMP/r/$FILE" 2>/dev/null)" = "$b64" ]; then echo "Nhánh $BRANCH đã giữ đúng khoá này."; return 0; fi
    warn "Nhánh $BRANCH đã có một khoá KHÁC: không ghi đè (khoá đó đang giữ các bản APK đã cài). Muốn đổi khoá thì xoá nhánh này bằng tay."
    return 0
  fi
  {
    git init -q "$TMP/n" && cd "$TMP/n" && git checkout -q -b "$BRANCH" \
      && printf '%s\n' "$b64" > "$FILE" \
      && printf '%s\n' "Khoá ký APK của PyEA (keystore base64). Giữ repo RIÊNG TƯ. Xoá nhánh này = lần build sau tạo khoá mới = phải gỡ app cũ một lần." > README.txt \
      && git add "$FILE" README.txt \
      && git -c user.name="pyea-ci" -c user.email="pyea-ci@users.noreply.github.com" commit -q -m "Giữ khoá ký APK để cài đè được giữa các lần build" \
      && git_auth push -q "$REMOTE" "$BRANCH"
  } >/dev/null 2>&1 \
    && echo "Đã ghi khoá ký vào nhánh $BRANCH của repo (build sau dùng lại, cài đè được)." \
    || warn "Không ghi được khoá ký vào nhánh $BRANCH (thiếu quyền ghi repo? workflow cần permissions: contents: write)."
  return 0
}

case "${1:-}" in
  restore) shift; cmd_restore "${1:?thiếu đường dẫn keystore}";;
  save) shift; cmd_save "${1:?thiếu đường dẫn keystore}";;
  *) echo "Dùng: $0 restore|save <keystore>" >&2; exit 2;;
esac
exit 0
