"""MT5 NHÚNG: chạy MT5 THẬT (proot + Ubuntu + Box64 + Wine + Xvfb) ngay trong app PyEA, KHÔNG cần cài Termux.

Vì sao làm được ở MỌI targetSdk: Android 10+ chặn execve() file trong thư mục DỮ LIỆU của app nhắm API >= 29 (SELinux chỉ cấm execute_no_trans trên app_data_file;
nạp/mmap code vẫn được). Nên proot + loader của nó được ĐÓNG GÓI TRONG APK dưới dạng «thư viện gốc» (native_libs/arm64-v8a/lib*.so -> nativeLibraryDir, nơi được phép
chạy trực tiếp - cách UserLAnd dùng ở targetSdk 37); proot tự chạy chương trình khách bằng loader + mmap chứ không execve file trong thư mục dữ liệu (xem src/execve/enter.c của proot).
Nhờ vậy APK nhắm API mới (không bị Play Protect chặn «xây dựng cho phiên bản Android cũ»). Đường cũ (tải proot về thư mục dữ liệu, cần targetSdk 28) vẫn còn làm dự phòng.

Phần này là Python thuần (không Kivy): tải proot dựng sẵn (UserLAnd-Assets-Support, bản arm64) -> tải + giải nén Ubuntu Base arm64 (kiểm SHA256SUMS) -> chạy NGUYÊN
script đã có (tools/mt5_phone/install_mt5_termux.sh inner = apt, Box64, Wine, tiền tố, MT5, EA; run_mt5_termux.sh = giám sát MT5) BÊN TRONG proot -> giám sát tiến trình,
đo CPU/RAM. Tiến trình cài báo về app qua cổng cục bộ 127.0.0.1 (cùng giao thức SEVT như bản Termux nên màn hình tiến trình dùng lại), và ghi thêm vào emu/state.json.

THẬT THÀ: phần logic (tải/kiểm hash/giải nén an toàn/dựng lệnh proot/dò lỗi/giám sát/đo tài nguyên) đã test bằng proot GIẢ (tests/test_embedded.py). CHƯA từng chạy
proot/Box64/Wine/MT5 trên điện thoại thật; các URL ở máy chủ bị chặn trong sandbox (cdimage.ubuntu.com, ryanfortner.github.io, download.mql5.com) chưa kiểm."""
import hashlib
import json
import os
import posixpath
import re
import shutil
import signal
import ssl
import stat
import subprocess
import tarfile
import threading
import time
import urllib.error
import urllib.request
import zipfile

from . import mt5ea

# ----------------------------------------------------------------------------------------------- nguồn tải
PROOT_ASSETS_URL = "https://github.com/CypherpunkArmory/UserLAnd-Assets-Support/releases/download/v1.4.33/arm64-v8a-assets.zip"
PROOT_ASSETS_SHA256 = "43d390148fa95846a9bb8834164a449e6bc954db1e438f67aa3b49e32c954213"      # đã tải và băm trong sandbox (github.com tải được)
ROOTFS_DIR_URL = "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/"             # chưa kiểm được trong sandbox (bị chặn)
ROOTFS_SUMS = "SHA256SUMS"
ROOTFS_RE = re.compile(r"^ubuntu-base-22\.04(?:\.\d+)?-base-arm64\.tar\.gz$")
MIN_FREE_MB = 4096                      # ƯỚC LƯỢNG (Ubuntu ~100 MB + Wine ~1 GB + MT5 + tải về); chưa đo. Dung lượng ổ đĩa không phải ưu tiên của người dùng
GUEST_ROOT = "/root"
PROOT_FILES = ("proot", "loader", "loader32", "libtalloc.so.2")
# Tên file trong APK (native_libs/arm64-v8a, buildozer android.add_libs_arm64_v8a): chỉ file «lib*.so» mới được đóng gói vào nativeLibraryDir.
NATIVE_FILES = {
    "a10": {"proot": "libproot_a10.so", "loader": "libproot_loader.so", "loader32": "libproot_loader32.so", "talloc": "libpyea_talloc_a10.so"},
    "base": {"proot": "libproot.so", "loader": "libproot_loader.so", "loader32": "libproot_loader32.so", "talloc": "libpyea_talloc.so"},
}
_AUTO = object()
WX_API = 29                             # từ API này, app KHÔNG được execve file trong thư mục dữ liệu của mình (Android 10 behavior changes) - hằng số của Android, không phải của riêng máy nào
NARROW_VA_BITS = 40                     # không gian địa chỉ ảo ≤ ngần này bit = «hẹp» (nhân Android thường 39-bit; Wine x86-64 cần tới ~47-bit). CHỈ dùng để CHẨN ĐOÁN, không chọn bản Wine
PLAY_PROTECT_GAP = 2                    # Play Protect cảnh báo khi targetSdk < (API của máy - 2) (developers.google.com/android/play-protect/warning-dev-guidance); luôn TÍNH theo máy, không ghi cứng
MIN_UP_S = 60.0
MAX_FAST_FAILS = 6

GUEST_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ANDROID_ENV = ("ANDROID_ROOT", "ANDROID_DATA", "ANDROID_RUNTIME_ROOT", "ANDROID_I18N_ROOT", "ANDROID_TZDATA_ROOT", "ANDROID_ART_ROOT", "ANDROID_STORAGE", "EXTERNAL_STORAGE",
               "BOOTCLASSPATH", "DEX2OATBOOTCLASSPATH")


class EmbedError(Exception):
    """Lỗi có lời giải thích cho người dùng (đi thẳng vào màn hình tiến trình)."""


class Stopped(Exception):
    """Người dùng yêu cầu dừng giữa chừng."""


# ----------------------------------------------------------------------------------------------- tiện ích chung
def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                return h.hexdigest()
            h.update(b)


def ssl_context():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:                                        # noqa: BLE001 - không có certifi (máy dev): dùng kho chứng chỉ hệ thống
        return ssl.create_default_context()


def human(n):
    n = float(n)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return ("%d %s" % (n, u)) if u == "B" else ("%.1f %s" % (n, u))
        n /= 1024.0
    return "%.1f GB" % n


def rmtree_force(path):
    """Xoá cả thư mục có quyền 0555 (hệ Ubuntu có thư mục chỉ-đọc)."""
    def _onerr(func, p, _exc):
        try:
            os.chmod(os.path.dirname(p), 0o700)
            os.chmod(p, 0o700)
            func(p)
        except OSError:
            pass
    if os.path.lexists(path):
        shutil.rmtree(path, onerror=_onerr)


def atomic_write(path, text, mode=None):
    tmp = "%s.tmp%d" % (path, os.getpid())
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    if mode is not None:
        os.chmod(tmp, mode)
    os.replace(tmp, path)


def atomic_write_bytes(path, data, mode=None):
    tmp = "%s.tmp%d" % (path, os.getpid())
    with open(tmp, "wb") as f:
        f.write(data)
    if mode is not None:
        os.chmod(tmp, mode)
    os.replace(tmp, path)


def download(url, dest, sha256=None, progress=None, stop=None, retries=6, timeout=30.0, sleep=time.sleep, ctx=None):
    """Tải về `dest` (tải tiếp được qua .part + Range, thử lại khi đứt mạng, kiểm SHA256 nếu có). Ném EmbedError/Stopped."""
    part = dest + ".part"
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    last = ""
    for attempt in range(retries):
        if stop and stop():
            raise Stopped()
        pos = os.path.getsize(part) if os.path.exists(part) else 0
        req = urllib.request.Request(url, headers={"User-Agent": "PyEA-embedded/1", **({"Range": "bytes=%d-" % pos} if pos else {})})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx or ssl_context()) as r:
                status = getattr(r, "status", 200)
                if pos and status != 206:                    # máy chủ bỏ qua Range: tải lại từ đầu
                    pos = 0
                total = int(r.headers.get("Content-Length") or 0) + pos if r.headers.get("Content-Length") else 0
                last_cb = 0.0
                with open(part, "ab" if pos else "wb") as f:
                    while True:
                        if stop and stop():
                            raise Stopped()
                        b = r.read(1 << 16)
                        if not b:
                            break
                        f.write(b)
                        pos += len(b)
                        now = time.monotonic()
                        if progress and now - last_cb >= 2.0:
                            last_cb = now
                            progress(pos, total)
            if total and pos < total:
                raise OSError("tải thiếu %s/%s" % (human(pos), human(total)))
            break
        except urllib.error.HTTPError as e:
            if e.code == 416 and os.path.exists(part):       # đã đủ từ lần trước
                break
            if 400 <= e.code < 500 and e.code not in (408, 429):
                raise EmbedError("Máy chủ trả mã %d cho %s (link đổi/bị chặn?)" % (e.code, url))
            last = "HTTP %d" % e.code
        except Stopped:
            raise
        except (urllib.error.URLError, OSError, ValueError) as e:
            last = str(getattr(e, "reason", e))
        sleep(min(30.0, 2.0 * (attempt + 1)))
    else:
        raise EmbedError("Không tải được %s sau %d lần thử (%s). Kiểm tra mạng rồi bấm chạy lại, sẽ tải tiếp phần còn dở." % (url, retries, last))
    if sha256:
        got = sha256_file(part)
        if got.lower() != sha256.lower():
            try:
                os.remove(part)
            except OSError:
                pass
            raise EmbedError("File tải về sai mã băm SHA256 (cần %s…, nhận %s…): link bị đổi hoặc tải hỏng. Đã xoá, hãy chạy lại." % (sha256[:12], got[:12]))
    os.replace(part, dest)
    return dest


def pick_rootfs(sums_text):
    """Chọn Ubuntu Base 22.04 arm64 trong SHA256SUMS: (tên file, sha256). Không phụ thuộc số bản con (22.04.5 -> 22.04.6)."""
    best = None
    for line in sums_text.splitlines():
        m = re.match(r"^([0-9a-fA-F]{64})\s+\*?(\S+)\s*$", line.strip())
        if m and ROOTFS_RE.match(m.group(2)):
            key = [int(x) for x in re.findall(r"\d+", re.search(r"22\.04(?:\.\d+)?", m.group(2)).group(0))]
            if best is None or key > best[0]:
                best = (key, m.group(2), m.group(1).lower())
    if not best:
        raise EmbedError("SHA256SUMS không có dòng ubuntu-base-22.04.x-base-arm64.tar.gz (Ubuntu đổi cách đặt tên?)")
    return best[1], best[2]


def _norm_member(name):
    """Chuẩn hoá tên trong tar: bỏ «./» đầu (KHÔNG bỏ dấu chấm của tệp ẩn), cấm tuyệt đối và «..». Trả '.' cho thư mục gốc."""
    if name.startswith("/"):
        raise EmbedError("Gói hệ thống có đường dẫn tuyệt đối: %r" % name)
    while name.startswith("./"):
        name = name[2:]
    n = os.path.normpath(name) if name else "."
    if n == ".." or n.startswith(".." + os.sep) or ".." in n.split(os.sep):
        raise EmbedError("Gói hệ thống có đường dẫn không an toàn: %r" % name)
    return n


def safe_extract_tar(tar_path, dest, stop=None, progress=None):
    """Giải nén .tar.gz vào `dest` AN TOÀN: cấm đường dẫn tuyệt đối/«..», cấm ghi xuyên symlink đã tạo, bỏ thiết bị/fifo, giữ bit thực thi, bỏ bit setuid/setgid,
    liên kết cứng -> bản sao nếu hệ thống không cho link. Chủ sở hữu luôn là app (proot -0 giả root). Trả số mục đã giải nén."""
    os.makedirs(dest, exist_ok=True)
    root = os.path.abspath(dest)
    links, dirs_mode, n = set(), [], 0

    def under_link(name):
        parts = name.split(os.sep)
        return any(os.sep.join(parts[:i]) in links for i in range(1, len(parts)))
    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf:
            if stop and stop():
                raise Stopped()
            name = _norm_member(m.name)
            if name == ".":
                continue
            if under_link(name):
                raise EmbedError("Gói hệ thống ghi xuyên symlink: %r" % m.name)
            target = os.path.join(root, name)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            if m.isdir():
                os.makedirs(target, exist_ok=True)
                dirs_mode.append((target, m.mode & 0o777))
            elif m.issym():
                if os.path.lexists(target):
                    os.remove(target)
                os.symlink(m.linkname, target)
                links.add(name)
            elif m.islnk():
                lname = _norm_member(m.linkname)
                src = os.path.join(root, lname)
                if under_link(lname) or os.path.islink(src) or not os.path.isfile(src):
                    raise EmbedError("Liên kết cứng trỏ sai: %r -> %r" % (m.name, m.linkname))
                if os.path.lexists(target):
                    os.remove(target)
                try:
                    os.link(src, target)
                except OSError:
                    shutil.copy2(src, target)
            elif m.isreg():
                if os.path.lexists(target):
                    os.remove(target)
                with tf.extractfile(m) as fi, open(target, "wb") as fo:
                    shutil.copyfileobj(fi, fo, 1 << 20)
                os.chmod(target, (m.mode & 0o777) | 0o600)
            else:
                continue                                      # thiết bị, fifo: bỏ (proot bind /dev thật)
            n += 1
            if progress and n % 300 == 0:
                progress(n)
    for p, mode in sorted(dirs_mode, key=lambda x: -len(x[0])):
        try:
            os.chmod(p, mode | 0o700)                         # chủ (app) luôn rwx để còn ghi/xoá được
        except OSError:
            pass
    return n


def address_space_bits(maps_path="/proc/self/maps"):
    """Số bit không gian địa chỉ ảo của tiến trình này (39 trên nhiều nhân Android, 47/48 trên Linux thường): bit_length của địa chỉ CAO NHẤT trong
    /proc/self/maps (ngăn xếp/vdso nằm sát đỉnh). 0 nếu không đọc được. ĐO trên chính máy, không đoán theo hãng/đời Android."""
    top = 0
    try:
        with open(maps_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if "[vsyscall]" in line or "[vectors]" in line:      # trang đặc biệt ở địa chỉ nhân/32-bit: không phản ánh không gian người dùng
                    continue
                m = re.match(r"([0-9a-fA-F]+)-([0-9a-fA-F]+)\s", line)
                if m:
                    top = max(top, int(m.group(2), 16))
    except OSError:
        return 0
    return top.bit_length()


def find_native_dir(env=None, maps="/proc/self/maps"):
    """Thư mục thư viện gốc của APK có chứa proot (libproot.so + loader), hoặc None. Thử: PYEA_NATIVE_LIB_DIR (test/ghi đè) -> Android API -> /proc/self/maps
    (thư mục của các lib*.so mà tiến trình này đã nạp, vd libpython)."""
    env = os.environ if env is None else env
    cands = []
    if env.get("PYEA_NATIVE_LIB_DIR"):
        cands.append(env["PYEA_NATIVE_LIB_DIR"])
    try:
        from . import android_native
        d = android_native.native_lib_dir()
        if d:
            cands.append(d)
    except Exception:                                        # noqa: BLE001 - không phải Android
        pass
    try:
        with open(maps, encoding="utf-8", errors="replace") as f:
            for line in f:
                m = re.search(r"(/\S*/lib/(?:arm64|arm64-v8a|aarch64)\S*?)/[^/\s]+\.so\b", line)
                if m:
                    cands.append(m.group(1))
    except OSError:
        pass
    seen = set()
    for d in cands:
        if d in seen:
            continue
        seen.add(d)
        if os.path.isfile(os.path.join(d, "libproot.so")) and os.path.isfile(os.path.join(d, "libproot_loader.so")):
            return d
    return None


def extract_proot_assets(zip_path, out_dir, variant):
    """Lấy proot/loader/loader32/libtalloc.so.2 từ gói UserLAnd vào out_dir (tên chuẩn). variant: «a10» (Android 10+) hoặc «base»."""
    os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        names = set(z.namelist())
        for base in PROOT_FILES:
            src = base + (".a10" if variant == "a10" else "")
            if src not in names:
                raise EmbedError("Gói proot thiếu «%s» (UserLAnd đổi cấu trúc gói?)" % src)
            dst = os.path.join(out_dir, base)
            with z.open(src) as fi, open(dst, "wb") as fo:
                shutil.copyfileobj(fi, fo)
            os.chmod(dst, 0o755)


# ----------------------------------------------------------------------------------------------- đường dẫn
class Layout:
    def __init__(self, data_dir):
        self.root = os.path.join(data_dir, "emu")
        self.bin = os.path.join(self.root, "bin")
        self.rootfs = os.path.join(self.root, "rootfs")
        self.dl = os.path.join(self.root, "dl")
        self.tmp = os.path.join(self.root, "tmp")
        self.fake = os.path.join(self.root, "fake")
        self.state = os.path.join(self.root, "state.json")
        self.request = os.path.join(self.root, "request.json")
        self.stop_flag = os.path.join(self.root, "stop.flag")
        self.pidfile = os.path.join(self.root, "run.pid")
        self.log = os.path.join(self.root, "emu.log")
        self.host_root = os.path.join(self.rootfs, GUEST_ROOT.lstrip("/"))
        self.install_log = os.path.join(self.host_root, ".pyea", "install.log")
        self.stages_log = os.path.join(self.host_root, ".pyea", "stages.log")           # «epoch id state» mỗi sự kiện bước do script trong Ubuntu ghi (app mở lại thì đọc từ đây, không phụ thuộc RAM)
        self.setup_exe = os.path.join(self.host_root, "dl", "mt5setup.exe")                # bộ cài MT5 đã tải (script: $DL/mt5setup.exe)
        self.spin_log = os.path.join(self.host_root, ".pyea", "mt5_spin.txt")           # v14: CPU từng tiến trình/luồng lúc bộ cài MT5 quay vòng (script ghi)
        self.wine_diag = os.path.join(self.host_root, ".pyea", "wine_diag.txt")
        self.mt5_shot = os.path.join(self.host_root, ".pyea", "mt5_screen.b64")        # ảnh màn hình ảo lúc bộ cài MT5 đứng im (xwd|gzip|base64, một dòng); giải bằng tools/mt5_phone/xwd_decode.py
        self.exec_probe = os.path.join(self.host_root, ".pyea", "exec_probe.txt")       # kết quả đo mmap/mprotect PROT_EXEC trong proot (script ghi)
        self.shim_log = os.path.join(self.host_root, ".pyea", "shim.log")               # lớp đệm pyea_noexec ghi errno thật của lời gọi bị từ chối
        self.run_log = os.path.join(self.host_root, ".pyea_mt5.log")
        self.stop_req = os.path.join(self.host_root, ".pyea", "stop.req")


def read_state(data_dir):
    try:
        with open(Layout(data_dir).state, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def read_stages(data_dir):
    """Trạng thái từng bước cài ĐỌC TỪ ĐĨA: state.json (bước do Python báo) + stages.log (bước do script trong Ubuntu báo, mỗi dòng «epoch id state»); bản MỚI NHẤT thắng.
    Máy chủ cục bộ của app chỉ giữ sự kiện trong RAM nên mở lại app giữa chừng là mất hết (log thật: «Đang cài (0%)» dù đã qua 5/11 bước). Dòng log cũ hơn lúc bắt đầu lần cài
    hiện tại (`run_t` trong state.json) bị bỏ để lỗi của lần trước không hiện như lỗi của lần này."""
    st = read_state(data_dir)
    try:
        run_t = float(st.get("run_t") or 0)
    except (TypeError, ValueError):
        run_t = 0.0
    out = {}
    for sid, rec in (st.get("stages") or {}).items():
        if isinstance(rec, dict) and rec.get("state"):
            out[str(sid)] = dict(rec)
    try:
        with open(Layout(data_dir).stages_log, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()[-400:]
    except OSError:
        lines = []
    for ln in lines:
        parts = ln.split()
        if len(parts) != 3 or not parts[0].isdigit():
            continue
        t, sid, state = float(parts[0]), parts[1], parts[2]
        if run_t and t < run_t - 2:
            continue
        cur = out.get(sid)
        if cur is None or t >= float(cur.get("t") or 0):
            out[sid] = {"state": state, "detail": "", "t": t}
    return out


def read_request(data_dir):
    try:
        with open(Layout(data_dir).request, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def write_request(data_dir, **kv):
    """UI/ứng dụng ghi yêu cầu cho dịch vụ Emu (dịch vụ sticky bị Android khởi động lại không kèm tham số nên đọc lại file này)."""
    lo = Layout(data_dir)
    os.makedirs(lo.root, exist_ok=True)
    cur = read_request(data_dir)
    cur.update(kv)
    atomic_write(lo.request, json.dumps(cur, ensure_ascii=False), 0o600)
    return cur


def request_stop(data_dir, on=True):
    lo = Layout(data_dir)
    os.makedirs(lo.root, exist_ok=True)
    if on:
        with open(lo.stop_flag, "w") as f:
            f.write(str(time.time()))
    else:
        try:
            os.remove(lo.stop_flag)
        except OSError:
            pass


def tail_text(path, n=2000):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - n))
            return f.read().decode("utf-8", "replace")
    except OSError:
        return ""


# ----------------------------------------------------------------------------------------------- đo CPU/RAM
def _stat_fields(pid):
    try:
        with open("/proc/%s/stat" % pid, "rb") as f:
            raw = f.read().decode("utf-8", "replace")
        i, j = raw.find("("), raw.rfind(")")
        return raw[i + 1:j], raw[j + 2:].split()
    except (OSError, ValueError):
        return None, None


def _tracer(pid):
    try:
        with open("/proc/%s/status" % pid, "rb") as f:
            for line in f.read().decode("utf-8", "replace").splitlines():
                if line.startswith("TracerPid:"):
                    return int(line.split()[1])
    except (OSError, ValueError, IndexError):
        pass
    return 0


class Sampler:
    """Đo CPU/RAM của CẢ cây tiến trình trong proot. Tiến trình khách là tracee của proot nên có TracerPid = pid proot (kể cả wineserver tự tách phiên)."""

    def __init__(self, root_pid, proc="/proc", clk=None, page=None, now=time.monotonic):
        self.root, self.proc, self.now = int(root_pid), proc, now
        self.clk = clk or (os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100)
        self.page = page or (os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096)
        self.prev, self.t_prev = {}, None

    def members(self):
        out = []
        try:
            names = os.listdir(self.proc)
        except OSError:
            return out
        for n in names:
            if not n.isdigit():
                continue
            pid = int(n)
            comm, f = _stat_fields(n)
            if f is None or len(f) < 22:
                continue
            ok = pid == self.root or int(f[3]) == self.root or _tracer(n) == self.root
            if ok:
                out.append((pid, comm, int(f[11]) + int(f[12]), int(f[21]) * self.page))
        return out

    def sample(self):
        t = self.now()
        mem = self.members()
        cur, rss, rows = {}, 0, []
        for pid, comm, ticks, rb in mem:
            cur[pid] = ticks
            rss += rb
            rows.append([comm, ticks - self.prev.get(pid, ticks), rb])
        dt = (t - self.t_prev) if self.t_prev is not None else 0.0
        delta = sum(max(0, r[1]) for r in rows)
        cpu = (100.0 * delta / self.clk / dt) if dt > 0 else 0.0
        self.prev, self.t_prev = cur, t
        agg = {}
        for comm, d, rb in rows:                           # gộp theo tên (wine có nhiều tiến trình cùng tên)
            a = agg.setdefault(comm, [0.0, 0])
            a[0] += (100.0 * max(0, d) / self.clk / dt) if dt > 0 else 0.0
            a[1] += rb
        top = sorted(agg.items(), key=lambda kv: -(kv[1][0] * 1000 + kv[1][1] / 1e6))[:4]
        return {"cpu": round(cpu, 1), "rss_mb": int(rss / 1048576), "procs": len(mem),
                "top": ",".join("%s:%d%%/%dMB" % (c, a[0], a[1] / 1048576) for c, a in top)}


# ----------------------------------------------------------------------------------------------- bộ chạy nhúng
class Embedded:
    def __init__(self, data_dir, host="127.0.0.1", port=18765, token="", profile="lean", scripts=None, urls=None, sdk=None, arch=None, min_free_mb=MIN_FREE_MB,
                 sleep=time.sleep, log=None, ssl_ctx=None, extra_env=None, native_dir=_AUTO, target=None, va_bits=_AUTO):
        self.data_dir = data_dir
        self.lo = Layout(data_dir)
        self.nice = 0
        self.nonce = ""                                     # mã của MỘT lần người dùng bấm chạy (launch); dịch vụ sticky tự dựng lại thì mã không đổi
        self.poll = 1.0                                     # giây giữa các lần kiểm (test đặt nhỏ)
        self.host, self.port, self.token, self.profile = host, int(port), str(token or ""), profile
        self.scripts = scripts or mt5ea.script_source
        u = {"proot": PROOT_ASSETS_URL, "proot_sha": PROOT_ASSETS_SHA256, "rootfs_dir": ROOTFS_DIR_URL}
        u.update(urls or {})
        self.urls, self.sleep, self.ssl = u, sleep, ssl_ctx
        self.sdk = sdk if sdk is not None else _sdk_int()
        self.target = target if target is not None else _target_sdk()
        self.arch = arch or os.uname().machine
        self.min_free_mb = min_free_mb
        self.extra_env = dict(extra_env or {})
        self._log_fn = log
        self.seccomp = True
        self.binv = None                                    # thư mục chứa libtalloc.so.2 (đường cũ: cả proot/loader)
        self.native = find_native_dir() if native_dir is _AUTO else (native_dir or None)   # proot nằm trong APK (nativeLibraryDir)?
        self.variant = None                                 # «a10» / «base» (chỉ đường native)
        self.va_bits = address_space_bits() if va_bits is _AUTO else int(va_bits or 0)
        self.proc = None
        self._lock = threading.Lock()
        self.install_stage = {}
        os.makedirs(self.lo.root, exist_ok=True)

    # ---- nhật ký / trạng thái / báo về app ----
    def log(self, msg):
        line = "%s %s\n" % (time.strftime("%F %T"), msg)
        try:
            with open(self.lo.log, "a", encoding="utf-8") as f:
                f.write(line)
        except OSError:
            pass
        if self._log_fn:
            self._log_fn(msg)

    def set_state(self, **kv):
        with self._lock:
            d = read_state(self.data_dir)
            d.update(kv)
            d["t"] = time.time()
            try:
                atomic_write(self.lo.state, json.dumps(d, ensure_ascii=False))
            except OSError:
                pass

    def send(self, *msgs):
        """Gửi dòng PyEA-EA tới máy chủ cục bộ của app (kênh giám sát SUPHELLO). Thất bại thì bỏ qua: tiến trình không phụ thuộc app."""
        if not self.token:
            return False
        import socket
        try:
            with socket.create_connection((self.host, self.port), timeout=2.0) as s:
                s.sendall(mt5ea.enc("SUPHELLO", v=1, token=self.token) + b"".join(msgs))
                time.sleep(0.1)
            return True
        except OSError:
            return False

    def event(self, stage, state, detail=""):
        self.install_stage[stage] = {"state": state, "detail": detail, "t": time.time()}
        self.set_state(stages=self.install_stage)
        self.log("[%s] %s %s" % (stage, state, detail))
        self.send(mt5ea.enc("SEVT", kind="install", stage=stage, state=state, detail=detail[:900]))

    def kind(self, kind, **kv):
        self.send(mt5ea.enc("SEVT", kind=kind, **kv))

    def should_stop(self):
        return os.path.exists(self.lo.stop_flag)

    def _check_stop(self):
        if self.should_stop():
            raise Stopped()

    # ---- các bước Python ----
    def stage(self, sid, label, fn, chk=None):
        if chk is not None:
            try:
                done = bool(chk())
            except Exception:                                # noqa: BLE001 - kiểm hỏng = coi như chưa xong, làm lại
                done = False
            if done:
                self.event(sid, "skip", label + " - đã có sẵn")
                return True
        self.event(sid, "start", label)
        try:
            fn()
        except Stopped:
            raise
        except EmbedError as e:
            self.event(sid, "fail", str(e))
            return False
        except Exception as e:                               # noqa: BLE001 - lỗi lạ: kèm loại lỗi để chẩn đoán
            self.event(sid, "fail", "%s: %s" % (type(e).__name__, e))
            return False
        self.event(sid, "ok", label)
        return True

    def _progress_cb(self, sid, what):
        def cb(pos, total=0):
            d = "%s: đã tải %s%s" % (what, human(pos), (" / " + human(total)) if total else "")
            self.event(sid, "progress", d)
        return cb

    def st_precheck(self):
        if self.arch not in ("aarch64", "arm64", "armv8l"):
            raise EmbedError("CPU báo «%s». Cần điện thoại ARM 64-bit (aarch64); máy 32-bit/x86 không chạy được Box64." % self.arch)
        if self.arch == "armv8l":
            raise EmbedError("Máy chạy hệ 32-bit (armv8l) nên không chạy được Box64/Wine 64-bit.")
        os.makedirs(self.lo.root, exist_ok=True)
        free = shutil.disk_usage(self.lo.root).free // 1048576
        if free < self.min_free_mb:
            raise EmbedError("Còn trống %d MB, cần tối thiểu khoảng %d MB (ước lượng cho Ubuntu + Wine + MT5). Dọn bớt rồi chạy lại." % (free, self.min_free_mb))
        if self.native:
            return                                           # proot chạy từ nativeLibraryDir: không cần execve file trong thư mục dữ liệu
        self._probe_exec()

    def _exe(self, name):
        """Đường dẫn thật của proot / loader / loader32 (trong APK nếu có, không thì thư mục tải về)."""
        if self.native:
            return os.path.join(self.native, NATIVE_FILES[self.variant or self._variants()[0]][name])
        return os.path.join(self.binv, name)

    def _probe_exec(self):
        """Đường cũ (không có proot trong APK): Android 10+ chặn execve file trong thư mục dữ liệu của app nhắm API >= 29. Thử thật: tạo script nhỏ rồi chạy."""
        os.makedirs(self.lo.bin, exist_ok=True)
        p = os.path.join(self.lo.bin, ".probe.sh")
        sh = "/system/bin/sh" if os.path.exists("/system/bin/sh") else "/bin/sh"
        with open(p, "w") as f:
            f.write("#!%s\nexit 0\n" % sh)
        os.chmod(p, 0o755)
        try:
            r = subprocess.run([p], timeout=15, capture_output=True)
        except OSError as e:
            raise EmbedError("Android không cho chạy file đã tải trong thư mục của app (%s) và APK này không chứa proot trong thư viện gốc. Dùng APK dựng từ bản mới "
                             "(có native_libs/arm64-v8a/libproot.so, xem docs/MT5_QUICK.md); nếu vẫn lỗi thì ROM của máy chặn - dùng đường Termux." % e)
        finally:
            try:
                os.remove(p)
            except OSError:
                pass
        if r.returncode != 0:
            raise EmbedError("Chạy thử file trong thư mục app trả mã %d: %s" % (r.returncode, (r.stderr or b"")[:200].decode("utf-8", "replace")))

    def _variants(self):
        return ["a10", "base"] if self.sdk >= WX_API else ["base", "a10"]

    def chk_proot(self):
        if not os.path.exists(os.path.join(self.lo.bin, ".ok")):
            return False
        v = open(os.path.join(self.lo.bin, ".ok")).read().strip()
        if v.startswith("native-"):                         # đã chọn bản proot trong APK
            if not self.native or v[7:] not in NATIVE_FILES:
                return False
            self.variant = v[7:]
            self.binv = os.path.join(self.lo.bin, v)
            return (os.access(self._exe("proot"), os.X_OK) and os.access(self._exe("loader"), os.X_OK)
                    and os.path.exists(os.path.join(self.binv, "libtalloc.so.2")))
        if self.native:                                      # .ok cũ của đường tải về, nhưng giờ APK có proot sẵn: làm lại theo đường mới
            return False
        self.binv = os.path.join(self.lo.bin, v)
        return all(os.access(os.path.join(self.binv, n), os.X_OK) for n in PROOT_FILES)

    def st_proot_native(self):
        """proot có sẵn trong APK: không tải gì. Chỉ chép libtalloc.so.2 (tên đúng để trình nạp tìm qua LD_LIBRARY_PATH) rồi thử `proot --version`."""
        errs = []
        for v in self._variants():
            names = NATIVE_FILES[v]
            miss = [n for n in names.values() if not os.path.isfile(os.path.join(self.native, n))]
            if miss:
                errs.append("%s: thiếu %s trong %s" % (v, ",".join(miss), self.native))
                continue
            d = os.path.join(self.lo.bin, "native-" + v)
            rmtree_force(d)
            os.makedirs(d, exist_ok=True)
            dst = os.path.join(d, "libtalloc.so.2")
            shutil.copyfile(os.path.join(self.native, names["talloc"]), dst)
            os.chmod(dst, 0o755)
            self.variant, self.binv = v, d
            ok, why = self._proot_selfcheck()
            if ok:
                atomic_write(os.path.join(self.lo.bin, ".ok"), "native-" + v)
                self.log("proot trong APK (%s) chạy được: %s" % (v, why.splitlines()[0] if why else ""))
                return
            errs.append("%s: %s" % (v, why))
        self.variant, self.binv = None, None
        raise EmbedError("proot đóng gói trong APK không chạy được trên máy này (%s). Có thể ROM chặn hoặc Android quá mới/cũ so với bản proot dựng sẵn." % "; ".join(errs))

    def st_proot(self):
        if self.native:
            return self.st_proot_native()
        zp = os.path.join(self.lo.dl, "proot-assets.zip")
        os.makedirs(self.lo.dl, exist_ok=True)
        if not (os.path.exists(zp) and sha256_file(zp) == self.urls["proot_sha"]):
            download(self.urls["proot"], zp, self.urls["proot_sha"], self._progress_cb("proot", "proot"), self.should_stop, sleep=self.sleep, ctx=self.ssl)
        errs = []
        for v in self._variants():
            d = os.path.join(self.lo.bin, v)
            rmtree_force(d)
            extract_proot_assets(zp, d, v)
            self.binv = d
            ok, why = self._proot_selfcheck()
            if ok:
                atomic_write(os.path.join(self.lo.bin, ".ok"), v)
                return
            errs.append("%s: %s" % (v, why))
        self.binv = None
        raise EmbedError("proot tải về nhưng không chạy được trên máy này (%s). Có thể ROM chặn hoặc Android quá mới/cũ so với bản proot dựng sẵn." % "; ".join(errs))

    def _proot_env(self, extra=None):
        env = {k: os.environ[k] for k in ANDROID_ENV if k in os.environ}
        env.update({"PATH": os.environ.get("PATH", "/system/bin"), "HOME": self.lo.root, "TMPDIR": self.lo.tmp, "PROOT_TMP_DIR": self.lo.tmp,
                    "PROOT_LOADER": self._exe("loader"), "PROOT_LOADER_32": self._exe("loader32"), "LD_LIBRARY_PATH": self.binv})
        if not self.seccomp:
            env["PROOT_NO_SECCOMP"] = "1"
        if extra:
            env.update(extra)
        return env

    def _proot_selfcheck(self):
        os.makedirs(self.lo.tmp, exist_ok=True)
        try:
            r = subprocess.run([self._exe("proot"), "--version"], env=self._proot_env(), capture_output=True, timeout=20)
        except (OSError, subprocess.SubprocessError) as e:
            return False, str(e)[:200]
        out = (r.stdout + r.stderr).decode("utf-8", "replace")
        return (r.returncode == 0, out.strip()[:200])

    def chk_rootfs(self):
        r = self.lo.rootfs
        return os.path.exists(os.path.join(r, ".pyea_rootfs_ok")) and (os.path.exists(os.path.join(r, "usr", "bin", "bash")) or os.path.exists(os.path.join(r, "bin", "bash")))

    def st_rootfs(self):
        os.makedirs(self.lo.dl, exist_ok=True)
        sums = os.path.join(self.lo.dl, "ubuntu-SHA256SUMS")
        download(self.urls["rootfs_dir"].rstrip("/") + "/" + ROOTFS_SUMS, sums, None, None, self.should_stop, sleep=self.sleep, ctx=self.ssl)
        name, sha = pick_rootfs(open(sums, encoding="utf-8", errors="replace").read())
        tb = os.path.join(self.lo.dl, name)
        if not (os.path.exists(tb) and sha256_file(tb) == sha):
            download(self.urls["rootfs_dir"].rstrip("/") + "/" + name, tb, sha, self._progress_cb("rootfs", "Ubuntu"), self.should_stop, sleep=self.sleep, ctx=self.ssl)
        self.event("rootfs", "progress", "đang giải nén hệ Ubuntu (%s)" % human(os.path.getsize(tb)))
        rmtree_force(self.lo.rootfs)
        n = safe_extract_tar(tb, self.lo.rootfs, self.should_stop, lambda k: self.event("rootfs", "progress", "đã giải nén %d mục" % k))
        self.finalize_rootfs()
        atomic_write(os.path.join(self.lo.rootfs, ".pyea_rootfs_ok"), "%s %d\n" % (name, n))
        try:
            os.remove(tb)                                    # đã giải nén; giữ SUMS để biết bản nào. Dung lượng không phải ưu tiên nhưng khỏi tải lại vô ích cũng không cần
        except OSError:
            pass

    SOURCES = ("deb http://ports.ubuntu.com/ubuntu-ports jammy main universe\n"
               "deb http://ports.ubuntu.com/ubuntu-ports jammy-updates main universe\n"
               "deb http://ports.ubuntu.com/ubuntu-ports jammy-security main universe\n")
    APT_CONF = ('APT::Sandbox::User "root";\nAPT::Install-Recommends "false";\nAcquire::Retries "5";\nAcquire::Languages "none";\n'
                'Dpkg::Options { "--force-unsafe-io"; "--force-confold"; };\n')

    def finalize_rootfs(self):
        """Việc nhỏ để apt/dpkg chạy được trong proot: DNS, nguồn apt, tắt sandbox _apt, không khởi động dịch vụ, thư mục cần có."""
        r = self.lo.rootfs
        for d in ("etc/apt/apt.conf.d", "usr/sbin", "root/pyea", "root/.pyea", "tmp", "dev", "proc", "sys", "run", "var/tmp"):
            os.makedirs(os.path.join(r, d), exist_ok=True)
        os.chmod(os.path.join(r, "tmp"), 0o1777)
        os.chmod(os.path.join(r, "var", "tmp"), 0o1777)
        atomic_write(os.path.join(r, "etc", "resolv.conf"), "nameserver 1.1.1.1\nnameserver 8.8.8.8\noptions timeout:2 attempts:3\n")
        atomic_write(os.path.join(r, "etc", "hosts"), "127.0.0.1 localhost\n::1 localhost\n")
        atomic_write(os.path.join(r, "etc", "apt", "sources.list"), self.SOURCES)
        atomic_write(os.path.join(r, "etc", "apt", "apt.conf.d", "99pyea"), self.APT_CONF)
        atomic_write(os.path.join(r, "usr", "sbin", "policy-rc.d"), "#!/bin/sh\nexit 101\n", 0o755)

    # ---- fake /proc (Android 8+ cấm đọc một số file) ----
    def _fake_binds(self):
        os.makedirs(self.lo.fake, exist_ok=True)
        ncpu = os.cpu_count() or 4
        binds = []
        now = int(time.time())

        def readable(p):
            try:
                with open(p, "rb") as f:
                    f.read(1)
                return True
            except OSError:
                return False
        if not readable("/proc/stat"):
            cpus = "".join("cpu%d 1000 0 1000 90000 100 0 100 0 0 0\n" % i for i in range(ncpu))
            atomic_write(os.path.join(self.lo.fake, "stat"), "cpu  %d 0 %d %d 0 0 0 0 0 0\n%sintr 0\nctxt 1000000\nbtime %d\nprocesses 1000\nprocs_running 1\nprocs_blocked 0\n" %
                         (1000 * ncpu, 1000 * ncpu, 90000 * ncpu, cpus, now - 3600))
            binds.append((os.path.join(self.lo.fake, "stat"), "/proc/stat"))
        if not readable("/proc/uptime"):
            atomic_write(os.path.join(self.lo.fake, "uptime"), "3600.00 14400.00\n")
            binds.append((os.path.join(self.lo.fake, "uptime"), "/proc/uptime"))
        if not readable("/proc/version"):
            atomic_write(os.path.join(self.lo.fake, "version"), "Linux version 5.10.0 (fake@pyea) #1 SMP PREEMPT %s\n" % time.strftime("%a %b %d %H:%M:%S UTC %Y", time.gmtime()))
            binds.append((os.path.join(self.lo.fake, "version"), "/proc/version"))
        for n in ("overflowuid", "overflowgid"):
            if not readable("/proc/sys/kernel/" + n):
                atomic_write(os.path.join(self.lo.fake, n), "65534\n")
                binds.append((os.path.join(self.lo.fake, n), "/proc/sys/kernel/" + n))
        return binds

    # ---- dựng lệnh proot ----
    def proot_cmd(self, argv, guest_env=None):
        """(lệnh, môi trường) chạy `argv` BÊN TRONG Ubuntu. Cờ: -0 (giả root), --link2symlink (liên kết cứng cho dpkg), --kill-on-exit (proot chết thì mọi tiến trình khách chết)."""
        if not self.binv:
            raise EmbedError("Chưa có proot (bước «proot» chưa xong).")
        cmd = [self._exe("proot"), "-0", "--link2symlink", "--kill-on-exit", "-r", self.lo.rootfs, "-b", "/dev", "-b", "/proc", "-b", "/sys"]
        if not os.access("/dev/shm", os.R_OK):
            os.makedirs(os.path.join(self.lo.rootfs, "tmp"), exist_ok=True)
            cmd += ["-b", "%s:/dev/shm" % os.path.join(self.lo.rootfs, "tmp")]
        for src, dst in self._fake_binds():
            cmd += ["-b", "%s:%s" % (src, dst)]
        ge = {"HOME": GUEST_ROOT, "USER": "root", "LANG": "C.UTF-8", "PATH": GUEST_PATH, "TERM": "xterm", "TMPDIR": "/tmp", "DEBIAN_FRONTEND": "noninteractive"}
        ge.update(guest_env or {})
        cmd += ["-w", GUEST_ROOT, "/usr/bin/env", "-i"] + ["%s=%s" % kv for kv in ge.items()] + list(argv)
        return cmd, self._proot_env()

    def spawn(self, argv, guest_env=None, out=None):
        cmd, env = self.proot_cmd(argv, guest_env)
        fo = open(out, "ab") if out else subprocess.DEVNULL
        try:
            p = subprocess.Popen(cmd, env=env, stdin=subprocess.DEVNULL, stdout=fo, stderr=subprocess.STDOUT, start_new_session=True, cwd=self.lo.root)
        finally:
            if out:
                fo.close()
        self.proc = p
        try:
            atomic_write(self.lo.pidfile, "%d\n" % p.pid)
        except OSError:
            pass
        if self.nice:
            try:
                os.setpriority(os.PRIO_PROCESS, p.pid, self.nice)       # tiến trình con sinh sau thừa hưởng độ «nhường» này
            except (OSError, AttributeError):
                pass
        return p

    def probe_guest(self):
        """Chạy thử một lệnh trong Ubuntu. Lỗi proot thường gặp (seccomp/ptrace) thì thử lại với PROOT_NO_SECCOMP=1."""
        last = ""
        for sec in (True, False):
            self.seccomp = sec
            cmd, env = self.proot_cmd(["/usr/bin/env", "true"])
            try:
                r = subprocess.run(cmd, env=env, capture_output=True, timeout=60, stdin=subprocess.DEVNULL, cwd=self.lo.root)
            except (OSError, subprocess.SubprocessError) as e:
                last = str(e)[:300]
                continue
            if r.returncode == 0:
                if not sec:
                    self.log("proot chạy được khi tắt seccomp (PROOT_NO_SECCOMP=1)")
                return True, ""
            last = (r.stdout + r.stderr).decode("utf-8", "replace").strip()[-400:]
        return False, last

    # ---- chuẩn bị file cho khách ----
    def prepare_guest(self):
        hr = self.lo.host_root
        os.makedirs(os.path.join(hr, "pyea"), exist_ok=True)
        os.makedirs(os.path.join(hr, ".pyea"), exist_ok=True)
        for n in mt5ea.SCRIPT_FILES:
            p = os.path.join(hr, "pyea", n)
            atomic_write(p, self.scripts(n), 0o755)
        try:                                                 # lớp đệm quyền thực thi cho Box64 (chỉ được script bật khi gặp đúng lỗi; thiếu file thì chỉ mất lớp cứu này)
            atomic_write_bytes(os.path.join(hr, "pyea", mt5ea.SHIM_GUEST_NAME), mt5ea.shim_bytes(), 0o755)
        except Exception as e:                               # noqa: BLE001
            self.log("không chép được lớp đệm %s: %s" % (mt5ea.SHIM_GUEST_NAME, e))
        tok = os.path.join(hr, "pyea", "token")
        atomic_write(tok, self.token, 0o600)
        self.write_override()

    def write_override(self):
        """Biến ghi đè nạp SAU file môi trường của trình cài (port/hồ sơ có thể đổi sau khi cài). Chỉ chứa giá trị không bí mật; token nằm riêng trong file token."""
        lines = ["# do PyEA tạo mỗi lần chạy; run_mt5_termux.sh nạp sau .pyea_env.sh"]
        kv = {"PYEA_HOST": self.host, "PYEA_PORT": str(self.port), "PYEA_PROFILE": self.profile,
              "PYEA_STOP_FILE": GUEST_ROOT + "/.pyea/stop.req"}
        kv.update({k: v for k, v in self.extra_env.items() if k.startswith(("PYEA_", "BOX64_", "WINE", "MIN_UP", "NICE"))})
        for k, v in kv.items():
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", k) or re.search(r"[\r\n]", str(v)):
                continue
            lines.append("export %s='%s'" % (k, str(v).replace("'", "'\\''")))
        atomic_write(os.path.join(self.lo.host_root, ".pyea_override.sh"), "\n".join(lines) + "\n", 0o600)

    # ---- cài ----
    def inner_env(self, redo="", mt5_url="", wine_ver=""):
        e = {"PYEA_TOKEN_FILE": GUEST_ROOT + "/pyea/token", "PYEA_HOST": self.host, "PYEA_PORT": str(self.port), "PYEA_GUEST_ROOT": GUEST_ROOT,
             "PYEA_INSTALL_LOG": GUEST_ROOT + "/.pyea/install.log", "HB_EVERY": "10", "PYEA_PROFILE": self.profile}
        if redo:
            e["PYEA_REDO"] = redo
        if mt5_url:
            e["MT5_SETUP_URL"] = mt5_url
        if wine_ver:                                         # người dùng tự chọn bản Wine; không có thì script dùng MỘT bản cố định (WINE_VER trong install_mt5_termux.sh), KHÔNG đoán theo máy
            e["WINE_VER"] = wine_ver
        return e

    def _wait_proc(self, p, sid, timeout_s):
        """Đợi tiến trình xong, kiểm yêu cầu dừng mỗi giây. Dừng -> yêu cầu dịu rồi giết."""
        end = time.monotonic() + timeout_s
        hb = time.monotonic()
        while p.poll() is None:
            if time.monotonic() - hb >= 10.0:                 # nhịp sống: UI phân biệt «đang cài lâu» với «dịch vụ đã chết»
                hb = time.monotonic()
                self.set_state(hb=time.time())
            if self.should_stop():
                self.terminate(p)
                raise Stopped()
            if time.monotonic() > end:
                self.terminate(p)
                raise EmbedError("Quá %d giây mà bước chưa xong." % timeout_s)
            self.sleep(self.poll)
        return p.returncode

    def run_inner(self, redo="", mt5_url="", wine_ver="", timeout_s=4 * 3600):
        os.makedirs(os.path.dirname(self.lo.install_log), exist_ok=True)
        p = self.spawn(["/bin/bash", GUEST_ROOT + "/pyea/install_mt5_termux.sh", "inner"], self.inner_env(redo, mt5_url, wine_ver), out=self.lo.log)
        return self._wait_proc(p, "inner", timeout_s)

    def failed_stage_from_log(self):
        m = re.findall(r"LỖI ở bước «([a-z0-9_]+)»: (.*)", tail_text(self.lo.install_log, 6000))
        return m[-1] if m else None

    STAGE_HINTS = (("Cài thư viện nền", "apt"), ("Box64", "box64"), ("Khởi tạo Wine", "prefix"), ("Tải Wine", "wine"), ("MetaTrader", "mt5"), ("Chép EA", "provision"),
                   ("Biên dịch", "compile"))

    def last_stage_from_log(self):
        """Bước đang chạy khi script trong Ubuntu chết/quá giờ, đoán từ dòng «▶ nhãn ...» cuối cùng trong install.log (không có thì «apt»)."""
        for line in reversed(tail_text(self.lo.install_log, 6000).splitlines()):
            if "▶" in line:
                for key, sid in self.STAGE_HINTS:
                    if key in line:
                        return sid
        return "apt"

    def install(self, redo="", mt5_url="", wine_ver=""):
        """Chạy mọi bước cài (làm tiếp từ bước dở). True nếu xong. Dùng lại được: bước đã xong tự bỏ qua."""
        self.set_state(phase="installing", profile=self.profile, error="", nonce=self.nonce, run_t=time.time())
        try:
            if not self.stage("precheck", "Kiểm tra máy (CPU 64-bit, dung lượng, chạy được file tải về)", self.st_precheck):
                return self._fail("precheck")
            if not self.stage("proot", "Tải proot (chạy Linux không cần root)", self.st_proot, self.chk_proot):
                return self._fail("proot")
            if not self.stage("rootfs", "Tải và giải nén Ubuntu 22.04 arm64", self.st_rootfs, self.chk_rootfs):
                return self._fail("rootfs")
            self.prepare_guest()
            ok, why = self.probe_guest()
            if not ok:
                self.event("rootfs", "fail", "proot không chạy được lệnh trong Ubuntu: %s" % why)
                return self._fail("rootfs")
            rc = self.run_inner(redo, mt5_url, wine_ver)
        except Stopped:
            self.set_state(phase="stopped")
            return False
        except EmbedError as e:                               # quá giờ ở phần cài trong Ubuntu
            sid = self.last_stage_from_log()
            self.event(sid, "fail", str(e))
            return self._fail(sid)
        except OSError as e:
            self.event("rootfs", "fail", "Lỗi tệp/thư mục khi chuẩn bị: %s" % e)
            return self._fail("rootfs")
        if rc != 0:
            f = self.failed_stage_from_log()
            if f is None:                                     # script chết mà không kịp báo (bị giết/hết bộ nhớ)
                sid = self.last_stage_from_log()
                self.event(sid, "fail", "Phần cài trong Ubuntu thoát mã %d mà không báo lỗi (bị Android giết? thiếu RAM? Android 12+ có «giới hạn tiến trình con»). Xem chẩn đoán." % rc)
                return self._fail(sid)
            return self._fail(f[0])
        self.set_state(phase="installed")
        return True

    def _fail(self, sid):
        self.set_state(phase="failed", failed_stage=sid, error=(self.install_stage.get(sid) or {}).get("detail", ""))
        return False

    # ---- chạy ----
    def start_run(self):
        self.prepare_guest()
        env = {"PYEA_ENV": GUEST_ROOT + "/.pyea_env.sh", "PYEA_ENV_OVERRIDE": GUEST_ROOT + "/.pyea_override.sh", "PYEA_TOKEN_FILE": GUEST_ROOT + "/pyea/token",
               "PYEA_HOST": self.host, "PYEA_PORT": str(self.port), "PYEA_PROFILE": self.profile, "PYEA_STOP_FILE": GUEST_ROOT + "/.pyea/stop.req"}
        try:
            os.remove(self.lo.stop_req)
        except OSError:
            pass
        return self.spawn(["/bin/bash", GUEST_ROOT + "/pyea/run_mt5_termux.sh", "run"], env, out=self.lo.log)

    def terminate(self, p=None, grace=15.0):
        """Dừng dịu: tạo file yêu cầu để script giám sát tự dọn (tắt Wine), rồi SIGTERM, cuối cùng SIGKILL. proot có --kill-on-exit nên giết proot là giết cả cây."""
        p = p or self.proc
        if p is None or p.poll() is not None:
            return
        try:
            os.makedirs(os.path.dirname(self.lo.stop_req), exist_ok=True)
            open(self.lo.stop_req, "w").close()
        except OSError:
            pass
        step = min(0.3, self.poll)
        for _ in range(max(1, int(grace / step))):
            if p.poll() is not None:
                break
            self.sleep(step)
        for sig in (signal.SIGTERM, signal.SIGKILL):
            if p.poll() is not None:
                break
            try:
                os.killpg(p.pid, sig)
            except (OSError, ProcessLookupError):
                try:
                    p.send_signal(sig)
                except OSError:
                    pass
            for _ in range(20):
                if p.poll() is not None:
                    break
                self.sleep(min(0.2, self.poll))

    def kill_orphans(self):
        """Dịch vụ bị Android giết rồi dựng lại: proot cũ có thể còn chạy mồ côi -> dọn để khỏi hai MT5 cùng chạy."""
        try:
            pid = int(open(self.lo.pidfile).read().strip())
        except (OSError, ValueError):
            return False
        try:
            with open("/proc/%d/cmdline" % pid, "rb") as f:
                cl = f.read()
        except OSError:
            cl = b""
        if b"proot" in cl:
            self.log("dọn tiến trình proot mồ côi pid %d" % pid)
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(pid, sig)
                except OSError:
                    try:
                        os.kill(pid, sig)
                    except OSError:
                        pass
                self.sleep(min(1.0, self.poll))
        try:
            os.remove(self.lo.pidfile)
        except OSError:
            pass
        return True

    def supervise(self, report_every=10.0, nice=None):
        self.nice = nice or self.nice
        """Giữ script giám sát chạy: chết thì dựng lại (lùi dần), chết nhanh nhiều lần thì bỏ cuộc và báo. Lean lỗi lặp (mã 2) -> tự chuyển hồ sơ «stable» một lần."""
        backoff, fast = 5.0, 0
        while not self.should_stop():
            t0 = time.monotonic()
            p = self.start_run()
            self.set_state(phase="running", profile=self.profile, pid=p.pid, started=time.time())
            self.event("login", "start", "bật MT5, đăng nhập tài khoản và nối EA vào app")
            smp, nxt = Sampler(p.pid), 0.0
            while p.poll() is None and not self.should_stop():
                self.sleep(self.poll)
                if time.monotonic() >= nxt:
                    nxt = time.monotonic() + report_every
                    self.report_res(smp, nice)
            if self.should_stop():
                self.terminate(p)
                self.set_state(phase="stopped")
                return True
            rc, up = p.returncode, time.monotonic() - t0
            self.kind("emu_exit", code=rc, up=int(up), profile=self.profile)
            self.log("script giám sát thoát mã %s sau %ds" % (rc, up))
            if rc == 2 and self.profile == "lean":
                self.profile = "stable"
                write_request(self.data_dir, profile="stable")
                self.kind("profile", to="stable", why="MT5 chết nhanh liên tiếp với hồ sơ lean")
                self.log("MT5 chết nhanh liên tiếp ở hồ sơ lean -> chuyển sang stable")
                fast = 0
                continue
            fast = 0 if up >= MIN_UP_S else fast + 1
            backoff = 5.0 if up >= MIN_UP_S else min(300.0, backoff * 2)
            if fast >= MAX_FAST_FAILS:
                self.set_state(phase="failed", failed_stage="login", error="Giám sát MT5 chết nhanh %d lần liên tiếp (mã %s)." % (fast, rc))
                self.event("login", "fail", "Giám sát MT5 chết nhanh %d lần liên tiếp (mã %s). Xem chẩn đoán." % (fast, rc))
                return False
            for _ in range(max(1, int(backoff))):
                if self.should_stop():
                    break
                self.sleep(self.poll)
        self.set_state(phase="stopped")
        return True

    def report_res(self, smp, nice=None):
        try:
            s = smp.sample()
        except Exception as e:                               # noqa: BLE001 - đo hỏng không được làm sập giám sát
            self.log("đo CPU/RAM lỗi: %r" % (e,))
            return None
        self.set_state(res=s)
        self.kind("res", cpu=s["cpu"], rss=s["rss_mb"], procs=s["procs"], top=s["top"])
        if nice:
            for pid, *_ in smp.members():
                try:
                    if os.getpriority(os.PRIO_PROCESS, pid) < nice:
                        os.setpriority(os.PRIO_PROCESS, pid, nice)
                except (OSError, AttributeError):
                    pass
        return s

    def serve(self, redo="", mt5_url="", wine_ver="", nice=None):
        """Việc của dịch vụ nền Emu: dọn mồ côi -> cài (làm tiếp) -> giám sát tới khi có yêu cầu dừng. True nếu kết thúc êm."""
        self.nice = nice or 0
        try:
            if self.should_stop():                           # người dùng đã bấm Dừng (kể cả khi Android dựng lại dịch vụ sticky): không tự chạy lại
                self.set_state(phase="stopped")
                return True
            self.kill_orphans()
            if not self.install(redo, mt5_url, wine_ver):
                return False
            return self.supervise(nice=nice)
        except Stopped:
            self.set_state(phase="stopped")
            return True

    def va_note(self):
        """Ghi chú chẩn đoán khi không gian địa chỉ ảo hẹp (đo thật). KHÔNG đổi cách cài: chỉ giúp đọc lỗi «map_fixed_area out of memory» nếu có. Rỗng nếu rộng/không đo được."""
        if 0 < self.va_bits <= NARROW_VA_BITS:
            return ("không gian địa chỉ ảo của máy chỉ %d-bit (Wine x86-64 hay cần ~47-bit): nếu nhật ký có «map_fixed_area out of memory» thì đó là giới hạn của máy/nhân Android, "
                    "không phải lỗi mạng hay lỗi cài đặt." % self.va_bits)
        return ""

    def diagnostics(self):
        note = play_protect_note(self.sdk, self.target)
        va = self.va_note()
        return diagnostics_text(self.data_dir, self.token, "profile=%s sdk=%s target=%s arch=%s seccomp=%s proot=%s native=%s variant=%s va=%s%s%s" % (
            self.profile, self.sdk, self.target, self.arch, self.seccomp, self.binv, self.native, self.variant, self.va_bits or "?",
            ("\nLƯU Ý: " + note) if note else "", ("\nLƯU Ý: " + va) if va else ""))


_SIGS = (("zip", b"PK\x03\x04"), ("7z", b"7z\xbc\xaf\x27\x1c"), ("cab", b"MSCF\x00\x00\x00\x00"), ("xz", b"\xfd7zXZ\x00"), ("gzip", b"\x1f\x8b\x08"), ("bzip2", b"BZh"), ("rar", b"Rar!\x1a\x07"),
         ("zstd", b"\x28\xb5\x2f\xfd"), ("lzma", b"\x5d\x00\x00\x80\x00"), ("ole/msi", b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"), ("nsis", b"NullsoftInst"), ("inno", b"Inno Setup Setup Data"),
         ("pe-nhúng", b"This program cannot be run in DOS mode"))
_STR_HITS = (b"terminal64.exe", b"metaeditor64.exe", b"MetaQuotes", b"IsDebuggerPresent", b"NtQueryInformationProcess", b"CheckRemoteDebuggerPresent", b"VirtualBox", b"VMware", b"WINE", b"wine_get_version",
             b"WebView2", b"WinHttp", b"InternetOpen")


def _entropy(b):
    if not b:
        return 0.0
    import math
    from collections import Counter
    n = float(len(b))
    return -sum((c / n) * math.log(c / n, 2) for c in Counter(b).values())


def pe_report(path, max_bytes=96 * 1024 * 1024):
    """Mô tả CẤU TRÚC tệp bộ cài (PE) để biết nó là gì mà KHÔNG chạy gì: tiêu đề + các section (kích cỡ, entropy), phần thừa cuối tệp (overlay: nơi bộ nén/gói dữ liệu thường nằm), dấu hiệu
    các định dạng nén trong tệp (vị trí), một số chuỗi, và các «stub» gọi syscall Windows TRỰC TIẾP (mov r10,rcx; mov eax,N; syscall; ret) kèm số N. Cái cuối kiểm chứng giả thuyết «bộ cài gọi
    syscall trực tiếp nên Wine/Box64 xử lý bằng Syscall User Dispatch rồi quay vòng». Không bao giờ ném: lỗi thì trả một dòng nói rõ."""
    import re
    import struct
    try:
        size = os.path.getsize(path)
    except OSError:
        return "không có tệp %s" % os.path.basename(path)
    try:
        with open(path, "rb") as f:
            data = f.read(max_bytes)
        out = ["tệp=%s %d byte%s" % (os.path.basename(path), size, " (chỉ đọc %d byte đầu)" % len(data) if size > len(data) else "")]
        if data[:2] != b"MZ" or len(data) < 0x40:
            return "; ".join(out + ["KHÔNG phải PE (không có 'MZ'); 16 byte đầu=%s" % data[:16].hex()])
        pe = struct.unpack_from("<I", data, 0x3C)[0]
        if data[pe:pe + 4] != b"PE\0\0":
            return "; ".join(out + ["có 'MZ' nhưng không thấy 'PE\\0\\0' ở %d" % pe])
        machine, nsec, _ts, _sym, _nsym, optsz, chars = struct.unpack_from("<HHIIIHH", data, pe + 4)
        opt = pe + 24
        magic = struct.unpack_from("<H", data, opt)[0]
        subsystem = struct.unpack_from("<H", data, opt + 68)[0]
        out.append("PE máy=0x%X (%s) %s subsystem=%d section=%d" % (machine, {0x8664: "x64", 0x14c: "x86", 0xAA64: "arm64"}.get(machine, "?"), "PE32+" if magic == 0x20B else "PE32", subsystem, nsec))
        sec_at, end_raw, secs = opt + optsz, 0, []
        for i in range(min(nsec, 40)):
            nm, vsz, _va, rsz, rptr = struct.unpack_from("<8sIIII", data, sec_at + 40 * i)
            end_raw = max(end_raw, rptr + rsz)
            blk = data[rptr:rptr + min(rsz, 1 << 20)]
            secs.append("%s raw=%d ent=%.2f" % (nm.rstrip(b"\0").decode("latin1", "replace"), rsz, _entropy(blk)))
        out.append("sections: " + ", ".join(secs))
        ov = max(0, size - end_raw)
        if ov:
            out.append("overlay: từ %d, %d byte, entropy đầu=%.2f giữa=%.2f cuối=%.2f" % (end_raw, ov, _entropy(data[end_raw:end_raw + (1 << 18)]),
                       _entropy(data[end_raw + ov // 2:end_raw + ov // 2 + (1 << 18)]), _entropy(data[max(end_raw, len(data) - (1 << 18)):])))
        hits = []
        for name, sig in _SIGS:
            pos, found, n = 0, [], 0
            while True:
                pos = data.find(sig, pos)
                if pos < 0:
                    break
                n += 1
                if len(found) < 6 and not (name == "pe-nhúng" and pos < 0x200):
                    found.append(pos)
                pos += 1
            if n:
                hits.append("%s×%d@%s" % (name, n, ",".join(str(x) for x in found)))
        out.append("dấu_hiệu_định_dạng: " + (" ".join(hits) or "không thấy"))
        out.append("chuỗi: " + (" ".join("%s×%d" % (x.decode(), data.count(x)) for x in _STR_HITS if x in data) or "không thấy"))
        stubs = re.findall(b"\x4c\x8b\xd1\xb8(.{4})\x0f\x05\xc3", data, re.S)
        nums = sorted({struct.unpack("<I", x)[0] for x in stubs})
        out.append("stub_syscall_trực_tiếp: %d (số hiệu: %s)" % (len(stubs), ",".join("0x%X" % n for n in nums[:24]) or "không"))
        out.append("lệnh_syscall_rời(0F 05): %d" % data.count(b"\x0f\x05"))
        return "\n".join(out)
    except Exception as e:                                    # noqa: BLE001
        return "không phân tích được %s: %s: %s" % (os.path.basename(path), type(e).__name__, e)


def diagnostics_text(data_dir, token="", extra=""):
    """Chẩn đoán dán/gửi được (đọc từ file nên dùng được cả khi dịch vụ không chạy). Token luôn bị che."""
    lo = Layout(data_dir)
    st = read_state(data_dir)
    st.pop("token", None)
    try:
        from . import android_native as _an
        apk = _an.app_signature_line()
    except Exception:
        apk = ""
    lines = ["PyEA - chẩn đoán MT5 nhúng (%s)" % time.strftime("%F %T"), "phase=%s %s" % (st.get("phase"), extra)] + ([apk] if apk else []) + [ "state=%s" % json.dumps(st, ensure_ascii=False)[:1500],
             "request=%s" % json.dumps({k: v for k, v in read_request(data_dir).items() if k != "token"}, ensure_ascii=False)[:600],
             "--- emu.log ---", tail_text(lo.log, 3000), "--- install.log ---", tail_text(lo.install_log, 3000), "--- chẩn đoán Wine (wine_diag.txt) ---", tail_text(lo.wine_diag, 24000),
             "--- đo quyền thực thi (exec_probe.txt) ---", tail_text(lo.exec_probe, 1200), "--- lớp đệm (shim.log) ---", tail_text(lo.shim_log, 1500),
             "--- quay vòng: CPU từng tiến trình/luồng (mt5_spin.txt) ---", tail_text(lo.spin_log, 6000),
             "--- trạng thái từng bước (stages.log: epoch id state) ---", tail_text(lo.stages_log, 1500),
             "--- cấu trúc bộ cài (mt5setup.exe; chỉ đọc, không chạy) ---", pe_report(lo.setup_exe),
             "--- run log ---", tail_text(lo.run_log, 2500)]
    shot = tail_text(lo.mt5_shot, 70000).strip()          # ảnh nằm CUỐI chẩn đoán, trọn một dòng (script giới hạn 60000 ký tự); không có thì bỏ mục này
    if shot:
        lines += ["--- ảnh màn hình bộ cài lúc đứng im (mt5_screen.b64; giải: python3 tools/mt5_phone/xwd_decode.py <tệp> ra.png) ---", shot]
    out = "\n".join(lines)
    token = token or str(read_request(data_dir).get("token") or "")
    return out.replace(token, "***") if token else out


def supported(arch=None, sdk=None, target=None, has_service=None, native=_AUTO):
    """(được, lý do): máy/APK này chạy được MT5 nhúng không? Tham số để test; thật thì tự đọc từ Android."""
    from . import android_native as an
    if not an.IS_ANDROID and sdk is None:
        return False, "không phải Android"
    arch = arch or os.uname().machine
    if arch not in ("aarch64", "arm64"):
        return False, "CPU %s không phải ARM 64-bit (Box64 cần aarch64)" % arch
    sdk = an.sdk_int() if sdk is None else sdk
    target = an.target_sdk() if target is None else target
    if native is _AUTO:
        native = find_native_dir()
    if sdk >= WX_API and target >= WX_API and not native:
        return False, ("APK nhắm API %d (>= %d) nên Android %d chặn chạy file tải về trong thư mục app, mà APK này lại không chứa proot trong thư viện gốc "
                       "(native_libs/arm64-v8a/libproot.so). Dùng APK dựng từ bản mới; (dự phòng cuối: PYEA_TARGET_SDK=<số thấp>, nhưng Play Protect có thể chặn cài)" % (target, WX_API, sdk))
    if has_service is None:
        has_service = an.service_present(an.EMU_SERVICE_NAME)
    if not has_service:
        return False, "APK này không có dịch vụ Emu (dựng từ buildozer.spec cũ)"
    return True, ""


def play_protect_note(sdk, target):
    """Cảnh báo (chuỗi, rỗng nếu ổn) khi targetSdk của APK thấp hơn API của máy quá PLAY_PROTECT_GAP mức - lúc đó Play Protect có thể chặn cài/cảnh báo.
    Tính từ chính máy + APK đang chạy nên không phụ thuộc máy cụ thể; sdk/target không đọc được (0) thì bỏ qua."""
    if not sdk or not target:
        return ""
    if target < sdk - PLAY_PROTECT_GAP:
        return ("targetSdk %d thấp hơn Android của máy (API %d) quá %d mức: Play Protect có thể chặn/cảnh báo khi cài. "
                "Nâng android.api trong buildozer.spec (và dựng lại) chứ không ghi cứng theo máy." % (target, sdk, PLAY_PROTECT_GAP))
    return ""


def _target_sdk():
    try:
        from . import android_native
        return android_native.target_sdk()
    except Exception:                                        # noqa: BLE001 - không phải Android
        return 0


def _sdk_int():
    try:
        from . import android_native
        return android_native.sdk_int()
    except Exception:                                        # noqa: BLE001 - không phải Android
        return 0


def clear_all(data_dir, keep_downloads=False):
    """Xoá toàn bộ MT5 nhúng (hệ Ubuntu, Wine, MT5, tải về). Gọi khi dịch vụ đã dừng."""
    lo = Layout(data_dir)
    rmtree_force(lo.rootfs)
    rmtree_force(lo.bin)
    rmtree_force(lo.fake)
    rmtree_force(lo.tmp)
    if not keep_downloads:
        rmtree_force(lo.dl)
    for p in (lo.state, lo.pidfile, lo.stop_flag, lo.request):
        try:
            os.remove(p)
        except OSError:
            pass


GUEST_MT5_HOME = GUEST_ROOT + "/.wine-mt5/drive_c/pyea-mt5"     # mỗi link bộ cài MỘT thư mục con (install_mt5_termux.sh: MT5_HOME_DIR)


def _tree_size(path):
    """Tổng cỡ tệp trong thư mục (không đi theo liên kết)."""
    total = 0
    for root, _dirs, files in os.walk(path):
        for n in files:
            try:
                total += os.lstat(os.path.join(root, n)).st_size
            except OSError:
                pass
    return total


def mt5_installs(data_dir, sizes=True):
    """Các bản MT5 đã cài (mỗi link bộ cài một thư mục) và bản nào đang dùng (`~/mt5` trỏ tới).
    Trả {"ok", "why", "active", "items": [{"key", "path", "size", "active"}]}. ok=False khi không xác định được bản đang dùng: khi đó KHÔNG được xoá gì."""
    lo = Layout(data_dir)
    home = os.path.join(lo.host_root, ".wine-mt5", "drive_c", "pyea-mt5")
    out = {"ok": False, "why": "", "active": None, "items": []}
    try:
        target = os.readlink(os.path.join(lo.host_root, "mt5"))
    except OSError:
        out["why"] = "chưa có bản MT5 đang dùng (cài chưa xong?)"
        return out
    if not target.startswith("/"):
        target = posixpath.join(GUEST_ROOT, target)
    target = posixpath.normpath(target)
    if not os.path.isdir(os.path.join(lo.rootfs, target.lstrip("/"))):
        out["why"] = "liên kết tới bản MT5 đang dùng bị hỏng"
        return out
    if posixpath.dirname(target) == GUEST_MT5_HOME:
        out["active"] = posixpath.basename(target)
    try:
        names = sorted(os.listdir(home))
    except OSError:
        names = []
    for n in names:
        p = os.path.join(home, n)
        if os.path.islink(p) or not os.path.isdir(p):
            continue
        out["items"].append({"key": n, "path": p, "size": _tree_size(p) if sizes else 0, "active": n == out["active"]})
    out["ok"] = True
    return out


def prune_mt5(data_dir):
    """Xoá các bản MT5 KHÔNG dùng (thư mục của các link bộ cài khác). Giữ nguyên bản đang dùng; từ chối khi đang cài hoặc không rõ bản nào đang dùng.
    Xoá cả dữ liệu trong các bản đó (tài khoản đã đăng nhập, EA đã gắn): quay lại link đó sẽ phải cài lại. Trả {"ok", "removed", "freed", "failed", "msg"}."""
    res = {"ok": False, "removed": 0, "freed": 0, "failed": 0, "msg": ""}
    st = status(data_dir)
    if st["phase"] == "installing" and st["alive"]:
        res["msg"] = "Đang cài MT5: đợi cài xong rồi hãy dọn."
        return res
    info = mt5_installs(data_dir)
    if not info["ok"]:
        res["msg"] = "Không dọn: %s." % info["why"]
        return res
    for it in info["items"]:
        if it["active"]:
            continue
        rmtree_force(it["path"])
        if os.path.lexists(it["path"]):
            res["failed"] += 1
        else:
            res["removed"] += 1
            res["freed"] += it["size"]
    # sổ «link -> thư mục» (mt5_dir.<mã>): bỏ dòng trỏ vào thư mục không còn, để lần sau script không tưởng là đã cài
    lo = Layout(data_dir)
    sdir = os.path.dirname(lo.install_log)
    try:
        notes = [n for n in os.listdir(sdir) if n.startswith("mt5_dir.")]
    except OSError:
        notes = []
    for n in notes:
        f = os.path.join(sdir, n)
        try:
            with open(f, encoding="utf-8") as fh:
                guest = (fh.read().strip().splitlines() or [""])[0]
        except OSError:
            continue
        if not guest or not os.path.isdir(os.path.join(lo.rootfs, guest.lstrip("/"))):
            try:
                os.remove(f)
            except OSError:
                pass
    res["ok"] = res["failed"] == 0
    if res["removed"]:
        res["msg"] = "Đã dọn %d bản MT5 không dùng, giải phóng %s." % (res["removed"], human(res["freed"]))
    else:
        res["msg"] = "Không có bản MT5 nào không dùng để dọn."
    if res["failed"]:
        res["msg"] += " Không xoá được %d bản (thử lại sau khi dừng MT5)." % res["failed"]
    return res


def service_main(argument):
    """Chạy trong dịch vụ p4a «Emu» (service_emu.py). Tham số (JSON): data_dir; cấu hình đọc thêm từ emu/request.json (dịch vụ sticky khởi động lại không kèm tham số)."""
    try:
        arg = json.loads(argument) if argument else {}
    except ValueError:
        arg = {}
    data_dir = arg.get("data_dir")
    if not data_dir:
        raise EmbedError("thiếu data_dir")
    req = read_request(data_dir)
    req.update({k: v for k, v in arg.items() if v not in (None, "")})
    if str(req.get("want", "run")) == "stop":
        return True
    nonce = str(req.get("nonce") or "")
    if nonce and read_state(data_dir).get("phase") == "failed" and read_state(data_dir).get("nonce") == nonce:
        # Android dựng lại dịch vụ sticky SAU KHI lần chạy này đã báo lỗi: không tự cài lại (log thật: lặp 14 lần, mỗi lần ~5 phút, cùng một lỗi,
        # tốn pin/mạng mà không sửa được gì). Người dùng bấm «Chạy lại» -> launch() đổi mã -> mới chạy.
        return False
    emb = Embedded(data_dir, port=int(req.get("port") or 18765), token=str(req.get("token") or ""), profile=str(req.get("profile") or "lean"),
                   extra_env=req.get("env") or {})
    emb.nonce = nonce
    return emb.serve(redo=str(req.get("redo") or ""), mt5_url=str(req.get("mt5_url") or ""), wine_ver=str(req.get("wine_ver") or ""), nice=int(req.get("nice") or 0) or None)


# ----------------------------------------------------------------------------------------------- phía app (UI) điều khiển dịch vụ Emu
def _start_service(argument):
    from . import android_native as an
    return an.start_service(argument, title="PyEA Runner - MT5 nhúng", text="Đang chuẩn bị...", name=an.EMU_SERVICE_NAME, foreground=True)


def _stop_service():
    from . import android_native as an
    return an.stop_service(an.EMU_SERVICE_NAME)


def launch(data_dir, port, token, profile="lean", mt5_url="", wine_ver="", redo="", nice=0, starter=None):
    """Bật dịch vụ Emu: cài (làm tiếp) rồi chạy MT5. Mật khẩu KHÔNG đi qua đây (nó ở RAM của app, script lấy qua cổng cục bộ). Trả (ok, lỗi)."""
    request_stop(data_dir, False)
    write_request(data_dir, want="run", port=int(port), token=str(token), profile=profile, mt5_url=mt5_url, wine_ver=wine_ver, redo=redo, nice=int(nice or 0),
                  nonce="%x-%s" % (int(time.time() * 1000), os.urandom(3).hex()))
    return (starter or _start_service)(json.dumps({"data_dir": data_dir}))


def stop(data_dir, wait=30.0, stopper=None, sleep=time.sleep):
    """Dừng dịu: ghi yêu cầu dừng, đợi dịch vụ tự tắt Wine/MT5 (tối đa `wait` giây), rồi mới tắt dịch vụ."""
    write_request(data_dir, want="stop")
    request_stop(data_dir)
    for _ in range(int(wait / 0.5)):
        if read_state(data_dir).get("phase") in ("stopped", "failed", "installed", "idle", None):
            break
        sleep(0.5)
    return (stopper or _stop_service)()


def status(data_dir, now=None):
    """Tóm tắt cho giao diện: phase (idle|installing|installed|running|stopped|failed), error, failed_stage, res, alive (dịch vụ còn ghi nhịp trong 60s)."""
    st = read_state(data_dir)
    now = time.time() if now is None else now
    ph = st.get("phase") or "idle"
    alive = ph in ("installing", "running") and (now - float(st.get("t") or 0)) < 60.0
    return {"phase": ph, "error": st.get("error", ""), "failed_stage": st.get("failed_stage", ""), "res": st.get("res") or {}, "alive": alive,
            "profile": st.get("profile", ""), "installed": os.path.exists(os.path.join(Layout(data_dir).rootfs, ".pyea_rootfs_ok"))}
