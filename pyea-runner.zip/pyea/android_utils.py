"""Tiện ích riêng cho Android (pyjnius). Mọi import đều lazy để chạy được trên máy tính."""
import traceback

from kivy.utils import platform

IS_ANDROID = platform == "android"
_REQ_PICK = 4242
_wake_lock = None
_pick_cb = None


def _activity():
    from jnius import autoclass
    return autoclass("org.kivy.android.PythonActivity").mActivity


def external_files_dir():
    """Thư mục riêng của app trên bộ nhớ ngoài (Android/data/<gói>/files) - người dùng lấy file qua USB/trình quản lý file mà KHÔNG cần
    xin quyền bộ nhớ. Trả về None nếu không phải Android hoặc lỗi."""
    if not IS_ANDROID:
        return None
    try:
        d = _activity().getExternalFilesDir(None)
        return str(d.getAbsolutePath()) if d is not None else None
    except Exception:
        return None


# ---------------------------------------------------------------- chọn file (SAF)
def pick_file(callback):
    """Mở bộ chọn file hệ thống (Storage Access Framework, không cần xin quyền bộ nhớ).
    callback(filename, text, error). Đọc nội dung dạng text UTF-8."""
    global _pick_cb
    if not IS_ANDROID:
        callback(None, None, "not_android")
        return
    try:
        from android import activity
        from jnius import autoclass
        Intent = autoclass("android.content.Intent")
        _pick_cb = callback
        activity.bind(on_activity_result=_on_result)
        intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.setType("*/*")
        _activity().startActivityForResult(intent, _REQ_PICK)
    except Exception:
        callback(None, None, traceback.format_exc(limit=3))


def _on_result(request_code, result_code, intent):
    global _pick_cb
    if request_code != _REQ_PICK:
        return
    from android import activity
    try:
        activity.unbind(on_activity_result=_on_result)
    except Exception:
        pass
    cb, _pick_cb = _pick_cb, None
    if cb is None:
        return
    if result_code != -1 or intent is None:      # RESULT_OK = -1
        cb(None, None, "cancelled")
        return
    try:
        from jnius import autoclass
        uri = intent.getData()
        resolver = _activity().getContentResolver()
        name = "bot.py"
        OpenableColumns = autoclass("android.provider.OpenableColumns")
        cur = resolver.query(uri, None, None, None, None)
        if cur is not None:
            try:
                if cur.moveToFirst():
                    idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if idx >= 0:
                        name = cur.getString(idx) or name
            finally:
                cur.close()
        stream = resolver.openInputStream(uri)
        Scanner = autoclass("java.util.Scanner")
        sc = Scanner(stream, "UTF-8").useDelimiter("\\A")
        text = sc.next() if sc.hasNext() else ""
        stream.close()
        cb(name, text, None)
    except Exception:
        cb(None, None, traceback.format_exc(limit=3))


# ---------------------------------------------------------------- chọn tệp LỚN (zip MT5) và chép sang thư mục của app
_REQ_PICK_COPY = 4243
_copy_cb = None
_copy_dest = None
ZIP_MAX_BYTES = 3 << 30          # trần 3 GB: tệp lớn hơn gần như chắc không phải thư mục MT5 và làm đầy bộ nhớ


def finalize_part(part_path, dest_path, magic=b"PK"):
    """Tệp .part đã chép xong: kiểm đầu tệp (zip bắt đầu «PK»), rồi đổi tên thành dest_path. Sai -> xoá .part và ném ValueError. Trả số byte."""
    import os
    try:
        size = os.path.getsize(part_path)
        with open(part_path, "rb") as f:
            head = f.read(len(magic))
        if size <= 0:
            raise ValueError("Tệp rỗng")
        if head != magic:
            raise ValueError("Đây không phải tệp .zip (đầu tệp không phải «PK»). Hãy nén thư mục MetaTrader 5 thành .zip rồi chọn lại.")
        if size > ZIP_MAX_BYTES:
            raise ValueError("Tệp quá lớn (%d MB), tối đa %d MB" % (size >> 20, ZIP_MAX_BYTES >> 20))
        os.replace(part_path, dest_path)
        return size
    except Exception:
        try:
            os.remove(part_path)
        except OSError:
            pass
        raise


def copy_stream_to(src, dest_path, chunk=1 << 20, limit=ZIP_MAX_BYTES):
    """Chép đối tượng đã mở (có read(n)) vào dest_path qua tệp .part, kiểm «PK», đổi tên. Trả số byte. Không đọc cả tệp vào RAM."""
    part = dest_path + ".part"
    total = 0
    try:
        with open(part, "wb") as out:
            while True:
                b = src.read(chunk)
                if not b:
                    break
                total += len(b)
                if total > limit:
                    raise ValueError("Tệp quá lớn (> %d MB)" % (limit >> 20))
                out.write(b)
    except Exception:
        try:
            import os
            os.remove(part)
        except OSError:
            pass
        raise
    return finalize_part(part, dest_path)


def pick_file_copy(dest_path, callback):
    """Mở bộ chọn file hệ thống (SAF, không cần quyền bộ nhớ) rồi CHÉP tệp được chọn vào dest_path ở luồng nền (tệp zip MT5 hàng trăm MB, không đọc vào RAM).
    callback(tên_tệp, số_byte, lỗi) - gọi từ luồng nền hoặc luồng giao diện: lỗi None = xong, «cancelled» = người dùng đóng bộ chọn. CHƯA thử trên máy thật."""
    global _copy_cb, _copy_dest
    if not IS_ANDROID:
        callback(None, 0, "not_android")
        return
    try:
        from android import activity
        from jnius import autoclass
        Intent = autoclass("android.content.Intent")
        _copy_cb, _copy_dest = callback, dest_path
        activity.bind(on_activity_result=_on_copy_result)
        intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.setType("*/*")
        _activity().startActivityForResult(intent, _REQ_PICK_COPY)
    except Exception:
        _copy_cb = None
        callback(None, 0, traceback.format_exc(limit=3))


def _on_copy_result(request_code, result_code, intent):
    global _copy_cb, _copy_dest
    if request_code != _REQ_PICK_COPY:
        return
    from android import activity
    try:
        activity.unbind(on_activity_result=_on_copy_result)
    except Exception:
        pass
    cb, dest, _copy_cb, _copy_dest = _copy_cb, _copy_dest, None, None
    if cb is None:
        return
    if result_code != -1 or intent is None:      # RESULT_OK = -1
        cb(None, 0, "cancelled")
        return
    try:
        from jnius import autoclass
        uri = intent.getData()
        resolver = _activity().getContentResolver()
        name = "mt5.zip"
        OpenableColumns = autoclass("android.provider.OpenableColumns")
        cur = resolver.query(uri, None, None, None, None)
        if cur is not None:
            try:
                if cur.moveToFirst():
                    idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if idx >= 0:
                        name = cur.getString(idx) or name
            finally:
                cur.close()
        pfd = None
        try:
            pfd = resolver.openFileDescriptor(uri, "r")
        except Exception:
            pfd = None
        if pfd is not None:
            fd = pfd.detachFd()                     # Python giữ và đóng fd này; chép bằng I/O của Python (nhanh, không qua jnius từng byte)
            import os
            src = os.fdopen(fd, "rb", closefd=True)
            stream = None
        else:                                       # nhà cung cấp tệp không cho mở fd (vd tệp ảo của Drive): chép bằng Java (API 26+)
            stream = resolver.openInputStream(uri)
            src = None
    except Exception:
        cb(None, 0, traceback.format_exc(limit=3))
        return
    import threading

    def work():
        try:
            if src is not None:
                with src:
                    n = copy_stream_to(src, dest)
            else:
                from jnius import autoclass
                Files, File, Opt = autoclass("java.nio.file.Files"), autoclass("java.io.File"), autoclass("java.nio.file.StandardCopyOption")
                try:
                    Files.copy(stream, File(dest + ".part").toPath(), Opt.REPLACE_EXISTING)
                finally:
                    stream.close()
                n = finalize_part(dest + ".part", dest)
            cb(name, n, None)
        except ValueError as e:
            cb(None, 0, str(e))
        except Exception:
            cb(None, 0, traceback.format_exc(limit=3))
    threading.Thread(target=work, daemon=True, name="pyea-pick-copy").start()


# ---------------------------------------------------------------- giữ máy thức
def set_keep_awake(on):
    """Giữ màn hình sáng + wake lock CPU khi bot chạy. An toàn gọi nhiều lần."""
    global _wake_lock
    if not IS_ANDROID:
        return
    try:
        from android.runnable import run_on_ui_thread
        from jnius import autoclass

        @run_on_ui_thread
        def _flag():
            w = _activity().getWindow()
            if on:
                w.addFlags(128)          # FLAG_KEEP_SCREEN_ON
            else:
                w.clearFlags(128)
        _flag()

        if on and _wake_lock is None:
            Context = autoclass("android.content.Context")
            PowerManager = autoclass("android.os.PowerManager")
            pm = _activity().getSystemService(Context.POWER_SERVICE)
            _wake_lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pyea:runner")
            _wake_lock.acquire()
        elif not on and _wake_lock is not None:
            if _wake_lock.isHeld():
                _wake_lock.release()
            _wake_lock = None
    except Exception:
        pass


def move_to_background():
    """Nút Back: đưa app xuống nền thay vì thoát (để bot không bị tắt nhầm)."""
    if not IS_ANDROID:
        return False
    try:
        _activity().moveTaskToBack(True)
        return True
    except Exception:
        return False


def share_text(text, subject="PyEA - báo lỗi"):
    """Mở bảng «Chia sẻ» của Android (Zalo/Telegram/Gmail/Drive...) với nội dung văn bản. Trả True nếu đã mở được; ngoài Android hoặc lỗi -> False
    (người gọi tự rơi về sao chép clipboard). Cắt còn 100.000 ký tự cuối (giới hạn dữ liệu của Intent)."""
    if not IS_ANDROID:
        return False
    try:
        from jnius import autoclass
        Intent = autoclass("android.content.Intent")
        it = Intent(Intent.ACTION_SEND)
        it.setType("text/plain")
        it.putExtra(Intent.EXTRA_SUBJECT, str(subject))
        it.putExtra(Intent.EXTRA_TEXT, str(text)[-100000:])
        chooser = Intent.createChooser(it, "Gửi báo lỗi qua...")
        _activity().startActivity(chooser)
        return True
    except Exception:                                    # noqa: BLE001 - thiếu pyjnius/Activity: caller dùng clipboard
        return False


def open_termux():
    """Mở app Termux (gọi thẳng activity chính nên không cần khai báo <queries> trong manifest). True nếu gọi được; chưa cài Termux/ngoài Android -> False."""
    if not IS_ANDROID:
        return False
    try:
        from jnius import autoclass
        Intent = autoclass("android.content.Intent")
        it = Intent()
        it.setClassName("com.termux", "com.termux.app.TermuxActivity")
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        _activity().startActivity(it)
        return True
    except Exception:                                    # noqa: BLE001 - chưa cài Termux (ActivityNotFound) hoặc thiếu pyjnius
        return False
