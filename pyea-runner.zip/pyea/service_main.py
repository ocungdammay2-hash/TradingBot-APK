"""
Điểm vào của DỊCH VỤ NỀN (python-for-android: services = Botservice:service_main.py:foreground:sticky).
Chạy trong tiến trình riêng, sống khi app bị đóng/tắt màn hình. Không import Kivy.
"""
import json
import os
import sys
import time
import traceback


def _data_dir():
    arg = os.environ.get("PYTHON_SERVICE_ARGUMENT", "")
    try:
        d = json.loads(arg).get("data_dir")
        if d:
            return d
    except Exception:
        pass
    # Dịch vụ sticky bị Android khởi động lại có thể KHÔNG kèm argument -> dùng thư mục files của app
    # (UI cũng dùng đúng thư mục này làm data_dir)
    try:
        from pyea import android_native as an
        d = an.files_dir()
        if d:
            return d
    except Exception:
        pass
    return os.path.join(os.environ.get("ANDROID_PRIVATE", "."), "app_data")


def main():
    from pyea import bootlog
    bootlog.crumb("--- Botservice bắt đầu ---")
    bootlog.enable_faulthandler()
    try:
        _main()
    except BaseException:                                   # noqa: BLE001
        bootlog.crumb("Botservice LỖI\n" + traceback.format_exc())
        raise


def _main():
    from pyea import android_native as an
    from pyea.ipc import ServiceHost, ServiceClient
    from pyea.watchdog import Watchdog

    data_dir = _data_dir()
    os.makedirs(data_dir, exist_ok=True)
    an.set_service_notification("PyEA Runner", "Dịch vụ nền đang khởi động...")
    an.acquire_wakelocks()
    crash_log = os.path.join(data_dir, "service_crash.log")
    failures = []
    while True:
        try:
            ServiceHost(data_dir, alarm=an.notify_alarm, set_notification=an.set_service_notification,
                        watchdog=Watchdog(an.schedule_watchdog, an.cancel_watchdog),
                        boot_mirror=an.device_files_dir()).run()
            break                                   # thoát bình thường (bot xong / nhàn rỗi)
        except Exception:
            tb = traceback.format_exc()
            try:
                with open(crash_log, "a", encoding="utf-8") as f:
                    f.write("%s\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
            except OSError:
                pass
            an.notify_alarm("Dịch vụ nền gặp lỗi", tb.strip().splitlines()[-1][:200])
            now = time.time()
            failures = [t for t in failures if now - t < 300] + [now]
            if len(failures) >= 5:
                an.notify_alarm("Dịch vụ nền dừng hẳn", "Lỗi liên tiếp 5 lần. Hãy mở app để kiểm tra / chạy lại bot.")
                break
            time.sleep(3)                           # rồi vòng lặp tạo ServiceHost mới (tự khôi phục phiên)
    an.release_wakelocks()


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
