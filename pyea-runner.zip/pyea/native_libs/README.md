# native_libs — file chạy trực tiếp được đóng gói TRONG APK

Mục đích: MT5 nhúng (`pyea/embedded.py`) cần chạy `proot`. Android 10+ **cấm `execve()` file nằm trong thư mục dữ liệu của app** nếu app nhắm API ≥ 29
(SELinux: `neverallow untrusted_app_29 app_data_file:file execute_no_trans`). Thư mục thư viện gốc của APK (`nativeLibraryDir`) thì **được phép**.
Vì vậy `proot` và `loader` của nó được đặt ở đây dưới tên `lib*.so` (chỉ file `lib*.so` mới được đóng gói) và buildozer chép chúng vào APK
(`android.add_libs_arm64_v8a = native_libs/arm64-v8a/*.so`). p4a đã đặt `extractNativeLibs=true` + `useLegacyPackaging=true` nên chúng được giải ra đĩa khi cài.
Đây là cách UserLAnd (cũng dùng proot) chạy ở targetSdk 37. Nhờ vậy APK nhắm API mới (36) và **không** bị Google Play Protect chặn kiểu
«được xây dựng cho phiên bản Android cũ» (Play Protect cảnh báo khi targetSdk thấp hơn Android của máy quá 2 mức).

| file trong APK | nguồn (UserLAnd-Assets-Support v1.4.33, `arm64-v8a-assets.zip`, SHA-256 `43d390148fa95846a9bb8834164a449e6bc954db1e438f67aa3b49e32c954213`) |
|---|---|
| `libproot.so` | `proot` |
| `libproot_a10.so` | `proot.a10` (bản cho Android 10+) |
| `libproot_loader.so` | `loader` (= `loader.a10`, giống hệt từng byte) |
| `libproot_loader32.so` | `loader32` (= `loader32.a10`) |
| `libpyea_talloc.so` | `libtalloc.so.2` (app chép ra tên `libtalloc.so.2` lúc chạy vì `proot` cần đúng tên đó) |
| `libpyea_talloc_a10.so` | `libtalloc.so.2.a10` |

`SHA256SUMS` ghi mã băm từng file; `tests/test_embedded.py::TestShippedNativeLibs` kiểm tên, mã băm, loại ELF (aarch64) và dòng `android.add_libs_arm64_v8a` trong `buildozer.spec`.
Đổi file thì phải cập nhật `SHA256SUMS` (`cd native_libs && sha256sum arm64-v8a/*.so > SHA256SUMS`).

## Giấy phép / mã nguồn
- **proot**: GPL-2.0-or-later. Mã nguồn: https://github.com/proot-me/proot (nhánh Termux/UserLAnd: https://github.com/termux/proot, https://github.com/CypherpunkArmory/UserLAnd-Assets-Support). Khi phát hành APK có chứa file này phải kèm/nêu nguồn như trên.
- **talloc**: LGPL-3.0-or-later (Samba). Mã nguồn: https://www.samba.org/ftp/talloc/
- `loader` đi kèm proot, cùng giấy phép proot.

THẬT THÀ: file đã băm/xác minh là ELF aarch64 và đúng với gói nguồn, nhưng CHƯA chạy được trên điện thoại thật trong phiên làm việc này.
