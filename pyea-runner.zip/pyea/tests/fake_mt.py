"""Sàn MetaTrader GIẢ dùng chung: một lõi (vị thế/lệnh chờ/khớp/lịch sử) + 3 bộ chuyển đổi
   FakeMetaApi (HTTP, đúng đường dẫn tài liệu MetaApi) · FakeMt5 (module `MetaTrader5` giả) · FakeEA (EA giả nói giao thức relay)."""
import json
import re
import threading
import time
import types
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def iso(t):
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class MtCore:
    def __init__(self, hedging=True):
        self.lock = threading.RLock()
        self.n = 1000
        self.prices = {"EURUSD": [1.1000, 1.1002], "XAUUSD": [2000.0, 2000.5]}
        self.positions, self.orders, self.deals = {}, {}, []
        self.balance, self.hedging = 10000.0, hedging
        self.spec = {"volume_min": 0.01, "volume_max": 100.0, "volume_step": 0.01}
        self.reject_next = None
        self.log = []
        self.sltp_calls = []                 # (ticket, sl, tp) mỗi lần sửa SL/TP vị thế - để test đếm số lời gọi
        self.balance_ops = [1000.0]          # nạp (+) / rút (-) của tài khoản: xuất hiện trong lịch sử như deal loại BALANCE
        self.contract = 100000.0             # contract size của MỌI mã trong sàn giả (sổ app KHÔNG biết số này -> khác số của sàn)

    def _id(self):
        self.n += 1
        return str(self.n)

    def pos_stats(self, p):
        """Lãi/lỗ thả nổi do 'sàn' tính: (giá hiện tại - giá mở) × chiều × khối lượng × contract size; swap/hoa hồng của vị thế nếu có."""
        bid, ask = self.prices[p["symbol"]]
        px = bid if p["side"] == "buy" else ask
        sign = 1 if p["side"] == "buy" else -1
        return {"profit": round((px - p["price"]) * sign * p["volume"] * self.contract, 2), "swap": float(p.get("swap", 0.0)),
                "commission": float(p.get("commission", -0.07)), "price_now": px}

    CONTRACT, LEVERAGE = 100000.0, 100.0           # EURUSD-like: 1 lot = 100000, đòn bẩy 1:100 (số của SÀN, khác công thức Δgiá × lot của sổ app)

    def acct(self):
        """Tài khoản do SÀN tính như MT: lãi/lỗ = Δgiá × lot × contract, ký quỹ = lot × contract × giá mở / đòn bẩy."""
        with self.lock:
            fl = mg = 0.0
            for p in self.positions.values():
                bid, ask = self.prices[p["symbol"]]
                buy = p["side"] == "buy"
                fl += ((bid if buy else ask) - p["price"]) * (1 if buy else -1) * p["volume"] * self.CONTRACT
                mg += p["volume"] * self.CONTRACT * p["price"] / self.LEVERAGE
            eq = self.balance + fl
            return {"balance": self.balance, "equity": eq, "margin": mg, "free_margin": eq - mg, "profit": fl,
                    "margin_level": (eq / mg * 100.0) if mg > 0 else 0.0}

    def bad_volume(self, v):
        return v < self.spec["volume_min"] - 1e-12 or abs(v / self.spec["volume_step"] - round(v / self.spec["volume_step"])) > 1e-6

    def _check(self, volume=None):
        if self.reject_next:
            code, msg = self.reject_next
            self.reject_next = None
            raise ValueError("%s|%s" % (code, msg))
        if volume is not None and self.bad_volume(volume):
            raise ValueError("10014|Invalid volume")

    def _deal(self, order_id, sym, side, vol, price, pnl=0.0, pos_id=None, entry="IN", reason=""):
        d = {"id": "D" + self._id(), "time": time.time(), "symbol": sym, "side": side, "qty": vol, "price": price, "fee": -0.07, "pnl": pnl,
             "order_id": str(order_id), "position_id": str(pos_id if pos_id is not None else order_id), "entry": entry, "reason": reason}
        self.deals.append(d)
        return d

    def open(self, sym, side, vol, comment=""):
        with self.lock:
            self._check(vol)
            if sym not in self.prices:
                raise ValueError("10013|Invalid symbol")
            bid, ask = self.prices[sym]
            px = ask if side == "buy" else bid
            oid = self._id()
            if not self.hedging:                           # tài khoản NETTING: cùng mã + cùng chiều thì CỘNG vào vị thế sẵn có (cùng ticket)
                same = next((p for p in self.positions.values() if p["symbol"] == sym and p["side"] == side), None)
                if same is not None:
                    tot = same["volume"] + vol
                    same["price"] = (same["price"] * same["volume"] + px * vol) / tot
                    same["volume"] = round(tot, 8)
                    self._deal(oid, sym, side, vol, px, pos_id=same["id"])
                    self.log.append(("open", sym, side, vol))
                    return oid, same["id"], px
            self.positions[oid] = {"id": oid, "symbol": sym, "side": side, "volume": vol, "price": px, "sl": 0.0, "tp": 0.0, "time": time.time(),
                                   "comment": comment}
            self._deal(oid, sym, side, vol, px)
            self.log.append(("open", sym, side, vol))
            return oid, oid, px

    def close(self, pid, vol=None):
        with self.lock:
            self._check(vol)
            p = self.positions.get(str(pid))
            if not p:
                raise ValueError("10013|No position")
            v = vol or p["volume"]
            bid, ask = self.prices[p["symbol"]]
            px = bid if p["side"] == "buy" else ask
            pnl = (px - p["price"]) * (1 if p["side"] == "buy" else -1) * v * 100000
            self.balance += pnl
            oid = self._id()
            if v >= p["volume"] - 1e-12:
                del self.positions[str(pid)]
            else:
                p["volume"] = round(p["volume"] - v, 8)
            self._deal(oid, p["symbol"], "sell" if p["side"] == "buy" else "buy", v, px, pnl, pos_id=pid, entry="OUT")
            self.log.append(("close", pid, v))
            return oid, px, v

    def modify_position(self, pid, sl, tp):
        """MT5 TRADE_ACTION_SLTP: đặt SL/TP của MỘT vị thế (0 = bỏ mức)."""
        with self.lock:
            self._check()
            p = self.positions.get(str(pid))
            if not p:
                raise ValueError("10036|Position doesn't exist")
            self.sltp_calls.append((str(pid), float(sl or 0.0), float(tp or 0.0)))
            p["sl"], p["tp"] = float(sl or 0.0), float(tp or 0.0)

    def _sltp_scan(self, sym):
        """Máy chủ canh SL/TP của từng vị thế (như MT thật): chạm mức -> đóng vị thế TẠI MỨC ĐÓ, ghi deal đóng."""
        bid, ask = self.prices[sym]
        for pid, p in list(self.positions.items()):
            if p["symbol"] != sym:
                continue
            buy = p["side"] == "buy"
            px = bid if buy else ask
            lvl = None
            if p["sl"] and ((buy and px <= p["sl"]) or (not buy and px >= p["sl"])):
                lvl = p["sl"]
            elif p["tp"] and ((buy and px >= p["tp"]) or (not buy and px <= p["tp"])):
                lvl = p["tp"]
            if lvl is None:
                continue
            pnl = (lvl - p["price"]) * (1 if buy else -1) * p["volume"] * 100000
            self.balance += pnl
            del self.positions[pid]
            self._deal(self._id(), sym, "sell" if buy else "buy", p["volume"], lvl, pnl, pos_id=pid, entry="OUT", reason="sl" if lvl == p["sl"] else "tp")
            self.log.append(("sltp", pid, lvl))

    def place(self, sym, side, kind, vol, price, stop_price=0.0, expiry=0):
        with self.lock:
            self._check(vol)
            oid = self._id()
            self.orders[oid] = {"id": oid, "symbol": sym, "side": side, "kind": kind, "volume": vol, "price": price, "stop_price": stop_price,
                                "sl": 0.0, "tp": 0.0, "expiry": expiry}
            return oid

    def modify(self, oid, price=None, sl=None, tp=None):
        with self.lock:
            self._check()
            o = self.orders.get(str(oid))
            if not o:
                raise ValueError("10013|No order")
            if price is not None:
                o["price"] = float(price)
            if sl is not None:
                o["sl"] = float(sl)
            if tp is not None:
                o["tp"] = float(tp)

    def cancel(self, oid):
        with self.lock:
            self._check()
            if str(oid) not in self.orders:
                raise ValueError("10013|No order")
            del self.orders[str(oid)]

    def set_price(self, sym, bid, ask=None):
        with self.lock:
            self.prices[sym] = [bid, ask if ask is not None else round(bid + 0.0002, 5)]
            bid, ask = self.prices[sym]
            self._sltp_scan(sym)
            for oid, o in list(self.orders.items()):
                if o["symbol"] != sym:
                    continue
                k, s = o["kind"], o["side"]
                if k == "stop_limit":
                    if (s == "buy" and ask >= o["stop_price"]) or (s == "sell" and bid <= o["stop_price"]):
                        o["kind"] = "limit"                      # đã kích hoạt: thành lệnh limit
                    continue
                hit = ((k == "limit" and s == "buy" and ask <= o["price"]) or (k == "limit" and s == "sell" and bid >= o["price"])
                       or (k == "stop" and s == "buy" and ask >= o["price"]) or (k == "stop" and s == "sell" and bid <= o["price"]))
                if hit:
                    del self.orders[oid]
                    px = o["price"]
                    self.positions[oid] = {"id": oid, "symbol": sym, "side": s, "volume": o["volume"], "price": px, "sl": 0.0, "tp": 0.0, "time": time.time(),
                                           "comment": ""}
                    self._deal(oid, sym, s, o["volume"], px)

    def candles(self, sym, step, count, end=None):
        end = end if end is not None else time.time()
        last = int(end // step) * step - (step if end is not None and end < time.time() - 1 else 0)
        out = []
        for i in range(count):
            t = last - (count - 1 - i) * step
            b = 1.1 + ((t // step) % 50) * 0.0001
            out.append([float(t), b, b + 0.0003, b - 0.0003, b + 0.0001, 10.0 + i])
        return out


class _Http:
    def start(self, handler):
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


# =========================================================================================== MetaApi
class FakeMetaApi(_Http):
    TOKEN, ACC = "tok-123", "acc-1"

    def __init__(self, core):
        self.core = core
        self.requests = []
        self.deals_as_dict = True
        self.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING"
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _h(self, m):
                u = urllib.parse.urlparse(self.path)
                q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n)) if n else {}
                fake.requests.append((m, u.path, q, body))
                if self.headers.get("auth-token") != fake.TOKEN:
                    return self._send({"message": "unauthorized"}, 401)
                pre = "/users/current/accounts/%s" % fake.ACC
                if not u.path.startswith(pre):
                    return self._send({"message": "account not found"}, 404)
                code, obj = fake.route(m, u.path[len(pre):], q, body)
                self._send(obj, code)

            def do_GET(self):
                self._h("GET")

            def do_POST(self):
                self._h("POST")
        self.start(H)

    def route(self, m, p, q, b):
        c = self.core
        with c.lock:
            if p == "/accountInformation":
                a = c.acct()
                return 200, {"balance": a["balance"], "equity": a["equity"], "margin": a["margin"], "freeMargin": a["free_margin"], "leverage": 100, "currency": "USD",
                             "marginMode": self.margin_mode, "marginLevel": a["margin_level"], "credit": 0}
            if p == "/symbols":
                return 200, sorted(c.prices)
            mm = re.match(r"^/symbols/(\w+)/specification$", p)
            if mm:
                return 200, {"symbol": mm.group(1), "minVolume": c.spec["volume_min"], "maxVolume": c.spec["volume_max"], "volumeStep": c.spec["volume_step"]}
            mm = re.match(r"^/symbols/(\w+)/current-price$", p)
            if mm:
                bid, ask = c.prices[mm.group(1)]
                return 200, {"symbol": mm.group(1), "bid": bid, "ask": ask, "time": iso(time.time()), "brokerTime": "2026-10-20 12:00:00.000"}
            mm = re.match(r"^/historical-market-data/symbols/(\w+)/timeframes/(\w+)/candles$", p)
            if mm:
                steps = {"1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "4h": 14400, "1d": 86400}
                if mm.group(2) not in steps:
                    return 400, {"message": "bad timeframe"}
                end = datetime.strptime(q["startTime"].replace("Z", ""), "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=timezone.utc).timestamp()
                cs = c.candles(mm.group(1), steps[mm.group(2)], int(q["limit"]), end)
                return 200, [{"symbol": mm.group(1), "timeframe": mm.group(2), "time": iso(r[0]), "open": r[1], "high": r[2], "low": r[3], "close": r[4],
                              "tickVolume": r[5]} for r in cs]
            if p == "/positions":
                return 200, [{"id": x["id"], "type": "POSITION_TYPE_BUY" if x["side"] == "buy" else "POSITION_TYPE_SELL", "symbol": x["symbol"],
                              "openPrice": x["price"], "volume": x["volume"], "stopLoss": x["sl"], "takeProfit": x["tp"], "time": iso(x["time"]),
                              "comment": x.get("comment", ""), "currentPrice": c.pos_stats(x)["price_now"], "profit": c.pos_stats(x)["profit"] + c.pos_stats(x)["swap"] +
                              c.pos_stats(x)["commission"], "unrealizedProfit": c.pos_stats(x)["profit"], "swap": c.pos_stats(x)["swap"],
                              "unrealizedSwap": c.pos_stats(x)["swap"], "commission": c.pos_stats(x)["commission"],
                              "unrealizedCommission": c.pos_stats(x)["commission"]} for x in c.positions.values()]
            if p == "/orders":
                nm = {"limit": "LIMIT", "stop": "STOP", "stop_limit": "STOP_LIMIT"}
                return 200, [{"id": o["id"], "type": "ORDER_TYPE_%s_%s" % (o["side"].upper(), nm[o["kind"]]), "state": "ORDER_STATE_PLACED", "symbol": o["symbol"],
                              "openPrice": o["stop_price"] if o["kind"] == "stop_limit" else o["price"], "currentVolume": o["volume"], "volume": o["volume"],
                              "stopLoss": o["sl"], "takeProfit": o["tp"]} for o in c.orders.values()]
            mm = re.match(r"^/history-deals/position/(\w+)$", p)
            if mm:
                return 200, ({"deals": self._deal_rows(d for d in c.deals if d["position_id"] == mm.group(1)), "synchronizing": False}
                             if self.deals_as_dict else self._deal_rows(d for d in c.deals if d["position_id"] == mm.group(1)))
            if p.startswith("/history-deals/time/"):
                lo, hi = (self._iso_epoch(x) for x in p[len("/history-deals/time/"):].split("/")[:2])       # máy chủ thật chỉ trả deal trong [lo, hi]
                rows = self._deal_rows(d for d in c.deals if lo <= d["time"] <= hi)
                for i, amt in enumerate(c.balance_ops):
                    if lo <= time.time() <= hi:
                        rows.append({"id": "B%d" % (i + 1), "type": "DEAL_TYPE_BALANCE", "profit": amt, "time": iso(time.time())})
                return 200, ({"deals": rows, "synchronizing": False} if self.deals_as_dict else rows)
            if m == "POST" and p == "/trade":
                return self.trade(b)
        return 404, {"message": "unknown " + p}

    @staticmethod
    def _iso_epoch(txt):
        import urllib.parse
        return datetime.strptime(urllib.parse.unquote(txt).replace("Z", ""), "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=timezone.utc).timestamp()

    @staticmethod
    def _deal_rows(deals):
        return [{"id": d["id"], "type": "DEAL_TYPE_BUY" if d["side"] == "buy" else "DEAL_TYPE_SELL", "entryType": "DEAL_ENTRY_" + d["entry"], "symbol": d["symbol"],
                 "volume": d["qty"], "price": d["price"], "commission": d["fee"], "swap": d.get("swap", 0), "profit": d["pnl"], "time": iso(d["time"]), "orderId": d["order_id"],
                 "positionId": d["position_id"]} for d in deals]

    def trade(self, b):
        c, a = self.core, b.get("actionType")
        done = lambda **kw: (200, dict({"numericCode": 10009, "stringCode": "TRADE_RETCODE_DONE", "message": "Request completed"}, **kw))   # noqa: E731
        try:
            if a in ("ORDER_TYPE_BUY", "ORDER_TYPE_SELL"):
                oid, pid, _ = c.open(b["symbol"], "buy" if a.endswith("BUY") else "sell", float(b["volume"]), b.get("comment", ""))
                return done(orderId=oid, positionId=pid)                          # đúng tài liệu: KHÔNG có giá khớp
            if a == "POSITION_CLOSE_ID":
                oid, _, _ = c.close(b["positionId"])
                return done(orderId=oid, positionId=b["positionId"])
            if a == "POSITION_MODIFY":
                c.modify_position(b["positionId"], b.get("stopLoss", 0.0), b.get("takeProfit", 0.0))
                return done(positionId=b["positionId"])
            if a == "POSITION_PARTIAL":
                oid, _, _ = c.close(b["positionId"], float(b["volume"]))
                return done(orderId=oid, positionId=b["positionId"])
            mm = re.match(r"^ORDER_TYPE_(BUY|SELL)_(LIMIT|STOP|STOP_LIMIT)$", a or "")
            if mm:
                kind = mm.group(2).lower()
                price, stop = (float(b["stopLimitPrice"]), float(b["openPrice"])) if kind == "stop_limit" else (float(b["openPrice"]), 0.0)
                return done(orderId=c.place(b["symbol"], mm.group(1).lower(), kind, float(b["volume"]), price, stop))
            if a == "ORDER_MODIFY":
                c.modify(b["orderId"], b.get("openPrice"), b.get("stopLoss"), b.get("takeProfit"))
                return done(orderId=b["orderId"])
            if a == "ORDER_CANCEL":
                c.cancel(b["orderId"])
                return done(orderId=b["orderId"])
        except ValueError as e:
            code, msg = str(e).split("|", 1)
            return 200, {"numericCode": int(code), "stringCode": "TRADE_RETCODE_REJECT", "message": msg}          # HTTP 200 nhưng MT từ chối
        return 400, {"message": "bad actionType"}


# =========================================================================================== module MetaTrader5 giả
class FakeMt5:
    TRADE_ACTION_DEAL, TRADE_ACTION_PENDING, TRADE_ACTION_SLTP, TRADE_ACTION_MODIFY, TRADE_ACTION_REMOVE = 1, 5, 6, 7, 8
    ORDER_TYPE_BUY, ORDER_TYPE_SELL, ORDER_TYPE_BUY_LIMIT, ORDER_TYPE_SELL_LIMIT, ORDER_TYPE_BUY_STOP, ORDER_TYPE_SELL_STOP = 0, 1, 2, 3, 4, 5
    ORDER_TYPE_BUY_STOP_LIMIT, ORDER_TYPE_SELL_STOP_LIMIT = 6, 7
    ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN = 0, 1, 2
    ORDER_TIME_GTC, ORDER_TIME_SPECIFIED = 0, 2
    ACCOUNT_MARGIN_MODE_RETAIL_HEDGING = 2
    DEAL_TYPE_BUY, DEAL_TYPE_SELL, DEAL_TYPE_BALANCE, DEAL_TYPE_CREDIT, DEAL_TYPE_CHARGE = 0, 1, 2, 3, 4
    TIMEFRAME_M1, TIMEFRAME_M5, TIMEFRAME_M15, TIMEFRAME_M30, TIMEFRAME_H1, TIMEFRAME_H4, TIMEFRAME_D1 = 1, 5, 15, 30, 16385, 16388, 16408
    STEPS = {1: 60, 5: 300, 15: 900, 30: 1800, 16385: 3600, 16388: 14400, 16408: 86400}

    def __init__(self, core, offset=7200, filling_mode=2, init_ok=True):
        self.core, self.offset, self.filling_mode, self.init_ok = core, offset, filling_mode, init_ok
        self.requests, self.init_args = [], None

    # tất cả "thời gian broker" = UTC + offset
    def initialize(self, **kw):
        self.init_args = kw
        return self.init_ok

    def last_error(self):
        return (-1, "fake error")

    def symbols_get(self):
        return [types.SimpleNamespace(name=s) for s in sorted(self.core.prices)]

    def symbol_select(self, s, flag):
        return s in self.core.prices

    def symbol_info(self, s):
        if s not in self.core.prices:
            return None
        sp = self.core.spec
        return types.SimpleNamespace(volume_min=sp["volume_min"], volume_max=sp["volume_max"], volume_step=sp["volume_step"], digits=5,
                                     filling_mode=self.filling_mode)

    def symbol_info_tick(self, s):
        if s not in self.core.prices:
            return None
        b, a = self.core.prices[s]
        t = time.time() + self.offset
        return types.SimpleNamespace(bid=b, ask=a, time=int(t), time_msc=int(t * 1000))

    def _rates(self, s, tf, count, end_broker):
        rows = self.core.candles(s, self.STEPS[tf], count, None if end_broker is None else end_broker - self.offset)
        return [{"time": r[0] + self.offset, "open": r[1], "high": r[2], "low": r[3], "close": r[4], "tick_volume": r[5]} for r in rows]

    def copy_rates_from_pos(self, s, tf, pos, count):
        return self._rates(s, tf, count, None)

    def copy_rates_from(self, s, tf, date_from, count):
        return self._rates(s, tf, count, date_from.timestamp())

    def account_info(self):
        c = self.core
        a = c.acct()
        return types.SimpleNamespace(balance=a["balance"], equity=a["equity"], margin=a["margin"], margin_free=a["free_margin"], leverage=100, currency="USD",
                                     margin_mode=2 if c.hedging else 0, margin_level=a["margin_level"], credit=0.0, profit=a["profit"])

    def _pos(self, p):
        return types.SimpleNamespace(ticket=int(p["id"]), identifier=int(p["id"]), symbol=p["symbol"], type=0 if p["side"] == "buy" else 1, volume=p["volume"],
                                     price_open=p["price"], sl=p["sl"], tp=p["tp"], time=int(p["time"] + self.offset), comment=p.get("comment", ""),
                                     profit=self.core.pos_stats(p)["profit"], swap=self.core.pos_stats(p)["swap"], price_current=self.core.pos_stats(p)["price_now"])

    def positions_get(self, symbol=None, ticket=None):
        rows = [self._pos(p) for p in self.core.positions.values() if (symbol is None or p["symbol"] == symbol) and (ticket is None or int(p["id"]) == ticket)]
        return tuple(rows) or None

    def orders_get(self, ticket=None):
        tm = {("buy", "limit"): 2, ("sell", "limit"): 3, ("buy", "stop"): 4, ("sell", "stop"): 5, ("buy", "stop_limit"): 6, ("sell", "stop_limit"): 7}
        rows = []
        for o in self.core.orders.values():
            if ticket is not None and int(o["id"]) != ticket:
                continue
            rows.append(types.SimpleNamespace(ticket=int(o["id"]), symbol=o["symbol"], type=tm[(o["side"], o["kind"])], volume_current=o["volume"],
                                              price_open=o["stop_price"] if o["kind"] == "stop_limit" else o["price"], price_stoplimit=o["price"],
                                              sl=o["sl"], tp=o["tp"]))
        return tuple(rows) or None

    ENTRY_N = {"IN": 0, "OUT": 1, "INOUT": 2, "OUT_BY": 3}
    REASON_N = {"client": 0, "mobile": 1, "web": 2, "expert": 3, "sl": 4, "tp": 5, "so": 6}

    @staticmethod
    def _ts(x):
        return x.timestamp() if hasattr(x, "timestamp") else float(x)

    def history_deals_get(self, a=None, b=None, position=None):
        rows = []
        for d in self.core.deals:
            if position is not None and str(d.get("position_id")) != str(position):
                continue
            if position is None and a is not None and b is not None and not (self._ts(a) <= d["time"] + self.offset <= self._ts(b)):
                continue                                                                   # terminal thật: chỉ deal trong khoảng [a, b] (giờ máy chủ)
            rows.append(types.SimpleNamespace(ticket=int(d["id"][1:]), order=int("".join(ch for ch in str(d["order_id"]) if ch.isdigit()) or 0),
                                              time=int(d["time"] + self.offset), type=0 if d["side"] == "buy" else 1, entry=self.ENTRY_N.get(d.get("entry", ""), 0), volume=d["qty"], price=d["price"], commission=d["fee"], swap=float(d.get("swap", 0.0)),
                                              profit=d["pnl"], symbol=d["symbol"], position_id=int(d.get("position_id") or 0),
                                              reason=self.REASON_N.get(d.get("reason", ""), 0), fee=0.0, comment=""))
        if position is None and (a is None or b is None or self._ts(a) <= time.time() + self.offset <= self._ts(b)):
            for i, amt in enumerate(self.core.balance_ops):
                rows.append(types.SimpleNamespace(ticket=999999 - i, order=0, time=int(time.time() + self.offset), type=2, entry=0, volume=0, price=0, commission=0,
                                                  swap=0, profit=amt, symbol="", position_id=0, reason=0, fee=0.0, comment="Deposit"))
        return tuple(rows)

    def _res(self, code, comment="", order=0, price=0.0, volume=0.0):
        return types.SimpleNamespace(retcode=code, comment=comment, order=order, deal=order, price=price, volume=volume)

    def order_send(self, req):
        self.requests.append(dict(req))
        c = self.core
        try:
            act = req["action"]
            if act == self.TRADE_ACTION_DEAL and "position" in req:
                oid, px, v = c.close(req["position"], req["volume"] if req["volume"] < c.positions[str(req["position"])]["volume"] - 1e-12 else None)
                return self._res(10009, "done", int(oid), px, v)
            if act == self.TRADE_ACTION_DEAL:
                oid, pid, px = c.open(req["symbol"], "buy" if req["type"] == 0 else "sell", req["volume"], req.get("comment", ""))
                return self._res(10009, "done", int(oid), px, req["volume"])
            if act == self.TRADE_ACTION_SLTP:
                p = c.positions.get(str(req["position"]))
                if p is not None and (p["sl"], p["tp"]) == (float(req["sl"]), float(req["tp"])):
                    return self._res(10025, "No changes")                       # MT5 thật: yêu cầu không thay đổi gì
                c.modify_position(req["position"], req["sl"], req["tp"])
                return self._res(10009, "sltp done", int(req["position"]))
            if act == self.TRADE_ACTION_PENDING:
                names = {2: ("buy", "limit"), 3: ("sell", "limit"), 4: ("buy", "stop"), 5: ("sell", "stop"), 6: ("buy", "stop_limit"), 7: ("sell", "stop_limit")}
                side, kind = names[req["type"]]
                price, stop = (req["stoplimit"], req["price"]) if kind == "stop_limit" else (req["price"], 0.0)
                return self._res(10009, "placed", int(c.place(req["symbol"], side, kind, req["volume"], price, stop, req.get("expiration", 0))))
            if act == self.TRADE_ACTION_MODIFY:
                c.modify(req["order"], req["price"], req["sl"], req["tp"])
                return self._res(10009, "modified", req["order"])
            if act == self.TRADE_ACTION_REMOVE:
                c.cancel(req["order"])
                return self._res(10009, "removed", req["order"])
        except ValueError as e:
            code, msg = str(e).split("|", 1)
            return self._res(int(code), msg)
        return self._res(10013, "bad request")


# =========================================================================================== EA giả (giao thức relay)
class FakeEA:
    """Mô phỏng PHÍA EA: gọi /ea/poll, đẩy trạng thái lên, thực thi lệnh nhận về. Dùng chung lõi MtCore."""

    def __init__(self, core, url, token="", interval=0.05, platform="MT5", caps="sltp,posdeals,comment,history"):
        self.core, self.url, self.token, self.interval, self.platform = core, url.rstrip("/"), token, interval, platform
        self.caps = caps                                                     # "" = mô phỏng EA BẢN CŨ (không khai khả năng, POS/DEAL ngắn)
        self.watch, self.stop = set(), threading.Event()
        self.pending_results, self.polls, self.cmd_log = [], 0, []
        self.deals_sent = set()
        self.t = threading.Thread(target=self.run, daemon=True)

    def start(self):
        self.t.start()
        return self

    def close(self):
        self.stop.set()
        self.t.join(2)

    def _body(self):
        c, out = self.core, []
        with c.lock:
            out.append("HELLO|%s|1000|123456%s" % (self.platform, ("|" + self.caps) if self.caps else ""))
            a = c.acct()
            out.append("ACCT|%s|%s|%s|%s|100|USD|%d%s" % (a["balance"], a["equity"], a["margin"], a["free_margin"], 1 if c.hedging else 0, "|0" if self.caps else ""))
            out.append("SYMS|" + ",".join(sorted(c.prices)))
            for s in self.watch:
                if s in c.prices:
                    b, a = c.prices[s]
                    out.append("TICK|%s|%s|%s|%s" % (s, b, a, time.time()))
                out.append("SPEC|%s|%s|%s|%s" % (s, c.spec["volume_min"], c.spec["volume_max"], c.spec["volume_step"]))
            out.append("POSALL|%d" % len(c.positions))
            for p in c.positions.values():
                st = c.pos_stats(p)
                out.append("POS|%s|%s|%s|%s|%s|%s|%s|%s%s" % (p["id"], p["symbol"], p["side"], p["volume"], p["price"], p["sl"], p["tp"], p["time"],
                                                            ("|%s|%s|%s|%s%s" % (p.get("comment", "").replace("|", "/"), st["profit"], st["swap"], st["price_now"],
                                                                                 ("|%s" % st["commission"]) if self.platform == "MT4" else "")) if self.caps else ""))
            out.append("ORDALL|%d" % len(c.orders))
            for o in c.orders.values():
                out.append("ORD|%s|%s|%s|%s|%s|%s|%s|%s" % (o["id"], o["symbol"], o["side"], o["kind"], o["volume"],
                                                          o["stop_price"] if o["kind"] == "stop_limit" else o["price"], o["sl"], o["tp"]))
            for d in c.deals:
                out.append("DEAL|" + self._deal(d, "|"))
        out += self.pending_results
        self.pending_results = []
        return "\n".join(out) + "\n"

    def _deal(self, d, sep):
        f = [d["id"], d["time"], d["symbol"], d["side"], d["qty"], d["price"], d["fee"], d["pnl"], d["order_id"]]
        if self.caps:
            f += [d.get("position_id", ""), d.get("entry", ""), d.get("reason", "")]
        return sep.join(str(x) for x in f)

    def _exec(self, cid, action, a):
        c = self.core
        try:
            if action == "sltp":
                if self.platform == "MT5" and (c.positions.get(a[0]) or {}).get("sl") == float(a[1]) and (c.positions.get(a[0]) or {}).get("tp") == float(a[2]):
                    return "RES|%s|1|10025|%s|%s|0|0|No changes" % (cid, a[0], a[0])             # MT5: không đổi gì
                c.modify_position(a[0], float(a[1]), float(a[2]))
                return "RES|%s|1|10009|%s|%s|0|0|sltp" % (cid, a[0], a[0])
            if action == "history":
                lo, hi = float(a[0]), float(a[1]) or time.time() + 86400
                rows = []
                for d in c.deals:
                    if lo <= d["time"] <= hi:
                        rows.append(",".join(str(x) for x in (d["id"], d["time"], "trade", d["symbol"], d["side"], d["qty"], d["price"], d.get("entry", ""), d.get("position_id", ""),
                                                              d["order_id"], d["pnl"], d["fee"], d.get("swap", 0.0), 0.0, "")))
                for i, amt in enumerate(c.balance_ops):
                    rows.append(",".join(str(x) for x in ("B%d" % (i + 1), time.time(), "balance", "", "", 0, 0, "", "", 0, amt, 0, 0, 0, "Deposit")))
                return "HIST|%s|%s" % (cid, ";".join(rows))
            if action == "posdeals":
                rows = [d for d in c.deals if str(d.get("position_id")) == a[0]]
                return "PDEALS|%s|%s" % (cid, ";".join(self._deal(d, ",") for d in rows))
            if action == "market":
                oid, pid, px = c.open(a[0], a[1], float(a[2]), a[3] if len(a) > 3 else "")
                return "RES|%s|1|10009|%s|%s|%s|%s|ok" % (cid, oid, pid, px, a[2])
            if action == "close":
                v = float(a[1]) or None
                oid, px, vol = c.close(a[0], v)
                return "RES|%s|1|10009|%s|%s|%s|%s|ok" % (cid, oid, a[0], px, vol)
            if action == "pending":
                oid = c.place(a[0], a[1], a[2], float(a[3]), float(a[4]), float(a[5]) if a[2] == "stop_limit" else 0.0, int(float(a[6])))
                return "RES|%s|1|10009|%s||0|0|placed" % (cid, oid)
            if action == "modify":
                c.modify(a[0], float(a[1]) if a[1] != "" else None, float(a[2]) if a[2] != "" else None, float(a[3]) if a[3] != "" else None)
                return "RES|%s|1|10009|%s||0|0|modified" % (cid, a[0])
            if action == "cancel":
                c.cancel(a[0])
                return "RES|%s|1|10009|%s||0|0|removed" % (cid, a[0])
            if action == "bars":
                rows = c.candles(a[0], int(a[1]) * 60, int(a[2]), float(a[3]) or None)
                return "BARS|%s|%s|%s|%s" % (cid, a[1], a[0], ";".join(",".join(str(x) for x in r) for r in rows))
            if action == "spec":
                self.watch.add(a[0])
                return "RES|%s|1|0|||0|0|ok" % cid
        except ValueError as e:
            code, msg = str(e).split("|", 1)
            return "RES|%s|0|%s|||0|0|%s" % (cid, code, msg)
        return "RES|%s|0|1|||0|0|unknown action" % cid

    def run(self):
        while not self.stop.is_set():
            try:
                req = urllib.request.Request(self.url + "/ea/poll", data=self._body().encode(), method="POST", headers={"X-PyEA-Token": self.token})
                with urllib.request.urlopen(req, timeout=5) as r:
                    text = r.read().decode()
                self.polls += 1
                for line in text.splitlines():
                    p = line.split("|")
                    if p[0] == "WATCH":
                        self.watch = set(x for x in p[1].split(",") if x)
                    elif p[0] == "CMD":
                        self.cmd_log.append(p[2:])
                        self.pending_results.append(self._exec(p[1], p[2], p[3:]))
            except (urllib.error.URLError, OSError):
                pass
            self.stop.wait(self.interval)
