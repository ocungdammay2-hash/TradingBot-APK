"""http_json giữ kết nối cho GET (keep-alive), POST luôn kết nối mới, xử lý lỗi/đóng kết nối/chuyển hướng như đường cũ."""
import http.server
import json
import os
import sys
import threading
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import feeds  # noqa: E402
from pyea.feeds import FeedError, HttpError, http_json  # noqa: E402


class Srv:
    def __init__(self, keepalive=True):
        self.conns, self.reqs, self.mode = set(), [], "ok"
        outer = self

        class H(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1" if keepalive else "HTTP/1.0"

            def _send(self, code, body, extra=None):
                b = body.encode()
                self.send_response(code)
                self.send_header("Content-Length", str(len(b)))
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                outer.conns.add(self.client_address)
                outer.reqs.append(("GET", self.path))
                if outer.mode == "429":
                    return self._send(429, '{"msg":"slow"}', {"Retry-After": "3"})
                if outer.mode == "redirect" and self.path == "/a":
                    return self._send(302, "", {"Location": "/b"})
                if outer.mode == "drop_after_first" and len(outer.reqs) > 1 and not getattr(outer, "dropped", False):
                    outer.dropped = True
                    self.close_connection = True
                    self.connection.close()
                    return
                self._send(200, json.dumps({"path": self.path, "n": len(outer.reqs)}))

            def do_POST(self):
                outer.conns.add(self.client_address)
                outer.reqs.append(("POST", self.path))
                n = int(self.headers.get("Content-Length", 0))
                self.rfile.read(n)
                self._send(200, '{"ok":true}')

            def log_message(self, *a):
                pass
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


class TestPool(unittest.TestCase):
    def setUp(self):
        feeds.pool_close_all()
        self._proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}

    def tearDown(self):
        feeds.pool_close_all()
        os.environ.update(self._proxy)

    def test_get_reuses_one_connection(self):
        s = Srv(True)
        try:
            for i in range(6):
                d = http_json(s.url + "/x", {"i": i})
                self.assertEqual(d["path"], "/x?i=%d" % i)
            self.assertEqual(len(s.conns), 1)                            # 6 yêu cầu, 1 kết nối
        finally:
            s.close()

    def test_server_closing_connection_is_not_reused(self):
        s = Srv(False)                                                   # HTTP/1.0: đóng sau mỗi phản hồi
        try:
            for _ in range(3):
                http_json(s.url + "/x")
            self.assertEqual(len(s.conns), 3)
        finally:
            s.close()

    def test_dead_pooled_connection_retried_once_for_get(self):
        s = Srv(True)
        try:
            http_json(s.url + "/x")
            s.mode = "drop_after_first"                                  # kết nối nhàn rỗi bị đóng giữa chừng
            d = http_json(s.url + "/y")
            self.assertEqual(d["path"], "/y")
        finally:
            s.close()

    def test_half_dead_pooled_connection_does_not_block_for_full_timeout(self):
        """Kết nối giữ sẵn bị «chết ngầm» (server không trả lời): chỉ chờ POOL_REUSED_TIMEOUT_S rồi thử lại trên kết nối mới."""
        import time
        s = Srv(True)
        old = feeds.POOL_REUSED_TIMEOUT_S
        feeds.POOL_REUSED_TIMEOUT_S = 0.4
        try:
            http_json(s.url + "/x")
            s.mode = "hang_once"
            s.hung = False
            orig = s.srv.RequestHandlerClass.do_GET

            def slow(h):
                if s.mode == "hang_once" and not s.hung:
                    s.hung = True
                    time.sleep(1.5)
                    return
                orig(h)
            s.srv.RequestHandlerClass.do_GET = slow
            t0 = time.time()
            d = http_json(s.url + "/y", timeout=10)
            self.assertEqual(d["path"], "/y")
            self.assertLess(time.time() - t0, 1.4)                         # không phải đợi 10 giây
        finally:
            feeds.POOL_REUSED_TIMEOUT_S = old
            s.close()

    def test_post_never_pooled_and_never_retried(self):
        s = Srv(True)
        try:
            http_json(s.url + "/x")
            http_json(s.url + "/order", body={"a": 1})
            http_json(s.url + "/order", body={"a": 2})
            posts = [r for r in s.reqs if r[0] == "POST"]
            self.assertEqual(len(posts), 2)
            self.assertEqual(len(s.conns), 3)                            # 1 GET + 2 POST, mỗi POST một kết nối mới
        finally:
            s.close()

    def test_http_error_keeps_retry_after_and_limiter_sees_status(self):
        s = Srv(True)
        seen = []

        class L:
            def acquire(self, c):
                pass

            def on_http(self, status, headers):
                seen.append((status, headers.get("Retry-After")))
        try:
            s.mode = "429"
            with self.assertRaises(HttpError) as cm:
                http_json(s.url + "/x", limiter=L())
            self.assertEqual(cm.exception.code if hasattr(cm.exception, "code") else 429, 429)
            self.assertEqual(seen, [(429, "3")])
        finally:
            s.close()

    def test_redirect_falls_back_to_urllib(self):
        s = Srv(True)
        try:
            s.mode = "redirect"
            d = http_json(s.url + "/a")
            self.assertEqual(d["path"], "/b")
        finally:
            s.close()

    def test_unreachable_is_feederror(self):
        with self.assertRaises(FeedError):
            http_json("http://127.0.0.1:9/x", timeout=1)

    def test_pool_can_be_disabled(self):
        s = Srv(True)
        feeds.POOL_ENABLED = False
        try:
            for _ in range(3):
                http_json(s.url + "/x")
            self.assertEqual(len(s.conns), 3)
        finally:
            feeds.POOL_ENABLED = True
            s.close()

    def test_proxy_env_uses_old_path(self):
        os.environ["http_proxy"] = "http://127.0.0.1:9"
        try:
            self.assertTrue(feeds._proxy_applies("http", "example.com"))
            self.assertIsNone(feeds._pool_get("http://example.com/x", {}, 1))
        finally:
            os.environ.pop("http_proxy", None)


if __name__ == "__main__":
    unittest.main()
