"""Kho nến backtest: lưu/đọc nhị phân, tải phần thiếu, liền mạch, CSV nhập/xuất. Không dùng mạng (feed giả)."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import candlestore as cs                      # noqa: E402
from pyea.sdk import Candle                             # noqa: E402

T0 = 1700000000 - 1700000000 % 3600


def mk(i, step=60):
    p = 100.0 + i * 0.01
    return Candle(T0 + i * step, p, p + 0.5, p - 0.5, p + 0.1, 10.0 + i)


def series(a, b, step=60):
    return [mk(i, step) for i in range(a, b)]


class FakeFeed:
    """history theo mô hình fetch_history: trả `n` nến cuối kết thúc trước `end`; đếm số nến đã «tải»."""
    def __init__(self, a, b, step=60, cap=None):
        self.all = series(a, b, step)
        self.served = 0
        self.calls = []
        self.cap = cap

    def fetch(self, feed, symbol, tf, n, end=None, progress=None):
        self.calls.append((n, end))
        pool = [c for c in self.all if end is None or c.time < end]
        if self.cap:
            n = min(n, self.cap)
        out = pool[-n:]
        self.served += len(out)
        return out


class TestStore(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory()
        self.s = cs.CandleStore(self.d.name)

    def tearDown(self):
        self.d.cleanup()

    def test_roundtrip_and_info(self):
        self.assertIsNone(self.s.info("x", "BTC", "1m"))
        self.assertTrue(self.s.put("x", "BTC", "1m", series(0, 100)))
        inf = self.s.info("x", "BTC", "1m")
        self.assertEqual((inf["count"], inf["first"], inf["last"]), (100, T0, T0 + 99 * 60))
        self.assertEqual(inf["bytes"], 8 + 100 * 48)
        got = self.s.read("x", "BTC", "1m")
        self.assertEqual(len(got), 100)
        self.assertEqual(got[5].close, mk(5).close)

    def test_read_window_and_last(self):
        self.s.put("x", "BTC", "1m", series(0, 100))
        w = self.s.read("x", "BTC", "1m", since=T0 + 10 * 60, before=T0 + 20 * 60)
        self.assertEqual([c.time for c in w], [T0 + i * 60 for i in range(10, 20)])
        self.assertEqual(len(self.s.read("x", "BTC", "1m", last=7)), 7)
        self.assertEqual(self.s.read("x", "BTC", "1m", last=7)[-1].time, T0 + 99 * 60)
        self.assertEqual(self.s.count_before("x", "BTC", "1m", T0 + 50 * 60), 50)

    def test_append_head_and_overlap(self):
        self.s.put("x", "BTC", "1m", series(50, 100))
        self.s.put("x", "BTC", "1m", series(100, 120))                     # nối đuôi
        self.s.put("x", "BTC", "1m", series(20, 50))                       # nối đầu
        self.s.put("x", "BTC", "1m", series(40, 60))                       # chồng lấn
        got = self.s.read("x", "BTC", "1m")
        self.assertEqual([c.time for c in got], [T0 + i * 60 for i in range(20, 120)])

    def test_append_does_not_rewrite_file(self):
        self.s.put("x", "BTC", "1m", series(0, 50))
        p = self.s.path("x", "BTC", "1m")
        ino = os.stat(p).st_ino
        self.s.put("x", "BTC", "1m", series(50, 60))
        self.assertEqual(os.stat(p).st_ino, ino)                           # ghi nối tại chỗ, không thay file

    def test_corrupt_header_is_ignored(self):
        p = self.s.path("x", "BTC", "1m")
        os.makedirs(self.d.name, exist_ok=True)
        open(p, "wb").write(b"junk")
        self.assertIsNone(self.s.info("x", "BTC", "1m"))
        self.assertEqual(self.s.read("x", "BTC", "1m"), [])

    def test_partial_tail_after_crash_uses_header_count(self):
        self.s.put("x", "BTC", "1m", series(0, 10))
        with open(self.s.path("x", "BTC", "1m"), "ab") as f:
            f.write(b"\x00" * 30)                                          # nửa dòng rác (ghi dở)
        self.assertEqual(self.s.info("x", "BTC", "1m")["count"], 10)
        self.s.put("x", "BTC", "1m", series(10, 12))
        self.assertEqual(len(self.s.read("x", "BTC", "1m")), 12)

    def test_cap_trims_oldest(self):
        old = cs.MAX_STORED
        cs.MAX_STORED = 50
        try:
            self.s.put("x", "BTC", "1m", series(0, 40))
            self.s.put("x", "BTC", "1m", series(40, 100))
            got = self.s.read("x", "BTC", "1m")
            self.assertLessEqual(len(got), 60)
            self.assertEqual(got[-1].time, T0 + 99 * 60)
        finally:
            cs.MAX_STORED = old

    def test_list_and_clear(self):
        self.s.put("a", "BTC", "1m", series(0, 5))
        self.s.put("file", "XAUUSD", "5m", series(0, 5, 300))
        lst = self.s.list()
        self.assertEqual({(e["source"], e["symbol"], e["tf"]) for e in lst}, {("a", "BTC", "1m"), ("file", "XAUUSD", "5m")})
        self.assertEqual(self.s.clear("a"), 1)
        self.assertEqual(len(self.s.list()), 1)


class TestGet(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory()
        self.s = cs.CandleStore(self.d.name)
        self.now = T0 + 1000 * 60 + 30                                      # đang giữa nến 1000 (chưa đóng)

    def tearDown(self):
        self.d.cleanup()

    def get(self, feed, bars, **kw):
        return cs.get_candles(self.s, "x", None, "BTC", "1m", bars, now=self.now, fetch=feed.fetch, **kw)

    def test_first_call_downloads_and_excludes_open_candle(self):
        f = FakeFeed(0, 1001)
        out, st = self.get(f, 200)
        self.assertEqual(len(out), 200)
        self.assertEqual(out[-1].time, T0 + 999 * 60)                      # nến 1000 chưa đóng -> không lấy
        self.assertEqual(f.served, 201)                                      # +1 nến đang chạy dở bị loại

    def test_second_call_hits_cache_no_network_beyond_tail(self):
        f = FakeFeed(0, 1001)
        self.get(f, 200)
        f.served, f.calls = 0, []
        out, st = self.get(f, 200)
        self.assertEqual(len(out), 200)
        self.assertEqual(f.served, 0)                                      # không tải gì nữa
        self.assertEqual(f.calls, [])

    def test_only_missing_tail_downloaded(self):
        f = FakeFeed(0, 1001)
        self.get(f, 200)
        self.now += 60 * 30                                                # 30 nến mới
        f.all = series(0, 1031)
        f.served = 0
        out, st = self.get(f, 200)
        self.assertEqual(out[-1].time, T0 + 1029 * 60)
        self.assertEqual(len(out), 200)
        self.assertLessEqual(f.served, 35)                                 # chỉ phần thiếu + chồng lấn

    def test_older_extension_when_more_bars_requested(self):
        f = FakeFeed(0, 1001)
        self.get(f, 100)
        f.served = 0
        out, st = self.get(f, 300)
        self.assertEqual(len(out), 300)
        self.assertLessEqual(f.served, 205)
        times = [c.time for c in out]
        self.assertEqual(times, [T0 + i * 60 for i in range(700, 1000)])   # liền mạch, không lỗ

    def test_gap_discards_cache_and_refetches(self):
        f = FakeFeed(0, 1001)
        self.get(f, 100)
        self.now += 60 * 500                                               # lệch xa
        f.all = series(0, 1501)
        f.cap = 20                                                         # nguồn bị cắt: không chồng lên nến đã lưu
        out, st = self.get(f, 100)
        self.assertTrue(st["refetch"])
        times = [c.time for c in out]
        self.assertTrue(all(b - a == 60 for a, b in zip(times, times[1:])) or len(out) <= 20)

    def test_historic_range_with_end(self):
        f = FakeFeed(0, 1001)
        out, st = self.get(f, 50, end=T0 + 500 * 60)
        self.assertEqual(out[-1].time, T0 + 499 * 60)
        self.assertEqual(len(out), 50)

    def test_simulated_source_none_is_not_stored(self):
        f = FakeFeed(0, 1001)
        out, st = cs.get_candles(self.s, None, None, "BTC", "1m", 50, now=self.now, fetch=f.fetch)
        self.assertEqual(len(out), 50)
        self.assertEqual(self.s.list(), [])

    def test_source_key(self):
        self.assertIsNone(cs.source_key({"exchange": "simulated"}))
        self.assertEqual(cs.source_key({"exchange": "public"}), "public")
        self.assertEqual(cs.source_key({"exchange": "ccxt", "ccxt_id": "OKX"}), "ccxt-okx")


class TestCsv(unittest.TestCase):
    def test_roundtrip(self):
        src = series(0, 20)
        got, info = cs.parse_csv(cs.to_csv(src))
        self.assertEqual(len(got), 20)
        self.assertAlmostEqual(got[3].close, src[3].close)
        self.assertEqual(got[3].time, src[3].time)

    def test_epoch_seconds_ms_and_headerless(self):
        t = int(T0)
        txt = "\n".join("%d,1.0,2.0,0.5,1.5,7" % (t + i * 60) for i in range(5))
        got, _ = cs.parse_csv(txt)
        self.assertEqual(got[0].time, t)
        ms = "\n".join("%d,1.0,2.0,0.5,1.5,7" % ((t + i * 60) * 1000) for i in range(5))
        self.assertEqual(cs.parse_csv(ms)[0][0].time, t)

    def test_mt5_export_format(self):
        txt = "<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\t<VOL>\t<SPREAD>\n" + \
              "\n".join("2024.01.02\t%02d:00:00\t2060.5\t2061.0\t2059.9\t2060.8\t100\t0\t20" % h for h in range(5))
        got, _ = cs.parse_csv(txt)
        self.assertEqual(len(got), 5)
        self.assertEqual(got[1].time - got[0].time, 3600)
        self.assertEqual(cs.detect_tf(got), "1h")

    def test_semicolon_decimal_comma_and_dmy(self):
        txt = "Date;Open;High;Low;Close;Volume\n" + "\n".join("0%d/02/2024 10:00;1,5;2,0;1,0;1,8;5" % d for d in range(1, 8))
        got, _ = cs.parse_csv(txt)
        self.assertEqual(len(got), 7)
        self.assertAlmostEqual(got[0].high, 2.0)
        self.assertEqual(cs.detect_tf(got), "1d")

    def test_bad_rows_skipped_and_garbage_rejected(self):
        txt = cs.to_csv(series(0, 10)) + "hỏng,dòng,này\n"
        got, info = cs.parse_csv(txt)
        self.assertEqual(len(got), 10)
        self.assertEqual(info["skipped"], 1)
        with self.assertRaises(ValueError):
            cs.parse_csv("abc\ndef\nghi")
        with self.assertRaises(ValueError):
            cs.parse_csv("")
        with self.assertRaises(ValueError):
            cs.parse_csv("time,open,close\n1,2,3")

    def test_unsorted_dupes_and_junk_prices_cleaned(self):
        rows = ["time,open,high,low,close,volume"]
        for i in [3, 1, 2, 2, 0, 4, 5]:
            rows.append("%d,100,101,99,100,1" % (T0 + i * 60))
        rows.append("%d,-5,1,1,1,1" % (T0 + 600))
        got, _ = cs.parse_csv("\n".join(rows))
        self.assertEqual([c.time for c in got], [T0 + i * 60 for i in range(6)])

    def test_detect_tf(self):
        self.assertEqual(cs.detect_tf(series(0, 10, 300)), "5m")
        self.assertIsNone(cs.detect_tf(series(0, 10, 77)))
        self.assertIsNone(cs.detect_tf(series(0, 2)))

    def test_import_then_store_read_back(self):
        d = tempfile.TemporaryDirectory()
        try:
            st = cs.CandleStore(d.name)
            got, _ = cs.parse_csv(cs.to_csv(series(0, 30)))
            st.put(cs.FILE_SOURCE, "XAUUSD", "1m", got)
            self.assertEqual(len(st.read(cs.FILE_SOURCE, "XAUUSD", "1m")), 30)
        finally:
            d.cleanup()


if __name__ == "__main__":
    unittest.main()


class TestHighLevel(unittest.TestCase):
    def test_import_and_export_roundtrip_across_machines(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b, tempfile.TemporaryDirectory() as ex:
            s1, s2 = cs.CandleStore(a), cs.CandleStore(b)
            s1.put("public", "XAUUSD", "5m", series(0, 45000, 300))              # > 1 khúc xuất (20.000)
            path = cs.export_csv(s1, "public", "XAUUSD", "5m", ex)
            self.assertTrue(path.endswith(".csv") and os.path.exists(path))
            info = cs.import_csv_text(s2, open(path, encoding="utf-8").read(), "xauusd")
            self.assertEqual((info["count"], info["tf"], info["symbol"]), (45000, "5m", "XAUUSD"))
            x, y = s1.read("public", "XAUUSD", "5m"), s2.read(cs.FILE_SOURCE, "XAUUSD", "5m")
            self.assertEqual(len(x), len(y))
            self.assertEqual([c.time for c in x[::5000]], [c.time for c in y[::5000]])
            self.assertAlmostEqual(x[12345].high, y[12345].high)

    def test_import_validation(self):
        with tempfile.TemporaryDirectory() as a:
            st = cs.CandleStore(a)
            txt = cs.to_csv(series(0, 30, 300))
            with self.assertRaises(ValueError):
                cs.import_csv_text(st, txt, "")
            with self.assertRaises(ValueError):
                cs.import_csv_text(st, txt, "BTC", "1h")                           # khung chọn sai so với dữ liệu
            with self.assertRaises(ValueError):
                cs.import_csv_text(st, cs.to_csv(series(0, 30, 77)), "BTC")        # không nhận được khung
            self.assertEqual(cs.import_csv_text(st, txt, "BTC", "5m")["tf"], "5m")
