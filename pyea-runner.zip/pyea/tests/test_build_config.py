"""Cấu hình build Android: tránh các lỗi đã gặp (xem HANDOFF 5bi, 5bk, 5bl)."""
import importlib.util
import os
import re
import shutil
import sys
import tempfile
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return f.read()


class TestBuildConfig(unittest.TestCase):
    def test_requirements_not_pinned_with_double_equals(self):
        m = re.search(r"^requirements\s*=\s*(.+)$", read("buildozer.spec"), re.M)
        self.assertTrue(m)
        # p4a 2026: tên có '==' không khớp recipe -> bị coi là module pip (kivy tải từ PyPI)
        self.assertNotIn("==", m.group(1))
        self.assertIn("kivy", m.group(1).split(","))
        # ép charset_normalizer thuần Python bằng link trực tiếp: KHÔNG phụ thuộc file workflow ở gốc repo
        self.assertRegex(m.group(1), r"charset_normalizer@https://files\.pythonhosted\.org/\S+-py3-none-any\.whl")

    def test_constraints_and_workflow(self):
        self.assertIn("charset-normalizer<3.5", read("tools", "p4a_constraints.txt"))
        # pip ghim đúng bản đóng gói trong hostpython 3.14.2 của p4a v2026.05.09 (HANDOFF 5bl)
        self.assertRegex(read("tools", "p4a_constraints.txt"), r"(?m)^pip==25\.3$")
        for wf in (os.path.join(".github", "workflows", "build-apk.yml"), os.path.join("docs", "build-apk.yml")):
            t = read(wf)
            self.assertIn("PIP_CONSTRAINT", t, wf)
            self.assertIn("buildozer-v3-", t, wf)
            self.assertNotIn("restore-keys: |\n            buildozer-${{ runner.os }}-\n", t, wf)
            self.assertIn("Drop stale p4a dist", t, wf)
            self.assertIn("build-*/build/venv", t, wf)          # xoá venv cũ của p4a khỏi cache (pip bị «lai»)

    def test_local_recipe_wired_in_spec(self):
        spec = read("buildozer.spec")
        m = re.search(r"^requirements\s*=\s*(.+)$", spec, re.M)
        self.assertIn("pyeapipfix", [x.strip() for x in m.group(1).split(",")])
        self.assertRegex(spec, r"(?m)^p4a\.local_recipes\s*=\s*tools/p4a_recipes\s*$")
        self.assertTrue(os.path.isfile(os.path.join(ROOT, "tools", "p4a_recipes", "pyeapipfix", "__init__.py")))
        # tools/ không được vào APK (recipe chỉ dùng lúc build)
        self.assertRegex(spec, r"source\.exclude_dirs\s*=.*\btools\b")

    def _load_recipe(self):
        """Nạp recipe với p4a GIẢ (không cần cài python-for-android) rồi trả về (module, build_giả)."""
        calls = []
        pfa = types.ModuleType("pythonforandroid")
        rec = types.ModuleType("pythonforandroid.recipe")
        bld = types.ModuleType("pythonforandroid.build")

        class Recipe:
            def prebuild_arch(self, arch):
                return "prebuild"
        rec.Recipe = Recipe

        def run_pymodules_install(ctx, arch, modules, project_dir=None, ignore_setup_py=False):
            calls.append((arch.arch, os.path.exists(os.path.join(ctx.build_dir, "venv"))))
            os.makedirs(os.path.join(ctx.build_dir, "venv", "lib"), exist_ok=True)
        bld.run_pymodules_install = run_pymodules_install
        pfa.recipe, pfa.build = rec, bld
        saved = {k: sys.modules.get(k) for k in ("pythonforandroid", "pythonforandroid.recipe", "pythonforandroid.build")}

        def restore():
            for k, v in saved.items():
                if v is None:
                    sys.modules.pop(k, None)
                else:
                    sys.modules[k] = v
        self.addCleanup(restore)                        # p4a giả tồn tại suốt bài test, trả lại nguyên trạng sau đó
        sys.modules.update({"pythonforandroid": pfa, "pythonforandroid.recipe": rec, "pythonforandroid.build": bld})
        spec = importlib.util.spec_from_file_location(
            "pyeapipfix_t", os.path.join(ROOT, "tools", "p4a_recipes", "pyeapipfix", "__init__.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod, bld, calls

    def test_recipe_removes_venv_before_each_arch(self):
        mod, bld, calls = self._load_recipe()
        self.assertEqual(mod.recipe.name, "pyeapipfix")
        self.assertIsNone(mod.recipe.url)               # không tải gì, không vào APK
        self.assertEqual(mod.recipe.depends, [])
        self.assertTrue(getattr(bld.run_pymodules_install, "_pyea_fresh_venv", False))
        d = tempfile.mkdtemp()
        try:
            ctx = types.SimpleNamespace(build_dir=d)
            for a in ("arm64-v8a", "armeabi-v7a"):
                bld.run_pymodules_install(ctx, types.SimpleNamespace(arch=a), [], None, ignore_setup_py=True)
            # lần 2 KHÔNG còn thấy venv của lần 1 => pip không bị chép đè
            self.assertEqual(calls, [("arm64-v8a", False), ("armeabi-v7a", False)])
            self.assertFalse(mod.apply_patch())            # idempotent: không bọc hai lần
            self.assertEqual(mod.recipe.prebuild_arch(None), "prebuild")
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_workflows_identical(self):
        self.assertEqual(read(".github", "workflows", "build-apk.yml"), read("docs", "build-apk.yml"))


if __name__ == "__main__":
    unittest.main()
