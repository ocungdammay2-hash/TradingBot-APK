"""Cấu hình build Android: tránh hai lỗi đã gặp (xem HANDOFF 5bi, 5bk)."""
import os
import re
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return f.read()


class TestBuildConfig(unittest.TestCase):
    def test_requirements_not_pinned_with_double_equals(self):
        m = re.search(r"^requirements\s*=\s*(.+)$", read("buildozer.spec"), re.M)
        self.assertTrue(m)
        # p4a 2026: tên có '==' không khớp recipe -> bị coi là module pip (kivy tải từ PyPI)
        self.assertNotIn("==", m.group(1))
        self.assertIn("kivy", m.group(1).split(","))

    def test_constraints_and_workflow(self):
        self.assertIn("charset-normalizer<3.5", read("tools", "p4a_constraints.txt"))
        for wf in (os.path.join(".github", "workflows", "build-apk.yml"), os.path.join("docs", "build-apk.yml")):
            t = read(wf)
            self.assertIn("PIP_CONSTRAINT", t, wf)
            self.assertIn("buildozer-v3-", t, wf)
            self.assertNotIn("restore-keys: |\n            buildozer-${{ runner.os }}-\n", t, wf)
            self.assertIn("Drop stale p4a dist", t, wf)

    def test_workflows_identical(self):
        self.assertEqual(read(".github", "workflows", "build-apk.yml"), read("docs", "build-apk.yml"))


if __name__ == "__main__":
    unittest.main()
