"""Renko / Range / gộp N nến."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import bars
from pyea.sdk import Candle


def C(t, o, h, l, c, v=10.0):
    return Candle(t, o, h, l, c, v)


class TestAggregate(unittest.TestCase):
    def test_groups_ohlcv(self):
        cs = [C(0, 10, 12, 9, 11), C(60, 11, 15, 10, 14), C(120, 14, 14, 8, 9), C(180, 9, 10, 9, 10)]
        a = bars.aggregate(cs, 3)
        self.assertEqual(len(a), 2)
        self.assertEqual((a[0].time, a[0].open, a[0].high, a[0].low, a[0].close, a[0].volume), (0, 10, 15, 8, 9, 30.0))
        self.assertEqual((a[1].open, a[1].close), (9, 10))                  # nến cuối chưa đủ vẫn giữ
        self.assertEqual(len(bars.aggregate(cs, 1)), 4)


class TestRenko(unittest.TestCase):
    def test_bricks_are_contiguous_and_exact_size(self):
        cs = [C(i * 60, 100 + i, 100 + i + 2, 100 + i - 1, 100 + i + 1) for i in range(30)]
        r = bars.renko(cs, 2.0, 60)
        self.assertGreater(len(r), 5)
        for b in r:
            self.assertAlmostEqual(b.high - b.low, 2.0)
            self.assertIn(b.close, (b.high, b.low))
        for a, b in zip(r, r[1:]):                                          # gạch nối tiếp liền mạch trong cùng xu hướng
            if (a.close > a.open) == (b.close > b.open):
                self.assertAlmostEqual(a.close, b.open)
        ts = [b.time for b in r]
        self.assertEqual(ts, sorted(set(ts)))                               # thời gian tăng và không trùng

    def test_reversal_needs_two_bricks(self):
        up = [C(0, 100, 106, 100, 106)]                                      # lên 3 gạch (brick=2)
        r = bars.renko(up + [C(60, 106, 106, 103, 103.5)], 2.0, 60)         # lùi 2.5 < 2 gạch (4) -> chưa đảo chiều
        self.assertTrue(all(b.close > b.open for b in r))
        r2 = bars.renko(up + [C(60, 106, 106, 101.9, 102)], 2.0, 60)        # lùi 4.1 -> đảo
        self.assertTrue(r2[-1].close < r2[-1].open)
        self.assertAlmostEqual(r2[-1].open, 104.0)                          # gạch giảm mở ở đáy gạch tăng cuối? (104 = đáy gạch 104-106)

    def test_flat_market_makes_no_bricks(self):
        self.assertEqual(bars.renko([C(i, 100, 100.5, 99.5, 100) for i in range(20)], 5.0, 60), [])

    def test_bad_input(self):
        self.assertEqual(bars.renko([], 1), [])
        self.assertEqual(bars.renko([C(0, 1, 2, 0, 1)], 0), [])


class TestRange(unittest.TestCase):
    def test_every_closed_bar_has_exact_range(self):
        import random
        rnd = random.Random(3)
        p, cs = 100.0, []
        for i in range(300):
            o = p
            c = o + rnd.uniform(-1.5, 1.5)
            cs.append(C(i * 60, o, max(o, c) + rnd.random(), min(o, c) - rnd.random(), c))
            p = c
        rb = bars.range_bars(cs, 1.0, 60)
        self.assertGreater(len(rb), 50)
        for b in rb:
            self.assertAlmostEqual(b.high - b.low, 1.0, places=9)
            self.assertLessEqual(b.low - 1e-9, min(b.open, b.close))
            self.assertGreaterEqual(b.high + 1e-9, max(b.open, b.close))
        ts = [b.time for b in rb]
        self.assertEqual(ts, sorted(set(ts)))
        for a, b in zip(rb, rb[1:]):
            self.assertAlmostEqual(b.open, a.close)                         # thanh sau mở tại giá đóng thanh trước

    def test_big_gap_makes_several_bars_without_hanging(self):
        rb = bars.range_bars([C(0, 100, 100, 100, 100), C(60, 100, 150, 100, 150)], 1.0, 60)
        self.assertEqual(len(rb), 50)


class TestTransform(unittest.TestCase):
    def test_dispatch_and_auto_size(self):
        cs = [C(i * 60, 100, 103, 97, 100 + (i % 3)) for i in range(60)]
        self.assertEqual(len(bars.transform(cs, "candle")), 60)
        self.assertEqual(len(bars.transform(cs, "agg", 5)), 12)
        self.assertGreater(bars.atr(cs), 5)
        self.assertEqual(bars.auto_size(cs, "range"), bars.auto_size(cs, "renko") / 2)
        self.assertIsInstance(bars.transform(cs, "renko", None, 60), list)


if __name__ == "__main__":
    unittest.main()


class TestChartPanelKinds(unittest.TestCase):
    def test_panel_transforms_and_persists(self):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import kivy_stub
        import test_ui_smoke as T
        kivy_stub.OPEN_POPUPS.clear()
        app = T.make_app()
        panel = app.chart_tab.panel
        cs = [C(i * 60, 100 + (i % 7), 104 + (i % 7), 98 + (i % 7), 101 + (i % 5)) for i in range(120)]
        got = {}
        panel.chart.update = lambda c, p, e, h: got.update(n=len(c), plots=p)
        panel.update(cs, {"x": [1] * 120}, [], [])
        self.assertEqual(got["n"], 120)
        panel.set_kind("agg", 4)
        panel.update(cs, {"x": [1] * 120}, [], [])
        self.assertEqual((got["n"], got["plots"]), (30, {}))
        self.assertEqual(app.store.load_prefs()["chart"]["bar_kind"], "agg")
        panel.set_kind("renko", None)
        panel.update(cs, {}, [], [])
        self.assertGreater(got["n"], 0)
        panel.kind_menu()
        self.assertIn("Gộp 5 nến", T.texts(kivy_stub.OPEN_POPUPS[-1].content))
        panel.set_kind("candle")
