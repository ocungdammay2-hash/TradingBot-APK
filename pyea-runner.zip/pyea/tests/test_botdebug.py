"""Debugger bot (pyea/botdebug.py): ghi từng dòng, điểm dừng chụp biến (có điều kiện), lỗi trong bot, giới hạn an toàn, KHÔNG đổi kết quả backtest."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import test_intrabar_tester as TI                              # noqa: E402
from pyea.backtest import run_backtest                         # noqa: E402
from pyea.botdebug import Tracer, parse_breakpoints            # noqa: E402

BOT = TI.write("dbg_bot.py", '''from pyea import BaseBot
class D(BaseBot):
    def on_init(self):
        self.n = 0
    def on_bar(self, c):
        self.n += 1
        gap = c.close - c.open
        if self.n == 3:
            self.api.buy(1.0, sl=90.0, tp=110.0, reason="dbg")
''')
BAD = TI.write("dbg_bad.py", '''from pyea import BaseBot
class B(BaseBot):
    def on_bar(self, c):
        x = 1
        y = x / 0
''')


def run(path, dbg=None):
    return run_backtest(path, {}, TI.settings(), "BTCUSD", "5m", TI.candles_with_trap(), warmup=30, mode="ohlc_hl", debugger=dbg)


class TestParse(unittest.TestCase):
    def test_parse_breakpoints(self):
        bp, warn = parse_breakpoints("6, 7:self.n == 3; x, 0, 9:")
        self.assertEqual(bp, {6: "", 7: "self.n == 3", 9: ""})
        self.assertEqual(len(warn), 2)


class TestTracer(unittest.TestCase):
    def test_line_mode_records_lines_of_the_bot_only(self):
        t = Tracer(BOT, "lines", max_calls=2)
        r = run(BOT, t)
        self.assertTrue(r.ok, r.error)
        lines = [e[2] for e in t.events if e[3] == "line"]
        self.assertTrue(lines and set(lines) <= {6, 7, 8, 9})          # chỉ dòng trong thân on_bar (dòng 6-9), không dòng của engine
        self.assertEqual(t.calls_traced, 2)
        txt = t.report()
        self.assertIn("on_bar #1", txt)
        self.assertIn("self.n += 1", txt)

    def test_breakpoint_with_condition_captures_locals(self):
        t = Tracer(BOT, "breakpoints", {9: "self.n == 3"}, max_calls=10)
        run(BOT, t)
        hits = [e for e in t.events if e[3] == "break"]
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0][2], 9)
        self.assertIn("gap", hits[0][4])
        self.assertIn("c", hits[0][4])
        self.assertIn("●", t.report())

    def test_bad_condition_is_reported_not_fatal(self):
        t = Tracer(BOT, "breakpoints", {6: "khong_co_bien > 1"}, max_calls=1)
        r = run(BOT, t)
        self.assertTrue(r.ok, r.error)
        self.assertTrue([e for e in t.events if e[3] == "condfail"])

    def test_error_in_bot_is_shown(self):
        t = Tracer(BAD, "lines", max_calls=1)
        r = run(BAD, t)
        self.assertFalse(r.ok)                                           # lỗi bot vẫn làm backtest dừng như bình thường
        self.assertTrue([e for e in t.events if e[3] == "exc"])
        self.assertIn("ZeroDivisionError", t.report())

    def test_limits_stop_tracing(self):
        t = Tracer(BOT, "lines", max_events=3, max_calls=50)
        run(BOT, t)
        self.assertTrue(t.truncated)
        self.assertEqual(len(t.events), 3)
        self.assertIn("giới hạn an toàn", t.report())

    def test_skip_calls(self):
        t = Tracer(BOT, "lines", skip_calls=3, max_calls=1)
        run(BOT, t)
        self.assertEqual({e[1] for e in t.events}, {1})
        self.assertEqual(t.calls_seen >= 4, True)

    def test_does_not_change_backtest_result_and_restores_trace(self):
        a = run(BOT)
        before = sys.gettrace()
        b = run(BOT, Tracer(BOT, "lines", max_calls=5))
        self.assertIs(sys.gettrace(), before)
        self.assertEqual([(x.open_price, x.close_price, round(x.profit, 8)) for x in a.trades], [(x.open_price, x.close_price, round(x.profit, 8)) for x in b.trades])
        self.assertEqual(a.report["Lợi nhuận ròng"], b.report["Lợi nhuận ròng"])


if __name__ == "__main__":
    unittest.main()
