"""DNSE: chữ ký/headers theo đặc tả đã đối chiếu (không có vector chính thức -> kiểm lại bằng HMAC độc lập) + client không retry lệnh."""
import base64, hashlib, hmac, json, os, re, sys, unittest, urllib.error, urllib.parse
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import dnse


class R:
    def __init__(self, body, status=200): self.b, self.status = body, status
    def read(self): return self.b.encode()
    def __enter__(self): return self
    def __exit__(self, *a): return False


class TestSign(unittest.TestCase):
    def test_date_format(self):
        self.assertEqual(dnse.http_date(1777433708), "Wed, 29 Apr 2026 03:35:08 +0000")

    def test_signing_string_matches_documented_example(self):
        s = dnse.signing_string("GET", "/accounts?x=1", "Wed, 29 Apr 2026 03:35:08 +0000", "40e22598c132020383c21e627a474353")
        self.assertEqual(s, "(request-target): get /accounts\ndate: Wed, 29 Apr 2026 03:35:08 +0000\nnonce: 40e22598c132020383c21e627a474353")

    def test_signature_is_urlencoded_b64_hmac(self):
        sig = dnse.sign("sec", "POST", "/registration/trading-token", "D", "N")
        raw = hmac.new(b"sec", b"(request-target): post /registration/trading-token\ndate: D\nnonce: N", hashlib.sha256).digest()
        self.assertEqual(urllib.parse.unquote(sig), base64.b64encode(raw).decode())
        self.assertNotRegex(sig, r"[+/=]")

    def test_headers(self):
        h = dnse.auth_headers("K", "S", "GET", "/accounts", version="v", date="D", nonce="a" * 32)
        self.assertEqual(h["X-Api-Key"], "K"); self.assertEqual(h["Date"], "D"); self.assertEqual(h["version"], "v")
        self.assertRegex(h["X-Signature"], r'^Signature keyId="K",algorithm="hmac-sha256",headers="\(request-target\) date",signature="[^"]+",nonce="a{32}"$')
        self.assertEqual(dnse.auth_headers("K", "S", "GET", "/a", date_header="X-Aux-Date")["X-Aux-Date"][-5:], "+0000")
        self.assertNotIn("version", dnse.auth_headers("K", "S", "GET", "/a"))

    def test_nonce_fresh(self):
        a = dnse.auth_headers("K", "S", "GET", "/a")["X-Signature"]; b = dnse.auth_headers("K", "S", "GET", "/a")["X-Signature"]
        self.assertNotEqual(a, b)


class TestClient(unittest.TestCase):
    def test_accounts_and_headers(self):
        seen = []
        def op(req, timeout=0):
            seen.append(req); return R(json.dumps({"accounts": [{"id": "1"}]}))
        c = dnse.DnseClient("K", "S", opener=op)
        self.assertEqual(c.accounts()["accounts"][0]["id"], "1")
        self.assertEqual(seen[0].full_url, "https://openapi.dnse.com.vn/accounts")
        self.assertTrue(seen[0].get_header("X-signature"))

    def test_order_not_retried_and_error_mapped(self):
        n = []
        def op(req, timeout=0):
            n.append(1); raise urllib.error.URLError("boom")
        c = dnse.DnseClient("K", "S", opener=op)
        with self.assertRaises(dnse.DnseError) as cm:
            c.place_order("0001", "TT", "M", "NORMAL", {"symbol": "HPG"})
        self.assertEqual(len(n), 1); self.assertIn("KHÔNG tự gửi lại", str(cm.exception))

    def test_place_order_request_shape(self):
        seen = []
        def op(req, timeout=0):
            seen.append(req); return R("{}")
        dnse.DnseClient("K", "S", opener=op).place_order("00 1", "TT", "STOCK", "NORMAL", {"symbol": "HPG", "side": "NB"})
        r = seen[0]
        self.assertEqual(r.get_method(), "POST"); self.assertIn("/accounts/00%201/orders?marketType=STOCK&orderCategory=NORMAL", r.full_url)
        self.assertEqual(r.get_header("Trading-token"), "TT"); self.assertEqual(json.loads(r.data)["side"], "NB")

    def test_missing_creds(self):
        with self.assertRaises(dnse.DnseError): dnse.DnseClient("", "")


if __name__ == "__main__":
    unittest.main()
