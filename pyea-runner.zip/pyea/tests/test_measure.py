import os
import subprocess
import tempfile
import unittest

TOOLS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools", "mt5_phone")


def fake_proc(root, pid, name, rss_kb, utime, stime):
    d = os.path.join(root, str(pid))
    os.makedirs(d)
    # /proc/<pid>/stat: pid (name) state ppid ... utime(14) stime(15)
    fields = ["S", "1"] + ["0"] * 10 + [str(utime), str(stime)] + ["0"] * 30
    open(os.path.join(d, "stat"), "w").write("%d (%s) %s\n" % (pid, name, " ".join(fields)))
    open(os.path.join(d, "status"), "w").write("Name:\t%s\nVmRSS:\t%d kB\n" % (name, rss_kb))


class TestMeasure(unittest.TestCase):
    def test_groups_and_summary(self):
        root = tempfile.mkdtemp()
        fake_proc(root, 10, "box64", 102400, 100, 50)
        fake_proc(root, 11, "wineserver", 51200, 10, 10)
        fake_proc(root, 12, "terminal64.exe", 204800, 500, 100)
        fake_proc(root, 13, "Xvfb", 20480, 5, 5)
        fake_proc(root, 14, "bash", 99999, 1, 1)                          # không thuộc nhóm nào -> bị bỏ qua
        open(os.path.join(root, "meminfo"), "w").write("MemAvailable:    2048000 kB\n")
        out = os.path.join(tempfile.mkdtemp(), "m.csv")
        sm = out + ".sum"
        env = dict(os.environ, PROC_ROOT=root, OUT=out, SUM=sm)
        p = subprocess.run(["bash", os.path.join(TOOLS, "measure.sh"), "0.03", "1"], env=env, capture_output=True, text=True, timeout=30)
        self.assertEqual(p.returncode, 0, p.stderr)
        rows = open(out).read().strip().splitlines()
        self.assertGreaterEqual(len(rows), 2)
        c = rows[1].split(",")
        self.assertEqual([int(x) for x in c[1:6]], [100, 50, 200, 20, 370])      # MB theo nhóm + tổng
        self.assertEqual(int(c[10]), 2000)
        text = open(sm).read()
        self.assertIn("RAM đỉnh (MB): 370", text)

    def test_no_processes_message(self):
        root = tempfile.mkdtemp()
        open(os.path.join(root, "meminfo"), "w").write("MemAvailable: 1000 kB\n")
        out = os.path.join(tempfile.mkdtemp(), "m.csv")
        env = dict(os.environ, PROC_ROOT=root, OUT=out, SUM=out + ".sum")
        subprocess.run(["bash", os.path.join(TOOLS, "measure.sh"), "0.02", "1"], env=env, capture_output=True, timeout=30)
        self.assertIn("KHÔNG thấy tiến trình", open(out + ".sum").read())


if __name__ == "__main__":
    unittest.main()
