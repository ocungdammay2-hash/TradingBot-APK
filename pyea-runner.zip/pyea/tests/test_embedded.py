"""MT5 nhúng (pyea/embedded.py): tải + kiểm hash, giải nén an toàn, dựng lệnh proot, cài/chạy/dừng/giám sát bằng proot GIẢ, đo CPU/RAM, dọn tiến trình mồ côi.
KHÔNG kiểm chứng được: proot/Box64/Wine/MT5 thật trên điện thoại, các URL ở máy chủ bị chặn trong sandbox."""
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import unittest
import zipfile
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, ROOT)

from pyea import embedded as em  # noqa: E402
from pyea import mt5ea  # noqa: E402

TOKEN = "tok_embedded_12345"

FAKE_PROOT = '''#!%(py)s
import os, sys
a = sys.argv[1:]
mode = "%(mode)s"
if a == ["--version"]:
    if mode == "badver":
        sys.exit(3)
    print("proot fake 5.1")
    sys.exit(0)
if mode == "needs_noseccomp" and os.environ.get("PROOT_NO_SECCOMP") != "1":
    sys.stderr.write("proot error: ptrace(TRACEME): Operation not permitted\\n")
    sys.exit(1)
root, i = None, 0
while i < len(a):
    if a[i] in ("-r", "-b", "-w"):
        if a[i] == "-r":
            root = a[i + 1]
        i += 2
    elif a[i].startswith("-"):
        i += 1
    else:
        break
cmd = a[i:]
assert cmd[0] == "/usr/bin/env" and cmd[1] == "-i", cmd
j, env = 2, {}
while j < len(cmd) and "=" in cmd[j] and not cmd[j].startswith("/"):
    k, v = cmd[j].split("=", 1)
    env[k] = (root + v) if v.startswith("/root") else v
    j += 1
prog = cmd[j:]
if prog == ["/usr/bin/env", "true"]:
    sys.exit(0)
prog = [(root + x) if x.startswith("/root/") else x for x in prog]
if prog[0] == "/bin/bash":
    prog[0] = "bash"
env["PATH"] = os.environ["PATH"]
os.execvpe(prog[0], prog, env)
'''

FAKE_INSTALL = r'''#!/bin/bash
mkdir -p "$(dirname "$PYEA_INSTALL_LOG")"
echo "▶ Tải Wine 64-bit 9.7 ..." >> "$PYEA_INSTALL_LOG"
case "@MODE@" in
  fail) echo "✗ LỖI ở bước «wine»: boom" >> "$PYEA_INSTALL_LOG"; exit 1;;
  die) exit 137;;
esac
echo "✓ xong" >> "$PYEA_INSTALL_LOG"
exit 0
'''

FAKE_RUN = r'''#!/bin/bash
# giả «run_mt5_termux.sh run»: sống tới khi có file yêu cầu dừng; chế độ nhúng vào mã (env -i xoá biến môi trường)
echo "profile=$PYEA_PROFILE" >> "$HOME_DBG/run.out" 2>/dev/null
case "@MODE@" in
  die) exit 1;;
  lean2) [ "$PYEA_PROFILE" = lean ] && exit 2;;
esac
while [ ! -e "$PYEA_STOP_FILE" ]; do sleep 0.05; done
exit 0
'''


def make_zip(path, py, variants=("", ".a10"), bad=(), mode=""):
    with zipfile.ZipFile(path, "w") as z:
        for v in variants:
            for n in ("proot", "loader", "loader32", "libtalloc.so.2"):
                body = (FAKE_PROOT % {"py": py, "mode": mode}) if n == "proot" else "loader-" + n
                if n == "proot" and v in bad:
                    body = "#!/bin/sh\nexit 1\n"
                z.writestr(n + v, body)
    return path


def make_rootfs(path, extra=()):
    with tarfile.open(path, "w:gz") as tf:
        def add(name, data=b"", mode=0o644, typ=tarfile.REGTYPE, link=""):
            ti = tarfile.TarInfo(name)
            ti.mode, ti.type, ti.linkname, ti.size = mode, typ, link, (len(data) if typ == tarfile.REGTYPE else 0)
            tf.addfile(ti, io.BytesIO(data) if typ == tarfile.REGTYPE else None)
        add("./", typ=tarfile.DIRTYPE, mode=0o755)
        add("./usr", typ=tarfile.DIRTYPE, mode=0o755)
        add("./usr/bin", typ=tarfile.DIRTYPE, mode=0o555)
        add("./usr/bin/bash", b"#!bash", 0o755)
        add("./bin", typ=tarfile.SYMTYPE, link="usr/bin")
        add("./etc/", typ=tarfile.DIRTYPE, mode=0o755)
        add("./.dockerenv", b"x", 0o644)
        for e in extra:
            add(*e[:1], **e[1])
    return path


def sums_for(path, name=None):
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()
    return "%s *%s\n" % (h, name or os.path.basename(path))


class Env:
    """Thư mục thử: data_dir, 'máy chủ tải' bằng file://, máy chủ cục bộ thật của app (Mt5EaServer) để nhận SEVT."""

    def __init__(self, tc, mode="ok", variants=("", ".a10"), bad=(), start_server=True, fake_run="wait", fake_mode="ok"):
        self.tmp = tempfile.TemporaryDirectory()
        tc.addCleanup(self.tmp.cleanup)
        t = self.tmp.name
        self.data = os.path.join(t, "data")
        self.srv_dir = os.path.join(t, "www")
        os.makedirs(self.data)
        os.makedirs(self.srv_dir)
        self.zip = make_zip(os.path.join(self.srv_dir, "assets.zip"), sys.executable, variants, bad, mode)
        self.tar = make_rootfs(os.path.join(self.srv_dir, "ubuntu-base-22.04.5-base-arm64.tar.gz"))
        with open(os.path.join(self.srv_dir, "SHA256SUMS"), "w") as f:
            f.write(sums_for(self.tar) + "deadbeef" * 8 + " *ubuntu-base-22.04.5-base-amd64.tar.gz\n")
        self.urls = {"proot": "file://" + self.zip, "proot_sha": hashlib.sha256(open(self.zip, "rb").read()).hexdigest(), "rootfs_dir": "file://" + self.srv_dir}
        self.scripts = {"install_mt5_termux.sh": FAKE_INSTALL.replace("@MODE@", fake_mode), "run_mt5_termux.sh": FAKE_RUN.replace("@MODE@", fake_run), "pyea_relay.py": "# relay"}
        self.srv = None
        if start_server:
            self.srv = mt5ea.Mt5EaServer(0, TOKEN)
            self.srv.start()
            tc.addCleanup(self.srv.close)

    def emb(self, **kw):
        e = em.Embedded(self.data, host="127.0.0.1", port=self.srv.port if self.srv else 1, token=TOKEN, scripts=self.scripts.__getitem__, urls=self.urls,
                        sdk=kw.pop("sdk", 30), arch=kw.pop("arch", "aarch64"), min_free_mb=kw.pop("min_free_mb", 1), **kw)
        e.poll = 0.05
        return e

    def stages(self):
        return {k: v["state"] for k, v in (self.srv.install if self.srv else {}).items()}


def wait_for(fn, timeout=15.0, step=0.05):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = fn()
        if v:
            return v
        time.sleep(step)
    return fn()


class TestDownload(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.src = os.path.join(self.tmp.name, "a.bin")
        open(self.src, "wb").write(os.urandom(300000))
        self.sha = hashlib.sha256(open(self.src, "rb").read()).hexdigest()
        self.dst = os.path.join(self.tmp.name, "o", "a.bin")

    def test_ok_and_sha_checked(self):
        em.download("file://" + self.src, self.dst, self.sha)
        self.assertEqual(open(self.dst, "rb").read(), open(self.src, "rb").read())
        self.assertFalse(os.path.exists(self.dst + ".part"))

    def test_sha_mismatch_deletes_and_raises(self):
        with self.assertRaises(em.EmbedError) as c:
            em.download("file://" + self.src, self.dst, "0" * 64)
        self.assertIn("SHA256", str(c.exception))
        self.assertFalse(os.path.exists(self.dst))
        self.assertFalse(os.path.exists(self.dst + ".part"))

    def test_resumes_from_part_even_when_server_ignores_range(self):
        os.makedirs(os.path.dirname(self.dst))
        open(self.dst + ".part", "wb").write(b"garbage-partial")
        em.download("file://" + self.src, self.dst, self.sha)          # file:// bỏ qua Range -> tải lại từ đầu, vẫn ra đúng nội dung
        self.assertEqual(em.sha256_file(self.dst), self.sha)

    def test_missing_file_retries_then_explains(self):
        slept = []
        with self.assertRaises(em.EmbedError) as c:
            em.download("file://" + self.src + ".nope", self.dst, retries=3, sleep=slept.append)
        self.assertIn("3 lần", str(c.exception))
        self.assertEqual(len(slept), 3)

    def test_stop_aborts(self):
        with self.assertRaises(em.Stopped):
            em.download("file://" + self.src, self.dst, stop=lambda: True)

    def test_progress_called(self):
        calls = []
        with mock.patch.object(em.time, "monotonic", side_effect=iter(range(0, 1000, 5))):
            em.download("file://" + self.src, self.dst, progress=lambda p, t: calls.append((p, t)))
        self.assertTrue(calls)


class TestPick(unittest.TestCase):
    def test_pick_newest_arm64(self):
        h = lambda c: c * 64          # noqa: E731
        txt = ("%s *ubuntu-base-22.04.5-base-amd64.tar.gz\n%s *ubuntu-base-22.04.4-base-arm64.tar.gz\n%s *ubuntu-base-22.04.5-base-arm64.tar.gz\n"
               "%s *ubuntu-base-22.04.5-base-arm64.manifest\n" % (h("a"), h("b"), h("c"), h("d")))
        self.assertEqual(em.pick_rootfs(txt), ("ubuntu-base-22.04.5-base-arm64.tar.gz", "c" * 64))

    def test_pick_none_raises(self):
        with self.assertRaises(em.EmbedError):
            em.pick_rootfs("%s *something-else.tar.gz\n" % ("a" * 64))


class TestExtract(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.t = self.tmp.name

    def tar(self, members):
        p = os.path.join(self.t, "x.tar.gz")
        with tarfile.open(p, "w:gz") as tf:
            for name, kw in members:
                ti = tarfile.TarInfo(name)
                data = kw.pop("data", b"")
                ti.mode = kw.pop("mode", 0o644)
                ti.type = kw.pop("type", tarfile.REGTYPE)
                ti.linkname = kw.pop("link", "")
                ti.size = len(data) if ti.type == tarfile.REGTYPE else 0
                tf.addfile(ti, io.BytesIO(data) if ti.type == tarfile.REGTYPE else None)
        return p

    def test_normal_extract_modes_links_hidden(self):
        dest = os.path.join(self.t, "r")
        p = make_rootfs(os.path.join(self.t, "r.tar.gz"))
        n = em.safe_extract_tar(p, dest)
        self.assertGreaterEqual(n, 5)
        self.assertTrue(os.access(os.path.join(dest, "usr", "bin", "bash"), os.X_OK))
        self.assertTrue(os.path.islink(os.path.join(dest, "bin")))
        self.assertEqual(os.readlink(os.path.join(dest, "bin")), "usr/bin")
        self.assertTrue(os.path.exists(os.path.join(dest, ".dockerenv")))             # tệp ẩn giữ nguyên dấu chấm
        self.assertTrue(os.access(os.path.join(dest, "usr", "bin"), os.W_OK))          # thư mục 0555 trong tar vẫn ghi được (chủ luôn rwx)
        em.rmtree_force(dest)
        self.assertFalse(os.path.exists(dest))

    def test_rejects_absolute_and_dotdot(self):
        for bad in ("/etc/passwd", "../evil", "a/../../evil"):
            with self.assertRaises(em.EmbedError, msg=bad):
                em.safe_extract_tar(self.tar([(bad, {"data": b"x"})]), os.path.join(self.t, "d"))
        self.assertFalse(os.path.exists(os.path.join(self.t, "evil")))

    def test_rejects_write_through_symlink(self):
        p = self.tar([("lnk", {"type": tarfile.SYMTYPE, "link": "/tmp"}), ("lnk/pwn", {"data": b"x"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d"))

    def test_rejects_hardlink_to_missing_or_outside(self):
        p = self.tar([("h", {"type": tarfile.LNKTYPE, "link": "nothere"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d"))
        p = self.tar([("h", {"type": tarfile.LNKTYPE, "link": "/etc/passwd"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d2"))

    def test_skips_devices_and_strips_setuid(self):
        p = self.tar([("dev", {"type": tarfile.CHRTYPE}), ("su", {"data": b"x", "mode": 0o4755}), ("ok", {"data": b"y", "mode": 0o000})])
        d = os.path.join(self.t, "d")
        em.safe_extract_tar(p, d)
        self.assertFalse(os.path.exists(os.path.join(d, "dev")))
        self.assertEqual(os.stat(os.path.join(d, "su")).st_mode & 0o7000, 0)
        self.assertTrue(os.access(os.path.join(d, "ok"), os.R_OK))                     # mode 000 vẫn đọc được (chủ luôn có rw)

    def test_stop_during_extract(self):
        p = make_rootfs(os.path.join(self.t, "r.tar.gz"))
        with self.assertRaises(em.Stopped):
            em.safe_extract_tar(p, os.path.join(self.t, "d"), stop=lambda: True)

    def test_hardlink_ok(self):
        p = self.tar([("a", {"data": b"hello", "mode": 0o755}), ("b", {"type": tarfile.LNKTYPE, "link": "a"})])
        d = os.path.join(self.t, "d")
        em.safe_extract_tar(p, d)
        self.assertEqual(open(os.path.join(d, "b"), "rb").read(), b"hello")

    def test_proot_assets_variants(self):
        z = make_zip(os.path.join(self.t, "z.zip"), sys.executable)
        em.extract_proot_assets(z, os.path.join(self.t, "a"), "a10")
        em.extract_proot_assets(z, os.path.join(self.t, "b"), "base")
        for d in ("a", "b"):
            for n in em.PROOT_FILES:
                self.assertTrue(os.access(os.path.join(self.t, d, n), os.X_OK), (d, n))
        z2 = make_zip(os.path.join(self.t, "z2.zip"), sys.executable, variants=("",))
        with self.assertRaises(em.EmbedError):
            em.extract_proot_assets(z2, os.path.join(self.t, "c"), "a10")


class TestInstallFlow(unittest.TestCase):
    def test_full_install_then_run_then_stop(self):
        e = Env(self)
        emb = e.emb()
        done = {}
        th = threading.Thread(target=lambda: done.update(rc=emb.serve()), daemon=True)
        th.start()
        st = wait_for(lambda: em.read_state(e.data).get("phase") == "running" and em.read_state(e.data))
        self.assertTrue(st, em.read_state(e.data))
        lo = emb.lo
        # proot + rootfs đã dựng
        self.assertEqual(open(os.path.join(lo.bin, ".ok")).read(), "a10")               # sdk 30 -> bản a10
        self.assertTrue(os.access(os.path.join(lo.bin, "a10", "proot"), os.X_OK))
        self.assertTrue(os.path.exists(os.path.join(lo.rootfs, ".pyea_rootfs_ok")))
        self.assertIn("nameserver", open(os.path.join(lo.rootfs, "etc", "resolv.conf")).read())
        self.assertIn('APT::Sandbox::User "root"', open(os.path.join(lo.rootfs, "etc", "apt", "apt.conf.d", "99pyea")).read())
        self.assertIn("ports.ubuntu.com", open(os.path.join(lo.rootfs, "etc", "apt", "sources.list")).read())
        self.assertEqual(oct(os.stat(os.path.join(lo.rootfs, "tmp")).st_mode & 0o7777), "0o1777")
        # script + token + override cấp cho khách; token chỉ chủ đọc
        for n in mt5ea.SCRIPT_FILES:
            self.assertTrue(os.path.exists(os.path.join(lo.host_root, "pyea", n)), n)
        self.assertEqual(oct(os.stat(os.path.join(lo.host_root, "pyea", "token")).st_mode & 0o777), "0o600")
        self.assertEqual(open(os.path.join(lo.host_root, "pyea", "token")).read(), TOKEN)
        ov = open(os.path.join(lo.host_root, ".pyea_override.sh")).read()
        self.assertIn("export PYEA_PROFILE='lean'", ov)
        self.assertIn("export PYEA_PORT='%d'" % e.srv.port, ov)
        self.assertNotIn(TOKEN, ov)
        # app (máy chủ thật) nhận được tiến trình
        self.assertTrue(wait_for(lambda: e.stages().get("login") == "start"))
        stg = e.stages()
        self.assertEqual((stg["precheck"], stg["proot"], stg["rootfs"]), ("ok", "ok", "ok"))
        # đo tài nguyên báo về app
        self.assertTrue(wait_for(lambda: e.srv.res.get("procs", 0) >= 1, 15), e.srv.res)
        # dừng êm
        em.request_stop(e.data)
        th.join(20)
        self.assertFalse(th.is_alive())
        self.assertTrue(done.get("rc"))
        self.assertEqual(em.read_state(e.data)["phase"], "stopped")

    def test_second_run_skips_done_stages(self):
        e = Env(self, fake_run="die")
        emb = e.emb()
        self.assertTrue(emb.install())
        e.srv.install_reset()
        emb2 = e.emb()
        self.assertTrue(emb2.install())
        stg = e.stages()
        self.assertEqual((stg["proot"], stg["rootfs"]), ("skip", "skip"))              # tải/giải nén không lặp lại

    def test_variant_fallback_when_first_proot_variant_dead(self):
        e = Env(self, bad=(".a10",))
        emb = e.emb(sdk=30)
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "base")

    def test_sdk_below_29_prefers_base(self):
        e = Env(self)
        emb = e.emb(sdk=26)
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "base")

    def test_both_variants_dead_reports_proot_fail(self):
        e = Env(self, bad=("", ".a10"))
        emb = e.emb()
        self.assertFalse(emb.install())
        self.assertEqual(e.stages()["proot"], "fail")
        st = em.read_state(e.data)
        self.assertEqual((st["phase"], st["failed_stage"]), ("failed", "proot"))
        self.assertIn("không chạy được", st["error"])

    def test_seccomp_fallback(self):
        e = Env(self, mode="needs_noseccomp")
        emb = e.emb()
        self.assertTrue(emb.install())
        self.assertFalse(emb.seccomp)
        cmd, env = emb.proot_cmd(["/bin/true"])
        self.assertEqual(env.get("PROOT_NO_SECCOMP"), "1")

    def test_guest_command_unusable_fails_rootfs_stage(self):
        e = Env(self, mode="badguest")
        # proot --version ok nhưng chạy lệnh khách luôn lỗi
        e.zip = make_zip(os.path.join(e.srv_dir, "assets.zip"), sys.executable)
        bad = FAKE_PROOT.replace('prog = cmd[j:]', 'sys.exit(5)\nprog = cmd[j:]')
        with zipfile.ZipFile(e.zip, "w") as z:
            for v in ("", ".a10"):
                for n in em.PROOT_FILES:
                    z.writestr(n + v, (bad % {"py": sys.executable, "mode": ""}) if n == "proot" else "x")
        e.urls["proot_sha"] = hashlib.sha256(open(e.zip, "rb").read()).hexdigest()
        emb = e.emb()
        self.assertFalse(emb.install())
        self.assertEqual(e.stages()["rootfs"], "fail")
        self.assertIn("không chạy được lệnh", em.read_state(e.data)["error"])

    def test_inner_failure_reports_stage_from_log(self):
        e = Env(self, fake_mode="fail")
        emb = e.emb()
        self.assertFalse(emb.install())
        st = em.read_state(e.data)
        self.assertEqual((st["phase"], st["failed_stage"]), ("failed", "wine"))

    def test_inner_killed_without_report_guesses_stage(self):
        e = Env(self, fake_mode="die")
        emb = e.emb()
        self.assertFalse(emb.install())
        st = em.read_state(e.data)
        self.assertEqual(st["failed_stage"], "wine")                    # từ dòng «▶ Tải Wine» cuối trong install.log
        self.assertEqual(e.stages()["wine"], "fail")
        self.assertIn("137", e.srv.install["wine"]["detail"])

    def test_precheck_arch_disk_exec(self):
        e = Env(self)
        self.assertFalse(e.emb(arch="x86_64").install())
        self.assertIn("ARM 64-bit", e.srv.install["precheck"]["detail"])
        e2 = Env(self)
        self.assertFalse(e2.emb(min_free_mb=10 ** 9).install())
        self.assertIn("Còn trống", e2.srv.install["precheck"]["detail"])
        e3 = Env(self)
        with mock.patch.object(em.subprocess, "run", side_effect=PermissionError(13, "Permission denied")):
            self.assertFalse(e3.emb().install())
        self.assertIn("targetSdk 28", e3.srv.install["precheck"]["detail"])

    def test_works_without_app_server(self):
        e = Env(self, start_server=False)
        emb = e.emb()
        self.assertTrue(emb.install())                                    # app không nghe: bỏ qua báo cáo, vẫn cài và ghi state
        self.assertEqual(em.read_state(e.data)["phase"], "installed")

    def test_stop_during_install(self):
        e = Env(self)
        emb = e.emb()
        em.request_stop(e.data)
        self.assertTrue(emb.serve())                                      # cờ dừng có sẵn: không chạy gì, êm
        self.assertEqual(em.read_state(e.data)["phase"], "stopped")
        self.assertFalse(os.path.exists(emb.lo.rootfs))


class TestSupervise(unittest.TestCase):
    def run_serve(self, e, emb, until, timeout=20):
        res = {}
        th = threading.Thread(target=lambda: res.update(rc=emb.serve()), daemon=True)
        th.start()
        ok = wait_for(until, timeout)
        em.request_stop(e.data)
        th.join(20)
        self.assertFalse(th.is_alive())
        return ok, res

    def test_lean_crash_loop_falls_back_to_stable(self):
        e = Env(self, fake_run="lean2")
        emb = e.emb(profile="lean")
        ov = os.path.join(emb.lo.host_root, ".pyea_override.sh")
        ok, res = self.run_serve(e, emb, lambda: emb.profile == "stable" and os.path.exists(ov) and "'stable'" in open(ov).read() and em.read_state(e.data).get("phase") == "running")
        self.assertTrue(ok, em.read_state(e.data))
        self.assertEqual(em.read_request(e.data).get("profile"), "stable")      # nhớ lựa chọn cho lần sau
        self.assertIn("export PYEA_PROFILE='stable'", open(os.path.join(emb.lo.host_root, ".pyea_override.sh")).read())
        self.assertTrue(wait_for(lambda: any(a["kind"] == "profile" for a in e.srv.alerts), 5))

    def test_gives_up_after_many_fast_deaths(self):
        e = Env(self, fake_run="die")
        emb = e.emb(profile="stable")
        ok, res = self.run_serve(e, emb, lambda: em.read_state(e.data).get("phase") == "failed", 40)
        self.assertTrue(ok, em.read_state(e.data))
        st = em.read_state(e.data)
        self.assertEqual(st["failed_stage"], "login")
        self.assertEqual(e.stages()["login"], "fail")
        self.assertFalse(res.get("rc"))

    def test_start_run_uses_proot_flags(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        cmd, env = emb.proot_cmd(["/bin/bash", "-c", "true"], {"X": "1"})
        self.assertEqual(cmd[1:4], ["-0", "--link2symlink", "--kill-on-exit"])
        self.assertEqual(cmd[cmd.index("-r") + 1], emb.lo.rootfs)
        self.assertEqual(cmd[cmd.index("-w") + 1], "/root")
        i = cmd.index("/usr/bin/env")
        self.assertEqual(cmd[i + 1], "-i")
        self.assertIn("X=1", cmd)
        self.assertEqual(env["PROOT_LOADER"], os.path.join(emb.binv, "loader"))
        self.assertEqual(env["LD_LIBRARY_PATH"], emb.binv)
        self.assertEqual(env["PROOT_TMP_DIR"], emb.lo.tmp)
        self.assertNotIn("PROOT_NO_SECCOMP", env)
        self.assertNotIn(TOKEN, " ".join(cmd))                              # token KHÔNG nằm trên dòng lệnh (ps thấy được)

    def test_fake_proc_files_bound_when_unreadable(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        real_open = open

        def fake_open(p, *a, **k):
            if str(p) in ("/proc/stat", "/proc/uptime", "/proc/version", "/proc/sys/kernel/overflowuid"):
                raise PermissionError(13, "denied")
            return real_open(p, *a, **k)
        with mock.patch("builtins.open", fake_open):
            binds = emb._fake_binds()
        dst = [d for _, d in binds]
        self.assertIn("/proc/stat", dst)
        self.assertIn("/proc/uptime", dst)
        self.assertIn("/proc/sys/kernel/overflowuid", dst)
        self.assertIn("cpu0", real_open(os.path.join(emb.lo.fake, "stat")).read())

    def test_orphan_killed(self):
        e = Env(self)
        emb = e.emb()
        p = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)", "proot-orphan"], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        open(emb.lo.pidfile, "w").write("%d\n" % p.pid)
        self.assertTrue(emb.kill_orphans())
        self.assertTrue(wait_for(lambda: p.poll() is not None, 10))
        self.assertFalse(os.path.exists(emb.lo.pidfile))

    def test_orphan_not_killed_if_pid_reused_by_other_program(self):
        e = Env(self)
        emb = e.emb()
        p = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(5)"], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        open(emb.lo.pidfile, "w").write("%d\n" % p.pid)
        emb.kill_orphans()
        time.sleep(0.3)
        self.assertIsNone(p.poll())                                         # không phải proot -> không đụng


class TestSampler(unittest.TestCase):
    def test_sampler_counts_session_and_cpu(self):
        code = "import time\nt=time.time()\nwhile time.time()-t<3: pass"
        p = subprocess.Popen([sys.executable, "-c", code], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        s = em.Sampler(p.pid)
        s.sample()
        time.sleep(1.0)
        r = s.sample()
        self.assertGreaterEqual(r["procs"], 1)
        self.assertGreater(r["rss_mb"], 1)
        self.assertGreater(r["cpu"], 20.0)                                  # vòng lặp bận ~100% của một nhân
        self.assertIn("MB", r["top"])

    def test_sampler_empty_when_gone(self):
        r = em.Sampler(2 ** 22 - 1).sample()
        self.assertEqual((r["procs"], r["rss_mb"]), (0, 0))


class TestRequestAndService(unittest.TestCase):
    def test_request_roundtrip_and_stop_flag(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, port=1234, token="abc", want="run")
            em.write_request(d, profile="stable")
            r = em.read_request(d)
            self.assertEqual((r["port"], r["token"], r["profile"]), (1234, "abc", "stable"))
            self.assertEqual(oct(os.stat(em.Layout(d).request).st_mode & 0o777), "0o600")
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))
            em.request_stop(d)
            self.assertTrue(os.path.exists(em.Layout(d).stop_flag))
            em.request_stop(d, False)
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))

    def test_service_main_stop_request_exits(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, want="stop")
            self.assertTrue(em.service_main(json.dumps({"data_dir": d})))
            with self.assertRaises(em.EmbedError):
                em.service_main("{}")

    def test_diagnostics_masks_token_and_clear_all(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        emb.log("token=%s" % TOKEN)
        txt = emb.diagnostics()
        self.assertNotIn(TOKEN, txt)
        self.assertIn("phase=installed", txt)
        em.clear_all(e.data)
        self.assertFalse(os.path.exists(emb.lo.rootfs))
        self.assertFalse(os.path.exists(emb.lo.bin))


class TestAppSide(unittest.TestCase):
    def test_launch_writes_request_clears_stop_and_starts(self):
        with tempfile.TemporaryDirectory() as d:
            em.request_stop(d)
            calls = []
            r = em.launch(d, 18765, TOKEN, "lean", mt5_url="https://x.example/s.exe", starter=lambda a: calls.append(json.loads(a)) or (True, ""))
            self.assertEqual(r, (True, ""))
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))
            self.assertEqual(calls, [{"data_dir": d}])                         # tham số dịch vụ KHÔNG chứa token; token ở file request.json (0600)
            q = em.read_request(d)
            self.assertEqual((q["want"], q["port"], q["profile"], q["mt5_url"]), ("run", 18765, "lean", "https://x.example/s.exe"))
            self.assertNotIn("password", json.dumps(q).lower())

    def test_stop_waits_for_service_then_kills_it(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, want="run")
            st = {"n": 0}
            os.makedirs(em.Layout(d).root, exist_ok=True)
            open(em.Layout(d).state, "w").write(json.dumps({"phase": "running"}))

            def fake_sleep(_):
                st["n"] += 1
                if st["n"] == 3:
                    open(em.Layout(d).state, "w").write(json.dumps({"phase": "stopped"}))
            killed = []
            em.stop(d, wait=10, stopper=lambda: killed.append(1) or True, sleep=fake_sleep)
            self.assertEqual(st["n"], 3)                                         # đợi tới khi dịch vụ báo đã dừng, không giết sớm
            self.assertEqual(killed, [1])
            self.assertTrue(os.path.exists(em.Layout(d).stop_flag))
            self.assertEqual(em.read_request(d)["want"], "stop")

    def test_status_alive_and_installed(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(em.status(d)["phase"], "idle")
            os.makedirs(em.Layout(d).rootfs)
            open(os.path.join(em.Layout(d).rootfs, ".pyea_rootfs_ok"), "w").write("x")
            open(em.Layout(d).state, "w").write(json.dumps({"phase": "running", "t": 1000.0, "res": {"cpu": 3.0}}))
            s = em.status(d, now=1030.0)
            self.assertTrue(s["alive"] and s["installed"])
            self.assertEqual(s["res"]["cpu"], 3.0)
            self.assertFalse(em.status(d, now=1100.0)["alive"])                  # quá 60s không ghi nhịp = dịch vụ đã chết


class TestSupported(unittest.TestCase):
    def test_matrix(self):
        ok = dict(arch="aarch64", sdk=33, target=28, has_service=True)
        self.assertEqual(em.supported(**ok), (True, ""))
        self.assertFalse(em.supported(**dict(ok, arch="x86_64"))[0])
        self.assertIn("targetSdk 28", em.supported(**dict(ok, target=34))[1])
        self.assertTrue(em.supported(**dict(ok, sdk=28, target=34))[0])            # Android 9 trở xuống chưa có W^X: chạy được dù nhắm API cao
        self.assertIn("Emu", em.supported(**dict(ok, has_service=False))[1])

    def test_not_android_without_overrides(self):
        self.assertEqual(em.supported(), (False, "không phải Android"))


if __name__ == "__main__":
    unittest.main()
