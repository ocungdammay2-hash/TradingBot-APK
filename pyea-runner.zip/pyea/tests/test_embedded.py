"""MT5 nhúng (pyea/embedded.py): tải + kiểm hash, giải nén an toàn, dựng lệnh proot, cài/chạy/dừng/giám sát bằng proot GIẢ, đo CPU/RAM, dọn tiến trình mồ côi.
KHÔNG kiểm chứng được: proot/Box64/Wine/MT5 thật trên điện thoại, các URL ở máy chủ bị chặn trong sandbox."""
import hashlib
import itertools
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import unittest
import zipfile
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, ROOT)

from pyea import embedded as em  # noqa: E402
from pyea import mt5ea  # noqa: E402

TOKEN = "tok_embedded_12345"

FAKE_PROOT = '''#!%(py)s
import os, sys
a = sys.argv[1:]
mode = "%(mode)s"
if a == ["--version"]:
    if mode == "badver":
        sys.exit(3)
    print("proot fake 5.1")
    sys.exit(0)
if mode == "needs_noseccomp" and os.environ.get("PROOT_NO_SECCOMP") != "1":
    sys.stderr.write("proot error: ptrace(TRACEME): Operation not permitted\\n")
    sys.exit(1)
root, i = None, 0
while i < len(a):
    if a[i] in ("-r", "-b", "-w"):
        if a[i] == "-r":
            root = a[i + 1]
        i += 2
    elif a[i].startswith("-"):
        i += 1
    else:
        break
cmd = a[i:]
assert cmd[0] == "/usr/bin/env" and cmd[1] == "-i", cmd
j, env = 2, {}
while j < len(cmd) and "=" in cmd[j] and not cmd[j].startswith("/"):
    k, v = cmd[j].split("=", 1)
    env[k] = (root + v) if v.startswith("/root") else v
    j += 1
prog = cmd[j:]
if prog == ["/usr/bin/env", "true"]:
    sys.exit(0)
prog = [(root + x) if x.startswith("/root/") else x for x in prog]
if prog[0] == "/bin/bash":
    prog[0] = "bash"
env["PATH"] = os.environ["PATH"]
os.execvpe(prog[0], prog, env)
'''

FAKE_INSTALL = r'''#!/bin/bash
mkdir -p "$(dirname "$PYEA_INSTALL_LOG")"
echo "▶ Tải Wine 64-bit 9.7 ..." >> "$PYEA_INSTALL_LOG"
case "@MODE@" in
  fail) echo "✗ LỖI ở bước «wine»: boom" >> "$PYEA_INSTALL_LOG"; exit 1;;
  die) exit 137;;
esac
echo "✓ xong" >> "$PYEA_INSTALL_LOG"
exit 0
'''

FAKE_RUN = r'''#!/bin/bash
# giả «run_mt5_termux.sh run»: sống tới khi có file yêu cầu dừng; chế độ nhúng vào mã (env -i xoá biến môi trường)
echo "profile=$PYEA_PROFILE" >> "$HOME_DBG/run.out" 2>/dev/null
case "@MODE@" in
  die) exit 1;;
  lean2) [ "$PYEA_PROFILE" = lean ] && exit 2;;
esac
while [ ! -e "$PYEA_STOP_FILE" ]; do sleep 0.05; done
exit 0
'''


def make_zip(path, py, variants=("", ".a10"), bad=(), mode=""):
    with zipfile.ZipFile(path, "w") as z:
        for v in variants:
            for n in ("proot", "loader", "loader32", "libtalloc.so.2"):
                body = (FAKE_PROOT % {"py": py, "mode": mode}) if n == "proot" else "loader-" + n
                if n == "proot" and v in bad:
                    body = "#!/bin/sh\nexit 1\n"
                z.writestr(n + v, body)
    return path


def make_rootfs(path, extra=()):
    with tarfile.open(path, "w:gz") as tf:
        def add(name, data=b"", mode=0o644, typ=tarfile.REGTYPE, link=""):
            ti = tarfile.TarInfo(name)
            ti.mode, ti.type, ti.linkname, ti.size = mode, typ, link, (len(data) if typ == tarfile.REGTYPE else 0)
            tf.addfile(ti, io.BytesIO(data) if typ == tarfile.REGTYPE else None)
        add("./", typ=tarfile.DIRTYPE, mode=0o755)
        add("./usr", typ=tarfile.DIRTYPE, mode=0o755)
        add("./usr/bin", typ=tarfile.DIRTYPE, mode=0o555)
        add("./usr/bin/bash", b"#!bash", 0o755)
        add("./bin", typ=tarfile.SYMTYPE, link="usr/bin")
        add("./etc/", typ=tarfile.DIRTYPE, mode=0o755)
        add("./.dockerenv", b"x", 0o644)
        for e in extra:
            add(*e[:1], **e[1])
    return path


def sums_for(path, name=None):
    h = hashlib.sha256(open(path, "rb").read()).hexdigest()
    return "%s *%s\n" % (h, name or os.path.basename(path))


class Env:
    """Thư mục thử: data_dir, 'máy chủ tải' bằng file://, máy chủ cục bộ thật của app (Mt5EaServer) để nhận SEVT."""

    def __init__(self, tc, mode="ok", variants=("", ".a10"), bad=(), start_server=True, fake_run="wait", fake_mode="ok"):
        self.tmp = tempfile.TemporaryDirectory()
        tc.addCleanup(self.tmp.cleanup)
        t = self.tmp.name
        self.data = os.path.join(t, "data")
        self.srv_dir = os.path.join(t, "www")
        os.makedirs(self.data)
        os.makedirs(self.srv_dir)
        self.zip = make_zip(os.path.join(self.srv_dir, "assets.zip"), sys.executable, variants, bad, mode)
        self.tar = make_rootfs(os.path.join(self.srv_dir, "ubuntu-base-22.04.5-base-arm64.tar.gz"))
        with open(os.path.join(self.srv_dir, "SHA256SUMS"), "w") as f:
            f.write(sums_for(self.tar) + "deadbeef" * 8 + " *ubuntu-base-22.04.5-base-amd64.tar.gz\n")
        self.urls = {"proot": "file://" + self.zip, "proot_sha": hashlib.sha256(open(self.zip, "rb").read()).hexdigest(), "rootfs_dir": "file://" + self.srv_dir}
        self.scripts = {"install_mt5_termux.sh": FAKE_INSTALL.replace("@MODE@", fake_mode), "run_mt5_termux.sh": FAKE_RUN.replace("@MODE@", fake_run), "pyea_relay.py": "# relay"}
        self.srv = None
        if start_server:
            self.srv = mt5ea.Mt5EaServer(0, TOKEN)
            self.srv.start()
            tc.addCleanup(self.srv.close)

    def emb(self, **kw):
        e = em.Embedded(self.data, host="127.0.0.1", port=self.srv.port if self.srv else 1, token=TOKEN, scripts=self.scripts.__getitem__, urls=self.urls,
                        sdk=kw.pop("sdk", 30), arch=kw.pop("arch", "aarch64"), min_free_mb=kw.pop("min_free_mb", 1), native_dir=kw.pop("native_dir", None), va_bits=kw.pop("va_bits", 0), **kw)
        e.poll = 0.05
        return e

    def stages(self):
        return {k: v["state"] for k, v in (self.srv.install if self.srv else {}).items()}


def wait_for(fn, timeout=15.0, step=0.05):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        v = fn()
        if v:
            return v
        time.sleep(step)
    return fn()


class TestDownload(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.src = os.path.join(self.tmp.name, "a.bin")
        open(self.src, "wb").write(os.urandom(300000))
        self.sha = hashlib.sha256(open(self.src, "rb").read()).hexdigest()
        self.dst = os.path.join(self.tmp.name, "o", "a.bin")

    def test_ok_and_sha_checked(self):
        em.download("file://" + self.src, self.dst, self.sha)
        self.assertEqual(open(self.dst, "rb").read(), open(self.src, "rb").read())
        self.assertFalse(os.path.exists(self.dst + ".part"))

    def test_sha_mismatch_deletes_and_raises(self):
        with self.assertRaises(em.EmbedError) as c:
            em.download("file://" + self.src, self.dst, "0" * 64)
        self.assertIn("SHA256", str(c.exception))
        self.assertFalse(os.path.exists(self.dst))
        self.assertFalse(os.path.exists(self.dst + ".part"))

    def test_resumes_from_part_even_when_server_ignores_range(self):
        os.makedirs(os.path.dirname(self.dst))
        open(self.dst + ".part", "wb").write(b"garbage-partial")
        em.download("file://" + self.src, self.dst, self.sha)          # file:// bỏ qua Range -> tải lại từ đầu, vẫn ra đúng nội dung
        self.assertEqual(em.sha256_file(self.dst), self.sha)

    def test_missing_file_retries_then_explains(self):
        slept = []
        with self.assertRaises(em.EmbedError) as c:
            em.download("file://" + self.src + ".nope", self.dst, retries=3, sleep=slept.append)
        self.assertIn("3 lần", str(c.exception))
        self.assertEqual(len(slept), 3)

    def test_stop_aborts(self):
        with self.assertRaises(em.Stopped):
            em.download("file://" + self.src, self.dst, stop=lambda: True)

    def test_progress_called(self):
        calls = []
        with mock.patch.object(em.time, "monotonic", side_effect=itertools.count(0, 5)):          # vô hạn: luồng nền của test khác cũng gọi time.monotonic, đồng hồ hữu hạn sẽ cạn
            em.download("file://" + self.src, self.dst, progress=lambda p, t: calls.append((p, t)))
        self.assertTrue(calls)


class TestPick(unittest.TestCase):
    def test_pick_newest_arm64(self):
        h = lambda c: c * 64          # noqa: E731
        txt = ("%s *ubuntu-base-22.04.5-base-amd64.tar.gz\n%s *ubuntu-base-22.04.4-base-arm64.tar.gz\n%s *ubuntu-base-22.04.5-base-arm64.tar.gz\n"
               "%s *ubuntu-base-22.04.5-base-arm64.manifest\n" % (h("a"), h("b"), h("c"), h("d")))
        self.assertEqual(em.pick_rootfs(txt), ("ubuntu-base-22.04.5-base-arm64.tar.gz", "c" * 64))

    def test_pick_none_raises(self):
        with self.assertRaises(em.EmbedError):
            em.pick_rootfs("%s *something-else.tar.gz\n" % ("a" * 64))


class TestExtract(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.t = self.tmp.name

    def tar(self, members):
        p = os.path.join(self.t, "x.tar.gz")
        with tarfile.open(p, "w:gz") as tf:
            for name, kw in members:
                ti = tarfile.TarInfo(name)
                data = kw.pop("data", b"")
                ti.mode = kw.pop("mode", 0o644)
                ti.type = kw.pop("type", tarfile.REGTYPE)
                ti.linkname = kw.pop("link", "")
                ti.size = len(data) if ti.type == tarfile.REGTYPE else 0
                tf.addfile(ti, io.BytesIO(data) if ti.type == tarfile.REGTYPE else None)
        return p

    def test_normal_extract_modes_links_hidden(self):
        dest = os.path.join(self.t, "r")
        p = make_rootfs(os.path.join(self.t, "r.tar.gz"))
        n = em.safe_extract_tar(p, dest)
        self.assertGreaterEqual(n, 5)
        self.assertTrue(os.access(os.path.join(dest, "usr", "bin", "bash"), os.X_OK))
        self.assertTrue(os.path.islink(os.path.join(dest, "bin")))
        self.assertEqual(os.readlink(os.path.join(dest, "bin")), "usr/bin")
        self.assertTrue(os.path.exists(os.path.join(dest, ".dockerenv")))             # tệp ẩn giữ nguyên dấu chấm
        self.assertTrue(os.access(os.path.join(dest, "usr", "bin"), os.W_OK))          # thư mục 0555 trong tar vẫn ghi được (chủ luôn rwx)
        em.rmtree_force(dest)
        self.assertFalse(os.path.exists(dest))

    def test_rejects_absolute_and_dotdot(self):
        for bad in ("/etc/passwd", "../evil", "a/../../evil"):
            with self.assertRaises(em.EmbedError, msg=bad):
                em.safe_extract_tar(self.tar([(bad, {"data": b"x"})]), os.path.join(self.t, "d"))
        self.assertFalse(os.path.exists(os.path.join(self.t, "evil")))

    def test_rejects_write_through_symlink(self):
        p = self.tar([("lnk", {"type": tarfile.SYMTYPE, "link": "/tmp"}), ("lnk/pwn", {"data": b"x"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d"))

    def test_rejects_hardlink_to_missing_or_outside(self):
        p = self.tar([("h", {"type": tarfile.LNKTYPE, "link": "nothere"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d"))
        p = self.tar([("h", {"type": tarfile.LNKTYPE, "link": "/etc/passwd"})])
        with self.assertRaises(em.EmbedError):
            em.safe_extract_tar(p, os.path.join(self.t, "d2"))

    def test_skips_devices_and_strips_setuid(self):
        p = self.tar([("dev", {"type": tarfile.CHRTYPE}), ("su", {"data": b"x", "mode": 0o4755}), ("ok", {"data": b"y", "mode": 0o000})])
        d = os.path.join(self.t, "d")
        em.safe_extract_tar(p, d)
        self.assertFalse(os.path.exists(os.path.join(d, "dev")))
        self.assertEqual(os.stat(os.path.join(d, "su")).st_mode & 0o7000, 0)
        self.assertTrue(os.access(os.path.join(d, "ok"), os.R_OK))                     # mode 000 vẫn đọc được (chủ luôn có rw)

    def test_stop_during_extract(self):
        p = make_rootfs(os.path.join(self.t, "r.tar.gz"))
        with self.assertRaises(em.Stopped):
            em.safe_extract_tar(p, os.path.join(self.t, "d"), stop=lambda: True)

    def test_hardlink_ok(self):
        p = self.tar([("a", {"data": b"hello", "mode": 0o755}), ("b", {"type": tarfile.LNKTYPE, "link": "a"})])
        d = os.path.join(self.t, "d")
        em.safe_extract_tar(p, d)
        self.assertEqual(open(os.path.join(d, "b"), "rb").read(), b"hello")

    def test_proot_assets_variants(self):
        z = make_zip(os.path.join(self.t, "z.zip"), sys.executable)
        em.extract_proot_assets(z, os.path.join(self.t, "a"), "a10")
        em.extract_proot_assets(z, os.path.join(self.t, "b"), "base")
        for d in ("a", "b"):
            for n in em.PROOT_FILES:
                self.assertTrue(os.access(os.path.join(self.t, d, n), os.X_OK), (d, n))
        z2 = make_zip(os.path.join(self.t, "z2.zip"), sys.executable, variants=("",))
        with self.assertRaises(em.EmbedError):
            em.extract_proot_assets(z2, os.path.join(self.t, "c"), "a10")


class TestInstallFlow(unittest.TestCase):
    def test_full_install_then_run_then_stop(self):
        e = Env(self)
        emb = e.emb()
        done = {}
        th = threading.Thread(target=lambda: done.update(rc=emb.serve()), daemon=True)
        th.start()
        st = wait_for(lambda: em.read_state(e.data).get("phase") == "running" and em.read_state(e.data))
        self.assertTrue(st, em.read_state(e.data))
        lo = emb.lo
        # proot + rootfs đã dựng
        self.assertEqual(open(os.path.join(lo.bin, ".ok")).read(), "a10")               # sdk 30 -> bản a10
        self.assertTrue(os.access(os.path.join(lo.bin, "a10", "proot"), os.X_OK))
        self.assertTrue(os.path.exists(os.path.join(lo.rootfs, ".pyea_rootfs_ok")))
        self.assertIn("nameserver", open(os.path.join(lo.rootfs, "etc", "resolv.conf")).read())
        self.assertIn('APT::Sandbox::User "root"', open(os.path.join(lo.rootfs, "etc", "apt", "apt.conf.d", "99pyea")).read())
        self.assertIn("ports.ubuntu.com", open(os.path.join(lo.rootfs, "etc", "apt", "sources.list")).read())
        self.assertEqual(oct(os.stat(os.path.join(lo.rootfs, "tmp")).st_mode & 0o7777), "0o1777")
        # script + token + override cấp cho khách; token chỉ chủ đọc
        for n in mt5ea.SCRIPT_FILES:
            self.assertTrue(os.path.exists(os.path.join(lo.host_root, "pyea", n)), n)
        self.assertEqual(oct(os.stat(os.path.join(lo.host_root, "pyea", "token")).st_mode & 0o777), "0o600")
        self.assertEqual(open(os.path.join(lo.host_root, "pyea", "token")).read(), TOKEN)
        ov = open(os.path.join(lo.host_root, ".pyea_override.sh")).read()
        self.assertIn("export PYEA_PROFILE='lean'", ov)
        self.assertIn("export PYEA_PORT='%d'" % e.srv.port, ov)
        self.assertNotIn(TOKEN, ov)
        # app (máy chủ thật) nhận được tiến trình
        self.assertTrue(wait_for(lambda: e.stages().get("login") == "start"))
        stg = e.stages()
        self.assertEqual((stg["precheck"], stg["proot"], stg["rootfs"]), ("ok", "ok", "ok"))
        # đo tài nguyên báo về app
        self.assertTrue(wait_for(lambda: e.srv.res.get("procs", 0) >= 1, 15), e.srv.res)
        # dừng êm
        em.request_stop(e.data)
        th.join(20)
        self.assertFalse(th.is_alive())
        self.assertTrue(done.get("rc"))
        self.assertEqual(em.read_state(e.data)["phase"], "stopped")

    def test_second_run_skips_done_stages(self):
        e = Env(self, fake_run="die")
        emb = e.emb()
        self.assertTrue(emb.install())
        e.srv.install_reset()
        emb2 = e.emb()
        self.assertTrue(emb2.install())
        stg = e.stages()
        self.assertEqual((stg["proot"], stg["rootfs"]), ("skip", "skip"))              # tải/giải nén không lặp lại

    def test_variant_fallback_when_first_proot_variant_dead(self):
        e = Env(self, bad=(".a10",))
        emb = e.emb(sdk=30)
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "base")

    def test_sdk_below_29_prefers_base(self):
        e = Env(self)
        emb = e.emb(sdk=26)
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "base")

    def test_both_variants_dead_reports_proot_fail(self):
        e = Env(self, bad=("", ".a10"))
        emb = e.emb()
        self.assertFalse(emb.install())
        self.assertEqual(e.stages()["proot"], "fail")
        st = em.read_state(e.data)
        self.assertEqual((st["phase"], st["failed_stage"]), ("failed", "proot"))
        self.assertIn("không chạy được", st["error"])

    def test_seccomp_fallback(self):
        e = Env(self, mode="needs_noseccomp")
        emb = e.emb()
        self.assertTrue(emb.install())
        self.assertFalse(emb.seccomp)
        cmd, env = emb.proot_cmd(["/bin/true"])
        self.assertEqual(env.get("PROOT_NO_SECCOMP"), "1")

    def test_guest_command_unusable_fails_rootfs_stage(self):
        e = Env(self, mode="badguest")
        # proot --version ok nhưng chạy lệnh khách luôn lỗi
        e.zip = make_zip(os.path.join(e.srv_dir, "assets.zip"), sys.executable)
        bad = FAKE_PROOT.replace('prog = cmd[j:]', 'sys.exit(5)\nprog = cmd[j:]')
        with zipfile.ZipFile(e.zip, "w") as z:
            for v in ("", ".a10"):
                for n in em.PROOT_FILES:
                    z.writestr(n + v, (bad % {"py": sys.executable, "mode": ""}) if n == "proot" else "x")
        e.urls["proot_sha"] = hashlib.sha256(open(e.zip, "rb").read()).hexdigest()
        emb = e.emb()
        self.assertFalse(emb.install())
        self.assertEqual(e.stages()["rootfs"], "fail")
        self.assertIn("không chạy được lệnh", em.read_state(e.data)["error"])

    def test_inner_failure_reports_stage_from_log(self):
        e = Env(self, fake_mode="fail")
        emb = e.emb()
        self.assertFalse(emb.install())
        st = em.read_state(e.data)
        self.assertEqual((st["phase"], st["failed_stage"]), ("failed", "wine"))

    def test_inner_killed_without_report_guesses_stage(self):
        e = Env(self, fake_mode="die")
        emb = e.emb()
        self.assertFalse(emb.install())
        st = em.read_state(e.data)
        self.assertEqual(st["failed_stage"], "wine")                    # từ dòng «▶ Tải Wine» cuối trong install.log
        self.assertEqual(e.stages()["wine"], "fail")
        self.assertIn("137", e.srv.install["wine"]["detail"])

    def test_precheck_arch_disk_exec(self):
        e = Env(self)
        self.assertFalse(e.emb(arch="x86_64").install())
        self.assertIn("ARM 64-bit", e.srv.install["precheck"]["detail"])
        e2 = Env(self)
        self.assertFalse(e2.emb(min_free_mb=10 ** 9).install())
        self.assertIn("Còn trống", e2.srv.install["precheck"]["detail"])
        e3 = Env(self)
        with mock.patch.object(em.subprocess, "run", side_effect=PermissionError(13, "Permission denied")):
            self.assertFalse(e3.emb().install())
        self.assertIn("libproot.so", e3.srv.install["precheck"]["detail"])

    def test_works_without_app_server(self):
        e = Env(self, start_server=False)
        emb = e.emb()
        self.assertTrue(emb.install())                                    # app không nghe: bỏ qua báo cáo, vẫn cài và ghi state
        self.assertEqual(em.read_state(e.data)["phase"], "installed")

    def test_stop_during_install(self):
        e = Env(self)
        emb = e.emb()
        em.request_stop(e.data)
        self.assertTrue(emb.serve())                                      # cờ dừng có sẵn: không chạy gì, êm
        self.assertEqual(em.read_state(e.data)["phase"], "stopped")
        self.assertFalse(os.path.exists(emb.lo.rootfs))


class TestSupervise(unittest.TestCase):
    def run_serve(self, e, emb, until, timeout=20):
        res = {}
        th = threading.Thread(target=lambda: res.update(rc=emb.serve()), daemon=True)
        th.start()
        ok = wait_for(until, timeout)
        em.request_stop(e.data)
        th.join(20)
        self.assertFalse(th.is_alive())
        return ok, res

    def test_lean_crash_loop_falls_back_to_stable(self):
        e = Env(self, fake_run="lean2")
        emb = e.emb(profile="lean")
        ov = os.path.join(emb.lo.host_root, ".pyea_override.sh")
        ok, res = self.run_serve(e, emb, lambda: emb.profile == "stable" and os.path.exists(ov) and "'stable'" in open(ov).read() and em.read_state(e.data).get("phase") == "running")
        self.assertTrue(ok, em.read_state(e.data))
        self.assertEqual(em.read_request(e.data).get("profile"), "stable")      # nhớ lựa chọn cho lần sau
        self.assertIn("export PYEA_PROFILE='stable'", open(os.path.join(emb.lo.host_root, ".pyea_override.sh")).read())
        self.assertTrue(wait_for(lambda: any(a["kind"] == "profile" for a in e.srv.alerts), 5))

    def test_gives_up_after_many_fast_deaths(self):
        e = Env(self, fake_run="die")
        emb = e.emb(profile="stable")
        ok, res = self.run_serve(e, emb, lambda: em.read_state(e.data).get("phase") == "failed", 40)
        self.assertTrue(ok, em.read_state(e.data))
        st = em.read_state(e.data)
        self.assertEqual(st["failed_stage"], "login")
        self.assertEqual(e.stages()["login"], "fail")
        self.assertFalse(res.get("rc"))

    def test_start_run_uses_proot_flags(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        cmd, env = emb.proot_cmd(["/bin/bash", "-c", "true"], {"X": "1"})
        self.assertEqual(cmd[1:4], ["-0", "--link2symlink", "--kill-on-exit"])
        self.assertEqual(cmd[cmd.index("-r") + 1], emb.lo.rootfs)
        self.assertEqual(cmd[cmd.index("-w") + 1], "/root")
        i = cmd.index("/usr/bin/env")
        self.assertEqual(cmd[i + 1], "-i")
        self.assertIn("X=1", cmd)
        self.assertEqual(env["PROOT_LOADER"], os.path.join(emb.binv, "loader"))
        self.assertEqual(env["LD_LIBRARY_PATH"], emb.binv)
        self.assertEqual(env["PROOT_TMP_DIR"], emb.lo.tmp)
        self.assertNotIn("PROOT_NO_SECCOMP", env)
        self.assertNotIn(TOKEN, " ".join(cmd))                              # token KHÔNG nằm trên dòng lệnh (ps thấy được)

    def test_fake_proc_files_bound_when_unreadable(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        real_open = open

        def fake_open(p, *a, **k):
            if str(p) in ("/proc/stat", "/proc/uptime", "/proc/version", "/proc/sys/kernel/overflowuid"):
                raise PermissionError(13, "denied")
            return real_open(p, *a, **k)
        with mock.patch("builtins.open", fake_open):
            binds = emb._fake_binds()
        dst = [d for _, d in binds]
        self.assertIn("/proc/stat", dst)
        self.assertIn("/proc/uptime", dst)
        self.assertIn("/proc/sys/kernel/overflowuid", dst)
        self.assertIn("cpu0", real_open(os.path.join(emb.lo.fake, "stat")).read())

    def test_orphan_killed(self):
        e = Env(self)
        emb = e.emb()
        p = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)", "proot-orphan"], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        open(emb.lo.pidfile, "w").write("%d\n" % p.pid)
        self.assertTrue(emb.kill_orphans())
        self.assertTrue(wait_for(lambda: p.poll() is not None, 10))
        self.assertFalse(os.path.exists(emb.lo.pidfile))

    def test_orphan_not_killed_if_pid_reused_by_other_program(self):
        e = Env(self)
        emb = e.emb()
        p = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(5)"], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        open(emb.lo.pidfile, "w").write("%d\n" % p.pid)
        emb.kill_orphans()
        time.sleep(0.3)
        self.assertIsNone(p.poll())                                         # không phải proot -> không đụng


class TestSampler(unittest.TestCase):
    def test_sampler_counts_session_and_cpu(self):
        code = "import time\nt=time.time()\nwhile time.time()-t<3: pass"
        p = subprocess.Popen([sys.executable, "-c", code], start_new_session=True)
        self.addCleanup(lambda: p.poll() is None and p.kill())
        s = em.Sampler(p.pid)
        s.sample()
        time.sleep(1.0)
        r = s.sample()
        self.assertGreaterEqual(r["procs"], 1)
        self.assertGreater(r["rss_mb"], 1)
        self.assertGreater(r["cpu"], 20.0)                                  # vòng lặp bận ~100% của một nhân
        self.assertIn("MB", r["top"])

    def test_sampler_empty_when_gone(self):
        r = em.Sampler(2 ** 22 - 1).sample()
        self.assertEqual((r["procs"], r["rss_mb"]), (0, 0))


class TestRequestAndService(unittest.TestCase):
    def test_request_roundtrip_and_stop_flag(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, port=1234, token="abc", want="run")
            em.write_request(d, profile="stable")
            r = em.read_request(d)
            self.assertEqual((r["port"], r["token"], r["profile"]), (1234, "abc", "stable"))
            self.assertEqual(oct(os.stat(em.Layout(d).request).st_mode & 0o777), "0o600")
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))
            em.request_stop(d)
            self.assertTrue(os.path.exists(em.Layout(d).stop_flag))
            em.request_stop(d, False)
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))

    def test_service_main_stop_request_exits(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, want="stop")
            self.assertTrue(em.service_main(json.dumps({"data_dir": d})))
            with self.assertRaises(em.EmbedError):
                em.service_main("{}")

    def test_failed_run_is_not_retried_by_sticky_restart_but_user_retry_works(self):
        """Log thật: sau khi MT5 cài lỗi, Android dựng lại dịch vụ sticky và nó cài lại 14 lần liền (~5 phút/lần) cùng một lỗi."""
        with tempfile.TemporaryDirectory() as d:
            ran = []

            class Spy:
                def __init__(self, *a, **k):
                    ran.append("init")
                nonce = ""

                def serve(self, **k):
                    ran.append("serve")
                    return True
            real = em.Embedded
            em.Embedded = Spy
            try:
                em.launch(d, 18765, TOKEN, "lean", starter=lambda a: (True, ""))
                n1 = em.read_request(d)["nonce"]
                self.assertTrue(n1)
                os.makedirs(em.Layout(d).root, exist_ok=True)
                open(em.Layout(d).state, "w").write(json.dumps({"phase": "failed", "nonce": n1, "failed_stage": "mt5"}))
                self.assertFalse(em.service_main(json.dumps({"data_dir": d})))      # Android tự dựng lại dịch vụ: KHÔNG chạy lại
                self.assertEqual(ran, [])
                em.launch(d, 18765, TOKEN, "lean", starter=lambda a: (True, ""))   # người dùng bấm «Chạy lại»
                n2 = em.read_request(d)["nonce"]
                self.assertNotEqual(n1, n2)
                self.assertTrue(em.service_main(json.dumps({"data_dir": d})))
                self.assertEqual(ran, ["init", "serve"])
                # dịch vụ bị Android giết giữa chừng khi đang cài (phase=installing) thì PHẢI làm tiếp
                ran.clear()
                open(em.Layout(d).state, "w").write(json.dumps({"phase": "installing", "nonce": n2}))
                self.assertTrue(em.service_main(json.dumps({"data_dir": d})))
                self.assertEqual(ran, ["init", "serve"])
            finally:
                em.Embedded = real

    def test_address_space_bits_measured_from_maps(self):
        """Log thật: «Didn't detect 48bits of address space, considering it's 39bits» -> Wine 9.x không nạp được ntdll.dll. Đo trên máy, không đoán."""
        with tempfile.TemporaryDirectory() as d:
            def maps(*lines):
                p = os.path.join(d, "maps")
                with open(p, "w") as f:
                    f.write("\n".join(lines) + "\n")
                return p
            low = maps("0000005560000000-0000005560100000 r-xp 00000000 fe:00 1 /bin/x",
                       "0000007fc9d3c000-0000007fc9d3d000 rw-p 00000000 00:00 0 [stack]")
            self.assertEqual(em.address_space_bits(low), 39)
            high = maps("0000aaaad0000000-0000aaaad0100000 r-xp 00000000 fe:00 1 /bin/x",
                        "0000ffffd0000000-0000ffffd0021000 rw-p 00000000 00:00 0 [stack]")
            self.assertEqual(em.address_space_bits(high), 48)
            vs = maps("00007ffc00000000-00007ffc00021000 rw-p 00000000 00:00 0 [stack]",
                      "ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0 [vsyscall]")
            self.assertEqual(em.address_space_bits(vs), 47)                 # [vsyscall] không tính
            self.assertEqual(em.address_space_bits(os.path.join(d, "none")), 0)

    def test_address_space_never_changes_the_wine_version_only_the_diagnosis(self):
        """Không đoán bản Wine theo máy: dù không gian địa chỉ hẹp hay rộng, app KHÔNG đổi WINE_VER; số đo chỉ vào chẩn đoán."""
        e = Env(self)
        self.assertFalse(hasattr(em, "LOW_VA_WINE"))
        self.assertFalse(hasattr(em, "LOW_VA_FALLBACK"))
        for bits in (39, 47, 48, 0):
            env = e.emb(va_bits=bits).inner_env()
            self.assertNotIn("WINE_VER", env, bits)
            self.assertNotIn("WINE_FALLBACK_VERS", env, bits)
        narrow = e.emb(va_bits=39)
        self.assertEqual(narrow.inner_env(wine_ver="9.9")["WINE_VER"], "9.9")           # người dùng tự chọn thì giữ nguyên
        txt = narrow.diagnostics()
        self.assertIn("va=39", txt)
        self.assertIn("39-bit", txt)
        self.assertIn("không phải lỗi mạng", txt)
        self.assertNotIn("39-bit", e.emb(va_bits=48).diagnostics())

    def test_install_records_nonce_in_state(self):
        e = Env(self)
        emb = e.emb()
        emb.nonce = "abc-1"
        self.assertTrue(emb.install())
        self.assertEqual(em.read_state(e.data).get("nonce"), "abc-1")

    def test_diagnostics_includes_wine_diag(self):
        e = Env(self)
        emb = e.emb()
        os.makedirs(os.path.dirname(emb.lo.wine_diag), exist_ok=True)
        with open(emb.lo.wine_diag, "w", encoding="utf-8") as f:
            f.write("wine=amd64-9.7 loại_PE=x86 trang_nhớ=16384\n")
        txt = emb.diagnostics()
        self.assertIn("chẩn đoán Wine", txt)
        self.assertIn("loại_PE=x86", txt)

    def test_diagnostics_masks_token_and_clear_all(self):
        e = Env(self)
        emb = e.emb()
        self.assertTrue(emb.install())
        emb.log("token=%s" % TOKEN)
        txt = emb.diagnostics()
        self.assertNotIn(TOKEN, txt)
        self.assertIn("phase=installed", txt)
        em.clear_all(e.data)
        self.assertFalse(os.path.exists(emb.lo.rootfs))
        self.assertFalse(os.path.exists(emb.lo.bin))


class TestAppSide(unittest.TestCase):
    def test_launch_writes_request_clears_stop_and_starts(self):
        with tempfile.TemporaryDirectory() as d:
            em.request_stop(d)
            calls = []
            r = em.launch(d, 18765, TOKEN, "lean", mt5_url="https://x.example/s.exe", starter=lambda a: calls.append(json.loads(a)) or (True, ""))
            self.assertEqual(r, (True, ""))
            self.assertFalse(os.path.exists(em.Layout(d).stop_flag))
            self.assertEqual(calls, [{"data_dir": d}])                         # tham số dịch vụ KHÔNG chứa token; token ở file request.json (0600)
            q = em.read_request(d)
            self.assertEqual((q["want"], q["port"], q["profile"], q["mt5_url"]), ("run", 18765, "lean", "https://x.example/s.exe"))
            self.assertNotIn("password", json.dumps(q).lower())

    def test_stop_waits_for_service_then_kills_it(self):
        with tempfile.TemporaryDirectory() as d:
            em.write_request(d, want="run")
            st = {"n": 0}
            os.makedirs(em.Layout(d).root, exist_ok=True)
            open(em.Layout(d).state, "w").write(json.dumps({"phase": "running"}))

            def fake_sleep(_):
                st["n"] += 1
                if st["n"] == 3:
                    open(em.Layout(d).state, "w").write(json.dumps({"phase": "stopped"}))
            killed = []
            em.stop(d, wait=10, stopper=lambda: killed.append(1) or True, sleep=fake_sleep)
            self.assertEqual(st["n"], 3)                                         # đợi tới khi dịch vụ báo đã dừng, không giết sớm
            self.assertEqual(killed, [1])
            self.assertTrue(os.path.exists(em.Layout(d).stop_flag))
            self.assertEqual(em.read_request(d)["want"], "stop")

    def test_status_alive_and_installed(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(em.status(d)["phase"], "idle")
            os.makedirs(em.Layout(d).rootfs)
            open(os.path.join(em.Layout(d).rootfs, ".pyea_rootfs_ok"), "w").write("x")
            open(em.Layout(d).state, "w").write(json.dumps({"phase": "running", "t": 1000.0, "res": {"cpu": 3.0}}))
            s = em.status(d, now=1030.0)
            self.assertTrue(s["alive"] and s["installed"])
            self.assertEqual(s["res"]["cpu"], 3.0)
            self.assertFalse(em.status(d, now=1100.0)["alive"])                  # quá 60s không ghi nhịp = dịch vụ đã chết


class TestSupported(unittest.TestCase):
    def test_matrix(self):
        ok = dict(arch="aarch64", sdk=33, target=28, has_service=True, native=None)
        self.assertEqual(em.supported(**ok), (True, ""))
        self.assertFalse(em.supported(**dict(ok, arch="x86_64"))[0])
        self.assertIn("libproot.so", em.supported(**dict(ok, target=34))[1])        # nhắm API mới mà APK không chứa proot -> không chạy được, nói rõ vì sao
        self.assertEqual(em.supported(**dict(ok, target=34, native="/data/app/x/lib/arm64")), (True, ""))   # có proot trong APK -> chạy ở mọi targetSdk
        self.assertTrue(em.supported(**dict(ok, sdk=28, target=34))[0])            # Android 9 trở xuống chưa có W^X: chạy được dù nhắm API cao
        self.assertIn("Emu", em.supported(**dict(ok, has_service=False))[1])

    def test_not_android_without_overrides(self):
        self.assertEqual(em.supported(), (False, "không phải Android"))


def make_native(d, py, bad=(), mode=""):
    """Thư mục «thư viện gốc» giả: tên file đúng như trong APK (native_libs/arm64-v8a)."""
    os.makedirs(d, exist_ok=True)
    for v, names in em.NATIVE_FILES.items():
        for k, n in names.items():
            p = os.path.join(d, n)
            if k == "proot":
                body = ("#!/bin/sh\nexit 1\n") if v in bad else (FAKE_PROOT % {"py": py, "mode": mode})
            else:
                body = "native-" + n
            with open(p, "w") as f:
                f.write(body)
            os.chmod(p, 0o755)
    return d


class TestNativeProot(unittest.TestCase):
    """proot đóng gói trong APK (nativeLibraryDir): chạy được ở mọi targetSdk, không tải gì, không execve file trong thư mục dữ liệu."""

    def env(self, **kw):
        e = Env(self, **{k: v for k, v in kw.items() if k in ("fake_run", "fake_mode", "mode")})
        e.native = make_native(os.path.join(e.tmp.name, "lib", "arm64"), sys.executable, bad=kw.get("bad", ()))
        e.urls["proot"] = "file://" + os.path.join(e.tmp.name, "khong-co.zip")          # nếu còn tải proot thì test này vỡ
        return e

    def test_install_without_download_and_without_exec_probe(self):
        e = self.env()
        emb = e.emb(native_dir=e.native, sdk=34)
        with mock.patch.object(em.Embedded, "_probe_exec", side_effect=AssertionError("không được thử execve file trong thư mục dữ liệu")):
            self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "native-a10")
        self.assertTrue(os.path.exists(os.path.join(emb.lo.bin, "native-a10", "libtalloc.so.2")))
        self.assertFalse(os.path.exists(os.path.join(emb.lo.dl, "proot-assets.zip")))
        self.assertEqual(e.stages()["proot"], "ok")
        env = emb._proot_env()
        self.assertEqual(env["PROOT_LOADER"], os.path.join(e.native, "libproot_loader.so"))          # loader NẰM TRONG APK, không phải thư mục dữ liệu
        self.assertEqual(env["PROOT_LOADER_32"], os.path.join(e.native, "libproot_loader32.so"))
        self.assertEqual(env["LD_LIBRARY_PATH"], os.path.join(emb.lo.bin, "native-a10"))
        cmd, _ = emb.proot_cmd(["/usr/bin/env", "true"])
        self.assertEqual(cmd[0], os.path.join(e.native, "libproot_a10.so"))
        self.assertNotIn(emb.lo.root, cmd[0])
        # nội dung libtalloc chép đúng bản a10
        self.assertEqual(open(os.path.join(emb.lo.bin, "native-a10", "libtalloc.so.2")).read(), "native-libpyea_talloc_a10.so")

    def test_second_run_skips(self):
        e = self.env(fake_run="die")
        self.assertTrue(e.emb(native_dir=e.native, sdk=34).install())
        e.srv.install_reset()
        self.assertTrue(e.emb(native_dir=e.native, sdk=34).install())
        self.assertEqual(e.stages()["proot"], "skip")

    def test_variant_fallback_to_base(self):
        e = self.env(bad=("a10",))
        emb = e.emb(native_dir=e.native, sdk=34)
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "native-base")
        cmd, _ = emb.proot_cmd(["/usr/bin/env", "true"])
        self.assertEqual(cmd[0], os.path.join(e.native, "libproot.so"))
        self.assertEqual(open(os.path.join(emb.lo.bin, "native-base", "libtalloc.so.2")).read(), "native-libpyea_talloc.so")

    def test_all_variants_dead_message(self):
        e = self.env(bad=("a10", "base"))
        self.assertFalse(e.emb(native_dir=e.native, sdk=34).install())
        self.assertIn("đóng gói trong APK", e.srv.install["proot"]["detail"])

    def test_missing_files_reported(self):
        e = self.env()
        os.remove(os.path.join(e.native, "libpyea_talloc_a10.so"))
        emb = e.emb(native_dir=e.native, sdk=34)
        self.assertTrue(emb.install())                                                   # a10 thiếu -> tự dùng bản base
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "native-base")
        os.remove(os.path.join(e.native, "libpyea_talloc.so"))
        e2 = self.env()
        os.remove(os.path.join(e2.native, "libpyea_talloc_a10.so"))
        os.remove(os.path.join(e2.native, "libpyea_talloc.so"))
        self.assertFalse(e2.emb(native_dir=e2.native, sdk=34).install())
        self.assertIn("thiếu", e2.srv.install["proot"]["detail"])

    def test_old_download_marker_is_redone_natively(self):
        e = self.env()
        emb = e.emb(native_dir=e.native, sdk=34)
        os.makedirs(emb.lo.bin, exist_ok=True)
        open(os.path.join(emb.lo.bin, ".ok"), "w").write("a10")                          # dấu của đường tải về (bản APK cũ)
        self.assertFalse(emb.chk_proot())
        self.assertTrue(emb.install())
        self.assertEqual(open(os.path.join(emb.lo.bin, ".ok")).read(), "native-a10")

    def test_native_marker_without_native_dir_is_not_trusted(self):
        e = self.env()
        self.assertTrue(e.emb(native_dir=e.native, sdk=34).install())
        legacy = e.emb(native_dir=None, sdk=34)
        self.assertFalse(legacy.chk_proot())

    def test_guest_command_runs_through_native_proot(self):
        e = self.env()
        emb = e.emb(native_dir=e.native, sdk=34)
        self.assertTrue(emb.install())
        ok, why = emb.probe_guest()
        self.assertTrue(ok, why)

    def test_diagnostics_mention_native(self):
        e = self.env()
        emb = e.emb(native_dir=e.native, sdk=34)
        emb.install()
        self.assertIn("native=%s" % e.native, emb.diagnostics())
        self.assertIn("variant=a10", emb.diagnostics())


class TestPlayProtectNote(unittest.TestCase):
    """Khoảng cách targetSdk ↔ Android của máy luôn TÍNH ra (không ghi cứng số của máy nào)."""

    def test_relation_not_constant(self):
        gap = em.PLAY_PROTECT_GAP
        for dev in (28, 30, 33, 35, 36, 40):                        # bất kỳ máy nào
            self.assertEqual(em.play_protect_note(dev, dev), "")
            self.assertEqual(em.play_protect_note(dev, dev - gap), "")
            self.assertIn("quá %d mức" % gap, em.play_protect_note(dev, dev - gap - 1))
        self.assertEqual(em.play_protect_note(0, 28), "")             # không đọc được máy/APK -> không đoán
        self.assertEqual(em.play_protect_note(33, 0), "")

    def test_message_names_actual_numbers(self):
        m = em.play_protect_note(34, 28)
        self.assertIn("targetSdk 28", m)
        self.assertIn("API 34", m)

    def test_diagnostics_includes_target_and_note(self):
        with tempfile.TemporaryDirectory() as d:
            low = em.Embedded(d, sdk=34, target=28, native_dir=None, arch="aarch64")
            self.assertIn("target=28", low.diagnostics())
            self.assertIn("LƯU Ý", low.diagnostics())
            ok = em.Embedded(d, sdk=34, target=34, native_dir=None, arch="aarch64")
            self.assertIn("target=34", ok.diagnostics())
            self.assertNotIn("LƯU Ý", ok.diagnostics())

    def test_ci_reads_api_from_spec_not_hardcoded(self):
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        wf = open(os.path.join(root, ".github", "workflows", "build-apk.yml"), encoding="utf-8").read()
        self.assertIn("buildozer.spec", wf)
        self.assertIn("targetSdkVersion = android.api", wf)
        self.assertNotIn("(2[0-9]|3[0-2])", wf)                        # dải số cứng cũ


class TestFindNative(unittest.TestCase):
    def mk(self, d):
        os.makedirs(d, exist_ok=True)
        for n in ("libproot.so", "libproot_loader.so"):
            open(os.path.join(d, n), "w").write("x")

    def test_env_override(self):
        with tempfile.TemporaryDirectory() as t:
            self.mk(t)
            self.assertEqual(em.find_native_dir(env={"PYEA_NATIVE_LIB_DIR": t}, maps="/nonexistent"), t)
            self.assertIsNone(em.find_native_dir(env={"PYEA_NATIVE_LIB_DIR": t + "/nope"}, maps="/nonexistent"))

    def test_from_proc_maps(self):
        with tempfile.TemporaryDirectory() as t:
            lib = os.path.join(t, "data", "app", "~~abc==", "org.pyea.pyearunner-xyz==", "lib", "arm64")
            self.mk(lib)
            maps = os.path.join(t, "maps")
            with open(maps, "w") as f:
                f.write("7a00000000-7a00200000 r-xp 00000000 fd:03 123 /system/lib64/libc.so\n")
                f.write("7b00000000-7b00200000 r-xp 00000000 fd:03 456 %s/libpython3.11.so\n" % lib)
            self.assertEqual(em.find_native_dir(env={}, maps=maps), lib)

    def test_none_when_dir_lacks_proot(self):
        with tempfile.TemporaryDirectory() as t:
            lib = os.path.join(t, "lib", "arm64")
            os.makedirs(lib)
            maps = os.path.join(t, "maps")
            open(maps, "w").write("7b00000000-7b00200000 r-xp 0 fd:03 456 %s/libpython3.11.so\n" % lib)
            self.assertIsNone(em.find_native_dir(env={}, maps=maps))


class TestShippedNativeLibs(unittest.TestCase):
    """Các file thật đóng vào APK: đủ tên, đúng mã băm, đúng loại ELF (aarch64) - lỗi ở đây = APK dựng ra thiếu proot."""
    ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "native_libs")

    def test_all_names_exist_and_hashes_match(self):
        want = set(n for v in em.NATIVE_FILES.values() for n in v.values())
        have = set(os.listdir(os.path.join(self.ROOT, "arm64-v8a")))
        self.assertEqual(want, have)
        sums = {}
        for line in open(os.path.join(self.ROOT, "SHA256SUMS")):
            h, n = line.split()
            sums[n] = h
        self.assertEqual(set(sums), set("arm64-v8a/" + n for n in want))
        for n in want:
            self.assertEqual(em.sha256_file(os.path.join(self.ROOT, "arm64-v8a", n)), sums["arm64-v8a/" + n], n)

    def test_elf_aarch64(self):
        for n in sorted(os.listdir(os.path.join(self.ROOT, "arm64-v8a"))):
            with open(os.path.join(self.ROOT, "arm64-v8a", n), "rb") as f:
                h = f.read(20)
            self.assertEqual(h[:4], b"\x7fELF", n)
            if n == "libproot_loader32.so":
                self.assertEqual((h[4], int.from_bytes(h[18:20], "little")), (1, 40), n)       # ELF32 ARM
            else:
                self.assertEqual((h[4], int.from_bytes(h[18:20], "little")), (2, 183), n)      # ELF64 AArch64

    def test_proot_is_dynamic_on_system_linker_and_needs_talloc(self):
        data = open(os.path.join(self.ROOT, "arm64-v8a", "libproot.so"), "rb").read()
        self.assertIn(b"/system/bin/linker64", data)
        self.assertIn(b"libtalloc.so.2", data)

    def test_buildozer_ships_them(self):
        spec = open(os.path.join(os.path.dirname(self.ROOT), "buildozer.spec"), encoding="utf-8").read()
        self.assertRegex(spec, r"(?m)^android\.add_libs_arm64_v8a\s*=\s*native_libs/arm64-v8a/\*\.so\s*$")


if __name__ == "__main__":
    unittest.main()
