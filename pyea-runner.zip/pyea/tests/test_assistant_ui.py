"""Giao diện Trợ lý (Kivy GIẢ - kiểm tra logic, không kiểm tra hiển thị thật): nút ở 3 tab, trả lời ngoại tuyến khi chưa có AI, thẻ đề xuất → «Áp dụng» (lưu thật, cập nhật ô cài đặt,
KHÔNG đè ô bạn đang gõ dở), «Hoàn tác», đề xuất bị cấm không có nút Áp dụng, chuyển tab, kiểm tra hệ thống ở luồng nền, nút «Hỏi Trợ lý» ở hộp lỗi crash, bật/tắt chia sẻ trạng thái."""
import json
import os
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub
kivy_stub.install()
import test_ui_smoke as T                                           # noqa: E402
from pyea import assistant as A                                      # noqa: E402

AGENT = {"name": "AI 1", "enabled": True, "preset": "Groq", "model": "m", "api_key": "gsk_" + "b" * 30}


def block(**obj):
    return "```pyea-action\n%s\n```" % json.dumps(obj, ensure_ascii=False)


class TestAssistantUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()
        del kivy_stub.SCHEDULED[:]

    def flush(self):
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for f in fns:
            f(0)

    def until(self, cond, timeout=10.0):
        end = time.time() + timeout
        while time.time() < end:
            self.flush()
            if cond():
                return True
            time.sleep(0.02)
        return False

    def make(self, reply="", ai=True):
        app = T.make_app()
        app.hub.agents = [dict(AGENT)] if ai else []
        a = app.assistant()
        self.calls = []

        def chat(agent, msgs, mt):
            self.calls.append(msgs)
            return reply(msgs) if callable(reply) else reply
        a.chat_fn = chat
        return app, a

    def dialog(self, app, **kw):
        app.open_assistant_dialog(**kw)
        return kivy_stub.OPEN_POPUPS[-1].content

    def ask(self, app, root, text):
        before = len(self.calls)
        app._assistant_ui["send"](text)
        self.assertTrue(self.until(lambda: not app._assistant_ui["input"].disabled and not app.assistant()._busy.locked() and len(T.texts(root)) > 0))
        self.until(lambda: "Bạn" in T.texts(root))
        time.sleep(0.05)
        self.flush()
        return len(self.calls) - before

    # ------------------------------------------------------------------------------------------------ nút
    def test_button_in_trade_settings_and_log_tabs(self):
        app, _ = self.make()
        for tab in (app.trade_tab, app.settings_tab, app.log_tab):
            self.assertTrue(T.find(tab, lambda x: getattr(x, "text", None) == "Trợ lý" and x._binds.get("on_release")), type(tab).__name__)

    def test_press_button_opens_dialog_with_welcome_and_hard_limit_notice(self):
        app, _ = self.make()
        T.press(app.log_tab, "Trợ lý")
        root = kivy_stub.OPEN_POPUPS[-1].content
        txt = T.texts(root)
        self.assertIn("KHÔNG đặt/sửa/đóng lệnh", txt)
        self.assertIn("Áp dụng", txt)
        self.assertIn("không bao giờ đặt lệnh", txt)                      # nhãn nói rõ giới hạn

    # ------------------------------------------------------------------------------------------------ ngoại tuyến
    def test_without_ai_answers_from_manual_and_says_so(self):
        app, a = self.make(ai=False)
        root = self.dialog(app)
        self.assertIn("SỔ TAY", T.texts(root))
        app._assistant_ui["send"]("app bị crash thoát đột ngột phải làm sao")
        self.assertTrue(self.until(lambda: "sổ tay có sẵn" in T.texts(root)))
        txt = T.texts(root)
        self.assertIn("Gói chẩn đoán", txt)
        self.assertIn("Chưa có AI", txt)
        self.assertEqual(self.calls, [])                                  # không gọi model

    def test_quick_chip_sends_question(self):
        app, a = self.make(ai=False)
        root = self.dialog(app)
        T.press(root, "Chạy nền / pin")
        self.assertTrue(self.until(lambda: "Tối ưu pin" in T.texts(root)))

    # ------------------------------------------------------------------------------------------------ đề xuất → áp dụng
    def propose_refresh(self, app, root):
        app._assistant_ui["send"]("tiết kiệm pin")
        self.assertTrue(self.until(lambda: "Đề xuất:" in T.texts(root)))

    def test_apply_saves_updates_form_and_does_not_clobber_unsaved_typing(self):
        app, a = self.make(block(action="set_setting", key="ui_refresh", value=2, why="tiết kiệm pin"))
        root = self.dialog(app)
        g = app.settings_tab.gform.ctrl
        g["chart_bars"].text = "777"                                       # người dùng đang gõ dở ở tab Cài đặt, CHƯA bấm Lưu
        self.propose_refresh(app, root)
        self.assertIn("1.0 → 2.0", T.texts(root))
        self.assertEqual(app.settings["ui_refresh"], 1.0)                  # chưa bấm thì chưa đổi
        T.press(root, "Áp dụng")
        self.assertEqual(app.settings["ui_refresh"], 2.0)
        disp = app.settings_tab.gform.inputs["ui_refresh"].display
        self.assertEqual(g["ui_refresh"].text, str(disp(2.0)))             # ô trong form cập nhật
        self.assertEqual(g["chart_bars"].text, "777")                      # ô gõ dở giữ nguyên
        self.assertEqual(app.settings["chart_bars"], 400)                  # và KHÔNG bị lưu theo
        saved = app.store.load_settings()
        self.assertEqual(saved["ui_refresh"], 2.0)
        self.assertEqual(saved["chart_bars"], 400)
        self.assertIn("Hoàn tác", T.texts(root))
        T.press(root, "Hoàn tác")
        self.assertEqual(app.settings["ui_refresh"], 1.0)
        self.assertEqual(app.store.load_settings()["ui_refresh"], 1.0)
        self.assertEqual(g["ui_refresh"].text, str(disp(1.0)))

    def test_skip_does_nothing(self):
        app, a = self.make(block(action="set_setting", key="ui_refresh", value=2))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        T.press(root, "Bỏ qua")
        self.assertIn("Đã bỏ qua", T.texts(root))
        self.assertEqual(app.settings["ui_refresh"], 1.0)

    def test_forbidden_proposal_has_no_apply_button(self):
        app, a = self.make(block(action="set_setting", key="mode", value="live"))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        self.assertIn("Không áp dụng được", T.texts(root))
        self.assertEqual(len(T.find(root, lambda x: getattr(x, "text", None) == "Áp dụng" and x._binds.get("on_release"))), 0)
        self.assertEqual(app.settings["mode"], "paper")

    def test_order_request_never_reaches_session(self):
        app, a = self.make(block(action="place_order", side="buy", volume=1))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        self.assertEqual(len(T.find(root, lambda x: getattr(x, "text", None) == "Áp dụng" and x._binds.get("on_release"))), 0)

    def test_map_field_apply_writes_json_override(self):
        from pyea import fieldmap
        fieldmap.forget()
        self.addCleanup(fieldmap.forget)
        self.addCleanup(fieldmap.configure, "")
        app, a = self.make(block(action="map_field", scope="simulated", kind="position", field="profit", path="unrealized_pnl", why="khớp"))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        self.assertIn("Lưu ý", T.texts(root))                              # chưa có dữ liệu thô để đối chiếu
        T.press(root, "Áp dụng")
        ov = json.loads(app.settings["field_overrides"])
        self.assertEqual(ov, {"simulated": {"position": {"profit": "unrealized_pnl"}}})
        self.assertEqual(fieldmap.override("position", "profit", "simulated"), "unrealized_pnl")      # có hiệu lực ngay trong tiến trình UI
        self.assertEqual(app.settings_tab.gform.ctrl["field_overrides"].text, app.settings["field_overrides"])
        T.press(root, "Hoàn tác")
        self.assertEqual(app.settings["field_overrides"], "")
        self.assertIsNone(fieldmap.override("position", "profit", "simulated"))

    def test_open_screen_switches_tab_and_closes_dialog(self):
        app, a = self.make(block(action="open_screen", screen="log"))
        root = self.dialog(app)
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.propose_refresh(app, root)
        T.press(root, "Áp dụng")
        self.assertIs(app.root_panel.current, app.tabs["log"])
        self.assertNotIn(pop, kivy_stub.OPEN_POPUPS)

    def test_selfcheck_runs_in_background_and_result_is_gated_by_share_toggle(self):
        app, a = self.make(block(action="run_selfcheck"))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        T.press(root, "Áp dụng")
        self.assertTrue(self.until(lambda: bool(getattr(app, "_last_diag", ""))))
        self.assertTrue(self.until(lambda: "không đọc được kết quả" in T.texts(root)))     # chia sẻ đang TẮT: Trợ lý không đọc
        self.assertEqual(len(self.calls), 1)                                                 # không có lượt hỏi tự động thứ hai
        self.assertIn("báo cáo kiểm tra", T.texts(root))

    def test_selfcheck_followup_when_sharing_on(self):
        app, a = self.make(lambda msgs: block(action="run_selfcheck") if len(self.calls) == 1 else "Kết quả ổn.")
        app.settings["assistant_share_state"] = True
        root = self.dialog(app)
        self.propose_refresh(app, root)
        T.press(root, "Áp dụng")
        self.assertTrue(self.until(lambda: "Kết quả ổn." in T.texts(root)))
        sysm = self.calls[-1][0]["content"]
        self.assertIn("báo cáo kiểm tra", sysm.lower() + self.calls[-1][-1]["content"].lower())
        self.assertIn("<du_lieu>", self.calls[-1][-1]["content"])

    def test_export_diag_creates_zip(self):
        app, a = self.make(block(action="export_diag"))
        root = self.dialog(app)
        self.propose_refresh(app, root)
        T.press(root, "Áp dụng")
        self.assertTrue(self.until(lambda: "Đã tạo gói chẩn đoán" in T.texts(root)))
        zips = [f for d, _s, fs in os.walk(app.data_dir) for f in fs if f.startswith("pyea-diag") and f.endswith(".zip")]
        self.assertTrue(zips)

    # ------------------------------------------------------------------------------------------------ chia sẻ trạng thái
    def test_share_toggle_persists_and_controls_context(self):
        app, a = self.make("ok")
        app.hub.agents = [dict(AGENT)]
        app.log_tab.append([(1, time.time(), "INFO", "LOGLINE-DUY-NHAT-123")])
        root = self.dialog(app)
        self.assertIn("TẮT", T.texts(root))
        self.assertTrue(self.ask(app, root, "sao lỗi"))
        self.assertNotIn("LOGLINE-DUY-NHAT-123", self.calls[-1][0]["content"])
        T.press(root, [x.text for x in T.find(root, lambda w: "Cho Trợ lý xem" in str(getattr(w, "text", "")))][0])
        self.assertTrue(app.settings["assistant_share_state"])
        self.assertTrue(app.store.load_settings()["assistant_share_state"])
        self.assertIn("BẬT", T.texts(root))
        self.assertTrue(self.ask(app, root, "sao lỗi nữa"))
        self.assertIn("LOGLINE-DUY-NHAT-123", self.calls[-1][0]["content"])

    # ------------------------------------------------------------------------------------------------ app gặp sự cố
    def test_crash_popup_offers_assistant_with_error_attached(self):
        app, a = self.make("Có vẻ là lỗi KeyError; hãy gửi Gói chẩn đoán.")
        with open(app.store.crash_path, "w", encoding="utf-8") as f:
            f.write("Traceback (most recent call last):\n  File x.py\nKeyError: 'equity'\n")
        app._after_start(0)
        crash = [p for p in kivy_stub.OPEN_POPUPS if "Lần chạy trước" in str(getattr(p, "title", ""))]
        self.assertTrue(crash)
        T.press(crash[-1].content, "Hỏi Trợ lý")
        root = kivy_stub.OPEN_POPUPS[-1].content
        self.assertTrue(self.until(lambda: "KeyError" in T.texts(root) and len(self.calls) == 1))
        last = self.calls[0][-1]["content"]
        self.assertIn("KeyError: 'equity'", last)
        self.assertIn("<du_lieu>", last)                                  # kèm trong khối dữ liệu, không phải mệnh lệnh

    def test_app_problems_text_feeds_context_only_when_shared(self):
        app, a = self.make("ok")
        with open(app.store.crash_path, "w", encoding="utf-8") as f:
            f.write("Traceback...\nZeroDivisionError: boom-xyz\n")
        app.note_ui_error("tb")
        env = a.env
        prob = env.app_problems()
        self.assertIn("boom-xyz", prob)
        self.assertIn("Dịch vụ nền đang chạy", prob)
        self.assertIn("Lỗi giao diện", prob)
        a.ask("app lỗi")
        self.assertNotIn("boom-xyz", self.calls[-1][0]["content"])
        app.settings["assistant_share_state"] = True
        a.ask("app lỗi")
        self.assertIn("boom-xyz", self.calls[-1][0]["content"])

    def test_save_forms_still_works_after_refactor(self):
        app, _ = self.make()
        app.settings_tab.gform.ctrl["ui_refresh"].text = "3"
        self.assertTrue(app.save_forms(False))
        self.assertEqual(app.settings["ui_refresh"], 3.0)
        self.assertEqual(app.store.load_settings()["ui_refresh"], 3.0)
        app.settings_tab.gform.ctrl["ui_refresh"].text = "oops"
        self.assertFalse(app.save_forms(False))

    def test_clear_conversation(self):
        app, a = self.make("xin chào")
        root = self.dialog(app)
        self.ask(app, root, "hi")
        self.assertTrue(a.history)
        T.press(root, "Xoá hội thoại")
        self.assertEqual(a.history, [])
        self.assertIn("Đã xoá hội thoại", T.texts(root))


if __name__ == "__main__":
    unittest.main()
