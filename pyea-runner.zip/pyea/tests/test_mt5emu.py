"""Logic «Kết nối MT5 nhanh» (pyea/mt5emu.py) + phần app của trình cài tự động (pyea/mt5ea.py): kiểm nhập liệu, cài đặt, startup.ini/mật khẩu, vòng đời mật khẩu,
cấp file qua GET, nhận sự kiện install, đọc tiến trình. Không cần Kivy/điện thoại; script cài được test ở tests/test_mt5_install.py."""
import base64
import os
import socket
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_ea import FakeEA                       # noqa: E402
from pyea import mt5ea, mt5emu                   # noqa: E402
from pyea.mt5ea import dec                       # noqa: E402


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait(cond, t=10.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.05)
    return cond()


def sup_exchange(port, token, *lines, until=None, timeout=5.0, settle=0.4):
    """Nói giao thức kênh giám sát như script bash: SUPHELLO rồi các dòng. until="FILE" -> đọc tới dòng bắt đầu bằng đó (hoặc khi server đóng); không có until -> chờ
    `settle` giây cho server xử lý rồi đóng. Trả về các dòng phản hồi đã đọc."""
    s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
    s.settimeout(0.2)
    s.sendall(("SUPHELLO|v=1|token=%s\n" % token).encode())
    for ln in lines:
        s.sendall((ln + "\n").encode())
    out, buf = [], b""
    end = time.time() + (timeout if until else settle)
    done = False
    while time.time() < end and not done:
        try:
            ch = s.recv(65536)
        except socket.timeout:
            continue
        except OSError:
            break
        if not ch:
            break
        buf += ch
        while b"\n" in buf:
            raw, buf = buf.split(b"\n", 1)
            out.append(raw.decode())
            if until and out[-1].startswith(until):
                done = True
    s.close()
    return out


def get_file(port, token, name):
    for ln in sup_exchange(port, token, "GET|name=" + name, until="FILE"):
        if ln.startswith("FILE"):
            typ, d = dec(ln)
            return d
    return None


class TestProblems(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(mt5emu.problems("50194988", "pw", "ICMarketsSC-Demo"), [])
        self.assertEqual(mt5emu.problems("50194988", "pw", "1.2.3.4:443", "https://b.example/x.exe"), [])

    def test_each_field(self):
        self.assertTrue(mt5emu.problems("abc", "pw", "S"))
        self.assertTrue(mt5emu.problems("123", "pw", "S"))                 # quá ngắn
        self.assertTrue(mt5emu.problems("50194988", "", "S"))
        self.assertTrue(mt5emu.problems("50194988", "a\nb", "S"))          # xuống dòng trong mật khẩu: chèn khoá .ini
        self.assertTrue(mt5emu.problems("50194988", "pw", ""))
        self.assertTrue(mt5emu.problems("50194988", "pw", "S\n[Experts]"))
        self.assertTrue(mt5emu.problems("50194988", "pw", "S", "http://insecure/x.exe"))
        self.assertTrue(mt5emu.problems("50194988", "pw", "S", "https://a b/x.exe"))

    def test_plan_keeps_good_token_and_replaces_bad(self):
        p = mt5emu.plan({"mt5ea_token": "good-token-123", "mt5ea_port": "19000"}, " 5550123 ", " Srv ")
        self.assertEqual((p["exchange"], p["mt5ea_token"], p["mt5ea_port"], p["mt5ea_login"], p["mt5ea_server"], p["mt5ea_supervised"]),
                         ("mt5ea", "good-token-123", "19000", "5550123", "Srv", "yes"))
        bad = mt5emu.plan({"mt5ea_token": "has space|x"}, "5550123", "S")
        self.assertRegex(bad["mt5ea_token"], r"^[0-9a-f]{24}$")
        self.assertEqual(mt5emu.plan({}, "5550123", "S")["mt5ea_port"], str(mt5ea.DEFAULT_PORT))
        self.assertEqual(mt5ea.problems(dict(mt5emu.plan({}, "5550123", "S")), require=True), [])

    def test_bootstrap_rejects_unsafe_token(self):
        for tok in ("a'b;rm -rf ~", "short", "has space 1234"):
            with self.assertRaises(ValueError):
                mt5emu.bootstrap_command(18765, tok)
        c = mt5emu.bootstrap_command(18765, "abcdefgh1234")
        self.assertIn("18765", c)
        self.assertNotIn("\n", c)


class TestStartupIni(unittest.TestCase):
    S = {"mt5ea_login": "5550123", "mt5ea_server": "Demo-1", "mt5ea_symbol": "XAUUSD"}

    def test_with_and_without_password(self):
        a = mt5ea.make_startup_ini(self.S)
        self.assertNotIn("Password", a)
        self.assertIn("KeepPrivate=1", a)
        b = mt5ea.make_startup_ini(self.S, "pw#1")
        self.assertIn("Login=5550123\nPassword=pw#1\nServer=Demo-1\n", b)
        for w in ("Expert=PyEABridge", "Symbol=XAUUSD", "ExpertParameters=bridge.set"):
            self.assertIn(w, b)

    def test_injection_refused(self):
        with self.assertRaises(mt5ea.BridgeError):
            mt5ea.make_startup_ini(self.S, "x\n[Experts]\nAllowLiveTrading=1")
        with self.assertRaises(mt5ea.BridgeError):
            mt5ea.make_startup_ini(dict(self.S, mt5ea_server="S\r\nPassword=evil"))


class TestServerSide(unittest.TestCase):
    def setUp(self):
        self.s = {"mt5ea_port": str(free_port())}
        self.upd, self.srv, self.cmd = mt5emu.prepare(self.s, "5550123", "Pw!1", "Demo-1")
        self.port, self.tok = self.srv.port, self.upd["mt5ea_token"]
        self.ea = None

    def tearDown(self):
        if self.ea:
            self.ea.close()
        self.srv.close()
        mt5ea._SERVERS.pop(self.port, None)

    def test_files_served_with_first_login_password(self):
        d = get_file(self.port, self.tok, "startup.ini")
        text = base64.b64decode(d["b64"]).decode()
        self.assertIn("Password=Pw!1", text)
        self.assertIn("Login=5550123", text)
        for n in ("install_mt5_termux.sh", "run_mt5_termux.sh", "PyEABridge.mq5", "bridge.set"):
            f = get_file(self.port, self.tok, n)
            self.assertIsNotNone(f, n)
            self.assertTrue(base64.b64decode(f["b64"]), n)
        self.assertEqual(base64.b64decode(get_file(self.port, self.tok, "install_mt5_termux.sh")["b64"]).decode(), mt5ea.script_source("install_mt5_termux.sh"))

    def test_unknown_file_and_wrong_token(self):
        d = get_file(self.port, self.tok, "../../etc/passwd")
        self.assertTrue(d is None or d.get("err"))
        self.assertIsNone(get_file(self.port, "wrong-token-0000", "startup.ini"))

    def test_password_forgotten_when_ea_connects_with_account(self):
        self.assertEqual(self.srv.first_login_password(), "Pw!1")
        self.ea = FakeEA(self.port, token=self.tok).start()                # HELLO login=123
        self.assertTrue(wait(lambda: self.srv.connected))
        self.assertTrue(wait(lambda: self.srv.first_login_password() is None))
        text = base64.b64decode(get_file(self.port, self.tok, "startup.ini")["b64"]).decode()
        self.assertNotIn("Password", text)
        self.assertIn("Login=5550123", text)                               # vẫn cấp phần còn lại
        self.assertTrue(any("xoá mật khẩu" in d[3] for d in self.srv.diag))

    def test_password_kept_when_ea_has_no_account_yet(self):
        class NoLogin(FakeEA):
            pass
        ea = NoLogin(self.port, token=self.tok)
        import pyea.mt5ea as m
        orig = ea._run

        def run():                                                          # EA đã gắn vào biểu đồ nhưng MT5 chưa đăng nhập: login=0
            import socket as so
            s = so.create_connection(("127.0.0.1", self.port), timeout=5)
            ea.sock = s
            ea.send("HELLO", v=1, token=self.tok, login="0", server="", company="", build=1, ea="1", hedging=1, demo=1)
            while not ea.stop.is_set():
                time.sleep(0.1)
        ea._run = run
        self.ea = ea.start()
        self.assertTrue(wait(lambda: self.srv.connected))
        time.sleep(0.5)
        self.assertEqual(self.srv.first_login_password(), "Pw!1")
        self.assertFalse(mt5emu.progress(self.srv)["connected"])           # login=0 thì chưa tính là đã nối tài khoản
        del m, orig

    def test_password_expires(self):
        old = mt5ea.PW_TTL_S
        mt5ea.PW_TTL_S = 0.2
        try:
            self.srv.set_first_login_password("tmp")
            self.assertEqual(self.srv.first_login_password(), "tmp")
            time.sleep(0.4)
            self.assertIsNone(self.srv.first_login_password())
        finally:
            mt5ea.PW_TTL_S = old

    def test_provision_function_error_reported_not_crash(self):
        self.srv.provision["startup.ini"] = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        d = get_file(self.port, self.tok, "startup.ini")
        self.assertIn("boom", d.get("err", ""))
        self.assertIsNotNone(get_file(self.port, self.tok, "bridge.set"))     # máy chủ vẫn sống

    def test_install_events_and_progress(self):
        srv = self.srv
        p = mt5emu.progress(srv)
        self.assertFalse(p["started"])
        self.assertEqual(mt5emu.headline(p)[1], "wait")
        self.assertIn("Chưa thấy Termux", mt5emu.headline(p)[0])
        sup_exchange(self.port, self.tok, "SEVT|kind=install|stage=precheck|state=start|detail=x", "SEVT|kind=install|stage=precheck|state=ok|detail=x",
                     "SEVT|kind=install|stage=wine|state=progress|detail=%C4%91ang t%E1%BA%A3i")
        self.assertTrue(wait(lambda: "wine" in srv.install))
        p = mt5emu.progress(srv)
        st = {sid: s for sid, _, s, _ in p["rows"]}
        self.assertEqual((st["precheck"], st["wine"], st["mt5"]), ("ok", "run", "todo"))
        self.assertTrue(p["started"] and 0 < p["pct"] < 100)
        self.assertIn("Đang cài", mt5emu.headline(p)[0])
        txt = mt5emu.render(p)
        self.assertIn("✓ Kiểm tra máy", txt)
        self.assertIn("▶ Tải Wine", txt)
        # lỗi -> báo động + tiêu đề lỗi
        sup_exchange(self.port, self.tok, "SEVT|kind=install|stage=wine|state=fail|detail=Kh%C3%B4ng t%E1%BA%A3i %C4%91%C6%B0%E1%BB%A3c Wine")
        self.assertTrue(wait(lambda: srv.install["wine"]["state"] == "fail"))
        p = mt5emu.progress(srv)
        self.assertEqual(p["failed"][0][0], "wine")
        self.assertEqual(mt5emu.headline(p)[1], "fail")
        self.assertTrue(any(a["kind"] == "install_fail" and "Tải Wine" in a["title"] for a in srv.alerts))
        # sự kiện lạ không làm hỏng
        sup_exchange(self.port, self.tok, "SEVT|kind=install|stage=khong_co|state=ok")
        mt5emu.progress(srv)

    def test_done_only_when_ea_connected_with_account(self):
        srv = self.srv
        sup_exchange(self.port, self.tok, "SEVT|kind=install|stage=login|state=ok|detail=authorized")
        self.assertTrue(wait(lambda: srv.install.get("login", {}).get("state") == "ok"))
        p = mt5emu.progress(srv)
        self.assertTrue(p["done"] and p["log_ok"])
        self.assertFalse(p["connected"])
        self.assertIn("đợi EA nối", mt5emu.headline(p)[0])
        self.ea = FakeEA(self.port, token=self.tok).start()
        self.assertTrue(wait(lambda: mt5emu.progress(srv)["connected"]))
        p = mt5emu.progress(srv)
        self.assertEqual(p["login"], 123)
        self.assertIn("ĐÃ NỐI", mt5emu.headline(p)[0])
        self.assertNotIn("đường tệp", mt5emu.headline(p)[0])
        self.assertIn("đường tệp", mt5emu.headline(dict(p, link="file"))[0])      # EA nối qua relay tệp (MT5 chặn socket): app nói rõ

    def test_prepare_resets_state_and_is_repeatable(self):
        sup_exchange(self.port, self.tok, "SEVT|kind=install|stage=wine|state=fail|detail=x")
        self.assertTrue(wait(lambda: "wine" in self.srv.install))
        upd2, srv2, _ = mt5emu.prepare(dict(self.s, mt5ea_token=self.tok), "5550123", "NewPw", "Demo-1")
        self.assertIs(srv2, self.srv)                                       # cùng cổng + token: dùng lại máy chủ
        self.assertEqual(srv2.install, {})
        self.assertEqual(srv2.first_login_password(), "NewPw")

    def test_prepare_validation_error_leaves_no_password(self):
        with self.assertRaises(ValueError):
            mt5emu.prepare(dict(self.s, mt5ea_token=self.tok), "abc", "x", "S")
        self.assertEqual(self.srv.first_login_password(), "Pw!1")          # lần chuẩn bị hỏng không đụng trạng thái cũ


class TestSettingsIntegration(unittest.TestCase):
    def test_make_backend_still_serves_all_files(self):
        port = free_port()
        s = {"mt5ea_token": "good-token-123", "mt5ea_port": str(port), "mt5ea_login": "5550123", "mt5ea_server": "Demo-1"}
        be = mt5ea.make_backend(s)
        try:
            for n in ("PyEABridge.mq5", "bridge.set", "startup.ini", "install_mt5_termux.sh", "run_mt5_termux.sh"):
                self.assertIsNotNone(get_file(port, "good-token-123", n), n)
        finally:
            be.close() if hasattr(be, "close") else None
            srv = mt5ea._SERVERS.pop(port, None)
            if srv:
                srv.close()

    def test_ensure_server_rejects_bad_settings(self):
        with self.assertRaises(mt5ea.BridgeError):
            mt5ea.ensure_server({"mt5ea_token": "x"})


if __name__ == "__main__":
    unittest.main()
