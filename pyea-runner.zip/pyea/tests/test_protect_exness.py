"""SL/TP NATIVE cho Exness - phần RIÊNG của Exness (các kịch bản chung nằm ở test_protect_contract.py, harness ExnH).

Đã đối chiếu tài liệu chính thức (exness-api.com, đọc 30/10/2026): loại lệnh `sltp` («đặt SL/TP cho một vị thế bằng lệnh SLTP mới»), trường `stop_loss_price`/`take_profit_price`,
PATCH /orders/{id} (bỏ khoá = giữ nguyên, null = gỡ mức), DELETE /orders/{id} (huỷ lệnh chờ hoặc SLTP), tài khoản close_only vẫn cho lệnh SLTP, ACK bất đồng bộ.
KHÔNG đọc được: tên trường mã vị thế khi TẠO lệnh SLTP -> adapter thử vài dạng và nhớ dạng chạy được; các test dưới đây kiểm cơ chế dò đó bằng sàn giả
có thể «đọc» các tên khác nhau."""
import json
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import test_protect_contract as tc                          # noqa: E402
from pyea.exness import ExnBroker                            # noqa: E402

h = None


def setUpModule():
    global h
    if not tc.HAVE_CRYPTO:
        raise unittest.SkipTest("cần cryptography")
    h = tc.ExnH()


def tearDownModule():
    if h is not None:
        h.close()


class Base(unittest.TestCase):
    def setUp(self):
        h.reset()
        self.tmp = tempfile.mkdtemp()
        self.s = h.session(self.tmp)
        h.tick(self.s, h.P0)
        self.f = h.fake

    def open(self, vol=0.06, sl=1.0900, tp=1.1200, side="buy"):
        r = self.s.send_order(h.SYM, side, vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position

    def poll(self, s=None):
        s = s or self.s
        s._prot_next = 0.0
        s._check_protection()

    def posts(self):
        return [r for r in self.f.requests if r["method"] == "POST" and r["path"].endswith("/orders")]

    def bodies(self):
        return [json.loads(r["body"]) for r in self.posts()]


class TestIdentity(Base):
    def test_market_order_returns_the_position_id_and_order_id(self):
        fill = self.s.broker.market_order(h.SYM, "buy", 0.05)
        self.assertTrue(fill.ref in self.f.positions)
        self.assertTrue(fill.order_id)
        self.s.broker.close_market(h.SYM, "buy", 0.05, ref=fill.ref)

    def test_virtual_positions_carry_ticket_and_close_exactly_that_one(self):
        a, b = self.open(0.06, 0, 0), self.open(0.04, 0, 0)
        self.assertTrue(a.ref and b.ref and a.ref != b.ref)
        self.assertEqual(set(self.f.positions), {a.ref, b.ref})
        r = self.s.close_position(b.id)                              # đóng vị thế MỚI: cũ nhất-trước sẽ đóng nhầm A
        self.assertTrue(r, r.message)
        self.assertEqual(set(self.f.positions), {a.ref})
        self.assertEqual(self.f.positions[a.ref]["volume"], 0.06)

    def test_close_by_ref_refuses_when_the_ticket_is_gone_instead_of_closing_another(self):
        a, b = self.open(0.06, 0, 0), self.open(0.06, 0, 0)
        del self.f.positions[a.ref]                                  # A vừa bị SL/đóng tay trên sàn
        before = dict(self.f.positions)
        r = self.s.close_position(a.id)
        self.assertFalse(r)
        self.assertEqual(set(self.f.positions), set(before))         # B nguyên vẹn
        self.assertIn(b.id, self.s.account.positions)

    def test_close_orders_are_booked_so_reconcile_does_not_count_them_twice(self):
        a = self.open(0.06, 0, 0)
        self.s.close_position(a.id)
        deal_orders = {d["order_id"] for d in self.f.deals}
        self.assertTrue(deal_orders & set(self.s._booked), "mã lệnh của lần đóng/mở phải được ghi sổ")


class TestLevelsFromSnapshot(Base):
    def test_levels_on_the_position_itself_are_read_when_there_is_no_sltp_order(self):
        """Nếu snapshot ghi SL/TP thẳng lên vị thế (không có lệnh SLTP riêng) thì vỏ đọc đúng và KHÔNG ghi lại cho khớp."""
        self.f.sltp_model = "position"
        p = self.open()
        self.poll()
        n = len(self.f.requests)
        with self.f.lock:
            for k in [k for k, o in self.f.orders.items() if o.get("type") == "sltp"]:
                del self.f.orders[k]                                  # chỉ còn mức nằm trên vị thế
        rows = self.s.broker.position_levels(h.SYM)
        self.assertEqual([(r["ref"], r["sl"], r["tp"]) for r in rows], [(p.ref, 1.09, 1.12)])
        self.assertEqual(self.s.broker.hedged_positions()[0]["sl"], 1.09)
        self.assertGreaterEqual(len(self.f.requests), n)

    def test_sltp_orders_are_not_listed_as_pending_orders(self):
        self.open()
        self.poll()
        self.assertEqual(self.s.broker.pending_orders(), {})
        self.assertTrue(any(o.get("type") == "sltp" for o in self.f.orders.values()))


class TestCreateShapeDiscovery(Base):
    def test_unknown_key_name_is_discovered_and_remembered(self):
        self.f.sltp_key = "position"                                  # máy chủ chỉ đọc «position», không phải «position_id»
        a = self.open()
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))
        self.assertEqual(len(self.f.sltp_created), 1)
        self.assertIn("position", self.f.sltp_created[0])
        first_try = len(self.posts())
        self.assertEqual(first_try, 2)                                # dạng đầu bị 400, dạng thứ hai được nhận
        b = self.open(0.04, 1.0800, 1.1300)
        self.poll()
        self.assertEqual(len(self.posts()), first_try + 1)            # NHỚ dạng chạy được: lần sau đúng ngay, không dò lại
        self.assertTrue(self.s.prot_covered(b.id, "sl"))

    def test_server_that_wants_instrument_side_volume_too(self):
        self.f.sltp_needs_instrument = True
        a = self.open()
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))
        body = self.f.sltp_created[0]
        self.assertEqual((body["instrument"], body["side"], body["volume"]), (h.SYM, "buy", "0.06"))
        self.assertEqual(body["stop_loss_price"], "1.09")

    def test_every_shape_rejected_means_the_shell_keeps_guarding_and_backs_off(self):
        self.f.sltp_key = "mystery_field"
        a = self.open()
        self.poll()
        self.assertFalse(self.s.prot_covered(a.id, "sl"))
        self.assertFalse(self.s.prot_covered(a.id, "tp"))
        self.assertIn(a.id, self.s.account.positions)                 # vị thế không bị đụng
        n = len(self.posts())
        self.assertGreaterEqual(n, 4)                                  # đã thử mọi dạng
        self.poll()
        self.poll()
        self.assertEqual(len(self.posts()), n)                         # nghỉ SLTP_RETRY_S: không dội lỗi lên sàn mỗi vòng
        warn = [m for _, _, lv, m in self.s.logs if lv == "WARN" and "SLTP" in m]
        self.assertTrue(warn, "phải cảnh báo rõ lý do")
        self.assertIn("mọi dạng", " ".join(warn))
        # app vẫn tự canh SL: giá xuống chạm SL thì vỏ đóng
        h.tick(self.s, 1.0890, t=2000.0)
        self.assertNotIn(a.id, self.s.account.positions)

    def test_business_rejection_is_not_mistaken_for_a_wrong_shape(self):
        """SL sai phía giá bị từ chối vì LUẬT GIÁ (lỗi nghiệp vụ): chỉ MỘT lần gửi, không dò tên trường khác."""
        a = self.open(0.06, 1.0900, 1.1200)
        self.f.reject_next = ("TRADING_RULE_INVALID_PRICE_LEVELS", "SL/TP sai mức")
        self.poll()
        self.assertEqual(len(self.posts()), 1)                         # đúng MỘT lần gửi, không dò tên trường khác
        self.assertFalse(self.s.prot_covered(a.id, "sl"))
        self.assertTrue(any("SL/TP sai mức" in m or "INVALID_PRICE_LEVELS" in m for _, _, lv, m in self.s.logs if lv == "WARN"))


class TestEditing(Base):
    def test_changing_a_level_patches_the_existing_sltp_order_with_both_fields(self):
        a = self.open()
        self.poll()
        n = len(self.posts())
        self.s.modify_position(a.id, sl=1.0950)
        self.poll()
        self.assertEqual(len(self.posts()), n)                         # không tạo lệnh SLTP thứ hai
        patch = [r for r in self.f.requests if r["method"] == "PATCH"]
        self.assertEqual(len(patch), 1)
        self.assertEqual(json.loads(patch[0]["body"]), {"stop_loss_price": "1.095", "take_profit_price": "1.12"})

    def test_removing_one_level_sends_null_for_it(self):
        a = self.open()
        self.poll()
        self.s.modify_position(a.id, tp=0)
        self.poll()
        patch = [r for r in self.f.requests if r["method"] == "PATCH"]
        self.assertEqual(json.loads(patch[-1]["body"]), {"stop_loss_price": "1.09", "take_profit_price": None})

    def test_removing_both_levels_deletes_the_sltp_order(self):
        a = self.open()
        self.poll()
        self.s.modify_position(a.id, sl=0, tp=0)
        self.poll()
        self.assertEqual([o for o in self.f.orders.values() if o.get("type") == "sltp"], [])
        self.assertTrue(any(r["method"] == "DELETE" and "/orders/" in r["path"] for r in self.f.requests))

    def test_close_only_account_still_accepts_sltp(self):
        """Tài liệu: tài khoản close_only chặn lệnh mới NGOẠI TRỪ lệnh SLTP."""
        a = self.open()
        self.f.account_status = "close_only"
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))


class TestOwnership(Base):
    def test_a_position_the_user_opened_by_hand_is_never_modified(self):
        keep = h.foreign()
        a = self.open()
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))
        self.assertTrue(keep())

    def test_after_restart_the_tickets_of_the_app_are_still_recognised(self):
        """Khởi động lại: vỏ dựng lại broker mới (không nhớ gì). Ticket đã gắn SL/TP trước đó vẫn của app -> bỏ SL trong sổ thì sàn cũng gỡ."""
        a = self.open()
        self.poll()
        s2 = h.session(self.tmp)
        s2.account.restore(self.s.account.to_dict())
        s2._prot_live = json.loads(json.dumps(self.s._prot_live))
        h.tick(s2, h.P0)
        s2.modify_position(a.id, sl=0, tp=0)
        self.poll(s2)
        self.assertEqual([o for o in self.f.orders.values() if o.get("type") == "sltp"], [])

    def test_adopted_positions_are_not_touched_even_when_they_carry_levels(self):
        """Vị thế nhận từ sàn khi đối soát (adopted) không tự động bị gắn/sửa SL-TP gốc trên sàn."""
        with self.f.lock:
            pid = self.f._open(h.SYM, "buy", 0.05, 1.1002)
            self.f.orders["X1"] = {"type": "sltp", "instrument": h.SYM, "side": "buy", "volume": 0.05, "price": 0.0, "sl": 1.0500, "tp": None, "position_id": pid}
        import pyea.reconcile as rc
        old, rc.CONFIRM_S = rc.CONFIRM_S, 0.0
        try:
            self.s.reconcile_now()
            for k in list(self.s._recon_pending):
                self.s._recon_pending[k] -= 60.0
            self.s.reconcile_now()
        finally:
            rc.CONFIRM_S = old
        pos = [p for p in self.s.account.positions.values() if p.ref == pid]
        self.assertEqual(len(pos), 1)
        self.assertTrue(pos[0].adopted)
        self.assertEqual((pos[0].sl, pos[0].tp), (1.05, 0.0))        # nhận cả SL của sàn
        self.poll()
        self.assertEqual(self.f.orders["X1"]["sl"], 1.05)
        self.assertEqual([r for r in self.f.requests if r["method"] in ("PATCH", "DELETE")], [])


class TestAfterTheFact(Base):
    def test_fill_is_booked_at_the_real_exit_price_from_the_position_deal(self):
        a = self.open()
        self.poll()
        h.fire("sl", 1.0900)
        self.poll()
        self.assertNotIn(a.id, self.s.account.positions)
        self.assertAlmostEqual(self.s.account.trades[-1].close_price, 1.0900, 6)
        self.assertEqual(self.s.account.trades[-1].reason, "Stop Loss")


if __name__ == "__main__":
    unittest.main()
