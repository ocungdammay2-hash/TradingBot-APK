"""«Không làm phiền» (DND): tạm hoãn N giờ + khung yên tĩnh hằng ngày; chỉ tắt ÂM/RUNG, không nuốt cảnh báo, sự cố nghiêm trọng vẫn kêu."""
import json
import os
import sys
import tempfile
import time
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

from pyea import android_native, dnd                                              # noqa: E402
from pyea.backtest import _ReplayFeed                                             # noqa: E402
from pyea.engine import Account, TradingSession                                   # noqa: E402
from pyea.settings import default_settings                                        # noqa: E402
from test_shell_gaps import tk                                                    # noqa: E402


def local(y, mo, d, h, mi, s=0):
    return time.mktime((y, mo, d, h, mi, s, 0, 0, -1))


NOON = local(2026, 10, 27, 12, 0)


class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.path = os.path.join(self.d, dnd.FILE)
        dnd.configure(self.path)
        dnd.apply({})

    def tearDown(self):
        dnd.configure(None)
        dnd.apply({})


class TestParse(unittest.TestCase):
    def test_hhmm(self):
        self.assertEqual(dnd.parse_hhmm("22:30"), 1350)
        self.assertEqual(dnd.parse_hhmm(" 07:05 "), 425)
        self.assertEqual(dnd.parse_hhmm("00:00"), 0)
        for bad in ("", None, "24:00", "12:60", "10pm", "7", "12:30:00", "ab:cd", "-1:10"):
            self.assertIsNone(dnd.parse_hhmm(bad), bad)

    def test_problems(self):
        self.assertEqual(dnd.problems({}), [])
        self.assertEqual(dnd.problems({"dnd_from": "22:00", "dnd_to": "07:00"}), [])
        self.assertEqual(len(dnd.problems({"dnd_from": "22:00"})), 1)                      # thiếu «đến»
        self.assertEqual(len(dnd.problems({"dnd_to": "07:00"})), 1)
        self.assertTrue(any("10pm" in p for p in dnd.problems({"dnd_from": "10pm", "dnd_to": "07:00"})))
        self.assertEqual(len(dnd.problems({"dnd_from": "08:00", "dnd_to": "08:00"})), 1)   # khung rỗng


class TestSnooze(Base):
    def test_active_until_expiry_and_remaining(self):
        until = dnd.snooze(2, now=NOON)
        self.assertAlmostEqual(until, NOON + 7200)
        self.assertTrue(dnd.active(NOON + 7199))
        self.assertAlmostEqual(dnd.remaining(NOON + 3600), 3600.0)
        self.assertFalse(dnd.active(NOON + 7201))                       # hết hạn tự tắt, không ai phải nhớ tắt
        self.assertEqual(dnd.remaining(NOON + 7201), 0.0)

    def test_state_is_shared_between_processes_through_the_file(self):
        dnd.snooze(1, now=NOON)
        dnd.configure(self.path)                                        # «tiến trình khác»: bộ nhớ trống, chỉ có file
        self.assertTrue(dnd.active(NOON + 60))
        with open(self.path, "w", encoding="utf-8") as f:               # bên kia bấm «Tắt» (ghi file) -> bên này thấy ngay, không cần khởi động lại
            json.dump({"until": 0.0}, f)
        self.assertFalse(dnd.active(NOON + 60))
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"until": NOON + 5000.0}, f)
        self.assertTrue(dnd.active(NOON + 60))

    def test_cancel_and_non_positive_hours(self):
        dnd.snooze(5, now=NOON)
        self.assertEqual(dnd.snooze(0), 0.0)
        self.assertFalse(dnd.active(NOON + 1))
        dnd.snooze(5, now=NOON)
        dnd.snooze(-3)
        self.assertFalse(dnd.active(NOON + 1))
        dnd.snooze(5, now=NOON)
        dnd.cancel()
        self.assertFalse(dnd.active(NOON + 1))

    def test_clamped_to_72_hours_and_bad_numbers_refused(self):
        until = dnd.snooze(10_000, now=NOON)
        self.assertAlmostEqual(until - NOON, 72 * 3600)
        for bad in (float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                dnd.snooze(bad)
        self.assertTrue(dnd.active(NOON + 60))                          # lệnh sai không làm mất trạng thái đang có

    def test_garbage_file_never_raises_and_means_off(self):
        for content in ("không phải json", "[1, 2]", '{"until": "abc"}', '{"until": NaN}', "", '{"until": null}'):
            with open(self.path, "w", encoding="utf-8") as f:
                f.write(content)
            dnd.configure(self.path)
            self.assertFalse(dnd.active(NOON), content)

    def test_without_a_file_path_state_lives_in_memory(self):
        dnd.configure(None)
        dnd.snooze(1, now=NOON)
        self.assertTrue(dnd.active(NOON + 10))
        dnd.cancel()
        self.assertFalse(dnd.active(NOON + 10))

    def test_unwritable_path_still_honoured_by_this_process(self):
        dnd.configure(os.path.join(self.d, "khong", "co", "thu_muc", dnd.FILE))
        dnd.snooze(1, now=NOON)
        self.assertTrue(dnd.active(NOON + 10))


class TestQuietWindow(Base):
    def test_overnight_window_crosses_midnight(self):
        dnd.apply({"dnd_from": "22:00", "dnd_to": "07:00"})
        self.assertFalse(dnd.active(local(2026, 10, 27, 21, 59, 59)))
        self.assertTrue(dnd.active(local(2026, 10, 27, 22, 0, 0)))                    # bao gồm đầu khung
        self.assertAlmostEqual(dnd.remaining(local(2026, 10, 27, 23, 30)), 7.5 * 3600, delta=1)
        self.assertAlmostEqual(dnd.remaining(local(2026, 10, 28, 3, 0)), 4 * 3600, delta=1)
        self.assertFalse(dnd.active(local(2026, 10, 28, 7, 0, 0)))                    # loại trừ cuối khung
        self.assertFalse(dnd.active(local(2026, 10, 28, 12, 0)))

    def test_same_day_window(self):
        dnd.apply({"dnd_from": "09:00", "dnd_to": "17:00"})
        self.assertFalse(dnd.active(local(2026, 10, 27, 8, 59)))
        self.assertTrue(dnd.active(local(2026, 10, 27, 9, 0)))
        self.assertAlmostEqual(dnd.remaining(local(2026, 10, 27, 15, 0)), 2 * 3600, delta=1)
        self.assertFalse(dnd.active(local(2026, 10, 27, 17, 0)))

    def test_incomplete_or_empty_window_is_off(self):
        for st in ({"dnd_from": "22:00"}, {"dnd_to": "07:00"}, {"dnd_from": "08:00", "dnd_to": "08:00"}, {"dnd_from": "abc", "dnd_to": "07:00"}):
            dnd.apply(st)
            self.assertFalse(dnd.active(local(2026, 10, 27, 23, 0)), st)

    def test_snooze_and_window_take_the_longer_end(self):
        dnd.apply({"dnd_from": "22:00", "dnd_to": "07:00"})
        n = local(2026, 10, 27, 23, 0)
        dnd.snooze(10, now=n)                                           # snooze dài hơn phần còn lại của khung (8h)
        self.assertAlmostEqual(dnd.remaining(n), 10 * 3600, delta=1)


class TestMutedPolicy(Base):
    def test_critical_alarms_pass_by_default(self):
        dnd.snooze(1, now=NOON)
        self.assertFalse(dnd.muted(True, NOON + 1))                     # kill switch, margin call... vẫn kêu
        self.assertTrue(dnd.muted(False, NOON + 1))
        self.assertTrue(dnd.muted(False, NOON + 3000))

    def test_user_can_choose_total_silence_explicitly(self):
        dnd.apply({"dnd_critical_pass": False})
        dnd.snooze(1, now=NOON)
        self.assertTrue(dnd.muted(True, NOON + 1))
        self.assertIn("TẮT CẢ", dnd.describe(NOON + 1))

    def test_nothing_is_muted_when_dnd_is_off(self):
        self.assertFalse(dnd.muted(False))
        self.assertFalse(dnd.muted(True))

    def test_describe(self):
        self.assertIn("tắt", dnd.describe(NOON))
        dnd.snooze(2.5, now=NOON)
        t = dnd.describe(NOON)
        self.assertIn("đến %s" % time.strftime("%H:%M", time.localtime(NOON + 9000)), t)
        self.assertIn("còn 2g30p", t)
        self.assertIn("nghiêm trọng vẫn kêu", t)
        dnd.apply({"dnd_from": "22:00", "dnd_to": "07:00"})
        dnd.cancel()
        self.assertIn("22:00–07:00", dnd.describe(NOON))


# =========================================================================== nối vào engine
class TestEngineAlarm(Base):
    def session(self, cb):
        st = dict(default_settings(), mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0,
                  spread_pct=0.0, max_loss_pct=0.0)
        s = TradingSession(st, sync=True, feed=_ReplayFeed(), alerts_file=os.path.join(self.d, "a.json"), alarm_cb=cb)
        s.events = deque(maxlen=1000)
        s.account = Account(10000.0, 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        return s

    def test_default_is_critical_and_routine_is_quiet_during_dnd(self):
        got = []
        s = self.session(lambda t, x, quiet=False: got.append((t, quiet)))
        dnd.snooze(1)
        s.alarm("Sự cố", "gì đó")                                       # không nói gì = nghiêm trọng (an toàn khi quên phân loại)
        s.alarm("Thông tin", "thường", critical=False)
        self.assertEqual(got, [("Sự cố", False), ("Thông tin", True)])

    def test_everything_is_loud_when_dnd_is_off(self):
        got = []
        s = self.session(lambda t, x, quiet=False: got.append((t, quiet)))
        s.alarm("a", "x", critical=False)
        s.alarm("b", "x")
        self.assertEqual(got, [("a", False), ("b", False)])

    def test_legacy_two_arg_callback_is_never_called_loudly_during_dnd(self):
        got = []
        s = self.session(lambda t, x: got.append(t))
        s.alarm("sự cố", "x")                                           # nghiêm trọng -> gọi bình thường
        dnd.snooze(1)
        s.alarm("thường", "x", critical=False)                          # callback cũ không hiểu quiet -> thà im còn hơn kêu giữa DND
        self.assertEqual(got, ["sự cố"])

    def test_alarm_is_always_logged_even_when_muted(self):
        s = self.session(lambda t, x, quiet=False: None)
        dnd.snooze(1)
        s.alarm("Cảnh báo giá X", "đã chạm", critical=False)
        self.assertTrue(any("Cảnh báo giá X" in m for _, _, _, m in s.logs))

    def test_real_sources_are_classified(self):
        got = []
        s = self.session(lambda t, x, quiet=False: got.append((t, quiet)))
        dnd.snooze(1)
        s.alert_add("BTCUSD", "above", 105.0)
        tk(s, "BTCUSD", 100.0, t=1000.0)
        tk(s, "BTCUSD", 106.0, t=1001.0)                                # cảnh báo giá: thường -> im lặng
        s.kill_switch("thử")                                            # kill switch: nghiêm trọng -> vẫn kêu
        self.assertEqual([q for t, q in got if t.startswith("Cảnh báo giá")], [True], got)
        self.assertEqual([q for t, q in got if t.startswith("KILL SWITCH")], [False], got)


# =========================================================================== thông báo Android + dịch vụ nền
class TestDelivery(unittest.TestCase):
    def test_channel_selection(self):
        self.assertEqual(android_native.alarm_channel_id(True, True)[0], android_native.CH_ALARM)          # hành vi cũ giữ nguyên
        self.assertEqual(android_native.alarm_channel_id(True, False)[0], "pyea_alarm_sx")
        cid, label = android_native.alarm_channel_id(True, True, quiet=True)
        self.assertEqual(cid, android_native.CH_ALARM_DND)
        self.assertNotEqual(cid, android_native.CH_ALARM)                                                  # kênh riêng: người dùng chỉnh được ở cài đặt Android
        self.assertIn("không làm phiền", label)
        self.assertEqual(android_native.alarm_channel_id(False, False, quiet=True)[0], android_native.CH_ALARM_DND)

    def test_notify_alarm_accepts_quiet_off_android(self):
        self.assertFalse(android_native.notify_alarm("t", "x", quiet=True))

    def test_service_records_quiet_alarms_and_passes_the_flag_on(self):
        from pyea import ipc

        class RT:
            id, name = "main", "chính"

        class Host:
            alarms = []
            sent = []

            def alarm_fn(self, *a, **kw):
                self.sent.append((a, kw))
        h = Host()
        ipc.ServiceHost._alarm_for(h, RT, "Giá", "chạm", quiet=True)
        ipc.ServiceHost._alarm_for(h, RT, "Lỗi", "sập")
        self.assertEqual([a["quiet"] for a in h.alarms], [True, False])                                   # UI dựa vào cờ này để không bật popup
        self.assertEqual(h.sent, [(("Giá", "chạm"), {"quiet": True}), (("Lỗi", "sập"), {})])


# =========================================================================== giao diện
class TestUI(Base):
    def setUp(self):
        super().setUp()
        import test_ui_smoke as sm
        self.sm = sm
        kivy_stub.OPEN_POPUPS.clear()
        self.app = sm.make_app()
        dnd.configure(self.path)                                        # build() đã trỏ vào thư mục tạm của app: dùng file của test

    def test_buttons_set_and_clear_snooze_and_label_follows(self):
        tab = self.app.settings_tab
        self.sm.press(tab, "4 giờ")
        self.assertTrue(dnd.active())
        self.assertAlmostEqual(dnd.remaining(), 4 * 3600, delta=5)
        self.assertIn("Đang không làm phiền", tab.dnd_lbl.text)
        self.sm.press(tab, "Tắt")
        self.assertFalse(dnd.active())
        self.assertIn("tắt", tab.dnd_lbl.text)

    def test_saving_a_bad_quiet_window_is_refused_not_silently_ignored(self):
        g = self.app.settings_tab.gform.ctrl
        g["dnd_from"].text = "10pm"
        g["dnd_to"].text = "07:00"
        n0 = len(kivy_stub.OPEN_POPUPS)
        self.assertFalse(self.app.save_forms())
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)                                              # đúng một popup báo lỗi mới
        self.assertIn("10pm", self.sm.texts(kivy_stub.OPEN_POPUPS[-1].content))
        g["dnd_from"].text = "22:00"
        self.assertTrue(self.app.save_forms())
        self.assertTrue(dnd.active(local(2026, 10, 27, 23, 0)))                                           # lưu xong là áp dụng ngay

    def test_quiet_alarm_from_the_service_logs_but_does_not_pop_up(self):
        class H:
            expect_running = False

            def failed_to_start(self):
                return False

            def crashed(self):
                return False

            def alarms(self):
                return [{"t": time.time() + 1, "title": "Cảnh báo giá X", "text": "chạm", "quiet": True},
                        {"t": time.time() + 2, "title": "Bot lỗi", "text": "sập", "quiet": False}]
        n0 = len(kivy_stub.OPEN_POPUPS)
        self.app._alarm_seen = 0.0
        self.app._service_watch(H())
        shown = kivy_stub.OPEN_POPUPS[n0:]
        self.assertEqual(len(shown), 1)                                                                   # chỉ cảnh báo nghiêm trọng bật popup


if __name__ == "__main__":
    unittest.main()
