"""Capital.com: máy chủ GIẢ viết theo tài liệu open-api.capital.com (đường dẫn, header CST/X-SECURITY-TOKEN, dealReference/confirms...).
Chỉ chứng minh mã nhất quán với tài liệu; chưa chứng minh gì về sàn thật."""
import http.server
import json
import os
import sys
import threading
import unittest
import urllib.parse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import capital, ratelimit  # noqa: E402
from pyea.broker import BrokerError, make_broker  # noqa: E402
from pyea.feeds import FeedError, make_feed  # noqa: E402
from pyea.settings import API_KEYS, GLOBAL_INPUTS, api_keys_for, default_settings  # noqa: E402


class Fake:
    API_KEY, IDENT, PW = "KEY123", "me@example.com", "custompw"

    def __init__(self):
        self.tok = {"CST": "cst-1", "X-SECURITY-TOKEN": "sec-1"}
        self.n_login = 0
        self.positions, self.orders, self.confirms = {}, {}, {}
        self.bid, self.ask = 1.1000, 1.1002
        self.reject_next = None
        self.expire_once = False
        self.log = []
        self.seq = 0
        outer = self

        class H(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def _send(self, code, obj, headers=None):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                for k, v in (headers or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(b)

            def _body(self):
                n = int(self.headers.get("Content-Length") or 0)
                return json.loads(self.rfile.read(n) or b"{}") if n else {}

            def _auth(self):
                if self.headers.get("X-CAP-API-KEY") != outer.API_KEY:
                    self._send(401, {"errorCode": "error.invalid.api.key"})
                    return False
                if outer.expire_once:
                    outer.expire_once = False
                    self._send(401, {"errorCode": "error.invalid.session.token"})
                    return False
                if self.headers.get("CST") != outer.tok["CST"] or self.headers.get("X-SECURITY-TOKEN") != outer.tok["X-SECURITY-TOKEN"]:
                    self._send(401, {"errorCode": "error.invalid.session.token"})
                    return False
                return True

            def do_POST(self):
                self.handle_any("POST")

            def do_GET(self):
                self.handle_any("GET")

            def do_PUT(self):
                self.handle_any("PUT")

            def do_DELETE(self):
                self.handle_any("DELETE")

            def handle_any(self, m):
                u = urllib.parse.urlsplit(self.path)
                path, q = u.path, dict(urllib.parse.parse_qsl(u.query))
                body = self._body() if m in ("POST", "PUT") else {}
                outer.log.append((m, path, body))
                if m == "POST" and path == "/api/v1/session":
                    if self.headers.get("X-CAP-API-KEY") != outer.API_KEY or body.get("identifier") != outer.IDENT or body.get("password") != outer.PW:
                        return self._send(401, {"errorCode": "error.invalid.details"})
                    outer.n_login += 1
                    outer.tok = {"CST": "cst-%d" % (outer.n_login + 1), "X-SECURITY-TOKEN": "sec-%d" % (outer.n_login + 1)}
                    return self._send(200, {"currentAccountId": "ACC1", "accounts": [{"accountId": "ACC1", "preferred": True, "currency": "USD",
                                            "balance": {"balance": 1000.0, "available": 900.0}}]}, outer.tok)
                if not self._auth():
                    return
                pre = "/api/v1"
                if m == "GET" and path == pre + "/accounts":
                    return self._send(200, {"accounts": [{"accountId": "ACC1", "preferred": True, "currency": "USD", "balance": {"balance": 1000.0, "deposit": 1000.0,
                                            "profitLoss": 0.0, "available": 900.0}}]})
                if m == "GET" and path.startswith(pre + "/markets/"):
                    return self._send(200, {"snapshot": {"bid": outer.bid, "offer": outer.ask, "marketStatus": outer.status if hasattr(outer, "status") else "TRADEABLE"}})
                if m == "GET" and path.startswith(pre + "/prices/"):
                    outer.last_price_q = q
                    rows = []
                    for i in range(int(q.get("max", 10))):
                        t = "2026-01-01T00:%02d:00" % i
                        px = lambda b: {"bid": b, "ask": b + 0.0002}  # noqa: E731
                        rows.append({"snapshotTime": t, "snapshotTimeUTC": t, "openPrice": px(1.0 + i * .001), "highPrice": px(1.0 + i * .001 + .002),
                                     "lowPrice": px(1.0 + i * .001 - .002), "closePrice": px(1.0 + i * .001 + .001), "lastTradedVolume": 5 + i})
                    return self._send(200, {"prices": rows})
                if m == "POST" and path == pre + "/positions":
                    return outer.open_pos(self, body)
                if m == "GET" and path == pre + "/positions":
                    return self._send(200, {"positions": [{"position": {"dealId": d, "direction": p["direction"], "size": p["size"], "level": p["level"],
                                                                        **({"stopLevel": p["stop"]} if p.get("stop") else {}),
                                                                        **({"profitLevel": p["profit"]} if p.get("profit") else {}),
                                                                        "workingOrderId": p.get("wo", "")},
                                                           "market": {"epic": p["epic"], "bid": outer.bid, "offer": outer.ask}} for d, p in outer.positions.items()]})
                if path.startswith(pre + "/positions/") and m in ("DELETE", "PUT"):
                    d = path.rsplit("/", 1)[1]
                    p = outer.positions.get(d)
                    if p is None:
                        return self._send(404, {"errorCode": "error.not-found"})
                    ref = outer.new_ref("p_")
                    if m == "DELETE":
                        outer.positions.pop(d)
                        outer.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "CLOSED", "dealId": d, "level": outer.bid if p["direction"] == "BUY" else outer.ask,
                                               "size": p["size"], "direction": p["direction"], "epic": p["epic"], "affectedDeals": [{"dealId": d, "status": "CLOSED"}]}
                    else:
                        for k_in, k_out in (("stopLevel", "stop"), ("profitLevel", "profit")):
                            if k_in in body:
                                p[k_out] = body[k_in]
                        outer.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "AMENDED", "dealId": d, "level": p["level"], "size": p["size"]}
                    return self._send(200, {"dealReference": ref})
                if m == "POST" and path == pre + "/workingorders":
                    ref = outer.new_ref("o_")
                    d = "WO%d" % outer.seq
                    outer.orders[d] = {"epic": body["epic"], "direction": body["direction"], "size": body["size"], "level": body["level"], "type": body["type"],
                                       "body": body}
                    outer.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "OPEN", "dealId": d, "level": body["level"], "size": body["size"],
                                           "affectedDeals": [{"dealId": d, "status": "OPEN"}]}
                    return self._send(200, {"dealReference": ref})
                if m == "GET" and path == pre + "/workingorders":
                    return self._send(200, {"workingOrders": [{"workingOrderData": {"dealId": d, "direction": o["direction"], "epic": o["epic"], "orderSize": o["size"],
                                                                                     "orderLevel": o["level"], "orderType": o["type"]},
                                                               "marketData": {"epic": o["epic"], "bid": outer.bid, "offer": outer.ask}} for d, o in outer.orders.items()]})
                if path.startswith(pre + "/workingorders/") and m in ("DELETE", "PUT"):
                    d = path.rsplit("/", 1)[1]
                    o = outer.orders.get(d)
                    if o is None:
                        return self._send(404, {"errorCode": "error.not-found"})
                    ref = outer.new_ref("o_")
                    if m == "DELETE":
                        outer.orders.pop(d)
                        outer.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "DELETED", "dealId": d}
                    else:
                        o["level"] = body.get("level", o["level"])
                        outer.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "AMENDED", "dealId": d, "level": o["level"]}
                    return self._send(200, {"dealReference": ref})
                if m == "GET" and path.startswith(pre + "/confirms/"):
                    c = outer.confirms.get(path.rsplit("/", 1)[1])
                    return self._send(200, c) if c else self._send(404, {"errorCode": "error.confirms.deal-not-found"})
                return self._send(404, {"errorCode": "unknown " + path})

            def log_message(self, *a):
                pass
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def new_ref(self, pre):
        self.seq += 1
        return "%s%d" % (pre, self.seq)

    def open_pos(self, h, body):
        ref = self.new_ref("o_")
        if self.reject_next:
            self.confirms[ref] = {"dealStatus": "REJECTED", "reason": self.reject_next, "status": "REJECTED"}
            self.reject_next = None
            return h._send(200, {"dealReference": ref})
        d = "DEAL%d" % self.seq
        lvl = self.ask if body["direction"] == "BUY" else self.bid
        self.positions[d] = {"epic": body["epic"], "direction": body["direction"], "size": body["size"], "level": lvl}
        self.confirms[ref] = {"dealStatus": "ACCEPTED", "status": "OPEN", "dealId": d, "level": lvl, "size": body["size"], "direction": body["direction"],
                              "epic": body["epic"], "affectedDeals": [{"dealId": d, "status": "OPEN"}]}
        return h._send(200, {"dealReference": ref})

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


def settings_for(f, **kw):
    s = default_settings()
    s.update(exchange="capital", base_url=f.url, capital_api_key=f.API_KEY, capital_identifier=f.IDENT, capital_password=f.PW)
    s.update(kw)
    return s


class TestCapital(unittest.TestCase):
    def setUp(self):
        ratelimit.reset_all()
        capital._CLIENTS.clear()
        self.f = Fake()
        self.st = settings_for(self.f)
        self.b = make_broker(self.st)
        self.feed = make_feed("capital", self.st)

    def tearDown(self):
        self.f.close()

    def test_login_balance_and_flags(self):
        self.assertEqual(self.b.prepare("EURUSD"), 900.0)                 # available
        self.assertEqual(self.b.account_flags(), {"currency": "USD"})
        self.assertEqual(self.f.n_login, 1)

    def test_bad_credentials_give_clear_error(self):
        capital._CLIENTS.clear()
        b = make_broker(settings_for(self.f, capital_password="sai"))
        with self.assertRaises(BrokerError) as cm:
            b.prepare("EURUSD")
        self.assertIn("401", str(cm.exception))
        with self.assertRaises(BrokerError):
            make_broker(settings_for(self.f, capital_api_key=""))

    def test_tick_and_tradeable_flag(self):
        t = self.feed.tick("EURUSD")
        self.assertEqual((t.bid, t.ask, t.tradeable), (1.1000, 1.1002, True))
        self.f.status = "CLOSED"
        self.assertFalse(self.feed.tick("EURUSD").tradeable)

    def test_history_maps_resolution_utc_and_mid(self):
        cs = self.feed.history("EURUSD", "5m", 20, end=1767225600)       # 2026-01-01T00:00:00Z
        self.assertEqual(len(cs), 20)
        self.assertEqual(self.f.last_price_q["resolution"], "MINUTE_5")
        self.assertEqual(self.f.last_price_q["max"], "20")
        self.assertEqual(self.f.last_price_q["to"], "2026-01-01T00:00:00")
        self.assertEqual(cs[0].time, 1767225600.0)
        self.assertAlmostEqual(cs[0].open, 1.0001, places=6)              # trung bình bid/ask
        self.assertEqual(cs[0].volume, 5.0)
        self.assertEqual([c.time for c in cs], sorted(c.time for c in cs))
        self.feed.history("EURUSD", "4h", 5)
        self.assertEqual(self.f.last_price_q["resolution"], "HOUR_4")
        self.feed.history("EURUSD", "1m", 5000)
        self.assertEqual(self.f.last_price_q["max"], "1000")             # trần của sàn

    def test_market_buy_uses_confirm_fill_and_positions_aggregate(self):
        fill = self.b.market_order("EURUSD", "buy", 2)
        self.assertEqual((fill.price, fill.qty), (1.1002, 2.0))
        self.assertTrue(fill.ref.startswith("DEAL"))
        self.b.market_order("EURUSD", "buy", 1)
        self.assertEqual(self.b.positions(), {"EURUSD": {"qty": 3.0, "price": 1.1002}})
        sent = [x for x in self.f.log if x[0] == "POST" and x[1].endswith("/positions")]
        self.assertEqual(sent[0][2]["direction"], "BUY")
        self.assertFalse(sent[0][2]["guaranteedStop"])

    def test_rejected_deal_raises_with_reason(self):
        self.f.reject_next = "INSUFFICIENT_FUNDS"
        with self.assertRaises(BrokerError) as cm:
            self.b.market_order("EURUSD", "buy", 1)
        self.assertIn("INSUFFICIENT_FUNDS", str(cm.exception))
        self.assertEqual(self.f.positions, {})

    def test_close_full_ok_partial_refused(self):
        self.b.market_order("EURUSD", "sell", 3)
        with self.assertRaises(BrokerError) as cm:
            self.b.market_order("EURUSD", "buy", 1, reduce_only=True)
        self.assertIn("CẢ vị thế", str(cm.exception))
        self.assertEqual(len(self.f.positions), 1)                        # không đóng gì khi từ chối
        fill = self.b.market_order("EURUSD", "buy", 3, reduce_only=True)
        self.assertEqual((fill.price, fill.qty), (1.1002, 3.0))           # bán xong mua lại: confirm trả ask
        self.assertEqual(self.b.positions(), {})
        with self.assertRaises(BrokerError):
            self.b.market_order("EURUSD", "buy", 1, reduce_only=True)

    def test_expired_session_relogs_once_and_order_not_duplicated(self):
        self.b.prepare("EURUSD")
        self.assertEqual(self.f.n_login, 1)
        self.f.expire_once = True                                          # phiên hết hạn đúng lúc đặt lệnh
        self.b.market_order("EURUSD", "buy", 1)
        self.assertEqual(self.f.n_login, 2)
        self.assertEqual(len(self.f.positions), 1)                         # 401 = chưa xử lý -> gửi lại không tạo lệnh trùng
        old = self.f.tok["CST"]
        self.b.c._at -= capital.SESSION_TTL + 5                            # quá TTL: đăng nhập lại chủ động trước khi gọi
        self.b.prepare("EURUSD")
        self.assertEqual(self.f.n_login, 3)
        self.assertNotEqual(self.f.tok["CST"], old)

    def test_position_levels_roundtrip(self):
        fill = self.b.market_order("EURUSD", "buy", 1)
        rows = self.b.position_levels("EURUSD")
        self.assertEqual((rows[0]["ref"], rows[0]["sl"], rows[0]["tp"], rows[0]["owned"]), (fill.ref, 0.0, 0.0, False))
        self.b.set_position_levels(fill.ref, 1.0900, 1.1200)
        r = self.b.position_levels("EURUSD")[0]
        self.assertEqual((r["sl"], r["tp"]), (1.09, 1.12))
        self.b.set_position_levels(fill.ref, 0, 1.13)                      # bỏ SL (gửi null), giữ TP mới
        put = [x for x in self.f.log if x[0] == "PUT"][-1][2]
        self.assertEqual(put, {"stopLevel": None, "profitLevel": 1.13})

    def test_protection_sync_only_touches_own_positions(self):
        mine = self.b.market_order("EURUSD", "buy", 1)
        self.f.positions["MANUAL1"] = {"epic": "EURUSD", "direction": "BUY", "size": 1, "level": 1.1}   # vị thế người dùng mở tay
        res = self.b.sync_protection("EURUSD", [{"pid": 1, "ref": mine.ref, "side": "sell", "qty": 1, "sl": 1.09, "tp": 0, "own": True}])
        self.assertFalse(res["errors"], res)
        self.assertEqual(self.f.positions[mine.ref]["stop"], 1.09)
        self.assertNotIn("stop", self.f.positions["MANUAL1"])

    def test_pending_lifecycle(self):
        oid = self.b.place_pending("EURUSD", "buy", "limit", 1, 1.0950, sl=1.09, tp=1.11, expiry=1767225600)
        body = [x for x in self.f.log if x[1].endswith("/workingorders") and x[0] == "POST"][0][2]
        self.assertEqual((body["type"], body["direction"], body["level"], body["stopLevel"], body["profitLevel"]), ("LIMIT", "BUY", 1.095, 1.09, 1.11))
        self.assertEqual(body["goodTillDate"], "2026-01-01T00:00:00")
        self.assertEqual(self.b.pending_orders()[oid], {"symbol": "EURUSD", "side": "buy", "price": 1.095, "qty": 1.0, "type": "LIMIT"})
        self.assertEqual(self.b.order_result(oid), {"state": "open"})
        self.assertEqual(self.b.modify_pending(oid, price=1.0940), oid)
        self.assertEqual(self.f.orders[oid]["level"], 1.094)
        self.f.orders.pop(oid)                                              # sàn khớp lệnh: thành vị thế mang workingOrderId
        self.f.positions["DEALX"] = {"epic": "EURUSD", "direction": "BUY", "size": 1, "level": 1.094, "wo": oid}
        self.assertEqual(self.b.order_result(oid), {"state": "filled", "price": 1.094, "qty": 1.0})
        oid2 = self.b.place_pending("EURUSD", "sell", "stop", 2, 1.0800)
        self.assertTrue(self.b.cancel_pending(oid2))
        self.assertEqual(self.b.order_result(oid2)["state"], "canceled")
        with self.assertRaises(BrokerError):
            self.b.place_pending("EURUSD", "buy", "stop_limit", 1, 1.0)

    def test_settings_wiring(self):
        self.assertIn("capital", GLOBAL_INPUTS["exchange"].choices)
        self.assertIn("capital_api_key", GLOBAL_INPUTS)
        self.assertTrue(GLOBAL_INPUTS["capital_api_key"].secret and GLOBAL_INPUTS["capital_password"].secret)
        self.assertIn("capital_password", api_keys_for("capital"))
        self.assertNotIn("oanda_token", api_keys_for("capital"))
        self.assertEqual(API_KEYS["capital"] & {"testnet"}, {"testnet"})
        from pyea.feeds import resolve_base
        self.assertEqual(resolve_base({"exchange": "capital", "testnet": True}), "https://demo-api-capital.backend-capital.com")
        self.assertEqual(resolve_base({"exchange": "capital", "testnet": False}), "https://api-capital.backend-capital.com")

    def test_feed_error_wraps_broker_error(self):
        capital._CLIENTS.clear()
        f2 = make_feed("capital", settings_for(self.f, capital_password="sai"))
        with self.assertRaises(FeedError):
            f2.tick("EURUSD")


if __name__ == "__main__":
    unittest.main()
