"""Bot mẫu mới: Breakout Donchian và DCA định kỳ (nạp được, chạy backtest, hành vi đúng)."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea.backtest import run_backtest                       # noqa: E402
from pyea.loader import inspect_bot                          # noqa: E402
from pyea.sdk import Candle                                  # noqa: E402
from pyea.settings import default_settings                   # noqa: E402
from pyea.backtest import run_portfolio                      # noqa: E402
from pyea.shell import portfolio_entries, portfolio_summary  # noqa: E402
from pyea.storage import Store                               # noqa: E402

TMP = tempfile.mkdtemp()
STORE = Store(TMP)
STORE.seed_examples()
BOTS = STORE.bots_dir
STEP = 300
T0 = 1_700_000_100 - (1_700_000_100 % STEP)


def S(**over):
    s = default_settings()
    s.update(initial_balance=10000.0, commission_pct=0.0, spread_pct=0.0, leverage=1.0, max_loss_pct=0.0)
    s.update(over)
    return s


def bar(i, o, h, l, c):
    return Candle(T0 + i * STEP, o, h, l, c)


def flat(n, base=100.0):
    return [bar(i, base, base + 1, base - 1, base) for i in range(n)]


class TestExamplesLoad(unittest.TestCase):
    def test_seeded_and_inspectable(self):
        for n, key in (("breakout.py", "channel"), ("dca.py", "every_bars")):
            self.assertTrue(os.path.exists(os.path.join(BOTS, n)), n)
            info = inspect_bot(os.path.join(BOTS, n))
            self.assertTrue(info.ok, info.error)
            self.assertEqual(info.api_min, "1.2")
            self.assertFalse(info.warnings, info.warnings)      # mẫu không dùng mạng/ghi file
            self.assertIn(key, info.inputs)


class TestBreakout(unittest.TestCase):
    def _bt(self, candles, **params):
        p = {"channel": 20, "exit_channel": 8, "lot": 1.0, "atr_period": 14}
        p.update(params)
        return run_backtest(os.path.join(BOTS, "breakout.py"), p, S(), "BTCUSD", "5m", candles, 40, "ohlc")

    def test_buys_upside_breakout_then_exits_on_channel_break(self):
        c = flat(60)
        c += [bar(60 + i, 100 + 2 * i, 102 + 2 * i, 100 + 2 * i - 0.5, 102 + 2 * i) for i in range(1, 8)]     # đột phá lên
        top = c[-1].close
        c += [bar(67 + i, top - 3 * i, top - 3 * i + 0.5, top - 3 * i - 2.5, top - 3 * i - 2.5) for i in range(0, 8)]   # rồi đổ xuống
        r = self._bt(c)
        self.assertTrue(r.ok, r.error)
        opens = [e for e in r.events if e.kind == "open"]
        self.assertTrue(opens, "phải có lệnh mở")
        self.assertEqual(opens[0].side, "buy")
        self.assertIn("MUA đột phá", opens[0].reason)
        self.assertTrue(any("thoát lệnh mua" in (e.reason or "") for e in r.events if e.kind == "close") or r.trades)
        self.assertGreaterEqual(len(r.trades), 1)

    def test_direction_long_ignores_downside_breakout(self):
        c = flat(60)
        c += [bar(60 + i, 100 - 3 * i, 100 - 3 * i + 0.5, 100 - 3 * i - 2.5, 100 - 3 * i - 2.5) for i in range(1, 10)]
        r = self._bt(c, direction="long")
        self.assertTrue(r.ok, r.error)
        self.assertEqual([e for e in r.events if e.kind == "open"], [])
        r2 = self._bt(c, direction="short")
        self.assertTrue([e for e in r2.events if e.kind == "open" and e.side == "sell"])

    def test_no_trade_inside_the_channel(self):
        r = self._bt(flat(120))
        self.assertTrue(r.ok, r.error)
        self.assertEqual(len(r.trades), 0)


class TestDCA(unittest.TestCase):
    def _bt(self, candles, **params):
        p = {"every_bars": 4, "max_buys": 3, "lot": 1.0, "basket_tp_pct": 3.0, "basket_sl_pct": 0.0}
        p.update(params)
        return run_backtest(os.path.join(BOTS, "dca.py"), p, S(), "BTCUSD", "5m", candles, 5, "ohlc")

    def test_buys_on_schedule_and_respects_max_buys(self):
        r = self._bt(flat(60))
        self.assertTrue(r.ok, r.error)
        opens = [e for e in r.events if e.kind == "open"]
        self.assertEqual(len(opens), 3)                                    # đúng giới hạn, không mua thêm
        self.assertTrue(all(e.side == "buy" for e in opens))
        self.assertIn("chu kỳ", opens[0].reason)

    def test_basket_take_profit_closes_everything(self):
        c = [bar(i, 100 * 1.01 ** i, 100 * 1.01 ** i + 0.1, 100 * 1.01 ** i - 0.1, 100 * 1.01 ** i) for i in range(80)]
        r = self._bt(c, max_buys=5, basket_tp_pct=2.0)
        self.assertTrue(r.ok, r.error)
        self.assertGreaterEqual(len(r.trades), 2)
        self.assertTrue(all(t.profit > 0 for t in r.trades[:2]))
        self.assertTrue(any("chốt toàn bộ" in (e.reason or "") for e in r.events if e.kind == "close"))

    def test_basket_stop_loss_when_enabled(self):
        c = [bar(i, 100 * 0.99 ** i, 100 * 0.99 ** i + 0.1, 100 * 0.99 ** i - 0.1, 100 * 0.99 ** i) for i in range(60)]
        r = self._bt(c, max_buys=5, basket_sl_pct=3.0)
        self.assertTrue(r.ok, r.error)
        self.assertTrue(any("cắt toàn bộ" in (e.reason or "") for e in r.events if e.kind == "close"))



class TestPortfolio(unittest.TestCase):
    def cfgs(self):
        return [{"iid": "dca-A-1", "bot_path": os.path.join(BOTS, "dca.py"), "symbol": "aaa", "tf": "5m",
                 "params": {"every_bars": 4, "max_buys": 3, "lot": 1.0, "basket_tp_pct": 3.0, "basket_sl_pct": 0.0}},
                {"iid": "brk-B-1", "bot_path": os.path.join(BOTS, "breakout.py"), "symbol": "BBB", "tf": "5m",
                 "params": {"channel": 20, "exit_channel": 8, "lot": 1.0, "atr_period": 14}},
                {"iid": "dca-B-2", "bot_path": os.path.join(BOTS, "dca.py"), "symbol": "BBB", "tf": "5m", "params": {"every_bars": 6, "lot": 1.0}}]

    def candles(self):
        rising = [bar(i, 100 * 1.01 ** i, 100 * 1.01 ** i + 0.1, 100 * 1.01 ** i - 0.1, 100 * 1.01 ** i) for i in range(80)]
        brk = flat(60) + [bar(60 + i, 100 + 2 * i, 102 + 2 * i, 100 + 2 * i - 0.5, 102 + 2 * i) for i in range(1, 12)]
        return {("AAA", "5m"): rising, ("BBB", "5m"): brk}

    def test_entries_use_each_bots_own_symbol_tf_params_and_share_candles(self):
        cs = self.candles()
        e = portfolio_entries(self.cfgs(), {"dca-A-1", "brk-B-1", "dca-B-2"}, cs, 30)
        self.assertEqual([(x["iid"], x["symbol"], x["tf"], x["warmup"]) for x in e],
                         [("dca-A-1", "AAA", "5m", 30), ("brk-B-1", "BBB", "5m", 30), ("dca-B-2", "BBB", "5m", 30)])
        self.assertIs(e[1]["candles"], e[2]["candles"])                   # hai bot cùng mã/khung dùng chung một chuỗi nến
        self.assertEqual(e[0]["params"]["every_bars"], 4)
        e[0]["params"]["every_bars"] = 99
        self.assertEqual(self.cfgs()[0]["params"]["every_bars"], 4)       # params là bản sao
        only = portfolio_entries(self.cfgs(), {"brk-B-1"}, cs, 30)
        self.assertEqual([x["iid"] for x in only], ["brk-B-1"])

    def test_entries_errors(self):
        with self.assertRaises(ValueError):
            portfolio_entries(self.cfgs(), set(), self.candles(), 30)
        cs = self.candles()
        del cs[("BBB", "5m")]
        with self.assertRaises(ValueError) as cm:
            portfolio_entries(self.cfgs(), {"brk-B-1"}, cs, 30)
        self.assertIn("BBB", str(cm.exception))

    def test_run_portfolio_two_symbols_shared_account_and_summary(self):
        e = portfolio_entries(self.cfgs(), {"dca-A-1", "brk-B-1"}, self.candles(), 30)
        r = run_portfolio(e, S(), 30, "ohlc")
        self.assertTrue(r.ok, r.error)
        self.assertEqual(set(r.by_bot), {"dca-A-1", "brk-B-1"})
        self.assertEqual(r.report["Số bot"], 2)
        self.assertGreater(r.by_bot["dca-A-1"]["trades"], 0)               # DCA chốt rổ ở thị trường tăng
        self.assertGreater(r.by_bot["brk-B-1"]["trades"], 0)               # breakout vào lệnh ở đoạn đột phá
        self.assertAlmostEqual(sum(d["net"] for d in r.by_bot.values()), r.report["Lợi nhuận ròng"], 6)    # tổng từng bot = tổng danh mục
        txt = portfolio_summary(r)
        self.assertIn("2 bot", txt)
        self.assertIn("dca-A-1 | AAA 5m", txt)
        self.assertIn("brk-B-1 | BBB 5m", txt)
        first = [ln for ln in txt.splitlines() if " | " in ln][0]          # xếp theo lãi ròng giảm dần
        nets = [d["net"] for _, d in sorted(r.by_bot.items(), key=lambda kv: -kv[1]["net"])]
        self.assertIn("%+.2f" % nets[0], first)

    def test_summary_handles_empty_and_errors(self):
        r = run_portfolio([], S(), 30, "ohlc")
        self.assertFalse(r.ok)
        self.assertIn("Chưa có bot", r.error)
        self.assertIn("Chưa có bot", portfolio_summary(r))                 # có lưu ý lỗi, không ném


if __name__ == "__main__":
    unittest.main()
