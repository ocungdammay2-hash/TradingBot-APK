"""Bản quyền: dùng thử 90 ngày CHỈ khi cài từ Play, khoá Ed25519, chống lùi đồng hồ / sửa file."""
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import ed25519, license as lic

DAY = 86400
T0 = 1_800_000_000.0
SEED = bytes(range(32))
PUB = ed25519.b64u(ed25519.public_key(SEED))
PLAY = lic.PLAY_INSTALLER


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = lic.Store(self.tmp.name)

    def ev(self, installer, now):
        return lic.evaluate(self.store, installer, now, PUB)


class TestTrial(Base):
    def test_sideload_never_limited(self):
        self.assertEqual(self.ev(None, T0)["state"], "sideload")
        self.assertEqual(self.ev("com.example.other", T0 + 500 * DAY)["state"], "sideload")
        self.assertFalse(lic.blocks_live(self.ev(None, T0 + 900 * DAY)))

    def test_play_trial_is_90_days_then_expires(self):
        self.assertEqual(self.ev(PLAY, T0)["state"], "trial")
        self.assertEqual(self.ev(PLAY, T0)["days_left"], 90)
        s = self.ev(PLAY, T0 + 89 * DAY)
        self.assertEqual((s["state"], s["days_left"]), ("trial", 1))
        s = self.ev(PLAY, T0 + 90 * DAY + 1)
        self.assertEqual(s["state"], "expired")
        self.assertTrue(lic.blocks_live(s))
        self.assertIn("paper", lic.describe(s))

    def test_clock_rollback_does_not_extend_trial(self):
        self.ev(PLAY, T0)
        self.ev(PLAY, T0 + 91 * DAY)                       # hết hạn, mốc "đã thấy" = ngày 91
        s = self.ev(PLAY, T0 + 10 * DAY)                    # người dùng lùi đồng hồ
        self.assertEqual(s["state"], "expired")
        self.assertTrue(s["rolled_back"])

    def test_small_clock_skew_is_not_rollback(self):
        self.ev(PLAY, T0)
        self.assertFalse(self.ev(PLAY, T0 - 60)["rolled_back"])

    def test_hand_edited_file_burns_trial_on_play_only(self):
        self.ev(PLAY, T0)
        with open(self.store.path) as f:
            d = json.load(f)
        d["first"] = T0 + 1000 * DAY                       # cố kéo dài dùng thử
        with open(self.store.path, "w") as f:
            json.dump(d, f)
        self.assertEqual(self.ev(PLAY, T0 + DAY)["state"], "expired")
        self.assertEqual(self.ev(None, T0 + DAY)["state"], "sideload")

    def test_install_id_stable(self):
        a = self.ev(PLAY, T0)["iid"]
        self.assertEqual(a, self.ev(PLAY, T0 + DAY)["iid"])
        self.assertEqual(len(a), 12)


class TestKeys(Base):
    def test_activation_unlocks_expired(self):
        iid = self.ev(PLAY, T0)["iid"]
        late = T0 + 200 * DAY
        self.assertEqual(self.ev(PLAY, late)["state"], "expired")
        key = lic.make_key(SEED, late + 30 * DAY, iid)
        ok, msg = lic.activate(self.store, key, PLAY, late, PUB)
        self.assertTrue(ok, msg)
        s = self.ev(PLAY, late + 1)
        self.assertEqual((s["state"], s["days_left"]), ("licensed", 29))
        self.assertEqual(self.ev(PLAY, late + 31 * DAY)["state"], "expired")      # hết hạn khoá -> lại hết hạn

    def test_perpetual_and_wildcard(self):
        self.ev(PLAY, T0)
        key = lic.make_key(SEED, 0, "*")
        self.assertTrue(lic.activate(self.store, key, PLAY, T0 + 300 * DAY, PUB)[0])
        s = self.ev(PLAY, T0 + 5000 * DAY)
        self.assertEqual(s["state"], "licensed")
        self.assertIn("vĩnh viễn", lic.describe(s))

    def test_rejects_wrong_device_forged_and_garbage(self):
        self.ev(PLAY, T0)
        self.assertIn("thiết bị khác", lic.activate(self.store, lic.make_key(SEED, 0, "other"), PLAY, T0, PUB)[1])
        other = bytes(range(1, 33))
        self.assertIn("Chữ ký", lic.activate(self.store, lic.make_key(other, 0, "*"), PLAY, T0, PUB)[1])
        good = lic.make_key(SEED, 0, "*")
        forged = good[:-4] + ("AAAA" if not good.endswith("AAAA") else "BBBB")
        self.assertFalse(lic.activate(self.store, forged, PLAY, T0, PUB)[0])
        self.assertFalse(lic.activate(self.store, "xyz", PLAY, T0, PUB)[0])
        self.assertIn("hết hạn", lic.activate(self.store, lic.make_key(SEED, T0 - 5, "*"), PLAY, T0, PUB)[1])

    def test_payload_swap_invalidates_signature(self):
        self.ev(PLAY, T0)
        a = lic.make_key(SEED, T0 + DAY, "*")
        b = lic.make_key(SEED, 0, "*")
        mixed = a.split(".")[0] + "." + b.split(".")[1]
        self.assertFalse(lic.activate(self.store, mixed, PLAY, T0, PUB)[0])

    def test_embedded_public_key_is_valid_ed25519_point(self):
        self.assertEqual(len(lic._b64u_dec(lic.PUBLIC_KEY)), 32)
        self.assertIsNotNone(ed25519._decompress(lic._b64u_dec(lic.PUBLIC_KEY)))

    def test_keygen_tool_roundtrip(self):
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
        import io
        import contextlib
        import license_keygen as kg
        priv = os.path.join(self.tmp.name, "k.key")
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            kg.main(["new-keypair", priv])
            pub = buf.getvalue().split(":")[1].strip()
            buf.truncate(0), buf.seek(0)
            kg.main(["issue", priv, "--iid", "*", "--days", "10"])
        k, why = lic.parse_key(buf.getvalue().strip(), "x", time_now(), pub)
        self.assertIsNone(why)
        self.assertEqual(k["plan"], "full")


class TestLicenseUI(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import kivy_stub
        import test_ui_smoke as T
        kivy_stub.OPEN_POPUPS.clear()
        self.T, self.stub = T, kivy_stub
        self.app = T.make_app()
        from pyea import ui_shell
        self.shell = ui_shell
        self._old = (ui_shell.native.IS_ANDROID, getattr(ui_shell.native, "installer_package", None))
        self.addCleanup(self._restore)

    def _restore(self):
        self.shell.native.IS_ANDROID, self.shell.native.installer_package = self._old

    def as_play(self, days_ago):
        import time
        self.shell.native.IS_ANDROID = True
        self.shell.native.installer_package = lambda: PLAY
        now = time.time()
        lic.Store(self.app.data_dir).save({"iid": "abc123def456", "first": now - days_ago * DAY, "seen": now - days_ago * DAY, "key": ""})

    def test_sideload_is_unrestricted(self):
        self.assertEqual(self.app.license_status()["state"], "sideload")
        self.assertTrue(self.app.license_gate_live())

    def test_play_trial_allows_live_and_expired_blocks_with_dialog(self):
        self.as_play(10)
        self.assertEqual(self.app.license_status()["state"], "trial")
        self.assertTrue(self.app.license_gate_live())
        self.as_play(95)
        self.stub.OPEN_POPUPS.clear()
        self.assertFalse(self.app.license_gate_live())
        blob = self.T.texts(self.stub.OPEN_POPUPS[-1].content)
        self.assertIn("Hết 90 ngày", blob)
        self.assertIn("abc123def456", blob)

    def test_expired_blocks_starting_live_session_but_not_paper(self):
        self.as_play(120)
        self.app.settings.update(mode="live", exchange="binance_futures", live_confirm=True)
        self.app.save_forms = lambda: True                                                 # giữ nguyên settings đã đặt
        self.stub.OPEN_POPUPS.clear()
        self.app.start_session()
        self.assertTrue(any(p.title == "Bản quyền" for p in self.stub.OPEN_POPUPS))

    def test_license_row_in_legal_menu_and_activation_via_dialog(self):
        self.as_play(120)
        self.app.legal_menu()
        self.assertIn("Bản quyền", self.T.texts(self.stub.OPEN_POPUPS[-1].content))
        self.app.license_dialog()
        pop = self.stub.OPEN_POPUPS[-1]
        key = lic.make_key(bytes.fromhex("00" * 32), 0, "*")
        self.assertFalse(lic.activate(lic.Store(self.app.data_dir), key, PLAY)[0])         # khoá ký bằng khoá lạ -> bị từ chối

    def test_nag_once_per_day_when_close_to_end(self):
        self.as_play(80)
        msgs = []
        self.app.toast = msgs.append
        self.app.license_nag()
        self.app.license_nag()
        self.assertEqual(len(msgs), 1)
        self.assertIn("còn", msgs[0])
        self.as_play(5)
        self.app.store.save_prefs({})
        self.app.license_nag()
        self.assertEqual(len(msgs), 1)                                                     # còn 85 ngày: không nhắc


def time_now():
    import time
    return time.time()


if __name__ == "__main__":
    unittest.main()
