"""Trailing Stop + Hòa vốn (như MT5): hàm thuần target_sl, kiểm luật, vòng tick thật qua TradingSession, lưu bền, IPC, giao diện."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

from pyea import trail as TR                                                      # noqa: E402
from pyea.trail import clean_rule, target_sl                                      # noqa: E402
from test_shell_gaps import make, tk                                              # noqa: E402


class TestCleanRule(unittest.TestCase):
    def test_valid_and_empty(self):
        self.assertEqual(clean_rule({"distance": "2", "be_at": 1}), {"distance": 2.0, "be_at": 1.0})
        self.assertIsNone(clean_rule(None))
        self.assertIsNone(clean_rule({"distance": 0, "be_at": ""}))
        self.assertIsNone(clean_rule({}))

    def test_bad_values(self):
        for bad in ({"distance": "abc"}, {"distance": -1}, {"distance": float("nan")}, {"distance": float("inf")},
                    {"start": 1}, {"step": 1}, {"be_offset": 1}, {"distance": 1, "be_offset": 1}):
            with self.assertRaises(ValueError, msg=str(bad)):
                clean_rule(bad)


class TestTargetSl(unittest.TestCase):
    def test_buy_trails_up_only(self):
        r = {"distance": 2.0, "step": 0.0}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 101.0, 101.1))            # chưa lãi đủ khoảng (start = distance)
        self.assertEqual(target_sl(r, "buy", 100, 0, 103.0, 103.1), 101.0)
        self.assertEqual(target_sl(r, "buy", 100, 101.0, 105.0, 105.1), 103.0)
        self.assertIsNone(target_sl(r, "buy", 100, 103.0, 104.0, 104.1))        # giá lùi: không kéo SL xuống
        self.assertIsNone(target_sl(r, "buy", 100, 103.0, 105.0, 105.1))        # bằng mức cũ: không đổi

    def test_sell_mirror_uses_ask(self):
        r = {"distance": 2.0, "step": 0.0}
        self.assertEqual(target_sl(r, "sell", 100, 0, 96.9, 97.0), 99.0)
        self.assertEqual(target_sl(r, "sell", 100, 99.0, 94.9, 95.0), 97.0)
        self.assertIsNone(target_sl(r, "sell", 100, 97.0, 96.0, 96.1))

    def test_start_and_step(self):
        r = {"distance": 1.0, "start": 3.0, "step": 0.5}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 102.5, 102.6))            # lãi 2.5 < start 3
        self.assertEqual(target_sl(r, "buy", 100, 0, 103.0, 103.1), 102.0)
        self.assertIsNone(target_sl(r, "buy", 100, 102.0, 103.3, 103.4))        # mới tiến 0.3 < step 0.5
        self.assertEqual(target_sl(r, "buy", 100, 102.0, 103.6, 103.7), 102.6)

    def test_default_step_is_ten_percent_of_distance(self):
        r = {"distance": 10.0}
        self.assertIsNone(target_sl(r, "buy", 100, 100.0, 110.5, 110.6))        # cand 100.5 - 100 = 0.5 < 1.0
        self.assertEqual(target_sl(r, "buy", 100, 100.0, 111.5, 111.6), 101.5)

    def test_break_even_with_offset_and_best_of_both(self):
        r = {"be_at": 1.0, "be_offset": 0.2}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 100.9, 101.0))
        self.assertEqual(target_sl(r, "buy", 100, 90.0, 101.0, 101.1), 100.2)
        self.assertEqual(target_sl(r, "sell", 100, 110.0, 98.9, 99.0), 99.8)
        self.assertIsNone(target_sl(r, "buy", 100, 100.5, 102.0, 102.1))        # SL đã tốt hơn hòa vốn
        both = {"be_at": 1.0, "distance": 5.0, "step": 0.0}
        self.assertEqual(target_sl(both, "buy", 100, 90.0, 102.0, 102.1), 100.0)    # chưa đủ start 5: chỉ hòa vốn
        self.assertEqual(target_sl(both, "buy", 100, 100.0, 110.0, 110.1), 105.0)   # trailing tốt hơn hòa vốn

    def test_sl_must_be_on_loss_side_and_bad_prices(self):
        self.assertIsNone(target_sl({"be_at": 1.0, "be_offset": 5.0}, "buy", 100, 0, 101.0, 101.1))   # BE+offset >= giá: SL sẽ chạm ngay -> bỏ
        self.assertIsNone(target_sl({"distance": 1.0}, "buy", 100, 0, 0, 0))
        self.assertIsNone(target_sl(None, "buy", 100, 0, 110, 110))


class TestSessionTrailing(unittest.TestCase):
    def setUp(self):
        self._mi = TR.MIN_INTERVAL
        TR.MIN_INTERVAL = 0.0

    def tearDown(self):
        TR.MIN_INTERVAL = self._mi

    def open_buy(self, s, **kw):
        tk(s, "BTCUSD", 100.0, 100.0, 1000.0)
        r = s.open_position("BTCUSD", "buy", 1.0, **kw)
        self.assertTrue(r.ok, r.message)
        return next(iter(s.account.positions))

    def test_sl_follows_price_up_and_closes_on_pullback(self):
        s = make()
        pid = self.open_buy(s)
        ok, msg = s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        self.assertTrue(ok, msg)
        tk(s, "BTCUSD", 101.0, 101.0, 1001.0)
        self.assertEqual(s.account.positions[pid].sl, 0.0)
        tk(s, "BTCUSD", 104.0, 104.0, 1002.0)
        self.assertEqual(s.account.positions[pid].sl, 102.0)
        tk(s, "BTCUSD", 106.0, 106.0, 1003.0)
        self.assertEqual(s.account.positions[pid].sl, 104.0)
        tk(s, "BTCUSD", 105.0, 105.0, 1004.0)
        self.assertEqual(s.account.positions[pid].sl, 104.0)                     # lùi: giữ nguyên
        tk(s, "BTCUSD", 103.9, 103.9, 1005.0)                                    # chạm SL
        self.assertNotIn(pid, s.account.positions)
        self.assertIn(s.account.trades[-1].reason, ("sl", "Stop Loss"))
        self.assertGreater(s.account.trades[-1].profit, 0)                       # chốt lãi nhờ trailing
        self.assertEqual(s.trail_rules(), {})                                    # vị thế đóng -> luật bị xoá (xoá ở tick sau)

    def test_rule_cleanup_after_close_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            s = make()
            s.state_file = os.path.join(d, "state.json")
            s._trail_init()
            pid = self.open_buy(s)
            self.assertTrue(s.set_trailing(pid, {"be_at": 1.0, "be_offset": 0.1})[0])
            self.assertTrue(os.path.exists(os.path.join(d, "trails.json")))
            s2 = make()
            s2.state_file = os.path.join(d, "state.json")
            s2._trail_init()
            self.assertEqual(s2.trail_rules(), {pid: {"be_at": 1.0, "be_offset": 0.1}})
            s.close_position(pid, "manual", "x")
            tk(s, "BTCUSD", 100.0, 100.0, 1010.0)
            self.assertEqual(s.trail_rules(), {})

    def test_set_and_clear_validation(self):
        s = make()
        pid = self.open_buy(s)
        self.assertFalse(s.set_trailing(999, {"distance": 1})[0])
        ok, msg = s.set_trailing(pid, {"distance": "x"})
        self.assertFalse(ok)
        self.assertIn("không phải số", msg)
        self.assertEqual(s.trail_rules(), {})
        self.assertTrue(s.set_trailing(pid, {"distance": 1})[0])
        self.assertTrue(s.set_trailing(pid, None)[0])
        self.assertEqual(s.trail_rules(), {})

    def test_sell_position_and_break_even_then_native_modify_is_used(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0, 1000.0)
        pid = None
        r = s.open_position("BTCUSD", "sell", 1.0)
        self.assertTrue(r.ok)
        pid = next(iter(s.account.positions))
        s.set_trailing(pid, {"be_at": 2.0, "be_offset": 0.5})
        tk(s, "BTCUSD", 97.0, 97.0, 1001.0)
        self.assertEqual(s.account.positions[pid].sl, 99.5)

    def test_rejected_modify_is_retried_and_warned_not_crashing(self):
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        calls = []
        orig = s.modify_position

        def bad(*a, **k):
            calls.append(a)
            from pyea.sdk import OrderResult, Ret
            return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message="stops_level")
        s.modify_position = bad
        tk(s, "BTCUSD", 105.0, 105.0, 1001.0)
        tk(s, "BTCUSD", 106.0, 106.0, 1002.0)
        self.assertEqual(len(calls), 2)                                          # thử lại ở tick sau
        self.assertEqual(sum(1 for _, _, lv, m in s.logs if "Trailing" in m and lv == "WARN"), 1)   # chỉ cảnh báo 1 lần/phút
        s.modify_position = orig

    def test_min_interval_throttles(self):
        TR.MIN_INTERVAL = 3600.0
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        tk(s, "BTCUSD", 104.0, 104.0, 1001.0)
        tk(s, "BTCUSD", 110.0, 110.0, 1002.0)
        self.assertEqual(s.account.positions[pid].sl, 102.0)                     # lần 2 bị giãn nhịp

    def test_snapshot_carries_trails(self):
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0})
        self.assertEqual(s.snapshot()["trails"], {pid: {"distance": 2.0}})


class TestUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_modify_dialog_saves_a_rule_through_the_controller(self):
        import test_ui_smoke as T
        app = T.make_app()
        calls = []
        class Ctl:
            def set_trailing(self, pid, rule):
                calls.append((pid, rule))
                return True, "ok"

            def modify_position(self, *a, **k):
                return True
        app.ctl = Ctl()
        from pyea.sdk import Position
        pos = Position(7, "BTCUSD", "buy", 1.0, 100.0, 1000.0)
        app.last_snap = {"positions": [pos], "trails": {}}
        app.open_modify_dialog(7)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[-2].text, ins[-1].text = "2", "1"                                    # Trailing, Hòa vốn
        T.press(dlg.content, "Lưu")
        self.assertEqual(calls, [(7, {"distance": 2.0, "be_at": 1.0})])
        # nhập sai -> không gửi, báo trong hộp
        calls.clear()
        app.open_modify_dialog(7)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[-2].text = "-5"
        T.press(dlg.content, "Lưu")
        self.assertEqual(calls, [])


class TestIpc(unittest.TestCase):
    def test_client_validates_before_sending(self):
        from pyea.ipc import ServiceHandle as ServiceController
        sent = []

        class C:
            def send(self, cmd, **kw):
                sent.append((cmd, kw))
        ctl = ServiceController.__new__(ServiceController)
        ctl.client = C()
        self.assertFalse(ctl.set_trailing(1, {"distance": "x"})[0])
        self.assertEqual(sent, [])
        self.assertTrue(ctl.set_trailing(1, {"distance": 2})[0])
        self.assertEqual(sent, [("trail", {"pos_id": 1, "rule": {"distance": 2}})])


if __name__ == "__main__":
    unittest.main()


class TestSafeBoot(unittest.TestCase):
    """Lỗi lúc dựng giao diện không được làm app văng ra ngoài: hiện lỗi trên màn hình."""

    def test_one_broken_tab_does_not_kill_the_app(self):
        import test_ui_smoke as T
        from pyea import ui
        orig = ui.MarketTab

        class Boom:
            def __init__(self, *a, **k):
                raise RuntimeError("hỏng-giả-lập")
        ui.MarketTab = Boom
        try:
            app = T.make_app()
        finally:
            ui.MarketTab = orig
        self.assertIsInstance(app.market_tab, ui._BrokenTab)
        self.assertIsNone(app.market_tab.refresh({}))                 # lời gọi vào tab hỏng là no-op
        self.assertIn("settings", app.tabs)                             # các tab còn lại vẫn có
        self.assertTrue(os.path.exists(app.store.crash_path))
        self.assertIn("hỏng-giả-lập", open(app.store.crash_path, encoding="utf-8").read())

    def test_total_failure_returns_an_error_screen_with_the_traceback(self):
        import tempfile
        from pyea import ui
        app = ui.PyEAApp()
        app.user_data_dir = tempfile.mkdtemp()
        app._build_main = lambda: (_ for _ in ()).throw(ValueError("sập-toàn-bộ"))
        root = app.build()
        self.assertIsNotNone(root)
        self.assertTrue(os.path.exists(os.path.join(app.user_data_dir, "crash.log")))
        self.assertIn("sập-toàn-bộ", open(os.path.join(app.user_data_dir, "crash.log"), encoding="utf-8").read())


class TestErrorReporting(unittest.TestCase):
    def test_share_falls_back_to_clipboard_and_diag_text_puts_crash_first(self):
        import tempfile
        import zipfile
        from pyea import android_utils, ui, ui_shell
        self.assertFalse(android_utils.share_text("x"))                 # ngoài Android: False -> caller dùng clipboard
        app = ui.PyEAApp()
        copied, toasts = [], []
        ui.Clipboard.copy = lambda t: copied.append(t)
        app.toast = lambda m: toasts.append(m)
        self.assertFalse(app.share_report("LỖI-ABC"))
        self.assertEqual(copied, ["LỖI-ABC"])
        self.assertTrue(toasts)
        d = tempfile.mkdtemp()
        zp = os.path.join(d, "x.zip")
        with zipfile.ZipFile(zp, "w") as z:
            z.writestr("settings.json", "{\"a\": 1}")
            z.writestr("crash.log", "TRACEBACK-XYZ")
        txt = ui_shell._diag_text(zp, "version=1.9.6")
        self.assertLess(txt.index("TRACEBACK-XYZ"), txt.index("settings.json"))
        self.assertIn("version=1.9.6", txt)
        self.assertIn("không đọc được", ui_shell._diag_text(os.path.join(d, "none.zip"), "v"))


class TestBootLog(unittest.TestCase):
    def setUp(self):
        from pyea import bootlog
        self.bl = bootlog
        self._p, self._fh = bootlog._path, bootlog._fh
        self.d = tempfile.mkdtemp()
        bootlog._path = os.path.join(self.d, "boot.log")

    def tearDown(self):
        self.bl._path, self.bl._fh = self._p, self._fh

    def test_crumb_appends_and_never_raises(self):
        self.bl.crumb("mốc-1")
        self.bl.crumb("mốc-2")
        txt = open(self.bl._path, encoding="utf-8").read()
        self.assertIn("mốc-1", txt)
        self.assertLess(txt.index("mốc-1"), txt.index("mốc-2"))
        self.bl._path = os.path.join(self.d, "không", "có", "\0bad")           # đường dẫn hỏng: không ném lỗi
        self.bl.crumb("x")

    def test_path_truncates_big_file(self):
        self.bl._path = None
        p = os.path.join(self.d, "boot.log")
        with open(p, "wb") as f:
            f.write(b"A" * (self.bl.MAX_BYTES + 5000))
        orig = self.bl._candidates
        self.bl._candidates = lambda: iter([self.d])
        try:
            self.assertEqual(self.bl.path(), p)
        finally:
            self.bl._candidates = orig
        self.assertLessEqual(os.path.getsize(p), self.bl.MAX_BYTES)

    def test_main_import_failure_shows_fallback_instead_of_dying(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("pyea_main_under_test", os.path.join(HERE, "..", "main.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        seen = []
        m._fallback = lambda tb: seen.append(tb)
        saved = sys.modules.get("pyea.ui")
        sys.modules["pyea.ui"] = None                                          # import pyea.ui -> ImportError
        try:
            m._run()
        finally:
            if saved is not None:
                sys.modules["pyea.ui"] = saved
            else:
                sys.modules.pop("pyea.ui", None)
        self.assertEqual(len(seen), 1)
        self.assertIn("pyea.ui", seen[0])
        self.assertIn("IMPORT LỖI", open(self.bl._path, encoding="utf-8").read())


class TestPreviousRunReport(unittest.TestCase):
    """Lần mở sau tự hiện «lần trước chết ở đâu» ngay trên màn hình - không bắt người dùng đi tìm file."""

    def setUp(self):
        from pyea import bootlog
        self.bl = bootlog
        self._p = bootlog._path
        bootlog._path = os.path.join(tempfile.mkdtemp(), "boot.log")

    def tearDown(self):
        self.bl._path = self._p

    def test_detects_unfinished_but_not_finished_or_already_reported(self):
        bl = self.bl
        self.assertIsNone(bl.previous_unfinished())                                   # chưa có gì
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("import pyea.ui OK")
        bl.crumb("build: tab «Biểu đồ» OK")
        prev = bl.previous_unfinished()                                               # chết giữa lúc dựng
        self.assertIn("tab «Biểu đồ» OK", prev)
        bl.mark_reported()
        self.assertIsNone(bl.previous_unfinished())                                   # đã báo: không báo lại
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("build: xong (trả root)")
        self.assertIsNone(bl.previous_unfinished())                                   # lần chạy tốt
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("build: tab «AI» LỖI")
        bl.crumb("build: xong (trả root)")
        self.assertIn("«AI» LỖI", bl.previous_unfinished())                           # dựng xong nhưng có tab lỗi: vẫn báo

    def test_main_shows_report_first_then_continues(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("pyea_main_under_test2", os.path.join(HERE, "..", "main.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        self.bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        self.bl.crumb("build: tab «Giao dịch» OK")
        shown = []
        m._fallback = lambda tb, title="", can_continue=False: shown.append((tb, can_continue)) or True
        saved = sys.modules.get("pyea.ui")
        sys.modules["pyea.ui"] = None                                                  # sau đó import lỗi -> fallback thứ hai
        try:
            m._run()
        finally:
            if saved is not None:
                sys.modules["pyea.ui"] = saved
            else:
                sys.modules.pop("pyea.ui", None)
        self.assertEqual(len(shown), 2)
        self.assertIn("Giao dịch", shown[0][0])
        self.assertTrue(shown[0][1])                                                   # có nút «Mở app»
        self.assertIn(self.bl.REPORTED_MARK, open(self.bl._path, encoding="utf-8").read())


class TestKeystoreCrashGuard(unittest.TestCase):
    """Android Keystore (pyjnius) làm app sập NATIVE trên máy thật -> mặc định khoá file; bật tay + chốt chặn."""

    def setUp(self):
        from pyea import keystore as K
        self.K = K
        self.d = tempfile.mkdtemp()
        self._on, self._cls = K._on_android, K.AndroidKeystoreBackend
        K._on_android = lambda: True
        self.tried = []

        class Fake:
            id = "ks"

            def __init__(s):
                self.tried.append(1)
                if getattr(self, "boom", False):
                    raise RuntimeError("boom")

            def encrypt(s, d):
                return d

            def decrypt(s, d):
                return d
        K.AndroidKeystoreBackend = Fake

    def tearDown(self):
        self.K._on_android, self.K.AndroidKeystoreBackend = self._on, self._cls

    def test_default_on_android_never_touches_keystore(self):
        box = self.K.SecretBox(self.d)
        self.assertEqual(self.tried, [])
        self.assertEqual(box.default.id, "file")

    def test_opt_in_works_and_clears_probe(self):
        open(os.path.join(self.d, ".ks_enable"), "w").close()
        box = self.K.SecretBox(self.d)
        self.assertEqual(self.tried, [1])
        self.assertEqual(box.default.id, "ks")
        self.assertFalse(os.path.exists(os.path.join(self.d, ".ks_probe")))

    def test_leftover_probe_means_native_crash_last_time_so_keystore_is_skipped(self):
        open(os.path.join(self.d, ".ks_enable"), "w").close()
        open(os.path.join(self.d, ".ks_probe"), "w").close()               # lần thử trước chết giữa chừng
        box = self.K.SecretBox(self.d)
        self.assertEqual(self.tried, [])
        self.assertEqual(box.default.id, "file")
        self.assertIn("làm app chết", box.note)

    def test_python_error_in_keystore_falls_back_and_clears_probe(self):
        open(os.path.join(self.d, ".ks_enable"), "w").close()
        self.boom = True
        box = self.K.SecretBox(self.d)
        self.assertEqual(box.default.id, "file")
        self.assertFalse(os.path.exists(os.path.join(self.d, ".ks_probe")))


class TestApiSection(unittest.TestCase):
    def test_pure_mapping(self):
        from pyea.settings import API_GROUPS, GLOBAL_INPUTS, api_keys_for, api_note
        self.assertEqual(api_keys_for("simulated"), set())
        self.assertIn("exness_api_key", api_keys_for("exness"))
        self.assertIn("live_confirm", api_keys_for("exness"))
        self.assertNotIn("api_key", api_keys_for("exness"))
        self.assertIsNone(api_keys_for("sàn-lạ"))                        # sàn lạ: hiện hết
        self.assertIn("giả lập", api_note("simulated"))
        # mọi khoá ô API thuộc nhóm API đều được một sàn nào đó hiển thị (không ô mồ côi)
        in_groups = {k for k, i in GLOBAL_INPUTS.items() if i.group in API_GROUPS}
        shown = set().union(*[api_keys_for(e) or set() for e in ("binance_spot", "binance_futures", "oanda", "capital", "exness", "metaapi", "mt5gw", "bridge", "ccxt")])
        self.assertEqual(in_groups - shown, set())

    def test_settings_form_has_one_collapsible_section_and_filters_by_exchange(self):
        import test_ui_smoke as T
        app = T.make_app()
        g = app.settings_tab.gform
        self.assertIsNotNone(g._sec_box)
        self.assertTrue(g._sec_open)                                     # luôn mở sẵn
        g.toggle_section()
        self.assertFalse(g._sec_open)
        g.toggle_section()
        self.assertTrue(g._sec_open)
        g.ctrl["exchange"].text = "exness"
        g._apply_visibility()                                            # Kivy thật tự gọi qua bind(text=...)
        self.assertGreater(g.rows["exness_api_key"].height, 0)
        self.assertEqual(g.rows["api_key"].height, 0)                    # ô Binance ẩn khi chọn Exness
        g.ctrl["exchange"].text = "binance_futures"
        g._apply_visibility()                                            # Kivy thật tự gọi qua bind(text=...)
        self.assertGreater(g.rows["api_key"].height, 0)
        self.assertEqual(g.rows["exness_api_key"].height, 0)
        g.ctrl["exchange"].text = "simulated"
        g._apply_visibility()                                            # Kivy thật tự gọi qua bind(text=...)
        self.assertTrue(all(r.height == 0 for r in g.rows.values()))
        g._toggle_all()
        self.assertTrue(all(r.height > 0 for r in g.rows.values()))
        # lưu vẫn đọc được mọi ô (kể cả ô đang ẩn)
        vals, errs = g.read()
        self.assertEqual(errs, [])
        self.assertIn("exness_api_key", vals)


class TestHistView(unittest.TestCase):
    def setUp(self):
        from pyea import brokerhist as bh
        from pyea.sdk import Trade
        self.bh, self.Trade = bh, Trade
        d = 86400.0
        base = 1_700_000_000.0
        self.res_deals = [
            {"id": "1", "time": base, "kind": "trade", "symbol": "XAUUSD", "side": "buy", "qty": 0.5, "price": 2000.0, "entry": "IN", "position_id": "9", "order_id": "o1", "comment": "bot1"},
            {"id": "2", "time": base + 100, "kind": "trade", "symbol": "XAUUSD", "side": "sell", "qty": 0.5, "price": 2010.0, "entry": "OUT", "position_id": "9", "order_id": "o2",
             "profit": 500.0, "commission": -3.5, "swap": -1.0, "comment": "bot1"},
            {"id": "3", "time": base + 2 * d, "kind": "trade", "symbol": "EURUSD", "side": "sell", "qty": 1.0, "price": 1.1, "entry": "IN", "position_id": "10", "order_id": "o3"},
            {"id": "4", "time": base + 2 * d + 60, "kind": "trade", "symbol": "EURUSD", "side": "buy", "qty": 1.0, "price": 1.12, "entry": "OUT", "position_id": "10", "order_id": "o4",
             "profit": -200.0},
            {"id": "5", "time": base + 3 * d, "kind": "balance", "profit": 1000.0},
        ]
        self.res = {"deals": self.res_deals, "positions": bh.positions_from_deals(self.res_deals)}
        self.base, self.d = base, d

    def test_broker_rows_three_tabs(self):
        from pyea import histview as H
        pos, deals, orders = H.positions_from_broker(self.res), H.deals_from_broker(self.res), H.orders_from_broker(self.res)
        self.assertEqual(len(pos), 2)
        self.assertEqual(len(deals), 4)                                    # deal nạp tiền không phải giao dịch
        self.assertEqual(len(orders), 4)
        xau = next(r for r in pos if r["symbol"] == "XAUUSD")
        self.assertEqual((xau["profit"], xau["price"], xau["price2"], xau["side"]), (500.0, 2000.0, 2010.0, "buy"))
        self.assertTrue(all(o["state"] == "Đã khớp" for o in orders))

    def test_filters_sort_totals(self):
        from pyea import histview as H
        pos = H.positions_from_broker(self.res)
        self.assertEqual(H.symbols_of(pos), ["EURUSD", "XAUUSD"])
        rows, tot = H.view({"positions": pos}, "positions", symbol="XAUUSD")
        self.assertEqual([r["symbol"] for r in rows], ["XAUUSD"])
        self.assertEqual(tot["profit"], 500.0)
        rows, tot = H.view({"positions": pos}, "positions", result="loss")
        self.assertEqual([r["profit"] for r in rows], [-200.0])
        rows, _ = H.view({"positions": pos}, "positions", sort="profit_asc")
        self.assertEqual([r["profit"] for r in rows], [-200.0, 500.0])
        rows, _ = H.view({"positions": pos}, "positions", sort="time_asc")
        self.assertEqual(rows[0]["symbol"], "XAUUSD")
        rows, _ = H.view({"positions": pos}, "positions", side="sell")             # vị thế EURUSD bán
        self.assertEqual([r["symbol"] for r in rows], ["EURUSD"])
        rows, tot = H.view({"positions": pos}, "positions", since=self.base + self.d, until=self.base + 3 * self.d)
        self.assertEqual([r["symbol"] for r in rows], ["EURUSD"])                  # chỉ nằm trong kỳ
        self.assertEqual(tot["count"], 1)
        _, tot = H.view({"positions": pos}, "positions")
        self.assertEqual((tot["count"], tot["wins"], tot["win_pct"], tot["profit"]), (2, 1, 50.0, 300.0))
        self.assertEqual(H.view({}, "deals")[1]["count"], 0)

    def test_local_trades_become_positions_and_two_deals_each(self):
        from pyea import histview as H
        t = self.Trade(1, "BTCUSD", "buy", 0.1, 100.0, 110.0, self.base, self.base + 60, 1.0, "TP", owner="")
        t2 = self.Trade(2, "BTCUSD", "sell", 0.1, 100.0, 90.0, self.base, self.base + 90, 1.0, "SL", owner="ma_cross")
        self.assertEqual([r["owner"] for r in H.positions_from_trades([t, t2])], ["thủ công", "ma_cross"])
        deals = H.deals_from_trades([t])
        self.assertEqual([(d["entry"], d["side"]) for d in deals], [("IN", "buy"), ("OUT", "sell")])
        self.assertEqual(deals[1]["profit"], 1.0)
        self.assertEqual(H.owners_of(H.positions_from_trades([t, t2])), ["ma_cross", "thủ công"])

    def test_custom_range(self):
        from pyea import histview as H
        a, b = H.custom_range("2026-10-01", "2026-10-31", 7 * 3600.0)
        self.assertEqual(b - a, 31 * 86400.0)
        a1, _ = H.custom_range("2026-10-01", "2026-10-02", 0.0)
        a2, _ = H.custom_range("2026-10-01", "2026-10-02", 7 * 3600.0)
        self.assertEqual(a1 - a2, 7 * 3600.0)                                      # 0h giờ VN sớm hơn 0h UTC 7 tiếng
        self.assertEqual(H.custom_range("", "2026-10-02", 0.0)[0], None)
        for bad in (("", ""), ("2026-10-05", "2026-10-01"), ("abc", "2026-10-01")):
            with self.assertRaises(ValueError):
                H.custom_range(*bad)


class TestChartOrder(unittest.TestCase):
    def test_classify_like_mt5(self):
        from pyea.chartorder import classify
        bid, ask = 100.0, 100.1
        self.assertEqual(classify("buy", 100.1, bid, ask), (None, "BUY"))
        self.assertEqual(classify("buy", 99.0, bid, ask), ("limit", "BUY LIMIT"))
        self.assertEqual(classify("buy", 101.0, bid, ask), ("stop", "BUY STOP"))
        self.assertEqual(classify("sell", 100.0, bid, ask), (None, "SELL"))
        self.assertEqual(classify("sell", 101.0, bid, ask), ("limit", "SELL LIMIT"))
        self.assertEqual(classify("sell", 99.0, bid, ask), ("stop", "SELL STOP"))
        self.assertEqual(classify("buy", 99.0, 0, 0), (None, "BUY"))          # chưa có giá: không suy ra loại chờ

    def test_validate_sides(self):
        from pyea.chartorder import validate
        bid, ask = 100.0, 100.1
        self.assertEqual(validate("buy", 100.1, 99.0, 102.0, bid, ask), "")
        self.assertIn("DƯỚI", validate("buy", 100.1, 101.0, 0, bid, ask))
        self.assertIn("TRÊN", validate("buy", 100.1, 0, 99.0, bid, ask))
        self.assertEqual(validate("sell", 100.0, 101.0, 98.0, bid, ask), "")
        self.assertIn("TRÊN", validate("sell", 100.0, 99.0, 0, bid, ask))
        self.assertIn("DƯỚI", validate("sell", 100.0, 0, 101.0, bid, ask))
        self.assertEqual(validate("buy", 95.0, 94.0, 99.0, bid, ask), "")          # buy limit: SL/TP so với GIÁ ĐẶT 95, không phải thị trường
        self.assertIn("DƯỚI", validate("buy", 95.0, 96.0, 99.0, bid, ask))
        self.assertIn("Chưa có giá", validate("buy", 95.0, 0, 0, 0, 0))

    def test_default_levels_and_pricemap_roundtrip(self):
        from pyea.chartorder import PriceMap, default_levels, nearest_line
        sl, tp = default_levels("buy", 100.0, 10.0)
        self.assertTrue(sl < 100.0 < tp)
        sl, tp = default_levels("sell", 100.0, 10.0)
        self.assertTrue(tp < 100.0 < sl)
        pm = PriceMap(y0=50.0, h=200.0, lo=90.0, hi=110.0)
        self.assertAlmostEqual(pm.price(pm.y(103.3)), 103.3)
        self.assertEqual(pm.price(-999), 90.0)                                       # kẹp trong vùng giá
        self.assertEqual(pm.price(9999), 110.0)
        lines = {"entry": 100.0, "sl": 95.0, "tp": 0.0}
        self.assertEqual(nearest_line(lines, pm.y(95.2), pm, 12.0), "sl")
        self.assertEqual(nearest_line(lines, pm.y(97.5), pm, 12.0), None)
        self.assertIsNone(nearest_line({"tp": 0.0}, pm.y(100), pm, 1e9))             # đường chưa đặt (0) không bắt được
