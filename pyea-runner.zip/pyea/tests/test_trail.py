"""Trailing Stop + Hòa vốn (như MT5): hàm thuần target_sl, kiểm luật, vòng tick thật qua TradingSession, lưu bền, IPC, giao diện."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

from pyea import trail as TR                                                      # noqa: E402
from pyea.trail import clean_rule, target_sl                                      # noqa: E402
from test_shell_gaps import make, tk                                              # noqa: E402


class TestCleanRule(unittest.TestCase):
    def test_valid_and_empty(self):
        self.assertEqual(clean_rule({"distance": "2", "be_at": 1}), {"distance": 2.0, "be_at": 1.0})
        self.assertIsNone(clean_rule(None))
        self.assertIsNone(clean_rule({"distance": 0, "be_at": ""}))
        self.assertIsNone(clean_rule({}))

    def test_bad_values(self):
        for bad in ({"distance": "abc"}, {"distance": -1}, {"distance": float("nan")}, {"distance": float("inf")},
                    {"start": 1}, {"step": 1}, {"be_offset": 1}, {"distance": 1, "be_offset": 1}):
            with self.assertRaises(ValueError, msg=str(bad)):
                clean_rule(bad)


class TestTargetSl(unittest.TestCase):
    def test_buy_trails_up_only(self):
        r = {"distance": 2.0, "step": 0.0}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 101.0, 101.1))            # chưa lãi đủ khoảng (start = distance)
        self.assertEqual(target_sl(r, "buy", 100, 0, 103.0, 103.1), 101.0)
        self.assertEqual(target_sl(r, "buy", 100, 101.0, 105.0, 105.1), 103.0)
        self.assertIsNone(target_sl(r, "buy", 100, 103.0, 104.0, 104.1))        # giá lùi: không kéo SL xuống
        self.assertIsNone(target_sl(r, "buy", 100, 103.0, 105.0, 105.1))        # bằng mức cũ: không đổi

    def test_sell_mirror_uses_ask(self):
        r = {"distance": 2.0, "step": 0.0}
        self.assertEqual(target_sl(r, "sell", 100, 0, 96.9, 97.0), 99.0)
        self.assertEqual(target_sl(r, "sell", 100, 99.0, 94.9, 95.0), 97.0)
        self.assertIsNone(target_sl(r, "sell", 100, 97.0, 96.0, 96.1))

    def test_start_and_step(self):
        r = {"distance": 1.0, "start": 3.0, "step": 0.5}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 102.5, 102.6))            # lãi 2.5 < start 3
        self.assertEqual(target_sl(r, "buy", 100, 0, 103.0, 103.1), 102.0)
        self.assertIsNone(target_sl(r, "buy", 100, 102.0, 103.3, 103.4))        # mới tiến 0.3 < step 0.5
        self.assertEqual(target_sl(r, "buy", 100, 102.0, 103.6, 103.7), 102.6)

    def test_default_step_is_ten_percent_of_distance(self):
        r = {"distance": 10.0}
        self.assertIsNone(target_sl(r, "buy", 100, 100.0, 110.5, 110.6))        # cand 100.5 - 100 = 0.5 < 1.0
        self.assertEqual(target_sl(r, "buy", 100, 100.0, 111.5, 111.6), 101.5)

    def test_break_even_with_offset_and_best_of_both(self):
        r = {"be_at": 1.0, "be_offset": 0.2}
        self.assertIsNone(target_sl(r, "buy", 100, 0, 100.9, 101.0))
        self.assertEqual(target_sl(r, "buy", 100, 90.0, 101.0, 101.1), 100.2)
        self.assertEqual(target_sl(r, "sell", 100, 110.0, 98.9, 99.0), 99.8)
        self.assertIsNone(target_sl(r, "buy", 100, 100.5, 102.0, 102.1))        # SL đã tốt hơn hòa vốn
        both = {"be_at": 1.0, "distance": 5.0, "step": 0.0}
        self.assertEqual(target_sl(both, "buy", 100, 90.0, 102.0, 102.1), 100.0)    # chưa đủ start 5: chỉ hòa vốn
        self.assertEqual(target_sl(both, "buy", 100, 100.0, 110.0, 110.1), 105.0)   # trailing tốt hơn hòa vốn

    def test_sl_must_be_on_loss_side_and_bad_prices(self):
        self.assertIsNone(target_sl({"be_at": 1.0, "be_offset": 5.0}, "buy", 100, 0, 101.0, 101.1))   # BE+offset >= giá: SL sẽ chạm ngay -> bỏ
        self.assertIsNone(target_sl({"distance": 1.0}, "buy", 100, 0, 0, 0))
        self.assertIsNone(target_sl(None, "buy", 100, 0, 110, 110))


class TestSessionTrailing(unittest.TestCase):
    def setUp(self):
        self._mi = TR.MIN_INTERVAL
        TR.MIN_INTERVAL = 0.0

    def tearDown(self):
        TR.MIN_INTERVAL = self._mi

    def open_buy(self, s, **kw):
        tk(s, "BTCUSD", 100.0, 100.0, 1000.0)
        r = s.open_position("BTCUSD", "buy", 1.0, **kw)
        self.assertTrue(r.ok, r.message)
        return next(iter(s.account.positions))

    def test_sl_follows_price_up_and_closes_on_pullback(self):
        s = make()
        pid = self.open_buy(s)
        ok, msg = s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        self.assertTrue(ok, msg)
        tk(s, "BTCUSD", 101.0, 101.0, 1001.0)
        self.assertEqual(s.account.positions[pid].sl, 0.0)
        tk(s, "BTCUSD", 104.0, 104.0, 1002.0)
        self.assertEqual(s.account.positions[pid].sl, 102.0)
        tk(s, "BTCUSD", 106.0, 106.0, 1003.0)
        self.assertEqual(s.account.positions[pid].sl, 104.0)
        tk(s, "BTCUSD", 105.0, 105.0, 1004.0)
        self.assertEqual(s.account.positions[pid].sl, 104.0)                     # lùi: giữ nguyên
        tk(s, "BTCUSD", 103.9, 103.9, 1005.0)                                    # chạm SL
        self.assertNotIn(pid, s.account.positions)
        self.assertIn(s.account.trades[-1].reason, ("sl", "Stop Loss"))
        self.assertGreater(s.account.trades[-1].profit, 0)                       # chốt lãi nhờ trailing
        self.assertEqual(s.trail_rules(), {})                                    # vị thế đóng -> luật bị xoá (xoá ở tick sau)

    def test_rule_cleanup_after_close_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            s = make()
            s.state_file = os.path.join(d, "state.json")
            s._trail_init()
            pid = self.open_buy(s)
            self.assertTrue(s.set_trailing(pid, {"be_at": 1.0, "be_offset": 0.1})[0])
            self.assertTrue(os.path.exists(os.path.join(d, "trails.json")))
            s2 = make()
            s2.state_file = os.path.join(d, "state.json")
            s2._trail_init()
            self.assertEqual(s2.trail_rules(), {pid: {"be_at": 1.0, "be_offset": 0.1}})
            s.close_position(pid, "manual", "x")
            tk(s, "BTCUSD", 100.0, 100.0, 1010.0)
            self.assertEqual(s.trail_rules(), {})

    def test_set_and_clear_validation(self):
        s = make()
        pid = self.open_buy(s)
        self.assertFalse(s.set_trailing(999, {"distance": 1})[0])
        ok, msg = s.set_trailing(pid, {"distance": "x"})
        self.assertFalse(ok)
        self.assertIn("không phải số", msg)
        self.assertEqual(s.trail_rules(), {})
        self.assertTrue(s.set_trailing(pid, {"distance": 1})[0])
        self.assertTrue(s.set_trailing(pid, None)[0])
        self.assertEqual(s.trail_rules(), {})

    def test_sell_position_and_break_even_then_native_modify_is_used(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0, 1000.0)
        pid = None
        r = s.open_position("BTCUSD", "sell", 1.0)
        self.assertTrue(r.ok)
        pid = next(iter(s.account.positions))
        s.set_trailing(pid, {"be_at": 2.0, "be_offset": 0.5})
        tk(s, "BTCUSD", 97.0, 97.0, 1001.0)
        self.assertEqual(s.account.positions[pid].sl, 99.5)

    def test_rejected_modify_is_retried_and_warned_not_crashing(self):
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        calls = []
        orig = s.modify_position

        def bad(*a, **k):
            calls.append(a)
            from pyea.sdk import OrderResult, Ret
            return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message="stops_level")
        s.modify_position = bad
        tk(s, "BTCUSD", 105.0, 105.0, 1001.0)
        tk(s, "BTCUSD", 106.0, 106.0, 1002.0)
        self.assertEqual(len(calls), 2)                                          # thử lại ở tick sau
        self.assertEqual(sum(1 for _, _, lv, m in s.logs if "Trailing" in m and lv == "WARN"), 1)   # chỉ cảnh báo 1 lần/phút
        s.modify_position = orig

    def test_min_interval_throttles(self):
        TR.MIN_INTERVAL = 3600.0
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0, "step": 0.0})
        tk(s, "BTCUSD", 104.0, 104.0, 1001.0)
        tk(s, "BTCUSD", 110.0, 110.0, 1002.0)
        self.assertEqual(s.account.positions[pid].sl, 102.0)                     # lần 2 bị giãn nhịp

    def test_snapshot_carries_trails(self):
        s = make()
        pid = self.open_buy(s)
        s.set_trailing(pid, {"distance": 2.0})
        self.assertEqual(s.snapshot()["trails"], {pid: {"distance": 2.0}})


class TestUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_modify_dialog_saves_a_rule_through_the_controller(self):
        import test_ui_smoke as T
        app = T.make_app()
        calls = []
        class Ctl:
            def set_trailing(self, pid, rule):
                calls.append((pid, rule))
                return True, "ok"

            def modify_position(self, *a, **k):
                return True
        app.ctl = Ctl()
        from pyea.sdk import Position
        pos = Position(7, "BTCUSD", "buy", 1.0, 100.0, 1000.0)
        app.last_snap = {"positions": [pos], "trails": {}}
        app.open_modify_dialog(7)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[-2].text, ins[-1].text = "2", "1"                                    # Trailing, Hòa vốn
        T.press(dlg.content, "Lưu")
        self.assertEqual(calls, [(7, {"distance": 2.0, "be_at": 1.0})])
        # nhập sai -> không gửi, báo trong hộp
        calls.clear()
        app.open_modify_dialog(7)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[-2].text = "-5"
        T.press(dlg.content, "Lưu")
        self.assertEqual(calls, [])


class TestIpc(unittest.TestCase):
    def test_client_validates_before_sending(self):
        from pyea.ipc import ServiceHandle as ServiceController
        sent = []

        class C:
            def send(self, cmd, **kw):
                sent.append((cmd, kw))
        ctl = ServiceController.__new__(ServiceController)
        ctl.client = C()
        self.assertFalse(ctl.set_trailing(1, {"distance": "x"})[0])
        self.assertEqual(sent, [])
        self.assertTrue(ctl.set_trailing(1, {"distance": 2})[0])
        self.assertEqual(sent, [("trail", {"pos_id": 1, "rule": {"distance": 2}})])


if __name__ == "__main__":
    unittest.main()


class TestSafeBoot(unittest.TestCase):
    """Lỗi lúc dựng giao diện không được làm app văng ra ngoài: hiện lỗi trên màn hình."""

    def test_one_broken_tab_does_not_kill_the_app(self):
        import test_ui_smoke as T
        from pyea import ui
        orig = ui.MarketTab

        class Boom:
            def __init__(self, *a, **k):
                raise RuntimeError("hỏng-giả-lập")
        ui.MarketTab = Boom
        try:
            app = T.make_app()
        finally:
            ui.MarketTab = orig
        self.assertIsInstance(app.market_tab, ui._BrokenTab)
        self.assertIsNone(app.market_tab.refresh({}))                 # lời gọi vào tab hỏng là no-op
        self.assertIn("settings", app.tabs)                             # các tab còn lại vẫn có
        self.assertTrue(os.path.exists(app.store.crash_path))
        self.assertIn("hỏng-giả-lập", open(app.store.crash_path, encoding="utf-8").read())

    def test_total_failure_returns_an_error_screen_with_the_traceback(self):
        import tempfile
        from pyea import ui
        app = ui.PyEAApp()
        app.user_data_dir = tempfile.mkdtemp()
        app._build_main = lambda: (_ for _ in ()).throw(ValueError("sập-toàn-bộ"))
        root = app.build()
        self.assertIsNotNone(root)
        self.assertTrue(os.path.exists(os.path.join(app.user_data_dir, "crash.log")))
        self.assertIn("sập-toàn-bộ", open(os.path.join(app.user_data_dir, "crash.log"), encoding="utf-8").read())


class TestErrorReporting(unittest.TestCase):
    def test_share_falls_back_to_clipboard_and_diag_text_puts_crash_first(self):
        import tempfile
        import zipfile
        from pyea import android_utils, ui, ui_shell
        self.assertFalse(android_utils.share_text("x"))                 # ngoài Android: False -> caller dùng clipboard
        app = ui.PyEAApp()
        copied, toasts = [], []
        ui.Clipboard.copy = lambda t: copied.append(t)
        app.toast = lambda m: toasts.append(m)
        self.assertFalse(app.share_report("LỖI-ABC"))
        self.assertEqual(copied, ["LỖI-ABC"])
        self.assertTrue(toasts)
        d = tempfile.mkdtemp()
        zp = os.path.join(d, "x.zip")
        with zipfile.ZipFile(zp, "w") as z:
            z.writestr("settings.json", "{\"a\": 1}")
            z.writestr("crash.log", "TRACEBACK-XYZ")
        txt = ui_shell._diag_text(zp, "version=1.9.6")
        self.assertLess(txt.index("TRACEBACK-XYZ"), txt.index("settings.json"))
        self.assertIn("version=1.9.6", txt)
        self.assertIn("không đọc được", ui_shell._diag_text(os.path.join(d, "none.zip"), "v"))


class TestBootLog(unittest.TestCase):
    def setUp(self):
        from pyea import bootlog
        self.bl = bootlog
        self._p, self._fh = bootlog._path, bootlog._fh
        self.d = tempfile.mkdtemp()
        bootlog._path = os.path.join(self.d, "boot.log")

    def tearDown(self):
        self.bl._path, self.bl._fh = self._p, self._fh

    def test_crumb_appends_and_never_raises(self):
        self.bl.crumb("mốc-1")
        self.bl.crumb("mốc-2")
        txt = open(self.bl._path, encoding="utf-8").read()
        self.assertIn("mốc-1", txt)
        self.assertLess(txt.index("mốc-1"), txt.index("mốc-2"))
        self.bl._path = os.path.join(self.d, "không", "có", "\0bad")           # đường dẫn hỏng: không ném lỗi
        self.bl.crumb("x")

    def test_path_truncates_big_file(self):
        self.bl._path = None
        p = os.path.join(self.d, "boot.log")
        with open(p, "wb") as f:
            f.write(b"A" * (self.bl.MAX_BYTES + 5000))
        orig = self.bl._candidates
        self.bl._candidates = lambda: iter([self.d])
        try:
            self.assertEqual(self.bl.path(), p)
        finally:
            self.bl._candidates = orig
        self.assertLessEqual(os.path.getsize(p), self.bl.MAX_BYTES)

    def test_main_import_failure_shows_fallback_instead_of_dying(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("pyea_main_under_test", os.path.join(HERE, "..", "main.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        seen = []
        m._fallback = lambda tb: seen.append(tb)
        saved = sys.modules.get("pyea.ui")
        sys.modules["pyea.ui"] = None                                          # import pyea.ui -> ImportError
        try:
            m._run()
        finally:
            if saved is not None:
                sys.modules["pyea.ui"] = saved
            else:
                sys.modules.pop("pyea.ui", None)
        self.assertEqual(len(seen), 1)
        self.assertIn("pyea.ui", seen[0])
        self.assertIn("IMPORT LỖI", open(self.bl._path, encoding="utf-8").read())


class TestPreviousRunReport(unittest.TestCase):
    """Lần mở sau tự hiện «lần trước chết ở đâu» ngay trên màn hình - không bắt người dùng đi tìm file."""

    def setUp(self):
        from pyea import bootlog
        self.bl = bootlog
        self._p = bootlog._path
        bootlog._path = os.path.join(tempfile.mkdtemp(), "boot.log")

    def tearDown(self):
        self.bl._path = self._p

    def test_detects_unfinished_but_not_finished_or_already_reported(self):
        bl = self.bl
        self.assertIsNone(bl.previous_unfinished())                                   # chưa có gì
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("import pyea.ui OK")
        bl.crumb("build: tab «Biểu đồ» OK")
        prev = bl.previous_unfinished()                                               # chết giữa lúc dựng
        self.assertIn("tab «Biểu đồ» OK", prev)
        bl.mark_reported()
        self.assertIsNone(bl.previous_unfinished())                                   # đã báo: không báo lại
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("build: xong (trả root)")
        self.assertIsNone(bl.previous_unfinished())                                   # lần chạy tốt
        bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        bl.crumb("build: tab «AI» LỖI")
        bl.crumb("build: xong (trả root)")
        self.assertIn("«AI» LỖI", bl.previous_unfinished())                           # dựng xong nhưng có tab lỗi: vẫn báo

    def test_main_shows_report_first_then_continues(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("pyea_main_under_test2", os.path.join(HERE, "..", "main.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        self.bl.crumb("=== main.py bắt đầu (Python 3.11) ===")
        self.bl.crumb("build: tab «Giao dịch» OK")
        shown = []
        m._fallback = lambda tb, title="", can_continue=False: shown.append((tb, can_continue)) or True
        saved = sys.modules.get("pyea.ui")
        sys.modules["pyea.ui"] = None                                                  # sau đó import lỗi -> fallback thứ hai
        try:
            m._run()
        finally:
            if saved is not None:
                sys.modules["pyea.ui"] = saved
            else:
                sys.modules.pop("pyea.ui", None)
        self.assertEqual(len(shown), 2)
        self.assertIn("Giao dịch", shown[0][0])
        self.assertTrue(shown[0][1])                                                   # có nút «Mở app»
        self.assertIn(self.bl.REPORTED_MARK, open(self.bl._path, encoding="utf-8").read())
