"""1.9.43: phát lại lần backtest đã xong - cắt lát dữ liệu theo nến, không đổi kết quả, giao diện ▶/⏸/lùi/tiến/thoát."""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

import test_costs_wf as W                                                      # noqa: E402
import test_ui_smoke as T                                                      # noqa: E402
from pyea.backtest import run_backtest                                         # noqa: E402
from pyea.replay import Replay                                                 # noqa: E402


def result(n=80):
    return run_backtest(W.HOLD_PATH, {"lot": 1.0, "side": "buy"}, W.S(), "TEST", "5m", W.flat(n), 10, "open")


class TestReplayLogic(unittest.TestCase):
    def test_start_after_warmup_and_frames_grow(self):
        r = result()
        rp = Replay(r)
        self.assertGreaterEqual(rp.start, 2)
        self.assertEqual(rp.pos, rp.start)
        cs0, _, ev0, eq0 = rp.frame()
        rp.step(20)
        cs1, _, ev1, eq1 = rp.frame()
        self.assertEqual(len(cs1), len(cs0) + 20)
        self.assertGreaterEqual(len(eq1), len(eq0))
        self.assertGreaterEqual(len(ev1), len(ev0))

    def test_end_equals_full_result_and_seek_clamps(self):
        r = result()
        rp = Replay(r)
        rp.seek(10 ** 9)
        self.assertTrue(rp.done)
        cs, _, evs, eq = rp.frame()
        self.assertEqual(len(cs), len(r.candles))
        self.assertEqual(len(evs), len(r.events))
        self.assertEqual(eq, [p[2] for p in r.curve])
        rp.seek(-5)
        self.assertEqual(rp.pos, rp.start)

    def test_events_never_ahead_of_visible_candle(self):
        r = result()
        rp = Replay(r)
        for pos in range(rp.start, rp.n + 1, 7):
            rp.seek(pos)
            cs, _, evs, _ = rp.frame()
            self.assertTrue(all(e.time <= cs[-1].time for e in evs))

    def test_replay_does_not_mutate_result(self):
        r = result()
        before = (len(r.candles), len(r.events), len(r.curve), dict(r.report))
        rp = Replay(r)
        rp.seek(30)
        rp.frame()
        self.assertEqual(before, (len(r.candles), len(r.events), len(r.curve), dict(r.report)))


class TestReplayUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()
        del kivy_stub.SCHEDULED[:]

    def test_toggle_step_exit(self):
        app = T.make_app()
        bt = app.bt_tab
        bt.replay_toggle()                                          # chưa có kết quả
        self.assertIsNone(bt._replay)
        bt.res = result()
        bt._speed_val = 0.0
        bt.replay_toggle()
        self.assertTrue(bt._replay_playing)
        self.assertEqual(bt.replay_btn.text, "⏸ Dừng")
        p0 = bt._replay.pos
        bt._replay_tick()
        self.assertGreater(bt._replay.pos, p0)
        self.assertIn("Phát lại", bt.prog.text)
        bt.replay_toggle()                                          # tạm dừng
        self.assertFalse(bt._replay_playing)
        p1 = bt._replay.pos
        bt.replay_step(-3)
        self.assertEqual(bt._replay.pos, max(bt._replay.start, p1 - 3))
        bt.replay_step(10 ** 6)
        self.assertTrue(bt._replay.done)
        bt.replay_exit()
        self.assertIsNone(bt._replay)
        self.assertEqual(len(bt.panel.chart.candles), len(bt.res.candles))   # trả về toàn bộ kết quả

    def test_play_to_end_resets_button(self):
        app = T.make_app()
        bt = app.bt_tab
        bt.res = result(40)
        bt._speed_val = 0.0
        bt.replay_toggle()
        for _ in range(500):
            if bt._replay_tick() is False:
                break
        self.assertTrue(bt._replay.done)
        self.assertEqual(bt.replay_btn.text, "▶ Phát lại")


if __name__ == "__main__":
    unittest.main()
