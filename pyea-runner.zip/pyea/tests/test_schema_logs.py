"""An toàn dữ liệu: che bí mật (redact), phiên bản định dạng dữ liệu (schema), xoay vòng/cắt nhật ký (logrot)."""
import json
import os
import sys
import tempfile
import time
import unittest
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import ai, logrot, prefs, redact, schema                      # noqa: E402
from pyea.settings import default_settings                              # noqa: E402
from pyea.storage import Store                                          # noqa: E402
from test_shell_gaps import log_levels, make                            # noqa: E402


class TestRedact(unittest.TestCase):
    def setUp(self):
        redact.learn([])

    def test_provider_key_prefixes_and_pairs(self):
        t = redact.redact('lỗi 401: sk-abcdefghijklmnopqrstuvwx hoặc AIza' + "A1" * 20 + ' | api_key = "abcd1234efgh5678ijkl"')
        self.assertNotIn("sk-abcdef", t)
        self.assertNotIn("AIzaA1", t)
        self.assertNotIn("abcd1234efgh", t)
        self.assertIn("lỗi 401", t)

    def test_json_bearer_and_pem(self):
        t = redact.redact('{"apiKey":"SECRETVALUE","price":"1.1"} Authorization: Bearer abcdefghijklmnop12345')
        self.assertNotIn("SECRETVALUE", t)
        self.assertNotIn("abcdefghijklmnop12345", t)
        self.assertIn('"price":"1.1"', t)
        pem = "-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIPrivateBodyPrivateBodyPrivateBody\n-----END PRIVATE KEY-----"
        self.assertNotIn("PrivateBody", redact.redact("khoá của tôi:\n" + pem + "\nxong"))

    def test_known_secrets_are_masked_exactly_even_if_short_and_plain(self):
        redact.learn(["hunter2hunter2"])
        self.assertEqual(redact.redact("pass là hunter2hunter2 nhé"), "pass là *** nhé")
        redact.learn(["short"])                                       # < MIN_KNOWN: quá dễ trùng chữ thường -> bỏ qua
        self.assertEqual(redact.redact("a short word"), "a short word")

    def test_code_and_long_identifiers_survive_in_default_mode(self):
        code = "def a_very_long_function_name_that_is_longer_than_forty_chars(): return self.p.api_key\nsecret = get_secret(name)"
        self.assertEqual(redact.redact(code), code)
        self.assertIn("***", redact.redact("x" * 60, aggressive=True))
        self.assertEqual(redact.redact("x" * 60), "x" * 60)

    def test_redact_obj_walks_nested(self):
        o = redact.redact_obj({"a": ["sk-abcdefghijklmnopqrstuvwx", {"b": "ok"}], "n": 5})
        self.assertEqual(o["a"][1], {"b": "ok"})
        self.assertNotIn("sk-abcdef", json.dumps(o))
        self.assertEqual(o["n"], 5)

    def test_prefs_apply_learns_settings_secrets(self):
        prefs.apply(dict(default_settings(), api_secret="TopSecretValue123"))
        self.assertNotIn("TopSecretValue123", redact.redact("lỗi ký: TopSecretValue123"))

    def test_session_log_and_events_never_contain_known_secret(self):
        prefs.apply(dict(default_settings(), api_secret="TopSecretValue123"))
        with tempfile.TemporaryDirectory() as d:
            s = make()
            s.log_file = os.path.join(d, "x.log")
            s.log("bot in ra khoá TopSecretValue123 và sk-abcdefghijklmnopqrstuvwx")
            self.assertNotIn("TopSecretValue123", log_levels(s)[-1][1])
            body = open(s.log_file, encoding="utf-8").read()
            self.assertNotIn("TopSecretValue123", body)
            self.assertNotIn("sk-abcdef", body)
            ev = s.add_event("note", "BTCUSD", 1.0, reason="khoá TopSecretValue123")
            self.assertNotIn("TopSecretValue123", ev.reason)

    def test_chat_log_and_ai_prompt_are_clean(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(d)
            prefs.apply(default_settings())
            sent = {}
            hub = ai.AIHub(store, lambda: {}, lambda: ("b", "API_KEY = 'sk-abcdefghijklmnopqrstuvwx'\nprint(1)", {}), lambda: default_settings())
            m = hub.add_message("user", "key của tôi là sk-abcdefghijklmnopqrstuvwx, sửa giúp")
            self.assertNotIn("sk-abcdef", m["text"])
            self.assertNotIn("sk-abcdef", open(store.chat.path, encoding="utf-8").read())
            orig = ai.chat_completion
            ai.chat_completion = lambda agent, msgs, mt: sent.setdefault("msgs", msgs) and "ok"
            try:
                hub._turn({"name": "A", "api_key": "k"}, False, [], True)
            finally:
                ai.chat_completion = orig
            self.assertNotIn("sk-abcdef", json.dumps(sent["msgs"]))

    def test_agent_keys_are_learned_from_store(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(d)
            store.save_agents([{"name": "A", "api_key": "plainAgentKey0001", "url": "u", "model": "m"}])
            ai.AIHub(store, lambda: {}, lambda: None, lambda: default_settings())
            self.assertNotIn("plainAgentKey0001", redact.redact("dùng plainAgentKey0001 đi"))


class TestSchema(unittest.TestCase):
    def test_fresh_dir_is_stamped_without_backup(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            self.assertEqual(st.schema_info["status"], "new")
            self.assertEqual(schema.read_marker(d), schema.CURRENT)
            self.assertFalse(os.path.exists(os.path.join(d, "migrate_backup")))

    def test_legacy_data_is_backed_up_then_migrated_once(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "settings.json"), "w") as f:
                json.dump({"mode": "paper"}, f)
            calls = []
            mig = {0: lambda base: calls.append(0) or "đổi A", 1: lambda base: calls.append(1) or "đổi B"}
            r = schema.migrate(d, current=2, migrations=mig)
            self.assertEqual((r["status"], r["found"], calls), ("migrated", 0, [0, 1]))
            self.assertEqual(r["notes"], ["đổi A", "đổi B"])
            self.assertTrue(os.path.isfile(os.path.join(d, "migrate_backup", "v0", "settings.json")))
            self.assertTrue(os.path.isfile(os.path.join(d, "migrate_backup", "v1", "settings.json")))
            self.assertEqual(schema.read_marker(d), 2)
            self.assertEqual(schema.migrate(d, current=2, migrations=mig)["status"], "ok")
            self.assertEqual(calls, [0, 1])                           # lần hai không chạy lại

    def test_failing_migration_keeps_marker_and_data(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "settings.json"), "w") as f:
                json.dump({"mode": "paper"}, f)

            def boom(base):
                raise RuntimeError("hỏng")
            r = schema.migrate(d, current=1, migrations={0: boom})
            self.assertEqual(r["status"], "failed")
            self.assertEqual(schema.read_marker(d), 0)
            self.assertEqual(json.load(open(os.path.join(d, "settings.json"))), {"mode": "paper"})

    def test_newer_data_dir_is_not_touched(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, schema.MARKER), "w") as f:
                json.dump({"schema": 99}, f)
            r = schema.migrate(d)
            self.assertEqual(r["status"], "too_new")
            self.assertEqual(schema.read_marker(d), 99)               # không hạ dấu xuống

    def test_settings_roundtrip_has_stamp_on_disk_but_not_in_memory(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.save_settings(dict(default_settings(), mode="paper", initial_balance=777.0))
            self.assertEqual(json.load(open(st.settings_path))["_schema"], schema.CURRENT)
            got = st.load_settings()
            self.assertEqual(got["initial_balance"], 777.0)
            self.assertNotIn("_schema", got)

    def test_settings_from_newer_app_are_set_aside_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            with open(st.settings_path, "w") as f:
                json.dump({"_schema": schema.CURRENT + 1, "initial_balance": 555.0, "future_key": 1}, f)
            got = st.load_settings()
            self.assertEqual(got["initial_balance"], default_settings()["initial_balance"])
            baks = [n for n in os.listdir(d) if n.startswith("settings.json.v")]
            self.assertEqual(len(baks), 1)
            self.assertEqual(json.load(open(os.path.join(d, baks[0])))["future_key"], 1)
            self.assertTrue(st.schema_notes)

    def test_prefs_roundtrip_and_newer_prefs(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.save_prefs({"tab": "bot"})
            self.assertEqual(st.load_prefs(), {"tab": "bot"})
            with open(st.prefs_path, "w") as f:
                json.dump({"_schema": 50, "tab": "x"}, f)
            self.assertEqual(st.load_prefs(), {})
            self.assertTrue(any(n.startswith("ui_prefs.json.v50") for n in os.listdir(d)))

    def test_session_state_is_stamped_and_newer_state_not_restored(self):
        with tempfile.TemporaryDirectory() as d:
            s = make()
            s.state_file = os.path.join(d, "session_state.json")
            s.events_file = None
            s._save_state()
            data = json.load(open(s.state_file))
            self.assertEqual(data["_schema"], schema.CURRENT)
            data["_schema"] = schema.CURRENT + 3
            data["account"]["balance"] = 1.23
            json.dump(data, open(s.state_file, "w"))
            s2 = make()
            s2.state_file, s2.events_file = s.state_file, None
            s2._load_state()
            self.assertNotEqual(s2.account.balance, 1.23)
            self.assertTrue(any(lv == "WARN" and "mới hơn" in m for lv, m in log_levels(s2)))
            self.assertFalse(os.path.exists(s.state_file))
            self.assertTrue(any(n.startswith("session_state.json.v") for n in os.listdir(d)))

    def test_backup_records_schema_and_refuses_newer(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.save_settings(default_settings())
            z = st.export_backup()
            self.assertIn("schema=%d" % schema.CURRENT, zipfile.ZipFile(z).read("BACKUP_INFO.txt").decode())
            bad = os.path.join(d, "newer.zip")
            with zipfile.ZipFile(bad, "w") as zf:
                zf.writestr("BACKUP_INFO.txt", "x\nschema=%d\n" % (schema.CURRENT + 1))
                zf.writestr("settings.json", "{}")
            with self.assertRaises(ValueError):
                st.import_backup(bad)
            self.assertEqual(st.import_backup(z)[0] > 0, True)


class TestLogRotation(unittest.TestCase):
    def test_prune_by_age_and_total_size(self):
        with tempfile.TemporaryDirectory() as d:
            now = time.time()
            for i, age in enumerate((40, 20, 3, 1)):
                p = os.path.join(d, "2026010%d.log" % (i + 1))
                open(p, "w").write("x" * 1000)
                os.utime(p, (now - age * 86400, now - age * 86400))
            open(os.path.join(d, "notes.txt"), "w").write("giữ")
            self.assertEqual(logrot.prune_daily_logs(d, keep_days=14, now=now), 2)
            self.assertEqual(sorted(n for n in os.listdir(d) if n.endswith(".log")), ["20260103.log", "20260104.log"])
            self.assertEqual(logrot.prune_daily_logs(d, keep_days=14, max_total=1500, now=now), 1)     # tổng 2000 > 1500: xoá file cũ nhất
            self.assertEqual(sorted(n for n in os.listdir(d) if n.endswith(".log")), ["20260104.log"])
            self.assertIn("notes.txt", os.listdir(d))

    def test_rotate_keeps_n_generations(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "a.log")
            for gen in "123":
                open(p, "w").write(gen * 100)
                self.assertTrue(logrot.rotate_if_big(p, max_bytes=50, keep=2))
            self.assertFalse(os.path.exists(p))
            self.assertEqual(open(p + ".1").read(), "3" * 100)
            self.assertEqual(open(p + ".2").read(), "2" * 100)
            self.assertFalse(os.path.exists(p + ".3"))
            open(p, "w").write("ok")
            self.assertFalse(logrot.rotate_if_big(p, max_bytes=50))

    def test_trim_jsonl_keeps_tail_whole_lines(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "chat.jsonl")
            with open(p, "wb") as f:
                for i in range(100):
                    f.write(json.dumps({"i": i}).encode() + b"\n")
                f.write(b'{"i": 100')                                   # dòng cuối chưa ghi xong
            dropped = logrot.trim_jsonl(p, max_bytes=100, keep_lines=10)
            rows = [json.loads(x) for x in open(p, "rb").read().splitlines()]
            self.assertEqual([r["i"] for r in rows], list(range(90, 100)))
            self.assertGreater(dropped, 80)
            self.assertEqual(logrot.trim_jsonl(p, max_bytes=10 ** 6, keep_lines=10), 0)

    def test_maintain_trim_false_leaves_chat_for_live_readers(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            with open(st.chat.path, "wb") as f:
                for i in range(3000):
                    f.write(json.dumps({"i": i, "pad": "x" * 900}).encode() + b"\n")
            size = os.path.getsize(st.chat.path)
            st.maintain(trim=False)
            self.assertEqual(os.path.getsize(st.chat.path), size)
            st.maintain(trim=True)
            self.assertLess(os.path.getsize(st.chat.path), size)
            self.assertEqual(len(st.chat.read_from(0)[0]), 1500)

    def test_session_rotates_oversized_daily_log(self):
        with tempfile.TemporaryDirectory() as d:
            s = make()
            s.log_file = os.path.join(d, "20260101.log")
            with open(s.log_file, "w") as f:
                f.write("x" * (5 * 1024 * 1024 + 10))
            for i in range(201):
                s.log("dòng %d" % i)
            self.assertTrue(os.path.exists(s.log_file + ".1"))
            self.assertLess(os.path.getsize(s.log_file), 100000)


if __name__ == "__main__":
    unittest.main()
