"""Hỗ trợ & pháp lý: kiểm tra cập nhật (GitHub Releases giả), gửi báo lỗi tự động (máy chủ giả, che bí mật, chỉ phần mới), EULA/giới thiệu/cài đặt mẫu."""
import json
import os
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import crashsend, legal, updater                      # noqa: E402
from pyea.settings import default_settings                      # noqa: E402


class Srv:
    def __init__(self, handler):
        self.httpd = HTTPServer(("127.0.0.1", 0), handler)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def releases_handler(state):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            state["calls"].append((self.path, self.headers.get("User-Agent")))
            code, body = state["resp"]
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(body).encode())
    return H


class TestUpdater(unittest.TestCase):
    def setUp(self):
        self.state = {"calls": [], "resp": (200, {})}
        self.srv = Srv(releases_handler(self.state))
        self.base = "http://127.0.0.1:%d" % self.srv.port

    def tearDown(self):
        self.srv.close()

    def test_version_compare(self):
        self.assertEqual(updater.parse_version("v1.9.13"), (1, 9, 13))
        self.assertEqual(updater.parse_version("2.0"), (2, 0, 0))
        self.assertIsNone(updater.parse_version("abc"))
        self.assertTrue(updater.is_newer("1.10.0", "1.9.13"))                  # so số, không so chuỗi
        self.assertFalse(updater.is_newer("1.9.13", "1.9.13"))
        self.assertFalse(updater.is_newer("1.9.2", "1.9.13"))

    def test_newer_release_with_apk(self):
        self.state["resp"] = (200, {"tag_name": "v1.10.0", "html_url": "https://github.com/a/b/releases/tag/v1.10.0", "body": "Có gì mới",
                                    "assets": [{"name": "src.zip", "browser_download_url": "https://x/src.zip"},
                                               {"name": "pyea.apk", "browser_download_url": "https://github.com/a/b/releases/download/v1.10.0/pyea.apk"}]})
        r = updater.check("a/b", "1.9.13", api_base=self.base)
        self.assertEqual((r["status"], r["latest"]), ("newer", "v1.10.0"))
        self.assertTrue(r["apk"].endswith("pyea.apk"))
        self.assertEqual(self.state["calls"][0][0], "/repos/a/b/releases/latest")
        self.assertEqual(self.state["calls"][0][1], "PyEA-Runner")

    def test_current_none_draft_and_errors(self):
        self.state["resp"] = (200, {"tag_name": "v1.9.13", "assets": []})
        self.assertEqual(updater.check("a/b", "1.9.13", api_base=self.base)["status"], "current")
        self.state["resp"] = (404, {"message": "Not Found"})
        self.assertEqual(updater.check("a/b", "1.9.13", api_base=self.base)["status"], "none")
        self.state["resp"] = (200, {"tag_name": "v9.0.0", "prerelease": True})
        self.assertEqual(updater.check("a/b", "1.9.13", api_base=self.base)["status"], "none")
        self.state["resp"] = (500, {})
        self.assertEqual(updater.check("a/b", "1.9.13", api_base=self.base)["status"], "error")
        self.state["resp"] = (200, {"tag_name": "không-phải-số"})
        self.assertEqual(updater.check("a/b", "1.9.13", api_base=self.base)["status"], "error")
        self.assertEqual(updater.check("sai dinh dang", "1.0", api_base=self.base)["status"], "error")
        self.assertEqual(updater.check("a/b", "1.0", api_base="http://127.0.0.1:9")["status"], "error")     # không kết nối được: không ném lỗi

    def test_non_https_apk_link_is_ignored(self):
        self.state["resp"] = (200, {"tag_name": "v2.0.0", "assets": [{"name": "x.apk", "browser_download_url": "http://evil/x.apk"}]})
        self.assertEqual(updater.check("a/b", "1.0", api_base=self.base)["apk"], "")


def post_handler(state):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            state["bodies"].append(json.loads(self.rfile.read(n)))
            self.send_response(state.get("code", 200))
            self.end_headers()
            self.wfile.write(b"{}")
    return H


class TestCrashSend(unittest.TestCase):
    def setUp(self):
        self.state = {"bodies": [], "code": 200}
        self.srv = Srv(post_handler(self.state))
        self.url = "http://127.0.0.1:%d/crash" % self.srv.port
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "crash.log")

    def tearDown(self):
        self.srv.close()

    def settings(self, **kw):
        return dict({"crash_report_auto": True, "crash_report_url": self.url}, **kw)

    def test_url_rules(self):
        self.assertTrue(crashsend.valid_url("https://a.example/x"))
        self.assertTrue(crashsend.valid_url("http://localhost:8000/x"))
        self.assertFalse(crashsend.valid_url("http://a.example/x"))              # http ra Internet: không cho
        self.assertFalse(crashsend.valid_url("ftp://a"))
        self.assertFalse(crashsend.valid_url(""))

    def test_off_by_default_sends_nothing(self):
        d = default_settings()
        self.assertFalse(d["crash_report_auto"])
        self.assertFalse(crashsend.flush(d, "lỗi", "1.0")[0])
        self.assertFalse(crashsend.flush({"crash_report_auto": True, "crash_report_url": ""}, "lỗi", "1.0")[0])
        self.assertFalse(crashsend.flush(self.settings(), "   ", "1.0")[0])                     # không có nội dung: không gửi
        self.assertEqual(self.state["bodies"], [])

    def test_sends_redacted_report_with_version(self):
        ok, _ = crashsend.flush(self.settings(), 'Traceback...\nlỗi mới api_key="ABCDEF1234567890SECRETKEY99" Authorization: Bearer abcdefghij1234567890\n', "1.9.14")
        self.assertTrue(ok)
        b = self.state["bodies"][0]
        self.assertEqual((b["app"], b["version"]), ("PyEA Runner", "1.9.14"))
        self.assertIn("lỗi mới", b["report"])
        self.assertNotIn("ABCDEF1234567890SECRETKEY99", b["report"])
        self.assertNotIn("abcdefghij1234567890", b["report"])

    def test_failure_returns_reason_and_never_raises(self):
        self.state["code"] = 500
        ok, msg = crashsend.flush(self.settings(), "lỗi A", "1")
        self.assertFalse(ok)
        self.assertTrue(msg)
        ok, msg = crashsend.flush(self.settings(crash_report_url="http://127.0.0.1:9/x"), "lỗi A", "1")      # không kết nối được
        self.assertFalse(ok)

    def test_long_text_is_cut_keeping_the_end(self):
        rep = crashsend.build_payload("a" * 100000 + "CUOI", "1")["report"]
        self.assertLessEqual(len(rep), crashsend.MAX_CHARS + 40)
        self.assertTrue(rep.endswith("CUOI"))


class TestLegal(unittest.TestCase):
    def test_ack_flow_and_version_bump(self):
        p = {}
        self.assertTrue(legal.needed(p))
        legal.acknowledge(p)
        self.assertFalse(legal.needed(p))
        self.assertTrue(legal.needed(p, legal.LEGAL_VERSION + 1))
        self.assertTrue(legal.needed({"legal_ack": "rác"}))

    def test_sample_is_safe_and_only_touches_its_keys(self):
        base = default_settings()
        base.update(mode="live", exchange="binance_futures", api_key="K", language="English")
        out = legal.sample_patch(base)
        self.assertEqual((out["mode"], out["exchange"]), ("paper", "simulated"))
        self.assertEqual(out["api_key"], "K")                                    # không xoá khoá người dùng
        self.assertEqual(base["mode"], "live")                                   # không sửa bản gốc
        for k in legal.SAMPLE_SETTINGS:
            self.assertIn(k, default_settings())                                 # mọi khoá mẫu đều là cài đặt có thật

    def test_texts_are_honest_about_defaults(self):
        self.assertIn("mặc định tắt", legal.PRIVACY_TEXT.lower())
        self.assertIn("luật sư", legal.EULA_TEXT)
        self.assertEqual(len(legal.ONBOARDING), 6)


if __name__ == "__main__":
    unittest.main()


class TestSupportUi(unittest.TestCase):
    """Giao diện (kivy_stub): lần đầu hiện điều khoản → hướng dẫn; cài đặt mẫu giữ khoá API; kiểm tra cập nhật khi chưa nhập kho."""
    def tearDown(self):
        import kivy_stub
        kivy_stub.OPEN_POPUPS.clear()

    def app(self):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import test_ui_smoke as T
        self.T = T
        return T.make_app()

    def test_first_run_shows_terms_then_onboarding_and_is_remembered(self):
        import kivy_stub
        app = self.app()
        p = app.store.load_prefs()
        p.pop("legal_ack", None)
        app.store.save_prefs(p)
        kivy_stub.OPEN_POPUPS.clear()
        self.assertTrue(app.first_run())
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertEqual(pop.title, legal.EULA_TITLE)
        self.assertIn("RIÊNG TƯ", self.T.texts(pop.content))
        self.T.press(pop.content, "Tôi đã đọc và đồng ý")
        self.assertFalse(legal.needed(app.store.load_prefs()))
        self.assertIn("1/6", kivy_stub.OPEN_POPUPS[-1].title)
        self.assertFalse(app.first_run())                                         # lần sau không hiện nữa

    def test_onboarding_walks_all_steps_and_sample_keeps_api_key(self):
        import kivy_stub
        app = self.app()
        app.settings.update(mode="live", exchange="binance_futures", api_key="GIU-LAI")
        app.onboarding(0)
        for i in range(1, 6):
            self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Tiếp")
            self.assertIn("%d/6" % (i + 1), kivy_stub.OPEN_POPUPS[-1].title)
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Dùng cài đặt mẫu")
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Áp dụng")
        self.assertEqual((app.settings["mode"], app.settings["exchange"], app.settings["api_key"]), ("paper", "simulated", "GIU-LAI"))
        self.assertEqual(app.store.load_settings()["mode"], "paper")              # đã lưu đĩa

    def test_update_dialog_without_repo_explains_how(self):
        import kivy_stub
        app = self.app()
        app.settings["update_repo"] = ""
        app.update_dialog()
        self.assertIn("Chưa nhập kho", self.T.texts(kivy_stub.OPEN_POPUPS[-1].content))

    def test_legal_menu_opens(self):
        import kivy_stub
        app = self.app()
        app.legal_menu()
        blob = self.T.texts(kivy_stub.OPEN_POPUPS[-1].content)
        for s in ("Hướng dẫn nhanh", "Điều khoản sử dụng", "Chính sách riêng tư", "Cảnh báo rủi ro", "Kiểm tra cập nhật"):
            self.assertIn(s, blob)
