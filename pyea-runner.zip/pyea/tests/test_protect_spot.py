"""SL/TP NATIVE trên Binance SPOT qua lệnh OCO (PROT_STYLE="pair" + BinanceBroker.sync_steps) với sàn Spot giả.

Sàn giả theo tài liệu Binance Spot: POST /api/v3/orderList/oco (aboveType/belowType...), DELETE/GET /api/v3/orderList, openOrders trả orderListId +
clientOrderId, và KHOÁ coin cho lệnh BÁN chờ (một cặp OCO khoá MỘT lần). Mã lỗi -2010 cho thiếu số dư/vi phạm giá là ước lượng của sàn giả.
"""
import os
import sys
import tempfile
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX                      # noqa: E402
from pyea import contract                                    # noqa: E402
from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.broker import BinanceBroker, BinanceFuturesBroker  # noqa: E402
from pyea.engine import Account, TradingSession              # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402

SYM = "BTCUSDT"


def make(fx, state_dir=None, **over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_spot", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0, native_sltp=True, native_sync_s=1.0, reconcile_interval=0)
    st.update(over)
    sf = os.path.join(state_dir, "state.json") if state_dir else None
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=sf)
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = [SYM]
    s.broker = BinanceBroker("key123", "sekret", fx.base)
    s.broker.prepare(SYM)
    s.sync = False
    return s


def tk(s, price, t=1000.0):
    s.process_tick(Tick(SYM, t, price, price))


def poll(s):
    s._prot_next = 0.0
    s._check_protection()


def lists(fx, status="EXECUTING"):
    return [l for l in fx.spot["lists"].values() if l["status"] == status]


def open_orders(fx):
    return [o for o in fx.spot["orders"].values() if o["status"] == "NEW"]


def posts(fx, path):
    return [c for c in fx.calls if c[0] == "POST" and c[1] == path]


def leg(fx, lst, k):
    return fx.spot["orders"][str(lst["legs"][k])]


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.fx.price = 100.0                                    # reset() không đặt lại giá: test trước có thể đã đổi
        self.fx.fee_rate = 0.0                                   # số tròn; test riêng cho phí bằng coin ở TestDust
        self.tmp = tempfile.mkdtemp()
        self.s = make(self.fx, self.tmp)
        tk(self.s, 100.0)

    def open(self, vol, sl=0.0, tp=0.0):
        r = self.s.send_order(SYM, "buy", vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position


class TestPairing(Base):
    def test_sl_and_tp_of_one_position_become_ONE_oco_order(self):
        p = self.open(0.05, 95.0, 110.0)
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                    # vừa mở: chưa có bảo vệ -> vỏ tự canh
        poll(self.s)
        sent = posts(self.fx, "/api/v3/orderList/oco")
        self.assertEqual(len(sent), 1)
        q = sent[0][2]
        self.assertEqual((q["symbol"], q["side"], q["quantity"]), (SYM, "SELL", "0.050"))
        self.assertEqual((q["aboveType"], q["abovePrice"], q["belowType"], q["belowStopPrice"]), ("LIMIT_MAKER", "110.00", "STOP_LOSS", "95.00"))
        self.assertTrue(all(q[k].startswith("pyeaP") for k in ("listClientOrderId", "aboveClientOrderId", "belowClientOrderId")))
        self.assertEqual(len(lists(self.fx)), 1)
        self.assertEqual(self.fx.locked_base(), 0.05)                         # khoá coin MỘT lần, không gấp đôi
        self.assertTrue(self.s.prot_covered(p.id, "sl") and self.s.prot_covered(p.id, "tp"))
        self.assertEqual(posts(self.fx, "/api/v3/order")[1:], [])             # ngoài lệnh MUA ban đầu không có lệnh rời nào
        n = len(self.fx.calls)
        poll(self.s)
        poll(self.s)
        self.assertEqual(len(posts(self.fx, "/api/v3/orderList/oco")), 1)     # đồng bộ lại = idempotent
        self.assertEqual([c for c in self.fx.calls[n:] if c[0] != "GET"], [])

    def test_two_separate_orders_would_be_rejected_by_the_exchange_which_is_why_pairs_exist(self):
        self.open(0.05)
        self.fx.calls.clear()
        r = self.s.broker.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 95.0, "qty": 0.05},
                                                 {"kind": "tp", "side": "sell", "trigger": 110.0, "qty": 0.05}])
        self.assertEqual(r["covered"], [0])                                    # SL đặt được, TP bị từ chối vì coin đã bị SL khoá hết
        self.assertIn("-2010", r["errors"][0])
        self.assertIn("insufficient", r["errors"][0])

    def test_only_sl_or_only_tp_use_single_orders(self):
        a, b = self.open(0.03, 95.0), self.open(0.02, tp=110.0)
        poll(self.s)
        self.assertEqual(posts(self.fx, "/api/v3/orderList/oco"), [])
        got = {(o["type"], o.get("stopPrice"), o.get("price"), o["origQty"]) for o in open_orders(self.fx)}
        self.assertEqual(got, {("STOP_LOSS", "95.00", None, "0.030"), ("LIMIT_MAKER", None, "110.00", "0.020")})
        self.assertTrue(all(o["clientId"].startswith("pyeaP") for o in open_orders(self.fx)))
        self.assertTrue(self.s.prot_covered(a.id, "sl") and self.s.prot_covered(b.id, "tp"))
        self.assertFalse(self.s.prot_covered(a.id, "tp"))
        self.assertAlmostEqual(self.fx.locked_base(), 0.05, 9)

    def test_positions_with_identical_levels_share_one_oco(self):
        a, b = self.open(0.03, 95.0, 110.0), self.open(0.02, 95.0, 110.0)
        poll(self.s)
        self.assertEqual(len(lists(self.fx)), 1)
        self.assertEqual(posts(self.fx, "/api/v3/orderList/oco")[0][2]["quantity"], "0.050")
        self.assertTrue(all(self.s.prot_covered(p.id, k) for p in (a, b) for k in ("sl", "tp")))

    def test_same_sl_different_tp_makes_two_ocos_and_total_locked_is_not_doubled(self):
        a, b = self.open(0.03, 95.0, 110.0), self.open(0.02, 95.0, 120.0)
        poll(self.s)
        got = sorted((leg(self.fx, l, "sl")["origQty"], leg(self.fx, l, "tp")["price"]) for l in lists(self.fx))
        self.assertEqual(got, [("0.020", "120.00"), ("0.030", "110.00")])
        self.assertAlmostEqual(self.fx.locked_base(), 0.05, 9)                  # đúng tổng khối lượng vị thế
        self.assertTrue(all(self.s.prot_covered(p.id, k) for p in (a, b) for k in ("sl", "tp")))
        self.assertEqual(self.s.reconcile_now(), [])

    def test_mixed_oco_and_single_do_not_double_lock(self):
        a, b = self.open(0.03, 95.0, 110.0), self.open(0.02, 95.0)
        poll(self.s)
        self.assertEqual((len(lists(self.fx)), len([o for o in open_orders(self.fx) if o.get("orderListId", -1) < 0])), (1, 1))
        self.assertAlmostEqual(self.fx.locked_base(), 0.05, 9)
        self.assertTrue(self.s.prot_covered(a.id, "sl") and self.s.prot_covered(b.id, "sl"))

    def test_foreign_orders_and_lists_are_never_touched(self):
        self.fx.spot["bal"]["BTC"] = 1.0                                       # coin có sẵn ngoài app
        mine = self.s.broker.place_pending(SYM, "sell", "limit", 0.1, 150.0)    # lệnh limit của app (clientId 'pyea...' không phải 'pyeaP')
        self.fx.spot["orders"]["999"] = {"orderId": 999, "symbol": SYM, "side": "SELL", "type": "LIMIT", "origQty": "0.2", "status": "NEW",
                                         "price": "200.00", "clientId": "my-own-order", "orderListId": -1}
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        poll(self.s)
        self.assertEqual(self.fx.spot["orders"]["999"]["status"], "NEW")
        self.assertEqual(self.fx.spot["orders"][mine]["status"], "NEW")
        self.assertEqual(len(lists(self.fx)), 1)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))

    def test_default_is_off_and_places_nothing(self):
        s = make(self.fx, tempfile.mkdtemp(), native_sltp=False)
        tk(s, 100.0)
        s.send_order(SYM, "buy", 0.05, 95.0, 110.0)
        poll(s)
        self.assertEqual(posts(self.fx, "/api/v3/orderList/oco"), [])
        self.assertEqual(lists(self.fx), [])


class TestOwnership(Base):
    def test_covered_levels_are_not_closed_by_the_shell(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        n = len(posts(self.fx, "/api/v3/order"))
        tk(self.s, 94.0, 1001.0)                                              # giá xuyên SL nhưng sàn canh -> vỏ không đóng
        self.assertIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx, "/api/v3/order")), n)

    def test_rejected_oco_leaves_the_levels_to_the_shell(self):
        p = self.open(0.05, 95.0, 110.0)
        self.fx.price = 94.0                                                  # SL đã nằm trên giá: luật giá OCO bị vi phạm -> sàn từ chối
        poll(self.s)
        self.assertEqual(lists(self.fx), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl") or self.s.prot_covered(p.id, "tp"))
        self.assertTrue(any("vẫn tự canh" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        tk(self.s, 94.0, 1001.0)
        self.assertNotIn(p.id, self.s.account.positions)                      # vỏ tự đóng bằng lệnh thị trường (coin không bị khoá)
        self.assertEqual(self.fx.spot["bal"]["BTC"], 0.0)

    def test_shell_close_cancels_the_oco_first_otherwise_the_exchange_would_refuse_the_sale(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        self.fx.calls.clear()
        res = self.s.close_position(p.id, "bot", "đóng tay")
        self.assertTrue(res, res.message)                                    # nếu không huỷ trước, bán thị trường sẽ bị -2010 (coin đang bị khoá)
        seq = [(c[0], c[1]) for c in self.fx.calls if c[0] in ("DELETE", "POST")]
        self.assertEqual(seq, [("DELETE", "/api/v3/orderList"), ("POST", "/api/v3/order")])
        self.assertEqual(lists(self.fx), [])
        self.assertEqual(self.fx.spot["bal"]["BTC"], 0.0)

    def test_closing_one_position_of_a_shared_oco_recreates_it_for_the_rest(self):
        a, b = self.open(0.03, 95.0, 110.0), self.open(0.02, 95.0, 110.0)
        poll(self.s)
        self.assertTrue(self.s.close_position(a.id, "bot", "x"))
        poll(self.s)
        ls = lists(self.fx)
        self.assertEqual([(leg(self.fx, l, "sl")["origQty"], leg(self.fx, l, "sl")["stopPrice"], leg(self.fx, l, "tp")["price"]) for l in ls],
                         [("0.020", "95.00", "110.00")])
        self.assertTrue(self.s.prot_covered(b.id, "sl") and self.s.prot_covered(b.id, "tp"))
        self.assertAlmostEqual(self.fx.locked_base(), 0.02, 9)

    def test_modify_sl_replaces_the_oco_and_keeps_the_tp(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        self.assertTrue(self.s.modify_position(p.id, sl=96.0))
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                     # đang đổi: vỏ canh tạm thời
        self.assertEqual(lists(self.fx), [])
        poll(self.s)
        (l,) = lists(self.fx)
        self.assertEqual((leg(self.fx, l, "sl")["stopPrice"], leg(self.fx, l, "tp")["price"]), ("96.00", "110.00"))
        self.assertTrue(self.s.prot_covered(p.id, "sl") and self.s.prot_covered(p.id, "tp"))

    def test_removing_the_tp_turns_the_oco_into_a_single_stop(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        self.assertTrue(self.s.modify_position(p.id, tp=0.0))
        poll(self.s)
        self.assertEqual(lists(self.fx), [])
        self.assertEqual([(o["type"], o["stopPrice"]) for o in open_orders(self.fx)], [("STOP_LOSS", "95.00")])
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        self.assertFalse(self.s.prot_covered(p.id, "tp"))


class TestFills(Base):
    def test_sl_leg_fill_is_booked_without_sending_any_order(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        (l,) = lists(self.fx)
        n = len(posts(self.fx, "/api/v3/order"))
        self.fx.fill_oco(l["id"], "sl", 94.8)                                 # sàn khớp chân STOP_LOSS; chân TP tự hết hạn
        poll(self.s)
        self.assertNotIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx, "/api/v3/order")), n)             # vỏ KHÔNG gửi thêm lệnh đóng
        tr = self.s.account.trades[-1]
        self.assertAlmostEqual(tr.profit, (94.8 - 100.0) * 0.05, 6)
        self.assertEqual(tr.close_price, 94.8)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, "sl")
        self.assertIn("NATIVE", ev.reason)
        self.assertIn("STOP_LOSS (Spot)", ev.reason)
        self.assertEqual(lists(self.fx), [])
        self.assertEqual(self.fx.locked_base(), 0.0)
        self.assertEqual(self.s.reconcile_now(), [])

    def test_tp_leg_fill_is_booked_as_take_profit(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        (l,) = lists(self.fx)
        self.fx.fill_oco(l["id"], "tp")
        poll(self.s)
        self.assertNotIn(p.id, self.s.account.positions)
        tr = self.s.account.trades[-1]
        self.assertAlmostEqual(tr.profit, 10.0 * 0.05, 6)
        self.assertEqual([e.source for e in self.s.events if e.kind == "close"][-1], "tp")
        self.assertEqual(self.s.reconcile_now(), [])

    def test_fill_of_one_group_does_not_close_a_position_that_only_shares_the_sl(self):
        b, a = self.open(0.02, 95.0, 120.0), self.open(0.03, 95.0, 110.0)      # b mở TRƯỚC (id nhỏ hơn): ghi sổ theo id sẽ chọn nhầm b nếu không lọc mức chân kia
        poll(self.s)
        l110 = [l for l in lists(self.fx) if leg(self.fx, l, "tp")["price"] == "110.00"][0]
        self.fx.fill_oco(l110["id"], "sl", 95.0)                              # SL của nhóm a chạm; b cùng mức SL nhưng thuộc cặp OCO KHÁC
        poll(self.s)
        self.assertNotIn(a.id, self.s.account.positions)
        self.assertIn(b.id, self.s.account.positions)
        self.assertEqual(len(lists(self.fx)), 1)                              # cặp của b còn nguyên
        self.assertTrue(self.s.prot_covered(b.id, "sl") and self.s.prot_covered(b.id, "tp"))
        self.assertEqual(self.s.reconcile_now(), [])

    def test_shared_oco_fill_books_every_position_of_the_group(self):
        a, b = self.open(0.03, 95.0, 110.0), self.open(0.02, 95.0, 110.0)
        poll(self.s)
        (l,) = lists(self.fx)
        self.fx.fill_oco(l["id"], "tp", 110.5)
        poll(self.s)
        self.assertEqual(self.s.account.positions, {})
        self.assertEqual(sorted(round(t.volume, 6) for t in self.s.account.trades), [0.02, 0.03])
        self.assertEqual(self.s.reconcile_now(), [])

    def test_fill_while_app_was_off_is_booked_after_restart(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        state = self.s.account.to_dict()
        (l,) = lists(self.fx)
        self.fx.fill_oco(l["id"], "sl", 94.5)                                 # app tắt, sàn khớp chân SL ở 94.5
        s2 = make(self.fx, self.tmp)                                          # app mở lại: cùng thư mục state -> đọc protect.json
        s2.account.restore(state)
        tk(s2, 94.5, 2000.0)
        self.assertIn(p.id, s2.account.positions)
        self.assertTrue(s2.prot_hold(SYM))                                    # chưa xác minh: vỏ chưa tự đóng
        poll(s2)
        self.assertNotIn(p.id, s2.account.positions)
        self.assertAlmostEqual(s2.account.trades[-1].close_price, 94.5, 6)       # giá khớp = tổng tiền (4 số lẻ) / khối lượng
        self.assertEqual(posts(self.fx, "/api/v3/order")[1:], [])             # không có lệnh đóng đúp
        self.assertEqual(s2.reconcile_now(), [])

    def test_restart_with_live_oco_does_not_duplicate(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        state = self.s.account.to_dict()
        s2 = make(self.fx, self.tmp)
        s2.account.restore(state)
        tk(s2, 100.0, 2000.0)
        poll(s2)
        self.assertEqual(len(posts(self.fx, "/api/v3/orderList/oco")), 1)     # nhận ra cặp đang sống, không đặt lại
        self.assertTrue(s2.prot_covered(p.id, "sl") and s2.prot_covered(p.id, "tp"))

    def test_oco_canceled_externally_is_replaced(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        (l,) = lists(self.fx)
        self.fx.external_cancel_oco(l["id"])                                  # ai đó huỷ tay trên web sàn
        poll(self.s)
        self.assertTrue(any("bị sàn huỷ" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        self.assertTrue(any("OCO SL @95" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        self.assertEqual(len(lists(self.fx)), 1)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))


class TestDust(Base):
    def test_coin_fee_dust_is_closed_with_the_native_fill(self):
        self.fx.fee_rate = 0.001                                              # phí mua bằng coin: 0.05 -> vị thế ảo 0.04995; sàn chỉ bán được 0.049
        p = self.open(0.05, 95.0, 110.0)
        self.assertAlmostEqual(p.volume, 0.04995, 9)
        poll(self.s)
        (l,) = lists(self.fx)
        self.assertEqual(leg(self.fx, l, "sl")["origQty"], "0.049")
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        self.fx.fill_oco(l["id"], "tp", 111.0)
        poll(self.s)
        self.assertEqual(self.s.account.positions, {})                        # không để lại vị thế ảo 0.00095 vô hình mà sàn không bán nổi
        self.assertFalse(any(lv == "WARN" and "sẽ đối soát" in m for _, _, lv, m in self.s.logs))
        self.assertLess(self.fx.spot["bal"]["BTC"], 0.001)


class TestBrokerLevel(Base):
    def setUp(self):
        super().setUp()
        self.b = self.s.broker
        self.fx.spot["bal"]["BTC"] = 0.05

    def d_oco(self, sl=95.0, tp=110.0, qty=0.05):
        return {"kind": "oco", "side": "sell", "trigger": sl, "sl": sl, "tp": tp, "qty": qty}

    def test_shape_and_idempotence(self):
        r = self.b.sync_steps(SYM, [self.d_oco()])
        self.assertEqual((r["covered"], r["errors"], len(r["live"])), ([0], [], 1))
        rows = self.b.protection_orders(SYM)
        self.assertEqual(contract.check_protection_orders(rows), [])
        self.assertEqual(rows[0]["kind"], "oco")
        self.assertEqual((rows[0]["sl"], rows[0]["tp"], rows[0]["qty"], rows[0]["step"]), (95.0, 110.0, 0.05, 0.001))
        self.assertTrue(rows[0]["id"].startswith("oco:"))
        n = len(posts(self.fx, "/api/v3/orderList/oco"))
        self.assertEqual(self.b.sync_steps(SYM, [self.d_oco()])["covered"], [0])
        self.assertEqual(len(posts(self.fx, "/api/v3/orderList/oco")), n)

    def test_changed_tp_cancels_then_places_so_the_coin_is_free(self):
        self.b.sync_steps(SYM, [self.d_oco()])
        self.fx.calls.clear()
        r = self.b.sync_steps(SYM, [self.d_oco(tp=115.0)])
        self.assertEqual((r["covered"], r["errors"]), ([0], []))
        seq = [(c[0], c[1]) for c in self.fx.calls if c[0] in ("DELETE", "POST")]
        self.assertEqual(seq, [("DELETE", "/api/v3/orderList"), ("POST", "/api/v3/orderList/oco")])
        self.assertEqual(self.b.protection_orders(SYM)[0]["tp"], 115.0)

    def test_price_rule_violation_is_reported_not_raised(self):
        r = self.b.sync_steps(SYM, [self.d_oco(tp=90.0)])                # TP dưới giá hiện tại
        self.assertEqual(r["covered"], [])
        self.assertIn("-2010", r["errors"][0])
        self.assertEqual(self.b.protection_orders(SYM), [])

    def test_buy_side_is_refused_because_spot_has_no_short(self):
        r = self.b.sync_steps(SYM, [{"kind": "sl", "side": "buy", "trigger": 105.0, "qty": 0.05}])
        self.assertEqual(r["covered"], [])
        self.assertIn("chỉ có vị thế mua", r["errors"][0])
        self.assertEqual(posts(self.fx, "/api/v3/order")[1:], [])

    def test_quantity_below_step_is_skipped(self):
        r = self.b.sync_steps(SYM, [self.d_oco(qty=0.0004)])
        self.assertEqual((r["covered"], r["errors"], r["live"]), ([], [], []))

    def test_only_one_visible_leg_is_cancelable_through_the_list(self):
        self.b.sync_steps(SYM, [self.d_oco()])
        (l,) = lists(self.fx)
        leg(self.fx, l, "tp")["status"] = "EXPIRED"                           # bất thường: chỉ còn một chân hiện trong openOrders
        rows = self.b.protection_orders(SYM)
        self.assertEqual([(r["kind"], r["id"]) for r in rows], [("sl", "oco:%d" % l["id"])])
        r = self.b.sync_steps(SYM, [])                                   # khác khoá với mọi thứ mong muốn -> huỷ cả cặp
        self.assertEqual((r["live"], r["errors"]), ([], []))
        self.assertEqual(lists(self.fx), [])

    def test_order_result_states(self):
        self.b.sync_steps(SYM, [self.d_oco()])
        (l,) = lists(self.fx)
        oid = "oco:%d" % l["id"]
        self.assertEqual(self.b.order_result(oid, SYM), {"state": "open"})
        tp = leg(self.fx, l, "tp")
        tp.update(status="PARTIALLY_FILLED", executedQty="0.020", px=110.0)  # khớp dở: chưa được ghi sổ
        self.assertEqual(self.b.order_result(oid, SYM), {"state": "open"})
        self.b.cancel_pending(oid, SYM)                                       # huỷ cặp khi đã khớp một phần: phần đã khớp là thật
        r = self.b.order_result(oid, SYM)
        self.assertEqual((r["state"], r["leg"], round(r["qty"], 6), round(r["price"], 6)), ("filled", "tp", 0.02, 110.0))
        self.assertEqual(contract.check_order_result(r), [])

    def test_order_result_canceled_and_unknown(self):
        self.b.sync_steps(SYM, [self.d_oco()])
        (l,) = lists(self.fx)
        self.fx.external_cancel_oco(l["id"])
        self.assertEqual(self.b.order_result("oco:%d" % l["id"], SYM), {"state": "canceled"})
        with self.assertRaises(Exception):
            self.b.order_result("oco:424242", SYM)                            # sàn báo không có cặp này -> lỗi (vỏ hỏi lại vòng sau)

    def test_futures_broker_is_unchanged_by_pair_mode(self):
        self.assertEqual(getattr(BinanceFuturesBroker, "PROT_STYLE", ""), "ladder")
        self.assertEqual(BinanceBroker.PROT_STYLE, "pair")


if __name__ == "__main__":
    unittest.main()
