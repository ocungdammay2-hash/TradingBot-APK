"""Đường TỆP dự phòng khi MT5 chặn socket của EA: relay THẬT (tools/mt5_phone/pyea_relay.py) + máy chủ cục bộ THẬT của app + EA giả nói đúng quy tắc tệp của EA MQL5.
KHÔNG chứng minh đoạn MQL5 đọc/ghi tệp chạy đúng trong MT5 (chưa biên dịch/chạy); chỉ chứng minh relay và quy tắc tệp nhất quán với app, và EA có đủ các phần đó."""
import importlib.util
import os
import re
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest

from fake_ea import FakeEA
from pyea import mt5ea

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RELAY_PY = os.path.join(ROOT, "tools", "mt5_phone", "pyea_relay.py")
SCRIPT = os.path.join(ROOT, "tools", "mt5_phone", "run_mt5_termux.sh")
TOKEN = "tok-12345678"

spec = importlib.util.spec_from_file_location("pyea_relay", RELAY_PY)
pyea_relay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pyea_relay)


def wait(cond, t=8.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.03)
    return False


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class FileLink:
    """Đối tượng giống socket, làm ĐÚNG những gì EA MQL5 làm trên tệp (PyEABridge.mq5: OpenFileSession/FileSendBytes/ReadFile/ProcessRx)."""
    def __init__(self, d, sid=None, seg=pyea_relay.SEG_BYTES):
        self.d, self.seg, self.sid = d, seg, int(sid or time.time())
        self.oseq = self.obytes = self.iseq = self.ioff = 0
        self.fo = open(self._o(), "wb")
        self.timeout = 0.2
        self.closed = False
        self.rx_files_deleted = 0

    def _o(self):
        return os.path.join(self.d, pyea_relay.out_name(self.sid, self.oseq))

    def _i(self, seq):
        return os.path.join(self.d, pyea_relay.in_name(self.sid, seq))

    def settimeout(self, t):
        self.timeout = t

    def sendall(self, data):
        self.fo.write(data)
        self.fo.flush()
        self.obytes += len(data)
        if self.obytes >= self.seg:
            self.fo.close()
            self.oseq += 1
            self.obytes = 0
            self.fo = open(self._o(), "wb")

    def _read_in(self):
        nxt = os.path.exists(self._i(self.iseq + 1))            # kiểm TRƯỚC khi đọc (giống EA)
        sz, data = 0, b""
        try:
            with open(self._i(self.iseq), "rb") as f:
                sz = os.fstat(f.fileno()).st_size
                if sz > self.ioff:
                    f.seek(self.ioff)
                    data = f.read(min(sz - self.ioff, 65536))
                    self.ioff += len(data)
        except FileNotFoundError:
            pass
        if nxt and self.ioff >= sz:
            os.remove(self._i(self.iseq))
            self.rx_files_deleted += 1
            self.iseq += 1
            self.ioff = 0
        return data

    def recv(self, n):
        end = time.monotonic() + self.timeout
        while True:
            data = self._read_in()
            if data:
                if b"RELAYCLOSE\n" in data:                     # EA: CloseSock("relay báo app đóng") ~ socket bị đóng
                    self.closed = True
                    return b""
                return data
            if time.monotonic() > end:
                raise socket.timeout()
            time.sleep(0.01)

    def shutdown(self, how):
        pass

    def close(self):
        try:
            self.fo.close()
        except Exception:
            pass


class RelayThread:
    def __init__(self, d, port, **kw):
        self.relay = pyea_relay.Relay(d, "127.0.0.1", port, log=lambda m: None, **kw)
        self.stop = threading.Event()
        self.t = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self.stop.is_set():
            self.relay.step()
            time.sleep(0.01)

    def __enter__(self):
        self.t.start()
        return self.relay

    def __exit__(self, *a):
        self.stop.set()
        self.t.join(2)
        self.relay._end()


def server():
    s = mt5ea.Mt5EaServer(free_port(), TOKEN, hb_s=0.3)
    s.start()
    return s


class TestRelayWithRealServer(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.srv = server()
        self.eas = []

    def tearDown(self):
        for e in self.eas:
            e.close()
        self.srv.close()

    def ea(self, **kw):
        link = kw.pop("link_obj", None) or FileLink(self.d, **kw)
        e = FakeEA(self.srv.port, TOKEN, link=lambda: link)
        e.fl = link
        self.eas.append(e)
        return e.start()

    def test_file_session_reaches_app_and_roundtrips(self):
        with RelayThread(self.d, self.srv.port):
            e = self.ea()
            self.assertTrue(wait(self.srv.alive), "HELLO qua tệp không tới được app")
            self.assertEqual(self.srv.info.get("login"), "123")
            self.assertTrue(wait(lambda: any(t == "WELCOME" for t, _ in e.log)), "WELCOME của app không về tới EA qua tệp")
            b = mt5ea.Mt5EaBackend(self.srv)
            self.assertEqual(b.symbols(), ["EURUSD", "XAUUSD"])                    # yêu cầu app -> EA -> trả lời EA -> app, đi hết hai chiều
            self.assertEqual(b.tick("EURUSD")[:2], (1.1, 1.1002))
            m = b.market("EURUSD", "buy", 0.1, "pyea-t:x")
            self.assertTrue(m["position_id"])

    def test_segments_rotate_and_old_files_are_deleted_both_directions(self):
        with RelayThread(self.d, self.srv.port, seg_bytes=600) as relay:
            e = self.ea(seg=600)
            self.assertTrue(wait(self.srv.alive))
            self.srv.subscribe(["EURUSD"])                                         # EA giả đẩy TICK liên tục -> hướng EA -> app đổi đoạn
            b = mt5ea.Mt5EaBackend(self.srv)
            for _ in range(40):                                                    # nhiều yêu cầu -> hướng app -> EA đổi đoạn
                b.tick("EURUSD")
            self.assertTrue(wait(lambda: e.fl.oseq >= 3, 10), "EA chưa đổi đoạn ra (oseq=%d)" % e.fl.oseq)
            self.assertTrue(wait(lambda: e.fl.iseq >= 2, 10), "EA chưa sang đoạn vào kế (iseq=%d)" % e.fl.iseq)
            self.assertTrue(self.srv.alive(), "đổi đoạn làm đứt kết nối")
            names = os.listdir(self.d)
            self.assertNotIn(pyea_relay.out_name(e.fl.sid, 0), names, "đoạn ra cũ phải bị relay xoá")
            self.assertNotIn(pyea_relay.in_name(e.fl.sid, 0), names, "đoạn vào cũ phải bị EA xoá")
            self.assertEqual(self.srv.connects, 1, "không được kết nối lại khi chỉ đổi đoạn")
            self.assertEqual(b.tick("EURUSD")[:2], (1.1, 1.1002))                  # vẫn chạy sau nhiều lần đổi đoạn

    def test_app_not_running_gives_relayclose_so_ea_retries(self):
        dead_port = free_port()
        with RelayThread(self.d, dead_port):
            link = FileLink(self.d)
            link.sendall(b"HELLO|v=1|token=%s\n" % TOKEN.encode())
            end = time.time() + 5
            got = False
            while time.time() < end:
                try:
                    if link.recv(100) == b"":
                        got = True
                        break
                except socket.timeout:
                    pass
            self.assertTrue(got and link.closed, "không nối được app mà EA không được báo RELAYCLOSE")

    def test_wrong_token_is_denied_through_relay_then_closed(self):
        with RelayThread(self.d, self.srv.port):
            link = FileLink(self.d)
            e = FakeEA(self.srv.port, "sai-token-123", link=lambda: link).start()
            self.eas.append(e)
            self.assertTrue(wait(lambda: any(t == "DENY" for t, _ in e.log)), "DENY của app không về tới EA")
            self.assertFalse(self.srv.alive())

    def test_new_session_replaces_old_and_app_sees_reconnect(self):
        with RelayThread(self.d, self.srv.port):
            s1 = int(time.time())
            self.ea(sid=s1)
            self.assertTrue(wait(self.srv.alive))
            self.assertEqual(self.srv.connects, 1)
            self.eas[0].close()
            self.eas[0].fl.close()
            self.ea(sid=s1 + 1)                                                    # EA mở phiên mới (sau RELAYCLOSE/khởi động lại)
            self.assertTrue(wait(lambda: self.srv.connects == 2), "phiên mới không được nối lại với app")
            self.assertTrue(wait(self.srv.alive))

    def test_stale_old_session_files_are_cleaned_but_current_kept(self):
        old_o = os.path.join(self.d, pyea_relay.out_name(100, 0))
        old_i = os.path.join(self.d, pyea_relay.in_name(100, 0))
        for p in (old_o, old_i):
            open(p, "wb").write(b"x\n")
            os.utime(p, (time.time() - 1000, time.time() - 1000))
        with RelayThread(self.d, self.srv.port, stale_s=60):
            self.ea()
            self.assertTrue(wait(self.srv.alive))
            self.assertTrue(wait(lambda: not os.path.exists(old_o) and not os.path.exists(old_i)), "tệp phiên cũ không được dọn")
            self.assertTrue(self.srv.alive())

    def test_relay_survives_garbage_files_and_missing_dir_entries(self):
        open(os.path.join(self.d, "pyea_o_abc_0.txt"), "w").write("x")             # tên không khớp mẫu: bỏ qua
        open(os.path.join(self.d, "khac.txt"), "w").write("x")
        with RelayThread(self.d, self.srv.port):
            self.ea()
            self.assertTrue(wait(self.srv.alive))


class TestEaSourceHasFileTransport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src = open(os.path.join(ROOT, "pyea", "assets", "PyEABridge.mq5.txt"), encoding="utf-8").read()

    def test_brackets_balanced(self):
        t = re.sub(r'"(\\.|[^"\\])*"', '""', self.src)
        t = re.sub(r"//.*", "", t)
        for a, b in ("{}", "()", "[]"):
            self.assertEqual(t.count(a), t.count(b), a + b)

    def test_protocol_constants_match_relay(self):
        for token in ('"pyea_o_"', '"pyea_i_"', "RELAYCLOSE", "#define SEG_BYTES %d" % pyea_relay.SEG_BYTES, "FILE_SHARE_READ", "FileWriteArray", "FileReadArray",
                      "FileFlush", "FileIsExist", "FileDelete", "InpTransport", "OpenFileSession", "ReadFile", "ProcessRx", "no link to app"):
            self.assertIn(token, self.src, token)
        self.assertRegex(self.src, r'"pyea_o_" \+ g_f_sid \+ "_" \+ IntegerToString\(g_f_oseq\) \+ "\.txt"')
        self.assertRegex(self.src, r'"pyea_i_" \+ g_f_sid \+ "_" \+ IntegerToString\(seq\) \+ "\.txt"')
        self.assertEqual(pyea_relay.out_name(5, 2), "pyea_o_5_2.txt")
        self.assertEqual(pyea_relay.in_name(5, 2), "pyea_i_5_2.txt")

    def test_socket_is_tried_first_and_file_is_only_fallback(self):
        a = self.src.index("void TryConnect()")
        body = self.src[a:self.src.index("//--------------------------------------------------------------- phân tích dòng")]
        self.assertLess(body.index("SocketConnect"), body.index("OpenFileSession()"))
        self.assertIn('InpTransport != "file"', body)
        self.assertIn('InpTransport == "socket"', body)

    def test_hello_tells_app_which_link(self):
        self.assertIn('KV("link", g_file_mode ? "file" : "socket")', self.src)

    def test_all_socket_state_checks_use_linked_helper(self):
        self.assertIn("bool Linked()", self.src)
        timer = self.src[self.src.index("void OnTimer()"):self.src.index("void OnTradeTransaction")]
        self.assertNotIn("g_sock == INVALID_HANDLE", timer)

    def test_relay_and_assets_are_identical_and_served(self):
        a = open(RELAY_PY, encoding="utf-8").read()
        b = open(os.path.join(ROOT, "pyea", "assets", "pyea_relay.py.txt"), encoding="utf-8").read()
        self.assertEqual(a, b)
        self.assertIn("pyea_relay.py", mt5ea.SCRIPT_FILES)
        self.assertEqual(mt5ea.script_source("pyea_relay.py"), a)


class TestScriptStartsRelay(unittest.TestCase):
    """run_mt5_termux.sh THẬT (với lệnh MT5 giả) tự bật relay và dọn nó khi dừng; EA giả đi bằng tệp và vẫn nối được app."""
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.d, "MQL5", "Files"))
        self.srv = server()
        self.proc = None

    def tearDown(self):
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(signal.SIGKILL)
        subprocess.run(["pkill", "-f", "pyea_relay.py --dir " + self.d], capture_output=True)
        self.srv.close()

    def env(self, **extra):
        return dict(os.environ, NO_XVFB="1", STATUS_FILE=os.path.join(self.d, "st"), LOG_FILE=os.path.join(self.d, "log"), NOTIFY_CMD="/bin/true", LOG_POLL="0",
                    PYEA_PORT=str(self.srv.port), PYEA_TOKEN=TOKEN, MT5_DIR=self.d, MT5_CMD="sleep 60", **extra)

    def relay_pids(self):
        r = subprocess.run(["pgrep", "-f", "pyea_relay.py --dir " + self.d], capture_output=True, text=True)
        return [x for x in r.stdout.split() if x]

    def test_script_runs_relay_ea_connects_through_files_then_stop_cleans_up(self):
        self.proc = subprocess.Popen(["bash", SCRIPT, "run"], env=self.env(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.assertTrue(wait(lambda: self.relay_pids(), 10), "script không bật relay")
        link = FileLink(os.path.join(self.d, "MQL5", "Files"))
        e = FakeEA(self.srv.port, TOKEN, link=lambda: link).start()
        try:
            self.assertTrue(wait(self.srv.alive, 10), "EA đi bằng tệp qua relay do script bật không nối được app")
            b = mt5ea.Mt5EaBackend(self.srv)
            self.assertEqual(b.symbols(), ["EURUSD", "XAUUSD"])
        finally:
            e.close()
        self.proc.send_signal(signal.SIGTERM)
        self.proc.wait(timeout=15)
        self.assertTrue(wait(lambda: not self.relay_pids(), 5), "relay còn sống sau khi dừng giám sát")

    def test_relay_can_be_disabled_and_missing_python_is_only_logged(self):
        self.proc = subprocess.Popen(["bash", SCRIPT, "run"], env=self.env(PYEA_RELAY="0"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1.0)
        self.assertEqual(self.relay_pids(), [])
        self.proc.send_signal(signal.SIGTERM)
        self.proc.wait(timeout=15)
        self.proc = subprocess.Popen(["bash", SCRIPT, "run"], env=self.env(PYEA_RELAY_PY=os.path.join(self.d, "khong-co.py")), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.assertTrue(wait(lambda: "relay: không thấy" in open(os.path.join(self.d, "log"), encoding="utf-8").read() if os.path.exists(os.path.join(self.d, "log")) else False, 8))
        self.proc.send_signal(signal.SIGTERM)
        self.proc.wait(timeout=15)


if __name__ == "__main__":
    unittest.main()
