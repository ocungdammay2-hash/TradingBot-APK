"""Chợ bot có chữ ký: đóng gói/xác minh, chống sửa, danh mục + băm, cài đặt không cấp quyền."""
import hashlib
import json
import os
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from pyea import ed25519, market
from pyea.perms import PermStore
from pyea.storage import Store

SEED = bytes(range(10, 42))
BOT = '''# @permission: network(api.example.com)
from pyea import BaseBot
class B(BaseBot):
    name = "B"
'''


class TestPackage(unittest.TestCase):
    def test_pack_verify_and_tamper(self):
        blob = market.pack(BOT, SEED, "Bot Thử", "1.2", "Tác giả", "mô tả")
        d = market.verify(blob)
        self.assertEqual((d["name"], d["filename"], d["version"]), ("Bot Thử", "bot_thử.py", "1.2"))
        self.assertTrue(any("api.example.com" in x for x in d["perms"]))
        self.assertEqual(len(d["fingerprint"].split()), 6)
        doc = json.loads(blob)
        doc["code"] = doc["code"] + "\nimport os\n"
        with self.assertRaisesRegex(market.MarketError, "CHỮ KÝ"):
            market.verify(json.dumps(doc).encode())
        doc = json.loads(blob)
        doc["pub"] = ed25519.b64u(ed25519.public_key(bytes(32)))                       # đổi nhà phát hành
        with self.assertRaisesRegex(market.MarketError, "CHỮ KÝ"):
            market.verify(json.dumps(doc).encode())
        doc = json.loads(blob)
        doc["filename"] = "../evil.py"
        with self.assertRaises(market.MarketError):
            market.verify(json.dumps(doc).encode())
        for bad in (b"khong phai json", b"{}", b"x" * (market.MAX_BYTES + 1)):
            with self.assertRaises(market.MarketError):
                market.verify(bad)

    def test_refuses_to_pack_invalid_code(self):
        with self.assertRaises(market.MarketError):
            market.pack("def (:\n", SEED, "X")
        with self.assertRaises(market.MarketError):
            market.pack("x = 1\n", SEED, "X")                                          # không có class BaseBot


class TestCatalog(unittest.TestCase):
    def setUp(self):
        self.pkg = market.pack(BOT, SEED, "Bot Thử", "1.0", "A")
        pkg = self.pkg
        sha = hashlib.sha256(pkg).hexdigest()
        pub = json.loads(pkg)["pub"]
        outer = self
        self.index = {"bots": [{"name": "Bot Thử", "version": "1.0", "author": "A", "description": "d", "url": "", "pub": pub, "sha256": sha},
                               {"name": "Hỏng băm", "url": "", "sha256": "0" * 64, "pub": pub}, {"rác": 1}, "x"]}

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                if self.path == "/index.json":
                    b = json.dumps(outer.index).encode()
                elif self.path == "/bot.pyeabot":
                    b = pkg
                else:
                    self.send_response(404)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        self.index["bots"][0]["url"] = self.index["bots"][1]["url"] = self.base + "/bot.pyeabot"
        self.addCleanup(self.srv.server_close)
        self.addCleanup(self.srv.shutdown)

    def test_catalog_fetch_and_checked_download(self):
        rows = market.fetch_catalog(self.base + "/index.json")
        self.assertEqual([r["name"] for r in rows], ["Bot Thử", "Hỏng băm"])           # dòng rác bị bỏ
        p = market.fetch_package(rows[0])
        self.assertEqual(p["name"], "Bot Thử")
        with self.assertRaisesRegex(market.MarketError, "SHA-256"):
            market.fetch_package(rows[1])
        bad = dict(rows[0], pub=ed25519.b64u(ed25519.public_key(bytes(32))))
        with self.assertRaisesRegex(market.MarketError, "Khoá ký"):
            market.fetch_package(bad)
        with self.assertRaises(market.MarketError):
            market.fetch_package(self.base + "/khong-co")
        with self.assertRaisesRegex(market.MarketError, "https"):
            market.fetch_catalog("http://example.com/index.json")

    def test_install_grants_nothing_and_keeps_old_version(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        store = Store(t.name)
        p = market.fetch_package(self.base + "/bot.pyeabot")
        path, trusted = market.install(store, p, trusted=())
        self.assertFalse(trusted)
        self.assertTrue(os.path.exists(path))
        self.assertEqual(PermStore(t.name).granted(path), {})                           # chưa cấp quyền mạng nào
        market.install(store, p, trusted=[p["pub"]])
        self.assertTrue(market.install(store, p, trusted=[p["pub"]])[1])


class TestTool(unittest.TestCase):
    def test_cli_roundtrip(self):
        import bot_pack
        import contextlib
        import io
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        k, b, o, ix = (os.path.join(t.name, n) for n in ("k", "b.py", "o.pyeabot", "i.json"))
        open(b, "w").write(BOT)
        with contextlib.redirect_stdout(io.StringIO()):
            bot_pack.main(["new-key", k])
            bot_pack.main(["pack", b, k, "--name", "CLI Bot", "-o", o])
            bot_pack.main(["verify", o])
            bot_pack.main(["index", o, "--base-url", "https://x.io/b/", "-o", ix])
        row = json.load(open(ix))["bots"][0]
        self.assertEqual(row["url"], "https://x.io/b/o.pyeabot")
        self.assertEqual(row["sha256"], hashlib.sha256(open(o, "rb").read()).hexdigest())


if __name__ == "__main__":
    unittest.main()


class TestMarketUI(unittest.TestCase):
    def test_confirm_dialog_installs_and_trust_persists(self):
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import kivy_stub
        import test_ui_smoke as T
        kivy_stub.OPEN_POPUPS.clear()
        app = T.make_app()
        pkg = market.verify(market.pack(BOT, SEED, "UI Bot", "1.0", "A"))
        done = []
        app._market_confirm(pkg, lambda: done.append(1))
        blob = T.texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("HỢP LỆ", blob)
        self.assertIn("api.example.com", blob)
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Cài + tin cậy nhà phát hành")
        self.assertEqual(done, [1])
        self.assertTrue(os.path.exists(os.path.join(app.store.bots_dir, "ui_bot.py")))
        self.assertIn(pkg["pub"], app.store.load_prefs()["market_trusted"])
        app._market_confirm(pkg, lambda: None)
        self.assertIn("ĐÃ TIN CẬY", T.texts(kivy_stub.OPEN_POPUPS[-1].content))

    def test_dialogs_open(self):
        import kivy_stub
        import test_ui_smoke as T
        app = T.make_app()
        app.market_dialog()
        self.assertEqual(kivy_stub.OPEN_POPUPS[-1].title, "Chợ bot")
        app.sync_dialog()
        self.assertEqual(kivy_stub.OPEN_POPUPS[-1].title, "Sao lưu / đồng bộ")
