import os, sys, unittest
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub


class T(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_api_button_opens_dialog_and_copies_values(self):
        import test_ui_smoke as T
        app = T.make_app()
        g = app.settings_tab.gform
        g.ctrl["exchange"].text = "binance_spot"
        g._apply_visibility()
        self.assertIn("binance_spot", g._sec_btn.text)
        n0 = len(kivy_stub.OPEN_POPUPS)
        g.open_api_dialog()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertTrue(pop is not None)

    def test_feed_exchange_follows_session(self):
        import test_ui_smoke as T
        app = T.make_app()
        app.settings["exchange"] = "public"
        self.assertEqual(app.feed_exchange(), "public")          # chưa kết nối: theo cài đặt
        app._sess_ex = "simulated"
        app.is_connected = lambda: True
        self.assertEqual(app.feed_exchange(), "simulated")        # đang chạy phiên giả lập: chart phải ghi giả lập dù cài đặt đã đổi


if __name__ == "__main__":
    unittest.main()
