import os, sys, unittest
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub


class T(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_api_button_opens_dialog_and_copies_values(self):
        import test_ui_smoke as T
        app = T.make_app()
        g = app.settings_tab.gform
        g.ctrl["exchange"].text = "binance_spot"
        g._apply_visibility()
        self.assertIn("binance_spot", g._sec_btn.text)
        n0 = len(kivy_stub.OPEN_POPUPS)
        g.open_api_dialog()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertTrue(pop is not None)

    def test_dialog_opens_for_every_exchange_and_show_all(self):
        import test_ui_smoke as T
        app = T.make_app()
        g = app.settings_tab.gform
        for ex in ("simulated", "public", "binance_futures", "oanda", "exness", "ccxt"):
            g.ctrl["exchange"].text = ex
            g._apply_visibility()
            g.open_api_dialog()
        g._show_all = True
        g._apply_visibility()
        g.open_api_dialog()

    def test_feed_exchange_follows_session(self):
        import test_ui_smoke as T
        app = T.make_app()
        app.settings["exchange"] = "public"
        self.assertEqual(app.feed_exchange(), "public")          # chưa kết nối: theo cài đặt
        app._sess_ex = "simulated"
        app.is_connected = lambda: True
        self.assertEqual(app.feed_exchange(), "simulated")        # đang chạy phiên giả lập: chart phải ghi giả lập dù cài đặt đã đổi


if __name__ == "__main__":
    unittest.main()


class TestAutoInputsPlain(unittest.TestCase):
    def test_plain_assignments_and_ranges(self):
        import tempfile
        from pyea import loader
        src = ('from pyea import BaseBot\nclass B(BaseBot):\n    name = "x"\n    # == Tín hiệu ==\n'
               '    fast = 10          # SMA nhanh {2..200}\n    lot: float = 0.01  # Khối lượng {0.01..10 step 0.01}\n'
               '    mode = "a"         # Chế độ [a|b|c]\n    use_sl = True\n    def on_bar(self, c): pass\n')
        p = os.path.join(tempfile.mkdtemp(), "b.py")
        open(p, "w", encoding="utf-8").write(src)
        i = loader.inspect_bot(p).inputs
        self.assertEqual(list(i), ["fast", "lot", "mode", "use_sl"])
        self.assertEqual((i["fast"].kind, i["fast"].min, i["fast"].max), ("int", 2, 200))
        self.assertEqual((i["lot"].min, i["lot"].max, i["lot"].step), (0.01, 10.0, 0.01))
        self.assertEqual(i["mode"].choices, ["a", "b", "c"])
        self.assertEqual(i["fast"].group, "Tín hiệu")
        with self.assertRaises(ValueError):
            i["fast"].coerce("500")                                  # vượt {2..200}


class TestStopFeedback(unittest.TestCase):
    def test_stop_shows_feedback_and_not_connected_toast(self):
        import test_ui_smoke as T
        app = T.make_app()
        msgs = []
        app.toast = msgs.append
        app.is_connected = lambda: False
        app.stop_session()
        self.assertTrue(msgs and "Chưa có phiên" in msgs[-1])
        app.is_connected = lambda: True
        class C:
            stopped = False
            def stop(self): self.stopped = True
        app.ctl, app.main_ctl = C(), None
        app._stop_extra_accounts = lambda: None
        app.stop_session()
        self.assertTrue(app.ctl.stopped)
        self.assertIn("Đang ngắt", msgs[-1])
        app.bot_tab.set_running(True) if hasattr(app, "bot_tab") else None
        if hasattr(app, "bot_tab"):
            self.assertIn("ĐANG NGẮT", app.bot_tab.stop_btn.text)
