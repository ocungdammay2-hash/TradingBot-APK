"""Mẫu biểu đồ (như Template của MT5): lưu/áp/xoá, dữ liệu hỏng, giới hạn, lưu bền qua Store."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import chart_indicators as chind                   # noqa: E402
from pyea.storage import Store                               # noqa: E402


def view(n_ind=2, **over):
    inds = [chind.new_cfg("ma" if "ma" in chind.INDICATORS else next(iter(chind.INDICATORS)), i) for i in range(n_ind)]
    v = {"bars": 200, "show_markers": False, "show_lines": True, "show_grid": False, "indicators": inds, "hidden_plots": ["bot-line"]}
    v.update(over)
    return v


class TestChartTemplates(unittest.TestCase):
    def test_save_snapshot_and_apply_with_fresh_uids(self):
        prefs = {}
        v = view(2)
        name = chind.save_template(prefs, "  Xu   hướng  ", v)
        self.assertEqual(name, "Xu hướng")                                   # gọn khoảng trắng
        tpl = chind.templates(prefs)["Xu hướng"]
        self.assertEqual((tpl["bars"], tpl["show_markers"], tpl["show_lines"], tpl["show_grid"]), (200, False, True, False))
        self.assertEqual(len(tpl["indicators"]), 2)
        self.assertNotIn("hidden_plots", tpl)                                 # đường vẽ của bot không thuộc mẫu
        applied = chind.fresh(tpl)
        self.assertEqual([c["key"] for c in applied["indicators"]], [c["key"] for c in v["indicators"]])
        self.assertTrue({c["uid"] for c in applied["indicators"]}.isdisjoint({c["uid"] for c in v["indicators"]}))   # uid mới
        applied["indicators"][0]["params"]["x"] = 1                           # sửa bản áp không làm hỏng mẫu đã lưu
        self.assertNotIn("x", chind.templates(prefs)["Xu hướng"]["indicators"][0]["params"])

    def test_overwrite_delete_and_listing_sorted(self):
        prefs = {}
        chind.save_template(prefs, "b mẫu", view(1))
        chind.save_template(prefs, "A mẫu", view(2))
        self.assertEqual(list(chind.templates(prefs)), ["A mẫu", "b mẫu"])    # sắp theo tên, không phân biệt hoa thường
        chind.save_template(prefs, "A mẫu", view(0))                          # ghi đè
        self.assertEqual(len(chind.templates(prefs)["A mẫu"]["indicators"]), 0)
        self.assertTrue(chind.delete_template(prefs, "b mẫu"))
        self.assertFalse(chind.delete_template(prefs, "b mẫu"))
        self.assertEqual(list(chind.templates(prefs)), ["A mẫu"])

    def test_validation_and_limit(self):
        prefs = {}
        for bad in ("", "   ", None):
            with self.assertRaises(ValueError):
                chind.save_template(prefs, bad, view(1))
        self.assertEqual(len(chind.save_template(prefs, "x" * 80, view(0))), 40)   # cắt tên 40 ký tự
        for i in range(chind.MAX_TEMPLATES - 1):
            chind.save_template(prefs, "m%d" % i, view(0))
        with self.assertRaises(ValueError):
            chind.save_template(prefs, "một mẫu nữa", view(0))
        chind.save_template(prefs, "m0", view(1))                             # ghi đè mẫu có sẵn vẫn được khi đã đủ số lượng

    def test_corrupt_data_is_tolerated(self):
        self.assertEqual(list(chind.templates({})), [])
        self.assertEqual(list(chind.templates({"chart_templates": "xyz"})), [])
        prefs = {"chart_templates": {"ok": {"bars": "abc", "indicators": [{"key": "không-có"}, "rác", {"key": next(iter(chind.INDICATORS)), "params": {"p": "?"}}]},
                                     "hỏng": 5}}
        t = chind.templates(prefs)
        self.assertEqual(list(t), ["ok"])
        self.assertEqual(t["ok"]["bars"], chind.DEFAULT_BARS)                 # số nến hỏng -> mặc định
        self.assertEqual(len(t["ok"]["indicators"]), 1)                       # chỉ báo lạ/rác bị bỏ
        self.assertEqual(chind.snapshot({"bars": 5})["bars"], 20)             # kẹp biên
        self.assertEqual(chind.snapshot({"bars": 10 ** 6})["bars"], 2000)
        prefs2 = {"chart_templates": ["lỗi"]}
        chind.save_template(prefs2, "mới", view(1))                           # kiểu sai được thay bằng dict
        self.assertEqual(list(chind.templates(prefs2)), ["mới"])

    def test_persist_through_store(self):
        st = Store(tempfile.mkdtemp())
        prefs = st.load_prefs()
        chind.save_template(prefs, "Dao động", view(2))
        st.save_prefs(prefs)
        again = Store(st.base).load_prefs()
        t = chind.templates(again)["Dao động"]
        self.assertEqual(len(t["indicators"]), 2)
        self.assertEqual(t["bars"], 200)


if __name__ == "__main__":
    unittest.main()
