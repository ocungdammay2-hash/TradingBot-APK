"""Phiên bản bot + hoàn tác."""
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pyea import botversions as bv
from pyea.codeedit import overwrite_with_backup
from pyea.storage import Store


class TestVersions(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = os.path.join(self.tmp.name, "bot.py")
        open(self.p, "w").write("v1\n")

    def test_snapshot_dedupe_and_listing(self):
        self.assertIsNotNone(bv.snapshot(self.p, "ai", now=1_700_000_000))
        self.assertIsNone(bv.snapshot(self.p, "ai"))                 # trùng nội dung bản mới nhất: không lưu
        open(self.p, "w").write("v2\n")
        bv.snapshot(self.p, "nap", now=1_700_000_100)
        it = bv.list_versions(self.p)
        self.assertEqual([i["tag"] for i in it], ["nap", "ai"])      # mới -> cũ
        self.assertEqual(it[0]["label"], "Nạp lại file")
        self.assertEqual(bv.snapshot(os.path.join(self.tmp.name, "khong_co.py")), None)

    def test_restore_is_itself_undoable(self):
        bv.snapshot(self.p, "ai", now=1_700_000_000)
        open(self.p, "w").write("v2\n")
        first = bv.list_versions(self.p)[0]["name"]
        self.assertEqual(bv.restore(self.p, first, now=1_700_000_500), "v1\n")
        self.assertEqual(open(self.p).read(), "v1\n")
        tags = [i["tag"] for i in bv.list_versions(self.p)]
        self.assertIn("khoiphuc", tags)                              # v2 đã được cất trước khi khôi phục
        back = [i for i in bv.list_versions(self.p) if i["tag"] == "khoiphuc"][0]["name"]
        self.assertEqual(bv.restore(self.p, back, now=1_700_000_900), "v2\n")

    def test_path_traversal_rejected_and_prune(self):
        with self.assertRaises(ValueError):
            bv.read_version(self.p, "../../etc/passwd")
        for i in range(bv.MAX_KEEP + 8):
            open(self.p, "w").write("n%d\n" % i)
            bv.snapshot(self.p, "tay", now=1_700_000_000 + i)
        self.assertEqual(len(bv.list_versions(self.p)), bv.MAX_KEEP)
        self.assertEqual(open(os.path.join(bv.vdir(self.p), bv.list_versions(self.p)[0]["name"])).read(), "n%d\n" % (bv.MAX_KEEP + 7))

    def test_diff_stats(self):
        self.assertEqual(bv.diff_stats("a\nb\n", "a\nc\nd\n"), (2, 1))


class TestHooks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = Store(self.tmp.name)

    def test_ai_overwrite_reinstall_delete_all_keep_old_text(self):
        p = self.store.install_bot_text("x.py", "A\n")
        overwrite_with_backup(p, "B\n")
        self.store.install_bot_text("x.py", "C\n")
        self.store.delete_bot(p)
        texts = {bv.read_version(p, i["name"]) for i in bv.list_versions(p)}
        self.assertEqual(texts, {"A\n", "B\n", "C\n"})
        self.assertFalse(os.path.exists(p))
        self.assertNotIn(".versions", [os.path.basename(x) for x in self.store.list_bots()])

    def test_dialog_lists_and_restores(self):
        import kivy_stub
        import test_ui_smoke as T
        kivy_stub.OPEN_POPUPS.clear()
        app = T.make_app()
        p = app.store.install_bot_text("zz_test.py", "from pyea.sdk import BaseBot\nclass Bot(BaseBot):\n    pass\n")
        app.store.install_bot_text("zz_test.py", "from pyea.sdk import BaseBot\nclass Bot(BaseBot):\n    x = 1\n")
        app.selected = p
        app.versions_dialog()
        blob = T.texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("Nạp lại file", blob)
        self.assertIn("so với hiện tại", blob)
        name = bv.list_versions(p)[0]["name"]
        app._bot_in_use = lambda _p: False
        app.versions_dialog()
        bv.restore(p, name)
        self.assertNotIn("x = 1", open(p).read())

    def test_dialog_without_selection(self):
        import test_ui_smoke as T
        app = T.make_app()
        msgs = []
        app.toast = msgs.append
        app.selected = None
        app.versions_dialog()
        self.assertIn("Chọn", msgs[0])


if __name__ == "__main__":
    unittest.main()
