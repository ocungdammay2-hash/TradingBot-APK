"""SL/TP NATIVE + danh tính vị thế (ticket) qua CỔNG PyEA tự dựng (gateway/mt_gateway.py) và qua hồ sơ REST (Profile).

Cùng bộ kịch bản chung `Conformance` (test_protect_contract) và `Identity` (test_ref_identity) chạy thêm trên:
  * Gateway + MetaTrader5 python (backend `mt5`, TRADE_ACTION_SLTP, history_deals_get(position=...))
  * Gateway + EA relay (backend `ea`, lệnh `sltp`/`posdeals` trong giao thức văn bản)
Test riêng: định dạng yêu cầu đúng tài liệu MQL5/MQL4, SL/TP không đổi = thành công (10025 / lỗi 1), EA/cổng BẢN CŨ tự tắt SL/TP native (vỏ tự canh),
MT4 đóng một phần đổi ticket -> không dùng đóng/đối soát theo ticket, và Profile REST khai op tuỳ chọn."""
import json
import os
import sys
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))
sys.path.insert(0, HERE)

import mt_gateway                                                              # noqa: E402
import test_protect_contract as tc                                             # noqa: E402
from fake_mt import FakeEA, FakeMt5, MtCore                                    # noqa: E402
from pyea import ratelimit                                                     # noqa: E402
from pyea.bridges import BridgeError, GatewayBackend, MtBroker, ProfileBackend # noqa: E402
from test_ref_identity import Identity, MtExt                                  # noqa: E402


def wait(cond, t=5.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


TOKEN = "gw-secret"


class SyncGw(GatewayBackend):
    """Relay vốn «nhất quán sau cùng»: trước mỗi lần ĐỌC đợi EA giả đẩy thêm 2 lượt để test đọc thấy ngay trạng thái mới nhất (xác định, không ngủ mò)."""
    def __init__(self, url, token, ea):
        GatewayBackend.__init__(self, url, token)
        self.ea = ea

    def _req(self, method, path, params=None, body=None):
        if method == "GET" and path != "/v1/ping":
            n = self.ea.polls
            wait(lambda: self.ea.polls >= n + 2)
        return GatewayBackend._req(self, method, path, params, body)


def _serve(backend):
    srv = mt_gateway.serve(backend, "127.0.0.1", 0, TOKEN)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, "http://127.0.0.1:%d" % srv.server_address[1]


class GwMt5H(tc.MtH):
    """Cổng + MetaTrader5 python: dữ liệu đọc ghi tức thì."""
    NAME, EXCHANGE = "gateway_mt5", "mt5gw"

    def start(self):
        self.core = MtCore()
        self.mt5 = FakeMt5(self.core, offset=7200)
        self.be = mt_gateway.Mt5Backend(mt5=self.mt5, login="1", password="p", server="Demo")
        self.srv, self.url = _serve(self.be)

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()

    def reset(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.sltp_calls.clear(); c.log.clear()
        c.balance, c.reject_next = 10000.0, None
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.mt5.requests.clear()

    def make_broker(self):
        return MtBroker(GatewayBackend(self.url, TOKEN))

    def writes(self):
        return len(self.mt5.requests)


class GwEaH(tc.MtH):
    """Cổng + EA relay (EA giả nói đúng giao thức văn bản)."""
    NAME, EXCHANGE = "gateway_ea", "mt5gw"
    WRITE_ACTS = ("market", "close", "pending", "modify", "cancel", "sltp")

    def start(self):
        self.core = MtCore()
        self.be = mt_gateway.EaRelayBackend(cmd_timeout=5.0)
        self.srv, self.url = _serve(self.be)
        self.ea = FakeEA(self.core, self.url, TOKEN, interval=0.01).start()
        assert wait(lambda: self.be.state["account"] is not None)

    def close(self):
        self.ea.close()
        self.srv.shutdown()
        self.srv.server_close()

    def reset(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.sltp_calls.clear(); c.log.clear()
        c.balance, c.reject_next = 10000.0, None
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.be.state["deals"].clear()
        self.ea.cmd_log.clear()
        n = self.ea.polls
        wait(lambda: self.ea.polls >= n + 3)

    def make_broker(self):
        b = MtBroker(SyncGw(self.url, TOKEN, self.ea))
        b.OP_WAIT = 3.0
        return b

    def writes(self):
        return len([c for c in self.ea.cmd_log if c[0] in self.WRITE_ACTS])


class TestConformance_gateway_mt5(tc.Conformance, unittest.TestCase):
    H = GwMt5H


class TestConformance_gateway_ea(tc.Conformance, unittest.TestCase):
    H = GwEaH


class TestIdentity_gateway_mt5(Identity, unittest.TestCase):
    H, EXT = GwMt5H, MtExt


class TestIdentity_gateway_ea(Identity, unittest.TestCase):
    H, EXT = GwEaH, MtExt


# =========================================================================================== riêng cổng MT5 (python)
class TestGatewayMt5Protect(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h = GwMt5H()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        self.h.reset()
        self.core, self.mt5 = self.h.core, self.h.mt5
        self.b = GatewayBackend(self.h.url, TOKEN)

    def _open(self, comment="pyea", side="buy", vol=0.05):
        pid, _, _ = self.core.open("EURUSD", side, vol, comment)
        return pid

    def test_ping_declares_features_and_backend_enables_native_levels(self):
        self.assertEqual(set(self.b._req("GET", "/v1/ping")["features"]), {"sltp", "posdeals", "comment", "history"})
        self.assertTrue(self.b.can_modify_position)
        self.assertTrue(MtBroker(self.b).prot_supported())

    def test_modify_position_request_follows_mql5_docs(self):
        pid = self._open()
        self.mt5.requests.clear()
        self.b.modify_position(pid, 1.0900, 1.1200)
        rq = self.mt5.requests[-1]
        self.assertEqual((rq["action"], rq["symbol"], rq["position"], rq["sl"], rq["tp"]), (self.mt5.TRADE_ACTION_SLTP, "EURUSD", int(pid), 1.09, 1.12))
        self.assertEqual((self.core.positions[pid]["sl"], self.core.positions[pid]["tp"]), (1.09, 1.12))

    def test_zero_removes_a_level(self):
        pid = self._open()
        self.b.modify_position(pid, 1.0900, 1.1200)
        self.b.modify_position(pid, 0.0, 1.1200)
        self.assertEqual((self.core.positions[pid]["sl"], self.core.positions[pid]["tp"]), (0.0, 1.12))

    def test_unchanged_levels_are_success_not_error(self):
        pid = self._open()
        self.b.modify_position(pid, 1.0900, 1.1200)
        self.b.modify_position(pid, 1.0900, 1.1200)                           # MT5 trả 10025 «không có thay đổi»
        self.assertEqual(self.mt5.requests[-1]["action"], self.mt5.TRADE_ACTION_SLTP)

    def test_missing_position_is_a_clear_error(self):
        with self.assertRaises(BridgeError) as cm:
            self.b.modify_position("424242", 1.09, 1.12)
        self.assertEqual(cm.exception.status, 404)
        self.assertIn("424242", str(cm.exception))

    def test_server_reject_surfaces_retcode(self):
        pid = self._open()
        self.core.reject_next = ("10016", "Invalid stops")
        with self.assertRaises(BridgeError) as cm:
            self.b.modify_position(pid, 1.2, 1.3)
        self.assertIn("10016", str(cm.exception))

    def test_positions_carry_comment_so_only_app_positions_are_owned(self):
        mine, manual = self._open("pyea"), self._open("")
        rows = {p["id"]: p for p in self.b.positions()}
        self.assertEqual((rows[mine]["comment"], rows[manual]["comment"]), ("pyea", ""))
        lv = {r["ref"]: r["owned"] for r in MtBroker(self.b).position_levels("EURUSD")}
        self.assertEqual((lv[mine], lv[manual]), (True, False))

    def test_deals_have_position_entry_and_reason(self):
        pid = self._open()
        self.core.close(pid)
        self.core.positions.clear()
        deals = [d for d in self.b.deals(time.time() - 60) if d["position_id"] == pid]
        self.assertEqual([d["entry"] for d in deals], ["IN", "OUT"])
        pid2 = self._open()
        self.core.positions[pid2]["sl"] = 1.0900
        self.core.set_price("EURUSD", 1.0890, 1.0892)                          # máy chủ chạm SL
        out = [d for d in self.b.deals_by_position(pid2) if d["entry"] == "OUT"]
        self.assertEqual([(d["reason"], d["price"]) for d in out], [("sl", 1.09)])

    def test_deals_by_position_uses_position_filter_not_a_time_window(self):
        pid = self._open()
        self.core.close(pid)
        self.mt5.history_calls = []
        orig = self.mt5.history_deals_get
        seen = []
        self.mt5.history_deals_get = lambda *a, **k: (seen.append((a, k)), orig(*a, **k))[1]
        try:
            rows = self.b.deals_by_position(pid)
        finally:
            self.mt5.history_deals_get = orig
        self.assertEqual(seen[-1][1].get("position"), int(pid))
        self.assertEqual(len(rows), 2)

    def test_broker_position_close_reports_exit_price_of_that_ticket(self):
        pid = self._open()
        self.core.set_price("EURUSD", 1.0950, 1.0952)
        self.core.close(pid)
        r = MtBroker(self.b).position_close(pid)
        self.assertEqual(r["state"], "filled")
        self.assertAlmostEqual(r["price"], 1.0950, 6)

    def test_old_gateway_without_features_keeps_native_levels_off(self):
        b = GatewayBackend(self.h.url, TOKEN)
        orig = b._req
        b._req = lambda m, p, params=None, body=None: {"ok": True, "backend": "mt5"} if p == "/v1/ping" else orig(m, p, params, body)
        self.assertFalse(b.can_modify_position)
        self.assertFalse(MtBroker(b).prot_supported())
        self.assertEqual(b.deals_by_position("1"), [])                         # rơi về lọc deals (cổng cũ không có position_id) - không lỗi

    def test_unreachable_gateway_does_not_cache_a_negative_answer(self):
        b = GatewayBackend("http://127.0.0.1:1", TOKEN, timeout=0.5)
        self.assertFalse(b.can_modify_position)
        self.assertIsNone(b._features)                                        # lỗi mạng KHÔNG được nhớ thành «không hỗ trợ»
        b.url = self.h.url
        self.assertTrue(b.can_modify_position)


# =========================================================================================== riêng cổng + EA relay
class TestGatewayEaProtect(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.h = GwEaH()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        self.h.reset()
        self.core, self.ea, self.be = self.h.core, self.h.ea, self.h.be
        self.ea.caps = "sltp,posdeals,comment,history"
        self.sync()
        self.b = SyncGw(self.h.url, TOKEN, self.ea)

    def sync(self, n=3):
        k = self.ea.polls
        wait(lambda: self.ea.polls >= k + n)

    def _open(self, comment="pyea"):
        pid, _, _ = self.core.open("EURUSD", "buy", 0.05, comment)
        self.sync()
        return pid

    def test_hello_declares_capabilities_and_ping_exposes_them(self):
        self.assertEqual(set(self.b._req("GET", "/v1/ping")["features"]), {"sltp", "posdeals", "comment", "history"})
        self.assertTrue(self.b.can_modify_position)

    def test_sltp_command_wire_format_and_effect(self):
        pid = self._open()
        self.b.modify_position(pid, 1.0900, 1.1200)
        self.assertEqual(self.ea.cmd_log[-1], ["sltp", pid, "1.09", "1.12"])
        self.assertEqual((self.core.positions[pid]["sl"], self.core.positions[pid]["tp"]), (1.09, 1.12))
        self.b.modify_position(pid, 1.0900, 1.1200)                           # EA báo 10025: vẫn thành công
        self.b.modify_position(pid, 0, 1.1200)
        self.assertEqual(self.ea.cmd_log[-1], ["sltp", pid, "0", "1.12"])
        self.assertEqual(self.core.positions[pid]["sl"], 0.0)

    def test_missing_position_error_comes_from_terminal(self):
        with self.assertRaises(BridgeError) as cm:
            self.b.modify_position("424242", 1.09, 1.12)
        self.assertIn("10036", str(cm.exception))                                # mã lỗi của terminal (EA giả) được chuyển nguyên văn lên app

    def test_positions_and_deals_carry_the_new_fields(self):
        mine, manual = self._open("pyea"), self._open("")
        rows = {p["id"]: p for p in self.b.positions()}
        self.assertEqual((rows[mine]["comment"], rows[manual]["comment"]), ("pyea", ""))
        self.core.close(mine)
        self.sync()
        d = [x for x in self.b.deals(time.time() - 60) if x["position_id"] == mine]
        self.assertEqual([x["entry"] for x in d], ["IN", "OUT"])

    def test_posdeals_command_returns_every_deal_of_the_position(self):
        pid = self._open()
        self.core.close(pid)
        self.sync()
        self.be.state["deals"].clear()                                         # như deal đã quá cửa sổ EA đang đẩy: chỉ lệnh posdeals lấy lại được
        self.ea.deals_sent = set()
        rows = self.be.deals_by_position(pid)["deals"]
        self.assertEqual(self.ea.cmd_log[-1], ["posdeals", pid])
        self.assertEqual(sorted(d["entry"] for d in rows), ["IN", "OUT"])

    def test_old_ea_without_capabilities_turns_native_levels_off_with_a_clear_reason(self):
        self.ea.caps = ""                                                      # EA bản cũ: HELLO không khai, POS/DEAL ngắn
        self.sync(4)
        b = SyncGw(self.h.url, TOKEN, self.ea)
        self.assertFalse(b.can_modify_position)
        self.assertFalse(MtBroker(b).prot_supported())
        with self.assertRaises(mt_gateway.GwError) as cm:
            self.be.modify_position("1", 1.0, 1.1)
        self.assertEqual(cm.exception.code, "EA_OLD")
        self.assertIn("biên dịch", str(cm.exception))
        pid = self._open()                                                     # EA cũ vẫn đặt lệnh/đọc vị thế bình thường (không comment)
        self.assertEqual([p["comment"] for p in self.b.positions() if p["id"] == pid], [""])
        self.assertEqual(self.be.deals_by_position(pid)["deals"], [])          # không lệnh posdeals, deal cũ không có position_id: rỗng, không lỗi

    def test_mt4_platform_stops_using_ticket_identity_because_partial_close_changes_ticket(self):
        mt5_broker = MtBroker(self.b)
        mt5_broker.prepare("EURUSD")
        self.assertTrue(mt5_broker.CLOSE_BY_REF)
        self.ea.platform = "MT4"
        self.sync(4)
        mt4 = MtBroker(SyncGw(self.h.url, TOKEN, self.ea))
        mt4.prepare("EURUSD")
        self.assertFalse(mt4.CLOSE_BY_REF)
        self.assertIs(MtBroker.CLOSE_BY_REF, True)                            # lớp không bị đổi, chỉ riêng broker MT4
        self.ea.platform = "MT5"
        self.sync(4)


# =========================================================================================== Profile REST
class _Vendor(BaseHTTPRequestHandler):
    store = None

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _handle(self, m):
        st = self.store
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n)) if n else {}
        path, _, qs = self.path.partition("?")
        st["calls"].append((m, path, qs, body))
        if m == "GET" and path == "/positions":
            return self._send({"items": st["positions"]})
        if m == "POST" and path.startswith("/positions/") and path.endswith("/sltp"):
            tk = path.split("/")[2]
            for p in st["positions"]:
                if p["ticket"] == tk:
                    p["sl"], p["tp"] = body["sl"], body["tp"]
                    return self._send({"ok": True})
            return self._send({"error": "no position"}, 404)
        if m == "GET" and path == "/deals":
            return self._send({"items": [d for d in st["deals"] if ("position=" + d["pos"]) in qs or "position=" not in qs]})
        self._send({"error": "not found"}, 404)

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")


class TestProfileProtect(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = {"calls": [], "positions": [], "deals": []}
        handler = type("H", (_Vendor,), {"store": cls.store})
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    PROFILE = {"name": "vendor", "ops": {
        "positions": {"path": "/positions", "list": "items",
                      "map": {"id": "ticket", "symbol": "symbol", "side": "type", "volume": "lots", "price": "open", "sl": "sl", "tp": "tp", "time": "t", "comment": "cmt"}},
        "modify_position": {"method": "POST", "path": "/positions/{position_id}/sltp", "body": {"sl": "{sl}", "tp": "{tp}"}},
        "deals_by_position": {"path": "/deals", "params": {"position": "{position_id}"}, "list": "items",
                              "map": {"id": "id", "time": "t", "symbol": "symbol", "side": "side", "qty": "qty", "price": "price", "fee": "fee", "pnl": "pnl",
                                      "order_id": "order", "position_id": "pos", "entry": "entry", "reason": "why"}}},
        "side": {"buy": "BUY", "sell": "SELL"}}

    def setUp(self):
        ratelimit.reset_all()
        self.store["calls"].clear()
        self.store["positions"][:] = [{"ticket": "11", "symbol": "EURUSD", "type": "BUY", "lots": 0.05, "open": 1.1, "sl": 0, "tp": 0, "t": 1000, "cmt": "pyea"},
                                      {"ticket": "12", "symbol": "EURUSD", "type": "BUY", "lots": 0.02, "open": 1.1, "sl": 1.0, "tp": 0, "t": 1000, "cmt": ""}]
        self.store["deals"][:] = [{"id": "d1", "t": 1000, "symbol": "EURUSD", "side": "BUY", "qty": 0.05, "price": 1.1, "fee": 0, "pnl": 0, "order": "11", "pos": "11",
                                   "entry": "IN", "why": ""},
                                  {"id": "d2", "t": 1100, "symbol": "EURUSD", "side": "SELL", "qty": 0.05, "price": 1.095, "fee": 0, "pnl": -5, "order": "99", "pos": "11",
                                   "entry": "OUT", "why": "SL"}]
        self.be = ProfileBackend(dict(self.PROFILE, base=self.base))

    def test_declared_ops_enable_native_levels_by_ticket(self):
        self.assertTrue(self.be.can_modify_position)
        self.assertTrue(MtBroker(self.be).prot_supported())

    def test_profile_without_modify_op_or_comment_field_stays_off(self):
        no_op = json.loads(json.dumps(self.PROFILE)); no_op["ops"].pop("modify_position")
        no_cmt = json.loads(json.dumps(self.PROFILE)); no_cmt["ops"]["positions"]["map"].pop("comment")
        self.assertFalse(ProfileBackend(dict(no_op, base=self.base)).can_modify_position)
        self.assertFalse(ProfileBackend(dict(no_cmt, base=self.base)).can_modify_position)       # không nhận ra vị thế của app -> không sửa SL/TP

    def test_modify_position_sends_numbers_and_only_touches_owned_positions(self):
        br = MtBroker(self.be)
        lv = {r["ref"]: r for r in br.position_levels("EURUSD")}
        self.assertEqual((lv["11"]["owned"], lv["12"]["owned"]), (True, False))
        br.sync_protection("EURUSD", [{"pid": 1, "ref": "11", "side": "sell", "qty": 0.05, "sl": 1.09, "tp": 1.12, "own": True}])
        post = [c for c in self.store["calls"] if c[0] == "POST"]
        self.assertEqual(len(post), 1)
        self.assertEqual((post[0][1], post[0][3]), ("/positions/11/sltp", {"sl": 1.09, "tp": 1.12}))
        self.assertEqual((self.store["positions"][1]["sl"], self.store["positions"][1]["tp"]), (1.0, 0))      # vị thế đặt tay nguyên vẹn

    def test_deals_by_position_op_gives_exit_price_of_that_ticket(self):
        r = MtBroker(self.be).position_close("11")
        self.assertEqual((r["state"], r["price"], r["reason"]), ("filled", 1.095, "sl"))

    def test_without_deals_by_position_op_close_result_is_unknown_not_a_crash(self):
        prof = json.loads(json.dumps(self.PROFILE)); prof["ops"].pop("deals_by_position")
        be = ProfileBackend(dict(prof, base=self.base))
        self.assertIsNone(MtBroker(be).position_close("11", raising=False))


if __name__ == "__main__":
    unittest.main()
