"""Chạy LOGIC giao diện bằng Kivy giả (không kiểm tra hiển thị thật): dựng 8 tab, kết nối phiên, Market Watch,
đặt lệnh thủ công, gắn bot, biểu đồ + chạm chấm -> popup lý do, backtest, chế độ dịch vụ nền, AI, chẩn đoán."""
import os, sys, tempfile, threading, time, unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub
kivy_stub.install()

from kivy.uix.textinput import TextInput                         # noqa: E402  (stub)
from pyea import android_native as native                        # noqa: E402
from pyea.ipc import ServiceHandle, ServiceHost                  # noqa: E402
import pyea.ui as ui                                             # noqa: E402


def walk(w):
    yield w
    for c in getattr(w, "children", []):
        yield from walk(c)


def texts(w):
    return "\n".join(str(getattr(x, "text", "")) for x in walk(w))


def find(root, pred):
    return [x for x in walk(root) if pred(x)]


def inputs_of(root):
    """TextInput theo THỨ TỰ THÊM VÀO (children của Kivy được lưu đảo ngược)."""
    return list(reversed(find(root, lambda x: isinstance(x, TextInput))))


def press(root, label):
    """Bấm nút có text == label trong cây widget (gọi callback on_release)."""
    for x in walk(root):
        if getattr(x, "text", None) == label and x._binds.get("on_release"):
            for cb in x._binds["on_release"]:
                cb(x)
            return True
    raise AssertionError("không thấy nút %r" % label)


def wait(cond, timeout=15.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:
            pass
        time.sleep(0.05)
    return False


def make_app(**settings):
    tmp = tempfile.mkdtemp()
    app = ui.PyEAApp()
    app.user_data_dir = tmp
    app.build()
    g = app.settings_tab.gform.ctrl
    g["tick_interval"].text = "0.2"
    g["sim_speed"].text = "200"
    g["history_bars"].text = "200"
    g["initial_balance"].text = "100000"
    g["max_loss_pct"].text = "0"
    g["background_service"].active = False
    for k, v in settings.items():
        g[k].text = v
    return app


class TestUISmoke(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def drive(self, app, cond, timeout=15.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.1)
        return False

    def test_build_tabs_and_seed(self):
        app = make_app()
        self.assertEqual(list(app.tabs), ["market", "trade", "bots", "chart", "bt", "ai", "settings", "log"])
        self.assertEqual(len(app.attach_cfgs), 1)
        self.assertEqual(app.attach_cfgs[0]["symbol"], "BTCUSD")
        self.assertTrue(app.save_forms())
        self.assertEqual(app.settings["tick_interval"], 0.2)
        app.settings_tab.gform.ctrl["tick_interval"].text = "abc"
        self.assertFalse(app.save_forms())
        self.assertTrue(kivy_stub.OPEN_POPUPS)

    def test_connect_market_watch_manual_order_and_chart_tap(self):
        app = make_app()
        app.start_session(run_bots=True)
        self.assertTrue(app.is_connected())
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and len(app.last_snap["watch"]) >= 4))
        self.assertGreaterEqual(len(app.market_tab.rows), 6)
        self.assertIn("EURUSD", app.market_tab.rows)
        self.assertIn("/", app.market_tab.rows["EURUSD"].text)                      # có bid / ask
        # --- đặt lệnh thủ công qua hộp thoại
        app.open_order_dialog("XAUUSD")
        dlg = kivy_stub.OPEN_POPUPS[-1]
        inputs = inputs_of(dlg.content)
        inputs[0].text = "0.5"
        press(dlg.content, "MUA")
        press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")                 # mặc định có bước xác nhận (confirm_trades)
        self.assertTrue(any("Đã MUA" in texts(p.content) for p in kivy_stub.OPEN_POPUPS), [texts(p.content)[:80] for p in kivy_stub.OPEN_POPUPS])
        self.assertTrue(self.drive(app, lambda: any(p.symbol == "XAUUSD" for p in app.last_snap["positions"])))
        pos = next(p for p in app.last_snap["positions"] if p.symbol == "XAUUSD")
        self.assertEqual(pos.owner, "manual")
        self.assertEqual(len(app.trade_tab._rows), len(app.last_snap["positions"]))
        # --- sửa SL/TP
        app.open_modify_dialog(pos.id)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = inputs_of(dlg.content)
        t = app.last_snap["watch"]["XAUUSD"]
        ins[0].text, ins[1].text = "%.2f" % (t["bid"] * 0.5), "%.2f" % (t["bid"] * 1.5)
        press(dlg.content, "Lưu")
        self.assertTrue(self.drive(app, lambda: next(p for p in app.last_snap["positions"] if p.id == pos.id).sl > 0))
        # --- biểu đồ XAUUSD: chấm lệnh thủ công, chạm -> popup lý do
        app.set_chart("XAUUSD", "5m")
        self.assertTrue(self.drive(app, lambda: app.chart_tab.panel.chart.candles and app.chart_tab.panel.chart.events))
        ch = app.chart_tab.panel.chart
        ch.redraw()
        x, y, ev = next(h for h in ch._hits if h[2].kind == "open")
        n0 = len(kivy_stub.OPEN_POPUPS)
        ch._tap(x + 2, y + 2)
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        blob = texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("thủ công", blob); self.assertIn("Nguồn quyết định", blob)
        # --- đóng lệnh: xác nhận
        app.close_one(pos.id)
        press(kivy_stub.OPEN_POPUPS[-1].content, "Đóng")
        self.assertTrue(self.drive(app, lambda: not any(p.id == pos.id for p in app.last_snap["positions"])))
        self.assertTrue(any(t.owner == "manual" for t in app.last_snap["trades"]))
        # --- ngắt phiên
        app.stop_session()
        self.assertTrue(self.drive(app, lambda: not app.is_connected(), 20))

    def test_attach_bot_to_other_asset_and_toggle_remove(self):
        app = make_app()
        app.start_session(run_bots=True)
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready")))
        app.chart_sym = "EURUSD"
        app.open_attach_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        press(dlg.content, "Gắn bot")
        self.assertEqual(len(app.attach_cfgs), 2)
        new = app.attach_cfgs[-1]
        self.assertEqual(new["symbol"], "EURUSD")
        self.assertTrue(self.drive(app, lambda: len(app.last_snap["instances"]) == 2 and
                                   all(i["status"] == "running" for i in app.last_snap["instances"]), 20))
        self.assertIn(new["iid"], app.attach_tab._att)
        l1, l2, l3, tog, _l4 = app.attach_tab._att[new["iid"]]
        self.assertIn("EURUSD", l1.text); self.assertEqual(tog.text, "Dừng")
        app.toggle_instance(new["iid"])
        self.assertTrue(self.drive(app, lambda: next(i for i in app.last_snap["instances"] if i["iid"] == new["iid"])["status"] in ("stopped", "stopping")))
        app.remove_attachment(new["iid"])
        press(kivy_stub.OPEN_POPUPS[-1].content, "Gỡ")
        self.assertEqual(len(app.attach_cfgs), 1)
        self.assertTrue(self.drive(app, lambda: len(app.last_snap["instances"]) == 1))
        app.stop_session()

    def test_backtest_tab_end_to_end(self):
        app = make_app()
        bt = app.bt_tab
        c = bt.form.ctrl
        c["symbol"].text, c["timeframe"].text, c["bars"].text, c["warmup"].text = "ETHUSD", "5m", "1500", "100"
        c["initial_balance"].text = "50000"
        bt.bot.text = "ma_cross.py"
        bt.run()
        self.assertTrue(wait(lambda: bt.res is not None, 30), bt.prog.text)
        self.assertTrue(bt.res.ok, bt.res.error)
        self.assertGreater(len(bt.res.trades), 5)
        self.assertNotEqual(bt.s["Tổng số lệnh"].v.text, "-")
        ch = bt.panel.chart
        ch.bars = 400; ch.redraw()
        self.assertTrue(ch._hits)
        x, y, ev = next(h for h in ch._hits if h[2].kind == "open")
        ch._tap(x, y)
        blob = texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("cắt", blob); self.assertIn("SMA10", blob); self.assertIn("Điều kiện / thông số kích hoạt", blob)
        bt.full_report()
        self.assertIn("Profit factor", texts(kivy_stub.OPEN_POPUPS[-1].content))
        self.assertGreater(len(bt.tr.children), 7)

    def test_backtest_tab_debug_log_and_html_report(self):
        app = make_app()
        bt = app.bt_tab
        c = bt.form.ctrl
        c["symbol"].text, c["timeframe"].text, c["bars"].text, c["warmup"].text = "ETHUSD", "5m", "800", "100"
        c["debug"].text = "Từng dòng"
        bt.bot.text = "ma_cross.py"
        bt.run()
        self.assertTrue(wait(lambda: bt.res is not None, 30), bt.prog.text)
        self.assertTrue(bt.res.ok, bt.res.error)
        self.assertIn("DEBUG BOT", bt.debug_text)
        bt.debug_dialog()
        self.assertIn("DEBUG BOT", texts(kivy_stub.OPEN_POPUPS[-1].content))
        bt.save_report_html()
        blob = texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("Đã lưu báo cáo HTML", kivy_stub.OPEN_POPUPS[-1].title)
        path = [ln for ln in blob.splitlines() if ln.strip().endswith(".html")][0].strip()
        self.assertIn("Tăng trưởng số dư", open(path, encoding="utf-8").read())

    def test_walk_forward_dialog_end_to_end_and_validation(self):
        app = make_app()
        bt = app.bt_tab
        c = bt.form.ctrl
        c["symbol"].text, c["timeframe"].text, c["bars"].text, c["warmup"].text = "ETHUSD", "5m", "1500", "100"
        bt.bot.text = "ma_cross.py"
        bt.walk_forward_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        self.assertEqual(dlg.title, "Walk-forward")
        ins = inputs_of(dlg.content)                       # từ, đến, bước, nến IS, nến OOS
        ins[0].text, ins[1].text, ins[2].text, ins[3].text, ins[4].text = "5", "8", "3", "10", "200"
        press(dlg.content, "Chạy")
        self.assertIn("IS >= 20", texts(dlg.content))        # IS quá ngắn: báo lỗi, hộp thoại giữ nguyên
        ins[3].text = "500"
        press(dlg.content, "Chạy")
        self.assertTrue(wait(lambda: any(p.title == "Kết quả walk-forward" for p in kivy_stub.OPEN_POPUPS), 60), bt.prog.text)
        res = [p for p in kivy_stub.OPEN_POPUPS if p.title == "Kết quả walk-forward"][-1]
        blob = texts(res.content)
        self.assertIn("TỔNG HỢP CÁC ĐOẠN OOS", blob)
        self.assertIn("WFE", blob)
        self.assertIn("#1", blob)
        self.assertIn("fast=", blob)                         # tham số đã chọn của từng cửa sổ
        self.assertFalse(bt._busy)

    def test_walk_forward_reports_insufficient_data_via_toast(self):
        app = make_app()
        bt = app.bt_tab
        c = bt.form.ctrl
        c["symbol"].text, c["timeframe"].text, c["bars"].text, c["warmup"].text = "ETHUSD", "5m", "300", "100"
        bt.bot.text = "ma_cross.py"
        toasts = []
        app.toast = lambda m, *a, **k: toasts.append(m)
        bt.walk_forward_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = inputs_of(dlg.content)
        ins[0].text, ins[1].text, ins[2].text, ins[3].text, ins[4].text = "5", "8", "3", "500", "200"
        press(dlg.content, "Chạy")
        self.assertTrue(wait(lambda: any("Walk-forward thất bại" in t for t in toasts), 30), toasts)
        self.assertTrue(any("Không đủ dữ liệu" in t for t in toasts))

    def test_accounts_dialog_add_toggle_remove(self):
        app = make_app()
        app.accounts_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        self.assertEqual(dlg.title, "Tài khoản (chạy song song)")
        self.assertIn("Chưa có tài khoản phụ", texts(dlg.content))
        press(dlg.content, "Thêm từ cài đặt hiện tại")
        add = kivy_stub.OPEN_POPUPS[-1]
        self.assertEqual(add.title, "Thêm tài khoản")
        press(add.content, "Lưu")                                           # tên rỗng
        self.assertIn("không được để trống", texts(add.content))
        inputs_of(add.content)[0].text = "Exness VN"
        press(add.content, "Lưu")
        book = app.account_book()
        self.assertEqual([a["id"] for a in book.list()], ["exness-vn"])
        self.assertEqual(book.get("exness-vn")["settings"]["exchange"], app.settings["exchange"])
        lst = kivy_stub.OPEN_POPUPS[-1]
        self.assertEqual(lst.title, "Tài khoản (chạy song song)")
        self.assertIn("Exness VN", texts(lst.content))
        self.assertIn("chạy song song: BẬT", texts(lst.content))
        press(lst.content, "Tắt")
        self.assertFalse(book.get("exness-vn")["enabled"])
        lst = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("chạy song song: tắt", texts(lst.content))
        press(lst.content, "Xoá")
        press(kivy_stub.OPEN_POPUPS[-1].content, "Xoá")                      # xác nhận
        self.assertEqual(book.list(), [])

    def test_view_requires_a_running_session_and_a_running_account(self):
        app = make_app()
        toasts = []
        app.toast = lambda m, *a, **k: toasts.append(m)
        self.assertFalse(app.view_account("exness-vn"))
        self.assertIn("Chưa có phiên", toasts[-1])
        app.start_session(run_bots=True)
        try:
            self.assertFalse(app.view_account("exness-vn"))                                  # phiên chính chạy nhưng tài khoản này chưa chạy
            self.assertIn("chưa chạy", toasts[-1])
        finally:
            app.stop_session()

    def test_parallel_accounts_in_direct_mode_without_the_background_service(self):
        app = make_app()
        app.account_book().add("Exness VN", dict(app.settings, initial_balance=7777.0, exchange="simulated"))
        app.start_session(run_bots=True)
        try:
            self.assertEqual(app.ctl.kind, "local")
            self.assertEqual(list(app.extra_handles), ["exness-vn"])
            extra = app.extra_handles["exness-vn"]
            self.assertEqual(extra.kind, "local")
            self.assertIsNot(extra.session, app.ctl.session)
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready"), 20))
            self.assertAlmostEqual(app.last_snap["equity"], 100000.0, 0)                     # đang xem tài khoản chính
            self.assertTrue(wait(lambda: extra.session.account is not None and extra.session.is_alive(), 20))
            self.assertAlmostEqual(extra.session.account.equity(), 7777.0, 0)
            # xem tài khoản phụ: ctl đổi, snapshot là của phụ, thanh an toàn có nhãn
            self.assertTrue(app.view_account("exness-vn"))
            self.assertIs(app.ctl, extra)
            self.assertTrue(self.drive(app, lambda: abs((app.last_snap or {}).get("equity", 0) - 7777.0) < 1, 25))
            self.assertTrue(self.drive(app, lambda: "[TÀI KHOẢN: Exness VN]" in texts(app.trade_tab), 15))
            # lệnh tay rơi vào tài khoản PHỤ
            app.open_order_dialog("EURUSD")
            dlg = kivy_stub.OPEN_POPUPS[-1]
            inputs_of(dlg.content)[0].text = "1000"
            press(dlg.content, "MUA")
            press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")
            self.assertTrue(wait(lambda: len(extra.session.account.positions) == 1, 20))
            self.assertEqual(len(app.main_ctl.session.account.positions), 0)
            # dữ liệu của tài khoản phụ nằm trong thư mục RIÊNG của nó
            acc_dir = app.account_book().data_dir_for("exness-vn")
            self.assertEqual(os.path.dirname(extra.session.state_file), acc_dir)
            self.assertTrue(wait(lambda: os.path.exists(os.path.join(acc_dir, "session_state.json")), 10))
            self.assertNotEqual(os.path.dirname(app.main_ctl.session.state_file), acc_dir)
            # gắn bot cho tài khoản phụ
            app.open_attach_dialog()
            dlg = kivy_stub.OPEN_POPUPS[-1]
            sp = find(dlg.content, lambda x: hasattr(x, "values") and "Exness VN" in list(x.values))[0]
            self.assertEqual(sp.text, "Exness VN")
            press(dlg.content, "Gắn bot")
            cfg = app.attach_cfgs[-1]
            self.assertEqual(cfg["account"], "exness-vn")
            self.assertTrue(wait(lambda: cfg["iid"] in extra.session.instances, 15))
            self.assertNotIn(cfg["iid"], app.main_ctl.session.instances)
            # quay về chính; dừng phiên dừng CẢ HAI
            self.assertTrue(app.view_account("main"))
            self.assertIs(app.ctl, app.main_ctl)
            app.stop_session()
            self.assertTrue(wait(lambda: not extra.session.is_alive() and not app.main_ctl.session.is_alive(), 20))
        finally:
            app.stop_session()

    def test_direct_mode_accounts_resume_their_own_books_and_fresh_start_wipes_them(self):
        app = make_app()
        app.account_book().add("Exness VN", dict(app.settings, initial_balance=7777.0, exchange="simulated", close_on_stop=False))
        app.start_session(run_bots=True)
        extra = app.extra_handles["exness-vn"]
        self.assertTrue(wait(lambda: extra.session.account is not None and extra.session.tick_count > 2, 20))
        r = extra.session.send_order("EURUSD", "buy", 1000.0)
        self.assertTrue(r.ok, r.message)
        app.stop_session()
        self.assertTrue(wait(lambda: not extra.session.is_alive(), 20))
        app._do_start(resume=True)                                                           # «Tiếp tục phiên»: sổ lệnh của TỪNG tài khoản được khôi phục
        try:
            e2 = app.extra_handles["exness-vn"]
            self.assertIsNot(e2, extra)
            self.assertTrue(wait(lambda: e2.session.account is not None and len(e2.session.account.positions) == 1, 20))
        finally:
            app.stop_session()
        self.assertTrue(wait(lambda: not e2.session.is_alive(), 20))
        app._do_start(resume=False)                                                          # phiên mới: xoá sổ cũ
        try:
            e3 = app.extra_handles["exness-vn"]
            self.assertTrue(wait(lambda: e3.session.account is not None, 20))
            self.assertEqual(len(e3.session.account.positions), 0)
        finally:
            app.stop_session()

    def test_direct_mode_bots_configured_for_a_secondary_account_start_with_it(self):
        app = make_app()
        app.account_book().add("Exness VN", dict(app.settings, exchange="simulated"))
        base = dict(app.attach_cfgs[0])
        app.attach_cfgs.append(dict(base, account="exness-vn", iid=base["iid"] + "@exness-vn", auto=True))
        app.start_session(run_bots=True)
        try:
            extra = app.extra_handles["exness-vn"]
            iid = base["iid"] + "@exness-vn"
            self.assertTrue(wait(lambda: iid in extra.session.instances, 20))
            self.assertNotIn(iid, app.main_ctl.session.instances)
        finally:
            app.stop_session()

    def test_fresh_direct_start_clears_the_old_book_and_events_of_the_account_at_once(self):
        from pyea.engine import TradingSession
        app = make_app()
        acc = app.account_book().add("Exness VN", dict(app.settings, exchange="simulated"))
        acc = app.account_book().get("exness-vn") if not isinstance(acc, dict) or "id" not in acc else acc
        d = app.account_book().data_dir_for("exness-vn")
        os.makedirs(d, exist_ok=True)
        for name in ("session_state.json", "events.jsonl"):
            open(os.path.join(d, name), "w").write("{\"x\": 1}\n")
        orig = TradingSession.start
        TradingSession.start = lambda self: None                         # chỉ kiểm lúc KHỞI TẠO: chưa luồng nào kịp ghi lại
        try:
            app._start_local_account(dict(acc, id="exness-vn", name="Exness VN"), app._account_cfg(dict(acc, id="exness-vn", name="Exness VN"), False))
            self.assertFalse(os.path.exists(os.path.join(d, "session_state.json")))
            self.assertEqual(os.path.getsize(os.path.join(d, "events.jsonl")), 0)
            open(os.path.join(d, "session_state.json"), "w").write("{}")
            app._start_local_account(dict(acc, id="exness-vn", name="Exness VN"), app._account_cfg(dict(acc, id="exness-vn", name="Exness VN"), True))
            self.assertTrue(os.path.exists(os.path.join(d, "session_state.json")))      # resume: giữ nguyên
        finally:
            TradingSession.start = orig

    def test_direct_mode_secondary_live_account_still_needs_its_own_confirmation(self):
        app = make_app()
        book = app.account_book()
        book.add("Thật có xác nhận", dict(app.settings, exchange="simulated", mode="live", live_confirm=True, testnet=False))
        book.add("Thật thiếu xác nhận", dict(app.settings, exchange="simulated", mode="live", live_confirm=False, testnet=False))
        toasts = []
        app.toast = lambda m, *a, **k: toasts.append(m)
        app.start_session(run_bots=True)
        try:
            self.assertTrue(any("chưa tick xác nhận" in t for t in toasts), toasts)
            self.assertEqual(app.extra_handles, {})                                          # chưa chạy gì: đang chờ xác nhận
            pop = [p for p in kivy_stub.OPEN_POPUPS if "TIỀN THẬT (tài khoản phụ)" in p.title][-1]
            self.assertNotIn("Thật thiếu xác nhận", texts(pop.content))
            press(pop.content, "Chạy song song")
            self.assertEqual([k.startswith("that-co") for k in app.extra_handles], [True])
        finally:
            app.stop_session()

    def test_one_broken_secondary_account_does_not_stop_the_others(self):
        app = make_app()
        book = app.account_book()
        book.add("Hỏng", dict(app.settings, exchange="simulated"))
        book.add("Tốt", dict(app.settings, exchange="simulated"))
        toasts = []
        app.toast = lambda m, *a, **k: toasts.append(m)
        real = app._start_local_account

        def flaky(acc, cfg):
            if acc["name"] == "Hỏng":
                raise RuntimeError("boom")
            return real(acc, cfg)
        app._start_local_account = flaky
        app.start_session(run_bots=True)
        try:
            self.assertEqual(list(app.extra_handles), ["tot"])
            self.assertTrue(any("Không khởi động được tài khoản 'Hỏng'" in t for t in toasts), toasts)
        finally:
            app.stop_session()

    def test_parallel_accounts_via_ui_service_mode(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        app.account_book().add("Exness VN", dict(app.settings, initial_balance=7777.0, exchange="simulated"))
        host_box = {}
        orig = (native.IS_ANDROID, native.start_service)

        def fake_start_service(arg, title="", text=""):
            host = ServiceHost(app.data_dir, sleep=0.05, exit_grace=0.5, idle_exit=5)
            host_box["host"] = host
            threading.Thread(target=host.run, daemon=True).start()
            return True, ""
        native.IS_ANDROID, native.start_service = True, fake_start_service
        try:
            app.start_session(run_bots=True)
            self.assertIn("exness-vn", app.extra_handles)
            host = host_box["host"]
            self.assertTrue(wait(lambda: "exness-vn" in host.rt and host.rt["exness-vn"].session is not None and host.rt["exness-vn"].session.is_alive(), 20))
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready"), 20))
            self.assertAlmostEqual(app.last_snap["equity"], 100000.0, 0)             # đang xem tài khoản chính
            # chuyển xem sang tài khoản phụ: ctl đổi, snapshot là của tài khoản phụ, thanh an toàn có nhãn
            self.assertTrue(app.view_account("exness-vn"))
            self.assertIs(app.ctl, app.extra_handles["exness-vn"])
            self.assertTrue(self.drive(app, lambda: abs((app.last_snap or {}).get("equity", 0) - 7777.0) < 1, 25))
            self.assertTrue(self.drive(app, lambda: "[TÀI KHOẢN: Exness VN]" in texts(app.trade_tab), 15))
            # đặt lệnh tay => rơi vào tài khoản PHỤ, không phải chính
            app.open_order_dialog("EURUSD")
            dlg = kivy_stub.OPEN_POPUPS[-1]
            inputs_of(dlg.content)[0].text = "1000"
            press(dlg.content, "MUA")
            press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")
            self.assertTrue(wait(lambda: len(host.rt["exness-vn"].session.account.positions) == 1, 20))
            self.assertEqual(len(host.rt["main"].session.account.positions), 0)
            # gắn bot cho tài khoản phụ từ hộp thoại
            app.open_attach_dialog()
            dlg = kivy_stub.OPEN_POPUPS[-1]
            sp = find(dlg.content, lambda x: hasattr(x, "values") and "Exness VN" in list(x.values))[0]
            self.assertEqual(sp.text, "Exness VN")                                 # mặc định chọn tài khoản đang xem
            n0 = len(app.attach_cfgs)
            press(dlg.content, "Gắn bot")
            cfg = app.attach_cfgs[-1]
            self.assertEqual(len(app.attach_cfgs), n0 + 1)
            self.assertEqual(cfg["account"], "exness-vn")
            self.assertTrue(cfg["iid"].endswith("@exness-vn"))
            self.assertTrue(wait(lambda: cfg["iid"] in host.rt["exness-vn"].session.instances, 15))
            self.assertNotIn(cfg["iid"], host.rt["main"].session.instances)
            # quay về tài khoản chính
            self.assertTrue(app.view_account("main"))
            self.assertIs(app.ctl, app.main_ctl)
            self.assertTrue(self.drive(app, lambda: abs((app.last_snap or {}).get("equity", 0) - 100000.0) < 1, 25))
            # mở lại app: gắn lại handle của phiên phụ bằng token lấy từ tóm tắt; dừng RIÊNG phiên phụ
            h2 = ServiceHandle.attach_running(app.client, app.store.events_path)
            app.extra_handles = {}
            app.reattach_extra_accounts(h2)
            self.assertIn("exness-vn", app.extra_handles)
            self.assertEqual(app.extra_handles["exness-vn"].token, host.rt["exness-vn"].token)
            app.extra_handles["exness-vn"].stop()
            self.assertTrue(wait(lambda: not host.rt["exness-vn"].session.is_alive(), 15))
            self.assertTrue(host.rt["main"].session.is_alive())
            app.stop_session()
            self.assertTrue(self.drive(app, lambda: not app.is_connected(), 25))
            host._exit = True
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_secondary_live_account_needs_its_own_confirmation(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        book = app.account_book()
        book.add("Thật có xác nhận", dict(app.settings, exchange="simulated", mode="live", live_confirm=True, testnet=False))
        book.add("Thật thiếu xác nhận", dict(app.settings, exchange="simulated", mode="live", live_confirm=False, testnet=False))
        toasts = []
        host_box = {}
        orig = (native.IS_ANDROID, native.start_service)

        def fake_start_service(arg, title="", text=""):
            host = ServiceHost(app.data_dir, sleep=0.05, exit_grace=0.5, idle_exit=5)
            host_box["host"] = host
            threading.Thread(target=host.run, daemon=True).start()
            return True, ""
        native.IS_ANDROID, native.start_service = True, fake_start_service
        try:
            app.toast = lambda m, *a, **k: toasts.append(m)
            app.start_session(run_bots=True)
            self.assertTrue(any("chưa tick xác nhận" in t for t in toasts), toasts)             # thiếu live_confirm: bị bỏ qua
            self.assertEqual(app.extra_handles, {})                                              # CHƯA chạy gì: đang chờ xác nhận
            pop = [p for p in kivy_stub.OPEN_POPUPS if "TIỀN THẬT (tài khoản phụ)" in p.title][-1]
            self.assertIn("Thật có xác nhận", texts(pop.content))
            self.assertNotIn("Thật thiếu xác nhận", texts(pop.content))
            press(pop.content, "Chạy song song")
            self.assertEqual(len(app.extra_handles), 1)
            self.assertEqual(next(iter(app.extra_handles)).startswith("that-co"), True)
            app.stop_session()
            host_box["host"]._exit = True
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_service_mode_end_to_end(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        host_box = {}
        orig = (native.IS_ANDROID, native.start_service)

        def fake_start_service(arg, title="", text=""):
            host = ServiceHost(app.data_dir, sleep=0.05, exit_grace=0.5, idle_exit=5)
            host_box["host"] = host
            threading.Thread(target=host.run, daemon=True).start()
            return True, ""
        native.IS_ANDROID, native.start_service = True, fake_start_service
        try:
            app.start_session(run_bots=True)
            self.assertIsInstance(app.ctl, ServiceHandle)
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and "BTCUSD" in app.last_snap["watch"], 20))
            # lệnh thủ công qua IPC
            app.open_order_dialog("EURUSD")
            dlg = kivy_stub.OPEN_POPUPS[-1]
            inputs_of(dlg.content)[0].text = "1000"
            press(dlg.content, "MUA")
            press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")
            self.assertTrue(any("dịch vụ nền" in texts(p.content) for p in kivy_stub.OPEN_POPUPS))
            self.assertTrue(self.drive(app, lambda: any(p.symbol == "EURUSD" for p in app.last_snap["positions"]), 20))
            # biểu đồ + chấm từ dịch vụ
            app.set_chart("EURUSD", "5m")
            self.assertTrue(self.drive(app, lambda: app.chart_tab.panel.chart.candles and any(e.symbol == "EURUSD" for e in app.chart_tab.panel.chart.events), 20))
            ch = app.chart_tab.panel.chart; ch.redraw()
            x, y, ev = next(h for h in ch._hits if h[2].symbol == "EURUSD")
            n0 = len(kivy_stub.OPEN_POPUPS); ch._tap(x, y)
            self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
            # đóng UI không dừng phiên -> gắn lại
            app.on_stop()
            self.assertTrue(app.is_connected())
            self.assertIsNotNone(ServiceHandle.attach_running(app.client, app.store.events_path))
            app.stop_session()
            self.assertTrue(self.drive(app, lambda: not app.is_connected(), 25))
            host_box["host"]._exit = True
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_service_start_failure_falls_back_to_local(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        orig = (native.IS_ANDROID, native.start_service)
        native.IS_ANDROID, native.start_service = True, (lambda *a, **k: (False, "boom"))
        try:
            app.start_session(run_bots=True)
            self.assertNotIsInstance(app.ctl, ServiceHandle)
            self.assertTrue(any("chạy trực tiếp" in l for l in app.log_tab.lines))
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready")))
            app.stop_session()
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_watchlist_add_remove_and_ai_diag_crash(self):
        app = make_app()
        app.add_symbol_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        inputs_of(dlg.content)[0].text = "usoil, gbpusd"
        press(dlg.content, "Thêm")
        self.assertIn("USOIL", app.settings["watchlist"])
        app.refresh(0)
        self.assertIn("USOIL", app.market_tab.rows)
        app.symbol_menu("USOIL")
        press(kivy_stub.OPEN_POPUPS[-1].content, "Xoá khỏi danh sách theo dõi")
        self.assertNotIn("USOIL", app.settings["watchlist"])
        # AI tab
        app.hub.add_message("user", "xin chào")
        n = len(app.ai_tab.chat_box.children); app.ai_tab.update()
        self.assertEqual(len(app.ai_tab.chat_box.children), n + 1)
        app.toggle_ai_auto(); self.assertTrue(app.hub.auto_on); app.toggle_ai_auto(); self.assertFalse(app.hub.auto_on)
        # chẩn đoán
        app.run_diagnostics()
        self.assertTrue(wait(lambda: any(p.title == "Kiểm tra hệ thống" for p in kivy_stub.OPEN_POPUPS), 20))
        # crash log
        app.note_ui_error("Traceback...\nValueError: x")
        app._after_start(0)
        self.assertTrue(any("bị lỗi" in p.title for p in kivy_stub.OPEN_POPUPS))


if __name__ == "__main__":
    unittest.main()
