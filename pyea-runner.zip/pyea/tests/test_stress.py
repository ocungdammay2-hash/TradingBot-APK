"""Thử tải nhỏ (bản rút gọn của pyea/stress.py): nhiều bot × nhiều mã không lỗi, sổ sách nhất quán; backtest nối tiếp không hỏng."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import stress                                         # noqa: E402


class TestStress(unittest.TestCase):
    def test_multi_bot_multi_symbol_ledger_consistent(self):
        r = stress.live(n_bots=4, n_syms=4, ticks=3000, samples=4)
        self.assertEqual(r["bots_not_running"], [])
        self.assertEqual(r["errors"], 0)
        self.assertEqual(r["instances"], 16)
        self.assertGreater(r["trades_closed"], 0)
        d = r["balance_check"]["diff_when_flat"]
        if d is not None:                                        # chỉ kiểm khi hết vị thế: số dư = vốn + tổng lãi lệnh đã đóng
            self.assertAlmostEqual(d, 0.0, places=4)

    def test_sequential_backtests_all_succeed(self):
        r = stress.backtests(n=8, bars=500, samples=4)
        self.assertEqual(r["failed"], 0)
        self.assertGreater(r["trades"], 0)


if __name__ == "__main__":
    unittest.main()
