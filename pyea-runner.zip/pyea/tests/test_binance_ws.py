"""Binance WebSocket đẩy giá (máy chủ giả) + order_book/recent_trades."""
import json, os, sys, threading, time, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea.feeds import BinanceFeed
from pyea.wsclient import accept_key, encode_frame


class Srv:
    def __init__(self):
        outer = self
        self.paths, self.rest_hits, self.px = [], 0, (100.0, 100.5)

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *a): pass
            def do_GET(self):
                if self.headers.get("Sec-WebSocket-Key"):
                    outer.paths.append(self.path)
                    self.send_response(101); self.send_header("Upgrade", "websocket"); self.send_header("Connection", "Upgrade")
                    self.send_header("Sec-WebSocket-Accept", accept_key(self.headers["Sec-WebSocket-Key"])); self.end_headers(); self.wfile.flush()
                    try:
                        while not outer.stop:
                            b, a = outer.px
                            self.connection.sendall(encode_frame(1, json.dumps({"s": "BTCUSDT", "b": str(b), "B": "1", "a": str(a), "A": "1"}).encode(), mask=False))
                            time.sleep(0.05)
                    except OSError:
                        pass
                    return
                outer.rest_hits += 1
                body = json.dumps({"serverTime": int(time.time() * 1000), "bidPrice": "1", "askPrice": "2"} if "bookTicker" in self.path or "time" in self.path else {}).encode()
                self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        self.stop = False
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.stop = True
        self.srv.shutdown()


class TestBinanceWs(unittest.TestCase):
    def test_push_price_used_after_first_message(self):
        s = Srv()
        f = BinanceFeed("http://127.0.0.1:%d" % s.port, ws=True, ws_base="ws://127.0.0.1:%d" % s.port)
        try:
            f.tick("BTCUSDT")                                   # lần đầu: REST (chưa có dữ liệu đẩy), đồng thời mở luồng
            end = time.time() + 5
            while time.time() < end and not f._ws["BTCUSDT"].fresh():
                time.sleep(0.05)
            hits = s.rest_hits
            t = f.tick("BTCUSDT")
            self.assertEqual((t.bid, t.ask), (100.0, 100.5))
            self.assertEqual(s.rest_hits, hits)                 # không gọi REST nữa
            self.assertIn("/ws/btcusdt@bookTicker", s.paths)
        finally:
            f.close(); s.close()

    def test_fallback_to_rest_when_stale(self):
        s = Srv()
        f = BinanceFeed("http://127.0.0.1:%d" % s.port, ws=True, ws_base="ws://127.0.0.1:1")     # cổng chết: không bao giờ có luồng
        try:
            t = f.tick("BTCUSDT")
            self.assertEqual((t.bid, t.ask), (1.0, 2.0))        # giá REST
        finally:
            f.close(); s.close()

    def test_ws_off_by_default(self):
        self.assertFalse(BinanceFeed().ws_on)


class TestMarketCall(unittest.TestCase):
    def test_none_when_unsupported(self):
        from pyea.engine import TradingSession
        from pyea.settings import default_settings
        sess = TradingSession(default_settings(), log_file=None)
        self.assertIsNone(sess.market_call("depth", "BTCUSDT", 10))      # nguồn giả lập: không có sổ lệnh
        self.assertIsNone(sess.market_call("agg_trades", "BTCUSDT"))


if __name__ == "__main__":
    unittest.main()


class TestBotOrderBook(unittest.TestCase):
    def test_bot_reads_depth_and_trades(self):
        import tempfile
        from pyea.engine import TradingSession
        from pyea.settings import default_settings

        class F:
            def depth(self, sym, limit):
                return {"bids": [[99.0, 2.0]], "asks": [[101.0, 3.0]], "limit": limit, "sym": sym}

            def agg_trades(self, sym, a, b, c, limit):
                return [{"id": i, "t": 1.0 * i, "p": 100.0, "q": 1.0, "buyer_maker": False} for i in range(5)]

            def close(self):
                pass
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "b.py")
            open(p, "w", encoding="utf-8").write("from pyea import BaseBot\nclass B(BaseBot):\n    pass\n")
            sess = TradingSession(default_settings(), log_file=None)
            sess.feed = F()
            r = sess.attach(p, "BTCUSDT", "1m")
            from pyea.engine import BotContext
            api = BotContext(r)
            bk = api.order_book(10, symbol="ethusdt")
            self.assertEqual((bk["sym"], bk["limit"]), ("ETHUSDT", 10))
            tr = api.recent_trades(3)
            self.assertEqual([x["id"] for x in tr], [2, 3, 4])
