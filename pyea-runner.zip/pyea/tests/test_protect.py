"""SL/TP NATIVE (protect.py + BinanceFuturesBroker.sync_protection) với sàn Binance Futures giả (Algo Order, reduceOnly, -2021/-2022)."""
import os
import sys
import tempfile
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX                      # noqa: E402
from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.broker import BinanceFuturesBroker                 # noqa: E402
from pyea.engine import Account, TradingSession              # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402

SYM = "BTCUSDT"


def make(fx, state_dir=None, **over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0, native_sltp=True, native_sync_s=1.0, reconcile_interval=0)
    st.update(over)
    sf = os.path.join(state_dir, "state.json") if state_dir else None
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=sf)
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = [SYM]
    s.broker = BinanceFuturesBroker("key123", "sekret", fx.base)
    s.broker.prepare(SYM)
    s.sync = False                                           # phiên «live» (không có luồng nền: test tự gọi _check_protection)
    return s


def tk(s, price, t=1000.0):
    s.process_tick(Tick(SYM, t, price, price))


def poll(s):
    s._prot_next = 0.0
    s._check_protection()


def algos(fx, status="NEW"):
    return [a for a in fx.fut["algo"].values() if a["algoStatus"] == status]


def posts(fx, part):
    return [c for c in fx.calls if c[0] == "POST" and part in c[1]]


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.tmp = tempfile.mkdtemp()
        self.s = make(self.fx, self.tmp)
        tk(self.s, 100.0)

    def open(self, vol, sl=0.0, tp=0.0):
        r = self.s.send_order(SYM, "buy", vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position


class TestLadder(Base):
    def test_levels_become_reduce_only_orders_and_are_covered(self):
        p = self.open(0.05, 95.0, 110.0)
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                    # vừa mở: chưa có bảo vệ -> vỏ tự canh
        poll(self.s)
        live = {(a["orderType"], a["side"], a["triggerPrice"], a["quantity"], a["reduceOnly"]) for a in algos(self.fx)}
        self.assertEqual(live, {("STOP_MARKET", "SELL", "95.00", "0.050", "true"), ("TAKE_PROFIT_MARKET", "SELL", "110.00", "0.050", "true")})
        self.assertTrue(all(a["clientAlgoId"].startswith("pyeaP") for a in algos(self.fx)))
        self.assertTrue(self.s.prot_covered(p.id, "sl") and self.s.prot_covered(p.id, "tp"))
        n = len(posts(self.fx, "/algoOrder"))
        poll(self.s)
        poll(self.s)
        self.assertEqual(len(posts(self.fx, "/algoOrder")), n)                # đồng bộ lại = idempotent, không đặt trùng

    def test_positions_with_same_level_are_aggregated(self):
        a, b = self.open(0.03, 95.0), self.open(0.02, 95.0, 120.0)
        poll(self.s)
        sl = [x for x in algos(self.fx) if x["orderType"] == "STOP_MARKET"]
        self.assertEqual([(x["triggerPrice"], x["quantity"]) for x in sl], [("95.00", "0.050")])
        self.assertTrue(all(self.s.prot_covered(p.id, "sl") for p in (a, b)))
        self.assertFalse(self.s.prot_covered(a.id, "tp"))                     # a không có TP

    def test_short_positions_use_buy_orders_on_the_other_side(self):
        self.fx.price = 100.0
        r = self.s.send_order(SYM, "sell", 0.04, 105.0, 90.0)
        self.assertTrue(r, r.message)
        poll(self.s)
        self.assertEqual({(a["orderType"], a["side"], a["triggerPrice"]) for a in algos(self.fx)},
                         {("STOP_MARKET", "BUY", "105.00"), ("TAKE_PROFIT_MARKET", "BUY", "90.00")})

    def test_foreign_conditional_orders_are_never_touched(self):
        mine = self.s.broker.place_pending(SYM, "sell", "stop", 0.01, 80.0)      # lệnh stop thường của app (clientAlgoId 'pyea...')
        self.fx.fut["algo"]["777"] = {"algoId": 777, "clientAlgoId": "my-own-order", "algoType": "CONDITIONAL", "orderType": "STOP_MARKET",
                                      "symbol": SYM, "side": "SELL", "quantity": "0.100", "algoStatus": "NEW", "triggerPrice": "70.00",
                                      "reduceOnly": "true", "actualOrderId": "", "actualPrice": "0"}
        p = self.open(0.05, 95.0)
        poll(self.s)
        poll(self.s)
        self.assertEqual(self.fx.fut["algo"]["777"]["algoStatus"], "NEW")
        self.assertEqual(self.fx.fut["algo"][mine[5:]]["algoStatus"], "NEW")
        self.assertEqual(len(algos(self.fx)), 3)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))


class TestOwnership(Base):
    def test_covered_level_is_not_closed_by_the_shell(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        n_orders = len(posts(self.fx, "/fapi/v1/order"))
        tk(self.s, 94.0, 1001.0)                                              # giá xuyên SL nhưng sàn canh -> vỏ không đóng
        self.assertIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx, "/fapi/v1/order")), n_orders)

    def test_uncovered_level_is_still_watched_by_the_shell(self):
        p = self.open(0.05, 95.0)
        self.fx.price = 94.0                                                  # SL đã nằm sai phía giá -> sàn từ chối (-2021)
        poll(self.s)
        self.assertEqual(algos(self.fx), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        self.assertTrue(any("vẫn tự canh" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        tk(self.s, 94.0, 1001.0)
        self.assertNotIn(p.id, self.s.account.positions)                      # vỏ tự canh và đóng (an toàn hơn là không ai canh)

    def test_bot_close_cancels_protection_before_market_close(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        self.fx.calls.clear()
        self.assertTrue(self.s.close_position(p.id, "bot", "đóng tay"))
        seq = [(c[0], c[1], c[2].get("type")) for c in self.fx.calls if c[0] in ("DELETE", "POST") and ("order" in c[1].lower())]
        deletes = [i for i, c in enumerate(seq) if c[0] == "DELETE"]
        market = [i for i, c in enumerate(seq) if c[0] == "POST" and c[2] == "MARKET"]
        self.assertEqual(len(deletes), 2)
        self.assertTrue(market and max(deletes) < min(market), seq)           # huỷ HAI lệnh bảo vệ trước khi gửi lệnh thị trường
        self.assertEqual(algos(self.fx), [])
        self.assertEqual(self.fx.fut["pos"], 0.0)

    def test_closing_one_position_keeps_the_others_protected(self):
        a, b = self.open(0.03, 95.0), self.open(0.02, 95.0)
        poll(self.s)
        self.s.close_position(a.id, "bot", "x")
        poll(self.s)
        sl = [x for x in algos(self.fx) if x["orderType"] == "STOP_MARKET"]
        self.assertEqual([(x["triggerPrice"], x["quantity"]) for x in sl], [("95.00", "0.020")])
        self.assertTrue(self.s.prot_covered(b.id, "sl"))

    def test_modify_sl_replaces_the_order_and_covers_again(self):
        p = self.open(0.05, 95.0)
        poll(self.s)
        self.assertTrue(self.s.modify_position(p.id, sl=96.0))
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                     # đang đổi: vỏ canh tạm thời
        self.assertEqual(algos(self.fx), [])
        poll(self.s)
        self.assertEqual([(a["triggerPrice"], a["quantity"]) for a in algos(self.fx)], [("96.00", "0.050")])
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        n = len(posts(self.fx, "/algoOrder"))
        self.s.modify_position(p.id, sl=96.0)                                 # không đổi mức -> không đụng tới sàn
        poll(self.s)
        self.assertEqual(len(posts(self.fx, "/algoOrder")), n)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))


class TestFills(Base):
    def test_sl_fill_is_booked_without_sending_any_order(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        sl_id = [k for k, a in self.fx.fut["algo"].items() if a["orderType"] == "STOP_MARKET"][0]
        n_orders = len(posts(self.fx, "/fapi/v1/order"))
        self.fx.fill_algo(sl_id, 95.0)                                        # sàn khớp lệnh bảo vệ (vị thế sàn về 0)
        poll(self.s)
        self.assertNotIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx, "/fapi/v1/order")), n_orders)     # vỏ KHÔNG gửi thêm lệnh đóng
        tr = self.s.account.trades[-1]
        self.assertAlmostEqual(tr.profit, (95.0 - 100.0) * 0.05, 6)
        self.assertEqual(tr.close_price, 95.0)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, "sl")
        self.assertIn("NATIVE", ev.reason)
        self.assertEqual(self.fx.fut["pos"], 0.0)
        self.assertEqual(algos(self.fx), [])                                  # lệnh TP còn lại bị huỷ ngay (không để đóng nhầm vị thế mới)
        self.assertEqual(self.s.reconcile_now(), [])                          # sổ app khớp sàn

    def test_tp_fill_and_second_position_keeps_its_own_level(self):
        a, b = self.open(0.03, 90.0, 110.0), self.open(0.02, 90.0, 120.0)
        poll(self.s)
        tp110 = [k for k, x in self.fx.fut["algo"].items() if x["orderType"] == "TAKE_PROFIT_MARKET" and x["triggerPrice"] == "110.00"][0]
        self.fx.fill_algo(tp110, 110.0)
        poll(self.s)
        self.assertNotIn(a.id, self.s.account.positions)
        self.assertIn(b.id, self.s.account.positions)
        self.assertAlmostEqual(self.s.account.trades[-1].profit, 10.0 * 0.03, 6)
        left = {(x["orderType"], x["triggerPrice"], x["quantity"]) for x in algos(self.fx)}
        self.assertEqual(left, {("STOP_MARKET", "90.00", "0.020"), ("TAKE_PROFIT_MARKET", "120.00", "0.020")})
        self.assertTrue(self.s.prot_covered(b.id, "sl") and self.s.prot_covered(b.id, "tp"))
        self.assertEqual(self.s.reconcile_now(), [])

    def test_fill_while_app_was_off_is_booked_after_restart(self):
        p = self.open(0.05, 95.0)
        poll(self.s)
        state = self.s.account.to_dict()
        sl_id = list(self.fx.fut["algo"])[0]
        self.fx.fill_algo(sl_id, 94.5)                                        # app tắt, sàn khớp lệnh bảo vệ ở 94.5
        s2 = make(self.fx, self.tmp)                                          # app mở lại: cùng thư mục state -> đọc protect.json
        s2.account.restore(state)
        tk(s2, 94.5, 2000.0)
        self.assertIn(p.id, s2.account.positions)
        poll(s2)
        self.assertNotIn(p.id, s2.account.positions)
        self.assertEqual(s2.account.trades[-1].close_price, 94.5)
        self.assertEqual(s2.reconcile_now(), [])

    def test_hold_blocks_shell_exits_right_after_restart_then_expires(self):
        p = self.open(0.05, 95.0)
        poll(self.s)
        state = self.s.account.to_dict()
        s2 = make(self.fx, self.tmp)                                          # còn lệnh bảo vệ chưa xác minh
        s2.account.restore(state)
        self.assertTrue(s2.prot_hold(SYM))
        tk(s2, 94.0, 2000.0)                                                  # giá xuyên SL nhưng đang «giữ»: vỏ không tự đóng
        self.assertIn(p.id, s2.account.positions)
        s2._prot_hold_until = 0.0                                             # quá 60 giây mà chưa xác minh được -> vỏ canh lại (an toàn)
        self.assertFalse(s2.prot_hold(SYM))
        tk(s2, 94.0, 2001.0)
        self.assertNotIn(p.id, s2.account.positions)

    def test_restart_with_live_orders_does_not_duplicate(self):
        p = self.open(0.05, 95.0, 110.0)
        poll(self.s)
        state = self.s.account.to_dict()
        s2 = make(self.fx, self.tmp)
        s2.account.restore(state)
        tk(s2, 100.0, 2000.0)
        n = len(posts(self.fx, "/algoOrder"))
        poll(s2)
        self.assertEqual(len(posts(self.fx, "/algoOrder")), n)                # nhận ra lệnh đang sống, không đặt lại
        self.assertTrue(s2.prot_covered(p.id, "sl") and s2.prot_covered(p.id, "tp"))

    def test_order_canceled_externally_is_replaced(self):
        p = self.open(0.05, 95.0)
        poll(self.s)
        aid = list(self.fx.fut["algo"])[0]
        self.fx.fut["algo"][aid]["algoStatus"] = "CANCELED"                   # ai đó huỷ tay trên web sàn
        poll(self.s)
        self.assertTrue(any("bị sàn huỷ" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        self.assertEqual(len(algos(self.fx)), 1)                              # vỏ đặt lại
        self.assertTrue(self.s.prot_covered(p.id, "sl"))


class TestSwitches(Base):
    def test_turning_the_setting_off_removes_orders_and_returns_control(self):
        p = self.open(0.05, 95.0)
        poll(self.s)
        self.assertEqual(len(algos(self.fx)), 1)
        self.s.settings["native_sltp"] = False
        poll(self.s)
        self.assertEqual(algos(self.fx), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        tk(self.s, 94.0, 1001.0)
        self.assertNotIn(p.id, self.s.account.positions)                      # vỏ canh lại như cũ

    def test_default_is_off_and_makes_no_algo_calls(self):
        s = make(self.fx, tempfile.mkdtemp(), native_sltp=False)
        tk(s, 100.0)
        s.send_order(SYM, "buy", 0.05, 95.0)
        poll(s)
        self.assertEqual(posts(self.fx, "/algoOrder"), [])
        self.assertTrue(default_settings()["native_sltp"] is False)

    def test_unsupported_broker_warns_once_and_changes_nothing(self):
        class Plain:
            supports_short, netting = True, False

            def market_order(self, sym, side, qty, reduce_only=False):
                from pyea.broker import Fill
                return Fill(100.0, qty)

        s = make(self.fx, tempfile.mkdtemp())
        s.broker = Plain()
        tk(s, 100.0)
        p = s.send_order(SYM, "buy", 0.05, 95.0).position
        poll(s)
        poll(s)
        warns = [m for _, _, lv, m in s.logs if "chưa hỗ trợ" in m]
        self.assertEqual(len(warns), 1)
        self.assertFalse(s.prot_covered(p.id, "sl"))
        tk(s, 94.0, 1001.0)
        self.assertNotIn(p.id, s.account.positions)                           # vỏ vẫn canh SL

    def test_api_errors_do_not_break_the_poll(self):
        p = self.open(0.05, 95.0)
        self.s.broker.sync_protection = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("sập mạng"))
        poll(self.s)                                                           # không ném
        self.assertTrue(any("lỗi" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        self.assertFalse(self.s.prot_covered(p.id, "sl"))


class TestBrokerSync(Base):
    def test_sync_protection_cancels_stale_and_reports_errors(self):
        b = self.s.broker
        self.fx.fut["pos"], self.fx.fut["entry"] = 0.05, 100.0
        d = [{"kind": "sl", "side": "sell", "trigger": 95.0, "qty": 0.05}, {"kind": "tp", "side": "sell", "trigger": 110.0, "qty": 0.05}]
        r = b.sync_steps(SYM, d)
        self.assertEqual((len(r["live"]), r["covered"], r["errors"]), (2, [0, 1], []))
        r2 = b.sync_steps(SYM, d[:1])                                      # bỏ TP -> huỷ lệnh TP
        self.assertEqual((len(r2["live"]), r2["covered"]), (1, [0]))
        self.assertEqual(len(algos(self.fx)), 1)
        r3 = b.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 150.0, "qty": 0.05}])   # SL trên giá: sàn từ chối
        self.assertEqual(r3["covered"], [])
        self.assertIn("-2021", r3["errors"][0])
        self.assertEqual(b.sync_steps(SYM, [])["live"], [])
        self.assertEqual(algos(self.fx), [])

    def test_volume_below_step_is_not_placed(self):
        self.fx.fut["pos"], self.fx.fut["entry"] = 0.05, 100.0
        r = self.s.broker.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 95.0, "qty": 0.0004}])
        self.assertEqual((r["live"], r["covered"]), ([], []))


if __name__ == "__main__":
    unittest.main()
