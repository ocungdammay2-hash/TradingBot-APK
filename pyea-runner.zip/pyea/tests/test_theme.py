"""Giao diện sáng/tối: đổi màu tại chỗ + độ tương phản (WCAG) cho các cặp chữ/nền thật sự dùng."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub                                                # noqa: E402
kivy_stub.install()
from pyea import ui_widgets as w                                # noqa: E402


class TestTheme(unittest.TestCase):
    def tearDown(self):
        w.apply_theme("dark")

    def test_resolve(self):
        self.assertEqual(w.resolve_theme("light"), "light")
        self.assertEqual(w.resolve_theme("dark", night=False), "dark")
        self.assertEqual(w.resolve_theme("auto", night=False), "light")
        self.assertEqual(w.resolve_theme("auto", night=True), "dark")
        self.assertEqual(w.resolve_theme("auto", night=None), "dark")
        self.assertEqual(w.resolve_theme("rác"), "dark")

    def test_in_place_so_early_imports_follow(self):
        ref = w.PANEL                                            # giữ tham chiếu như `from ui_widgets import PANEL` ở module khác
        dark = tuple(ref)
        w.apply_theme("light")
        self.assertIs(ref, w.PANEL)
        self.assertNotEqual(tuple(ref), dark)
        self.assertEqual(tuple(ref), w.THEMES["light"]["PANEL"])
        w.apply_theme("dark")
        self.assertEqual(tuple(ref), dark)
        self.assertEqual(len(w.PALETTE), 5)

    def test_col_behaves_like_tuple(self):
        c = w.Col((0.1, 0.2, 0.3, 1))
        self.assertEqual(c, (0.1, 0.2, 0.3, 1))
        self.assertEqual(c[:3] + (0.5,), (0.1, 0.2, 0.3, 0.5))
        self.assertEqual(w.hexc(c), "19334c")
        r, g, b, a = c
        self.assertEqual(a, 1)

    def test_contrast_in_both_themes(self):
        for th in ("dark", "light"):
            w.apply_theme(th)
            for bg in (w.BG, w.PANEL, w.PANEL2):
                self.assertGreaterEqual(w.contrast(w.TEXT, bg), 7, (th, "TEXT"))
                self.assertGreaterEqual(w.contrast(w.MUTED, bg), 4.5, (th, "MUTED"))
                self.assertGreaterEqual(w.contrast(w.LOG_BOT, bg), 4.5, (th, "LOG_BOT"))
                self.assertGreaterEqual(w.contrast(w.LOG_TRACE, bg), 4.5, (th, "LOG_TRACE"))
            for bg in (w.BG, w.PANEL):
                self.assertGreaterEqual(w.contrast(w.UP, bg), 4.4, (th, "UP"))
                self.assertGreaterEqual(w.contrast(w.DOWN, bg), 4.4, (th, "DOWN"))
                for c in w.PALETTE:
                    self.assertGreaterEqual(w.contrast(c, bg), 3.5, (th, c))
            for bg in (w.GREEN, w.RED, w.BLUE, w.AMBER, w.PANEL2, w.BUBBLE_USER, w.BUBBLE_DECISION):
                self.assertGreaterEqual(w.contrast(w.on_color(bg), bg), 3.0, (th, tuple(bg)))
            for bg in (w.BUBBLE_USER, w.BUBBLE_DECISION):
                self.assertGreaterEqual(w.contrast(w.TEXT, bg), 7, (th, "bubble"))

    def test_button_text_stays_white_where_it_was(self):
        w.apply_theme("dark")
        for bg in (w.GREEN, w.RED, w.BLUE):
            self.assertEqual(w.on_color(bg), (1, 1, 1, 1))
        self.assertNotEqual(w.on_color(w.AMBER), (1, 1, 1, 1))         # trắng trên hổ phách chỉ 1.6:1 -> đổi sang chữ tối

    def test_ink_flips_for_overlays(self):
        w.apply_theme("light")
        self.assertEqual(tuple(w.INK[:3]), (0, 0, 0))
        w.apply_theme("dark")
        self.assertEqual(tuple(w.INK[:3]), (1, 1, 1))

    def test_app_boots_in_light_theme(self):
        import test_ui_smoke as T
        from pyea.settings import default_settings
        self.assertEqual(default_settings()["theme"], "dark")
        w.apply_theme("light")
        app = T.make_app()
        self.assertIsNotNone(app)


if __name__ == "__main__":
    unittest.main()
