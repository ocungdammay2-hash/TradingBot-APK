"""Nhà cung cấp AI: URL gốc đã đối chiếu tài liệu chính thức (2026-10-27) không bị lệch, và model gợi ý chưa xác minh phải nói rõ."""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import ai                                                               # noqa: E402

# Nguồn: trang tài liệu của từng nhà cung cấp (xem PRESETS[...]["doc"]). Gemini ghi base_url có "/" cuối - resolve_agent bỏ nó.
DOCUMENTED = {
    "OpenRouter": "https://openrouter.ai/api/v1",
    "Groq": "https://api.groq.com/openai/v1",
    "Google Gemini": "https://generativelanguage.googleapis.com/v1beta/openai",
    "Cerebras": "https://api.cerebras.ai/v1",
    "Mistral": "https://api.mistral.ai/v1",
    "NVIDIA NIM": "https://integrate.api.nvidia.com/v1",
}


class TestPresets(unittest.TestCase):
    def test_documented_urls_are_exact(self):
        for name, url in DOCUMENTED.items():
            self.assertEqual(ai.PRESETS[name]["url"], url, name)
            self.assertTrue(ai.PRESETS[name]["checked"], name)
            self.assertTrue(ai.PRESETS[name]["doc"].startswith("https://"), name)

    def test_every_preset_has_the_audit_fields_and_unverified_ones_say_so(self):
        for name, p in ai.PRESETS.items():
            for k in ("url", "example", "note", "doc", "checked", "model_checked"):
                self.assertIn(k, p, (name, k))
            if name not in DOCUMENTED:
                self.assertEqual(p["checked"], "", name)                           # tự host / tuỳ chỉnh: không có tài liệu để đối chiếu
            if p["example"] and not p["model_checked"]:                           # model gợi ý chưa xác minh -> ghi chú phải dặn người dùng
                self.assertTrue(any(w in p["note"] for w in ("404", "chưa xác minh")), name)

    def test_request_url_has_no_double_slash_even_with_documented_trailing_slash(self):
        seen = []
        orig = ai.http_json
        ai.http_json = lambda url, **kw: (seen.append(url), {"choices": [{"message": {"content": "ok"}}]})[1]
        try:
            for name in DOCUMENTED:
                agent = dict(ai.default_agent(1), preset=name, model="m", api_key="k")
                ai.chat_completion(agent, [{"role": "user", "content": "x"}])
            gem = dict(ai.default_agent(1), preset="Google Gemini", model="m", base_url="https://generativelanguage.googleapis.com/v1beta/openai/")
            ai.chat_completion(gem, [{"role": "user", "content": "x"}])
        finally:
            ai.http_json = orig
        self.assertEqual(seen[:-1], [u + "/chat/completions" for u in DOCUMENTED.values()])
        self.assertEqual(seen[-1], DOCUMENTED["Google Gemini"] + "/chat/completions")

    def test_empty_model_falls_back_to_the_suggestion_and_providers_without_one_ask(self):
        self.assertEqual(ai.resolve_agent(dict(ai.default_agent(1), preset="Groq"))[1], ai.PRESETS["Groq"]["example"])
        with self.assertRaises(ai.AIError):
            ai.chat_completion(dict(ai.default_agent(1), preset="Cerebras"), [{"role": "user", "content": "x"}])


class TestCheatsheet(unittest.TestCase):
    def test_documents_the_new_bot_api(self):
        t = ai.SDK_CHEATSHEET
        for w in ("self.api.store", "self.api.shared", "oco(", "stats()", "on_tester", "FROZEN", "freeze_level", "@permission: network", "prompt_hash"):
            self.assertIn(w, t, w)


if __name__ == "__main__":
    unittest.main()
