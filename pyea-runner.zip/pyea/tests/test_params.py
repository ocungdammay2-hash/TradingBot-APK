"""Nhận dạng tham số từ code bot (như MT5 nhận dạng `input`), tự sinh form, đổi tham số khi bot đang chạy."""
import os, sys, tempfile, threading, time, unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea.engine import BotRunner
from pyea.ipc import ServiceClient, ServiceHandle, ServiceHost
from pyea.loader import build_params, inspect_bot
from pyea.settings import default_settings
from pyea.storage import Store

TMP = tempfile.mkdtemp()
STORE = Store(TMP)
STORE.seed_examples()


def S(**o):
    s = default_settings()
    s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=True, initial_balance=100000.0)
    s.update(o)
    return s


def wait(cond, timeout=12.0, step=0.05):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:
            pass
        time.sleep(step)
    return False


def bot(d, name, src):
    p = os.path.join(d, name)
    open(p, "w", encoding="utf-8").write(src)
    return p


class TestRecognition(unittest.TestCase):
    def test_form1_dict(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "a.py", "from pyea import BaseBot, Input\nclass A(BaseBot):\n    inputs = {'x': Input(1, 'X', min=0), 'm': Input('a', 'M', choices=['a','b'])}\n")
            i = inspect_bot(p)
            self.assertEqual(list(i.inputs), ["x", "m"]); self.assertEqual(i.inputs["m"].kind, "choice")

    def test_form2_class_attributes_and_inheritance(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "b.py", "from pyea import BaseBot, Input\n"
                    "class Base(BaseBot):\n    lot = Input(0.01, 'Khối lượng')\n"
                    "class B(Base):\n    fast = Input(10, 'Nhanh', min=2)\n    inputs = {'slow': Input(30, 'Chậm')}\n")
            i = inspect_bot(p)
            self.assertEqual(sorted(i.inputs), ["fast", "lot", "slow"])

    def test_form3_annotated_attributes(self):
        i = inspect_bot(os.path.join(STORE.bots_dir, "auto_inputs.py"))
        self.assertTrue(i.ok, i.error)
        ins = i.inputs
        self.assertEqual(list(ins), ["rsi_period", "oversold", "overbought", "direction", "lot", "use_sl", "sl_pct", "tp_pct"])
        self.assertEqual(ins["rsi_period"].kind, "int"); self.assertEqual(ins["rsi_period"].label, "Chu kỳ RSI")
        self.assertEqual(ins["oversold"].kind, "float"); self.assertEqual(ins["use_sl"].kind, "bool")
        self.assertEqual(ins["direction"].kind, "choice"); self.assertEqual(ins["direction"].choices, ["long", "short", "both"])
        self.assertEqual(ins["direction"].label, "Hướng giao dịch")
        self.assertEqual(ins["rsi_period"].group, "Tín hiệu"); self.assertEqual(ins["lot"].group, "Quản lý vốn")

    def test_form3_rules(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "c.py", "from typing import Literal\nfrom pyea import BaseBot\n"
                    "class C(BaseBot):\n"
                    "    name: str = 'không phải tham số'\n"
                    "    _private: int = 5\n"
                    "    computed: float = 2 * 3.0\n"
                    "    a: int = 3          # Tham số A\n"
                    "    side: Literal['buy', 'sell'] = 'buy'   # Hướng\n"
                    "    z = 99\n")                                           # 1.9.25: không chú thích kiểu vẫn được nhận
            ins = inspect_bot(p).inputs
            self.assertEqual(list(ins), ["a", "side", "z"])      # 'name', '_private' và biểu thức không phải literal (computed) bị bỏ
            self.assertEqual(ins["side"].choices, ["buy", "sell"])
            # có inputs = {...} thì KHÔNG tự thêm thuộc tính có kiểu
            p2 = bot(d, "d.py", "from pyea import BaseBot, Input\nclass D(BaseBot):\n    inputs = {'q': Input(1)}\n    other: int = 5\n")
            self.assertEqual(list(inspect_bot(p2).inputs), ["q"])

    def test_no_inputs_is_ok(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "e.py", "from pyea import BaseBot\nclass E(BaseBot):\n    pass\n")
            i = inspect_bot(p); self.assertTrue(i.ok); self.assertEqual(len(i.inputs), 0)

    def test_build_params_validates_like_form(self):
        ins = inspect_bot(os.path.join(STORE.bots_dir, "ma_cross.py")).inputs
        v = build_params(ins, {"fast": "12", "slow": "abc", "lot": -5, "allow_short": "false"})
        self.assertEqual(v["fast"], 12); self.assertEqual(v["slow"], ins["slow"].default)    # sai kiểu -> mặc định
        self.assertEqual(v["lot"], ins["lot"].default); self.assertFalse(v["allow_short"])  # < min -> mặc định


LIVE = ("from pyea import BaseBot\n"
        "class L(BaseBot):\n"
        "    lot: float = 0.01      # Khối lượng\n"
        "    label: str = 'A'       # Nhãn\n"
        "    def on_init(self):\n"
        "        self.log('INIT lot=%s label=%s p.lot=%s' % (self.lot, self.label, self.p.lot))\n"
        "        if self.lot > 1: return False\n"
        "    def on_deinit(self, reason):\n"
        "        self.log('DEINIT reason=%s' % reason)\n"
        "    def on_tick(self, t):\n"
        "        if not self.api.positions(): self.api.buy(self.lot, reason='lot=%s' % self.lot)\n")


class TestLiveParams(unittest.TestCase):
    def _run(self, d):
        p = bot(d, "live.py", LIVE)
        r = BotRunner(p, S(), {})
        r.start()
        self.assertTrue(wait(lambda: r.account is not None and r.account.positions, 10))
        return r

    def logs(self, r):
        return [l[3] for l in r.logs]

    def test_change_keeps_positions_and_reinitializes(self):
        with tempfile.TemporaryDirectory() as d:
            r = self._run(d)
            pid = list(r.account.positions)[0]
            r.apply_params({"lot": 0.5, "label": "B"})
            self.assertTrue(wait(lambda: r.bot_params.get("lot") == 0.5, 8))
            self.assertEqual((r.bot.lot, r.bot.p.lot, r.bot.label), (0.5, 0.5, "B"))        # thuộc tính + self.p đều cập nhật
            logs = "\n".join(self.logs(r))
            self.assertIn("DEINIT reason=params", logs)
            self.assertIn("INIT lot=0.5 label=B p.lot=0.5", logs)
            self.assertLess(logs.index("DEINIT reason=params"), logs.rindex("INIT lot=0.5"))   # deinit TRƯỚC init
            self.assertIn(pid, r.account.positions)                                         # lệnh đang mở giữ nguyên
            self.assertEqual(len(r.account.positions), 1)
            ev = [e for e in r.events if e.kind == "note" and "Đổi tham số" in e.reason]
            self.assertTrue(ev and "lot" in ev[-1].details)                                 # đánh dấu trên biểu đồ
            self.assertIn("Đã áp dụng", r.params_msg)
            # bot dùng tham số mới cho lệnh sau
            r.session.close_all("manual", "test")
            self.assertTrue(wait(lambda: any(p.volume == 0.5 for p in r.account.positions.values()), 10))
            opens = [e for e in r.events if e.kind == "open"]
            self.assertIn("lot=0.5", opens[-1].reason)
            r.stop(); r._thread.join(8)

    def test_unchanged_is_noop_and_reject_reverts(self):
        with tempfile.TemporaryDirectory() as d:
            r = self._run(d)
            n0 = sum("DEINIT" in l for l in self.logs(r))
            r.apply_params({"lot": 0.01, "label": "A"})
            time.sleep(1.0)
            self.assertEqual(sum("DEINIT" in l for l in self.logs(r)), n0)                 # không đổi -> không khởi tạo lại
            alarms = []
            r.session.alarm_cb = lambda t, x: alarms.append(t)
            r.apply_params({"lot": 5.0})                                                    # on_init trả False -> bị từ chối
            self.assertTrue(wait(lambda: "bị bot từ chối" in r.params_msg, 8))
            self.assertEqual(r.bot_params["lot"], 0.01); self.assertEqual(r.bot.lot, 0.01)  # quay lại tham số cũ
            self.assertEqual(r.status, "running")                                           # bot KHÔNG chết
            self.assertTrue(any("Tham số bị từ chối" in a for a in alarms))
            r.stop(); r._thread.join(8)

    def test_invalid_values_fall_back(self):
        with tempfile.TemporaryDirectory() as d:
            r = self._run(d)
            r.apply_params({"lot": "không phải số", "label": "Z"})
            self.assertTrue(wait(lambda: r.bot_params.get("label") == "Z", 8))
            self.assertEqual(r.bot_params["lot"], 0.01)
            r.stop(); r._thread.join(8)

    def test_params_before_start_apply_on_start(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "live.py", LIVE)
            r = BotRunner(p, S(), {"lot": 0.2}); r.apply_params({"lot": 0.3})
            r.start()
            self.assertTrue(wait(lambda: r.account is not None and r.account.positions, 10))
            self.assertEqual(list(r.account.positions.values())[0].volume, 0.3)
            r.stop(); r._thread.join(8)


class TestParamsViaService(unittest.TestCase):
    def test_params_command_updates_running_bot_and_desired(self):
        with tempfile.TemporaryDirectory() as d:
            p = bot(d, "live.py", LIVE)
            host = ServiceHost(d, sleep=0.05, exit_grace=0.3, idle_exit=5)
            th = threading.Thread(target=host.run, daemon=True); th.start()
            client = ServiceClient(d)
            stop = threading.Event()
            threading.Thread(target=lambda: [client.touch_ui() or time.sleep(0.3) for _ in iter(stop.is_set, True)], daemon=True).start()
            h = ServiceHandle(client, host.store.events_path)
            h.start({"settings": S(), "log_file": None, "trades_csv": None,
                     "instances": [{"iid": "L-1", "bot_path": p, "symbol": "BTCUSD", "tf": "1m", "params": {}, "running": True}]})
            self.assertTrue(wait(lambda: (h.snapshot() or {}).get("positions"), 15))
            h.set_params("L-1", {"lot": 0.7, "label": "S"})
            self.assertTrue(wait(lambda: "Đã áp dụng" in (h.snapshot()["instances"][0].get("params_msg") or ""), 10))
            self.assertEqual(host.session.instances["L-1"].bot.lot, 0.7)
            self.assertEqual(client.read_desired()["config"]["instances"][0]["params"]["lot"], 0.7)   # resume sau crash dùng tham số mới
            h.stop(); self.assertTrue(wait(lambda: not h.is_alive(), 15)); stop.set(); th.join(5)


class TestPresetsStore(unittest.TestCase):
    def test_presets(self):
        path = os.path.join(STORE.bots_dir, "ma_cross.py")
        STORE.save_preset(path, "Thận trọng", {"fast": 20, "slow": 60})
        STORE.save_preset(path, "Nhanh", {"fast": 5, "slow": 15})
        self.assertEqual(sorted(STORE.load_presets(path)), ["Nhanh", "Thận trọng"])
        STORE.delete_preset(path, "Nhanh")
        self.assertEqual(list(STORE.load_presets(path)), ["Thận trọng"])


class TestParamsUI(unittest.TestCase):
    def setUp(self):
        import kivy_stub
        kivy_stub.install()
        self.ks = kivy_stub

    def tearDown(self):
        self.ks.OPEN_POPUPS.clear()

    def test_form_is_generated_applied_live_and_presets(self):
        from kivy.uix.textinput import TextInput
        from kivy.uix.switch import Switch
        from kivy.uix.spinner import Spinner
        import pyea.ui as ui
        from test_ui_smoke import make_app, find, press, inputs_of, texts
        app = make_app()
        auto = os.path.join(app.store.bots_dir, "auto_inputs.py")
        iid = "auto_inputs-BTCUSD-1"
        app.attach_cfgs.append({"iid": iid, "bot_path": auto, "symbol": "BTCUSD", "tf": "1m", "params": {}, "auto": True})
        app._save_attach()
        app.start_session()
        self.assertTrue(wait(lambda: (app.refresh(0), (app.last_snap or {}).get("instances"))[1] and
                             all(i["status"] == "running" for i in app.last_snap["instances"]), 20))
        app.edit_params_dialog(iid)
        dlg = self.ks.OPEN_POPUPS[-1]
        # form tự sinh theo kiểu: số -> TextInput, bool -> Switch, [long|short|both] -> Spinner
        self.assertEqual(len(find(dlg.content, lambda x: isinstance(x, Switch))), 1)
        sp = find(dlg.content, lambda x: isinstance(x, Spinner)); self.assertEqual(len(sp), 1)
        self.assertEqual(sp[0].values, ["long", "short", "both"])
        self.assertIn("Chu kỳ RSI", texts(dlg.content)); self.assertIn("Quản lý vốn", texts(dlg.content))
        ins = inputs_of(dlg.content)                      # rsi_period, oversold, overbought, lot, sl_pct, tp_pct
        ins[0].text = "9"; ins[3].text = "0.05"
        # lưu thành bộ tham số rồi nạp lại
        press(dlg.content, "Lưu bộ")
        name_dlg = self.ks.OPEN_POPUPS[-1]; inputs_of(name_dlg.content)[0].text = "Nhanh"; press(name_dlg.content, "OK")
        self.assertIn("Nhanh", app.store.load_presets(auto))
        ins[0].text = "14"
        press(dlg.content, "Nạp bộ")
        press(self.ks.OPEN_POPUPS[-1].content, "Nhanh")
        self.assertEqual(ins[0].text, "9")
        # giá trị sai bị chặn
        ins[1].text = "abc"
        press(dlg.content, "Lưu & áp dụng")
        self.assertTrue(any("chưa hợp lệ" in p.title for p in self.ks.OPEN_POPUPS))
        ins[1].text = "25"
        press(dlg.content, "Lưu & áp dụng")
        inst = app.ctl.session.instances[iid]
        self.assertTrue(wait(lambda: inst.bot_params["rsi_period"] == 9, 10), inst.params_msg)
        self.assertEqual((inst.bot.rsi_period, inst.bot.oversold, inst.bot.lot), (9, 25.0, 0.05))
        self.assertEqual(app._cfg(iid)["params"]["rsi_period"], 9)
        self.assertEqual(app.store.load_params(auto)["oversold"], 25.0)
        app.refresh(0)
        self.assertIn("Đã áp dụng", app.attach_tab._att[iid][2].text)
        app.stop_session()


if __name__ == "__main__":
    unittest.main()
