"""Máy chủ Exness GIẢ (HTTP + WebSocket cùng một cổng) cho test. Xác minh chữ ký Ed25519 như sàn thật (dùng `cryptography`)."""
import base64
import hashlib
import json
import os
import re
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea.wsclient import accept_key, encode_frame, parse_frame  # noqa: E402

EMPTY_HASH = "47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU"


def b64u_dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


class FakeExness:
    def __init__(self, public_raw, api_key="exnsk_test", account="123456"):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        self.pub = Ed25519PublicKey.from_public_bytes(public_raw)
        self.api_key, self.account = api_key, account
        self.lock = threading.RLock()
        self.balance = 10000.0
        self.prices = {"EURUSD": [1.1000, 1.1002], "XAUUSD": [2000.0, 2000.5]}
        self.positions, self.orders, self.ops = {}, {}, {}
        self.requests = []
        self.n = 0
        self.confirm_after_polls = 0          # >0: operation còn 'pending' N lần hỏi
        self.op_shape = "flat"                # flat | nested | noprice
        self.tf_enum = "mt"                   # mt: M1/H1 ; lower: m1/h1 (để thử tự dò)
        self.candles_max = 300                # limits...max_candles_per_request
        self.history_range_days, self.history_age_days = 30, 90
        self.limits_shape = "documented"      # documented (limits.rest.methods[]) | legacy (dạng cũ để thử dò linh hoạt) | none
        self.time_fmt = "both"                # both | iso | ms : định dạng from/to mà máy chủ chấp nhận
        self.candle_only = {"GBPJPY"}         # mã có nến nhưng WebSocket không phát giá (test fallback REST)
        self.candle_gap = None                # (t0, t1): không có nến trong khoảng này (nghỉ cuối tuần)
        self.close_volume_in = "body"         # body | query : nơi máy chủ ĐỌC volume của DELETE /positions/{id}
        self.account_status, self.trade_mode = "active", "full"
        self.family_host = {"history": "ap", "configuration": "disc", "market-data": "disc"}     # họ endpoint -> host phục vụ ('any' = cả hai)
        self.ap_host = None                   # đặt sau khi biết cổng
        self.ws_conns = []
        self.ws_log = []
        self.tick_interval = 0.05
        self.reject_next = None               # None | "tên/thông điệp" | (error_code, error_message)
        self.deals = []
        self.hist_orders = []
        self.ap_shape = "bare"                # bare | nested
        self.sltp_key = "position_id"         # tên trường mã vị thế mà máy chủ ĐỌC khi tạo lệnh SLTP (tài liệu công khai không nêu -> test dò nhiều tên)
        self.sltp_needs_instrument = False    # True: thân tạo lệnh SLTP bắt buộc có instrument/side/volume
        self.sltp_model = "orders"            # orders: SL/TP của vị thế là một lệnh SLTP riêng (snapshot không ghi mức lên vị thế) | position: snapshot ghi mức lên vị thế
        self.sltp_created = []                # thân các yêu cầu tạo lệnh SLTP được CHẤP NHẬN
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.port = self.srv.server_address[1]
        self.base = "http://127.0.0.1:%d" % self.port
        self.ap_host = "localhost:%d" % self.port         # access point trả host KHÁC chuỗi với host chính -> test được định tuyến theo họ endpoint
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self._stop = threading.Event()
        threading.Thread(target=self._ticker, daemon=True).start()

    def limits_payload(self):
        if self.limits_shape == "none":
            return {"something": "else"}
        if self.limits_shape == "legacy":
            return {"limits": [{"scope": "trading.positions", "limit": 5, "window_ms": 1000},
                               {"scope": "market-data.candles", "limit": 10, "window_ms": 1000}]}
        return {"limits": {"rest": {"global_account_rate": {"limit": 50, "window_seconds": 1},
                                    "methods": [{"api_operation_id": "openPosition", "http_method": "POST",
                                                 "path": "/v1/trading/accounts/{account_id}/positions", "rate_limit": {"limit": 5, "window_seconds": 1}},
                                                {"api_operation_id": "getCandleHistory", "http_method": "GET",
                                                 "path": "/v1/market-data/accounts/{account_id}/candles", "rate_limit": {"limit": 10, "window_seconds": 1},
                                                 "limits": {"max_candles_per_request": self.candles_max}},
                                                {"api_operation_id": "getDealsHistory", "http_method": "GET",
                                                 "path": "/v1/history/accounts/{account_id}/deals", "rate_limit": {"limit": 8, "window_seconds": 1},
                                                 "limits": {"history_range_days": self.history_range_days, "history_age_days": self.history_age_days}}]},
                           "websocket": {"global_account_limits": {"max_connections": 4}, "endpoints": []}}}

    def close(self):
        self._stop.set()
        self.srv.shutdown()
        self.srv.server_close()

    # ---- mô phỏng thị trường ----
    def set_price(self, sym, bid, ask=None):
        with self.lock:
            self.prices[sym] = [bid, ask if ask is not None else bid + 0.0002]
            self._check_pending(sym)

    def _check_pending(self, sym):
        bid, ask = self.prices[sym]
        for oid, o in list(self.orders.items()):
            if o["instrument"] != sym:
                continue
            hit = False
            if o["side"] == "buy":
                hit = (o["type"] == "limit" and ask <= o["price"]) or (o["type"] == "stop" and ask >= o["price"])
            else:
                hit = (o["type"] == "limit" and bid >= o["price"]) or (o["type"] == "stop" and bid <= o["price"])
            if hit:
                del self.orders[oid]
                self._open(sym, o["side"], o["volume"], o["price"], o.get("sl"), o.get("tp"))
        self._check_sltp(sym)

    def _sltp_of(self, pid):
        return next((k for k, o in self.orders.items() if o.get("type") == "sltp" and o.get("position_id") == pid), None)

    def _levels(self, pid):
        """(sl, tp) đang có của vị thế: từ lệnh SLTP gắn với nó, hoặc từ chính vị thế (stop_loss_price/take_profit_price)."""
        k = self._sltp_of(pid)
        if k is not None:
            return self.orders[k].get("sl"), self.orders[k].get("tp")
        p = self.positions.get(pid, {})
        return p.get("stop_loss_price"), p.get("take_profit_price")

    def _check_sltp(self, sym):
        """Máy chủ canh SL/TP của từng vị thế: chạm mức -> đóng vị thế TẠI MỨC ĐÓ, ghi deal đóng (có position_id), gỡ lệnh SLTP."""
        bid, ask = self.prices[sym]
        for pid, p in list(self.positions.items()):
            if p["instrument"] != sym:
                continue
            sl, tp = self._levels(pid)
            buy = p["side"] == "buy"
            px = bid if buy else ask
            lvl = None
            if sl and ((buy and px <= sl) or (not buy and px >= sl)):
                lvl = sl
            elif tp and ((buy and px >= tp) or (not buy and px <= tp)):
                lvl = tp
            if lvl is None:
                continue
            pnl = (lvl - p["open_price"]) * (1 if buy else -1) * p["volume"] * 100000
            self.balance += pnl
            del self.positions[pid]
            k = self._sltp_of(pid)
            if k is not None:
                del self.orders[k]
            self.n += 1
            self.deals.append({"deal_id": "D%d" % self.n, "order_id": "O%d" % self.n, "type": "close", "event_time": datetime.now(timezone.utc).isoformat(),
                               "instrument": sym, "side": "sell" if buy else "buy", "volume": p["volume"], "price": lvl, "profit": pnl,
                               "commission": -0.07, "position_id": pid, "reason": "sl" if lvl == sl else "tp"})

    def _open(self, sym, side, vol, price, sl=None, tp=None):
        self.n += 1
        pid = "P%d" % self.n
        self.positions[pid] = {"position_id": pid, "instrument": sym, "side": side, "volume": vol, "open_price": price,
                               "stop_loss_price": sl, "take_profit_price": tp, "open_time": datetime.now(timezone.utc).isoformat()}
        self.last_order_id = "O%d" % self.n
        self.deals.append({"deal_id": "D%d" % self.n, "order_id": "O%d" % self.n, "position_id": pid, "type": "open", "instrument": sym, "side": side,
                           "volume": vol, "price": price, "profit": 0.0, "commission": -0.07, "event_time": datetime.now(timezone.utc).isoformat()})
        return pid

    def _ticker(self):
        while not self._stop.wait(self.tick_interval):
            with self.lock:
                conns = [c for c in self.ws_conns if c["kind"] == "ticks"]
                for c in conns:
                    for ins in c["ins"]:
                        if ins in self.prices:
                            b, a = self.prices[ins]
                            c["q"].append({"instrument": ins, "bid": "%.5f" % b, "ask": "%.5f" % a,
                                           "timestamp": datetime.now(timezone.utc).isoformat()})

    def broadcast(self, msg):
        with self.lock:
            for c in self.ws_conns:
                if c["kind"] == "events" and c["tx"]:
                    c["q"].append(msg)

    # ---- xác thực ----
    def check_auth(self, h, method, path_q, body):
        g = lambda k: h.headers.get(k)  # noqa: E731
        try:
            data = b64u_dec(g("EXN-DATA"))
            p = json.loads(data)
            assert g("EXN-API-KEY") == self.api_key == p["api_key"], "api_key"
            assert p["idempotency_key"] == (g("EXN-IDEMPOTENCY-KEY") or ""), "idem header"
            assert str(p["timestamp"]) == g("EXN-TIMESTAMP"), "timestamp"
            assert abs(time.time() * 1000 - p["timestamp"]) < 60000, "clock skew"
            assert str(p["sign_version"]) == g("EXN-SIGN-VERSION") == "1", "version"
            assert p["method"] == method, "method"
            assert p["path"] == path_q, "path %r != %r" % (p["path"], path_q)
            exp = EMPTY_HASH if not body else base64.urlsafe_b64encode(hashlib.sha256(body).digest()).decode().rstrip("=")
            assert p["body_hash"] == exp, "body_hash"
            if method == "GET":
                assert (g("EXN-IDEMPOTENCY-KEY") or "") == "", "GET idem phải rỗng"
            else:
                assert g("EXN-IDEMPOTENCY-KEY"), "mutating cần idempotency key"
            self.pub.verify(b64u_dec(g("EXN-SIGN")), data)
            return None
        except Exception as e:                                           # noqa: BLE001
            return {"error_code": 1001, "error_message": "AUTH_INVALID_SIGNATURE", "why": str(e)}

    # ---- HTTP ----
    def _handler(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def _send(self, code, obj):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _do(self, method):
                u = urlsplit(self.path)
                path_q = self.path
                n = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(n) if n else b""
                if method == "GET" and (self.headers.get("Upgrade") or "").lower() == "websocket":
                    return fake._ws(self, u, path_q)
                err = fake.check_auth(self, method, path_q, body)
                with fake.lock:
                    fake.requests.append({"method": method, "path": u.path, "query": parse_qs(u.query), "body": body.decode() if body else "",
                                          "idem": self.headers.get("EXN-IDEMPOTENCY-KEY")})
                if err:
                    return self._send(401, err)
                try:
                    code, obj = fake.route(method, u.path, {k: v[0] for k, v in parse_qs(u.query).items()},
                                           json.loads(body) if body else None, self.headers.get("EXN-IDEMPOTENCY-KEY"),
                                           self.headers.get("Host") or "")
                except Exception as e:                                   # noqa: BLE001
                    code, obj = 500, {"error_code": 9000, "error_message": "fake error: %s" % e}
                self._send(code, obj)

            def do_GET(self):
                self._do("GET")

            def do_POST(self):
                self._do("POST")

            def do_DELETE(self):
                self._do("DELETE")

            def do_PATCH(self):
                self._do("PATCH")

            def do_PUT(self):
                self._do("PUT")
        return H

    # ---- routes ----
    def _family_ok(self, path, host):
        """Mô phỏng: mỗi họ endpoint chỉ được phục vụ ở một host (host chính 'disc' hoặc access point 'ap'); sai host -> 404."""
        parts = path.split("/")
        fam = parts[2] if len(parts) > 2 else ""
        want = self.family_host.get(fam, "any")
        if want == "any" or fam == "trading":
            return True
        is_ap = host == self.ap_host
        return is_ap if want == "ap" else ((not is_ap) if want == "disc" else False)

    def route(self, m, path, q, body, idem, host=""):
        acc = self.account
        with self.lock:
            if m == "GET" and path == "/v1/trading/access-point":
                h = self.ap_host
                return 200, ({"access_point": h, "account_id": int(acc)} if self.ap_shape == "bare"
                             else {"data": {"endpoint": {"host": h}}})
            if path.startswith("/v1/") and m == "GET" and not self._family_ok(path, host):
                return 404, {"error_code": 404, "error_message": "NOT_FOUND on this host %s" % host}
            if path == "/v1/configuration/accounts/%s/account" % acc:
                return 200, {"account_id": acc, "currency": "USD", "balance": "%.2f" % self.balance, "leverage": 200,
                             "account_status": self.account_status, "trade_mode": self.trade_mode}
            if path == "/v1/configuration/accounts/%s/instruments" % acc:
                return 200, {"instruments": sorted(self.prices)}
            mm = re.match(r"^/v1/configuration/accounts/%s/instruments/(\w+)/conditions$" % acc, path)
            if mm:
                return 200, {"volume_min": "0.01", "volume_max": "100", "volume_step": "0.01", "point_digits": 5}
            if path == "/v1/configuration/accounts/%s/limits" % acc:
                return 200, self.limits_payload()
            if path == "/v1/market-data/accounts/%s/candles" % acc:
                return self.candles(q)
            mm = re.match(r"^/v1/history/accounts/%s/(deals|orders)$" % acc, path)
            if m == "GET" and mm:
                return self.history(mm.group(1), q)
            base = "/v1/trading/accounts/%s" % acc
            if m == "GET" and path == base + "/snapshot":
                poss = [dict(p) for p in self.positions.values()]
                if self.sltp_model == "orders":                                 # mức SL/TP chỉ nằm ở lệnh SLTP, không ghi lên vị thế
                    for p in poss:
                        p.pop("stop_loss_price", None)
                        p.pop("take_profit_price", None)
                return 200, {"event_type": "trading_state_snapshot",
                             "account_state": {"balance": "%.2f" % self.balance, "equity": "%.2f" % self.balance, "used_margin": "0"},
                             "positions": poss,
                             "orders": [dict(o, order_id=k, stop_loss_price=o.get("sl"), take_profit_price=o.get("tp")) for k, o in self.orders.items()]}
            mm = re.match(r"^%s/operations/(\w[\w-]*)$" % re.escape(base), path)
            if m == "GET" and mm:
                op = self.ops.get(mm.group(1))
                if not op:
                    return 404, {"error_code": 3004, "error_message": "OPERATION_NOT_FOUND"}
                if op["polls"] < self.confirm_after_polls:
                    op["polls"] += 1
                    return 200, {"status": "pending", "operation_id": mm.group(1)}
                return 200, op["result"]
            if m == "POST" and path == base + "/positions":
                return self.open_position(body, idem)
            mm = re.match(r"^%s/positions/(\w+)$" % re.escape(base), path)
            if m == "DELETE" and mm:
                return self.close_position(mm.group(1), q, body, idem)
            if m == "POST" and path == base + "/orders":
                return self.place_order(body, idem)
            mm = re.match(r"^%s/orders/(\w+)$" % re.escape(base), path)
            if mm and m == "PUT":
                return 405, {"error_code": 1, "error_message": "METHOD_NOT_ALLOWED"}
            if mm and m == "PATCH":
                o = self.orders.get(mm.group(1))
                if not o:
                    return 404, {"error_code": 3005, "error_message": "ORDER_NOT_FOUND"}
                if self.account_status == "close_only":
                    return self._reject(idem, "ACCOUNT_CLOSE_ONLY")
                bad = [k for k in ("price", "stop_loss_price", "take_profit_price") if body.get(k) and self._bad_digits(body[k])]
                if bad:
                    return self._reject(idem, "REQUEST_INVALID_PRICE")
                if "price" in body:
                    o["price"] = float(body["price"])
                if "stop_loss_price" in body:
                    o["sl"] = float(body["stop_loss_price"]) if body["stop_loss_price"] else None
                if "take_profit_price" in body:
                    o["tp"] = float(body["take_profit_price"]) if body["take_profit_price"] else None
                if o.get("type") == "sltp" and self.sltp_model == "position" and o.get("position_id") in self.positions:
                    self.positions[o["position_id"]]["stop_loss_price"], self.positions[o["position_id"]]["take_profit_price"] = o.get("sl"), o.get("tp")
                return self.ack("modify", idem, {})
            if m == "DELETE" and mm:
                if mm.group(1) not in self.orders:
                    return 404, {"error_code": 3005, "error_message": "ORDER_NOT_FOUND"}
                del self.orders[mm.group(1)]
                return self.ack("cancel", idem, {})
        return 404, {"error_code": 404, "error_message": "NOT_FOUND %s %s" % (m, path)}

    # ---- thao tác giao dịch (bất đồng bộ: ACK rồi xác nhận) ----
    def ack(self, kind, idem, extra):
        self.n += 1
        op_id = "op%d" % self.n
        res = {"status": "confirmed", "operation_id": op_id, "client_request_id": idem}
        res.update(extra)
        self.ops[op_id] = {"polls": 0, "result": res}
        if self.confirm_after_polls == 0:
            ev = dict(res, event_type="transaction_event")
            threading.Timer(0.02, self.broadcast, args=(ev,)).start()
        return 202, {"status": "accepted", "operation_id": op_id, "client_request_id": idem}

    def _bad_volume(self, vol):
        try:
            v = float(vol)
        except (TypeError, ValueError):
            return True
        return v < 0.01 - 1e-12 or abs(v / 0.01 - round(v / 0.01)) > 1e-6

    def _bad_digits(self, price):
        """point_digits=5: giá có quá 5 chữ số lẻ bị từ chối (tài liệu)."""
        txt = str(price)
        return "." in txt and len(txt.split(".")[1]) > 5

    def open_position(self, b, idem):
        if self.reject_next:
            msg, self.reject_next = self.reject_next, None
            return self._reject(idem, msg)
        if self.account_status == "close_only":
            return self._reject(idem, "ACCOUNT_CLOSE_ONLY")
        if b.get("instrument") not in self.prices or b.get("side") not in ("buy", "sell") or self._bad_volume(b.get("volume")):
            return 400, {"error_code": 2001, "error_message": "REQUEST_INVALID_PARAMETER"}
        bid, ask = self.prices[b["instrument"]]
        price = ask if b["side"] == "buy" else bid
        pid = self._open(b["instrument"], b["side"], float(b["volume"]), price, float(b["stop_loss_price"]) if b.get("stop_loss_price") else None,
                         float(b["take_profit_price"]) if b.get("take_profit_price") else None)
        extra = {"flat": {"position_id": pid, "order_id": self.last_order_id, "price": "%.5f" % price, "volume": b["volume"]},
                 "nested": {"result": {"deal": {"price": price, "volume": float(b["volume"])}, "position_id": pid}},
                 "noprice": {"position_id": pid}}[self.op_shape]
        return self.ack("open", idem, extra)

    def _reject(self, idem, why):
        """why: tên/thông điệp (str) hoặc (error_code, error_message)."""
        self.n += 1
        op_id = "op%d" % self.n
        code, msg = (why if isinstance(why, tuple) else (4001, why))
        res = {"status": "rejected", "operation_id": op_id, "client_request_id": idem, "error_code": code, "error_message": msg}
        self.ops[op_id] = {"polls": 0, "result": res}
        threading.Timer(0.02, self.broadcast, args=(dict(res, event_type="transaction_event"),)).start()
        return 202, {"status": "accepted", "operation_id": op_id, "client_request_id": idem}

    def close_position(self, pid, q, body, idem):
        p = self.positions.get(pid)
        if not p:
            return 404, {"error_code": 3001, "error_message": "POSITION_NOT_FOUND"}
        src = (body or {}) if self.close_volume_in == "body" else q          # nơi máy chủ ĐỌC volume; nơi kia bị bỏ qua -> đóng hết
        vol = float(src["volume"]) if src.get("volume") not in (None, "") else p["volume"]
        if vol > p["volume"] + 1e-12:
            return self._reject(idem, ("TRADING_RULE_VOLUME_TOO_LARGE", "volume > open volume"))
        bid, ask = self.prices[p["instrument"]]
        price = bid if p["side"] == "buy" else ask
        pnl = (price - p["open_price"]) * (1 if p["side"] == "buy" else -1) * vol * 100000
        self.balance += pnl
        if vol >= p["volume"] - 1e-12:
            del self.positions[pid]
            k = self._sltp_of(pid)
            if k is not None:                                                    # đóng vị thế thì lệnh SLTP của nó mất theo
                del self.orders[k]
        else:
            p["volume"] = round(p["volume"] - vol, 8)
        self.n += 1
        self.deals.append({"deal_id": "D%d" % self.n, "order_id": "O%d" % self.n, "type": "close", "event_time": datetime.now(timezone.utc).isoformat(),
                           "instrument": p["instrument"], "side": "sell" if p["side"] == "buy" else "buy", "volume": vol, "price": price, "profit": pnl,
                           "commission": -0.07, "position_id": pid})
        return self.ack("close", idem, {"price": "%.5f" % price, "volume": "%g" % vol, "order_id": "O%d" % self.n})

    def place_sltp(self, b, idem):
        """Tạo lệnh SLTP cho một vị thế. Máy chủ chỉ ĐỌC trường mã vị thế tên `sltp_key`; thiếu/sai tên -> 400 REQUEST_INVALID (không có tác dụng phụ)."""
        if self.reject_next:
            msg, self.reject_next = self.reject_next, None
            return self._reject(idem, msg)
        pid = b.get(self.sltp_key)
        if not pid or (self.sltp_needs_instrument and not all(b.get(k) for k in ("instrument", "side", "volume"))):
            return 400, {"error_code": 3000, "error_message": "REQUEST_INVALID"}
        p = self.positions.get(str(pid))
        if p is None:
            return 404, {"error_code": 3013, "error_message": "REQUEST_POSITION_NOT_FOUND"}
        if any(b.get(k) and self._bad_digits(b[k]) for k in ("stop_loss_price", "take_profit_price")):
            return self._reject(idem, "REQUEST_INVALID_PRICE")
        sl = float(b["stop_loss_price"]) if b.get("stop_loss_price") else None
        tp = float(b["take_profit_price"]) if b.get("take_profit_price") else None
        bid, ask = self.prices[p["instrument"]]
        buy = p["side"] == "buy"
        if (sl and ((buy and sl >= bid) or (not buy and sl <= ask))) or (tp and ((buy and tp <= bid) or (not buy and tp >= ask))):
            return self._reject(idem, ("TRADING_RULE_INVALID_PRICE_LEVELS", "SL/TP sai phía giá"))
        old = self._sltp_of(str(pid))
        if old is not None:
            del self.orders[old]
        self.n += 1
        oid = "O%d" % self.n
        self.orders[oid] = {"type": "sltp", "instrument": p["instrument"], "side": p["side"], "volume": p["volume"], "price": 0.0, "sl": sl, "tp": tp,
                            "position_id": str(pid)}
        if self.sltp_model == "position":
            p["stop_loss_price"], p["take_profit_price"] = sl, tp
        self.sltp_created.append(dict(b))
        return self.ack("order", idem, {"order_id": oid})

    def place_order(self, b, idem):
        if self.account_status == "close_only" and b.get("type") != "sltp":
            return self._reject(idem, "ACCOUNT_CLOSE_ONLY")
        if b.get("type") == "sltp":
            return self.place_sltp(b, idem)
        if b.get("type") not in ("limit", "stop", "sltp") or b.get("instrument") not in self.prices or self._bad_volume(b.get("volume")):
            return 400, {"error_code": 2001, "error_message": "REQUEST_INVALID_PARAMETER"}
        if any(b.get(k) and self._bad_digits(b[k]) for k in ("price", "stop_loss_price", "take_profit_price")):
            return self._reject(idem, "REQUEST_INVALID_PRICE")
        self.n += 1
        oid = "O%d" % self.n
        self.orders[oid] = {"type": b["type"], "instrument": b["instrument"], "side": b["side"], "volume": float(b["volume"]),
                            "price": float(b["price"]), "sl": float(b["stop_loss_price"]) if b.get("stop_loss_price") else None,
                            "tp": float(b["take_profit_price"]) if b.get("take_profit_price") else None}
        return self.ack("order", idem, {"order_id": oid})

    # ---- thời gian từ/đến ----
    def _parse_time(self, v):
        """-> epoch giây hoặc None nếu định dạng sai/không được chấp nhận (theo time_fmt)."""
        try:
            if self.time_fmt in ("both", "ms") and re.match(r"^\d{11,}$", str(v)):
                return float(v) / 1000.0
        except ValueError:
            pass
        if self.time_fmt in ("both", "iso") and re.match(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ?$", str(v)):
            return datetime.strptime(str(v).replace("Z", ""), "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
        return None

    # ---- nến (tài liệu: from BẮT BUỘC; from+to hoặc from+count; from gồm, to không gồm; tăng dần) ----
    def candles(self, q):
        names = {"mt": {"M1": 60, "M3": 180, "M5": 300, "M10": 600, "M15": 900, "M30": 1800, "H1": 3600},
                 "lower": {"m1": 60, "m3": 180, "m5": 300, "m10": 600, "m15": 900, "m30": 1800, "h1": 3600}}[self.tf_enum]
        if q.get("timeframe") not in names:
            return 400, {"error_code": 2002, "error_message": "REQUEST_INVALID_TIMEFRAME"}
        if q.get("instrument") not in self.prices and q.get("instrument") not in self.candle_only:
            return 404, {"error_code": 2004, "error_message": "MARKET_INSTRUMENT_NOT_FOUND"}
        if "from" not in q or ("to" not in q) == ("count" not in q):
            return 400, {"error_code": 2000, "error_message": "REQUEST_INVALID_PARAMETERS"}
        frm = self._parse_time(q["from"])
        if frm is None:
            return 400, {"error_code": 2003, "error_message": "REQUEST_INVALID_PARAMETERS"}
        step = names[q["timeframe"]]
        now = time.time()
        if "to" in q:
            to = self._parse_time(q["to"])
            if to is None:
                return 400, {"error_code": 2003, "error_message": "REQUEST_INVALID_PARAMETERS"}
            if to <= frm or (to - frm) / step > self.candles_max + 1e-9:
                return 400, {"error_code": 2005, "error_message": "REQUEST_INVALID_TIME_RANGE"}
            t0 = int(-(-frm // step)) * step
            ts = [t0 + k * step for k in range(int((to - t0 + step - 1) // step)) if t0 + k * step < to]
        else:
            cnt = int(q["count"])
            if cnt == 0 or abs(cnt) > self.candles_max:
                return 400, {"error_code": 2006, "error_message": "REQUEST_INVALID_COUNT"}
            t0 = int(-(-frm // step)) * step
            ts = [t0 + k * step for k in range(cnt)] if cnt > 0 else [t0 - (k + 1) * step for k in range(-cnt)][::-1]
        out = []
        for t in ts:
            if t + 0 > now or (self.candle_gap and self.candle_gap[0] <= t < self.candle_gap[1]):
                continue
            base = 1.1 + ((t // step) % 50) * 0.0001
            out.append({"time": datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "open": "%.5f" % base,
                        "high": "%.5f" % (base + 0.0003), "low": "%.5f" % (base - 0.0003), "close": "%.5f" % (base + 0.0001), "volume": 10})
        return 200, {"candles": out}

    # ---- lịch sử (from bắt buộc trừ khi có cursor; limit 1..200; tăng dần theo event_time; có cursor) ----
    def history(self, kind, q):
        now = time.time()
        rows = self.deals if kind == "deals" else self.hist_orders
        if "cursor" in q:
            if set(q) - {"cursor", "limit"}:
                return 400, {"error_code": 2000, "error_message": "REQUEST_INVALID_PARAMETERS"}
            f_, t_, o_ = q["cursor"].split("|")
            frm, to, off = float(f_), float(t_), int(o_)
        else:
            if "from" not in q:
                return 400, {"error_code": 2000, "error_message": "REQUEST_INVALID_PARAMETERS"}
            frm = self._parse_time(q["from"])
            to = self._parse_time(q["to"]) if "to" in q else now + 1
            if frm is None or to is None:
                return 400, {"error_code": 2003, "error_message": "REQUEST_INVALID_PARAMETERS"}
            if frm >= now or to <= frm:
                return 400, {"error_code": 2005, "error_message": "REQUEST_INVALID_TIME_RANGE"}
            if (to - frm) > self.history_range_days * 86400 + 1 or frm < now - self.history_age_days * 86400:
                return 400, {"error_code": 2005, "error_message": "REQUEST_INVALID_TIME_RANGE"}
            off = 0
        lim = int(q.get("limit", 50))
        if not 1 <= lim <= 200:
            return 400, {"error_code": 2006, "error_message": "REQUEST_INVALID_COUNT"}
        sel = []
        for r in rows:
            t = datetime.fromisoformat(r["event_time"]).timestamp()
            if frm <= t < to:
                sel.append(r)
        sel.sort(key=lambda r: r["event_time"])
        page = sel[off:off + lim]
        out = {kind: page}
        if off + lim < len(sel):
            out["next_cursor"] = "%f|%f|%d" % (frm, to, off + lim)
        return 200, out

    # ---- WebSocket ----
    def _ws(self, h, u, path_q):
        m = re.match(r"^/v1/server-events/accounts/%s/ws/(ticks|events)$" % self.account, u.path)
        err = self.check_auth(h, "GET", path_q, b"")
        proto = h.headers.get("Sec-WebSocket-Protocol")
        if not m or err or proto != "exness-ws-protocol":
            code = 401 if err else 404
            body = json.dumps(err or {"error_message": "bad ws request (proto=%s)" % proto}).encode()
            h.send_response(code)
            h.send_header("Content-Length", str(len(body)))
            h.end_headers()
            h.wfile.write(body)
            return
        key = h.headers.get("Sec-WebSocket-Key")
        h.send_response(101)
        h.send_header("Upgrade", "websocket")
        h.send_header("Connection", "Upgrade")
        h.send_header("Sec-WebSocket-Accept", accept_key(key))
        h.send_header("Sec-WebSocket-Protocol", "exness-ws-protocol")
        h.end_headers()
        h.wfile.flush()
        conn = {"kind": m.group(1), "ins": set(), "q": [], "tx": False}
        with self.lock:
            self.ws_conns.append(conn)
        sock = h.connection
        sock.settimeout(0.05)
        buf = bytearray()
        try:
            while not self._stop.is_set():
                try:
                    d = sock.recv(65536)
                    if not d:
                        break
                    buf += d
                except OSError as e:
                    if "timed out" not in str(e):
                        break
                while True:
                    fr = parse_frame(buf)
                    if not fr:
                        break
                    fin, op, payload, used = fr
                    del buf[:used]
                    if op == 0x8:
                        return
                    if op == 0x1:
                        j = json.loads(payload)
                        with self.lock:
                            self.ws_log.append(j)
                            s = j.get("subscribe", {})
                            if s.get("event") == "ticks":
                                conn["ins"].update(s.get("instruments", []))
                            if s.get("event") == "transactions":
                                conn["tx"] = True
                                conn["q"].append({"event_type": "trading_state_snapshot", "positions": []})
                            if s.get("event") == "account_state":
                                conn["q"].append({"event_type": "account_state_event", "event_time": datetime.now(timezone.utc).isoformat(),
                                                  "payload": {"account_state": {"balance": "%.2f" % self.balance, "equity": "%.2f" % self.balance,
                                                                                "used_margin": "0"}}})
                with self.lock:
                    q, conn["q"] = conn["q"], []
                for msg in q:
                    sock.sendall(encode_frame(0x1, json.dumps(msg), mask=False))
        except OSError:
            pass
        finally:
            with self.lock:
                if conn in self.ws_conns:
                    self.ws_conns.remove(conn)
            h.close_connection = True
