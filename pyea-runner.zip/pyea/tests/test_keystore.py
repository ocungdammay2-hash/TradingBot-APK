"""Mã hoá API key at-rest (Keystore/khoá file) - xác nhận trên ĐĨA không còn bản rõ."""
import glob
import json
import os
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea.ipc import ServiceClient
from pyea.keystore import PREFIX, FileKeyBackend, SecretBox, SecretError, box_for
from pyea.loader import inspect_bot
from pyea.storage import Store

SECRET = "sk-THIS-IS-A-SECRET-12345"


def _all_text(d):
    out = []
    for dp, _, files in os.walk(d):
        for f in files:
            if f.endswith(".key") or f == ".pyea_key":
                continue
            try:
                with open(os.path.join(dp, f), "r", encoding="utf-8", errors="ignore") as fh:
                    out.append(fh.read())
            except OSError:
                pass
    return "\n".join(out)


class TestBox(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.box = SecretBox(self.d, prefer_keystore=False)

    def test_roundtrip_and_format(self):
        t = self.box.seal(SECRET)
        self.assertTrue(t.startswith(PREFIX + "file:"))
        self.assertNotIn(SECRET, t)
        self.assertEqual(self.box.open(t), SECRET)

    def test_unicode_and_long(self):
        s = "khoá-bí-mật-🔑" * 200
        self.assertEqual(self.box.open(self.box.seal(s)), s)

    def test_random_nonce_each_time(self):
        self.assertNotEqual(self.box.seal(SECRET), self.box.seal(SECRET))

    def test_plaintext_passthrough_and_empty(self):
        self.assertEqual(self.box.open("plain"), "plain")
        self.assertEqual(self.box.seal(""), "")
        self.assertEqual(self.box.seal(None), None)
        sealed = self.box.seal(SECRET)
        self.assertEqual(self.box.seal(sealed), sealed)          # idempotent: không mã hoá hai lần

    def test_tamper_detected(self):
        t = self.box.seal(SECRET)
        head, payload = t.rsplit(":", 1)
        bad = head + ":" + ("A" if payload[0] != "A" else "B") + payload[1:]
        self.assertEqual(self.box.open(bad), "")
        self.assertTrue(self.box.failed)

    def test_other_device_key_cannot_open(self):
        other = SecretBox(tempfile.mkdtemp(), prefer_keystore=False)
        self.assertEqual(other.open(self.box.seal(SECRET)), "")

    def test_key_file_persisted_and_private(self):
        again = SecretBox(self.d, prefer_keystore=False)
        self.assertEqual(again.open(self.box.seal(SECRET)), SECRET)
        mode = os.stat(os.path.join(self.d, ".pyea_key")).st_mode & 0o777
        self.assertEqual(mode, 0o600)

    def test_keystore_failure_falls_back_to_file(self):
        box = SecretBox(self.d, prefer_keystore=True)           # ngoài Android: không có jnius -> dự phòng
        self.assertEqual(box.default.id, "file")
        self.assertIn("Keystore", box.note)
        self.assertEqual(box.open(box.seal(SECRET)), SECRET)

    def test_short_blob_error(self):
        with self.assertRaises(SecretError):
            FileKeyBackend(self.d).decrypt(b"x" * 10)

    def test_settings_helpers(self):
        s = {"api_key": "K", "api_secret": SECRET, "exchange": "oanda", "leverage": 1.0, "oanda_token": ""}
        sealed = self.box.seal_settings(s)
        self.assertTrue(sealed["api_secret"].startswith(PREFIX))
        self.assertEqual(sealed["exchange"], "oanda")
        self.assertEqual(sealed["oanda_token"], "")
        self.assertEqual(self.box.open_settings(sealed), s)
        self.assertTrue(self.box.has_plain_secret(s))
        self.assertFalse(self.box.has_plain_secret(sealed))

    def test_new_exchange_keys_are_secret(self):
        s = {"exness_private_key": "-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----", "exness_api_key": "ak",
             "metaapi_token": "mt", "mt5gw_token": "gw", "ccxt_secret": "cs", "ccxt_password": "pw"}
        sealed = self.box.seal_settings(s)
        for k in s:
            self.assertTrue(sealed[k].startswith(PREFIX), k)
        self.assertEqual(self.box.open_settings(sealed), s)


class TestStore(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.store = Store(self.d)

    def test_settings_encrypted_on_disk_but_loaded_plain(self):
        s = self.store.load_settings()
        s.update(api_key="AK-" + SECRET, api_secret=SECRET, oanda_token="OT-" + SECRET)
        self.store.save_settings(s)
        raw = open(self.store.settings_path, encoding="utf-8").read()
        self.assertNotIn(SECRET, raw)
        self.assertIn(PREFIX, raw)
        back = self.store.load_settings()
        self.assertEqual(back["api_secret"], SECRET)
        self.assertEqual(back["oanda_token"], "OT-" + SECRET)

    def test_legacy_plaintext_is_migrated_in_place(self):
        s = self.store.load_settings()
        s["api_secret"] = SECRET
        with open(self.store.settings_path, "w", encoding="utf-8") as f:      # file cũ: bản rõ
            json.dump(s, f)
        self.assertIn(SECRET, open(self.store.settings_path, encoding="utf-8").read())
        self.assertEqual(self.store.load_settings()["api_secret"], SECRET)
        self.assertNotIn(SECRET, open(self.store.settings_path, encoding="utf-8").read())

    def test_agents_keys_encrypted(self):
        self.store.save_agents([{"name": "gpt", "api_key": SECRET, "model": "m"}])
        raw = open(self.store.agents_path, encoding="utf-8").read()
        self.assertNotIn(SECRET, raw)
        self.assertEqual(self.store.load_agents()[0]["api_key"], SECRET)
        self.assertEqual(self.store.load_agents()[0]["model"], "m")

    def test_backup_without_secrets_masks_all_new_keys(self):
        s = self.store.load_settings()
        s.update(api_secret=SECRET, exness_private_key=SECRET, metaapi_token=SECRET)
        self.store.save_settings(s)
        z = self.store.export_backup()
        with zipfile.ZipFile(z) as zf:
            txt = zf.read("settings.json").decode()
        self.assertNotIn(SECRET, txt)
        self.assertNotIn(PREFIX, txt)

    def test_backup_with_secrets_is_portable_plaintext_then_resealed_on_import(self):
        s = self.store.load_settings()
        s["api_secret"] = SECRET
        self.store.save_settings(s)
        z = self.store.export_backup(include_secrets=True)
        with zipfile.ZipFile(z) as zf:
            self.assertIn(SECRET, zf.read("settings.json").decode())          # người dùng chủ động giữ khoá
        other = Store(tempfile.mkdtemp())
        n, warns = other.import_backup(z)
        self.assertGreater(n, 0)
        self.assertEqual(other.load_settings()["api_secret"], SECRET)
        self.assertNotIn(SECRET, open(other.settings_path, encoding="utf-8").read())    # đã mã hoá lại bằng khoá máy mới

    def test_import_keeps_existing_secret_when_backup_blank(self):
        s = self.store.load_settings()
        s["api_secret"] = SECRET
        self.store.save_settings(s)
        z = self.store.export_backup()                                           # đã xoá khoá
        self.store.import_backup(z)
        self.assertEqual(self.store.load_settings()["api_secret"], SECRET)


class TestIpc(unittest.TestCase):
    def test_config_secrets_never_plaintext_in_ipc_files(self):
        d = tempfile.mkdtemp()
        c = ServiceClient(d)
        cfg = {"settings": {"api_secret": SECRET, "exchange": "binance_futures", "exness_private_key": SECRET}, "token": "t"}
        c.send("session_start", config=cfg)
        c.write_desired({"running": True, "config": cfg})
        self.assertNotIn(SECRET, _all_text(d))
        cmds = ServiceClient(d).pop_commands()                                    # phía dịch vụ đọc lại
        self.assertEqual(cmds[0]["config"]["settings"]["api_secret"], SECRET)
        self.assertEqual(ServiceClient(d).read_desired()["config"]["settings"]["exness_private_key"], SECRET)

    def test_other_commands_unaffected(self):
        d = tempfile.mkdtemp()
        c = ServiceClient(d)
        c.send("place_order", symbol="X", side="buy")
        self.assertEqual(c.pop_commands()[0]["symbol"], "X")


class TestBotImportGuard(unittest.TestCase):
    def _inspect(self, body):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "b.py")
        open(p, "w", encoding="utf-8").write(body)
        return inspect_bot(p)

    def test_bot_cannot_import_internal_secret_modules(self):
        for line in ("from pyea.keystore import box_for", "from pyea import storage", "import pyea.broker", "from jnius import autoclass",
                     "from pyea.exness import ExnBroker"):
            info = self._inspect("%s\nfrom pyea import BaseBot\nclass B(BaseBot):\n    pass\n" % line)
            self.assertFalse(info.ok, line)

    def test_normal_sdk_imports_still_allowed(self):
        info = self._inspect("from pyea import BaseBot, Input, ta\nclass B(BaseBot):\n    inputs = {}\n    def on_tick(self, t):\n        pass\n")
        self.assertTrue(info.ok, getattr(info, "error", ""))


if __name__ == "__main__":
    unittest.main()
