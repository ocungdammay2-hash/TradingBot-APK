"""api.store / api.shared (kho JSON bền của bot) và quyền mạng theo bot (# @permission: network(host)) - cưỡng chế ở tiến trình riêng THẬT."""
import json
import os
import socket
import sys
import tempfile
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

from pyea import kvstore, loader, perms                                           # noqa: E402
from pyea.backtest import run_backtest                                            # noqa: E402
from pyea.engine import TradingSession                                            # noqa: E402
from pyea.kvstore import KVStore                                                  # noqa: E402
from pyea.sdk import Candle                                                       # noqa: E402
from pyea.settings import default_settings                                        # noqa: E402
from test_botproc import HEAD, ProcBase, S, wait, write                           # noqa: E402


# ======================================================================================= KVStore
class TestKVStore(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.p = os.path.join(self.d, "s.json")

    def test_persists_across_instances_and_returns_copies(self):
        a = KVStore(self.p)
        a.set("cfg", {"x": [1, 2], "n": None})
        b = KVStore(self.p)
        v = b.get("cfg")
        self.assertEqual(v, {"x": [1, 2], "n": None})
        v["x"].append(99)                                                # sửa bản sao không đổi kho
        self.assertEqual(b.get("cfg")["x"], [1, 2])
        self.assertEqual(b.get("none", "mặc định"), "mặc định")

    def test_unchanged_value_does_not_touch_the_disk(self):
        a = KVStore(self.p)
        self.assertTrue(a.set("k", 1))
        m = os.stat(self.p).st_mtime_ns
        writes = []
        orig = a._flush
        a._flush = lambda: (writes.append(1), orig())[1]
        self.assertFalse(a.set("k", 1))
        self.assertEqual(writes, [])
        self.assertEqual(os.stat(self.p).st_mtime_ns, m)
        self.assertTrue(a.set("k", 2))
        self.assertEqual(writes, [1])

    def test_validation_and_limits(self):
        a = KVStore(self.p, max_total=500, max_value=100, max_keys=3)
        for bad in (object(), {1, 2}, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                a.set("k", bad)
        with self.assertRaises(ValueError):
            a.set("", 1)
        with self.assertRaises(ValueError):
            a.set("x" * 81, 1)
        with self.assertRaises(ValueError):
            a.set("big", "x" * 200)
        a.set("a", 1); a.set("b", 2); a.set("c", 3)
        with self.assertRaises(ValueError):
            a.set("d", 4)
        a.set("a", 10)                                                    # ghi đè khoá cũ vẫn được
        self.assertEqual(a.keys(), ["a", "b", "c"])
        b = KVStore(self.p + "2", max_total=60)
        b.set("k1", "x" * 20)
        with self.assertRaises(ValueError):
            b.set("k2", "y" * 50)
        self.assertEqual(b.keys(), ["k1"])                                # lần ghi bị từ chối không để lại dấu vết

    def test_incr_delete_clear_items(self):
        a = KVStore()
        self.assertEqual(a.incr("n"), 1)
        self.assertEqual(a.incr("n", 4), 5)
        a.set("s", "text")
        with self.assertRaises(ValueError):
            a.incr("s")
        self.assertTrue(a.delete("n"))
        self.assertFalse(a.delete("n"))
        self.assertEqual(a.items(), {"s": "text"})
        self.assertEqual(a.clear(), 1)
        self.assertEqual(a.size(), 0)

    def test_incr_is_atomic_across_threads(self):
        a = KVStore(self.p)

        def work():
            for _ in range(50):
                a.incr("c")
        ts = [threading.Thread(target=work) for _ in range(8)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(KVStore(self.p).get("c"), 400)

    def test_corrupt_file_is_kept_aside_and_store_starts_empty(self):
        open(self.p, "w").write("{không phải json")
        a = KVStore(self.p)
        self.assertEqual(a.keys(), [])
        self.assertTrue(os.path.exists(self.p + ".corrupt"))
        a.set("k", 1)
        self.assertEqual(KVStore(self.p).get("k"), 1)

    def test_memory_only_never_creates_files(self):
        a = KVStore(None)
        a.set("k", 1)
        self.assertEqual(os.listdir(self.d), [])

    def test_rpc_gateway_allows_only_known_operations(self):
        a = KVStore()
        a.call("set", "k", 1)
        self.assertEqual(a.call("get", "k", None), 1)
        for op in ("_flush", "path", "__init__", "load"):
            with self.assertRaises(AttributeError):
                a.call(op)


# ======================================================================================= thread mode
COUNTER = HEAD + '''
class C(BaseBot):
    def on_init(self):
        n = self.api.store.incr("starts")
        self.api.store.set("last", {"symbol": self.api.symbol, "n": n})
        self.api.log("STORE starts=%d last=%s" % (n, self.api.store.get("last")))
        self.api.shared.set("flag_" + self.api.symbol, n)
'''
READER = HEAD + '''
class R(BaseBot):
    def on_init(self):
        self.api.log("SHARED sees=%s" % sorted(self.api.shared.items().items()))
        try:
            self.api.store.set("bad", object())
        except ValueError as e:
            self.api.log("STORE rejected non-json")
'''


class TestStoreInThreadMode(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.sessions = []

    def tearDown(self):
        for s in self.sessions:
            try:
                for i in list(s.instances.values()):
                    i.stop()
                s.stop(wait=True)
            except Exception:
                pass

    def session(self):
        s = TradingSession(S(bot_isolation="thread"), log_file=None)
        s.data_dir = self.d
        self.sessions.append(s)
        return s

    def logs(self, s):
        return "\n".join(x[3] for x in s.get_logs(0))

    def test_store_survives_restart_and_is_per_bot_while_shared_is_common(self):
        path = write(self.d, "c.py", COUNTER)
        rpath = write(self.d, "r.py", READER)
        s1 = self.session()
        i1 = s1.attach(path, "BTCUSD", "1m", {}, iid="c1")
        s1.start(); i1.start()
        self.assertTrue(wait(lambda: "STORE starts=1" in self.logs(s1)), self.logs(s1))
        i1.stop(); s1.stop(wait=True)
        s2 = self.session()                                                # "khởi động lại app": phiên mới, cùng thư mục dữ liệu + iid
        i2 = s2.attach(path, "BTCUSD", "1m", {}, iid="c1")
        o = s2.attach(rpath, "BTCUSD", "1m", {}, iid="r1")
        s2.start(); i2.start(); o.start()
        self.assertTrue(wait(lambda: "STORE starts=2" in self.logs(s2)), self.logs(s2))
        self.assertIn("'symbol': 'BTCUSD'", self.logs(s2))
        self.assertTrue(wait(lambda: "STORE rejected non-json" in self.logs(s2)), self.logs(s2))
        self.assertTrue(os.path.isfile(os.path.join(self.d, "bot_data", "c1", "store.json")))
        self.assertFalse(os.path.isfile(os.path.join(self.d, "bot_data", "r1", "store.json")))     # bot đọc không ghi gì -> không có file
        self.assertIn("flag_BTCUSD", json.load(open(os.path.join(self.d, "shared_vars.json"))))
        self.assertTrue(wait(lambda: "SHARED sees=" in self.logs(s2)))
        # kho riêng của bot r1 không thấy khoá của c1
        self.assertEqual(o.kv("store").keys(), [])

    def test_backtests_do_not_leak_state_between_runs(self):
        body = HEAD + '''
class B(BaseBot):
    def on_init(self):
        self.api.log("RUNSEEN=%d" % self.api.store.incr("runs"))
        self.api.log("SHAREDSEEN=%d" % self.api.shared.incr("g"))
'''
        path = write(self.d, "bt.py", body)
        cs = [Candle(1_700_000_000 + i * 300, 100, 100, 100, 100, 1.0) for i in range(120)]
        a = run_backtest(path, {}, default_settings(), "BTCUSD", "5m", cs, warmup=20)
        b = run_backtest(path, {}, default_settings(), "BTCUSD", "5m", cs, warmup=20)
        for r in (a, b):
            self.assertTrue(r.ok, r.error)
            joined = "\n".join(r.logs)
            self.assertIn("RUNSEEN=1", joined)
            self.assertIn("SHAREDSEEN=1", joined)                          # lần chạy thứ hai KHÔNG thấy trạng thái của lần đầu
        self.assertFalse(os.path.exists(os.path.join(tempfile.gettempdir(), "bot_data", "bt", "store.json")))


# ======================================================================================= tiến trình riêng
class TestStoreInProcessMode(ProcBase):
    def test_store_and_shared_work_over_rpc_and_errors_cross_the_boundary(self):
        body = HEAD + '''
class P(BaseBot):
    def on_init(self):
        s, g = self.api.store, self.api.shared
        s.set("k", {"a": [1, 2.5, "x", None, True]})
        n = g.incr("count")
        try:
            s.set("bad", {1, 2})
        except ValueError:
            self.api.log("PROC non-json rejected")
        self.api.log("PROC got=%s count=%s keys=%s has=%s" % (s.get("k"), n, s.keys(), s.has("k")))
'''
        s, inst = self.run_bot(body)
        self.assertTrue(wait(lambda: "PROC got=" in self.logs(s)), self.logs(s))
        out = self.logs(s)
        self.assertIn("PROC non-json rejected", out)
        self.assertIn("{'a': [1, 2.5, 'x', None, True]}", out)
        self.assertIn("count=1", out)
        self.assertEqual(json.load(open(os.path.join(self.d, "bot_data", "p1", "store.json")))["k"]["a"][0], 1)
        self.assertEqual(json.load(open(os.path.join(self.d, "shared_vars.json"))), {"count": 1})


class Listener:
    def __init__(self):
        self.srv = socket.socket()
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(5)
        self.port = self.srv.getsockname()[1]
        self.hits = 0
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while True:
            try:
                c, _ = self.srv.accept()
                self.hits += 1
                c.close()
            except OSError:
                return

    def close(self):
        self.srv.close()


def net_bot(port, decl=""):
    return decl + HEAD + '''
import socket
class N(BaseBot):
    def on_init(self):
        try:
            socket.create_connection(("127.0.0.1", %d), timeout=3).close()
            self.api.log("NET connected")
        except PermissionError as e:
            self.api.log("NET denied: %%s" %% e)
        except OSError as e:
            self.api.log("NET oserror %%s" %% e)
''' % port


class TestNetworkPermissionsInProcessMode(ProcBase):
    def setUp(self):
        super().setUp()
        self.srv = Listener()

    def tearDown(self):
        self.srv.close()
        super().tearDown()

    def run_net(self, decl="", grant=None, **settings):
        path = write(self.d, "net.py", net_bot(self.srv.port, decl))
        if grant:
            perms.PermStore(self.d).grant(path, "network", grant)
        s, inst = self.run_bot(net_bot(self.srv.port, decl), name="net.py", **settings)
        self.assertTrue(wait(lambda: "NET " in self.logs(s)), self.logs(s))
        return self.logs(s)

    def test_default_bot_has_no_network_in_process_mode(self):
        out = self.run_net()
        self.assertIn("NET denied", out)
        self.assertIn("@permission: network(127.0.0.1)", out)           # thông báo chỉ cách khai báo
        self.assertEqual(self.srv.hits, 0)

    def test_declared_but_not_granted_is_still_denied(self):
        out = self.run_net("# @permission: network(127.0.0.1)\n")
        self.assertIn("NET denied", out)
        self.assertEqual(self.srv.hits, 0)

    def test_declared_and_granted_connects(self):
        out = self.run_net("# @permission: network(127.0.0.1)\n", grant=["127.0.0.1"])
        self.assertIn("NET connected", out)
        self.assertTrue(wait(lambda: self.srv.hits == 1))

    def test_grant_for_other_host_does_not_open_loopback(self):
        out = self.run_net("# @permission: network(127.0.0.1)\n", grant=["api.other.com"])
        self.assertIn("NET denied", out)

    def test_grant_covers_only_what_was_declared(self):
        """Người dùng cấp host A; bot sau đó sửa file xin thêm 127.0.0.1 -> phần mới chưa được cấp."""
        out = self.run_net("# @permission: network(api.other.com, 127.0.0.1)\n", grant=["api.other.com"])
        self.assertIn("NET denied", out)

    def test_policy_off_and_dev_mode_disable_the_guard(self):
        self.assertIn("NET connected", self.run_net(bot_net_policy="off"))

    def test_sandbox_escape_modules_are_rejected_statically(self):
        errs, _, _ = loader.check_bot_source("import _socket\nclass B: pass\n")
        self.assertTrue(errs and "_socket" in errs[0])
        errs, _, _ = loader.check_bot_source("import _socket\nclass B: pass\n", dev_mode=True)
        self.assertEqual(errs, [])


# ======================================================================================= khai báo + lưu cấp phép
class TestPermsModel(unittest.TestCase):
    def test_parse_declared_all_forms(self):
        src = ("# @permission: network(api.x.com, *.example.org, 1.2.3.4, bad host!)\n# @permission: file(read:data/*.csv)\n"
               "# @permission: ai_signal\n# @permission: laser\n# @permissions: network, files\nclass B: pass\n")
        d = perms.parse_declared(src)
        self.assertEqual(d["network"], ["api.x.com", "*.example.org", "1.2.3.4", "*"])       # '*' do khai báo kiểu cũ `network` trống host
        self.assertEqual(d["file"], ["read:data/*.csv"])
        self.assertTrue(d["ai_signal"])
        self.assertEqual(len(d["errors"]), 2)
        self.assertEqual(perms.parse_declared("class B: pass")["network"], [])

    def test_host_matching_rules(self):
        m = perms.host_matches
        self.assertTrue(m("API.X.com", ["api.x.com"]))
        self.assertTrue(m("a.b.example.org", ["*.example.org"]))
        self.assertFalse(m("example.org", ["*.example.org"]))
        self.assertFalse(m("evilexample.org", ["*.example.org"]))
        self.assertFalse(m("api.x.com.evil.io", ["api.x.com"]))
        self.assertTrue(m("anything.io", ["*"]))
        self.assertFalse(m("", ["*"]))

    def test_store_pending_grant_revoke(self):
        d = tempfile.mkdtemp()
        st = perms.PermStore(d)
        decl = perms.parse_declared("# @permission: network(api.x.com, *.y.org)\n")
        self.assertEqual(st.pending("/x/bot.py", decl), {"network": ["api.x.com", "*.y.org"]})
        st.grant_declared("/other/path/bot.py", decl)                      # khoá theo TÊN file
        self.assertEqual(st.pending("bot.py", decl), {})
        self.assertEqual(st.effective_hosts("bot.py", decl), ["api.x.com", "*.y.org"])
        wide = perms.parse_declared("# @permission: network\n")
        self.assertEqual(st.pending("bot.py", wide), {"network": ["*"]})   # cấp host cụ thể KHÔNG phải cấp mọi host
        self.assertEqual(st.effective_hosts("bot.py", wide), [])
        st.revoke("bot.py")
        self.assertEqual(st.effective_hosts("bot.py", decl), [])
        self.assertEqual(perms.PermStore(None).effective_hosts("bot.py", decl), [])

    def test_loader_warns_when_network_used_without_declaration(self):
        _, w, man = loader.check_bot_source("import requests\nclass B: pass\n")
        self.assertTrue(any("chưa khai báo" in x for x in w))
        _, w, man = loader.check_bot_source("# @permission: network(api.x.com)\nimport requests\nclass B: pass\n")
        self.assertFalse(any("chưa khai báo" in x for x in w))
        self.assertEqual(man["perms"]["network"], ["api.x.com"])


# ======================================================================================= giao diện
class TestPermsUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def make(self):
        from test_ui_smoke import make_app
        app = make_app()
        self.path = os.path.join(app.store.bots_dir, "netbot.py")
        open(self.path, "w", encoding="utf-8").write("# @permission: network(api.my-model.com)\n" + HEAD + "class N(BaseBot):\n    pass\n")
        return app

    def test_ask_grant_then_not_asked_again_and_revoke(self):
        from test_ui_smoke import press, texts
        app = self.make()
        self.assertTrue(app.ask_bot_perms(self.path))
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("api.my-model.com", texts(pop.content))
        self.assertIn("CƯỠNG CHẾ", texts(pop.content))                    # đang ở chế độ luồng: nói rõ chưa cưỡng chế
        press(pop.content, "Cho phép")
        st = perms.PermStore(app.data_dir)
        self.assertEqual(st.granted(self.path)["network"], ["api.my-model.com"])
        n = len(kivy_stub.OPEN_POPUPS)
        self.assertFalse(app.ask_bot_perms(self.path))
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n)
        app.selected = self.path
        app.bot_perms_dialog()
        press(kivy_stub.OPEN_POPUPS[-1].content, "Thu hồi")
        self.assertEqual(st.granted(self.path), {})

    def test_deny_keeps_bot_attachable_and_grants_nothing(self):
        from test_ui_smoke import press
        app = self.make()
        called = []
        app.ask_bot_perms(self.path, then=lambda: called.append(1))
        press(kivy_stub.OPEN_POPUPS[-1].content, "Từ chối")
        self.assertEqual(called, [1])
        self.assertEqual(perms.PermStore(app.data_dir).granted(self.path), {})

    def test_bot_without_declaration_is_not_asked(self):
        app = self.make()
        plain = os.path.join(app.store.bots_dir, "plain.py")
        open(plain, "w", encoding="utf-8").write(HEAD + "class P(BaseBot):\n    pass\n")
        n = len(kivy_stub.OPEN_POPUPS)
        self.assertFalse(app.ask_bot_perms(plain))
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n)

    def test_info_panel_lists_requested_permissions(self):
        app = self.make()
        info = app.get_info(self.path)
        app.attach_tab.show_info(info)
        self.assertIn("api.my-model.com", app.attach_tab.info_text.text)


if __name__ == "__main__":
    unittest.main()
