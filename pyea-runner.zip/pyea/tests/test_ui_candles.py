"""Tab Backtest: nguồn dữ liệu (sàn tự lưu / file đã nhập) và hộp thoại «Dữ liệu nến đã lưu» (giao diện giả Kivy; không kiểm được cảm ứng/Android)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402
from pyea import candlestore as cst                      # noqa: E402
from pyea.sdk import Candle                              # noqa: E402

T0 = 1700000000 - 1700000000 % 3600


def series(n, step=300):
    return [Candle(T0 + i * step, 100 + i * .01, 101 + i * .01, 99 + i * .01, 100.5 + i * .01, 5.0) for i in range(n)]


class T(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_form_has_data_source_default_exchange(self):
        import test_ui_smoke as S
        app = S.make_app()
        vals, errs = app.bt_tab.form.read()
        self.assertEqual(errs, [])
        self.assertEqual(vals["data_source"], "Sàn (tự lưu)")

    def test_file_source_reads_store_and_explains_when_missing(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        vals, _ = bt.form.read()
        vals["data_source"] = "File đã nhập"
        with self.assertRaises(ValueError) as cm:
            bt._candles(vals, dict(app.settings), "XAUUSD", "5m", 100, None)
        self.assertIn("Nhập CSV", str(cm.exception))
        bt.candle_store().put(cst.FILE_SOURCE, "XAUUSD", "5m", series(300))
        out = bt._candles(vals, dict(app.settings), "XAUUSD", "5m", 100, None)
        self.assertEqual(len(out), 100)
        self.assertEqual(out[-1].time, T0 + 299 * 300)

    def test_simulated_exchange_not_stored(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        vals, _ = bt.form.read()
        st = dict(app.settings, exchange="simulated")
        bt._candles(vals, st, "BTCUSD", "5m", 60, None)
        self.assertEqual(bt.candle_store().list(), [])

    def test_dialog_opens_empty_and_with_data(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        n0 = len(kivy_stub.OPEN_POPUPS)
        bt.data_dialog()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        bt.candle_store().put("public", "BTCUSD", "5m", series(50))
        bt.data_dialog()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 2)

    def test_describe_line(self):
        import test_ui_smoke  # noqa: F401  (cài kivy giả)
        from pyea.ui_candles import describe
        s = cst.CandleStore(os.path.join(__import__("tempfile").mkdtemp(), "c"))
        s.put("public", "BTCUSD", "5m", series(50))
        d = describe(s.list()[0])
        self.assertIn("BTCUSD", d)
        self.assertIn("50 nến", d)


if __name__ == "__main__":
    unittest.main()
