"""Sao lưu/đồng bộ mã hoá: mã hoá đúng, sai mật khẩu, chống sửa gói, chống ghi ra ngoài, hợp nhất mới-hơn-thắng, WebDAV giả."""
import json
import os
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import botversions, bundle
from pyea.storage import Store


def mk():
    t = tempfile.TemporaryDirectory()
    return t, Store(t.name)


class TestCrypto(unittest.TestCase):
    def test_roundtrip_wrong_password_tamper(self):
        blob = bundle.seal(b"xin chao" * 50, "mk-dung", iters=2000)
        self.assertNotIn(b"xin chao", blob)
        self.assertEqual(bundle.unseal(blob, "mk-dung"), b"xin chao" * 50)
        with self.assertRaises(bundle.BundleError):
            bundle.unseal(blob, "mk-sai")
        bad = bytearray(blob)
        bad[60] ^= 1
        with self.assertRaises(bundle.BundleError):
            bundle.unseal(bytes(bad), "mk-dung")
        with self.assertRaises(bundle.BundleError):
            bundle.unseal(b"khong phai goi", "x")
        self.assertNotEqual(bundle.seal(b"a", "p", 2000), bundle.seal(b"a", "p", 2000))      # salt/nonce ngẫu nhiên


class TestBundle(unittest.TestCase):
    def setUp(self):
        self.ta, self.a = mk()
        self.tb, self.b = mk()
        self.addCleanup(self.ta.cleanup)
        self.addCleanup(self.tb.cleanup)

    def test_transfer_bots_params_prefs_and_exclusions(self):
        self.a.install_bot_text("alpha.py", "# alpha\n")
        self.a.save_params(self.a.bots_dir + "/alpha.py", {"x": 1}) if hasattr(self.a, "save_params") else None
        self.a.save_prefs({"drawings": {"BTCUSDT": [{"k": 1}]}})
        open(os.path.join(self.a.base, "bot_perms.json"), "w").write('{"alpha.py": {"network": ["x.com"]}}')
        open(os.path.join(self.a.logs_dir, "x.log"), "w").write("nhat ky")
        blob = bundle.export_bundle(self.a, "mk")
        rep = bundle.import_bundle(self.b, blob, "mk")
        self.assertIn("bots/alpha.py", rep["written"])
        self.assertEqual(open(os.path.join(self.b.bots_dir, "alpha.py")).read(), "# alpha\n")
        self.assertEqual(self.b.load_prefs()["drawings"]["BTCUSDT"], [{"k": 1}])
        self.assertFalse(os.path.exists(os.path.join(self.b.base, "bot_perms.json")))          # quyền bot KHÔNG đi theo
        self.assertFalse(any("log" in r for r in rep["written"]))
        self.assertNotIn("settings", rep["written"])                                           # mặc định không gồm cài đặt/khoá API

    def test_newer_wins_and_overwritten_bot_is_versioned(self):
        pa = self.a.install_bot_text("beta.py", "# a-cu\n")
        pb = self.b.install_bot_text("beta.py", "# b-moi\n")
        now = time.time()
        os.utime(pa, (now - 1000, now - 1000))
        os.utime(pb, (now, now))
        rep = bundle.import_bundle(self.b, bundle.export_bundle(self.a, "mk"), "mk")
        self.assertIn("bots/beta.py", rep["kept"])                                              # máy B mới hơn -> giữ
        self.assertEqual(open(pb).read(), "# b-moi\n")
        os.utime(pa, (now + 500, now + 500))
        rep = bundle.import_bundle(self.b, bundle.export_bundle(self.a, "mk"), "mk")
        self.assertIn("bots/beta.py", rep["written"])
        self.assertEqual(open(pb).read(), "# a-cu\n")
        self.assertEqual([botversions.read_version(pb, v["name"]) for v in botversions.list_versions(pb)], ["# b-moi\n"])

    def test_malicious_paths_are_skipped(self):
        evil = {"v": 1, "time": 1, "files": {"../../evil.py": {"b": "eA==", "m": 1}, "bots/../x.py": {"b": "eA==", "m": 1},
                                             "bots/ok.py": {"b": "IyBvawo=", "m": 1}, "bot_perms.json": {"b": "e30=", "m": 1}}}
        blob = bundle.seal(json.dumps(evil).encode(), "mk", 2000)
        rep = bundle.import_bundle(self.b, blob, "mk")
        self.assertEqual(rep["written"], ["bots/ok.py"])
        self.assertEqual(sorted(rep["skipped"]), ["../../evil.py", "bot_perms.json", "bots/../x.py"])
        self.assertFalse(os.path.exists(os.path.join(os.path.dirname(self.b.base), "evil.py")))

    def test_settings_opt_in_is_resealed_on_target(self):
        s = self.a.load_settings()
        s["api_key"], s["api_secret"] = "KEY-A", "SECRET-A"
        self.a.save_settings(s)
        blob = bundle.export_bundle(self.a, "mk", include_secrets=True)
        self.assertNotIn(b"SECRET-A", blob)
        rep = bundle.import_bundle(self.b, blob, "mk")
        self.assertIn("settings", rep["written"])
        got = self.b.load_settings()
        self.assertEqual((got["api_key"], got["api_secret"]), ("KEY-A", "SECRET-A"))
        self.assertNotIn("SECRET-A", open(self.b.settings_path).read())                        # trên đĩa máy B vẫn được mã hoá

    def test_sync_via_file_two_devices(self):
        f = os.path.join(self.ta.name, "sync.bin")
        self.a.install_bot_text("g.py", "# g1\n")
        bundle.sync(self.a, "mk", f)
        r = bundle.sync(self.b, "mk", f)
        self.assertIn("bots/g.py", r["pulled"]["written"])
        self.b.install_bot_text("h.py", "# h\n")
        bundle.sync(self.b, "mk", f)
        r = bundle.sync(self.a, "mk", f)
        self.assertIn("bots/h.py", r["pulled"]["written"])
        with self.assertRaises(bundle.BundleError):
            bundle.sync(self.a, "sai", f)


class TestWebDAV(unittest.TestCase):
    def test_sync_over_webdav_with_auth_and_https_rule(self):
        store = {}

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _ok(self):
                return self.headers.get("Authorization", "").startswith("Basic ")

            def do_GET(self):
                if not self._ok():
                    self.send_response(401)
                    self.end_headers()
                    return
                if "b" not in store:
                    self.send_response(404)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Length", str(len(store["b"])))
                self.end_headers()
                self.wfile.write(store["b"])

            def do_PUT(self):
                if not self._ok():
                    self.send_response(401)
                    self.end_headers()
                    return
                store["b"] = self.rfile.read(int(self.headers["Content-Length"]))
                self.send_response(201)
                self.send_header("Content-Length", "0")
                self.end_headers()
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.server_close)
        self.addCleanup(srv.shutdown)
        url = "http://127.0.0.1:%d/pyea.bin" % srv.server_address[1]
        ta, a = mk()
        tb, b = mk()
        self.addCleanup(ta.cleanup)
        self.addCleanup(tb.cleanup)
        a.install_bot_text("w.py", "# w\n")
        r = bundle.sync(a, "mk", url, user="u", webdav_password="p")
        self.assertTrue(r["pushed"] and r["pulled"] is None)                                    # lần đầu: 404 -> chỉ đẩy lên
        self.assertNotIn(b"# w", store["b"])
        self.assertIn("bots/w.py", bundle.sync(b, "mk", url, user="u", webdav_password="p")["pulled"]["written"])
        with self.assertRaises(bundle.BundleError):
            bundle.sync(a, "mk", url)                                                           # thiếu thông tin đăng nhập -> 401
        with self.assertRaises(bundle.BundleError):
            bundle.sync(a, "mk", "http://example.com/x.bin")                                    # http thường bị từ chối


if __name__ == "__main__":
    unittest.main()
