"""Sửa lỗi bố cục báo từ máy thật (1.9.17): tab Cài đặt bị nút cố định chiếm nửa màn hình, nút đặt lệnh trên biểu đồ bị ép nhỏ,
kéo trang khó, chụp màn hình bị chặn. Stub Kivy không đo được pixel nên test kiểm CẤU TRÚC (ai nằm trong vùng cuộn, tham số cuộn)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub
import test_ui_smoke as T


def walk(w):
    yield w
    for c in getattr(w, "children", []):
        yield from walk(c)


class TestLayout(unittest.TestCase):
    def setUp(self):
        kivy_stub.OPEN_POPUPS.clear()
        self.app = T.make_app()

    def test_settings_action_buttons_live_inside_the_scroll_area(self):
        st = self.app.settings_tab if hasattr(self.app, "settings_tab") else self.app.tabs["settings"]
        direct = [c for c in st.children]
        # ngoài vùng cuộn chỉ còn hàng Lưu/Mặc định + chính vùng cuộn
        self.assertEqual(len(direct), 2, [type(c).__name__ for c in direct])
        outside = T.texts(st.top_row)
        self.assertIn("Lưu", outside)
        for label in ("Sao lưu", "Gói chẩn đoán", "Hướng dẫn · điều khoản", "Tài khoản (chạy song song)", "Không làm phiền".upper()):
            self.assertNotIn(label, outside)
            self.assertIn(label, T.texts(st.content), label)

    def test_scroll_views_use_drag_friendly_thresholds(self):
        from pyea import ui_widgets as W
        sv = W.vscroll(W.vbox())
        self.assertGreaterEqual(sv.scroll_timeout, 150)
        self.assertLessEqual(sv.scroll_distance, 12 * 4)
        self.assertGreaterEqual(sv.bar_width, 5)

    def test_chart_tools_row_has_four_roomy_buttons_and_order_button(self):
        ct = self.app.chart_tab
        top = ct.children[-1] if False else None
        blob = T.texts(ct)
        self.assertIn("Đặt lệnh", blob)
        self.assertIn("Lệnh mới", blob)
        rows = [w for w in walk(ct) if len([c for c in getattr(w, "children", []) if hasattr(c, "on_release") or type(c).__name__ == "Button"]) == 4]
        self.assertTrue(rows, "không thấy hàng công cụ 4 nút")

    def test_order_button_when_not_connected_explains_and_offers_to_connect(self):
        ct = self.app.chart_tab
        self.app.is_connected = lambda: False
        called = []
        self.app.start_session = lambda *a: called.append(1)
        kivy_stub.OPEN_POPUPS.clear()
        ct.toggle_draft()
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("Chưa kết nối", pop.title)
        T.press(pop.content, "Kết nối")
        self.assertEqual(called, [1])

    def test_screenshots_allowed_by_default_and_migration_runs_once(self):
        from pyea.settings import default_settings
        self.assertEqual(default_settings()["secure_screen"], "off")
        self.assertFalse(self.app.want_secure())
        self.app.settings["secure_screen"] = "always"
        self.assertTrue(self.app.want_secure())

    def test_migration_resets_old_sensitive_default_once_and_keeps_always(self):
        import tempfile
        from pyea.storage import Store, migrate_defaults
        d = tempfile.mkdtemp()
        st = Store(d)
        s = st.load_settings()
        s["secure_screen"] = "sensitive"
        st.save_settings(s)
        self.assertTrue(migrate_defaults(st))
        self.assertEqual(st.load_settings()["secure_screen"], "off")
        s = st.load_settings()
        s["secure_screen"] = "sensitive"                    # người dùng tự chọn lại sau đó: KHÔNG bị đổi nữa
        st.save_settings(s)
        self.assertFalse(migrate_defaults(st))
        self.assertEqual(st.load_settings()["secure_screen"], "sensitive")
        d2 = tempfile.mkdtemp()
        st2 = Store(d2)
        s = st2.load_settings()
        s["secure_screen"] = "always"
        st2.save_settings(s)
        self.assertFalse(migrate_defaults(st2))
        self.assertEqual(st2.load_settings()["secure_screen"], "always")


if __name__ == "__main__":
    unittest.main()
