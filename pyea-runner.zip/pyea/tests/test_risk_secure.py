"""Cảnh báo rủi ro lần đầu (và chặn LIVE khi chưa xác nhận) + FLAG_SECURE."""
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub
kivy_stub.install()

from pyea import android_native as native, risk                    # noqa: E402
from test_ui_smoke import make_app, press, texts                    # noqa: E402


class TestRiskLogic(unittest.TestCase):
    def test_needed_until_acknowledged_and_again_on_new_version(self):
        p = {}
        self.assertTrue(risk.needed(p))
        risk.acknowledge(p)
        self.assertFalse(risk.needed(p))
        self.assertIn("risk_ack_at", p)
        self.assertTrue(risk.needed(p, version=risk.RISK_VERSION + 1))
        self.assertTrue(risk.needed({"risk_ack": "hỏng"}))

    def test_text_covers_the_pdf_points(self):
        for kw in ("KHÔNG phải lời khuyên", "MẤT TOÀN BỘ", "backtest", "AI", "rút tiền", "trách nhiệm"):
            self.assertIn(kw, risk.RISK_TEXT)


class TestRiskUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_first_run_shows_disclaimer_once(self):
        app = make_app()
        self.assertTrue(app.risk_needed())
        app._after_start(0)
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("lời khuyên đầu tư", texts(pop.content))
        press(pop.content, "Tôi hiểu và đồng ý")
        self.assertFalse(app.risk_needed())
        self.assertFalse(app.store.load_prefs().get("risk_ack", 0) < risk.RISK_VERSION)
        from pyea import legal
        pr = app.store.load_prefs()
        legal.acknowledge(pr)                                            # điều khoản lần đầu (1.9.14) cũng đã đồng ý
        app.store.save_prefs(pr)
        n = len(kivy_stub.OPEN_POPUPS)
        app._after_start(0)
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n)                  # đã xác nhận: không hỏi lại

    def test_closing_without_ack_does_not_count(self):
        app = make_app()
        app.risk_dialog()
        self.assertTrue(app.risk_needed())

    def test_live_start_is_blocked_until_acknowledged_then_continues(self):
        app = make_app()
        g = app.settings_tab.gform.ctrl
        g["exchange"].text, g["mode"].text, g["live_confirm"].active = "binance_spot", "live", True
        app.start_session()
        self.assertFalse(app.is_connected())
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("lời khuyên đầu tư", texts(pop.content))
        press(pop.content, "Tôi hiểu và đồng ý")
        self.assertTrue(any("GIAO DỊCH TIỀN THẬT" in str(getattr(p, "title", "")) for p in kivy_stub.OPEN_POPUPS))
        self.assertFalse(app.is_connected())                              # vẫn chờ bấm «Kết nối LIVE»

    def test_paper_start_does_not_need_ack(self):
        app = make_app()
        app.start_session()
        self.assertTrue(app.is_connected())
        app.stop_session()


class TestSecureFlag(unittest.TestCase):
    def setUp(self):
        self.calls = []
        win = types.SimpleNamespace(addFlags=lambda f: self.calls.append(("add", f)), clearFlags=lambda f: self.calls.append(("clear", f)))
        act = types.SimpleNamespace(getWindow=lambda: win)
        self._mods = {k: sys.modules.get(k) for k in ("jnius", "android", "android.runnable")}
        sys.modules["jnius"] = types.SimpleNamespace(autoclass=lambda name: types.SimpleNamespace(mActivity=act))
        sys.modules["android"] = types.ModuleType("android")
        sys.modules["android.runnable"] = types.SimpleNamespace(run_on_ui_thread=lambda f: f)
        self._was = native.IS_ANDROID
        native.IS_ANDROID = True
        native._secure_state["on"] = None

    def tearDown(self):
        native.IS_ANDROID = self._was
        native._secure_state["on"] = None
        for k, v in self._mods.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def test_set_secure_adds_and_clears_flag_only_on_change(self):
        self.assertTrue(native.set_secure(True))
        self.assertTrue(native.set_secure(True))                          # không gọi lại
        self.assertTrue(native.set_secure(False))
        self.assertEqual(self.calls, [("add", 0x2000), ("clear", 0x2000)])

    def test_not_android_is_a_noop(self):
        native.IS_ANDROID = False
        self.assertFalse(native.set_secure(True))
        self.assertEqual(self.calls, [])

    def test_ui_follows_option_and_current_tab(self):
        app = make_app()
        rec = []
        orig = native.set_secure
        native.set_secure = lambda on: rec.append(on) or True
        try:
            app.settings["secure_screen"] = "sensitive"
            self.assertFalse(app.want_secure())
            app.root_panel.current_tab = app.tabs["settings"]
            self.assertTrue(app.want_secure())
            app.settings["secure_screen"] = "off"
            self.assertFalse(app.want_secure())
            app.settings["secure_screen"] = "always"
            app.root_panel.current_tab = app.tabs["market"]
            self.assertTrue(app.want_secure())
            app.apply_secure()
            self.assertEqual(rec[-1], True)
        finally:
            native.set_secure = orig


if __name__ == "__main__":
    unittest.main()
