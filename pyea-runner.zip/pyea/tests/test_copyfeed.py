"""Copy trading: chữ ký, tươi/cũ/phát lại, logic plan, lõi chủ/theo với api giả, transport file + HTTP, bot mẫu nạp được."""
import json
import os
import sys
import tempfile
import threading
import unittest
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import copyfeed as cf

SECRET = "khoa-chung-rat-dai"
NOW = 1_800_000_000.0


def doc(positions, seq=1, t=NOW, secret=SECRET, name="m"):
    return json.dumps(cf.sign({"v": 1, "master": name, "seq": seq, "t": t, "positions": positions}, secret)).encode()


def P(i, side="buy", vol=1.0, sym="BTCUSDT", sl=0.0, tp=0.0):
    return {"id": i, "symbol": sym, "side": side, "volume": vol, "sl": sl, "tp": tp, "open_price": 100.0}


@dataclass
class FPos:
    id: int
    side: str
    volume: float
    comment: str = ""
    symbol: str = "BTCUSDT"
    sl: float = 0.0
    tp: float = 0.0
    open_price: float = 100.0


class FakeApi:
    symbol = "BTCUSDT"

    def __init__(self):
        self.pos, self.n, self.calls = [], 100, []

    def positions(self, side=None):
        return list(self.pos)

    def _open(self, side, vol, sl, tp, comment, **kw):
        self.n += 1
        self.pos.append(FPos(self.n, side, vol, comment, sl=sl, tp=tp))
        self.calls.append((side, vol, sl, tp, comment))
        return True

    def buy(self, vol, sl=0.0, tp=0.0, comment="", **kw):
        return self._open("buy", vol, sl, tp, comment)

    def sell(self, vol, sl=0.0, tp=0.0, comment="", **kw):
        return self._open("sell", vol, sl, tp, comment)

    def close(self, pid, **kw):
        self.pos = [p for p in self.pos if p.id != pid]
        self.calls.append(("close", pid))
        return True


class TestSignature(unittest.TestCase):
    def test_verify_ok_tamper_wrong_secret_stale_replay_future(self):
        d = cf.verify(doc([P(1)]), SECRET, 30, NOW + 5)
        self.assertEqual(d["positions"][0]["id"], 1)
        t = json.loads(doc([P(1)]))
        t["positions"][0]["volume"] = 99.0
        with self.assertRaisesRegex(cf.FeedError, "KHÔNG hợp lệ"):
            cf.verify(json.dumps(t), SECRET, 30, NOW)
        with self.assertRaisesRegex(cf.FeedError, "KHÔNG hợp lệ"):
            cf.verify(doc([P(1)]), "khoa-khac", 30, NOW)
        with self.assertRaisesRegex(cf.FeedError, "CŨ"):
            cf.verify(doc([P(1)]), SECRET, 30, NOW + 31)
        with self.assertRaisesRegex(cf.FeedError, "lùi"):
            cf.verify(doc([P(1)], seq=3), SECRET, 30, NOW, last_seq=5)
        with self.assertRaisesRegex(cf.FeedError, "tương lai"):
            cf.verify(doc([P(1)], t=NOW + 500), SECRET, 30, NOW)
        for bad in (b"xx", b"{}", json.dumps(cf.sign({"v": 1, "master": "m", "seq": 1, "t": NOW, "positions": [{"id": 1}]}, SECRET)).encode()):
            with self.assertRaises(cf.FeedError):
                cf.verify(bad, SECRET, 30, NOW)
        with self.assertRaises(cf.FeedError):
            cf.sign({}, "")


class TestPlan(unittest.TestCase):
    def test_open_close_flip_filter_ratio(self):
        mp = [P(1, "buy", 2.0, sl=90, tp=120), P(2, "sell", 1.0, sym="ETHUSDT"), P(3, "sell", 1.0)]
        r = cf.plan(mp, {}, "BTCUSDT", 0.5)
        self.assertEqual([(o["mid"], o["side"], o["volume"], o["sl"], o["tp"]) for o in r["open"]], [("1", "buy", 1.0, 90.0, 120.0), ("3", "sell", 0.5, 0.0, 0.0)])
        self.assertEqual(r["close"], [])
        r = cf.plan([P(1, "sell", 2.0)], {"1": (11, "buy")}, "BTCUSDT", 1.0)                       # chủ đảo chiều
        self.assertEqual(r["close"], [11])
        self.assertEqual(r["open"][0]["side"], "sell")
        r = cf.plan([], {"1": (11, "buy")}, "BTCUSDT", 1.0)
        self.assertEqual((r["close"], r["open"]), ([11], []))
        r = cf.plan([P(1)], {"1": (11, "buy")}, "BTCUSDT", 1.0)                                      # đã sao chép: không làm gì
        self.assertEqual((r["close"], r["open"]), ([], []))
        self.assertEqual(cf.plan([P(1, sl=5)], {}, "BTCUSDT", 1.0, copy_sl_tp=False)["open"][0]["sl"], 0.0)
        self.assertEqual(cf.plan([P(1, sym="XBTUSD")], {}, "BTCUSDT", 1.0, master_symbol="XBTUSD")["open"][0]["mid"], "1")
        self.assertEqual(cf.plan([P(1)], {}, "BTCUSDT", 0.0)["open"], [])


class TestCores(unittest.TestCase):
    def test_follower_full_lifecycle_with_restart_safe_mapping(self):
        api = FakeApi()
        f = cf.FollowerCore(api, SECRET, 0.5, 30, clock=lambda: NOW)
        r = f.step(doc([P(1, "buy", 2.0)], seq=1))                                                   # có sẵn trước khi theo -> bỏ qua
        self.assertEqual((r["opened"], r["closed"], api.calls), (0, 0, []))
        r = f.step(doc([P(1, "buy", 2.0), P(2, "sell", 4.0, sl=110)], seq=2))
        self.assertEqual((r["opened"], api.calls[-1]), (1, ("sell", 2.0, 110.0, 0.0, "cp:2")))
        f2 = cf.FollowerCore(api, SECRET, 0.5, 30, clock=lambda: NOW)                                 # khởi động lại: đọc ánh xạ từ comment
        r = f2.step(doc([P(1, "buy", 2.0), P(2, "sell", 4.0)], seq=3))
        self.assertEqual((r["opened"], r["closed"]), (0, 0))
        r = f2.step(doc([P(1, "buy", 2.0)], seq=4))                                                   # chủ đóng #2
        self.assertEqual(r["closed"], 1)
        self.assertEqual(api.positions(), [])

    def test_follower_ignores_bad_feed_and_does_not_touch_positions(self):
        api = FakeApi()
        api.pos = [FPos(5, "buy", 1.0, "cp:9")]
        f = cf.FollowerCore(api, SECRET, 1.0, 30, clock=lambda: NOW)
        for raw in (doc([], secret="sai"), doc([], t=NOW - 100), b"rac"):
            self.assertIsNotNone(f.step(raw)["error"])
        self.assertEqual(len(api.pos), 1)                                                             # tín hiệu xấu/cũ KHÔNG đóng lệnh

    def test_master_publishes_on_change_and_heartbeat(self):
        api = FakeApi()
        sent, t = [], [NOW]
        m = cf.MasterCore(api, "x", SECRET, "m", heartbeat=10, writer=lambda loc, data, u, p: sent.append(data), clock=lambda: t[0])
        self.assertTrue(m.publish())
        self.assertFalse(m.publish())
        t[0] += 11
        self.assertTrue(m.publish())                                                                  # nhịp tim
        api.pos.append(FPos(7, "buy", 1.0))
        self.assertTrue(m.publish())                                                                  # vị thế đổi
        d = cf.verify(sent[-1], SECRET, 30, t[0])
        self.assertEqual((d["seq"], d["positions"][0]["id"]), (3, 7))


class TestTransport(unittest.TestCase):
    def test_file_and_http(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        p = os.path.join(t.name, "feed.json")
        cf.write(p, b"abc")
        self.assertEqual(cf.read(p), b"abc")
        store = {}

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_PUT(self):
                store["auth"] = self.headers.get("Authorization")
                store["b"] = self.rfile.read(int(self.headers["Content-Length"]))
                self.send_response(201)
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Length", str(len(store["b"])))
                self.end_headers()
                self.wfile.write(store["b"])
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.addCleanup(srv.server_close)
        self.addCleanup(srv.shutdown)
        url = "http://127.0.0.1:%d/f" % srv.server_address[1]
        cf.write(url, b"xyz", "u", "p")
        self.assertTrue(store["auth"].startswith("Basic "))
        self.assertEqual(cf.read(url), b"xyz")
        with self.assertRaises(cf.FeedError):
            cf.read("http://example.com/f")


class TestExampleBots(unittest.TestCase):
    def test_examples_compile_declare_permission_and_have_api(self):
        from pyea.codeedit import check_bot_code
        from pyea.perms import parse_declared
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pyea", "examples")
        for n in ("copy_master.py.txt", "copy_follower.py.txt"):
            src = open(os.path.join(base, n), encoding="utf-8").read()
            self.assertTrue(check_bot_code(src)[0], n)
            self.assertEqual(parse_declared(src)["network"], ["feed.example.com"])

    def test_follower_bot_loads_in_sandbox_loader(self):
        from pyea.loader import load_bot_class
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pyea", "examples")
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        for n in ("copy_master", "copy_follower"):
            p = os.path.join(t.name, n + ".py")
            open(p, "w", encoding="utf-8").write(open(os.path.join(base, n + ".py.txt"), encoding="utf-8").read())
            cls, _mod = load_bot_class(p)
            self.assertTrue(hasattr(cls, "on_timer"))


class TestEngineEndToEnd(unittest.TestCase):
    def test_follower_bot_copies_through_real_engine_backtest(self):
        import time
        from pyea.backtest import run_backtest
        from pyea.sdk import Candle
        from pyea.settings import default_settings
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pyea", "examples")
        bot = os.path.join(t.name, "f.py")
        open(bot, "w", encoding="utf-8").write(open(os.path.join(base, "copy_follower.py.txt"), encoding="utf-8").read())
        feed = os.path.join(t.name, "feed.json")
        now = time.time()
        cf.write(feed, json.dumps(cf.sign({"v": 1, "master": "m", "seq": 1, "t": now, "positions": [P(7, "buy", 0.01)]}, SECRET)).encode())
        cs = [Candle(now - 300 * 60 + i * 60, 100, 101, 99, 100.5, 5) for i in range(300)]
        r = run_backtest(bot, {"feed": feed, "secret": SECRET, "copy_existing": True, "max_age": 1e9}, default_settings(), "BTCUSDT", "1m", cs, warmup=100)
        self.assertTrue(r.ok, r.error)
        self.assertEqual(len(r.trades), 1)
        self.assertEqual(r.trades[0].side, "buy")
        # tín hiệu sai khoá chung -> không mở lệnh nào
        r2 = run_backtest(bot, {"feed": feed, "secret": "sai", "copy_existing": True, "max_age": 1e9}, default_settings(), "BTCUSDT", "1m", cs, warmup=100)
        self.assertEqual(len(r2.trades), 0)


if __name__ == "__main__":
    unittest.main()
