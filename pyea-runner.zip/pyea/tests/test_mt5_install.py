"""Test trình cài tự động MT5-trong-giả-lập (tools/mt5_phone/install_mt5_termux.sh + run_mt5_termux.sh) bằng LỆNH GIẢ (pkg, proot-distro, apt-get, wget, tar, box64...)
nói chuyện với MÁY CHỦ CỤC BỘ THẬT của app (pyea/mt5ea.py).
Chứng minh được: thứ tự các bước, chạy lại thì bỏ qua bước đã xong và làm tiếp bước lỗi, lỗi hiện về app đúng bước, file cấp từ app, tiến trình app đọc được,
mật khẩu chỉ ở RAM + biến mất khỏi máy sau khi EA nối, lệnh dán 1 lần chạy được.
KHÔNG chứng minh: Box64/Wine/MT5 chạy thật trên điện thoại, URL tải còn sống, mẫu câu log MT5 thật."""
import glob
import base64
import gzip
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

from fake_ea import FakeEA          # noqa: E402
from pyea import mt5ea, mt5emu      # noqa: E402

TOOLS = os.path.join(ROOT, "tools", "mt5_phone")
INSTALL = os.path.join(TOOLS, "install_mt5_termux.sh")
RUN = os.path.join(TOOLS, "run_mt5_termux.sh")
PW = "S3cret#pw-4242"

STUBS = {
    "pkg": r"""#!/bin/bash
echo "pkg $*" >> "$CALLS"
[ "${FAIL_PKG:-}" = 1 ] && { echo "pkg: mirror error" >&2; exit 100; }
cp "$LATER/proot-distro" "$LATER/wget" "$LATER/curl" "$BIN2/" ; exit 0
""",
    "apt-get": r"""#!/bin/bash
echo "apt-get $*" >> "$CALLS"
[ "${FAIL_APT:-}" = 1 ] && { echo "E: Unable to locate package" >&2; exit 100; }
case " $* " in *" install "*)
  for t in Xvfb xz gpg; do printf '#!/bin/bash\nexit 0\n' > "$BIN2/$t"; chmod +x "$BIN2/$t"; done
  case " $* " in *" box64-android "*|*" box64 "*) cp "$LATER/box64" "$BIN2/box64";; esac;;
esac
exit 0
""",
    "ps": r"""#!/bin/bash
# ps giả. FAKE_PS=busy: có tiến trình Wine con trong ${FAKE_PS_SECS:-4}s đầu (CPU tăng theo thời gian) rồi biến mất, đồng thời «tiến trình con» hoàn tất tiền tố;
# FAKE_PS=hung: luôn có, CPU KHÔNG đổi (kẹt thật). Không đặt FAKE_PS: không có tiến trình Wine nào.
mode="${FAKE_PS:-}"; [ -n "$mode" ] || exit 0
f="$T/ps_start"; [ -f "$f" ] || date +%s > "$f"
el=$(( $(date +%s) - $(cat "$f") ))
case "$mode" in
  busy)
    if [ "$el" -lt "${FAKE_PS_SECS:-4}" ]; then
      printf ' 210     1 Sl   %s  30000 box64 /root/wine64/bin/wineserver\n' "$el"
      printf ' 215   210 Sl   %s  90000 box64 /root/wine64/bin/wine64 C:\\windows\\system32\\wineboot.exe --init\n' "$(( el * 7 ))"
    else
      d="$WINEPREFIX/drive_c/windows/system32"; mkdir -p "$d"; echo reg > "$WINEPREFIX/system.reg"; echo reg > "$WINEPREFIX/user.reg"; echo dll > "$d/kernel32.dll"; echo dll > "$d/ntdll.dll"
    fi;;
  hung)
    printf ' 210     1 Sl   12  30000 box64 /root/wine64/bin/wineserver\n'
    printf ' 215   210 Sl   40  90000 box64 /root/wine64/bin/wine64 C:\\windows\\system32\\wineboot.exe --init\n';;
esac
exit 0
""",
    "tar": r"""#!/bin/bash
echo "tar $*" >> "$CALLS"
[ "${FAIL_TAR:-}" = 1 ] && { echo "tar: unexpected EOF" >&2; exit 2; }
d=""; while [ $# -gt 0 ]; do [ "$1" = -C ] && d="$2"; shift; done
mkdir -p "$d/bin"; printf '#!/bin/true\n' > "$d/bin/wine64"; printf '#!/bin/true\n' > "$d/bin/wineserver"; exit 0
""",
    "termux-wake-lock": "#!/bin/bash\necho wakelock >> \"$CALLS\"\nexit 0\n",
}
LATER = {
    "curl": "#!/bin/bash\nexit 0\n",
    "proot-distro": r"""#!/bin/bash
echo "proot-distro $*" >> "$CALLS"
case "$1" in
  install) mkdir -p "$PYEA_ROOTFS/root" "$PYEA_ROOTFS/bin"; touch "$PYEA_ROOTFS/bin/bash"; exit 0;;
  login) shift; while [ $# -gt 0 ] && [ "$1" != -- ]; do shift; done; shift; exec "$@";;
esac
exit 1
""",
    "wget": r"""#!/bin/bash
out=""; url=""; cont=0
while [ $# -gt 0 ]; do case "$1" in -O) out="$2"; shift;; -c) cont=1;; http*) url="$1";; esac; shift; done
echo "wget $url -> $out" >> "$CALLS"
if [ -n "${FAIL_WGET:-}" ]; then case "$url" in *"$FAIL_WGET"*) echo "wget: unable to resolve host" >&2; exit 4;; esac; fi
case "$out" in /etc/*) out="$FAKE_ETC${out#/etc}"; mkdir -p "$(dirname "$out")";; esac
src="$T/wget_src.$$"
case "$url" in *.exe*) if [ -f "$T/fake.exe" ]; then cp "$T/fake.exe" "$src"; else printf 'MZ\220\000fakeexe %s' "$url" > "$src"; fi;; *) echo "data $url" > "$src";; esac
# như `wget -c` THẬT (đã thử): có sẵn tệp -> chỉ xin phần còn thiếu và NỐI ĐUÔI; tệp cũ đã đủ hoặc dài hơn thì giữ nguyên, không tải lại
if [ "$cont" = 1 ] && [ -s "$out" ]; then
  cur=$(stat -c %s "$out"); nw=$(stat -c %s "$src"); [ "$cur" -lt "$nw" ] && tail -c +$((cur+1)) "$src" >> "$out"
else cp "$src" "$out"; fi
rm -f "$src"
exit 0
""",
    "box64": r"""#!/bin/bash
echo "box64 $*" >> "$CALLS"
if [ "$1" = --version ]; then echo "Box64 arm64 v0.3.8 fake"; exit 0; fi
prog="$1"; shift
case "$prog" in
  wine64)
    case "$1" in
      --version)
        if [ -n "${FAKE_WINE_VERSION_BAD:-}" ] && case "$(cat "$WINE_DIR/.pyea_variant" 2>/dev/null)" in *"-$FAKE_WINE_VERSION_BAD") true;; *) false;; esac; then echo "wine: /lib/x86_64-linux-gnu/libc.so.6: version GLIBC_2.38 not found" >&2; exit 127; fi
        echo "wine-9.7"; exit 0;;
      wineboot)
        case "${WINEDEBUG:-}" in *warn+virtual*) echo "trace" >> "$T/wineboot_trace_runs";; *) echo "wineboot" >> "$T/wineboot_runs"; echo "LD_PRELOAD=${LD_PRELOAD:-}" >> "$T/preload_seen";; esac   # lần chạy ngắn của wine_diag (kênh virtual) đếm riêng
        echo "WINEDLLOVERRIDES=${WINEDLLOVERRIDES:-}" >> "$T/overrides_seen"
        mkdir -p "$WINEPREFIX/drive_c/windows/system32"
        case "${FAKE_WINEBOOT:-}" in timeout|timeout_files)   # đúng triệu chứng log thật lần 5: wineboot con kẹt (hộp thoại Mono/Gecko), tiến trình chính bỏ chờ sau 300 s rồi chết
          echo "wine: created the configuration directory '$WINEPREFIX'"
          echo '0001.100:0024:trace:loaddll:build_module Loaded L"C:\\windows\\system32\\wineboot.exe" at 00007FF6: builtin'
          echo '0003.200:004c:trace:loaddll:build_module Loaded L"C:\\windows\\system32\\appwiz.cpl" at 00007FF7: builtin'
          echo '0003.300:004c:trace:process:CreateProcessInternalW app L"C:\\windows\\system32\\rundll32.exe" cmdline L"rundll32 appwiz.cpl,install_addon"'
          echo "004c:err:ole:start_rpcss Failed to open RpcSs service"
          echo "0024:err:environ:run_wineboot boot event wait timed out"
          echo "wine: could not load kernel32.dll, status c0000135"
          echo reg > "$WINEPREFIX/system.reg"
          if [ "$FAKE_WINEBOOT" = timeout_files ]; then   # đúng máy thật: đủ file mà wineboot vẫn không xong
            echo reg > "$WINEPREFIX/user.reg"; echo dll > "$WINEPREFIX/drive_c/windows/system32/kernel32.dll"; echo dll > "$WINEPREFIX/drive_c/windows/system32/ntdll.dll"
          fi
          exit 1;;
        esac
        if [ -n "${FAKE_EXEC_BAD:-}" ]; then   # đúng log thật thứ hai (Cat S52, Wine 10.12): mprotect(PROT_EXEC) bị từ chối; có lớp đệm thì qua (always = vẫn lỗi dù có lớp đệm)
          case "${LD_PRELOAD:-}" in *pyea_noexec.so*) [ "$FAKE_EXEC_BAD" = always ] && pre=bad || pre=good;; *) pre=bad;; esac
          if [ "$pre" = bad ]; then
            echo "wine: created the configuration directory '$WINEPREFIX'"
            echo "002c:err:virtual:map_image_into_view failed to set 60000020 protection on L\"\\\\??\\\\C:\\\\windows\\\\system32\\\\ntdll.dll\" section .text, noexec filesystem?"
            echo "002c:err:virtual:virtual_setup_exception stack overflow 1344 bytes addr 0x7ffff3fa8c stack 0x7fff0ac0 (0x7fff0000-0x7fff1000-0x801f0000)"
            exit 1
          fi
        fi
        for noisy in ${FAKE_ADDR_NOISY:-}; do  # đúng log thật v12 (Wine 10.12 sau khi 11.19 hỏng): in lỗi vùng nhớ ảo, thoát mã 1, NHƯNG tiền tố đã dựng đủ file hệ thống
          case "$(cat "$WINE_DIR/.pyea_variant" 2>/dev/null)" in *"-$noisy")
            echo "wine: created the configuration directory '$WINEPREFIX'"
            echo "002c:err:virtual:map_fixed_area out of memory for 0x6ffffff40000-0x6fffffff0000"
            echo reg > "$WINEPREFIX/system.reg"; echo reg > "$WINEPREFIX/user.reg"
            echo dll > "$WINEPREFIX/drive_c/windows/system32/kernel32.dll"; echo dll > "$WINEPREFIX/drive_c/windows/system32/ntdll.dll"
            exit 1;;
          esac
        done
        for bad in ${FAKE_ADDR_BAD:-}; do      # đúng chuỗi lỗi thật trên Cat S52 (Android 10, nhân 4.9 - không gian địa chỉ 39-bit)
          case "$(cat "$WINE_DIR/.pyea_variant" 2>/dev/null)" in *"-$bad")
            echo "wine: created the configuration directory '$WINEPREFIX'"
            echo "002c:err:virtual:map_fixed_area out of memory for 0x6ffffff40000-0x6fffffff0000"
            echo "002c:err:virtual:try_map_free_area mmap() error Cannot allocate memory, range 0x7ffffff40000-0x7fffffff0000, unix_prot 0x7."
            echo "002c:err:virtual:map_image_into_view failed to set 60500020 protection on L\"\\\\??\\\\C:\\\\windows\\\\system32\\\\ntdll.dll\" section .text, noexec filesystem?"
            echo reg > "$WINEPREFIX/system.reg"; echo reg > "$WINEPREFIX/user.reg"; exit 0;;
          esac
        done
        if [ "${FAKE_WINEBOOT:-}" = noserver ]; then    # đúng triệu chứng Wine 10.12 trên máy thật: không chạy được wineserver, tiền tố chỉ có dosdevices + drive_c
          mkdir -p "$WINEPREFIX/dosdevices"; echo "wine: could not exec wineserver"; exit 1
        fi
        if [ "${FAKE_WINEBOOT:-}" = partial ] && [ ! -f "$T/healed" ]; then   # làm dở: có system.reg nhưng thiếu DLL (đúng triệu chứng trên máy thật)
          echo reg > "$WINEPREFIX/system.reg"; exit 0
        fi
        echo reg > "$WINEPREFIX/system.reg"; echo reg > "$WINEPREFIX/user.reg"
        echo dll > "$WINEPREFIX/drive_c/windows/system32/kernel32.dll"; echo dll > "$WINEPREFIX/drive_c/windows/system32/ntdll.dll"
        case "$(cat "$WINE_DIR/.pyea_variant" 2>/dev/null)" in *wow64*) mkdir -p "$WINEPREFIX/drive_c/windows/syswow64"; echo dll > "$WINEPREFIX/drive_c/windows/syswow64/kernel32.dll";; esac
        touch "$T/healed"; exit 0;;
      reg)   # `reg add HKCU\Software\Wine /v Version /d win11` ghi vào user.reg đúng định dạng của Wine (để thử win_chosen); mọi lệnh reg đều được ghi lại
        echo "$*" >> "$T/reg_calls"
        if [ "$3" = 'HKCU\Software\Wine' ] && [ "$4" = /v ] && [ "$5" = Version ]; then
          printf 'WINE REGISTRY Version 2\n\n[Software\\\\Wine] 1700000000\n"Version"="%s"\n\n[Software\\\\Wine\\\\Other] 1700000000\n"Version"="zzz"\n' "$9" > "$WINEPREFIX/user.reg"
        fi
        exit 0;;
      winedbg)   # Box64 THẬT chặn winedbg (log v11: «winedbg detected, not launching it!») -> script không được phụ thuộc vào nó; ghi lại để test khẳng định không ai gọi
        echo "winedbg $*" >> "$T/winedbg_calls"; echo "[BOX64] winedbg detected, not launching it!"; exit 0;;
      cmd)
        if [ -z "${FAKE_CMD_FAIL:-}" ] && [ -s "$WINEPREFIX/drive_c/windows/system32/kernel32.dll" ]; then echo PYEA_PROBE_OK; exit 0; fi
        echo "wine: could not load kernel32.dll, status c0000135"; exit 1;;
      */mt5setup.exe|mt5setup.exe)
        # FAKE_K32=once|always: bộ cài in đúng lỗi thật trên máy người dùng rồi KHÔNG thoát (thật: treo ~300 s) -> script phải tự dừng sớm
        if [ "${FAKE_K32:-}" = always ] || { [ "${FAKE_K32:-}" = once ] && [ ! -f "$T/k32_failed" ]; }; then
          touch "$T/k32_failed"; echo "wine: could not load kernel32.dll, status c0000135"; exec sleep 600
        fi
        if [ "${FAKE_MT5:-}" = hang ]; then   # đúng log thật bản v8: bộ cài chạy mãi, chỉ có vài dòng vết/lỗi vô hại, không ra terminal64.exe
          echo '0001.100:0040:trace:loaddll:build_module Loaded L"C:/windows/system32/wininet.dll" at 00007FF8: builtin'
          echo '0001.150:0040:trace:loaddll:build_module Loaded L"C:/windows/system32/winhttp.dll" at 00007FF9: builtin'
          echo '0001.200:0040:err:winediag:fake_installer_hang waiting for something'
          exec sleep 600
        fi
        d="$WINEPREFIX/drive_c/Program Files/${FAKE_MT5_DIRNAME:-MetaTrader 5}"; mkdir -p "$d"
        head -c 2048 /dev/zero > "$d/terminal64.exe"; head -c 1024 /dev/zero > "$d/metaeditor64.exe"; exec sleep 600;;
      metaeditor64.exe)
        for a in "$@"; do case "$a" in /compile:*) src="${a#/compile:}";; esac; done
        src="${src#Z:}"; src="${src//\\//}"
        [ "${FAIL_COMPILE:-}" = 1 ] && { printf 'PyEABridge.mq5 : error 100: boom\nResult: 1 errors, 0 warnings\n' | iconv -f UTF-8 -t UTF-16 > "${src%.mq5}.log"; exit 0; }
        printf 'Result: 0 errors, 0 warnings\n' | iconv -f UTF-8 -t UTF-16 > "${src%.mq5}.log"; echo ex5 > "${src%.mq5}.ex5"; exit 0;;
      terminal64.exe)
        mkdir -p logs
        grep -c '^Password=' startup.ini > "$T/terminal_saw_password" 2>/dev/null
        sleep 0.5
        printf '2026.11.15 08:00:00.123\tNetwork\t'"'"'555'"'"': authorized on Demo-1 through Access (ping 12 ms)\r\n' | iconv -f UTF-8 -t UTF-16 >> logs/20261115.log
        exec sleep 600;;
    esac;;
  */wineserver|wineserver)
    echo "wineserver $*" >> "$T/wineserver_calls"
    [ "$1" = --version ] && echo "Wine 10.12 (fake wineserver)"
    exit 0;;
esac
exit 0
""",
}


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait(cond, t=25.0, step=0.1):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(step)
    return cond()


class Env:
    """Thư mục tạm giả lập Termux + Debian-bên-trong + lệnh giả."""

    def __init__(self, **extra):
        self.t = tempfile.mkdtemp(prefix="pyea_inst_")
        t = self.t
        self.home, self.rootfs = os.path.join(t, "home"), os.path.join(t, "rootfs")
        self.bin, self.bin2, self.later = os.path.join(t, "bin"), os.path.join(t, "bin2"), os.path.join(t, "later")
        for d in (self.home, self.rootfs, self.bin, self.bin2, self.later, os.path.join(t, "prefix", "bin")):
            os.makedirs(d, exist_ok=True)
        for n, body in STUBS.items():
            self._w(self.bin, n, body)
        for n, body in LATER.items():
            self._w(self.later, n, body)
        # PATH khép kín: chỉ các lệnh hệ thống mà script cần. Máy chạy test có thể đã có sẵn Xvfb/gpg/wget/curl nên nếu để PATH thật thì các bước «đã có sẵn»
        # bị bỏ qua và test không còn kiểm được việc cài.
        self.sysbin = os.path.join(t, "sysbin")
        os.makedirs(self.sysbin)
        for n in ("bash sh cat date sleep mkdir cp rm mv ln find head tail tr cut awk sed grep egrep du df wc od iconv mktemp kill timeout base64 dirname basename cmp tee "
                  "env uname pgrep pkill touch chmod ls id true false sort uniq xargs readlink realpath dd stat nohup cksum gzip tar_real").split():
            w = shutil.which(n, path="/usr/bin:/bin:/usr/local/bin:/usr/sbin:/sbin") or shutil.which(n)    # ưu tiên lệnh thật của hệ thống (môi trường phát triển có thể đặt «bảo vệ rm» lên đầu PATH)
            if w:
                os.symlink(w, os.path.join(self.sysbin, n))
        self.calls = os.path.join(t, "calls.log")
        open(self.calls, "w").close()
        self.groot = os.path.join(self.rootfs, "root")
        self.env = dict(os.environ)
        self.env.update(
            PATH=os.pathsep.join([self.bin2, self.bin, self.sysbin]), HOME=self.home, PYEA_BASE=self.home, PREFIX=os.path.join(t, "prefix"),
            T=t, CALLS=self.calls, BIN2=self.bin2, LATER=self.later, FAKE_ETC=os.path.join(t, "fake_etc"),
            PYEA_ROOTFS=self.rootfs, PYEA_GUEST_ROOT=self.groot, PYEA_HOST_ROOT=self.groot, PYEA_ARCH="aarch64", MIN_FREE_KB="1",
            HB_EVERY="1", MT5_POLL="0.2", MT5_STABLE="1", NO_XVFB="1", RETRY_SLEEP="0", SYNC_FAST="0.5", LOGIN_POLL="0.3", COMPILE_TIMEOUT="30",
            PYEA_REDO="", FAIL_PKG="", FAIL_APT="", FAIL_WGET="", FAIL_TAR="", FAIL_COMPILE="", WINE_VER="10.12")   # mặc định thật của script là 11.19; test cũ tính theo 10.12 nên ghim ở đây, test mặc định đặt WINE_VER=""
        self.env.update(extra)
        self.srv = None
        self.ea = None

    def _w(self, d, n, body):
        p = os.path.join(d, n)
        with open(p, "w") as f:
            f.write(body)
        os.chmod(p, 0o755)

    def open_app(self, **settings):
        s = {"mt5ea_port": str(free_port())}
        s.update(settings)
        upd, srv, cmd = mt5emu.prepare(s, "5550123", PW, "Demo-1")
        self.srv, self.upd, self.cmd = srv, upd, cmd
        self.env.update(PYEA_PORT=upd["mt5ea_port"], PYEA_TOKEN=upd["mt5ea_token"])
        return srv

    def run(self, redo="", timeout=120, **extra):
        env = dict(self.env, PYEA_REDO=redo, **extra)
        return subprocess.run(["bash", INSTALL], env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True, errors="replace", timeout=timeout, cwd=self.t)   # `cut -c` (locale C) có thể cắt giữa ký tự UTF-8; app cũng đọc bằng errors=replace

    def call_log(self):
        return open(self.calls, encoding="utf-8", errors="ignore").read()

    def apt_calls(self):
        """Số lần chạy «apt-get install» của GIAI ĐOẠN apt; không tính x11-utils (bước MT5 tự cài theo nhu cầu để liệt kê cửa sổ khi chẩn đoán)."""
        return sum(1 for l in self.call_log().splitlines() if "apt-get install" in l and "x11-utils" not in l)

    def stop_supervisor(self):
        pidf = os.path.join(self.home, ".pyea", "run.pid")
        try:
            pid = int(open(pidf).read().strip())
            os.kill(pid, signal.SIGTERM)
            wait(lambda: not os.path.exists("/proc/%d" % pid) or open("/proc/%d/stat" % pid).read().split()[2] == "Z", 8)
        except (OSError, ValueError):
            pass
        subprocess.run(["pkill", "-f", self.t], stdin=subprocess.DEVNULL)

    def close(self):
        if self.ea:
            self.ea.close()
        self.stop_supervisor()
        if self.srv:
            self.srv.close()
            mt5ea._SERVERS.pop(self.srv.port, None)
        shutil.rmtree(self.t, ignore_errors=True)


def tree_text(root):
    blob = []
    for d, _, fs in os.walk(root):
        for f in fs:
            try:
                blob.append(open(os.path.join(d, f), "rb").read().decode("utf-8", "ignore"))
            except OSError:
                pass
    return "\n".join(blob)


class TestInstallFlow(unittest.TestCase):
    def setUp(self):
        self.e = Env()
        self.srv = self.e.open_app()

    def tearDown(self):
        self.e.close()

    def test_full_install_login_and_password_forgotten(self):
        e, srv = self.e, self.srv
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("XONG PHẦN CÀI", r.stdout)
        p = mt5emu.progress(srv)
        states = {sid: stt for sid, _, stt, _ in p["rows"]}
        for sid in ("precheck", "termux_pkgs", "rootfs", "fetch", "apt", "box64", "wine", "prefix", "mt5", "provision", "compile", "launcher"):
            self.assertEqual(states[sid], "ok", (sid, p["rows"]))
        mt5 = os.path.join(e.groot, "mt5")
        self.assertTrue(os.path.islink(mt5))
        self.assertTrue(os.path.isfile(os.path.join(mt5, "MQL5", "Experts", "PyEABridge.mq5")))
        self.assertTrue(os.path.isfile(os.path.join(mt5, "MQL5", "Experts", "PyEABridge.ex5")))
        self.assertTrue(os.path.isfile(os.path.join(e.groot, "pyea", "pyea_relay.py")), "trình cài phải lấy relay tệp từ app (đường dự phòng khi MT5 chặn socket)")
        self.assertIn("python3", e.call_log(), "trình cài phải cài python3 cho relay")
        ini = open(os.path.join(mt5, "startup.ini"), encoding="utf-8").read()
        self.assertIn("Login=5550123", ini)
        self.assertIn("Server=Demo-1", ini)
        self.assertIn("Password=" + PW, ini)                       # lần đầu: có mật khẩu để MT5 đăng nhập + tự lưu
        self.assertIn("KeepPrivate=1", ini)
        for f in ("pyea-start-mt5.sh",):
            self.assertTrue(os.access(os.path.join(e.home, f), os.X_OK))
        self.assertTrue(os.path.isfile(os.path.join(e.home, ".termux", "boot", "pyea-mt5.sh")))
        # supervisor đã bật MT5 giả và MT5 giả thấy mật khẩu trong startup.ini
        self.assertTrue(wait(lambda: os.path.exists(os.path.join(e.t, "terminal_saw_password"))))
        self.assertEqual(open(os.path.join(e.t, "terminal_saw_password")).read().strip(), "1")
        # script báo «đăng nhập ổn» từ log Journal UTF-16 (mẫu câu theo trí nhớ)
        self.assertTrue(wait(lambda: mt5emu.progress(srv)["log_ok"]), srv.install)
        self.assertFalse(mt5emu.progress(srv)["connected"])           # chưa có EA nối -> CHƯA được coi là xong
        # EA nối vào app -> app quên mật khẩu -> startup.ini trên máy tự mất dòng Password
        self.assertEqual(srv.first_login_password(), PW)
        e.ea = FakeEA(srv.port, token=e.upd["mt5ea_token"]).start()
        self.assertTrue(wait(lambda: srv.connected))
        self.assertTrue(wait(lambda: srv.first_login_password() is None))
        self.assertTrue(wait(lambda: "Password=" not in open(os.path.join(mt5, "startup.ini"), encoding="utf-8").read(), 15), "startup.ini vẫn còn mật khẩu")
        p = mt5emu.progress(srv)
        self.assertTrue(p["connected"])
        self.assertEqual(p["pct"], 100)
        self.assertIn("ĐÃ NỐI", mt5emu.headline(p)[0])
        # mật khẩu không lọt vào nhật ký, chẩn đoán, đầu ra, cuộc gọi lệnh
        e.stop_supervisor()
        leak = tree_text(e.t) + r.stdout + r.stderr + srv.diagnostics_text()
        self.assertNotIn(PW, leak)
        self.assertNotIn(e.upd["mt5ea_token"], srv.diagnostics_text())

    def test_rerun_skips_done_stages_and_does_not_redownload(self):
        e, srv = self.e, self.srv
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        n_before = {k: e.call_log().count(k) for k in ("wineboot", "mt5setup.exe", "tar ", "proot-distro install", "pkg ")}; n_before["apt-get install"] = e.apt_calls()
        r2 = e.run()
        self.assertEqual(r2.returncode, 0, r2.stdout + r2.stderr)
        e.stop_supervisor()
        n_after = {k: e.call_log().count(k) for k in n_before if k != "apt-get install"}; n_after["apt-get install"] = e.apt_calls()
        self.assertEqual(n_before, n_after, "chạy lại không được cài lại thứ đã có")
        for sid in ("termux_pkgs", "rootfs", "apt", "box64", "wine", "prefix", "mt5", "compile"):
            self.assertEqual(srv.install[sid]["state"], "skip", (sid, srv.install[sid]))
        self.assertIn("đã có sẵn, bỏ qua", r2.stdout)

    def test_redo_forces_stage(self):
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        c0 = e.call_log().count("wineboot")
        self.assertEqual(e.run(redo="prefix").returncode, 0)
        e.stop_supervisor()
        self.assertEqual(e.call_log().count("wineboot"), c0 + 1)

    def test_failure_reports_stage_to_app_and_rerun_resumes(self):
        e, srv = self.e, self.srv
        r = e.run(FAIL_WGET="Wine-Builds")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(srv.install["wine"]["state"], "fail")
        self.assertIn("Wine", srv.install["wine"]["detail"])
        self.assertTrue(any(a.get("kind") == "install_fail" for a in srv.alerts), srv.alerts)
        p = mt5emu.progress(srv)
        self.assertEqual(p["failed"][0][0], "wine")
        self.assertIn("LỖI ở bước", mt5emu.headline(p)[0])
        self.assertNotIn("mt5", srv.install)                       # không chạy tiếp qua bước lỗi
        self.assertIn("Chạy lại CÙNG lệnh", r.stdout)
        n_apt = e.apt_calls()
        r2 = e.run()                                              # sửa mạng rồi chạy lại cùng lệnh
        self.assertEqual(r2.returncode, 0, r2.stdout + r2.stderr)
        e.stop_supervisor()
        self.assertEqual(srv.install["apt"]["state"], "skip")
        self.assertEqual(srv.install["box64"]["state"], "skip")
        self.assertEqual(srv.install["wine"]["state"], "ok")
        self.assertEqual(e.apt_calls(), n_apt, "apt không được chạy lại")

    def test_compile_error_is_reported(self):
        e, srv = self.e, self.srv
        r = e.run(FAIL_COMPILE="1")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(srv.install["compile"]["state"], "fail")
        self.assertIn("Biên dịch EA lỗi", srv.install["compile"]["detail"])

    def test_precheck_rejects_32bit_cpu_before_touching_anything(self):
        e, srv = self.e, self.srv
        r = e.run(PYEA_ARCH="armv7l")
        self.assertEqual(r.returncode, 1)
        self.assertEqual(srv.install["precheck"]["state"], "fail")
        self.assertIn("64-bit", srv.install["precheck"]["detail"])
        self.assertEqual(e.call_log().strip(), "wakelock")        # chưa gọi pkg/proot-distro...

    def test_not_enough_disk(self):
        e, srv = self.e, self.srv
        r = e.run(MIN_FREE_KB="999999999999")
        self.assertEqual(r.returncode, 1)
        self.assertIn("Còn trống", srv.install["precheck"]["detail"])

    def test_unreachable_app_fails_at_fetch_with_clear_hint(self):
        e, srv = self.e, self.srv
        r = e.run(PYEA_TOKEN="wrong-token-0000")
        self.assertEqual(r.returncode, 1)
        self.assertIn("fetch", r.stdout)
        self.assertIn("App phải đang mở", r.stdout)

    def test_custom_installer_url_is_used(self):
        e = self.e
        self.assertEqual(e.run(MT5_SETUP_URL="https://broker.example/exness5setup.exe").returncode, 0)
        e.stop_supervisor()
        self.assertIn("https://broker.example/exness5setup.exe", e.call_log())
        self.assertNotIn("download.mql5.com", e.call_log())

    # ---- ô «Link bộ cài MT5 của sàn»: mỗi link một thư mục MT5 riêng, không ghi đè nhau, đổi link không dùng nhầm bộ cài cũ ----
    GEN_URL = "https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe"
    BRK_URL = "https://broker.example/b.exe"

    def mt5_dirs(self):
        h = os.path.join(self.e.groot, ".wine-mt5", "drive_c", "pyea-mt5")
        return sorted(os.listdir(h)) if os.path.isdir(h) else []

    def link_target(self):
        return os.path.realpath(os.path.join(self.e.groot, "mt5"))

    def mark(self, d, name):
        f = os.path.join(d, "MQL5", "Files", name)
        os.makedirs(os.path.dirname(f), exist_ok=True)
        open(f, "w").write("x")
        return f

    def run_ok(self, **kw):
        r = self.e.run(**kw)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.e.stop_supervisor()
        return r

    def test_each_link_gets_its_own_mt5_folder_and_none_overwrites_another(self):
        e = self.e
        self.run_ok()                                                                  # bản chung
        gen = self.link_target()
        m_gen = self.mark(gen, "cua_ban_chung.txt")
        self.run_ok(MT5_SETUP_URL=self.BRK_URL)                                        # bộ cài của sàn CỐ TÌNH chọn trùng tên thư mục «MetaTrader 5»
        brk = self.link_target()
        self.assertNotEqual(brk, gen, "link khác phải ra thư mục khác")
        self.assertTrue(os.path.exists(m_gen), "bản của link kia phải còn nguyên, không bị ghi đè")
        self.assertEqual(len(self.mt5_dirs()), 2)
        self.assertTrue(os.path.exists(os.path.join(brk, "terminal64.exe")))
        n = e.call_log().count("mt5setup.exe")
        self.run_ok()                                                                  # bỏ trống ô link = quay lại bản chung: KHÔNG cài lại
        self.assertEqual(self.link_target(), gen)
        self.assertEqual(e.call_log().count("mt5setup.exe"), n, "quay lại link cũ không được tải/cài lại")
        self.run_ok(MT5_SETUP_URL=self.BRK_URL)
        self.assertEqual(self.link_target(), brk)
        self.assertEqual(e.call_log().count("mt5setup.exe"), n)
        self.assertEqual(len(self.mt5_dirs()), 2)

    def test_changed_link_never_reuses_the_old_download(self):
        """Lỗi thật thử bằng wget thật: `wget -c` với link KHÁC nối đuôi vào tệp tải dở (hỏng) hoặc giữ nguyên bản cũ đã đủ, và vẫn thoát mã 0 với đầu «MZ» hợp lệ."""
        e = self.e
        r = e.run(FAKE_MT5="hang", MT5_INSTALL_TIMEOUT="3", MT5_POLL="1")             # bản chung: tải xong nhưng cài lỗi
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        e.stop_supervisor()
        exe = os.path.join(e.groot, "dl", "mt5setup.exe")
        self.assertIn(b"download.mql5.com", open(exe, "rb").read())
        self.run_ok(MT5_SETUP_URL=self.BRK_URL)
        data = open(exe, "rb").read()
        self.assertIn(b"broker.example/b.exe", data)
        self.assertNotIn(b"download.mql5.com", data, "bộ cài của link cũ còn lẫn trong tệp")

    def test_install_made_before_the_registry_existed_is_adopted_not_reinstalled(self):
        e = self.e
        self.run_ok()
        n = e.call_log().count("mt5setup.exe")
        for f in glob.glob(os.path.join(e.groot, ".pyea", "mt5_dir.*")):
            os.remove(f)
        self.run_ok()
        self.assertEqual(e.call_log().count("mt5setup.exe"), n, "bản cài cũ (chưa có sổ) phải được nhận lại, không cài lại")
        self.assertEqual(len(glob.glob(os.path.join(e.groot, ".pyea", "mt5_dir.*"))), 1)
        self.assertTrue(os.path.exists(os.path.join(self.link_target(), "terminal64.exe")))

    def test_old_install_without_registry_is_moved_so_a_later_installer_cannot_overwrite_it(self):
        """Bản cài của phiên bản cũ nằm ở «Program Files/MetaTrader 5», chưa có sổ: được nhận rồi chuyển vào thư mục riêng; bộ cài của sàn chọn trùng tên thư mục cũng không đè lên nó."""
        e = self.e
        self.run_ok()
        home = os.path.join(e.groot, ".wine-mt5", "drive_c")
        old = os.path.join(home, "Program Files", "MetaTrader 5")
        os.makedirs(os.path.dirname(old), exist_ok=True)
        os.rename(self.link_target(), old)                                             # dựng lại cảnh của bản cũ: thư mục ở chỗ bộ cài chọn, chưa có sổ
        for f in glob.glob(os.path.join(e.groot, ".pyea", "mt5_dir.*")):
            os.remove(f)
        m_old = self.mark(old, "cua_ban_cu.txt")
        self.run_ok()                                                                  # nhận lại, KHÔNG cài lại
        gen = self.link_target()
        self.assertTrue(gen.startswith(os.path.join(home, "pyea-mt5")), gen)
        self.assertFalse(os.path.exists(old), "bản cũ phải được chuyển đi khỏi chỗ bộ cài hay chọn")
        self.assertTrue(os.path.exists(os.path.join(gen, "MQL5", "Files", "cua_ban_cu.txt")))
        self.run_ok(MT5_SETUP_URL=self.BRK_URL)                                        # bộ cài của sàn lại chọn đúng «Program Files/MetaTrader 5»
        self.assertTrue(os.path.exists(os.path.join(gen, "MQL5", "Files", "cua_ban_cu.txt")), "bộ cài của sàn đã ghi đè bản cũ")
        self.assertEqual(len(self.mt5_dirs()), 2)

    def test_redo_mt5_rebuilds_only_this_links_folder(self):
        self.run_ok()
        gen = self.link_target()
        m_gen = self.mark(gen, "cua_ban_chung.txt")
        self.run_ok(MT5_SETUP_URL=self.BRK_URL)
        m_brk = self.mark(self.link_target(), "cua_ban_sang.txt")
        self.run_ok(redo="mt5", MT5_SETUP_URL=self.BRK_URL)
        self.assertTrue(os.path.exists(m_gen), "làm lại MT5 của link này không được đụng thư mục của link khác")
        self.assertFalse(os.path.exists(m_brk), "làm lại phải cài sạch thư mục của chính link này")
        self.assertEqual(len(self.mt5_dirs()), 2)

    def test_start_script_is_idempotent_and_stoppable(self):
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        sh = os.path.join(e.home, "pyea-start-mt5.sh")
        out = subprocess.run(["bash", sh, "status"], env=e.env, capture_output=True, text=True, stdin=subprocess.DEVNULL)
        self.assertIn("đang chạy", out.stdout)
        out = subprocess.run(["bash", sh, "start"], env=e.env, capture_output=True, text=True, stdin=subprocess.DEVNULL)
        self.assertIn("đã đang chạy", out.stdout)
        e.stop_supervisor()


def pe_bytes(machine):
    """Tệp PE tối thiểu: «MZ», e_lfanew=128 ở offset 60, «PE\\0\\0» + Machine (0x14c = 32-bit, 0x8664 = 64-bit)."""
    b = bytearray(256)
    b[0:2] = b"MZ"
    b[60:64] = (128).to_bytes(4, "little")
    b[128:132] = b"PE\0\0"
    b[132:134] = machine.to_bytes(2, "little")
    return bytes(b)


class TestWineHeal(unittest.TestCase):
    """Lỗi thật trên máy người dùng: «wine: could not load kernel32.dll, status c0000135». Bước «Khởi tạo Wine» từng chỉ kiểm có system.reg nên
    tiền tố hỏng vẫn bị coi là «đã có sẵn» và dịch vụ cài lặp lại 14 lần. Nay: kiểm file + chạy thử cmd.exe, tự dựng lại, dừng sớm, có chẩn đoán."""

    def setUp(self):
        self.e = Env()
        self.srv = self.e.open_app()

    def tearDown(self):
        self.e.close()

    def runs(self, what="wineboot"):
        p = os.path.join(self.e.t, what + "_runs")
        return len(open(p).read().split()) if os.path.exists(p) else 0

    def put_exe(self, machine):
        with open(os.path.join(self.e.t, "fake.exe"), "wb") as f:
            f.write(pe_bytes(machine))

    def pfx(self, *a):
        return os.path.join(self.e.groot, ".wine-mt5", *a)

    def test_half_made_prefix_is_not_trusted(self):
        e, srv = self.e, self.srv
        os.makedirs(self.pfx(), exist_ok=True)
        open(self.pfx("system.reg"), "w").write("x")            # đúng trạng thái trên máy người dùng: có system.reg, thiếu DLL hệ thống
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(srv.install["prefix"]["state"], "ok", "tiền tố dở dang không được coi là «đã có sẵn»")
        self.assertEqual(self.runs(), 1)
        self.assertTrue(os.path.getsize(self.pfx("drive_c", "windows", "system32", "kernel32.dll")) > 0)

    def test_rerun_rebuilds_prefix_that_lost_kernel32(self):
        e, srv = self.e, self.srv
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        os.remove(self.pfx("drive_c", "windows", "system32", "kernel32.dll"))
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(srv.install["prefix"]["state"], "ok")
        self.assertEqual(self.runs(), 2)

    def test_rerun_keeps_healthy_prefix_without_wineboot(self):
        e, srv = self.e, self.srv
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        os.remove(os.path.join(e.groot, ".pyea", "prefix.ok"))     # mất dấu nhưng tiền tố tốt: chạy thử cmd.exe được -> giữ, không dựng lại
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        self.assertEqual(self.runs(), 1)
        self.assertTrue(os.path.exists(os.path.join(e.groot, ".pyea", "prefix.ok")))
        self.assertEqual(srv.install["prefix"]["state"], "ok")

    def test_redo_prefix_forces_rebuild(self):
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        self.assertEqual(e.run(redo="prefix").returncode, 0)
        e.stop_supervisor()
        self.assertEqual(self.runs(), 2)

    def test_kernel32_error_once_rebuilds_prefix_and_installs(self):
        e, srv = self.e, self.srv
        r = e.run(FAKE_K32="once")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("dựng lại tiền tố Wine", r.stdout)
        self.assertEqual(self.runs(), 2)                          # 1 lần ở bước prefix + 1 lần tự chữa
        self.assertEqual(srv.install["mt5"]["state"], "ok")

    def test_kernel32_error_always_stops_fast_with_diagnosis(self):
        e, srv = self.e, self.srv
        t0 = time.time()
        r = e.run(FAKE_K32="always")
        self.assertLess(time.time() - t0, 60, "phải dừng ngay khi thấy lỗi, không đợi bộ cài treo")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(srv.install["mt5"]["state"], "fail")
        d = srv.install["mt5"]["detail"]
        self.assertIn("kernel32", d)
        self.assertIn("Chẩn đoán", d)
        self.assertEqual(self.runs(), 2, "chỉ tự chữa MỘT lần rồi dừng, không lặp mãi")
        diag = open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read()
        for k in ("wine=", "loại_PE=", "system32/kernel32=", "trang_nhớ="):
            self.assertIn(k, diag)

    def test_default_wine_is_one_pinned_version(self):
        """Không đoán bản Wine theo máy: MỘT bản cố định (10.12), không tải bản nào khác."""
        e, srv = self.e, self.srv
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("/10.12/wine-10.12-amd64.tar.xz", e.call_log())
        self.assertEqual(set(re.findall(r"wine-([0-9.]+)-amd64\.tar\.xz", e.call_log())), {"10.12"})
        self.assertEqual(open(os.path.join(e.groot, "wine64", ".pyea_variant")).read().strip(), "amd64-10.12")
        self.assertEqual(self.runs(), 1)
        src = open(INSTALL, encoding="utf-8").read()
        self.assertNotIn("FALLBACK", src)
        self.assertNotIn("prefix_rebuild_fallback", src)

    def test_virtual_address_error_stops_with_clear_diagnosis_and_no_retry_chain(self):
        """Log thật: wineboot báo map_fixed_area out of memory (nhân 39-bit). Không thử-đoán bản Wine khác: dừng, nói rõ nguyên nhân, ghi chẩn đoán."""
        e, srv = self.e, self.srv
        r = e.run(FAKE_ADDR_BAD="10.12")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(srv.install["prefix"]["state"], "fail")
        d = srv.install["prefix"]["detail"]
        self.assertIn("ntdll.dll", d)
        self.assertIn("vùng nhớ ảo", d)
        self.assertEqual(self.runs(), 1, "đúng một lần wineboot, không vòng thử bản khác")
        self.assertEqual(set(re.findall(r"wine-([0-9.]+)-amd64\.tar\.xz", e.call_log())), {"10.12"}, "không tải thêm bản Wine nào")
        self.assertNotIn("mt5", srv.install)
        diag = open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read()
        self.assertIn("lỗi vùng nhớ ảo (map_fixed_area/try_map_free_area): CÓ", diag)
        self.assertIn("lỗi quyền thực thi (failed to set ... protection / noexec): CÓ", diag)    # dòng 60500020 đi kèm lỗi vùng nhớ vẫn khớp, nhưng lời giải thích chính là vùng nhớ ảo
        self.assertNotIn("KHÔNG phải lỗi 39-bit", d)
        self.assertIn("box64:", diag)

    def test_wine_version_chosen_by_user_is_used_as_is(self):
        e, srv = self.e, self.srv
        r = e.run(WINE_VER="9.7")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("/9.7/wine-9.7-amd64.tar.xz", e.call_log())
        self.assertNotIn("wine-10.12", e.call_log())
        self.assertEqual(open(os.path.join(e.groot, "wine64", ".pyea_variant")).read().strip(), "amd64-9.7")

    def test_other_prefix_errors_do_not_change_wine(self):
        e, srv = self.e, self.srv
        r = e.run(FAKE_WINEBOOT="partial")                                 # lỗi KHÁC (thiếu DLL, không phải vùng nhớ)
        self.assertEqual(r.returncode, 1)
        self.assertEqual(set(re.findall(r"wine-([0-9.]+)-amd64\.tar\.xz", e.call_log())), {"10.12"})
        self.assertEqual(srv.install["prefix"]["state"], "fail")

    def test_wine_tarball_is_kept_as_cache_and_dropped_when_corrupt(self):
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        self.assertTrue(os.path.isfile(os.path.join(e.groot, "dl", "wine-10.12-amd64.tar.xz")), "tệp tải về phải được giữ làm cache")
        e2 = Env()
        try:
            e2.open_app()
            r = e2.run(FAIL_TAR="1")                                       # giải nén lỗi (tệp cụt) -> xoá tệp cache hỏng để lần sau tải lại sạch
            self.assertEqual(r.returncode, 1)
            self.assertFalse(os.path.exists(os.path.join(e2.groot, "dl", "wine-10.12-amd64.tar.xz")))
        finally:
            e2.close()

    def test_wrappers_tell_wine_where_wineserver_and_loader_are(self):
        """Lỗi thật «wine: could not exec wineserver» (Wine 10.12): chỉ đường bằng WINESERVER/WINELOADER (wine(1)) tới script bọc `box64 ...`."""
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        wb = os.path.join(e.groot, ".pyea_bin")
        envsh = open(os.path.join(e.groot, ".pyea_env.sh"), encoding="utf-8").read()
        self.assertIn('export WINESERVER="%s/wineserver" WINELOADER="%s/wine"' % (wb, wb), envsh)
        for n, target in (("wineserver", "/wine64/bin/wineserver"), ("wine", "/wine64/bin/wine64")):
            f = os.path.join(wb, n)
            self.assertTrue(os.access(f, os.X_OK), n)
            body = open(f, encoding="utf-8").read()
            self.assertTrue(body.startswith("#!/bin/sh\n"), n)
            self.assertIn('exec box64 "%s%s" "$@"' % (e.groot, target), body)
        out = subprocess.run([os.path.join(wb, "wineserver"), "--version"], env=e.env, capture_output=True, text=True, stdin=subprocess.DEVNULL, timeout=30)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertIn("fake wineserver", out.stdout)                       # script bọc thật sự gọi được box64 + chuyển đối số

    def test_diag_reports_wineserver_state(self):
        e, srv = self.e, self.srv
        r = e.run(FAKE_K32="always")
        self.assertEqual(r.returncode, 1, r.stdout)
        diag = open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read()
        for k in ("wineboot_cuối:", "wineserver: tệp=", "wineserver --version (qua box64 trực tiếp)", "wineserver --version (qua WINESERVER)", "fake wineserver"):
            self.assertIn(k, diag)

    def test_could_not_exec_wineserver_is_named_in_the_error(self):
        e, srv = self.e, self.srv
        r = e.run(FAKE_WINEBOOT="noserver")
        self.assertEqual(r.returncode, 1, r.stdout)
        d = srv.install["prefix"]["detail"]
        self.assertIn("wineserver", d)

    # ---- lỗi thật thứ hai: «failed to set 60000020 protection ... noexec filesystem?» (mprotect PROT_EXEC bị từ chối) + lớp đệm LD_PRELOAD ----
    def put_shim(self):
        d = os.path.join(self.e.groot, "pyea")
        os.makedirs(d, exist_ok=True)
        shutil.copy(os.path.join(ROOT, "pyea", "assets", mt5ea.SHIM_ASSET), os.path.join(d, mt5ea.SHIM_GUEST_NAME))

    def preloads(self):
        p = os.path.join(self.e.t, "preload_seen")
        return open(p).read().split("\n")[:-1] if os.path.exists(p) else []

    def test_exec_denied_turns_on_shim_once_and_retries(self):
        e, srv = self.e, self.srv
        self.put_shim()
        r = e.run(FAKE_EXEC_BAD="1")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.runs(), 2, "lần 1 lỗi quyền thực thi -> bật lớp đệm -> lần 2 qua")
        pl = self.preloads()
        self.assertEqual(pl[0], "LD_PRELOAD=", "lần 1 chưa có lớp đệm (không bật trước khi có bằng chứng lỗi)")
        self.assertIn("pyea_noexec.so", pl[1])
        self.assertTrue(os.path.exists(os.path.join(e.groot, ".pyea", "shim.on")))
        wrap = open(os.path.join(e.groot, ".pyea_shim", "box64"), encoding="utf-8").read()
        self.assertTrue(wrap.startswith("#!/bin/sh\n"))
        self.assertIn('LD_PRELOAD="%s/pyea/pyea_noexec.so' % e.groot, wrap)
        self.assertIn('PYEA_SHIM_LOG="%s/.pyea/shim.log"' % e.groot, wrap)
        self.assertIn('exec "%s"' % os.path.join(e.bin2, "box64"), wrap, "bọc phải gọi box64 THẬT, không gọi lại chính nó")
        envsh = open(os.path.join(e.groot, ".pyea_env.sh"), encoding="utf-8").read()
        self.assertIn(".pyea_shim", envsh)                                 # MT5 chạy sau này (run_mt5_termux.sh nạp file này) cũng đi qua lớp đệm
        self.assertIn("PYEA_SHIM_LOG", envsh)
        log = open(os.path.join(e.groot, ".pyea", "install.log"), encoding="utf-8").read()
        self.assertIn("bật lớp đệm pyea_noexec", log)
        self.assertIn("đo quyền thực thi:", log)
        self.assertEqual(srv.install["mt5"]["state"], "ok")

    def test_shim_stays_on_for_later_runs(self):
        e = self.e
        self.put_shim()
        self.assertEqual(e.run(FAKE_EXEC_BAD="1").returncode, 0)
        e.stop_supervisor()
        n = self.runs()
        self.assertEqual(e.run(FAKE_EXEC_BAD="1", redo="prefix").returncode, 0)        # dựng lại tiền tố: lớp đệm đã bật từ trước, một lần wineboot là đủ
        e.stop_supervisor()
        self.assertEqual(self.runs(), n + 1)
        self.assertIn("pyea_noexec.so", self.preloads()[-1])

    def test_exec_denied_without_shim_file_names_the_real_cause(self):
        e, srv = self.e, self.srv
        r = e.run(FAKE_EXEC_BAD="1")
        self.assertEqual(r.returncode, 1, r.stdout)
        d = srv.install["prefix"]["detail"]
        self.assertIn("quyền thực thi", d)
        self.assertIn("KHÔNG phải lỗi 39-bit", d)
        self.assertNotIn("vùng nhớ ảo (nhân Android có thể chỉ 39-bit)", d, "không được kết luận sai là 39-bit")
        self.assertEqual(self.runs(), 1)
        diag = open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read()
        self.assertIn("lỗi quyền thực thi (failed to set ... protection / noexec): CÓ", diag)
        self.assertIn("lỗi vùng nhớ ảo (map_fixed_area/try_map_free_area): không", diag)
        self.assertIn("có_file=không", diag)
        self.assertIn("wine kênh virtual (cảnh báo):", diag)
        self.assertEqual(self.runs("wineboot_trace"), 1, "chẩn đoán chạy lại wineboot ngắn với kênh virtual đúng một lần")

    def test_exec_denied_even_with_shim_stops_after_two_tries_and_keeps_evidence(self):
        e, srv = self.e, self.srv
        self.put_shim()
        r = e.run(FAKE_EXEC_BAD="always")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(self.runs(), 2, "đúng hai lần: không lặp vô hạn")
        d = srv.install["prefix"]["detail"]
        self.assertIn("Đã bật lớp đệm", d)
        diag = open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read()
        for k in ("đang_bật=có", "wineboot_lần_1 (trước khi bật lớp đệm): ", "noexec filesystem", "shim.log (đuôi):"):
            self.assertIn(k, diag)

    def test_shim_can_be_forced_off_or_on(self):
        e = self.e
        self.put_shim()
        r = e.run(FAKE_EXEC_BAD="1", PYEA_SHIM="0")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(self.runs(), 1)
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea", "shim.on")))
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea_shim", "box64")))
        e2 = Env()
        try:
            e2.open_app()
            d = os.path.join(e2.groot, "pyea"); os.makedirs(d, exist_ok=True)
            shutil.copy(os.path.join(ROOT, "pyea", "assets", mt5ea.SHIM_ASSET), os.path.join(d, mt5ea.SHIM_GUEST_NAME))
            self.assertEqual(e2.run(FAKE_EXEC_BAD="1", PYEA_SHIM="1").returncode, 0)    # luôn bật: lần wineboot đầu đã có lớp đệm
            e2.stop_supervisor()
            p = os.path.join(e2.t, "preload_seen")
            seen = open(p).read().split("\n")[:-1]
            self.assertEqual(len(seen), 1)
            self.assertIn("pyea_noexec.so", seen[0])
        finally:
            e2.close()

    def test_healthy_machine_is_not_touched_by_shim(self):
        e = self.e
        self.put_shim()
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        self.assertEqual(self.runs(), 1)
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea", "shim.on")))
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea_shim", "box64")))
        self.assertNotIn(".pyea_shim", open(os.path.join(e.groot, ".pyea_env.sh"), encoding="utf-8").read())
        self.assertEqual(set(self.preloads()), {"LD_PRELOAD="})

    def test_address_space_error_does_not_enable_shim(self):
        """Lỗi 39-bit cũng in dòng «failed to set ... protection» nhưng lớp đệm không giúp được: không bật, không thử lại."""
        e = self.e
        self.put_shim()
        r = e.run(FAKE_ADDR_BAD="10.12")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(self.runs(), 1)
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea", "shim.on")))

    def test_wrong_architecture_shim_file_is_ignored(self):
        e = self.e
        d = os.path.join(e.groot, "pyea"); os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, mt5ea.SHIM_GUEST_NAME), "wb") as f:                   # ELF x86-64, không phải aarch64
            f.write(b"\x7fELF" + b"\x02\x01\x01" + b"\x00" * 9 + b"\x03\x00\x3e\x00" + b"\x00" * 40)
        r = e.run(FAKE_EXEC_BAD="1")
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertEqual(self.runs(), 1)
        self.assertIn("có_file=không", open(os.path.join(e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8").read())

    # ---- v8: log thật lần 5 (bản v7): wineboot chờ đúng 300 s rồi «run_wineboot boot event wait timed out» + «could not load kernel32.dll, status c0000135» ----
    def diag_text(self):
        return open(os.path.join(self.e.groot, ".pyea", "wine_diag.txt"), encoding="utf-8", errors="replace").read()

    def install_log(self):
        return open(os.path.join(self.e.groot, ".pyea", "install.log"), encoding="utf-8", errors="replace").read()

    def test_mono_gecko_dialogs_are_disabled_for_every_wine_run(self):
        """Tạo tiền tố mới trong Xvfb bật hộp thoại «cài Mono/Gecko» chờ người bấm -> wineboot đứng. Script chạy MT5 đã tắt chúng; script CÀI trước đây thì chưa."""
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        envsh = open(os.path.join(e.groot, ".pyea_env.sh"), encoding="utf-8").read()
        self.assertIn('export WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=d"', envsh)
        seen = open(os.path.join(e.t, "overrides_seen"), encoding="utf-8").read().split()
        self.assertTrue(seen)
        self.assertEqual(set(seen), {"WINEDLLOVERRIDES=mscoree,mshtml,winemenubuilder.exe=d"}, "lần wineboot nào cũng phải chạy với bản tắt Mono/Gecko")

    def test_child_still_working_is_waited_for_not_killed(self):
        """Wine bỏ chờ sau 300 s cứng nhưng wineboot con vẫn bận (máy chậm): chờ nó xong, đừng dựng lại tiền tố từ đầu."""
        e, srv = self.e, self.srv
        r = e.run(FAKE_WINEBOOT="timeout", FAKE_PS="busy", FAKE_PS_SECS="3", WINE_POLL_S="1", PS_EVERY="1")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.runs(), 1, "không được xoá và dựng lại tiền tố khi wineboot con vẫn đang làm")
        lg = self.install_log()
        self.assertIn("xem tiến trình Wine con còn làm việc không", lg)
        self.assertIn("mọi tiến trình Wine đã thoát", lg)
        self.assertEqual(srv.install["prefix"]["state"], "ok")

    def test_hung_child_stops_waiting_and_leaves_evidence(self):
        """Con kẹt thật (CPU không tăng): thôi chờ sau WINE_STALL_S, và để lại bằng chứng: mẫu CPU, chương trình đã mở, vết nạp kernel32, biến WINEDLLOVERRIDES."""
        e = self.e
        t0 = time.time()
        r = e.run(FAKE_WINEBOOT="timeout", FAKE_PS="hung", WINE_STALL_S="2", WINE_POLL_S="1", PS_EVERY="1", PREFIX_TIMEOUT="60")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertLess(time.time() - t0, 40, "phải dừng chờ sớm khi CPU đứng im, không chờ hết PREFIX_TIMEOUT")
        self.assertIn("đứng im", self.install_log())
        d = self.diag_text()
        self.assertIn("wineboot_mẫu_CPU", d)
        self.assertIn("cpu=12s", d, "mẫu tiến trình phải có số giây CPU")
        self.assertIn("appwiz.cpl×", d, "thấy chương trình trình cài Mono/Gecko được mở")
        self.assertIn("rundll32 appwiz.cpl,install_addon", d)
        self.assertIn("WINEDLLOVERRIDES=mscoree,mshtml,winemenubuilder.exe=d", d)
        self.assertIn("vết_nạp_kernel32", d)
        self.assertIn("c0000135", d.split("vết_nạp_kernel32")[1])
        self.assertIn("system32 (mẫu): kernel32.dll: không có", d)
        self.assertIn("dosdevices:", d)
        self.assertIn("Mono/Gecko", r.stdout, "thông báo lỗi phải nêu nghi vấn dựa trên bằng chứng")
        self.assertIn("300 s", r.stdout)
        out = open(os.path.join(e.groot, "dl", "wineboot.out"), encoding="utf-8").read()
        self.assertIn(":trace:loaddll:", out, "vết đầy đủ phải còn trong wineboot.out")
        self.assertNotIn(":trace:", self.install_log(), "nhật ký cài chỉ nhận dòng lỗi, không nhận dòng vết")

    def test_without_ps_command_nothing_waits_and_old_behaviour_remains(self):
        e = self.e
        t0 = time.time()
        r = e.run(FAKE_WINEBOOT="timeout")                       # ps giả không in gì = không có tiến trình Wine con
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertLess(time.time() - t0, 30)
        self.assertIn("mọi tiến trình Wine đã thoát", self.install_log())
        self.assertEqual(self.runs(), 1)

    def test_complete_prefix_with_failed_main_wineboot_lets_cmd_probe_decide(self):
        """Đúng máy thật: đủ file hệ thống mà wineboot chính vẫn chết. Trước đây kết luận «hỏng» ngay; giờ để lệnh thử cmd.exe (chạy THẬT) quyết định."""
        e = self.e
        r = e.run(FAKE_WINEBOOT="timeout_files")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("để lệnh thử cmd.exe quyết định", self.install_log())
        self.assertEqual(self.runs(), 1)

    def test_complete_prefix_but_cmd_probe_fails_is_reported_with_probe_output(self):
        e = self.e
        r = e.run(FAKE_WINEBOOT="timeout_files", FAKE_CMD_FAIL="1")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertIn("chạy thử cmd.exe lỗi", r.stdout)
        self.assertIn("could not load kernel32.dll", self.diag_text().split("lệnh_thử_cmd:")[1].split("\n")[0])

    def test_exec_denial_is_not_waited_out(self):
        """Lỗi quyền thực thi / vùng nhớ đã rõ nguyên nhân: không chờ tiến trình con, đi thẳng vào lớp đệm như cũ."""
        e = self.e
        self.put_shim()
        r = e.run(FAKE_EXEC_BAD="1", FAKE_PS="hung", WINE_STALL_S="30", WINE_POLL_S="1")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertNotIn("xem tiến trình Wine con", self.install_log())
        self.assertEqual(self.runs(), 2)

    # ---- v9: log thật lần 6 (bản v8): prefix XONG (~3 phút) nhưng bộ cài MT5 chạy 2400 s không ra terminal64.exe, không dòng lỗi nào ----
    def put_xwininfo(self):
        p = os.path.join(self.e.bin, "xwininfo")
        with open(p, "w", encoding="utf-8") as f:
            f.write("#!/bin/bash\necho '     0x200004 \"MetaTrader 5 Setup\": (\"setup.exe\" \"Wine\")  400x300+0+0  +0+0'\necho '     0x200006 (has no name): ()  1x1+0+0  +0+0'\n")
        os.chmod(p, 0o755)

    def test_installer_that_never_finishes_stops_early_with_evidence(self):
        e, srv = self.e, self.srv
        self.put_xwininfo()
        t0 = time.time()
        r = e.run(FAKE_MT5="hang", FAKE_PS="hung", MT5_STALL_S="3", MT5_CHECK_S="1", MT5_POLL="1", MT5_SAMPLE_S="1", HB_EVERY="1")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertLess(time.time() - t0, 60, "phải dừng sớm khi CPU Wine và drive_c đều đứng im, không chờ hết 2400 s")
        self.assertEqual(srv.install["mt5"]["state"], "fail")
        self.assertIn("đứng im", srv.install["mt5"]["detail"])
        self.assertEqual(self.runs(), 1, "đứng im không phải lỗi kernel32: không dựng lại tiền tố")
        d = self.diag_text()
        self.assertIn("bộ_cài_mẫu_theo_thời_gian", d)
        self.assertIn("cpu=52s", d, "mẫu phải có tổng giây CPU của tiến trình Wine")
        self.assertIn("MetaTrader 5 Setup", d, "phải liệt kê cửa sổ đang hiện trên màn hình ảo")
        self.assertNotIn("(has no name)", d.split("bộ_cài_mẫu_theo_thời_gian")[1].split("bộ_cài_12_dòng")[0])
        self.assertIn("wininet.dll×1", d)
        self.assertIn("winhttp.dll×1", d)
        self.assertIn("windows_khai_báo", d)
        out = open(os.path.join(e.groot, "dl", "mt5setup.out"), encoding="utf-8").read()
        self.assertIn(":trace:loaddll:", out, "vết đầy đủ phải còn trong mt5setup.out")
        lg = self.install_log()
        self.assertIn("err:winediag:fake_installer_hang", lg, "dòng lỗi thật vẫn phải vào nhật ký cài")
        self.assertNotIn(":trace:", lg, "nhật ký cài không nhận dòng vết")

    def test_sampler_leaves_no_orphan_process_behind(self):
        """Bộ lấy mẫu nền bị tắt khi bộ cài xong/đứng im: không được sót lệnh `sleep` mồ côi (lỗi thật gặp khi chạy bộ test: `sleep 60` sót làm test khác đếm nhầm)."""
        e = self.e
        self.put_xwininfo()
        r = e.run(FAKE_MT5="hang", FAKE_PS="hung", MT5_STALL_S="3", MT5_CHECK_S="1", MT5_POLL="1", MT5_SAMPLE_S="77", HB_EVERY="1")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        time.sleep(0.5)
        left = subprocess.run(["pgrep", "-af", "sleep 77"], capture_output=True, text=True).stdout.strip()
        self.assertEqual(left, "", "sót tiến trình `sleep 77` của bộ lấy mẫu")

    def test_busy_installer_is_not_mistaken_for_stalled(self):
        """CPU Wine đang tăng (bộ cài còn làm việc, vd giải nén bằng Box64 chậm): không được dừng vì «đứng im», chỉ dừng khi hết hạn chung."""
        e, srv = self.e, self.srv
        r = e.run(FAKE_MT5="hang", FAKE_PS="busy", FAKE_PS_SECS="30", MT5_STALL_S="3", MT5_CHECK_S="1", MT5_POLL="1", MT5_SAMPLE_S="1", MT5_INSTALL_TIMEOUT="8", HB_EVERY="1")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        d = srv.install["mt5"]["detail"]
        self.assertIn("quá 8s", d)
        self.assertNotIn("đứng im", d)

    def test_windows_11_is_set_through_the_registry_not_winecfg(self):
        r"""v9: `winecfg -v=win10` (chương trình có cửa sổ) bị «Killed» sau ~35 s trên máy thật. v11 ghi thẳng HKCU\Software\Wine\Version bằng reg.exe, mặc định win11, trước khi chạy bộ cài."""
        e = self.e
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        calls = e.call_log()
        self.assertNotIn("winecfg", calls)
        want = r"reg add HKCU\Software\Wine /v Version /t REG_SZ /d win11 /f"
        i, j = calls.find(want), calls.find(" /auto")
        self.assertGreaterEqual(i, 0, calls[-800:])
        self.assertGreaterEqual(j, 0, calls[-600:])
        self.assertLess(i, j, "phải đặt Windows TRƯỚC khi chạy bộ cài")
        self.assertIn('Windows khai báo cho tiền tố: "Version"="win11"', self.install_log(), "đọc lại từ user.reg: chỉ lấy giá trị của khoá HKCU\\Software\\Wine, không lẫn khoá con")

    def test_windows_version_can_be_overridden(self):
        e = self.e
        self.assertEqual(e.run(WIN_VER="win10").returncode, 0)
        e.stop_supervisor()
        self.assertIn(r"/v Version /t REG_SZ /d win10 /f", e.call_log())
        self.assertNotIn("/d win11", e.call_log())

    # ---- v11: log thật bản v9: mt5setup.exe hiện cửa sổ 312x102 rồi đứng im ~10 phút (CPU ~20 s, không ghi gì). Nghi: thông báo «debugger» giả của DRM MetaQuotes trên Wine >= 10.3 ----
    def stall(self, **extra):
        kw = dict(FAKE_MT5="hang", FAKE_PS="hung", MT5_STALL_S="3", MT5_PROBE_S="1", MT5_CHECK_S="1", MT5_POLL="1", MT5_SAMPLE_S="1", HB_EVERY="1")
        kw.update(extra)
        return self.e.run(**kw)

    def put_xwd(self, payload="XWDFAKE"):
        p = os.path.join(self.e.bin, "xwd")
        with open(p, "w", encoding="utf-8") as f:
            f.write("#!/bin/bash\necho \"xwd $*\" >> \"$CALLS\"\nprintf '%s' '" + payload + "'\n")
        os.chmod(p, 0o755)

    def flavor_file(self):
        return os.path.join(self.e.groot, ".pyea", "wine_flavor")

    def variant(self):
        return open(os.path.join(self.e.groot, "wine64", ".pyea_variant")).read().strip()

    def test_stall_probe_records_the_window_and_screenshot_and_never_calls_winedbg(self):
        """Log v11: «[BOX64] winedbg detected, not launching it!» - Box64 chặn winedbg. Thăm dò dựa vào tên cửa sổ X, luồng chờ và ẢNH, không dựa vào winedbg."""
        e = self.e
        self.put_xwininfo()
        self.put_xwd("XWDFAKE")
        r = self.stall()
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertFalse(os.path.exists(os.path.join(e.t, "winedbg_calls")), "không được gọi winedbg")
        self.assertNotIn("winedbg", e.call_log())
        d = self.diag_text()
        self.assertIn("bộ_cài_thăm_dò", d)
        self.assertIn("thăm dò [idle]", d)
        self.assertIn("thăm dò [stall]", d)
        self.assertIn("MetaTrader 5 Setup", d, "tên cửa sổ X phải có")
        shot = open(os.path.join(e.groot, ".pyea", "mt5_screen.b64")).read()
        self.assertEqual(gzip.decompress(base64.b64decode(shot)), b"XWDFAKE", "ảnh = xwd | gzip | base64 giải ngược được")
        self.assertNotIn(shot, d, "ảnh nằm ở tệp riêng, không làm phình wine_diag.txt")
        self.assertIn("ảnh màn hình ảo nằm cuối chẩn đoán", self.srv.install["mt5"]["detail"])
        self.assertEqual(self.variant(), "amd64-10.12", "đứng im KHÔNG tự đổi Wine (không có bằng chứng tự động để đổi)")
        self.assertFalse(os.path.exists(self.flavor_file()))

    def test_screenshot_tool_missing_or_oversized_is_recorded_not_fatal(self):
        e = self.e
        r = self.stall()                                              # không có xwd
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "mt5_screen.b64")).read().strip(), "không-có-xwd")
        self.assertIn("đứng im", self.srv.install["mt5"]["detail"])
        self.put_xwd("A" * 5000)
        self.stall(MT5_SHOT_MAX="20")
        self.assertIn("quá-lớn", open(os.path.join(e.groot, ".pyea", "mt5_screen.b64")).read())

    # ---- v12: ảnh thật từ máy (log v11) = hộp thoại «A debugger has been found running in your system» trên Wine 10.12 -> bản Wine mặc định 11.19 (có Syscall User Dispatch), tự lùi 10.12 nếu không chạy ----
    def test_default_wine_is_11_19(self):
        e = self.e
        r = e.run(WINE_VER="")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("/11.19/wine-11.19-amd64.tar.xz", e.call_log())
        self.assertNotIn("/10.12/", e.call_log())
        self.assertEqual(self.variant(), "amd64-11.19")
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea", "wine_ver")), "chưa lùi thì không có tệp chốt")

    def test_existing_10_12_wine_is_upgraded_to_the_default_on_the_next_run(self):
        e = self.e
        self.assertEqual(e.run().returncode, 0)                       # Wine 10.12 như bản v9-v11 đã cài trên máy
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-10.12")
        runs_before = self.runs()
        r = e.run(WINE_VER="")                                        # bản mới: mặc định 11.19
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-11.19")
        self.assertIn("/11.19/wine-11.19-amd64.tar.xz", e.call_log())
        self.assertEqual(self.runs(), runs_before, "tiền tố đang chạy được thì GIỮ (trong đó có thể đã có MT5 và dữ liệu của người dùng); Wine mới tự cập nhật tiền tố")
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "prefix.ok")).read().strip(), "amd64-11.19")
        self.assertIn("giữ nguyên", self.install_log())

    def test_up_to_date_wine_is_not_downloaded_again(self):
        e = self.e
        self.assertEqual(e.run(WINE_VER="").returncode, 0)
        e.stop_supervisor()
        n = e.call_log().count("/11.19/wine-11.19-amd64.tar.xz")
        runs = self.runs()
        self.assertEqual(e.run(WINE_VER="").returncode, 0)
        e.stop_supervisor()
        self.assertEqual(e.call_log().count("/11.19/wine-11.19-amd64.tar.xz"), n)
        self.assertEqual(self.runs(), runs, "không dựng lại tiền tố khi bản Wine không đổi")

    # ---- v13: máy tự tìm (nhị phân) bản Wine 11.N mới nhất chạy được ----
    def wsearch(self):
        p = os.path.join(self.e.groot, ".pyea", "wine_search")
        return dict(l.split("=", 1) for l in open(p).read().split()) if os.path.exists(p) else None

    def downloaded(self):
        """Các bản Wine đã tải, theo thứ tự lần đầu xuất hiện (cache tệp tải về nên có thể gọi wget lại cùng bản)."""
        seen = []
        for v in re.findall(r"releases/download/([0-9.]+)/wine-[0-9.]+-amd64\.tar\.xz", self.e.call_log()):
            if v not in seen:
                seen.append(v)
        return seen

    def bad_from(self, n, upto=19):
        return " ".join("11.%d" % k for k in range(n, upto + 1))

    def state_file(self, name, text):
        d = os.path.join(self.e.groot, ".pyea")
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, name), "w", encoding="utf-8").write(text)

    def test_default_wine_that_works_is_chosen_without_any_search(self):
        e = self.e
        r = e.run(WINE_VER="")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-11.19")
        self.assertEqual(self.downloaded(), ["11.19"])
        self.assertEqual(self.wsearch(), {"ok": "19", "bad": "20", "done": "1"})

    def test_bisection_finds_the_newest_working_wine(self):
        """Log thật v12: 11.19 không khởi động được trên Cat S52. Không đoán bản nào chạy được: đo. 19 hỏng -> 12 chạy -> 15 hỏng -> 13 hỏng => chốt 12 (4 lần thử, không phải 14)."""
        e = self.e
        r = e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(13))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-11.12")
        self.assertEqual(self.downloaded(), ["11.19", "11.12", "11.15", "11.13"], "chỉ 4 bản được thử, theo đúng thứ tự chia đôi")
        self.assertEqual(self.wsearch(), {"ok": "12", "bad": "13", "done": "1"})
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "wine_ver")).read().strip(), "11.12")
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "prefix.ok")).read().strip(), "amd64-11.12", "tiền tố cuối cùng là của bản đã chốt")
        why = open(os.path.join(e.groot, ".pyea", "wine_fallback.txt"), encoding="utf-8").read()
        for v in ("11.19:", "11.15:", "11.13:"):
            self.assertIn(v, why)
        self.assertIn("vùng nhớ ảo", why, "lý do (lỗi thật) phải được giữ lại")
        self.assertEqual(self.runs(), 5, "19, 12, 15, 13, rồi dựng lại tiền tố cho 12 đã chốt")
        # lần chạy sau: dùng thẳng bản đã chốt, không tải, không thử lại, không dựng lại tiền tố
        calls, runs = e.call_log().count("releases/download/"), self.runs()
        self.assertEqual(e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(13)).returncode, 0)
        e.stop_supervisor()
        self.assertEqual(e.call_log().count("releases/download/"), calls)
        self.assertEqual(self.runs(), runs)
        self.assertEqual(self.variant(), "amd64-11.12")

    def test_when_nothing_from_11_6_works_the_search_ends_on_10_12(self):
        e = self.e
        r = e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(6))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-10.12")
        self.assertEqual(self.downloaded(), ["11.19", "11.12", "11.8", "11.6", "10.12"])
        self.assertEqual(self.wsearch(), {"ok": "5", "bad": "6", "done": "1"})
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "wine_ver")).read().strip(), "10.12")

    def test_wine_that_cannot_even_print_its_version_is_skipped_too(self):
        e = self.e
        r = e.run(WINE_VER="", FAKE_WINE_VERSION_BAD="11.19")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-11.18", "chỉ 11.19 hỏng: các bản thấp hơn chạy được -> chốt bản MỚI NHẤT trong số chạy được")
        self.assertEqual(self.wsearch(), {"ok": "18", "bad": "19", "done": "1"})
        self.assertIn("GLIBC", open(os.path.join(e.groot, ".pyea", "wine_fallback.txt"), encoding="utf-8").read() + self.install_log())

    def test_search_state_and_failed_versions_are_in_the_diagnostics(self):
        r = self.stall(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(13))          # tìm xong, rồi bộ cài đứng im
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        d = self.diag_text()
        self.assertIn("wine_tìm: chạy_được_tới=11.12 hỏng_từ=11.13 chốt=có", d)
        tail = d.split("wine_đã_hỏng")[1][:1500]
        self.assertIn("11.19:", tail)
        self.assertIn("vùng nhớ ảo", tail)
        self.assertIn("mặc_định=11.19 chốt=11.12", d)

    def test_users_own_wine_choice_is_never_searched(self):
        e = self.e
        r = e.run(WINE_VER="11.19", FAKE_ADDR_BAD="11.19")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertEqual(self.variant(), "amd64-11.19")
        self.assertEqual(self.downloaded(), ["11.19"])
        self.assertIsNone(self.wsearch())
        self.assertFalse(os.path.exists(os.path.join(e.groot, ".pyea", "wine_ver")))

    def test_custom_wine_url_is_never_searched(self):
        e = self.e
        r = e.run(WINE_VER="", WINE_URL="https://example.invalid/my-wine.tar.xz", FAKE_ADDR_BAD="11.19 10.12")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        self.assertNotIn("releases/download/", e.call_log())
        self.assertIsNone(self.wsearch())

    def test_if_even_10_12_fails_both_reasons_are_reported(self):
        e = self.e
        r = e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(6) + " 10.12")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        d = self.srv.install["prefix"]["detail"]
        self.assertIn("cũng không dựng được tiền tố", d)
        self.assertIn("Lỗi lúc đầu", d)

    def test_a_finished_search_is_never_repeated_even_if_the_prefix_breaks_later(self):
        """Đã chốt 11.12 mà sau đó tiền tố hỏng: báo lỗi thật, KHÔNG tìm lại (tốn thời gian, hạ bản âm thầm, ghi lý do giả). Phải chốt ở bản KHÔNG phải 10.12: nếu chốt 10.12 thì
        tìm lại cũng quay về chính nó nên không phân biệt được."""
        e = self.e
        self.state_file("wine_ver", "11.12\n")
        self.state_file("wine_search", "ok=12\nbad=13\ndone=1\n")
        r = e.run(WINE_VER="", FAKE_ADDR_BAD="11.12")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.downloaded(), ["11.12"], "không được thử bản nào khác")
        self.assertNotIn("thử Wine", self.install_log())
        self.assertNotIn("Tìm bản Wine", self.srv.install["prefix"]["detail"])
        self.assertEqual(self.wsearch(), {"ok": "12", "bad": "13", "done": "1"}, "trạng thái đã chốt không bị sửa")
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "wine_ver")).read().strip(), "11.12")

    def test_search_resumes_after_a_restart_without_repeating_what_is_known(self):
        """Dịch vụ bị tắt giữa chừng khi đang thử 11.15 (đã biết: 12 chạy được, 19 hỏng): chạy lại thì thử tiếp 11.15, KHÔNG tải lại 11.19."""
        e = self.e
        self.state_file("wine_ver", "11.15\n")
        self.state_file("wine_search", "ok=12\nbad=19\ndone=0\n")
        r = e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(13))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.downloaded(), ["11.15", "11.13", "11.12"])
        self.assertEqual(self.variant(), "amd64-11.12")
        self.assertEqual(self.wsearch(), {"ok": "12", "bad": "13", "done": "1"})

    def test_state_left_by_the_v12_fallback_does_not_block_the_search(self):
        """Máy đã cài v12: wine_ver=10.12 do «lùi» nhưng không có wine_search. Nếu giữ nó thì không bao giờ thử lại 11.N."""
        e = self.e
        self.state_file("wine_ver", "10.12\n")
        self.state_file("wine_fallback.txt", "Wine 11.19: Khởi tạo tiền tố Wine lỗi\n")
        r = e.run(WINE_VER="", FAKE_ADDR_BAD=self.bad_from(13))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.downloaded()[0], "11.19")
        self.assertEqual(self.variant(), "amd64-11.12")

    def test_search_marks_never_contradict_each_other(self):
        """Bản từng chạy được mà lần sau hỏng (hoặc ngược lại) không được để ok >= bad: sẽ làm vòng tìm kẹt."""
        e = self.e
        script = open(os.path.join(ROOT, "pyea", "assets", "install_mt5_termux.sh.txt"), encoding="utf-8").read()      # bản ASSET: bản app thật chạy
        fn = script[script.index("wine_minor_of() {"):script.index("wine_search_done() {")]
        sandbox = os.path.join(e.t, "mark_test")
        os.makedirs(sandbox, exist_ok=True)
        st = os.path.join(sandbox, "wine_search")
        open(st, "w").write("ok=12\nbad=19\ndone=0\n")
        cmd = ('WINE_SEARCH_F="%s"; WINEFB_F="%s/fb"; WINE_DRM_MIN=6; WINE_DEFAULT_VER=11.19\n%s\n'
               'wine_search_mark bad 12 x; wine_search_get ok; wine_search_get bad; '
               'wine_search_mark good 18 ; wine_search_get ok; wine_search_get bad; '
               'wine_search_mark bad 15 y; wine_search_get ok; wine_search_get bad; '
               'wine_search_mark good 19; wine_search_get ok; wine_search_get bad') % (st, sandbox, fn)
        out = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=30).stdout.split()
        # (ok,bad): 12 hỏng -> (11,12); 18 chạy -> (18,19); 15 hỏng -> (14,15); 19 chạy -> (19,20)
        self.assertEqual(out, ["11", "12", "18", "19", "14", "15", "19", "20"])

    def test_wineboot_error_text_is_not_a_verdict_when_the_prefix_is_complete_and_cmd_runs(self):
        """Log thật v12: Wine 10.12 in «map_fixed_area out of memory», thoát mã 1, nhưng tiền tố đã đủ 791 file. Bản cũ vứt tiền tố và báo «không dựng được»; nay cmd.exe quyết định."""
        e = self.e
        r = e.run(FAKE_ADDR_NOISY="10.12")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertEqual(self.variant(), "amd64-10.12")
        self.assertEqual(open(os.path.join(e.groot, ".pyea", "prefix.ok")).read().strip(), "amd64-10.12", "tiền tố được công nhận")
        self.assertEqual(self.runs(), 1, "dựng tiền tố đúng một lần (không xoá đi dựng lại)")
        self.assertIn("NHƯNG tiền tố đã đủ file hệ thống", self.install_log())

    def test_complete_prefix_but_cmd_fails_is_still_an_error_with_the_real_reason(self):
        e = self.e
        r = e.run(FAKE_ADDR_NOISY="10.12", FAKE_CMD_FAIL="1")
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
        d = self.srv.install["prefix"]["detail"]
        self.assertIn("chạy thử cmd.exe lỗi", d)
        self.assertIn("vùng nhớ ảo", d, "chữ lỗi gốc vẫn phải hiện trong chẩn đoán")

    def test_forced_staging_flavor_downloads_staging_first(self):
        e = self.e
        r = e.run(WINE_FLAVOR="staging")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("/10.12/wine-10.12-staging-amd64.tar.xz", e.call_log())
        self.assertNotIn("/10.12/wine-10.12-amd64.tar.xz", e.call_log())
        self.assertEqual(self.variant(), "staging-amd64-10.12")

    def test_stall_check_has_no_broken_pipe_even_when_sigpipe_is_ignored(self):
        """Log thật v9: «install_mt5_termux.sh: line 379: printf: write error: Broken pipe» (printf | grep -q thoát sớm). Chạy đúng các hàm đó trên dữ liệu lớn, bật «bỏ qua SIGPIPE» như khi chạy dưới Python."""
        bigf = os.path.join(self.e.t, "big.txt")
        with open(bigf, "w") as f:
            f.write("map_fixed_area out of memory\n" + ("x" * 80 + "\n") * 40000)          # ~3 MB, khớp ngay dòng đầu: grep -q sẽ thoát khi printf còn đang ghi
        script = ('trap "" PIPE; source <(grep -E "^(has_re|addr_err|exec_err)\\(\\)" "%s"); BIG=$(cat "%s"); '
                  'addr_err "$BIG" && echo ADDR_YES; exec_err "$BIG" || echo EXEC_NO; has_re "PYEA_PROBE_OK" "$BIG" || echo PROBE_NO' % (INSTALL, bigf))
        r = subprocess.run(["bash", "-c", script], capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(r.stderr, "", "không được có «Broken pipe»")
        self.assertEqual(r.stdout.split(), ["ADDR_YES", "EXEC_NO", "PROBE_NO"])

    def test_32bit_installer_switches_to_wow64_wine(self):
        e, srv = self.e, self.srv
        self.put_exe(0x14C)
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        e.stop_supervisor()
        self.assertIn("wine-10.12-amd64-wow64.tar.xz", e.call_log())              # cùng số bản với bản chính (không còn số 9.19 riêng)
        self.assertEqual(open(os.path.join(e.groot, "wine64", ".pyea_variant")).read().strip(), "amd64-wow64-10.12")
        self.assertTrue(os.path.getsize(self.pfx("drive_c", "windows", "syswow64", "kernel32.dll")) > 0)
        self.assertEqual(self.runs(), 2)
        self.assertIn("loại PE=x86", open(os.path.join(e.groot, ".pyea", "install.log"), encoding="utf-8").read())
        self.assertEqual(srv.install["mt5"]["state"], "ok")

    def test_64bit_installer_keeps_plain_wine(self):
        e = self.e
        self.put_exe(0x8664)
        self.assertEqual(e.run().returncode, 0)
        e.stop_supervisor()
        self.assertNotIn("wow64", e.call_log())
        self.assertEqual(open(os.path.join(e.groot, "wine64", ".pyea_variant")).read().strip(), "amd64-10.12")
        self.assertIn("loại PE=x64", open(os.path.join(e.groot, ".pyea", "install.log"), encoding="utf-8").read())

    def test_wow64_version_overridable(self):
        e = self.e
        self.put_exe(0x14C)
        self.assertEqual(e.run(WINE_WOW64_VER="10.1").returncode, 0)
        e.stop_supervisor()
        self.assertIn("/10.1/wine-10.1-amd64-wow64.tar.xz", e.call_log())


class TestScripts(unittest.TestCase):
    def test_syntax(self):
        for f in (INSTALL, RUN):
            self.assertEqual(subprocess.run(["bash", "-n", f]).returncode, 0, f)

    def test_common_block_identical(self):
        def blk(p):
            t = open(p, encoding="utf-8").read()
            return t[t.index("# >>> pyea-common"):t.index("# <<< pyea-common")]
        self.assertEqual(blk(INSTALL), blk(RUN))

    def test_assets_are_copies(self):
        for n in ("install_mt5_termux.sh", "run_mt5_termux.sh"):
            self.assertEqual(open(os.path.join(TOOLS, n), "rb").read(), open(os.path.join(ROOT, "pyea", "assets", n + ".txt"), "rb").read(), n)
            self.assertEqual(mt5ea.script_source(n), open(os.path.join(TOOLS, n), encoding="utf-8").read())

    def test_stage_ids_match_app_list(self):
        import re
        t = open(INSTALL, encoding="utf-8").read()
        outer = t[t.index("  outer)"):t.index("  inner)")]
        inner = t[t.index("  inner)"):]
        ids_o = re.findall(r"^\s+stage (\w+) ", outer, re.M)
        ids_i = re.findall(r"^\s+stage (\w+) ", inner, re.M)
        seq = ids_o[:4] + ids_i + ids_o[4:] + ["login"]
        self.assertEqual(seq, [s for s, _ in mt5ea.INSTALL_STAGES])

    def test_apk_ships_scripts_with_allowed_extension(self):
        spec = open(os.path.join(ROOT, "buildozer.spec"), encoding="utf-8").read()
        exts = [l for l in spec.splitlines() if l.startswith("source.include_exts")][0].split("=")[1].strip().split(",")
        self.assertIn("txt", exts)
        self.assertNotIn("sh", exts)                                # nên đóng gói dạng .sh.txt

    def test_stop_pattern_does_not_match_its_own_command_line(self):
        t = open(INSTALL, encoding="utf-8").read()
        self.assertIn('pkill -TERM -f "run_mt5_[t]ermux.sh"', t)


class TestBootstrapCommand(unittest.TestCase):
    """Lệnh dán 1 lần phải tự tải script từ app qua cổng cục bộ rồi chạy nó."""

    def setUp(self):
        self.t = tempfile.mkdtemp(prefix="pyea_boot_")
        self.srv = None

    def tearDown(self):
        if self.srv:
            self.srv.close()
            mt5ea._SERVERS.pop(self.srv.port, None)
        shutil.rmtree(self.t, ignore_errors=True)

    def test_downloads_and_runs(self):
        upd, srv, cmd = mt5emu.prepare({"mt5ea_port": str(free_port())}, "5550123", PW, "Demo-1", "https://broker.example/a.exe?x=1&y=2")
        self.srv = srv
        srv.provision["install_mt5_termux.sh"] = "#!/bin/bash\necho BOOT-OK port=$PYEA_PORT token=$PYEA_TOKEN url=$MT5_SETUP_URL\n"
        r = subprocess.run(["bash", "-c", cmd], env=dict(os.environ, HOME=self.t), capture_output=True, text=True, timeout=30, stdin=subprocess.DEVNULL)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("BOOT-OK port=%s token=%s url=https://broker.example/a.exe?x=1&y=2" % (upd["mt5ea_port"], upd["mt5ea_token"]), r.stdout)

    def test_big_real_script_survives_transfer_intact(self):
        upd, srv, cmd = mt5emu.prepare({"mt5ea_port": str(free_port())}, "5550123", PW, "Demo-1")
        self.srv = srv
        # chạy lệnh thật nhưng thay bước chạy script bằng so sánh nội dung đã tải
        probe = cmd.replace("bash ~/pyea_install.sh", "cmp ~/pyea_install.sh " + INSTALL + " && echo SAME")
        r = subprocess.run(["bash", "-c", probe], env=dict(os.environ, HOME=self.t), capture_output=True, text=True, timeout=30, stdin=subprocess.DEVNULL)
        self.assertIn("SAME", r.stdout, r.stdout + r.stderr)

    def test_app_not_listening_gives_message(self):
        cmd = mt5emu.bootstrap_command(free_port(), "tok-abcdefgh12")
        r = subprocess.run(["bash", "-c", cmd], env=dict(os.environ, HOME=self.t), capture_output=True, text=True, timeout=30, stdin=subprocess.DEVNULL)
        self.assertIn("Không nối được app PyEA", r.stdout + r.stderr)
        self.assertFalse(os.path.exists(os.path.join(self.t, "pyea_install.sh")))

    def test_wrong_token_does_not_run_stale_script(self):
        upd, srv, cmd = mt5emu.prepare({"mt5ea_port": str(free_port())}, "5550123", PW, "Demo-1")
        self.srv = srv
        open(os.path.join(self.t, "pyea_install.sh"), "w").write("echo STALE-RAN\n")
        r = subprocess.run(["bash", "-c", cmd.replace(upd["mt5ea_token"], "wrongtoken12345")], env=dict(os.environ, HOME=self.t), capture_output=True, text=True,
                           timeout=40, stdin=subprocess.DEVNULL)
        self.assertNotIn("STALE-RAN", r.stdout)
        self.assertIn("Không lấy được script", r.stdout)


if __name__ == "__main__":
    unittest.main()
