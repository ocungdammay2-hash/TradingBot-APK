"""Công cụ tự kiểm tra CHUNG chạy trên máy chủ giả của từng sàn bằng CÙNG một đoạn code (không nhánh riêng từng sàn)."""
import io
import json
import os
import sys
import unittest
from contextlib import redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    HAVE_CRYPTO = True
except Exception:                                    # noqa: BLE001
    HAVE_CRYPTO = False

from fake_exchanges import FakeBinanceX, FakeOandaX                      # noqa: E402
from pyea import exness, feeds, ratelimit, selfcheck                      # noqa: E402
from pyea.settings import clean_settings                                  # noqa: E402


def names(rows):
    return " | ".join("%s=%s" % (r["name"], r["status"]) for r in rows)


class Common:
    """Khẳng định CHUNG cho mọi sàn: không dòng LỖI, mọi bước giao dịch có mặt, vị thế về mức ban đầu."""
    expect_pending = True
    expect_protect = False

    def run_check(self, settings, **kw):
        ratelimit.reset_all()
        rows, appendix, chk = selfcheck.run(settings, poll=4.0, **kw)
        return rows, appendix, chk

    def assert_green(self, rows, need=()):
        bad = [r for r in rows if r["status"] == selfcheck.FAIL]
        self.assertEqual(bad, [], "\n" + selfcheck.format_report(rows))
        text = names(rows)
        for n in need:
            self.assertIn(n, text)

    TRADE_STEPS = ("Lệnh: mua thị trường", "Lệnh: đóng MỘT PHẦN", "Lệnh: đóng nốt", "Dọn dẹp", "history() thấy lệnh vừa chạy")


class TestExnSelfcheck(Common, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not HAVE_CRYPTO:
            raise unittest.SkipTest("cần cryptography")
        from fake_exness import FakeExness
        key = Ed25519PrivateKey.generate()
        cls.pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        cls.fake = FakeExness(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        f = self.fake
        with f.lock:
            f.positions.clear(); f.orders.clear(); f.deals.clear(); f.requests.clear()
            f.reject_next, f.account_status, f.close_volume_in = None, "active", "body"
        exness._CLIENTS.clear()
        self.s = clean_settings({"exchange": "exness", "exness_api_key": "exnsk_test", "exness_private_key": self.pem, "exness_account": "123456",
                                 "exness_host": f.base})

    def test_readonly_sends_no_orders_and_is_green(self):
        rows, _, _ = self.run_check(self.s)
        self.assert_green(rows, ("Feed: tick EURUSD", "Feed: nến 1m", "Broker: positions()", "Broker: history(since, symbols)", "Hợp đồng chữ ký broker"))
        self.assertEqual([r for r in self.fake.requests if r["method"] in ("POST", "DELETE", "PATCH")], [])

    def test_full_trade_cycle_is_green_and_leaves_no_trace(self):
        rows, _, _ = self.run_check(self.s, trade=True)
        self.assert_green(rows, self.TRADE_STEPS + ("Lệnh chờ limit", "Lệnh chờ stop"))
        self.assertEqual(self.fake.positions, {})
        self.assertEqual(self.fake.orders, {})

    def test_partial_close_bug_is_caught_end_to_end_and_cleaned_up(self):
        """Máy chủ đọc volume ở query (ta gửi body) -> đóng hết thay vì một phần: selfcheck phải báo LỖI, không để sót vị thế."""
        self.fake.close_volume_in = "query"
        rows, _, _ = self.run_check(self.s, trade=True)
        part = next(r for r in rows if r["name"].startswith("Lệnh: đóng MỘT PHẦN"))
        self.assertEqual(part["status"], selfcheck.FAIL)
        self.assertEqual(self.fake.positions, {})
        self.assertEqual(self.fake.orders, {})

    def test_close_only_account_skips_trading_instead_of_failing(self):
        self.fake.account_status = "close_only"
        rows, _, _ = self.run_check(self.s, trade=True)
        r = next(r for r in rows if r["name"] == "Giao dịch thật")
        self.assertEqual(r["status"], selfcheck.SKIP)


class TestBinanceFuturesSelfcheck(Common, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.s = clean_settings({"exchange": "binance_futures", "api_key": "key123", "api_secret": "sekret", "base_url": self.fx.base})

    def test_readonly_green(self):
        rows, _, _ = self.run_check(self.s, tfs=("1m", "5m", "2h"))
        self.assert_green(rows, ("Feed: tick BTCUSDT", "Broker: account_flags()", "Broker: history(since, symbols)"))

    def test_full_trade_cycle_including_native_protection(self):
        rows, _, _ = self.run_check(self.s, trade=True, tfs=("1m", "5m"))
        self.assert_green(rows, self.TRADE_STEPS + ("SL/TP native: đặt 2 lệnh/mức theo phong cách ladder", "SL/TP native: gỡ", "Lệnh chờ stop"))
        self.assertAlmostEqual(self.fx.fut["pos"], 0.0, 9)
        self.assertEqual([a for a in self.fx.fut["algo"].values() if a["algoStatus"] == "NEW"], [])


class TestBinanceSpotSelfcheck(Common, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.s = clean_settings({"exchange": "binance_spot", "api_key": "key123", "api_secret": "sekret", "base_url": self.fx.base})

    def test_full_trade_cycle_tolerates_coin_fee_dust(self):
        rows, _, chk = self.run_check(self.s, trade=True, tfs=("1m",))
        self.assert_green(rows, self.TRADE_STEPS + ("SL/TP native: đặt 1 lệnh/mức theo phong cách pair", "SL/TP native: gỡ"))
        self.assertEqual([c for c in self.fx.calls if c[0] == "POST" and c[1] == "/api/v3/orderList/oco"].__len__(), 1)   # MỘT lệnh OCO, không phải 2 lệnh rời
        self.assertTrue(all(l["status"] == "ALL_DONE" for l in self.fx.spot["lists"].values()))
        self.assertEqual(self.fx.locked_base(), 0.0)
        self.assertLess(self.fx.spot["bal"]["BTC"], chk.qty)                         # chỉ còn bụi
        self.assertTrue(all(o["status"] != "NEW" for o in self.fx.spot["orders"].values()))


class TestOandaSelfcheck(Common, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeOandaX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.s = clean_settings({"exchange": "oanda", "oanda_token": self.fx.TOKEN, "oanda_account": self.fx.ACC, "base_url": self.fx.base})

    def test_full_trade_cycle_including_replace_style_modify_and_protection(self):
        rows, _, _ = self.run_check(self.s, trade=True, symbol="EUR_USD", tfs=("1m", "5m"))
        self.assert_green(rows, self.TRADE_STEPS + ("SL/TP native: đặt 2 lệnh/mức theo phong cách ladder", "Lệnh chờ limit"))
        self.assertEqual(self.fx.pos, 0.0)
        self.assertEqual([o for o in self.fx.orders.values() if o["state"] == "PENDING"], [])


class TestMetaApiSelfcheck(Common, unittest.TestCase):
    """Cầu nối MT (qua MetaApi giả): cùng đoạn kiểm tra, adapter dựng sẵn."""

    @classmethod
    def setUpClass(cls):
        from fake_mt import FakeMetaApi, MtCore
        cls.core = MtCore()
        cls.api = FakeMetaApi(cls.core)

    @classmethod
    def tearDownClass(cls):
        cls.api.close()

    def setUp(self):
        from pyea.bridges import MetaApiBackend, MtBroker, MtFeed
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.api.deals_as_dict = True
        be = MetaApiBackend(self.api.TOKEN, self.api.ACC, client_url=self.api.base, data_url=self.api.base)
        self.feed, self.broker = MtFeed(be), MtBroker(be)

    def test_readonly_and_full_trade_cycle(self):
        ratelimit.reset_all()
        rows, _, _ = selfcheck.run({"exchange": "metaapi"}, trade=True, symbol="EURUSD", tfs=("1m", "5m"), poll=4.0, feed=self.feed, broker=self.broker)
        self.assert_green(rows, self.TRADE_STEPS + ("SL/TP native: đặt 1 lệnh/mức theo phong cách position", "SL/TP native: gỡ"))
        self.assertEqual(self.core.positions, {})
        self.assertEqual(self.core.orders, {})

    def test_netting_account_runs_native_protection_check_safely(self):
        ratelimit.reset_all()
        self.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_NETTING"
        try:
            rows, _, _ = selfcheck.run({"exchange": "metaapi"}, trade=True, symbol="EURUSD", tfs=("1m",), poll=4.0, feed=self.feed, broker=self.broker)
        finally:
            self.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING"
        # Netting giờ được hỗ trợ AN TOÀN (mức SL/TP chỉ gắn khi vị thế ảo là TOÀN BỘ ticket gộp; chi tiết ở protection.sync_position_levels):
        # phép tự kiểm dùng đúng MỘT vị thế nên chạy đủ hai bước thay vì bỏ qua.
        self.assert_green(rows, self.TRADE_STEPS + ("SL/TP native: đặt 1 lệnh/mức theo phong cách position", "SL/TP native: gỡ"))
        self.assertEqual(self.core.positions, {})


class TestSelfcheckMechanics(unittest.TestCase):
    def test_redaction_masks_keys_signatures_and_long_tokens(self):
        u = selfcheck.redact_url("https://x.test/a?symbol=BTC&signature=abcdef123&api_key=zzz&timestamp=5")
        self.assertIn("symbol=BTC", u)
        self.assertNotIn("abcdef123", u)
        self.assertNotIn("zzz", u)
        t = selfcheck.redact_text('{"apiKey":"SECRETVALUE","price":"1.1","token":"t0k","note":"%s"}' % ("A" * 60))
        self.assertNotIn("SECRETVALUE", t)
        self.assertNotIn("t0k", t)
        self.assertNotIn("A" * 60, t)
        self.assertIn('"price":"1.1"', t)

    def test_failure_report_includes_redacted_raw_response(self):
        c = selfcheck.Check({"exchange": "x"})
        feeds.HTTP_TAP = c._tap
        try:
            def boom():
                c._tap("GET", "https://h.test/v1/x?signature=SIG&a=1", 400, b'{"k":1}', '{"error_message":"BAD","apiKey":"K"}')
                raise RuntimeError("sàn trả lỗi")
            c.step("Bước thử", boom)
        finally:
            feeds.HTTP_TAP = None
        r = c.rows[0]
        self.assertEqual(r["status"], selfcheck.FAIL)
        txt = selfcheck.format_report(c.rows, c.appendix)
        self.assertIn("BAD", txt)
        self.assertNotIn("SIG", txt)
        self.assertNotIn('"K"', txt)
        self.assertIn("Phụ lục", txt)

    def test_template_and_settings_loading(self):
        t = selfcheck.template("exness")
        self.assertEqual(t["exchange"], "exness")
        self.assertIn("exness_private_key", t)
        self.assertNotIn("api_secret", t)
        self.assertIn("api_secret", selfcheck.template("binance_futures"))

    def test_trade_requires_explicit_confirmation(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            code = selfcheck.main(["--exchange", "exness", "--trade", "--set", "exness_api_key=k"])
        self.assertEqual(code, 2)                                                      # không tty, không --yes -> huỷ, không gửi gì
        self.assertIn("--yes", buf.getvalue())

    def test_cli_template_prints_json(self):
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.assertEqual(selfcheck.main(["--template", "oanda"]), 0)
        self.assertIn("oanda_token", json.loads(buf.getvalue()))

    def test_unbuildable_feed_is_reported_not_raised(self):
        rows, _, _ = selfcheck.run(clean_settings({"exchange": "oanda"}))
        self.assertEqual(rows[0]["status"], selfcheck.FAIL)
        self.assertIn("OANDA", rows[0]["detail"])


if __name__ == "__main__":
    unittest.main()
