"""Tương quan chỉ báo ↔ giá, tham số ↔ kết quả (corrlab) + hộp thoại trong tab Backtest."""
import os
import random
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402
from pyea import corrlab as C                            # noqa: E402


class K:
    def __init__(self, t, c):
        self.time, self.close = t, c


def walk(n=800, seed=1):
    random.seed(seed)
    p, cs = 100.0, []
    for i in range(n):
        p *= 1 + random.gauss(0, 0.01)
        cs.append(K(i * 60, p))
    return cs


class TestMath(unittest.TestCase):
    def test_spearman_basic(self):
        self.assertAlmostEqual(C.spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0)
        self.assertAlmostEqual(C.spearman([1, 2, 3, 4], [4, 3, 2, 1]), -1.0)
        self.assertIsNone(C.spearman([1, 1, 1], [1, 2, 3]))            # hằng số
        self.assertIsNone(C.spearman([1, 2], [1, 2]))                  # quá ít
        self.assertAlmostEqual(C.spearman([1, 2, 3, 4, 5], [1, 4, 9, 16, 25]), 1.0)   # đơn điệu phi tuyến

    def test_ties(self):
        r = C.spearman([1, 1, 2, 2, 3, 3], [1, 2, 3, 4, 5, 6])
        self.assertTrue(0.9 < r <= 1.0)

    def test_none_skipped(self):
        self.assertAlmostEqual(C.spearman([1, None, 3, 4], [2, 9, 6, 8]), 1.0)


class TestIndicators(unittest.TestCase):
    def test_noise_indicator_not_significant(self):
        cs = walk()
        random.seed(5)
        rows = C.indicator_vs_price(cs, {"noise": [(c.time, random.random()) for c in cs]})
        self.assertTrue(rows)
        self.assertFalse(any(r["significant"] for r in rows))

    def test_leaky_indicator_found(self):
        cs = walk()
        # chỉ báo = lợi suất 5 nến SAU (cố ý rò rỉ) -> phải bị phát hiện rất mạnh ở h=5
        lk = [(c.time, (cs[i + 5].close / c.close - 1.0) if i + 5 < len(cs) else 0.0) for i, c in enumerate(cs)]
        rows = C.indicator_vs_price(cs, {"leak": lk})
        h5 = next(r for r in rows if r["h"] == 5)
        self.assertGreater(h5["rho"], 0.9)
        self.assertTrue(h5["significant"])
        self.assertEqual(rows[0]["name"], "leak")                      # xếp theo |t| giảm dần

    def test_effective_n_discounts_overlap(self):
        cs = walk()
        rows = C.indicator_vs_price(cs, {"x": [(c.time, c.close) for c in cs]})
        r1 = next(r for r in rows if r["h"] == 1)
        r20 = next(r for r in rows if r["h"] == 20)
        self.assertLess(r20["n_eff"], r1["n_eff"] / 10)

    def test_align_no_lookahead(self):
        cs = [K(i * 60, 100.0) for i in range(40)]
        pts = [(i * 60 + 30, float(i)) for i in range(40)]            # điểm chỉ báo ở GIỮA hai nến
        col = C.align_plots(cs, {"a": pts})["a"]
        self.assertIsNone(col[0])                                      # chưa có điểm nào <= thời điểm nến 0
        self.assertEqual(col[5], 4.0)                                  # nến 5 (t=300) chỉ thấy điểm t=270 (i=4)

    def test_price_scale_normalized(self):
        cs = walk()
        ma = [(c.time, c.close * 0.99) for c in cs]
        rows = C.indicator_vs_price(cs, {"ma": ma})
        self.assertIn("close", rows[0]["note"])

    def test_redundant_pair(self):
        cs = walk()
        def ma(k):
            return [(c.time, sum(x.close for x in cs[max(0, i - k + 1):i + 1]) / min(i + 1, k)) for i, c in enumerate(cs)]
        a, b = ma(10), ma(12)
        random.seed(2)
        n = [(c.time, random.random() * 100) for c in cs]
        red = C.indicator_redundancy(cs, {"a": a, "b": b, "n": n})
        self.assertEqual({(r["a"], r["b"]) for r in red}, {("a", "b")})

    def test_short_series_ignored(self):
        cs = walk(100)
        self.assertEqual(C.indicator_vs_price(cs, {"x": [(0, 1.0), (60, 2.0)]}), [])
        self.assertIn("api.plot", C.indicator_text([], []))

    def test_text_says_no_signal(self):
        cs = walk()
        random.seed(8)
        rows = C.indicator_vs_price(cs, {"noise": [(c.time, random.random()) for c in cs]})
        self.assertIn("KHÔNG chỉ báo nào", C.indicator_text(rows, []))


class TestParams(unittest.TestCase):
    def grid(self):
        out = []
        for f in (5, 10, 15, 20):
            for s in (20, 30, 40, 50):
                out.append({"params": {"fast": f, "slow": s, "mode": "x"}, "report": {"Lợi nhuận ròng": f * 10 - s * 0.1 + (30 if f * 2 >= s else 0)}})
        return out

    def test_vs_metric(self):
        eff = C.param_effects(self.grid())
        d = {r["name"]: r["rho"] for r in eff["vs_metric"]}
        self.assertGreater(d["fast"], 0.5)
        self.assertNotIn("mode", d)                                    # không phải số
        self.assertEqual(eff["vs_metric"][0]["name"], "fast")

    def test_pairs_in_top_group(self):
        eff = C.param_effects(self.grid())
        self.assertEqual(eff["top_n"], 8)
        self.assertTrue(all(0 <= abs(p["rho"]) <= 1 for p in eff["pairs_top"]))

    def test_constant_param_skipped_and_empty(self):
        eff = C.param_effects([{"params": {"a": 1}, "report": {"Lợi nhuận ròng": 1}}] * 5)
        self.assertEqual(eff["vs_metric"], [])
        self.assertEqual(C.param_text(C.param_effects([]), "x"), "")


class TestUi(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_dialog(self):
        import test_ui_smoke as S
        from pyea.backtest import BacktestResult
        app = S.make_app()
        bt = app.bt_tab
        bt.res = None
        n0 = len(kivy_stub.OPEN_POPUPS)
        bt.indicator_corr_dialog()                                     # chưa chạy: chỉ toast, không mở hộp thoại
        self.assertFalse([p for p in kivy_stub.OPEN_POPUPS if "Tương quan" in str(getattr(p, "title", ""))])
        cs = walk()
        bt.res = BacktestResult(candles=cs, plots={"ma": [(c.time, c.close * 0.99) for c in cs]}, report={"Lợi nhuận ròng": 1})
        bt.indicator_corr_dialog()
        self.assertTrue([p for p in kivy_stub.OPEN_POPUPS if "Tương quan" in str(getattr(p, "title", ""))])

    def test_opt_stats_has_param_corr(self):
        import test_ui_smoke as S
        app = S.make_app()
        n0 = len(kivy_stub.OPEN_POPUPS)
        app.bt_tab.opt_stats_dialog("x.py", TestParams().grid(), "Lợi nhuận ròng")
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)


if __name__ == "__main__":
    unittest.main()
