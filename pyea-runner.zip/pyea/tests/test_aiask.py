"""api.ask_ai: bot gọi AI tổng quát (schema do bot khai, ngữ cảnh chọn được, nền, hạn mức, tra web theo cấu hình, ghi/phát lại cho backtest). Không dùng mạng."""
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub                                                                  # noqa: E402
kivy_stub.install()

from pyea import aiask, airec                                                     # noqa: E402
from pyea.ai import AGENT_INPUTS, chat_completion                                 # noqa: E402
from pyea.backtest import run_backtest                                            # noqa: E402
from pyea.sdk import Candle                                                       # noqa: E402
from pyea.settings import default_settings                                        # noqa: E402

TMP = tempfile.mkdtemp()
T0, STEP = 1_700_000_000, 300


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t


def svc(reply='{"action":"hold","confidence":0.7}', settings=None, agents=None, runner="sync", log=None):
    st = default_settings()
    st.update(bot_ai_enabled=True)
    st.update(settings or {})
    calls = []

    def chat(agent, messages, max_tokens, timeout):
        calls.append({"agent": agent, "messages": messages, "max_tokens": max_tokens, "timeout": timeout})
        if isinstance(reply, Exception):
            raise reply
        return reply
    q = []
    clock = Clock()
    s = aiask.AskService(lambda: st, lambda: agents if agents is not None else [{"name": "A1", "model": "m", "enabled": True}], chat,
                         log=log, clock=clock, runner=(lambda fn: fn()) if runner == "sync" else q.append)
    s.calls_made, s.queue, s.clock_obj, s.st = calls, q, clock, st
    return s


SCHEMA = {"action": ["hold", "close"], "confidence": "0..1", "why?": "str"}


def spec(**kw):
    d = {"question": "Giữ hay đóng?", "context": {"x": 1}, "schema": SCHEMA, "key": "k1", "tag": "t1"}
    d.update(kw)
    return d


class TestSchema(unittest.TestCase):
    def test_extract_json_handles_fences_think_and_noise(self):
        self.assertEqual(aiask.extract_json('Ok ```json\n{"a": 1, "b": {"c": "}"}}\n``` xong'), {"a": 1, "b": {"c": "}"}})
        self.assertEqual(aiask.extract_json('<think>{"z":1}</think>{"a":2}'), {"a": 2})
        self.assertIsNone(aiask.extract_json("không có json"))
        self.assertEqual(aiask.extract_json('{hỏng} {"a":3}'), {"a": 3})

    def test_validate_choices_ranges_types_optional(self):
        d, err = aiask.validate(SCHEMA, {"action": "CLOSE", "confidence": 0.5})
        self.assertEqual((d, err), ({"action": "close", "confidence": 0.5}, ""))
        for bad in ({"action": "buy", "confidence": 0.5}, {"action": "hold", "confidence": 1.5}, {"action": "hold"},
                    {"action": "hold", "confidence": "abc"}, {"action": "hold", "confidence": True}, {"action": "hold", "confidence": float("nan")}):
            self.assertNotEqual(aiask.validate(SCHEMA, bad)[1], "", bad)

    def test_validate_dict_spec_int_bool_maxlen(self):
        sc = {"n": {"type": "int", "min": 1, "max": 5}, "flag": "bool", "t": {"type": "str", "maxlen": 3}}
        d, err = aiask.validate(sc, {"n": 3, "flag": "true", "t": "abcdef"})
        self.assertEqual((d, err), ({"n": 3, "flag": True, "t": "abc"}, ""))
        self.assertNotEqual(aiask.validate(sc, {"n": 2.5, "flag": True, "t": "a"})[1], "")

    def test_schema_prompt_describes_keys_without_scenarios(self):
        p = aiask.schema_prompt(SCHEMA)
        self.assertIn('"action"', p)
        self.assertIn("không bắt buộc", p)
        self.assertIn("0.0 đến 1.0", p)


class TestService(unittest.TestCase):
    def test_disabled_by_default_and_explains(self):
        s = svc(settings={"bot_ai_enabled": False})
        a = s.ask(spec())
        self.assertEqual((a.status, a.ok), ("disabled", False))
        self.assertIn("Bot gọi AI", a.error)
        self.assertEqual(s.calls_made, [])

    def test_ok_with_schema_and_prompt_contents(self):
        s = svc()
        a = s.ask(spec())
        self.assertTrue(a.ok)
        self.assertEqual(a.data, {"action": "hold", "confidence": 0.7})
        msg = s.calls_made[0]["messages"]
        self.assertIn("Giữ hay đóng?", msg[1]["content"])
        self.assertIn('"x":1', msg[1]["content"])
        self.assertIn("JSON object", msg[1]["content"])
        self.assertEqual(s.calls_made[0]["max_tokens"], 600)

    def test_pending_then_result_without_blocking(self):
        s = svc(runner="queue")
        a = s.ask(spec())
        self.assertEqual((a.status, a.pending), ("pending", True))
        a = s.ask(spec())                                                          # gọi lại khi đang hỏi: vẫn pending, KHÔNG hỏi lần 2
        self.assertTrue(a.pending)
        self.assertEqual(len(s.queue), 1)
        s.queue[0]()
        a = s.ask(spec())
        self.assertTrue(a.ok)
        self.assertEqual(len(s.calls_made), 1)

    def test_cache_window(self):
        s = svc(settings={"bot_ai_cache_s": 100})
        s.ask(spec())
        s.clock_obj.t += 50
        a = s.ask(spec())
        self.assertTrue(a.cached)
        self.assertEqual(len(s.calls_made), 1)
        s.clock_obj.t += 100
        s.ask(spec())
        self.assertEqual(len(s.calls_made), 2)
        s.ask(spec(cache_s=0))                                                     # bot đặt riêng: không dùng lại
        self.assertEqual(len(s.calls_made), 3)

    def test_hourly_and_daily_limits(self):
        s = svc(settings={"bot_ai_max_per_hour": 2, "bot_ai_cache_s": 0})
        s.ask(spec(key="a"))
        s.ask(spec(key="b"))
        a = s.ask(spec(key="c"))
        self.assertEqual(a.status, "limited")
        self.assertGreater(a.retry_after_s, 0)
        self.assertEqual(len(s.calls_made), 2)
        s.clock_obj.t += 3601
        self.assertTrue(s.ask(spec(key="c")).ok)
        s2 = svc(settings={"bot_ai_max_per_hour": 0, "bot_ai_max_per_day": 1, "bot_ai_cache_s": 0})
        s2.ask(spec(key="a"))
        self.assertEqual(s2.ask(spec(key="b")).status, "limited")
        self.assertEqual(s.info()["limit_hour"], 2)

    def test_bad_schema_answer_is_error_not_data(self):
        s = svc(reply='{"action":"buy","confidence":0.9}')
        a = s.ask(spec())
        self.assertEqual(a.status, "error")
        self.assertIn("schema", a.error)
        self.assertEqual(a.data, {})
        self.assertIn("buy", a.text)
        s2 = svc(reply="chỉ là văn xuôi")
        self.assertIn("không trả JSON", s2.ask(spec()).error)

    def test_no_schema_returns_text(self):
        s = svc(reply="Nên giữ vì ...")
        a = s.ask(spec(schema=None))
        self.assertTrue(a.ok)
        self.assertEqual(a.text, "Nên giữ vì ...")

    def test_network_error_is_status_error_and_not_hammered(self):
        s = svc(reply=RuntimeError("HTTP 500"))
        a = s.ask(spec())
        self.assertEqual(a.status, "error")
        self.assertIn("HTTP 500", a.error)
        s.ask(spec())
        self.assertEqual(len(s.calls_made), 1)                                     # lỗi được nhớ ≤30 s, không gọi dồn
        s.clock_obj.t += 31
        s.ask(spec())
        self.assertEqual(len(s.calls_made), 2)

    def test_agent_selection_and_unknown_agent(self):
        ags = [{"name": "A1", "model": "m1"}, {"name": "A2", "model": "m2"}, {"name": "Off", "model": "m3", "enabled": False}]
        s = svc(agents=ags, settings={"bot_ai_agent": "A2"})
        s.ask(spec())
        self.assertEqual(s.calls_made[0]["agent"]["name"], "A2")
        s.ask(spec(key="z", agent="A1"))
        self.assertEqual(s.calls_made[1]["agent"]["name"], "A1")
        a = s.ask(spec(key="y", agent="Off"))
        self.assertEqual(a.status, "error")
        self.assertIn("Không có AI", a.error)
        self.assertEqual(svc(agents=[]).ask(spec()).status, "error")

    def test_context_cap_refuses_with_reason(self):
        s = svc(settings={"bot_ai_max_context": 1000})
        a = s.ask(spec(context={"big": "x" * 5000}))
        self.assertEqual(a.status, "error")
        self.assertIn("quá lớn", a.error)
        self.assertEqual(s.calls_made, [])

    def test_secrets_are_redacted_from_prompt(self):
        s = svc()
        s.ask(spec(context={"note": "api_key=sk-ABCDEF1234567890ABCDEF"}, schema=None))
        self.assertNotIn("sk-ABCDEF1234567890ABCDEF", s.calls_made[0]["messages"][1]["content"])

    def test_global_system_and_per_call_system_are_appended(self):
        s = svc(settings={"bot_ai_system": "Trả lời bằng tiếng Việt."})
        s.ask(spec(system="Ngắn gọn."))
        sysm = s.calls_made[0]["messages"][0]["content"]
        self.assertIn("tiếng Việt", sysm)
        self.assertIn("Ngắn gọn.", sysm)


class TestWeb(unittest.TestCase):
    AG = [{"name": "A1", "model": "plain", "enabled": True}, {"name": "W", "model": "plain", "web_model": "searchy", "enabled": True},
          {"name": "X", "model": "plain", "web_extra_body": '{"tools":[{"type":"web"}]}', "enabled": True}]

    def test_web_needs_user_permission(self):
        s = svc(agents=self.AG, settings={"bot_ai_allow_web": False})
        a = s.ask(spec(web=True, agent="W"))
        self.assertEqual(a.status, "error")
        self.assertIn("cho phép AI tra web", a.error)
        self.assertEqual(s.calls_made, [])

    def test_web_needs_agent_config_and_never_silently_falls_back(self):
        s = svc(agents=self.AG, settings={"bot_ai_allow_web": True})
        a = s.ask(spec(web=True, agent="A1"))
        self.assertEqual(a.status, "error")
        self.assertIn("chưa cấu hình tra web", a.error)
        self.assertEqual(s.calls_made, [])

    def test_web_uses_web_model_and_extra_body(self):
        s = svc(agents=self.AG, settings={"bot_ai_allow_web": True})
        a = s.ask(spec(web=True, agent="W"))
        self.assertTrue(a.ok and a.web)
        self.assertEqual(s.calls_made[0]["agent"]["model"], "searchy")
        s.ask(spec(web=True, agent="X", key="kx"))
        self.assertEqual(s.calls_made[1]["agent"]["extra_body"], '{"tools":[{"type":"web"}]}')
        s.ask(spec(key="plain", agent="W"))                                         # không web -> model thường
        self.assertEqual(s.calls_made[2]["agent"]["model"], "plain")

    def test_chat_completion_merges_extra_body_json(self):
        import pyea.ai as A
        seen = {}

        def fake(url, headers=None, method=None, body=None, timeout=None):
            seen.update(body)
            return {"choices": [{"message": {"content": "ok"}}]}
        old = A.http_json
        A.http_json = fake
        try:
            ag = {"preset": "Tuỳ chỉnh", "base_url": "http://x/v1", "model": "m", "extra_body": '{"tools":[1],"messages":"bị bỏ","stream":true}'}
            self.assertEqual(chat_completion(ag, [{"role": "user", "content": "hi"}]), "ok")
            self.assertEqual(seen["tools"], [1])
            self.assertIsInstance(seen["messages"], list)
            self.assertNotIn("stream", seen)
            with self.assertRaises(A.AIError):
                chat_completion(dict(ag, extra_body="{khong json"), [{"role": "user", "content": "hi"}])
        finally:
            A.http_json = old

    def test_agent_form_has_new_fields(self):
        for k in ("extra_body", "web_model", "web_extra_body"):
            self.assertIn(k, AGENT_INPUTS)


class TestRecordReplay(unittest.TestCase):
    def test_answer_is_recorded_redacted_and_replayed_without_lookahead(self):
        with tempfile.TemporaryDirectory() as d:
            log = aiask.AskLog(os.path.join(d, aiask.ASK_FILE))
            s = svc(log=log, reply='{"action":"close","confidence":0.9}')
            s.ask(spec(tag="giu_dong"))
            recs = aiask.load_asks(d)
            self.assertEqual(len(recs), 1)
            self.assertEqual(recs[0]["tag"], "giu_dong")
            self.assertEqual(recs[0]["data"]["action"], "close")
            t = recs[0]["time"]
            clock = Clock(t - 1)
            rp = aiask.ReplayAsk(recs, clock, 3600)
            self.assertEqual(rp.ask({"tag": "giu_dong"}).status, "no_replay")          # chưa tới thời điểm ghi: không nhìn trước
            clock.t = t + 10
            a = rp.ask({"tag": "giu_dong", "key": "k"})
            self.assertTrue(a.ok and a.cached)
            self.assertEqual(a.data["action"], "close")
            clock.t = t + 7200
            self.assertEqual(rp.ask({"tag": "giu_dong"}).status, "no_replay")          # quá hạn
            self.assertEqual(rp.ask({"tag": "khac"}).status, "no_replay")

    def test_record_can_be_turned_off(self):
        with tempfile.TemporaryDirectory() as d:
            log = aiask.AskLog(os.path.join(d, aiask.ASK_FILE))
            svc(log=log, settings={"bot_ai_record": False}).ask(spec())
            self.assertEqual(aiask.load_asks(d), [])


# ===================================================================== qua BotContext + backtest
def settings(**over):
    s = default_settings()
    s.update(initial_balance=10000.0, leverage=10.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0)
    s.update(over)
    return s


def candles(n=80):
    return [Candle(T0 + i * STEP, 100.0 + i * 0.1, 100.0 + i * 0.1, 100.0 + i * 0.1, 100.0 + i * 0.1, 1.0) for i in range(n)]


BOT = os.path.join(TMP, "askbot.py")
open(BOT, "w", encoding="utf-8").write('''
from pyea import BaseBot

class B(BaseBot):
    def on_init(self):
        self.answers = []
    def on_bar(self, c):
        a = self.api.ask_ai("Mua hay chờ?", include=["tick", "candles:5m:5", "account", "symbol"],
                            schema={"action": ["buy", "wait"]}, tag="muachoi", key="k")
        self.api.log("ask:", a.status, a.get("action"))
        if a.ok and a.data["action"] == "buy" and not self.api.positions():
            self.api.buy(1.0, reason="AI")
''')


class TestBacktestIntegration(unittest.TestCase):
    def run_bt(self, sigs):
        return run_backtest(BOT, {}, settings(), "BTCUSD", "5m", candles(), warmup=30, mode="open", ai_signals=sigs)

    def test_backtest_without_replay_never_calls_ai_and_says_so(self):
        r = self.run_bt(None)
        self.assertEqual(r.trades, [])
        self.assertIn("KHÔNG gọi AI trong backtest", r.report["Tín hiệu AI"])

    def test_backtest_replays_recorded_answer_only_after_its_time(self):
        sigs = airec.SignalList()
        sigs.asks = [{"time": float(T0 + 50 * STEP), "tag": "muachoi", "text": "", "data": {"action": "buy"}, "agent": "A", "model": "m"}]
        r = self.run_bt(sigs)
        self.assertTrue(r.trades or r.report)
        opened = [t for t in (r.trades or [])]
        if opened:
            self.assertGreaterEqual(opened[0].open_time, T0 + 50 * STEP)
        self.assertIn("Phát lại câu trả lời AI đã ghi", r.report["Tín hiệu AI"])

    def test_context_providers_build_compact_json_and_unknown_is_explained(self):
        from types import SimpleNamespace as NS
        cs = candles(10)
        api = NS(symbol="BTCUSD", timeframe="5m", tick=NS(bid=1.0, ask=1.1, time=5),
                 positions=lambda side=None: [NS(id=1, symbol="BTCUSD", side="buy", volume=0.1, open_price=100.123456789, sl=0.0, tp=0.0, open_time=1, profit=2.5, comment="")],
                 orders=lambda: [], account_info=lambda: NS(balance=1000.0, equity=1001.0, margin=0.0, free_margin=1001.0, margin_level=0.0, leverage=1.0, mode="paper"),
                 symbol_info=lambda: NS(volume_min=0.01, volume_max=10.0, volume_step=0.01, spread=0.1, market_open=True),
                 candles=lambda n, include_current=False, timeframe=None: cs[-n:], calendar=lambda h, i: [{"ts": 1, "currency": "USD", "title": "CPI", "impact": 3, "x": 1}],
                 stats=lambda: {"trades": 3}, store=NS(items=lambda: [("a", 1)]), time_info=lambda: {"utc": 1})
        ctx = aiask.build_context(api, ["positions", "tick", "candles:1d:4", "calendar:6:high", "account", "symbol", "stats", "store", "time", "orders"], {"mine": [1, 2]})
        self.assertEqual(ctx["candles:1d:4"]["timeframe"], "1d")
        self.assertEqual(len(ctx["candles:1d:4"]["rows"]), 4)
        self.assertEqual(ctx["calendar:6:high"][0]["title"], "CPI")
        self.assertNotIn("x", ctx["calendar:6:high"][0])
        self.assertEqual(ctx["positions"][0]["open_price"], 100.123457)
        self.assertEqual(ctx["data"], {"mine": [1, 2]})
        json.dumps(ctx)
        with self.assertRaises(ValueError) as cm:
            aiask.build_context(api, ["khong_co"])
        self.assertIn("positions", str(cm.exception))
        big = aiask.build_context(api, ["candles:1h:99999"])
        self.assertLessEqual(len(big["candles:1h:99999"]["rows"]), 300)


class TestContextApiAndRpc(unittest.TestCase):
    def ctx(self, hub):
        from types import SimpleNamespace as NS
        from pyea.engine import BotContext
        runner = NS(session=NS(ai_hub=hub), symbol="BTCUSD", tf="5m", iid="bot-1")
        return BotContext(runner)

    def test_no_hub_is_disabled_status_not_exception(self):
        a = self.ctx(None).ask_ai("q")
        self.assertEqual(a.status, "disabled")

    def test_passes_spec_through_with_stable_key_and_tag(self):
        got = []

        class Hub:
            def ask(self, spec):
                got.append(spec)
                from pyea.sdk import AIAnswer
                return AIAnswer(status="ok", ok=True, data={"a": 1}, key=spec["key"])

            def ask_info(self):
                return {"enabled": True}
        c = self.ctx(Hub())
        a = c.ask_ai("Câu hỏi", data={"x": 1}, schema={"a": "number"}, web=True, agent="W", cache_s=5)
        self.assertTrue(a.ok)
        sp = got[0]
        self.assertEqual((sp["question"], sp["web"], sp["agent"], sp["cache_s"], sp["symbol"], sp["bot"]), ("Câu hỏi", True, "W", 5, "BTCUSD", "bot-1"))
        self.assertTrue(sp["key"].startswith("k:"))
        self.assertTrue(sp["tag"].startswith("q:"))
        c.ask_ai("Câu hỏi", data={"x": 1}, schema={"a": "number"}, web=True, agent="W", cache_s=5)
        self.assertEqual(got[0]["key"], got[1]["key"])                                # cùng nội dung -> cùng key
        c.ask_ai("Câu hỏi", data={"x": 2}, schema={"a": "number"}, web=True, agent="W", cache_s=5)
        self.assertNotEqual(got[0]["key"], got[2]["key"])
        self.assertEqual(c.ask_ai_info(), {"enabled": True})

    def test_bad_include_and_bad_schema_become_error_answers(self):
        class Hub:
            def ask(self, spec):
                raise AssertionError("không được gọi")
        c = self.ctx(Hub())
        self.assertEqual(c.ask_ai("q", include=["nope"]).status, "error")
        self.assertEqual(c.ask_ai("q", schema={}).status, "error")

    def test_answer_crosses_process_boundary(self):
        from pyea import botproc
        from pyea.sdk import AIAnswer
        a = AIAnswer(status="ok", ok=True, text="t", data={"action": "hold", "confidence": 0.5}, key="k")
        b = botproc.dec(json.loads(json.dumps(botproc.enc(a))))
        self.assertIsInstance(b, AIAnswer)
        self.assertEqual(b.data["action"], "hold")
        self.assertEqual(b.get("confidence"), 0.5)
        self.assertEqual(b.get("nope", 7), 7)


if __name__ == "__main__":
    unittest.main()


class TestHistory(unittest.TestCase):
    def mk(self, d, **kw):
        h = aiask.AskLog(os.path.join(d, aiask.HIST_FILE))
        return svc(log=aiask.AskLog(os.path.join(d, aiask.ASK_FILE)), **kw), h

    def test_every_call_is_logged_with_bot_and_redacted(self):
        with tempfile.TemporaryDirectory() as d:
            s, h = self.mk(d)
            s.history = h
            s.ask(spec(bot="bot1-BTC", symbol="BTCUSD", question="Hỏi api_key=sk-ABCDEF1234567890ABCDEF"))
            recs = aiask.load_history(d)
            self.assertEqual(len(recs), 1)
            r = recs[0]
            self.assertEqual((r["bot"], r["symbol"], r["status"]), ("bot1-BTC", "BTCUSD", "ok"))
            self.assertNotIn("sk-ABCDEF1234567890ABCDEF", r["q"])
            self.assertEqual(r["data"]["action"], "hold")
            self.assertIn("bot1-BTC", aiask.hist_line(r))
            self.assertIn("Câu hỏi", aiask.hist_detail(r))

    def test_errors_and_limits_are_logged_but_limit_is_throttled(self):
        with tempfile.TemporaryDirectory() as d:
            s, h = self.mk(d, reply=RuntimeError("HTTP 500"), settings={"bot_ai_max_per_hour": 1, "bot_ai_cache_s": 0})
            s.history = h
            s.ask(spec(key="a"))
            for _ in range(5):
                s.ask(spec(key="b"))
            st = [r["status"] for r in aiask.load_history(d)]
            self.assertEqual(st.count("error"), 1)
            self.assertEqual(st.count("limited"), 1)                                   # 5 lần bị từ chối chỉ ghi 1 dòng

    def test_usage_counts_ignore_refusals(self):
        with tempfile.TemporaryDirectory() as d:
            s, h = self.mk(d, settings={"bot_ai_max_per_hour": 1, "bot_ai_cache_s": 0})
            s.history = h
            s.ask(spec(key="a"))
            s.ask(spec(key="b"))                                                       # limited
            self.assertEqual(aiask.usage_counts(d, 1001.0), (1, 1))                    # lần bị từ chối vì hạn mức không tính

    def test_newest_first_limit_and_clear(self):
        with tempfile.TemporaryDirectory() as d:
            h = aiask.AskLog(os.path.join(d, aiask.HIST_FILE))
            for i in range(10):
                h.append({"time": 1000.0 + i, "tag": "t", "status": "ok"})
            recs = aiask.load_history(d, 3)
            self.assertEqual([r["time"] for r in recs], [1009.0, 1008.0, 1007.0])
            self.assertTrue(aiask.clear_history(d))
            self.assertEqual(aiask.load_history(d), [])
            self.assertFalse(aiask.clear_history(d))

    def test_hub_wires_history_file_and_bot_id(self):
        from pyea.ai import AIHub
        from pyea.storage import Store as Storage
        with tempfile.TemporaryDirectory() as d:
            hub = AIHub(Storage(d), lambda: {}, lambda: None, lambda: default_settings())
            self.assertIsNotNone(hub.asker.history)
            self.assertTrue(hub.asker.history.path.endswith(aiask.HIST_FILE))


class TestHistoryUi(unittest.TestCase):
    def test_dialog_opens_empty_and_with_records(self):
        import test_ui_smoke as S
        app = S.make_app()
        n0 = len(kivy_stub.OPEN_POPUPS)
        app.ai_tab.ask_history()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        aiask.AskLog(os.path.join(app.store.base, aiask.HIST_FILE)).append(
            {"time": 1700000000.0, "tag": "t", "bot": "b1", "symbol": "BTCUSD", "status": "ok", "q": "câu hỏi", "data": {"a": 1}, "took_s": 1.2})
        app.ai_tab.ask_history()
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 2)
        kivy_stub.OPEN_POPUPS.clear()
        aiask.clear_history(app.store.base)


