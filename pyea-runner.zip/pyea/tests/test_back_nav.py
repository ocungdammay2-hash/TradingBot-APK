"""1.9.35: nút Back (đóng popup / về tab trước), đổi tài sản-khung của bot đã nạp, chạm dòng lệnh/đường lệnh để sửa. Giao diện giả Kivy."""
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402


class TestTabHistory(unittest.TestCase):
    def test_back_walks_history(self):
        from pyea.backnav import TabHistory
        h = TabHistory()
        h.cur = "market"
        for k in ("bots", "chart", "settings"):
            h.visit(k)
        self.assertEqual(h.back(), "chart")
        h.visit("chart")                                    # switch_to do back() gây ra: bị bỏ qua
        self.assertEqual(h.back(), "bots")
        self.assertEqual(h.back(), "market")
        self.assertIsNone(h.back())

    def test_no_pingpong_growth(self):
        from pyea.backnav import TabHistory
        h = TabHistory()
        h.cur = "a"
        for _ in range(20):
            h.visit("b")
            h.visit("a")
        self.assertLessEqual(len(h.stack), 2)

    def test_limit(self):
        from pyea.backnav import TabHistory
        h = TabHistory(limit=3)
        h.cur = "t0"
        for i in range(1, 10):
            h.visit("t%d" % i)
        self.assertEqual(len(h.stack), 3)


class TestBackKey(unittest.TestCase):
    def setUp(self):
        from pyea import ui_widgets as W
        del W.POPUP_STACK[:]                                 # popup mở dở của test khác (stub không tự đóng)

    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()
        from pyea import ui_widgets as W
        del W.POPUP_STACK[:]

    def test_back_closes_top_popup_then_tab(self):
        import test_ui_smoke as S
        from pyea import ui_widgets as W
        app = S.make_app()
        a = W.StyledPopup(title="a", content=None)
        b = W.StyledPopup(title="b", content=None)
        a.open()
        b.open()
        self.assertIs(W.top_popup(), b)
        self.assertTrue(app._on_key(None, 27))
        self.assertIs(W.top_popup(), a)                     # chỉ đóng popup trên cùng
        self.assertTrue(app._on_key(None, 27))
        self.assertIsNone(W.top_popup())
        # không còn popup: về tab trước
        app.root_panel.switch_to(app.tabs["chart"])
        app._tab_hist.visit("chart")
        app.root_panel.switch_to(app.tabs["settings"])
        app._tab_hist.visit("settings")
        self.assertTrue(app.go_back())
        self.assertIs(app.root_panel.current, app.tabs["chart"])

    def test_blocking_popup_swallows_back(self):
        import test_ui_smoke as S
        from pyea import ui_widgets as W
        app = S.make_app()
        p = W.StyledPopup(title="rủi ro", content=None)
        p.back_blocks = True
        p.open()
        self.assertTrue(app._on_key(None, 27))
        self.assertIs(W.top_popup(), p)                     # vẫn mở, và app KHÔNG thoát

    def test_other_keys_ignored(self):
        import test_ui_smoke as S
        app = S.make_app()
        self.assertFalse(app._on_key(None, 13))

    def test_risk_dialog_blocks_back(self):
        import test_ui_smoke as S
        from pyea import ui_widgets as W
        app = S.make_app()
        pop = app.risk_dialog(lambda *_: None) if app.risk_dialog.__code__.co_argcount > 1 else app.risk_dialog()
        self.assertTrue(pop.back_blocks)


class TestEditInstance(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_change_symbol_tf_offline(self):
        import test_ui_smoke as S
        app = S.make_app()
        cfg = app.attach_cfgs[0]
        iid = cfg["iid"]
        self.assertTrue(app.apply_instance_target(iid, "ETHUSDT", "15m"))
        self.assertEqual((cfg["symbol"], cfg["tf"]), ("ETHUSDT", "15m"))
        self.assertFalse(app.apply_instance_target(iid, "ETHUSDT", "15m"))      # không đổi gì
        app.attach_tab.update(None, False)                                      # hàng bot dựng lại với mã mới
        self.assertIn("ETHUSDT", app.attach_tab._att[iid][0].text)

    def test_dialog_opens(self):
        import test_ui_smoke as S
        app = S.make_app()
        n = len(kivy_stub.OPEN_POPUPS)
        app.edit_instance_dialog(app.attach_cfgs[0]["iid"])
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n + 1)

    def test_change_live_instance(self):
        import test_ui_smoke as S
        app = S.make_app()
        app.start_session(run_bots=False)
        try:
            end = time.time() + 15
            while time.time() < end and not (app.last_snap and app.last_snap["instances"]):
                app.refresh(0)
                time.sleep(0.05)
            iid = app.last_snap["instances"][0]["iid"]
            self.assertTrue(app.apply_instance_target(iid, "ETHUSDT", "15m"))
            end = time.time() + 15
            ok = False
            while time.time() < end and not ok:
                app.refresh(0)
                ok = any(i["iid"] == iid and i.get("symbol", "ETHUSDT") == "ETHUSDT" for i in app.last_snap["instances"])
                time.sleep(0.05)
            self.assertTrue(ok)
            inst = app.ctl.session.instances.get(iid) if hasattr(app.ctl, "session") else None
            if inst is not None:
                self.assertEqual((inst.symbol, inst.tf), ("ETHUSDT", "15m"))
        finally:
            if app.is_connected():
                app.ctl.stop()


class TestTapTargets(unittest.TestCase):
    def test_tap_panel_fires_only_on_tap(self):
        from pyea import ui_widgets as W

        class T:
            def __init__(s, x, y):
                s.x, s.y, s.pos, s.ud, s.grab_current = x, y, (x, y), {}, None
            def grab(s, w): s.grab_current = w
            def ungrab(s, w): s.grab_current = None
        hits = []
        p = W.TapPanel(on_tap=lambda: hits.append(1))
        p.collide_point = lambda x, y: True
        p.children = []
        t = T(10, 10)
        self.assertTrue(p.on_touch_down(t))
        t.x, t.y, t.pos = 11, 11, (11, 11)
        t.grab_current = p
        p.on_touch_up(t)
        self.assertEqual(hits, [1])
        t2 = T(10, 10)
        p.on_touch_down(t2)
        t2.x, t2.y, t2.pos = 10, 200, (10, 200)             # kéo = cuộn trang, không phải chạm
        t2.grab_current = p
        p.on_touch_up(t2)
        self.assertEqual(hits, [1])

    def test_chart_line_tap(self):
        import test_chart as C
        ch = C.make_chart(200, 60)
        got = []
        ch.on_line_tap = got.append
        last = ch.candles[-1].close
        ch.update(ch.candles, {}, [], [(last, (1, 1, 1, 1), "BUY", ("pos", 7))])
        ch.redraw()
        self.assertTrue(ch._hlhits)
        y = ch._hlhits[0][0]
        t = C.down(ch, 100, y + 3)
        C.up(ch, t)
        self.assertEqual(got, [("pos", 7)])

    def test_pan_warns_when_everything_visible(self):
        import test_chart as C
        ch = C.make_chart(60, 60)
        msgs = []
        ch.on_toast = msgs.append
        t = C.down(ch, 100, 150)
        C.move(ch, t, 160, 151)
        self.assertEqual(len(msgs), 1)

    def test_pan_moves_with_refresh_between(self):
        from dataclasses import replace
        import test_chart as C
        ch = C.make_chart(160, 60)
        cs = list(ch.candles)
        t = C.down(ch, 200, 150)
        for i in range(1, 6):
            C.move(ch, t, 200 + i * 15, 152)
            ch.update(cs[:-1] + [replace(cs[-1], close=cs[-1].close + i * 0.01)], {}, [], [])
        self.assertGreater(ch.offset, 10)


if __name__ == "__main__":
    unittest.main()
