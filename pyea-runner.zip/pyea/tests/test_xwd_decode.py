"""Công cụ giải ảnh màn hình ảo của bộ cài MT5 (tools/mt5_phone/xwd_decode.py): đọc xwd|gzip|base64 từ tệp chẩn đoán thành PNG."""
import base64
import gzip
import importlib.util
import os
import shutil
import struct
import subprocess
import tempfile
import time
import unittest
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.join(HERE, "..", "tools", "mt5_phone", "xwd_decode.py")
spec = importlib.util.spec_from_file_location("xwd_decode", TOOL)
xd = importlib.util.module_from_spec(spec)
spec.loader.exec_module(xd)


def make_xwd(width, height, pixels565, name=b"fake\0"):
    """Tệp XWD tối thiểu: TrueColor 16 bit (rgb565), little-endian như Xvfb trên x86/arm."""
    bpl = width * 2
    header_size = 100 + len(name)
    h = struct.pack(">25I", header_size, 7, 2, 16, width, height, 0, 0, 32, 0, 32, 16, bpl, 4, 0xF800, 0x07E0, 0x001F, 6, 0, 0, width, height, 0, 0, 0)
    data = b"".join(struct.pack("<H", p) for p in pixels565)
    return h + name + data


def make_xwd_directcolor24(width, height, rgb_pixels, bpl):
    """Giống HệT tiêu đề ảnh thật chụp trên điện thoại: depth 24, 24 bit/điểm, DirectColor (loại 5), 256 mục bảng màu theo dốc xám, dòng đệm tới bpl byte."""
    name = b"xwdump\0"
    h = struct.pack(">25I", 100 + len(name), 7, 2, 24, width, height, 0, 0, 32, 0, 8, 24, bpl, 5, 0xFF0000, 0x00FF00, 0x0000FF, 8, 256, 256, width, height, 0, 0, 0)
    cmap = b"".join(struct.pack(">IHHHBB", i * 0x010101, i * 257, i * 257, i * 257, 7, 0) for i in range(256))
    rows = []
    for y in range(height):
        row = b"".join(bytes((b, g, r)) for (r, g, b) in rgb_pixels[y * width:(y + 1) * width])      # little-endian 0x00RRGGBB
        rows.append(row + b"\0" * (bpl - len(row)))
    return h + name + cmap + b"".join(rows)


class TestXwdDecode(unittest.TestCase):
    def test_rgb565_pixels_are_expanded_exactly(self):
        raw = make_xwd(2, 2, [0xF800, 0x07E0, 0x001F, 0xFFFF])      # đỏ, lục, lam, trắng
        w, h, rgb = xd.parse_xwd(raw)
        self.assertEqual((w, h), (2, 2))
        self.assertEqual(list(rgb), [255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 255])

    def test_directcolor_24bit_padded_rows_like_the_real_phone_screenshot(self):
        """Lỗi thật gặp ở ảnh đầu tiên từ điện thoại: tra bảng màu theo cả giá trị điểm ảnh làm mọi màu ngoài xám thành ĐEN."""
        px = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (10, 20, 30), (200, 200, 200), (0, 0, 0)]
        w, h, rgb = xd.parse_xwd(make_xwd_directcolor24(3, 2, px, bpl=16))
        self.assertEqual((w, h), (3, 2))
        self.assertEqual(list(rgb), [c for p in px for c in p])

    def test_finds_the_image_inside_a_noisy_diagnostic_file_and_writes_png(self):
        d = tempfile.mkdtemp(prefix="pyea_xwd_")
        try:
            src = os.path.join(d, "diag.txt")
            big = make_xwd(40, 40, [(i * 977) & 0xFFFF for i in range(1600)])
            b64big = base64.b64encode(gzip.compress(big)).decode()
            with open(src, "w", encoding="utf-8") as f:
                f.write("--- chẩn đoán ---\nwine=amd64-10.12 abc123\n" + "dòng thường " * 30 + "\n--- ảnh màn hình ---\n" + b64big + "\n")
            out = os.path.join(d, "o.png")
            self.assertEqual(xd.main(["x", src, out]), 0)
            png = open(out, "rb").read()
            self.assertEqual(png[:8], b"\x89PNG\r\n\x1a\n")
            w, h = struct.unpack(">II", png[16:24])
            self.assertEqual((w, h), (40, 40))
            idat = png[png.index(b"IDAT") + 4:png.index(b"IEND") - 8]
            self.assertEqual(len(zlib.decompress(idat)), 40 * (1 + 40 * 3))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_missing_image_gives_a_clear_message(self):
        with self.assertRaises(ValueError) as cm:
            xd.find_b64("không có ảnh: không-có-xwd")
        self.assertIn("không thấy chuỗi base64", str(cm.exception))

    @unittest.skipUnless(shutil.which("xwd") and shutil.which("Xvfb"), "cần xwd và Xvfb để thử trên ảnh thật")
    def test_real_xwd_from_real_xvfb_roundtrip(self):
        d = tempfile.mkdtemp(prefix="pyea_xwd_")
        disp = ":%d" % (600 + os.getpid() % 300)
        xv = subprocess.Popen(["Xvfb", disp, "-screen", "0", "320x200x16", "-nolisten", "tcp"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            time.sleep(1.5)
            env = dict(os.environ, DISPLAY=disp)
            shot = subprocess.run("xwd -root -silent | gzip -9 | base64 -w0", shell=True, env=env, capture_output=True, timeout=30).stdout.decode()
            self.assertGreater(len(shot), 200)
            w, h, rgb = xd.parse_xwd(gzip.decompress(base64.b64decode(xd.find_b64(shot))))
            self.assertEqual((w, h), (320, 200))
            self.assertEqual(len(rgb), 320 * 200 * 3)
        finally:
            xv.terminate()
            xv.wait(timeout=10)
            shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
