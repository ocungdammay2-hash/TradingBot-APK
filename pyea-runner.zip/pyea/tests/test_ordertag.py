import unittest

from pyea import ordertag, tradeinfo
from pyea.sdk import Position, Trade, TradeEvent


class OrderTagTests(unittest.TestCase):
    def test_comment_never_exceeds_31_with_nonce(self):
        for label in ("", "x", "Phá vỡ đa khung thời gian H1/H4 rất dài rất dài", "ÀÁẢÃẠ" * 10):
            base = ordertag.compose("instance-with-a-very-long-id-0001", label)
            self.assertLessEqual(len(base), 22)
            self.assertLessEqual(len(base + "~deadbeef"), 31)
            self.assertTrue(base.startswith("pyea"))

    def test_roundtrip_and_owner_lookup(self):
        owners = ["bot-a", "bot-b", "bot-c"]
        c = ordertag.compose("bot-b", "Breakout H1") + "~0a1b2c3d"
        d = ordertag.decode(c)
        self.assertTrue(d["app"])
        self.assertEqual(d["label"], "Breakout-H1")
        self.assertEqual(d["nonce"], "0a1b2c3d")
        self.assertEqual(ordertag.match_owner(d["code"], owners), "bot-b")
        self.assertIsNone(ordertag.match_owner("zzzz", owners))

    def test_legacy_tags_still_app(self):
        self.assertTrue(ordertag.decode("pyea")["app"])
        self.assertTrue(ordertag.decode("pyea~0a1b2c3d")["app"])
        self.assertEqual(ordertag.decode("pyea~0a1b2c3d")["nonce"], "0a1b2c3d")

    def test_classify(self):
        self.assertEqual(ordertag.classify("pyeaabcd:x~00000000"), "app")
        self.assertEqual(ordertag.classify("", 0), "manual")
        self.assertEqual(ordertag.classify("", 777), "ea")
        self.assertEqual(ordertag.classify("MyEA v2", 0), "ea")
        self.assertEqual(ordertag.classify("[sl 1.2345]", 0), "sl_tp")

    def test_empty_owner_is_plain_prefix(self):
        self.assertEqual(ordertag.compose(None, "x"), "pyea")


class TradeInfoTests(unittest.TestCase):
    def test_position_detail_uses_event_reason(self):
        p = Position(id=3, symbol="EURUSD", side="buy", volume=0.1, open_price=1.1, open_time=1000.0, sl=1.09, tp=1.12, owner="bot-a", ref="555", origin="app")
        ev = TradeEvent(id=1, kind="open", time=1000.0, price=1.1, side="buy", pos_id=3, reason="Vượt đỉnh 20 nến", symbol="EURUSD")
        i = tradeinfo.build("position", p, [ev], {"bot-a": {"name": "Breakout"}}, now=5000.0)
        self.assertEqual(i["entry_logic"], "Vượt đỉnh 20 nến")
        self.assertIn("Breakout (bot-a)", dict(i["rows"])["Bot / chủ lệnh"])
        self.assertFalse(i["closed"])
        self.assertEqual(i["span"], (1000.0, 5000.0))

    def test_no_reason_is_stated_not_invented(self):
        t = Trade(id=9, symbol="BTCUSDT", side="sell", volume=1, open_price=10, close_price=9, open_time=100.0, close_time=200.0, profit=1.0, reason="TP", owner="manual")
        i = tradeinfo.build("trade", t, [], {})
        self.assertIn("Không có ghi chép", i["entry_logic"])
        self.assertTrue(i["closed"])
        self.assertEqual(len(tradeinfo.marker_events(i)), 2)

    def test_history_row_from_broker_comment_restores_bot_and_origin(self):
        row = {"symbol": "EURUSD", "side": "buy", "volume": 0.1, "price": 1.1, "price2": 1.2, "time": 2000.0, "open_time": 1000.0, "profit": 3.0,
               "id": "7", "owner": ordertag.compose("bot-a", "scalp") + "~abcdef01"}
        i = tradeinfo.build("row", row, [], {"bot-a": {}})
        self.assertEqual(i["origin"], "app")
        self.assertEqual(i["owner"], "bot-a")
        self.assertEqual(dict(i["rows"])["Logic (nhãn)"], "scalp")

    def test_manual_row(self):
        i = tradeinfo.build("row", {"symbol": "EURUSD", "side": "sell", "volume": 1, "price": 1, "price2": 2, "time": 9.0, "open_time": 1.0, "profit": 0, "id": "1", "owner": ""}, [], {})
        self.assertEqual(i["origin"], "")

    def test_pick_tf_scales_with_duration(self):
        self.assertEqual(tradeinfo.pick_tf(0, 600)[0], "1m")
        self.assertIn(tradeinfo.pick_tf(0, 86400 * 3)[0], ("1h", "2h"))
        self.assertGreater(tradeinfo.bars_needed(0, 3600, 60), 50)


if __name__ == "__main__":
    unittest.main()
