"""DANH TÍNH VỊ THẾ (ticket) trong ĐỐI SOÁT - chạy y hệt trên mọi sàn có vị thế riêng + ticket (MT/MetaApi, Exness).

Khi broker khai CLOSE_BY_REF + hedged_positions() và mọi vị thế ảo của mã có ticket duy nhất, `adopt` đối chiếu CHÍNH XÁC theo ticket:
  * vị thế nào mất trên sàn  -> đúng vị thế ảo đó đóng, ở GIÁ của deal đóng thuộc ticket đó (không phải «mới nhất trước» + giá hiện tại);
  * ticket nào giảm khối lượng -> đúng vị thế ảo đó giảm;
  * ticket lạ xuất hiện       -> nhập với ticket + SL/TP của sàn, đánh dấu adopted (không tự động bị sửa SL/TP gốc);
  * không đủ điều kiện (thiếu ticket / nhiều vị thế ảo chung ticket - netting) -> rơi về cách suy theo tổng khối lượng như cũ."""
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import test_protect_contract as tc                          # noqa: E402
import pyea.reconcile as rc                                  # noqa: E402


class Ext:
    """Thao tác «bên ngoài app» trên sàn giả: đóng/giảm/mở vị thế y như bạn bấm trên app của sàn."""
    def __init__(self, h):
        self.h = h

    def close(self, ref, price): raise NotImplementedError
    def reduce(self, ref, by, price): raise NotImplementedError
    def open(self, side, vol, sl=0.0, tp=0.0): raise NotImplementedError


class MtExt(Ext):
    def close(self, ref, price):
        c = self.h.core
        p = c.positions.pop(ref)
        c._deal("X" + ref, p["symbol"], "sell" if p["side"] == "buy" else "buy", p["volume"], price, 0.0, pos_id=ref, entry="OUT")

    def reduce(self, ref, by, price):
        c = self.h.core
        p = c.positions[ref]
        p["volume"] = round(p["volume"] - by, 8)
        c._deal("R" + ref, p["symbol"], "sell" if p["side"] == "buy" else "buy", by, price, 0.0, pos_id=ref, entry="OUT")

    def open(self, side, vol, sl=0.0, tp=0.0):
        c = self.h.core
        pid, _, _ = c.open(self.h.SYM, side, vol, "")                       # đặt tay: comment rỗng
        c.positions[pid]["sl"], c.positions[pid]["tp"] = sl, tp
        return pid


class ExnExt(Ext):
    def close(self, ref, price):
        f = self.h.fake
        with f.lock:
            p = f.positions.pop(ref)
            for k in [k for k, o in f.orders.items() if o.get("position_id") == ref]:
                del f.orders[k]
            f.n += 1
            f.deals.append({"deal_id": "D%d" % f.n, "order_id": "X%d" % f.n, "type": "close", "event_time": __import__("datetime").datetime.now(
                __import__("datetime").timezone.utc).isoformat(), "instrument": p["instrument"], "side": "sell" if p["side"] == "buy" else "buy",
                "volume": p["volume"], "price": price, "profit": 0.0, "commission": 0.0, "position_id": ref})

    def reduce(self, ref, by, price):
        f = self.h.fake
        with f.lock:
            p = f.positions[ref]
            p["volume"] = round(p["volume"] - by, 8)
            f.n += 1
            f.deals.append({"deal_id": "D%d" % f.n, "order_id": "X%d" % f.n, "type": "close", "event_time": __import__("datetime").datetime.now(
                __import__("datetime").timezone.utc).isoformat(), "instrument": p["instrument"], "side": "sell" if p["side"] == "buy" else "buy",
                "volume": by, "price": price, "profit": 0.0, "commission": 0.0, "position_id": ref})

    def open(self, side, vol, sl=0.0, tp=0.0):
        f = self.h.fake
        with f.lock:
            pid = f._open(self.h.SYM, side, vol, f.prices[self.h.SYM][1 if side == "buy" else 0])
            if sl or tp:
                f.n += 1
                f.orders["E%d" % f.n] = {"type": "sltp", "instrument": self.h.SYM, "side": side, "volume": vol, "price": 0.0, "sl": sl or None, "tp": tp or None,
                                         "position_id": pid}
        return pid


class Identity:
    H = None
    EXT = None

    @classmethod
    def setUpClass(cls):
        if cls.H is tc.ExnH and not tc.HAVE_CRYPTO:
            raise unittest.SkipTest("cần cryptography")
        cls.h = cls.H()
        cls.ext = cls.EXT(cls.h)

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        self.h.reset()
        self._cs, rc.CONFIRM_S = rc.CONFIRM_S, 0.0
        self.s = self.h.session(tempfile.mkdtemp(), native_sltp=False)
        self.h.tick(self.s, self.h.P0)

    def tearDown(self):
        rc.CONFIRM_S = self._cs

    def open(self, vol, sl, tp):
        r = self.s.send_order(self.h.SYM, "buy", vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position

    def converge(self):
        first = self.s.reconcile_now()
        for k in list(self.s._recon_pending):
            self.s._recon_pending[k] -= 60.0
        return self.s.reconcile_now() if first else first

    def test_external_close_removes_exactly_that_virtual_position_at_its_deal_price(self):
        h = self.h
        a, b = self.open(h.VOL_A, *h.LV_A), self.open(h.VOL_B, *h.LV_B)
        self.assertTrue(a.ref and b.ref and a.ref != b.ref)
        b_owner, b_id = b.owner, b.id
        self.ext.close(a.ref, 1.0950)                                         # bạn đóng vị thế A (CŨ) trên app của sàn, giá 1.0950
        self.converge()
        self.assertEqual(self.s.account.positions.keys(), {b_id})            # «mới nhất trước» sẽ đóng nhầm B; theo ticket thì đúng A
        kept = self.s.account.positions[b_id]
        self.assertEqual((kept.ref, kept.owner, kept.sl, kept.tp, kept.volume), (b.ref, b_owner, h.LV_B[0], h.LV_B[1], h.VOL_B))
        tr = self.s.account.trades[-1]
        self.assertAlmostEqual(tr.close_price, 1.0950, 6)                     # giá của deal đóng thuộc ĐÚNG ticket A
        self.assertEqual(tr.reason, "Đối soát")
        self.assertTrue(any("ticket #%s" % a.ref in repr(e) for e in self.s.events), "sự kiện phải nêu ticket")
        self.assertEqual(self.s.reconcile_now(), [])                          # hội tụ

    def test_reduced_ticket_reduces_exactly_that_virtual_position(self):
        h = self.h
        a, b = self.open(h.VOL_A, *h.LV_A), self.open(h.VOL_B, *h.LV_B)
        self.ext.reduce(b.ref, 0.01, 1.1010)
        self.converge()
        self.assertAlmostEqual(self.s.account.positions[b.id].volume, h.VOL_B - 0.01, 6)
        self.assertAlmostEqual(self.s.account.positions[a.id].volume, h.VOL_A, 6)
        self.assertEqual(self.s.reconcile_now(), [])

    def test_unknown_ticket_is_imported_with_its_ticket_levels_and_marked_adopted(self):
        h = self.h
        a = self.open(h.VOL_A, *h.LV_A)
        pid = self.ext.open("buy", 0.05, 1.0500, 1.2000)
        self.converge()
        imp = [p for p in self.s.account.positions.values() if p.ref == pid]
        self.assertEqual(len(imp), 1)
        p = imp[0]
        self.assertTrue(p.adopted)
        self.assertEqual((p.owner, p.sl, p.tp, p.volume), ("manual", 1.05, 1.2, 0.05))
        self.assertIn(a.id, self.s.account.positions)
        self.assertEqual(self.s.reconcile_now(), [])

    def test_virtual_positions_sharing_one_ticket_fall_back_to_the_total_volume_logic(self):
        h = self.h
        a, b = self.open(h.VOL_A, *h.LV_A), self.open(h.VOL_B, *h.LV_B)
        real_a = a.ref
        b.ref = a.ref                                                         # như netting: hai vị thế ảo chung một ticket (ref trùng)
        self.ext.close(real_a, 1.0950)                                        # sàn mất 0.06 (còn đúng 0.04 của vị thế thật B)
        self.converge()                                                       # không lỗi, không đoán theo ticket: suy theo TỔNG khối lượng
        self.assertAlmostEqual(sum(p.volume for p in self.s.account.positions.values()), h.VOL_B, 6)
        self.assertEqual(self.s.reconcile_now(), [])

    def test_virtual_position_without_ticket_falls_back_to_the_total_volume_logic(self):
        h = self.h
        a, b = self.open(h.VOL_A, *h.LV_A), self.open(h.VOL_B, *h.LV_B)
        a.ref = ""                                                            # sổ cũ chưa có ticket
        self.ext.close(b.ref, 1.0950)
        self.converge()
        self.assertAlmostEqual(sum(p.volume for p in self.s.account.positions.values()), h.VOL_A, 6)   # tổng khối lượng khớp sàn


class TestMtIdentity(Identity, unittest.TestCase):
    H, EXT = tc.MtH, MtExt


class TestExnIdentity(Identity, unittest.TestCase):
    H, EXT = tc.ExnH, ExnExt


if __name__ == "__main__":
    unittest.main()
