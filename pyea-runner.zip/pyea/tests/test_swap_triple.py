"""Swap kiểu broker MT: tính rời rạc mỗi ngày giao dịch ở giờ rollover, ngày chỉ định x3, T7/CN không tính."""
import os
import sys
import unittest
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea.backtest import CostModel                          # noqa: E402
from pyea.sdk import Position                                # noqa: E402
from pyea.settings import clean_settings, default_settings   # noqa: E402


def ts(y, m, d, h=0, mi=0):
    return datetime(y, m, d, h, mi, tzinfo=timezone.utc).timestamp()


# 2024-01-01 là Thứ Hai
MON, TUE, WED, THU, FRI, SAT, SUN = (ts(2024, 1, i) for i in range(1, 8))


def pos(side="buy", vol=1.0):
    return Position(id=1, symbol="EURUSD", side=side, volume=vol, open_price=100.0, open_time=0.0)


class TestTripleSwap(unittest.TestCase):
    def cm(self, **kw):
        base = dict(swap_long_pct_day=0.1, swap_short_pct_day=-0.05, swap_triple_weekday=2, swap_rollover_hour_utc=21.0)
        base.update(kw)
        return CostModel(**base)

    def test_one_week_charges_seven_days_not_nine_or_five(self):
        c = self.cm()
        n = c.rollovers(MON, MON + 7 * 86400)                      # T2 00:00 -> T2 tuần sau
        self.assertEqual(n, 7)                                     # T2 1 + T3 1 + T4 3 + T5 1 + T6 1 (T7/CN: 0)
        self.assertEqual(c.rollovers(MON, TUE), 1)

    def test_wednesday_rollover_is_triple_and_weekend_is_zero(self):
        c = self.cm()
        wed_before = WED + 20 * 3600.0
        self.assertEqual(c.rollovers(wed_before, wed_before + 3600 * 2), 3)          # qua 21:00 UTC thứ Tư
        self.assertEqual(c.rollovers(SAT, SAT + 86400), 0)
        self.assertEqual(c.rollovers(SUN, SUN + 86400), 0)
        self.assertEqual(c.rollovers(THU + 3600, THU + 7200), 0)                      # không qua giờ rollover nào

    def test_boundaries_are_half_open_and_additive(self):
        c = self.cm()
        r = WED + 21 * 3600.0
        self.assertEqual(c.rollovers(r - 1, r), 3)                 # (t0, t1]: gồm đúng t1
        self.assertEqual(c.rollovers(r, r + 1), 0)                 # không đếm hai lần
        a, b, e = MON, WED + 5 * 3600.0, FRI + 23 * 3600.0
        self.assertEqual(c.rollovers(a, b) + c.rollovers(b, e), c.rollovers(a, e))   # chia nhỏ khoảng thời gian không làm đổi tổng

    def test_swap_amount_uses_rollovers_and_signs(self):
        c = self.cm()
        end = WED + 22 * 3600.0
        long_amt = c.swap_amount(pos("buy", 2.0), 50.0, 3 * 3600.0, end)          # qua rollover T4: x3
        self.assertAlmostEqual(long_amt, 2.0 * 50.0 * 0.1 / 100.0 * 3)
        short_amt = c.swap_amount(pos("sell", 2.0), 50.0, 3 * 3600.0, end)
        self.assertAlmostEqual(short_amt, 2.0 * 50.0 * -0.05 / 100.0 * 3)         # âm = nhận swap
        self.assertEqual(c.swap_amount(pos(), 50.0, 3600.0, THU + 3600.0), 0.0)

    def test_disabled_keeps_old_continuous_behaviour(self):
        c = self.cm(swap_triple_weekday=-1)
        self.assertAlmostEqual(c.swap_amount(pos(), 100.0, 43200.0, WED), 100.0 * 0.1 / 100.0 * 0.5)
        self.assertAlmostEqual(c.swap_amount(pos(), 100.0, 43200.0), 100.0 * 0.1 / 100.0 * 0.5)    # không t_end cũng chạy như cũ
        c2 = self.cm()                                                              # bật nhưng thiếu t_end -> liên tục (an toàn)
        self.assertAlmostEqual(c2.swap_amount(pos(), 100.0, 43200.0), 100.0 * 0.1 / 100.0 * 0.5)

    def test_funding_stays_continuous(self):
        c = self.cm(swap_long_pct_day=0.0, funding_8h_pct=0.01)
        self.assertAlmostEqual(c.swap_amount(pos(), 100.0, 28800.0, SAT), 100.0 * 0.01 / 100.0)

    def test_settings_mapping(self):
        d = default_settings()
        self.assertEqual((d["bt_swap_triple_day"], d["bt_swap_rollover_hour"]), ("off", 21.0))
        self.assertEqual(CostModel.from_settings(d).swap_triple_weekday, -1)
        for name, wd in (("wed", 2), ("fri", 4), ("mon", 0)):
            st = dict(d, bt_swap_triple_day=name, bt_swap_rollover_hour=22.0)
            cm = CostModel.from_settings(st)
            self.assertEqual((cm.swap_triple_weekday, cm.swap_rollover_hour_utc), (wd, 22.0))
        self.assertEqual(clean_settings({"bt_swap_triple_day": "xyz"})["bt_swap_triple_day"], "off")
        self.assertEqual(CostModel.from_settings(dict(d, bt_swap_rollover_hour=30.0)).swap_rollover_hour_utc, 6.0)   # 30 % 24

    def test_per_symbol_override(self):
        c = CostModel(swap_long_pct_day=0.1, swap_triple_weekday=2, per_symbol={"US30": {"swap_triple_weekday": 4}})
        self.assertEqual(c.for_symbol("US30").swap_triple_weekday, 4)
        self.assertEqual(c.for_symbol("EURUSD").swap_triple_weekday, 2)


if __name__ == "__main__":
    unittest.main()


class TestSwapInBacktest(unittest.TestCase):
    def test_position_across_wednesday_pays_triple_in_backtest(self):
        import tempfile
        from pyea.backtest import run_backtest
        from pyea.sdk import Candle
        d = tempfile.mkdtemp()
        p = os.path.join(d, "hold.py")
        with open(p, "w", encoding="utf-8") as f:
            f.write("from pyea import BaseBot\nclass B(BaseBot):\n    def on_bar(self, c):\n        if not self.api.positions():\n            self.api.buy(1.0)\n")
        step = 3600
        candles = [Candle(TUE + i * step, 100.0, 100.0, 100.0, 100.0) for i in range(24 * 2 + 12 + 1)]   # T3 00:00 -> T5 12:00, giá phẳng
        st = default_settings()
        st.update(initial_balance=10000.0, commission_pct=0.0, spread_pct=0.0, leverage=1.0, max_loss_pct=0.0, close_on_stop=True)
        tri = run_backtest(p, {}, st, "EURUSD", "1h", candles, 2, "open",
                           costs=CostModel(spread_pct=0.0, swap_long_pct_day=0.1, swap_triple_weekday=2))
        con = run_backtest(p, {}, st, "EURUSD", "1h", candles, 2, "open",
                           costs=CostModel(spread_pct=0.0, swap_long_pct_day=0.1))
        self.assertTrue(tri.ok and con.ok, (tri.error, con.error))
        s_tri, s_con = tri.report["Swap/Funding"], con.report["Swap/Funding"]
        self.assertGreater(s_tri, 0)
        self.assertGreater(s_con, 0)
        # Giữ lệnh T3 02:00 -> T5 12:00: rollover T3 21:00 (x1) + T4 21:00 (x3) = 4 lần tính; liên tục chỉ ~2,4 ngày
        self.assertAlmostEqual(s_tri, 100.0 * 0.1 / 100.0 * 4, places=6)
        self.assertAlmostEqual(s_con, 100.0 * 0.1 / 100.0 * 58 / 24.0, delta=0.01)
        self.assertGreater(s_tri, s_con * 1.5)
