"""Nhiều tài khoản cùng lúc: sổ hồ sơ + dịch vụ nền chạy song song nhiều phiên (cô lập, chuyển xem, dừng riêng, khôi phục)."""
import json
import os
import sys
import tempfile
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea.accounts import ACCOUNT_DENY, MAIN, AccountBook, slug                    # noqa: E402
from pyea.ipc import ServiceClient, ServiceHandle, ServiceHost                     # noqa: E402
from pyea.keystore import PREFIX                                                   # noqa: E402
from pyea.settings import default_settings                                         # noqa: E402
from pyea.storage import Store                                                     # noqa: E402

SECRET = "SECRET-KEY-VALUE-98765"
HOLD = ("from pyea import BaseBot\\nclass H(BaseBot):\\n    def on_tick(self, t):\\n"
        "        if not self.api.positions(): self.api.buy(%s, reason='giữ')\\n").replace("\\n", "\n")


def S(**over):
    s = default_settings()
    s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=False, initial_balance=10000.0, watchlist="BTCUSD,EURUSD")
    s.update(over)
    return s


def wait(cond, timeout=12.0, step=0.05):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(step)
    return False


class TestAccountBook(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.book = AccountBook(self.d)

    def test_slug_and_unique_ids_and_main_reserved(self):
        self.assertEqual(slug("Binance Futures #1"), "binance-futures-1")
        self.assertEqual(slug("Tài khoản Đầu tư"), "tai-khoan-dau-tu")
        self.assertEqual(slug("Exness VN"), "exness-vn")
        self.assertEqual(slug("???"), "acc")
        a = self.book.add("Exness", S())
        b = self.book.add("Exness", S())
        c = self.book.add("Main", S())
        d = self.book.add("main", S())
        self.assertEqual((a["id"], b["id"]), ("exness", "exness-2"))
        self.assertNotEqual(c["id"], MAIN)
        self.assertNotEqual(d["id"], MAIN)
        with self.assertRaises(ValueError):
            self.book.add("   ", S())

    def test_secrets_sealed_on_disk_but_readable_via_api(self):
        a = self.book.add("Bybit", S(exchange="ccxt", ccxt_id="bybit", ccxt_api_key="AK-" + SECRET, ccxt_secret=SECRET))
        raw = open(self.book.path, encoding="utf-8").read()
        self.assertNotIn(SECRET, raw)
        self.assertIn(PREFIX, raw)
        got = self.book.get(a["id"])
        self.assertEqual(got["settings"]["ccxt_secret"], SECRET)
        self.assertEqual(got["settings"]["ccxt_id"], "bybit")

    def test_app_level_keys_are_not_stored_in_profile(self):
        a = self.book.add("X", S(background_service=False, power_mode="saver", ai_rounds=9))
        for k in ("background_service", "power_mode", "ai_rounds", "ui_refresh"):
            self.assertNotIn(k, a["settings"], k)
        self.assertIn("exchange", a["settings"])
        self.assertTrue(ACCOUNT_DENY)

    def test_effective_settings_profile_overrides_base_but_keeps_app_level(self):
        a = self.book.add("Exness", S(exchange="exness", exness_account="777", initial_balance=2500.0))
        base = S(exchange="simulated", background_service=True, power_mode="saver", initial_balance=10000.0)
        eff = self.book.effective_settings(a["id"], base)
        self.assertEqual((eff["exchange"], eff["exness_account"], eff["initial_balance"]), ("exness", "777", 2500.0))
        self.assertEqual((eff["background_service"], eff["power_mode"]), (True, "saver"))      # cấp app lấy từ base
        with self.assertRaises(KeyError):
            self.book.effective_settings("ghost", base)

    def test_update_enable_remove_and_enabled_filter(self):
        a = self.book.add("A", S())
        b = self.book.add("B", S())
        self.book.update(a["id"], enabled=False, name="  Tên mới ")
        self.assertEqual([x["id"] for x in self.book.enabled()], [b["id"]])
        self.assertEqual(self.book.get(a["id"])["name"], "Tên mới")
        self.book.update(b["id"], settings=S(exchange="oanda", oanda_token="T-" + SECRET))
        self.assertEqual(self.book.get(b["id"])["settings"]["exchange"], "oanda")
        self.assertNotIn(SECRET, open(self.book.path, encoding="utf-8").read())
        self.assertTrue(self.book.remove(a["id"]))
        self.assertFalse(self.book.remove(a["id"]))
        with self.assertRaises(KeyError):
            self.book.update("ghost", enabled=True)

    def test_data_dir_per_account_and_corrupt_file_tolerated(self):
        p = self.book.data_dir_for("exness")
        self.assertTrue(os.path.isdir(p))
        self.assertTrue(p.endswith(os.path.join("accounts", "exness")))
        open(self.book.path, "w").write("{not json")
        self.assertEqual(self.book.list(), [])


class MultiHostBase(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.alarms, self.notes = [], []
        self.host = ServiceHost(self.d, alarm=lambda t, x: self.alarms.append(t), set_notification=lambda t, x: self.notes.append((t, x)),
                                sleep=0.05, exit_grace=0.4, idle_exit=8)
        self.th = threading.Thread(target=self.host.run, daemon=True)
        self.th.start()
        self.client = ServiceClient(self.d)
        self.book = AccountBook(self.d)
        self.bot = os.path.join(self.d, "hold.py")
        open(self.bot, "w", encoding="utf-8").write(HOLD % "0.01")
        self.stop_flag = threading.Event()
        threading.Thread(target=self._ui_beat, daemon=True).start()          # UI "đang mở" -> dịch vụ publish mỗi giây

    def _ui_beat(self):
        while not self.stop_flag.is_set():
            self.client.touch_ui()
            time.sleep(0.2)

    def tearDown(self):
        self.stop_flag.set()
        self.host._exit = True
        self.th.join(5)
        for rt in self.host.rt.values():
            if rt.session is not None and rt.session.is_alive():
                rt.session.stop(wait=True)

    def cfg(self, name, instances=None, **over):
        return {"settings": S(**over), "instances": instances or [], "log_file": None, "trades_csv": None, "account_name": name}

    def start_main(self, **over):
        h = ServiceHandle(self.client, Store(self.d).events_path, pending=True)
        h.start(self.cfg("Chính", **over))
        return h

    def start_extra(self, aid, name, **over):
        ev = os.path.join(self.book.data_dir_for(aid), "events.jsonl")
        hx = ServiceHandle(self.client, ev, pending=True).for_account(aid, ev, pending=True)
        hx.start(self.cfg(name, **over))
        return hx

    def both_alive(self, aid):
        return wait(lambda: self.host.rt[MAIN].session is not None and self.host.rt[MAIN].session.is_alive() and aid in self.host.rt
                    and self.host.rt[aid].session is not None and self.host.rt[aid].session.is_alive())


class TestParallelSessions(MultiHostBase):
    def test_two_accounts_run_concurrently_with_isolated_books(self):
        h = self.start_main(initial_balance=10000.0)
        hx = self.start_extra("exness", "Exness", initial_balance=25000.0)
        self.assertTrue(self.both_alive("exness"))
        self.assertIsNot(self.host.rt[MAIN].session, self.host.rt["exness"].session)
        self.assertTrue(wait(lambda: self.host.rt[MAIN].session.account is not None and self.host.rt["exness"].session.account is not None))
        self.assertEqual(self.host.rt[MAIN].session.account.balance, 10000.0)
        self.assertEqual(self.host.rt["exness"].session.account.balance, 25000.0)
        hx.place_order("EURUSD", "buy", 1000)                                  # lệnh gắn nhãn tài khoản phụ
        self.assertTrue(wait(lambda: len(self.host.rt["exness"].session.account.positions) == 1))
        time.sleep(0.4)
        self.assertEqual(len(self.host.rt[MAIN].session.account.positions), 0)   # tài khoản chính KHÔNG bị ảnh hưởng
        h.place_order("BTCUSD", "buy", 0.01)
        self.assertTrue(wait(lambda: len(self.host.rt[MAIN].session.account.positions) == 1))
        self.assertEqual({p.symbol for p in self.host.rt["exness"].session.account.positions.values()}, {"EURUSD"})
        self.assertEqual({p.symbol for p in self.host.rt[MAIN].session.account.positions.values()}, {"BTCUSD"})

    def test_per_account_files_in_own_directory(self):
        self.start_main()
        hx = self.start_extra("exness", "Exness")
        self.assertTrue(self.both_alive("exness"))
        hx.place_order("EURUSD", "buy", 1000)
        adir = self.book.data_dir_for("exness")
        self.assertTrue(wait(lambda: os.path.exists(os.path.join(adir, "session_state.json")) and os.path.getsize(os.path.join(adir, "session_state.json")) > 10))
        ev_x = os.path.join(adir, "events.jsonl")
        self.assertTrue(wait(lambda: os.path.exists(ev_x) and "EURUSD" in open(ev_x, encoding="utf-8").read()))
        ev_main = Store(self.d).events_path
        self.assertNotIn("EURUSD", open(ev_main, encoding="utf-8").read() if os.path.exists(ev_main) else "")

    def test_view_switch_changes_snapshot_owner_but_all_keep_running(self):
        h = self.start_main(initial_balance=10000.0)
        hx = self.start_extra("exness", "Exness", initial_balance=25000.0)
        self.assertTrue(self.both_alive("exness"))
        self.assertTrue(wait(lambda: h.snapshot() is not None))
        self.assertEqual(h.view_account(), "main")
        self.assertIsNone(hx.snapshot())                                       # đang xem tài khoản chính
        h.set_view("exness")
        self.assertTrue(wait(lambda: hx.snapshot() is not None))
        self.assertEqual(hx.view_account(), "exness")
        self.assertIsNone(h.snapshot())
        self.assertAlmostEqual(hx.snapshot()["equity"], 25000.0, 2)
        h.set_view("main")
        self.assertTrue(wait(lambda: h.snapshot() is not None))
        self.assertTrue(self.host.rt["exness"].session.is_alive() and self.host.rt[MAIN].session.is_alive())

    def test_view_of_unknown_account_ignored(self):
        h = self.start_main()
        self.assertTrue(wait(lambda: h.snapshot() is not None))
        h.set_view("ghost")
        time.sleep(0.5)
        self.assertEqual(h.view_account(), "main")
        self.client.send("order", account="ghost", symbol="BTCUSD", side="buy", volume=0.01)      # lệnh cho tài khoản không tồn tại
        time.sleep(0.5)
        self.assertNotIn("ghost", self.host.rt)
        self.assertEqual(len(self.host.rt[MAIN].session.account.positions), 0)

    def test_accounts_summary_lists_every_running_account(self):
        h = self.start_main(initial_balance=10000.0, exchange="simulated")
        self.start_extra("exness", "Exness", initial_balance=25000.0)
        self.assertTrue(self.both_alive("exness"))
        self.assertTrue(wait(lambda: len(h.accounts()) == 2))
        rows = {r["id"]: r for r in h.accounts()}
        self.assertEqual(set(rows), {"main", "exness"})
        self.assertEqual(rows["exness"]["name"], "Exness")
        self.assertTrue(rows["main"]["alive"] and rows["exness"]["alive"])
        self.assertTrue(wait(lambda: {r["id"]: r for r in h.accounts()}["exness"].get("equity") == 25000.0))

    def test_alarm_from_secondary_account_session_thread_is_labelled(self):
        self.start_main()
        hx = self.start_extra("exness", "Exness")
        self.assertTrue(self.both_alive("exness"))
        hx.kill_switch("thử")                                                   # alarm phát từ LUỒNG PHIÊN của tài khoản phụ
        self.assertTrue(wait(lambda: any(a.startswith("[Exness]") and "KILL SWITCH" in a for a in self.alarms), 10), self.alarms)
        self.assertFalse(any("KILL SWITCH" in a and not a.startswith("[Exness]") for a in self.alarms), self.alarms)

    def test_kill_on_one_account_does_not_touch_the_other(self):
        h = self.start_main(initial_balance=100000.0)
        hx = self.start_extra("exness", "Exness", initial_balance=100000.0)
        self.assertTrue(self.both_alive("exness"))
        self.assertTrue(wait(lambda: self.host.rt["exness"].session.account is not None))
        hx.kill_switch("chỉ tài khoản phụ")
        self.assertTrue(wait(lambda: self.host.rt["exness"].session.halted is True))
        self.assertFalse(self.host.rt[MAIN].session.halted)
        hx.place_order("EURUSD", "buy", 1000)                                   # tài khoản phụ đã khoá: lệnh bị chặn
        h.place_order("BTCUSD", "buy", 0.01)                                    # tài khoản chính vẫn giao dịch bình thường
        self.assertTrue(wait(lambda: len(self.host.rt[MAIN].session.account.positions) == 1))
        time.sleep(0.4)
        self.assertEqual(len(self.host.rt["exness"].session.account.positions), 0)

    def test_stop_one_account_keeps_the_other_and_updates_desired(self):
        h = self.start_main()
        hx = self.start_extra("exness", "Exness")
        self.assertTrue(self.both_alive("exness"))
        hx.stop()
        self.assertTrue(wait(lambda: not self.host.rt["exness"].session.is_alive()))
        self.assertTrue(self.host.rt[MAIN].session.is_alive())
        self.assertTrue(wait(lambda: (self.client.read_desired() or {}).get("extra", {}).get("exness", {}).get("running") is False))
        d = self.client.read_desired()
        self.assertTrue(d["running"])                                         # tài khoản chính vẫn "cần chạy"

    def test_notification_mentions_secondary_accounts(self):
        self.start_main()
        self.start_extra("exness", "Exness")
        self.assertTrue(self.both_alive("exness"))
        self.assertTrue(wait(lambda: any("tài khoản phụ" in x for _t, x in self.notes), 15), self.notes[-2:])

    def test_host_exits_only_after_every_session_has_finished(self):
        h = self.start_main()
        hx = self.start_extra("exness", "Exness")
        self.assertTrue(self.both_alive("exness"))
        h.stop()
        self.assertTrue(wait(lambda: not self.host.rt[MAIN].session.is_alive()))
        time.sleep(1.0)                                                       # > exit_grace: nhưng tài khoản phụ vẫn chạy
        self.assertTrue(self.th.is_alive())
        self.assertTrue(self.host.rt["exness"].session.is_alive())
        hx.stop()
        self.th.join(8)
        self.assertFalse(self.th.is_alive())

    def test_extra_only_without_main_session(self):
        hx = self.start_extra("solo", "Solo")
        self.assertTrue(wait(lambda: "solo" in self.host.rt and self.host.rt["solo"].session is not None and self.host.rt["solo"].session.is_alive()))
        self.assertIsNone(self.host.rt[MAIN].session)
        self.assertTrue(wait(lambda: any("solo" == r["id"] for r in hx.accounts())))
        hx.set_view("solo")
        self.assertTrue(wait(lambda: hx.snapshot() is not None))                # publish tự rơi về tài khoản đang chạy khi chính chưa có phiên

    def test_bots_attach_per_account(self):
        inst = lambda iid, sym: {"iid": iid, "bot_path": self.bot, "symbol": sym, "tf": "1m", "params": {}, "running": True}       # noqa: E731
        ev = os.path.join(self.book.data_dir_for("exness"), "events.jsonl")
        h = ServiceHandle(self.client, Store(self.d).events_path, pending=True)
        h.start(self.cfg("Chính", instances=[inst("m1", "BTCUSD")], initial_balance=100000.0))
        hx = h.for_account("exness", ev, pending=True)
        hx.start(self.cfg("Exness", instances=[inst("x1", "EURUSD")], initial_balance=100000.0))
        self.assertTrue(self.both_alive("exness"))
        self.assertTrue(wait(lambda: self.host.rt[MAIN].session.instances["m1"].status == "running"))
        self.assertTrue(wait(lambda: self.host.rt["exness"].session.instances["x1"].status == "running"))
        self.assertEqual(set(self.host.rt[MAIN].session.instances), {"m1"})
        self.assertEqual(set(self.host.rt["exness"].session.instances), {"x1"})
        self.assertTrue(wait(lambda: any(p.symbol == "EURUSD" for p in self.host.rt["exness"].session.account.positions.values())))
        self.assertTrue(wait(lambda: any(p.symbol == "BTCUSD" for p in self.host.rt[MAIN].session.account.positions.values())))
        self.assertFalse(any(p.symbol == "EURUSD" for p in self.host.rt[MAIN].session.account.positions.values()))
        hx.detach("x1")
        self.assertTrue(wait(lambda: "x1" not in self.host.rt["exness"].session.instances))
        self.assertIn("m1", self.host.rt[MAIN].session.instances)


class TestDesiredAndResume(unittest.TestCase):
    def test_secrets_of_every_account_sealed_in_desired_and_ipc_files(self):
        d = tempfile.mkdtemp()
        host = ServiceHost(d, sleep=0.05, exit_grace=0.2, idle_exit=5)
        host.start_session(dict({"settings": S(api_secret=SECRET), "instances": [], "log_file": None, "trades_csv": None, "token": "t1"}))
        host._cur = host._runtime("exness", create=True, name="Exness")
        host.start_session({"settings": S(ccxt_secret=SECRET, exchange="simulated"), "instances": [], "log_file": None, "trades_csv": None, "token": "t2",
                            "account_name": "Exness"})
        host._cur = host.rt[MAIN]
        raw = open(os.path.join(d, "ipc", "desired.json"), encoding="utf-8").read()
        self.assertNotIn(SECRET, raw)
        self.assertGreaterEqual(raw.count(PREFIX), 2)
        back = ServiceClient(d).read_desired()
        self.assertEqual(back["config"]["settings"]["api_secret"], SECRET)
        self.assertEqual(back["extra"]["exness"]["config"]["settings"]["ccxt_secret"], SECRET)
        self.assertTrue(back["extra"]["exness"]["running"])
        for rt in host.rt.values():
            rt.session.stop(wait=True)

    def test_crash_recovery_restores_both_accounts_with_their_positions(self):
        d = tempfile.mkdtemp()
        alarms = []
        bot = os.path.join(d, "hold.py")
        open(bot, "w", encoding="utf-8").write(HOLD % "0.01")

        def cfg(iid, tok, name):
            return {"settings": S(initial_balance=100000.0), "token": tok, "log_file": None, "trades_csv": None, "account_name": name,
                    "instances": [{"iid": iid, "bot_path": bot, "symbol": "BTCUSD", "tf": "1m", "params": {}, "running": True}]}
        h1 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
        h1.start_session(cfg("m1", "t1", "Chính"))
        h1._cur = h1._runtime("exness", create=True, name="Exness")
        h1.start_session(cfg("x1", "t2", "Exness"))
        h1._cur = h1.rt[MAIN]
        self.assertTrue(wait(lambda: h1.rt[MAIN].session.account.positions and h1.rt["exness"].session.account.positions, 12))
        pm = list(h1.rt[MAIN].session.account.positions)[0]
        px = list(h1.rt["exness"].session.account.positions)[0]
        for rt in h1.rt.values():
            rt.session.stop(wait=True)                                         # "crash": phiên chết nhưng desired vẫn running
        c = ServiceClient(d)
        c.write_desired({"running": True, "config": cfg("m1", "t1", "Chính"), "extra": {"exness": {"running": True, "name": "Exness", "config": cfg("x1", "t2", "Exness")}}})
        h2 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
        th = threading.Thread(target=h2.run, daemon=True)
        th.start()
        self.assertTrue(wait(lambda: h2.rt[MAIN].session is not None and h2.rt.get("exness") is not None and h2.rt["exness"].session is not None, 12))
        self.assertTrue(wait(lambda: pm in h2.rt[MAIN].session.account.positions and px in h2.rt["exness"].session.account.positions, 12))
        self.assertEqual(h2.rt["exness"].session.account.positions[px].owner, "x1")
        self.assertEqual(h2.rt[MAIN].session.account.positions[pm].owner, "m1")
        time.sleep(0.8)
        self.assertEqual(len(h2.rt["exness"].session.account.positions), 1)        # bot nhận lại lệnh của mình, không mở thêm
        self.assertEqual(len(h2.rt[MAIN].session.account.positions), 1)
        self.assertEqual(h2.rt["exness"].name, "Exness")
        self.assertTrue(any("khôi phục" in a for a in alarms), alarms)
        h2._exit = True
        th.join(5)
        for rt in h2.rt.values():
            rt.session.stop(wait=True)

    def test_storm_guard_blocks_all_accounts(self):
        d = tempfile.mkdtemp()
        alarms = []
        cfg = {"settings": S(), "token": "t", "log_file": None, "trades_csv": None, "instances": []}
        ServiceClient(d).write_desired({"running": True, "config": cfg, "restarts": [time.time()] * 3,
                                        "extra": {"exness": {"running": True, "name": "E", "config": dict(cfg, token="t2")}}})
        h = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, idle_exit=0.3)
        h.run()
        self.assertIsNone(h.rt[MAIN].session)
        self.assertNotIn("exness", h.rt)
        self.assertTrue(any("crash liên tục" in a for a in alarms))
        self.assertFalse(ServiceClient(d).read_desired()["extra"]["exness"]["running"])

    def test_extra_only_resume_and_auto_resume_off(self):
        d = tempfile.mkdtemp()
        cfg = {"settings": S(auto_resume=False), "token": "t", "log_file": None, "trades_csv": None, "instances": []}
        ServiceClient(d).write_desired({"running": False, "extra": {"e1": {"running": True, "name": "E1", "config": cfg}}})
        h = ServiceHost(d, sleep=0.05, idle_exit=0.3)
        h.run()
        self.assertNotIn("e1", h.rt)                                           # auto_resume tắt: không tự chạy lại
        self.assertFalse(ServiceClient(d).read_desired()["extra"]["e1"]["running"])
        cfg2 = {"settings": S(), "token": "t3", "log_file": None, "trades_csv": None, "instances": []}
        ServiceClient(d).write_desired({"running": False, "extra": {"e2": {"running": True, "name": "E2", "config": cfg2}}})
        h2 = ServiceHost(d, sleep=0.05, exit_grace=0.2, idle_exit=0.3)
        th = threading.Thread(target=h2.run, daemon=True)
        th.start()
        self.assertTrue(wait(lambda: "e2" in h2.rt and h2.rt["e2"].session is not None and h2.rt["e2"].session.is_alive(), 10))
        self.assertIsNone(h2.rt[MAIN].session)
        h2._exit = True
        th.join(5)
        h2.rt["e2"].session.stop(wait=True)


if __name__ == "__main__":
    unittest.main()
