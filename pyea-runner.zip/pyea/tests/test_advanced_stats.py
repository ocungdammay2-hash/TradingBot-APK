import json
import os
import sys
import threading
import unittest
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))

from pyea import mcarlo, genetic, webhook          # noqa: E402
from pyea.sdk import Trade                          # noqa: E402


def T(i, p, day=0):
    t0 = 1_760_000_000 + i * 86400 + day * 86400 * 30
    return Trade(id=i, symbol="EURUSD", side="buy", volume=1, open_price=1, close_price=1, open_time=t0, close_time=t0 + 3600, profit=p, reason="Bot")


class StatsTest(unittest.TestCase):
    def test_basic(self):
        trades = [T(i, p) for i, p in enumerate([10, -5, 8, -4, 12, -6, 9])]
        s = mcarlo.extra_stats(trades, 1000)
        self.assertIsNotNone(s["Sortino (theo lệnh)"])
        self.assertGreater(s["Kỳ vọng (R)"], 0)
        self.assertEqual(mcarlo.max_drawdown([-100, 50], 1000), (100.0, 10.0))
        self.assertIsNone(mcarlo.sortino([1, 2], 100))
        self.assertIsNone(mcarlo.sortino([1, 2, 3, 4], 100))          # không có lỗ -> không xác định, không bịa số

    def test_monthly(self):
        m = mcarlo.monthly([T(0, 5), T(1, -2), T(2, 3, day=1)])
        self.assertEqual(sum(x["n"] for x in m), 3)
        self.assertAlmostEqual(sum(x["net"] for x in m), 6)

    def test_r_given_risk(self):
        r = mcarlo.r_multiples([T(0, 20), T(1, -10)], risk_per_trade=10)
        self.assertEqual(r["R"], [2.0, -1.0])

    def test_mc_deterministic_and_shuffle_keeps_total(self):
        tr = [T(i, p) for i, p in enumerate([30, -20, 15, -10, 25, -30, 40, -15])]
        a = mcarlo.monte_carlo(tr, 1000, 300, "shuffle", seed=7)
        b = mcarlo.monte_carlo(tr, 1000, 300, "shuffle", seed=7)
        self.assertEqual(a, b)
        self.assertAlmostEqual(a["final_p5"], 1035.0)                 # hoán vị giữ nguyên tổng lãi
        self.assertAlmostEqual(a["final_p95"], 1035.0)
        self.assertGreaterEqual(a["dd_p95"], a["dd_p50"])
        c = mcarlo.monte_carlo(tr, 1000, 300, "bootstrap", seed=7)
        self.assertLessEqual(c["final_p5"], c["final_p95"])
        self.assertFalse(mcarlo.monte_carlo([], 1000)["ok"])
        self.assertIn("Monte Carlo", mcarlo.monte_carlo_text(a))
        with self.assertRaises(ValueError):
            mcarlo.monte_carlo(tr, 1000, 10, "x")


class GeneticTest(unittest.TestCase):
    def test_finds_optimum_with_fewer_evals_than_grid(self):
        grid = {"a": list(range(1, 21)), "b": list(range(1, 21)), "c": list(range(1, 11))}     # 4000 tổ hợp
        calls = []

        def ev(p):
            calls.append(1)
            return -((p["a"] - 13) ** 2) - ((p["b"] - 7) ** 2) - ((p["c"] - 4) ** 2)
        res = genetic.genetic_search(grid, ev, population=24, generations=15, seed=3, max_evals=400)
        self.assertLessEqual(len(calls), 400)
        self.assertGreaterEqual(res[0]["score"], -3)               # rất gần đỉnh (0) với <10% số lần của lưới
        self.assertEqual(len(calls), len({tuple(sorted(r["params"].items())) for r in res}))   # mỗi tổ hợp chạy đúng 1 lần
        again = genetic.genetic_search(grid, ev, population=24, generations=15, seed=3, max_evals=400)
        self.assertEqual(res[0]["params"], again[0]["params"])

    def test_errors_and_stop(self):
        def bad(p):
            raise RuntimeError("x")
        res = genetic.genetic_search({"a": [1, 2, 3]}, bad, population=3, generations=2, seed=1)
        self.assertTrue(all(r["score"] <= -1e29 for r in res))
        ev = threading.Event()
        ev.set()
        self.assertEqual(genetic.genetic_search({"a": [1, 2]}, lambda p: 1, stop_event=ev, seed=1)[0]["score"], 1)
        self.assertEqual(genetic.genetic_search({}, lambda p: 1), [])


class WebhookTest(unittest.TestCase):
    SECRET = "s3cret-long-enough"

    def core(self, **kw):
        self.calls = []
        kw.setdefault("clock", lambda: 1000.0)
        return webhook.WebhookCore(lambda o: self.calls.append(o) or {"ok": True}, self.SECRET, **kw)

    def body(self, **kw):
        d = {"secret": self.SECRET, "id": "a1", "action": "buy", "symbol": "eurusd", "volume": 0.01}
        d.update(kw)
        return json.dumps(d).encode()

    def test_ok_and_validation(self):
        c = self.core(allowed_symbols=["EURUSD"], max_volume=0.1)
        st, r = c.handle(self.body())
        self.assertEqual((st, r["ok"]), (200, True))
        self.assertEqual(self.calls[0]["symbol"], "EURUSD")
        for bad, code in ((dict(secret="sai-sai-sai-sai"), 401), (dict(action="x"), 400), (dict(volume=-1, id="b"), 400),
                          (dict(volume=1, id="c"), 403), (dict(symbol="XAUUSD", id="d"), 403), (dict(volume="a", id="e"), 400)):
            self.assertEqual(c.handle(self.body(**bad))[0], code, bad)
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(c.handle(b"not json")[0], 400)
        self.assertEqual(c.handle(b"[1]")[0], 400)
        self.assertEqual(c.handle(b"x" * 5000)[0], 413)

    def test_idempotent_ip_rate_hmac_dry(self):
        c = self.core()
        c.handle(self.body())
        st, r = c.handle(self.body())
        self.assertTrue(r.get("duplicate"))
        self.assertEqual(len(self.calls), 1)
        c = self.core(allowed_ips=webhook.TV_IPS)
        self.assertEqual(c.handle(self.body(), ip="1.2.3.4")[0], 403)
        self.assertEqual(c.handle(self.body(), ip="52.89.214.238")[0], 200)
        c = self.core(rate_per_min=2)
        codes = [c.handle(self.body(id="r%d" % i))[0] for i in range(3)]
        self.assertEqual(codes, [200, 200, 429])
        import hashlib
        import hmac as h
        c = self.core(hmac_secret="k" * 16)
        b = self.body()
        self.assertEqual(c.handle(b, signature="00")[0], 401)
        self.assertEqual(c.handle(b, signature=h.new(b"k" * 16, b, hashlib.sha256).hexdigest())[0], 200)
        c = self.core(dry_run=True)
        self.assertTrue(c.handle(self.body())[1]["dry_run"])
        with self.assertRaises(ValueError):
            webhook.WebhookCore(lambda o: 0, "short")

    def test_executor_error_does_not_crash(self):
        c = webhook.WebhookCore(lambda o: 1 / 0, self.SECRET)
        st, r = c.handle(self.body())
        self.assertEqual(st, 200)
        self.assertFalse(r["result"]["ok"])

    def test_http_route_and_gateway_executor(self):
        import mt_gateway as gw

        class Be:
            def __init__(s):
                s.log = []
            def market(s, sym, side, vol, comment=""):
                s.log.append(("market", sym, side, vol)); return {"position_id": "9"}
            def modify_position(s, pid, sl, tp):
                s.log.append(("sltp", pid, sl, tp)); return {}
            def positions(s):
                return {"positions": [{"id": "9", "symbol": "EURUSD"}, {"id": "10", "symbol": "XAUUSD"}]}
            def close(s, pid, volume=None):
                s.log.append(("close", pid)); return {}
        be = Be()
        wh = webhook.WebhookCore(webhook.gateway_executor(be), self.SECRET)
        srv = gw.serve(be, "127.0.0.1", 0, token="tok-tok-tok-tok", webhook=wh)
        port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            def post(path, data, hdr=None):
                rq = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), data=data, method="POST", headers=hdr or {})
                try:
                    with urllib.request.urlopen(rq, timeout=5) as r:
                        return r.status, json.loads(r.read())
                except urllib.error.HTTPError as e:
                    return e.code, json.loads(e.read())
            st, r = post("/v1/webhook/tradingview", self.body(sl=1.05, tp=1.2))
            self.assertEqual(st, 200, r)
            self.assertEqual(be.log, [("market", "EURUSD", "buy", 0.01), ("sltp", "9", 1.05, 1.2)])
            st, _ = post("/v1/webhook/tradingview", self.body(id="z", secret="nope-nope-nope"))
            self.assertEqual(st, 401)
            self.assertEqual(post("/v1/market", b"{}")[0], 401)       # đường khác vẫn cần Bearer
            st, r = post("/v1/webhook/tradingview", self.body(id="y", action="close", symbol="EURUSD"))
            self.assertEqual(be.log[-1], ("close", "9"))
        finally:
            srv.shutdown()


if __name__ == "__main__":
    unittest.main()
