"""Ánh xạ trường DÙNG CHUNG cho mọi sàn (pyea/fieldmap.py): bảng bí danh chung + ghi đè tay trong Cài đặt thay cho việc sửa mã từng sàn.

Kiểm: dò tên không phân biệt hoa thường/dấu, ghi đè theo sàn thắng «*» thắng bảng chung và KHÔNG lặng lẽ rơi về bảng chung, đọc lồng, kiểm hợp lệ JSON ghi đè,
thêm một ghi đè an toàn, chẩn đoán (khớp/thiếu/khoá số chưa dùng), nối vào số tài khoản/vị thế/lịch sử/SLTP của Exness và vào «Kiểm tra hệ thống»."""
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))
sys.path.insert(0, HERE)

from pyea import acctstate, exness, fieldmap as fm                           # noqa: E402


class Base(unittest.TestCase):
    def setUp(self):
        fm.configure("")
        fm.forget()

    tearDown = setUp


class TestLookup(Base):
    def test_names_match_regardless_of_case_and_separators(self):
        for key in ("free_margin", "freeMargin", "FreeMargin", "FREE-MARGIN", "margin_free", "marginAvailable"):
            self.assertEqual(fm.pick("account", {key: 7}, "free_margin"), 7, key)

    def test_missing_or_empty_is_none_and_zero_is_kept(self):
        self.assertIsNone(fm.pick("account", {"balance": None}, "balance"))
        self.assertIsNone(fm.pick("account", {"balance": ""}, "balance"))
        self.assertEqual(fm.pick("account", {"balance": 0}, "balance"), 0)           # 0 là số thật, không phải «sàn không báo»
        self.assertIsNone(fm.pick("account", {}, "balance"))
        self.assertIsNone(fm.pick("account", "junk", "balance"))

    def test_alias_priority_follows_the_table_order(self):
        self.assertEqual(fm.pick("account", {"nav": 1, "equity": 2}, "equity"), 2)
        self.assertEqual(fm.pick("account", {"nav": 1}, "equity"), 1)

    def test_extra_aliases_apply_only_to_that_call(self):
        self.assertIsNone(fm.pick("account", {"net_liq": 5}, "equity"))
        self.assertEqual(fm.pick("account", {"net_liq": 5}, "equity", extra=("net_liq",)), 5)
        self.assertIsNone(fm.pick("account", {"net_liq": 5}, "equity"))

    def test_nested_search_only_when_depth_allows(self):
        rec = {"data": {"acct": {"equity": 9}}}
        self.assertIsNone(fm.pick("account", rec, "equity"))
        self.assertIsNone(fm.pick("account", rec, "equity", depth=1))
        self.assertEqual(fm.pick("account", rec, "equity", depth=2), 9)
        v, p = fm.lookup("account", rec, "equity", depth=2)
        self.assertEqual(p, "data.acct.equity")

    def test_trade_profit_never_falls_back_to_amount_because_amount_may_be_a_quantity(self):
        self.assertIsNone(fm.pick("deal", {"amount": 5}, "profit"))
        self.assertEqual(fm.pick("deal", {"amount": 5}, "amount"), 5)                # deal tài chính: amount là số tiền

    def test_num_accepts_decimal_strings_and_rejects_garbage(self):
        self.assertEqual(fm.num("1.50"), 1.5)
        for bad in (None, "", "x", True, float("nan"), float("inf"), [], {}):
            self.assertIsNone(fm.num(bad), bad)


class TestOverrides(Base):
    def test_override_beats_the_shared_table(self):
        fm.configure({"field_overrides": json.dumps({"acme": {"account": {"equity": "net_value"}}})})
        rec = {"equity": 1, "net_value": 2}
        self.assertEqual(fm.pick("account", rec, "equity", "acme"), 2)
        self.assertEqual(fm.pick("account", rec, "equity", "other"), 1)              # chỉ áp cho đúng sàn đã khai
        self.assertEqual(fm.pick("account", rec, "equity"), 1)

    def test_specific_exchange_beats_star(self):
        fm.configure(json.dumps({"*": {"account": {"equity": "a"}}, "acme": {"account": {"equity": "b"}}}))
        rec = {"a": 1, "b": 2}
        self.assertEqual(fm.pick("account", rec, "equity", "acme"), 2)
        self.assertEqual(fm.pick("account", rec, "equity", "zzz"), 1)

    def test_override_pointing_at_a_missing_key_does_not_silently_use_the_table(self):
        fm.configure({"field_overrides": {"acme": {"account": {"equity": "net_value"}}}})
        self.assertIsNone(fm.pick("account", {"equity": 1}, "equity", "acme"))      # cấu hình sai phải lộ ra («-»), không được che bằng số khác

    def test_override_supports_dotted_paths_and_normalised_names(self):
        fm.configure({"field_overrides": {"*": {"position": {"profit": "pl.Unrealized_Total"}}}})
        self.assertEqual(fm.pick("position", {"pl": {"unrealizedTotal": 3.5}}, "profit"), 3.5)

    def test_invalid_overrides_are_rejected_with_reasons_and_valid_ones_kept(self):
        ov, errs = fm.parse_overrides(json.dumps({
            "acme": {"account": {"equity": "net", "bogus": "x", "balance": "a b"}, "nokind": {"x": "y"}, "deal": "str"},
            "bad": 5}))
        self.assertEqual(ov, {"acme": {"account": {"equity": "net"}}})
        self.assertEqual(len(errs), 5, errs)
        for text in ("{not json", "[1]", '"x"'):
            ov, errs = fm.parse_overrides(text)
            self.assertEqual(ov, {})
            self.assertTrue(errs, text)
        self.assertEqual(fm.parse_overrides(""), ({}, []))
        self.assertEqual(fm.parse_overrides(None), ({}, []))

    def test_unsafe_paths_are_refused(self):
        for bad in ("a/b", "a..b", ".a", "a b", "a;b", "x" * 0, "a.b.c.d.e.f.g"):
            ov, errs = fm.parse_overrides({"*": {"account": {"equity": bad}}})
            self.assertEqual(ov, {}, bad)
            self.assertTrue(errs, bad)

    def test_configure_replaces_the_whole_set_and_returns_errors(self):
        fm.configure({"field_overrides": {"a": {"account": {"equity": "x"}}}})
        self.assertEqual(fm.overrides(), {"a": {"account": {"equity": "x"}}})
        errs = fm.configure({"field_overrides": "{oops"})
        self.assertTrue(errs)
        self.assertEqual(fm.overrides(), {})                                         # JSON hỏng: không giữ cấu hình cũ nửa vời

    def test_add_override_validates_before_accepting_and_merges(self):
        t, errs = fm.add_override("", "acme", "position", "profit", "pnl_now")
        self.assertEqual(errs, [])
        t, errs = fm.add_override(t, "acme", "deal", "amount", "sum")
        self.assertEqual(errs, [])
        self.assertEqual(json.loads(t), {"acme": {"position": {"profit": "pnl_now"}, "deal": {"amount": "sum"}}})
        t2, errs = fm.add_override(t, "acme", "position", "nonsense", "x")
        self.assertTrue(errs)
        self.assertEqual(t2, t)                                                       # lỗi: giữ nguyên bản cũ
        t3, errs = fm.add_override(t, "acme", "position", "profit", "bad path!")
        self.assertTrue(errs)
        self.assertEqual(t3, t)
        t4, errs = fm.add_override(t, None, "account", "equity", "x")
        self.assertEqual(json.loads(t4)["*"], {"account": {"equity": "x"}})


class TestDiagnose(Base):
    def test_reports_mapped_missing_and_unused_numeric_keys(self):
        rec = {"balance": 10, "total_value": 11, "margin": 2, "label": "x", "extra_num": "3.5", "nested": {"a": 1}}
        d = fm.diagnose("account", rec)
        self.assertEqual(d["mapped"]["balance"], "balance")
        self.assertIn("equity", d["missing"])
        self.assertEqual(d["core_missing"], ["equity"])                               # margin có, equity thiếu -> thiếu cần thiết
        self.assertEqual(sorted(d["unmatched"]), ["extra_num", "total_value"])        # ứng viên để ghi đè (số, chưa trường nào dùng)
        self.assertNotIn("label", d["unmatched"])
        self.assertNotIn("nested", d["unmatched"])

    def test_override_is_listed_and_fixes_the_core_field(self):
        fm.configure({"field_overrides": {"acme": {"account": {"equity": "total_value"}}}})
        d = fm.diagnose("account", {"balance": 10, "total_value": 11, "margin": 2}, "acme")
        self.assertEqual(d["core_missing"], [])
        self.assertEqual(d["overridden"], ["equity"])
        self.assertEqual(d["mapped"]["equity"], "total_value")

    def test_report_uses_the_last_raw_record_seen_per_exchange(self):
        acctstate.normalize({"balance": 5, "equity": 5, "used_margin": 1}, "acme")
        rep = fm.report("acme")
        self.assertEqual(set(rep), {"account"})
        self.assertEqual(rep["account"]["mapped"]["margin"], "used_margin")
        self.assertEqual(fm.report("other"), {})
        text = fm.format_report(rep)
        self.assertIn("equity←equity", text)
        self.assertIn("margin←used_margin", text)

    def test_format_report_flags_core_missing_and_candidates(self):
        acctstate.normalize({"balance": 5, "mystery_equity": 5}, "acme")
        text = fm.format_report(fm.report("acme"))
        self.assertIn("THIẾU CẦN THIẾT: equity, margin", text)
        self.assertIn("mystery_equity", text)


class TestAccountAndPositionStats(Base):
    def test_exchange_specific_override_fixes_the_account_numbers_without_code_changes(self):
        raw = {"cash": 1000.0, "net_asset_value": 1100.0, "im": 100.0}
        self.assertIsNone(acctstate.normalize(raw, "acme"))                           # trước: không đọc được -> «-»/sổ app
        fm.configure({"field_overrides": {"acme": {"account": {"balance": "cash", "equity": "net_asset_value", "margin": "im"}}}})
        st = acctstate.normalize(raw, "acme")
        self.assertEqual((st["balance"], st["equity"], st["margin"]), (1000.0, 1100.0, 100.0))
        self.assertAlmostEqual(st["margin_level"], 1100.0)                            # phần tính (mức ký quỹ...) vẫn theo định nghĩa MT5
        self.assertIsNone(acctstate.normalize(raw, "other"))                          # sàn khác không bị ảnh hưởng

    def test_position_stats_use_the_same_layer(self):
        rows = [{"id": "7", "floating_pl": 3.0, "swap_fee": -1.0}]
        self.assertEqual(acctstate.normalize_position_stats(rows, "acme"), {})
        fm.configure({"field_overrides": {"acme": {"position": {"profit": "floating_pl", "swap": "swap_fee"}}}})
        self.assertEqual(acctstate.normalize_position_stats(rows, "acme"), {"7": {"profit": 3.0, "swap": -1.0}})


class TestExnHistory(Base):
    DEALS = {"deals": [
        {"deal_id": "1", "event_time": "2026-10-30T10:00:00Z", "deal_type": "open", "instrument": "EURUSD", "side": "buy", "volume": "0.1", "price": "1.1", "position_id": "P1",
         "order_id": "O1", "pl_gross": "0", "fees": "-0.5"},
        {"deal_id": "2", "event_time": "2026-10-30T11:00:00Z", "deal_type": "close", "instrument": "EURUSD", "side": "sell", "volume": "0.1", "price": "1.11", "position_id": "P1",
         "order_id": "O2", "pl_gross": "100", "fees": "-0.5"},
        {"deal_id": "3", "event_time": "2026-10-30T12:00:00Z", "deal_type": "balance", "sum": "1000"},
        {"deal_id": "4", "event_time": "2026-10-30T13:00:00Z", "deal_type": "swap_fee", "sum": "-2.5"}]}

    def test_unfamiliar_names_show_up_as_missing_then_an_override_fixes_them(self):
        rows = exness.normalize_history(self.DEALS)
        by = {r["id"]: r for r in rows}
        self.assertEqual(by["2"]["profit"], 0.0)                                       # tên «pl_gross» chưa biết
        self.assertEqual(by["3"]["profit"], 0.0)
        rep = fm.report("exness")["deal"]
        self.assertIn("profit", rep["missing"])
        self.assertIn("pl_gross", rep["unmatched"])                                    # chẩn đoán gợi ý đúng khoá cần ghi đè
        self.assertIn("sum", rep["unmatched"])
        fm.configure({"field_overrides": {"exness": {"deal": {"profit": "pl_gross", "amount": "sum", "commission": "fees"}}}})
        rows = exness.normalize_history(self.DEALS)
        by = {r["id"]: r for r in rows}
        self.assertEqual((by["2"]["profit"], by["2"]["commission"]), (100.0, -0.5))
        self.assertEqual((by["3"]["kind"], by["3"]["profit"]), ("balance", 1000.0))
        self.assertEqual((by["4"]["kind"], by["4"]["swap"]), ("other", -2.5))

    def test_summary_over_overridden_names_matches_mt5_definitions(self):
        from pyea import brokerhist
        fm.configure({"field_overrides": {"exness": {"deal": {"profit": "pl_gross", "amount": "sum", "commission": "fees"}}}})
        sm = brokerhist.summarize(exness.normalize_history(self.DEALS))
        self.assertAlmostEqual(sm["profit"], 100.0)
        self.assertAlmostEqual(sm["deposit"], 1000.0)
        self.assertAlmostEqual(sm["swap"], -2.5)
        self.assertAlmostEqual(sm["commission"], -1.0)
        self.assertEqual(sm["positions"], 1)

    def test_default_names_still_work_with_no_configuration(self):
        raw = {"deals": [{"deal_id": "9", "event_time": 1_790_000_000, "deal_type": "close", "instrument": "XAUUSD", "side": "sell", "volume": 1, "price": 2000,
                          "position_id": "P", "profit": 12.5, "commission": -1, "swap": -0.5},
                         {"deal_id": "8", "event_time": 1_790_000_001, "deal_type": "balance", "amount": 50}]}
        rows = {r["id"]: r for r in exness.normalize_history(raw)}
        self.assertEqual((rows["9"]["profit"], rows["9"]["commission"], rows["9"]["swap"], rows["9"]["entry"]), (12.5, -1.0, -0.5, "OUT"))
        self.assertEqual((rows["8"]["kind"], rows["8"]["profit"]), ("balance", 50.0))

    def test_old_deal_contract_uses_the_same_layer(self):
        fm.configure({"field_overrides": {"exness": {"deal": {"profit": "pl_gross", "commission": "fees"}}}})
        rows = exness.normalize_deals(self.DEALS)
        close = next(r for r in rows if r["id"] == "2")
        self.assertEqual((close["pnl"], close["fee"], close["entry"], close["position_id"]), (100.0, -0.5, "OUT", "P1"))


try:
    import test_protect_contract as tc
    HAVE = tc.HAVE_CRYPTO
except Exception:                                                                       # noqa: BLE001
    HAVE = False


@unittest.skipUnless(HAVE, "cần cryptography")
class TestExnSltpKeyOverride(Base):
    """Tên khoá mã vị thế khi TẠO lệnh SLTP không có trong tài liệu: không đoán nữa mà ghi đè được bằng cấu hình («request.sltp_position»)."""
    @classmethod
    def setUpClass(cls):
        cls.h = tc.ExnH()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        Base.setUp(self)
        h = self.h
        h.reset()
        self.s = h.session(tempfile.mkdtemp())
        h.tick(self.s, h.P0)
        self.f = h.fake

    def open(self):
        r = self.s.send_order(self.h.SYM, "buy", 0.06, 1.0900, 1.1200)
        self.assertTrue(r, r.message)
        return r.position

    def poll(self):
        self.s._prot_next = 0.0
        self.s._check_protection()

    def posts(self):
        return [r for r in self.f.requests if r["method"] == "POST" and r["path"].endswith("/orders")]

    def test_unknown_key_without_override_is_not_guessed_and_shell_keeps_guarding(self):
        self.f.sltp_key = "mystery_field"
        a = self.open()
        self.poll()
        self.assertFalse(self.s.prot_covered(a.id, "sl"))
        self.assertEqual(self.f.sltp_created, [])

    def test_override_names_the_key_and_it_works_on_the_first_request(self):
        self.f.sltp_key = "mystery_field"
        fm.configure({"field_overrides": {"exness": {"request": {"sltp_position": "mystery_field"}}}})
        a = self.open()
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))
        self.assertEqual(len(self.f.sltp_created), 1)
        self.assertIn("mystery_field", self.f.sltp_created[0])
        self.assertEqual(len(self.posts()), 1)                                         # không dò mò: đúng ngay lần đầu

    def test_position_stats_of_the_real_exness_broker_follow_the_override(self):
        a = self.open()
        snap = {"positions": [{"position_id": a.ref, "instrument": self.h.SYM, "side": "buy", "volume": "0.06", "open_price": "1.1", "floating_pl": "12.5", "swap_fee": "-0.4"}]}
        self.s.broker.c.snapshot = lambda: snap
        self.assertEqual(self.s.broker.position_stats(), {})                           # tên lạ: chưa khớp
        fm.configure({"field_overrides": {"exness": {"position": {"profit": "floating_pl", "swap": "swap_fee"}}}})
        self.assertEqual(self.s.broker.position_stats(), {a.ref: {"profit": 12.5, "swap": -0.4}})

    def test_override_for_another_exchange_does_not_change_exness(self):
        self.f.sltp_key = "position"
        fm.configure({"field_overrides": {"oanda": {"request": {"sltp_position": "zzz"}}}})
        a = self.open()
        self.poll()
        self.assertTrue(self.s.prot_covered(a.id, "sl"))                               # vẫn dò mặc định bình thường


class TestSettingsAndFactory(Base):
    def test_setting_exists_and_validates_through_the_settings_form_helper(self):
        from pyea.settings import GLOBAL_INPUTS
        self.assertIn("field_overrides", GLOBAL_INPUTS)
        self.assertEqual(GLOBAL_INPUTS["field_overrides"].default, "")
        self.assertEqual(fm.parse_overrides(GLOBAL_INPUTS["field_overrides"].default), ({}, []))

    def test_make_broker_loads_overrides_and_tags_the_broker_with_its_exchange(self):
        from pyea.broker import make_broker
        s = {"exchange": "binance_spot", "api_key": "k", "api_secret": "s", "testnet": True,
             "field_overrides": json.dumps({"binance_spot": {"account": {"equity": "x"}}})}
        b = make_broker(s)
        self.assertEqual(b.field_scope, "binance_spot")
        self.assertEqual(fm.overrides(), {"binance_spot": {"account": {"equity": "x"}}})


if __name__ == "__main__":
    unittest.main()
