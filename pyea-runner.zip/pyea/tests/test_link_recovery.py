"""Mất mạng / app chết / khôi phục: cảnh báo (linkwatch.py), chờ mạng khi khôi phục (engine), và ĐỒNG BỘ sổ app với sàn sau khoảng ngừng
(reconcile.py: adopt giữ nguyên phần đã khớp, giá ra lấy từ lần khớp THẬT của sàn). Sàn dùng ở đây là server Binance giả chạy thật qua HTTP
(tests/fake_exchanges.py) nên đi qua đúng đường history()/positions()/market_order() của broker thật."""
import json
import os
import sys
import tempfile
import time
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub                                             # noqa: E402
kivy_stub.install()

from fake_exchanges import FakeBinanceX                      # noqa: E402
from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.broker import BinanceBroker, BinanceFuturesBroker, BrokerError   # noqa: E402
from pyea.engine import Account, TradingSession, _Halt       # noqa: E402
from pyea.feeds import FeedError, make_feed                  # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402
from test_botproc import HEAD, S, wait, write                # noqa: E402
from test_recon_cache import FakeBroker, make as make_paper  # noqa: E402

SYM = "BTCUSDT"


def _alarms(s):
    """Ghi lại mọi báo động (tiêu đề, nội dung, critical) - alarm() thật vẫn chạy."""
    s.alarm_log = []
    orig = s.alarm

    def rec(title, text, critical=True):
        s.alarm_log.append((title, text, critical))
        return orig(title, text, critical=critical)
    s.alarm = rec
    return s


def make_live(fx, state_dir=None, resume=False, **over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0, native_sltp=False, reconcile_interval=60, reconcile_policy="adopt", sync_interval=0)
    st.update(over)
    sf = os.path.join(state_dir, "state.json") if state_dir else None
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=sf, resume=resume)
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = [SYM]
    s.broker = BinanceFuturesBroker("key123", "sekret", fx.base)
    s.broker.prepare(SYM)
    s.sync = False
    _alarms(s)
    if resume:
        s._load_state()
    return s


def tk(s, price, t=None):
    s.process_tick(Tick(SYM, t or time.time(), price, price))


def adopt_now(s):
    """Lần 1 chỉ ghi nhận (chờ xác nhận); lùi giờ chờ; lần 2 mới sửa sổ."""
    first = s.reconcile_now()
    for k in list(s._recon_pending):
        s._recon_pending[k] -= 60.0
    return s.reconcile_now() if first else first


def pause():
    time.sleep(0.012)                                        # lịch sử sàn có độ phân giải mili-giây: tách thứ tự các lần khớp


class FxBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.fx.price = 100.0
        self.tmp = tempfile.mkdtemp()
        self.s = make_live(self.fx, self.tmp)
        tk(self.s, 100.0)

    def pos(self):
        return sorted(self.s.account.positions.values(), key=lambda p: p.id)

    def buy(self, vol, sl=0.0, tp=0.0, owner="manual", price=None):
        if price is not None:
            self.fx.price = price
            tk(self.s, price)
        r = self.s.send_order(SYM, "buy", vol, sl, tp, owner=owner)
        self.assertTrue(r, r.message)
        pause()
        return r.position


# ====================================================================================== đồng bộ sổ với sàn sau khoảng ngừng
class TestAdoptAfterGap(FxBase):
    def test_exchange_closed_part_while_app_was_away_books_real_exit_price_and_keeps_the_other_positions(self):
        a = self.buy(0.03, 90.0, 120.0, owner="botA")
        b = self.buy(0.02, owner="botB")
        self.assertEqual(self.s.reconcile_now(), [])                                    # đang khớp
        self.fx.external_trade("fut", "sell", 0.02, 103.0)                              # bạn/thanh lý đóng 0.02 trên app của sàn lúc app không canh
        self.fx.price = 99.0
        tk(self.s, 99.0)                                                                # giá HIỆN TẠI khác giá khớp thật
        issues = adopt_now(self.s)
        self.assertEqual([i["kind"] for i in issues], ["mismatch"])
        left = self.pos()
        self.assertEqual([(p.id, p.owner, round(p.volume, 9), p.sl, p.tp) for p in left], [(a.id, "botA", 0.03, 90.0, 120.0)])     # vị thế cũ KHÔNG bị đụng
        tr = [t for t in self.s.account.trades if t.id == b.id][0]
        self.assertEqual((tr.close_price, tr.owner, tr.reason), (103.0, "botB", "Đối soát"))                                        # giá ra = lần khớp THẬT
        self.assertAlmostEqual(tr.profit, (103.0 - b.open_price) * 0.02, 6)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.details["cách tính giá ra"], "lần khớp thật của sàn")
        self.assertEqual(self.s.reconcile_now(), [])                                    # hội tụ

    def test_whole_position_gone_closes_all_newest_first_at_the_real_fill(self):
        self.buy(0.03)
        self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.05, 97.5)
        adopt_now(self.s)
        self.assertEqual(self.pos(), [])
        self.assertEqual({t.close_price for t in self.s.account.trades}, {97.5})

    def test_apps_own_orders_are_never_mistaken_for_external_fills(self):
        a = self.buy(0.03)
        b = self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.02, 103.0)                              # ngoài app, SỚM hơn
        pause()
        self.fx.price = 99.0
        tk(self.s, 99.0)
        r = self.s.close_position(a.id, "manual", "đóng một phần", volume=0.01)         # lệnh của chính app, MUỘN hơn, giá 99
        self.assertTrue(r, r.message)
        self.assertEqual(round(self.s.account.positions[a.id].volume, 9), 0.02)
        adopt_now(self.s)
        tr = [t for t in self.s.account.trades if t.id == b.id][0]
        self.assertAlmostEqual(tr.close_price, 103.0, 9)                                # nếu không loại lệnh của app, VWAP sẽ lẫn giá 99
        self.assertEqual([round(p.volume, 9) for p in self.pos()], [0.02])

    def test_only_fills_on_the_closing_side_count_even_if_a_newer_opposite_fill_exists(self):
        b = self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.03, 103.0)                              # bạn đóng 0.02 và đảo sang bán 0.01
        pause()
        self.fx.external_trade("fut", "buy", 0.01, 120.0)                               # rồi mua lại 0.01 (MỚI hơn, nhưng là chiều MỞ)
        adopt_now(self.s)
        tr = [t for t in self.s.account.trades if t.id == b.id][0]
        self.assertAlmostEqual(tr.close_price, 103.0, 9)

    def test_too_little_evidence_in_history_falls_back_to_current_price(self):
        b = self.buy(0.04)
        self.fx.external_trade("fut", "sell", 0.01, 103.0)                              # lịch sử chỉ giải thích được 25% khối lượng đã mất
        self.fx.fut["pos"] = 0.0                                                         # (phần còn lại biến mất mà lịch sử không có - vd thanh lý ngoài phạm vi)
        self.fx.price = 99.0
        tk(self.s, 99.0)
        adopt_now(self.s)
        tr = [t for t in self.s.account.trades if t.id == b.id][0]
        self.assertEqual(tr.close_price, 99.0)

    def test_enough_evidence_uses_the_history_price_for_the_whole_amount(self):
        b = self.buy(0.04)
        self.fx.external_trade("fut", "sell", 0.03, 103.0)                              # giải thích 75%
        self.fx.fut["pos"] = 0.0
        self.fx.price = 99.0
        tk(self.s, 99.0)
        adopt_now(self.s)
        self.assertAlmostEqual([t for t in self.s.account.trades if t.id == b.id][0].close_price, 103.0, 9)

    def test_without_history_falls_back_to_current_price_and_says_so(self):
        b = self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.02, 103.0)
        self.s.broker.history = lambda *a, **k: (_ for _ in ()).throw(BrokerError("lịch sử lỗi"))
        self.fx.price = 99.0
        tk(self.s, 99.0)
        adopt_now(self.s)
        tr = [t for t in self.s.account.trades if t.id == b.id][0]
        self.assertEqual(tr.close_price, 99.0)
        self.assertIn("giá hiện tại", [e for e in self.s.events if e.kind == "close"][-1].details["cách tính giá ra"])
        self.assertEqual(self.pos(), [])                                                # đối soát vẫn xong, không ném lỗi

    def test_broker_without_history_at_all_still_adopts(self):
        b = self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.02, 103.0)
        self.s.broker.__class__ = type("NoHist", (BinanceFuturesBroker,), {"history": property(lambda self: (_ for _ in ()).throw(AttributeError("history")))})
        del self.s.broker.__class__.history                                             # không có history() như sàn chưa hỗ trợ
        adopt_now(self.s)
        self.assertEqual(self.pos(), [])
        self.assertTrue([t for t in self.s.account.trades if t.id == b.id])

    def test_extra_exchange_position_is_imported_without_touching_existing_ones(self):
        a = self.buy(0.03, 90.0, owner="botA")
        self.fx.external_trade("fut", "buy", 0.02, 101.0)                               # lệnh gửi dở lúc crash / bạn vào tay
        adopt_now(self.s)
        rows = [(p.owner, round(p.volume, 9), p.open_price) for p in self.pos()]
        self.assertEqual(rows, [("botA", 0.03, a.open_price), ("manual", 0.02, 101.0)])  # giá vào = lần khớp thật
        self.assertEqual(self.pos()[0].sl, 90.0)

    def test_reversed_side_closes_ledger_and_imports_the_real_position(self):
        self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.05, 102.0)                              # sàn: long 0.02 -> short 0.03
        adopt_now(self.s)
        self.assertEqual([(p.side, round(p.volume, 9), p.owner) for p in self.pos()], [("sell", 0.03, "manual")])
        self.assertEqual(self.s.account.trades[-1].close_price, 102.0)

    def test_a_single_odd_answer_from_the_exchange_does_not_wipe_the_ledger(self):
        self.buy(0.02)
        real = self.s.broker.positions
        self.s.broker.positions = lambda: {}                                            # một lần sàn trả lời thiếu/lỗi
        self.s.reconcile_now()
        self.assertEqual(len(self.pos()), 1)
        self.assertTrue(self.s._recon_next - time.time() < 5.0)                         # hỏi lại sớm để xác nhận
        self.s.broker.positions = real                                                  # lần sau sàn trả đúng
        self.assertEqual(self.s.reconcile_now(), [])
        self.assertEqual(len(self.pos()), 1)
        self.assertEqual(self.s._recon_pending, {})

    def test_confirmation_needs_the_same_discrepancy_twice_not_a_changing_one(self):
        self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.01, 101.0)
        self.s.reconcile_now()
        self.fx.external_trade("fut", "sell", 0.005, 101.0)                             # sàn lại đổi -> chênh lệch KHÁC -> chờ xác nhận lại
        for k in list(self.s._recon_pending):
            self.s._recon_pending[k] -= 60.0
        self.s.reconcile_now()
        self.assertEqual([round(p.volume, 9) for p in self.pos()], [0.02])

    def test_alert_policy_never_changes_the_ledger(self):
        s = make_live(self.fx, self.tmp, reconcile_policy="alert")
        tk(s, 100.0)
        s.send_order(SYM, "buy", 0.02)
        self.fx.external_trade("fut", "sell", 0.02, 103.0)
        for _ in range(3):
            for k in list(s._recon_pending):
                s._recon_pending[k] -= 60.0
            s.reconcile_now()
        self.assertEqual(len(s.account.positions), 1)
        self.assertEqual(len([a for a in s.alarm_log if "Lệch vị thế" in a[0]]), 1)

    def test_default_policy_is_adopt_and_alarm_is_raised_once(self):
        self.assertEqual(default_settings()["reconcile_policy"], "adopt")
        self.buy(0.02)
        self.fx.external_trade("fut", "sell", 0.02, 103.0)
        adopt_now(self.s)
        self.assertEqual(len([a for a in self.s.alarm_log if "Lệch vị thế" in a[0]]), 1)

    def test_orders_the_app_placed_are_remembered_and_survive_a_restart(self):
        self.buy(0.02)
        self.s._save_state()
        with open(os.path.join(self.tmp, "state.json"), encoding="utf-8") as f:
            booked = json.load(f)["booked"]
        self.assertEqual(len(booked), 1)
        s2 = make_live(self.fx, self.tmp, resume=True)
        self.assertEqual(list(s2._booked), booked)
        self.assertEqual(len(s2.account.positions), 1)


class TestNativeFillBeatsReconcile(FxBase):
    def test_protective_order_that_filled_is_booked_as_sl_not_as_reconcile(self):
        s = make_live(self.fx, self.tmp, native_sltp=True, native_sync_s=1.0)

        class Feed:
            def tick(self, sym):
                return Tick(sym, time.time(), 99.0, 99.0)

            def history(self, *a, **k):
                return []

            def close(self):
                pass
        s.feed = Feed()
        s.sync = False
        tk(s, 100.0)
        r = s.send_order(SYM, "buy", 0.05, 95.0, 120.0)
        self.assertTrue(r, r.message)
        s._prot_next = 0.0
        s._check_protection()
        aid = [a["algoId"] for a in self.fx.fut["algo"].values() if a["orderType"] == "STOP_MARKET"][0]
        self.fx.fill_algo(aid, 95.0)                                                    # SL khớp trên sàn trong lúc app không canh
        s.reconcile_now()                                                               # đối soát đã THẤY chênh lệch từ trước (đang chờ xác nhận)
        for k in list(s._recon_pending):
            s._recon_pending[k] -= 60.0
        s._prot_next = 0.0
        s._recon_next = 0.0
        s.poll_once()                                                                   # một vòng poll: bảo vệ chạy TRƯỚC đối soát (đảo thứ tự -> «Đối soát»)
        self.assertEqual(len(s.account.positions), 0)
        tr = s.account.trades[-1]
        self.assertEqual((tr.close_price, tr.reason), (95.0, "Stop Loss"))                  # đúng nhãn SL của lệnh bảo vệ, không phải «Đối soát»


# ====================================================================================== Spot: ví ít coin hơn sổ
class TestSpotShortfall(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def test_coin_sold_elsewhere_is_booked_at_the_real_sell_price(self):
        fx = self.fx
        fx.reset()
        fx.price = 100.0
        st = default_settings()
        st.update(mode="paper", exchange="binance_spot", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0,
                  reconcile_policy="adopt", sync_interval=0)
        s = TradingSession(st, sync=True, feed=_ReplayFeed())
        s.events = deque(maxlen=1000)
        s.account = Account(100000.0, 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        s.watch = [SYM]
        s.broker = BinanceBroker("key123", "sekret", fx.base)
        s.broker.prepare(SYM)
        s.sync = False
        _alarms(s)
        tk(s, 100.0)
        r = s.send_order(SYM, "buy", 0.04)
        self.assertTrue(r, r.message)
        pause()
        fx.external_trade("spot", "sell", 0.03, 108.0)                                  # bán 0.03 coin ở app sàn
        fx.price = 99.0
        tk(s, 99.0)
        adopt_now(s)
        self.assertAlmostEqual(sum(p.volume for p in s.account.positions.values()), 0.04 - 0.03, 3)
        self.assertEqual(s.account.trades[-1].close_price, 108.0)


# ====================================================================================== khôi phục sau crash
class TestRestartAfterCrash(FxBase):
    def test_exchange_closed_the_position_while_the_app_was_dead(self):
        a = self.buy(0.03, 90.0, 120.0, owner="botA")
        b = self.buy(0.02, owner="botB")
        self.s._save_state()                                                            # (lần lưu cuối trước khi app bị giết - KHÔNG qua _finish)
        self.fx.external_trade("fut", "sell", 0.02, 104.0)
        self.fx.price = 98.0
        s2 = make_live(self.fx, self.tmp, resume=True)                                   # tiến trình mới
        self.assertEqual([p.id for p in s2.account.positions.values()], [a.id, b.id])   # sổ cũ được khôi phục (chưa biết sàn đã đổi)
        tk(s2, 98.0)
        adopt_now(s2)
        self.assertEqual([(p.id, p.owner, p.sl, p.tp) for p in s2.account.positions.values()], [(a.id, "botA", 90.0, 120.0)])
        self.assertEqual([t.close_price for t in s2.account.trades if t.id == b.id], [104.0])

    def test_gap_alarm_after_unclean_stop_with_open_positions(self):
        self.buy(0.02)
        self.s._save_state()
        p = os.path.join(self.tmp, "state.json")
        d = json.load(open(p, encoding="utf-8"))
        d["saved_at"] = time.time() - 900
        json.dump(d, open(p, "w", encoding="utf-8"))
        s2 = make_live(self.fx, self.tmp, resume=True)
        al = [a for a in s2.alarm_log if "khôi phục" in a[0].lower()]
        self.assertEqual(len(al), 1)
        self.assertTrue(al[0][2])                                                       # nghiêm trọng
        self.assertIn("ngừng hoạt động khoảng 15 phút", al[0][1])
        self.assertIn("1 vị thế", al[0][1])
        self.assertAlmostEqual(s2.restore_info["gap_s"], 900, delta=5)

    def test_no_alarm_after_user_stop_or_short_gap_or_nothing_open(self):
        self.buy(0.02)
        p = os.path.join(self.tmp, "state.json")

        def reload(**ch):
            self.s._save_state()
            d = json.load(open(p, encoding="utf-8"))
            d.update(ch)
            json.dump(d, open(p, "w", encoding="utf-8"))
            return make_live(self.fx, self.tmp, resume=True)
        self.assertEqual(reload(saved_at=time.time() - 900, clean=True).alarm_log, [])      # bạn dừng có chủ đích
        self.assertEqual(reload(saved_at=time.time() - 30).alarm_log, [])                   # ngừng ngắn
        self.s.account.positions.clear()
        self.assertEqual(reload(saved_at=time.time() - 900).alarm_log, [])                  # không còn gì để canh

    def test_finish_marks_the_state_as_a_clean_stop(self):
        self.s._finished = False
        self.s.settings["close_on_stop"] = False
        self.s._finish()
        self.assertTrue(json.load(open(os.path.join(self.tmp, "state.json"), encoding="utf-8"))["clean"])
        self.s._save_state()
        self.assertFalse(json.load(open(os.path.join(self.tmp, "state.json"), encoding="utf-8"))["clean"])


# ====================================================================================== chờ mạng khi khôi phục
class FlakyBroker:
    def __init__(self, fails):
        self.fails, self.calls = fails, 0

    def prepare(self, sym, lev):
        self.calls += 1
        if self.calls <= self.fails:
            raise BrokerError("không có mạng")
        return 1234.5


class TestResumeWaitsForNetwork(unittest.TestCase):
    def _s(self, resume, fails):
        st = default_settings()
        st.update(mode="live", exchange="binance_futures", live_confirm=True)
        s = TradingSession(st, sync=True, feed=_ReplayFeed(), resume=resume)
        s.RETRY_BASE_S = 0.01
        s.broker = FlakyBroker(fails)
        s.watch = [SYM]
        _alarms(s)
        return s

    def test_resume_keeps_retrying_until_the_network_is_back(self):
        s = self._s(True, 3)
        self.assertEqual(s._connect_broker([SYM]), 1234.5)
        self.assertEqual(s.broker.calls, 4)
        al = [a for a in s.alarm_log if "Chưa kết nối được sàn" in a[0]]
        self.assertEqual(len(al), 1)                                                    # một đợt chờ = một báo động
        self.assertTrue(al[0][2])
        self.assertIn("SL/TP native", al[0][1])

    def test_user_pressing_start_gets_the_error_at_once(self):
        s = self._s(False, 3)
        with self.assertRaises(_Halt) as c:
            s._connect_broker([SYM])
        self.assertTrue(c.exception.error)
        self.assertEqual(s.broker.calls, 1)

    def test_stopping_while_waiting_ends_the_wait(self):
        s = self._s(True, 10 ** 6)
        s.RETRY_BASE_S = 0.05
        s._stop.set()
        with self.assertRaises(_Halt):
            s._connect_broker([SYM])

    def test_bad_configuration_is_not_retried(self):
        st = default_settings()
        st.update(mode="live", exchange="binance_futures", live_confirm=True, binance_key="", binance_secret="")
        s = TradingSession(st, sync=True, feed=_ReplayFeed(), resume=True)
        with self.assertRaises(_Halt):
            s.setup()


class FlakyHistory:
    """Nguồn giá mô phỏng nhưng tải lịch sử nến lỗi N lần đầu (không có mạng lúc app vừa dựng lại)."""

    def __init__(self, inner, fails):
        self.inner, self.fails, self.calls = inner, fails, 0

    def history(self, *a, **k):
        self.calls += 1
        if self.calls <= self.fails:
            raise FeedError("không có mạng")
        return self.inner.history(*a, **k)

    def __getattr__(self, n):
        return getattr(self.inner, n)


BOT = HEAD + '''
class B(BaseBot):
    def on_init(self):
        self.api.log("INIT-OK")
    def on_tick(self, t):
        pass
'''


class TestBotsWaitForDataOnResume(unittest.TestCase):
    def _run(self, resume, fails):
        d = tempfile.mkdtemp()
        st = S(bot_isolation="thread")
        feed = FlakyHistory(make_feed("simulated", st), fails)
        s = TradingSession(st, state_file=os.path.join(d, "state.json"), resume=resume, feed=feed)
        s.data_dir = d
        s.RETRY_BASE_S = 0.02
        inst = s.attach(write(d, "b.py", BOT), "BTCUSD", "1m", {}, iid="w1")
        s.start()
        inst.start()
        return s, inst, feed

    def test_bot_of_a_resumed_session_waits_instead_of_dying(self):
        s, inst, feed = self._run(True, 3)
        try:
            self.assertTrue(wait(lambda: any("INIT-OK" in x[3] for x in s.get_logs(0)), 15), [x[3] for x in s.get_logs(0)][-8:])
            self.assertEqual(inst.status, "running")
            self.assertGreaterEqual(feed.calls, 4)
        finally:
            s.stop(wait=True)

    def test_bot_started_by_the_user_still_fails_fast(self):
        s, inst, feed = self._run(False, 3)
        try:
            self.assertTrue(wait(lambda: inst.status == "error", 10))
            self.assertIn("Không lấy được dữ liệu", inst.message)
            self.assertEqual(feed.calls, 1)
        finally:
            s.stop(wait=True)


# ====================================================================================== giám sát kết nối
class DeadFeed:
    def __init__(self):
        self.calls = 0

    def tick(self, sym):
        self.calls += 1
        raise FeedError("mất mạng")

    def history(self, *a, **k):
        return []

    def close(self):
        pass


def paper(**over):
    s = make_paper(**over)
    _alarms(s)
    s.broker = FakeBroker({})
    return s


def link_tick(s, back=0.0):
    s._link_t = 0.0
    if back and s._link["down_since"]:
        s._link["down_since"] -= back
    s._check_link()


def age(s, secs):
    s._link["down_since"] -= secs
    if s._link["alerted_at"]:
        s._link["alerted_at"] -= secs


class TestLinkMonitor(unittest.TestCase):
    def test_healthy_connection_raises_nothing(self):
        s = paper()
        tk_paper(s)
        for _ in range(5):
            link_tick(s)
        self.assertEqual(s.alarm_log, [])
        self.assertFalse(s.link_state()["down"])

    def test_feed_outage_alarms_after_the_threshold_with_what_is_unprotected(self):
        s = paper()
        tk_paper(s)
        s.sync = False
        s.send_order("BTCUSDT", "buy", 0.5, sl=90.0)                                    # SL do APP canh
        s.send_order("BTCUSDT", "buy", 0.2)                                             # không SL/TP
        s.feed = DeadFeed()
        s.poll_once()
        self.assertTrue(s.link_state()["down"])
        self.assertEqual([a for a in s.alarm_log if "Mất kết nối" in a[0]], [])         # chưa đủ link_alarm_s
        age(s, 31)
        link_tick(s)
        al = [a for a in s.alarm_log if a[0].startswith("Mất kết nối")]
        self.assertEqual(len(al), 1)
        self.assertTrue(al[0][2])
        self.assertIn("2 vị thế đang mở", al[0][1])
        self.assertIn("1 chỉ do APP canh SL/TP (KHÔNG hoạt động lúc này)", al[0][1])
        self.assertIn("1 không đặt SL/TP", al[0][1])
        link_tick(s)
        self.assertEqual(len([a for a in s.alarm_log if a[0].startswith("Mất kết nối")]), 1)   # không báo lặp mỗi vòng

    def test_native_sltp_is_reported_as_still_working(self):
        s = paper()
        tk_paper(s)
        s.sync = False
        p = s.send_order("BTCUSDT", "buy", 0.5, sl=90.0).position
        s._prot_pos.add((p.id, "sl"))
        self.assertEqual(s.link_exposure(), {"positions": 1, "native": 1, "app": 0, "none": 0, "app_pending": 0})
        self.assertIn("1 được SÀN canh SL/TP (native, vẫn hoạt động)", s._exposure_text(s.link_exposure()))

    def test_reminder_repeats_while_still_down_and_not_before(self):
        s = paper()
        tk_paper(s)
        s.feed = DeadFeed()
        s.poll_once()
        age(s, 40)
        link_tick(s)
        age(s, 300)
        link_tick(s)
        self.assertEqual(len(s.alarm_log), 1)                                           # 5 phút < link_repeat_min (10)
        age(s, 400)
        link_tick(s)
        al = [a for a in s.alarm_log if a[0].startswith("VẪN mất kết nối")]
        self.assertEqual(len(al), 1)
        self.assertTrue(al[0][2])

    def test_repeat_can_be_switched_off(self):
        s = paper(link_repeat_min=0.0)
        tk_paper(s)
        s.feed = DeadFeed()
        s.poll_once()
        age(s, 40)
        link_tick(s)
        age(s, 5000)
        link_tick(s)
        self.assertEqual(len(s.alarm_log), 1)

    def test_alarm_can_be_switched_off(self):
        s = paper(link_alarm_s=0.0)
        tk_paper(s)
        s.feed = DeadFeed()
        s.poll_once()
        age(s, 500)
        link_tick(s)
        self.assertEqual(s.alarm_log, [])

    def test_restored_connection_notifies_and_resyncs_everything_at_once(self):
        s = paper()
        tk_paper(s)
        s.feed = DeadFeed()
        s.poll_once()
        age(s, 90)
        link_tick(s)

        class Back:
            def tick(self, sym):
                return Tick(sym, time.time(), 100.0, 100.0)

            def history(self, *a, **k):
                return []

            def close(self):
                pass
        s.feed = Back()
        s._feed_next.clear()
        s._recon_next = s._sync_next = s._prot_next = s._native_sync_due = time.time() + 999
        s._link_t = 0.0
        s.poll_once()
        self.assertFalse(s.link_state()["down"])
        ok = [a for a in s.alarm_log if a[0] == "Đã có lại kết nối"]
        self.assertEqual(len(ok), 1)
        self.assertFalse(ok[0][2])                                                      # thông tin, không phải sự cố
        self.assertIn("đối soát", ok[0][1])
        self.assertLess(s._recon_next, time.time() + 1)                                 # đối soát NGAY, không chờ 60 giây
        self.assertLess(s._sync_next, time.time())
        self.assertLess(s._native_sync_due, time.time())
        self.assertAlmostEqual(s.link_state()["last_down_s"], 90, delta=5)
        self.assertEqual(s.link_state()["episodes"], 1)

    def test_short_blip_that_never_alarmed_does_not_send_a_restored_notice(self):
        s = paper()
        tk_paper(s)
        s.feed = DeadFeed()
        s.poll_once()
        self.assertTrue(s.link_state()["down"])
        s._feed_fail["BTCUSDT"] = 0
        s._tick_wall["BTCUSDT"] = time.time()
        link_tick(s)
        self.assertFalse(s.link_state()["down"])
        self.assertEqual(s.alarm_log, [])

    def test_never_halts_by_default_even_after_hundreds_of_failures_with_a_position_open(self):
        s = paper()
        tk_paper(s)
        s.send_order("BTCUSDT", "buy", 0.5)
        s.feed = DeadFeed()
        for _ in range(400):
            s._feed_next.clear()
            s.poll_once()                                                               # trước đây: _Halt ở lần thứ 120 và không tự chạy lại
        self.assertGreaterEqual(s._feed_fail["BTCUSDT"], 400)

    def test_halts_only_when_the_user_asks_for_it(self):
        s = paper(feed_halt_min=10.0)
        tk_paper(s)
        s.send_order("BTCUSDT", "buy", 0.5)
        s.feed = DeadFeed()
        s.poll_once()
        s._feed_first_fail["BTCUSDT"] -= 599
        s._feed_next.clear()
        s.poll_once()                                                                   # 599 giây: chưa
        s._feed_first_fail["BTCUSDT"] -= 2
        s._feed_next.clear()
        with self.assertRaises(_Halt):
            s.poll_once()

    def test_polling_backs_off_during_a_long_outage(self):
        s = paper()
        tk_paper(s)
        feed = s.feed = DeadFeed()
        for _ in range(60):
            s.poll_once()
        self.assertLess(feed.calls, 15)                                                 # lùi nhịp: không gọi mỗi vòng
        self.assertGreaterEqual(feed.calls, 10)

    def test_price_coming_back_is_logged(self):
        s = paper()
        tk_paper(s)
        s.feed = DeadFeed()
        for _ in range(3):
            s._feed_next.clear()
            s.poll_once()

        class Back(DeadFeed):
            def tick(self, sym):
                return Tick(sym, time.time(), 100.0, 100.0)
        s.feed = Back()
        s._feed_next.clear()
        s.poll_once()
        self.assertTrue(any("Đã lấy lại được giá" in x[3] for x in s.get_logs(0)))
        self.assertEqual(s._feed_fail["BTCUSDT"], 0)

    def test_exchange_api_outage_with_prices_fine_is_detected_and_cleared(self):
        s = paper()
        tk_paper(s)
        s.send_order("BTCUSDT", "buy", 0.5)
        s.broker = FakeBroker({"BTCUSDT": {"qty": 0.5, "price": 100.0}}, fail=True)
        s.reconcile_now()
        self.assertFalse(s.broker_link()[0])                                            # mới 1 lần lỗi: chưa kết luận
        s.reconcile_now()
        down, err, since = s.broker_link()
        self.assertTrue(down)
        self.assertIn("mạng lỗi", err)
        self.assertTrue(s.health()["broker_down"])
        link_tick(s)
        self.assertTrue(s.link_state()["down"])
        self.assertEqual(s.link_state()["reason"], "sàn")
        age(s, 40)
        link_tick(s)
        al = [a for a in s.alarm_log if a[0] == "Mất kết nối sàn"]
        self.assertEqual(len(al), 1)
        self.assertIn("mạng lỗi", al[0][1])
        s.broker.fail = False
        s.reconcile_now()
        self.assertFalse(s.health()["broker_down"])
        link_tick(s)
        self.assertFalse(s.link_state()["down"])
        self.assertEqual([a[0] for a in s.alarm_log][-1], "Đã có lại kết nối")

    def test_one_failing_probe_among_healthy_ones_is_enough_but_a_single_failure_is_not(self):
        s = paper()
        s.link_note("native", True)
        s.link_note("reconcile", False, "x")
        self.assertFalse(s.broker_link()[0])
        s.link_note("reconcile", False, "x")
        self.assertTrue(s.broker_link()[0])
        s.link_note("reconcile", True)
        self.assertFalse(s.broker_link()[0])

    def test_snapshot_carries_link_and_health(self):
        s = paper()
        tk_paper(s)
        snap = s.snapshot()
        self.assertFalse(snap["link"]["down"])
        self.assertIn("broker_down", snap["health"])

    def test_link_check_never_raises_into_the_poll_loop(self):
        s = paper()
        tk_paper(s)
        s.health = lambda: (_ for _ in ()).throw(RuntimeError("hỏng"))
        s._link_t = 0.0
        s._check_link()                                                                 # không ném


class TestUnprotectedWarningLive(FxBase):
    def test_no_warning_when_native_sltp_is_on_and_supported(self):
        s = make_live(self.fx, self.tmp, native_sltp=True)
        tk(s, 100.0)
        s.send_order(SYM, "buy", 0.02, 90.0)
        link_tick(s)
        self.assertEqual([a for a in s.alarm_log if a[0] == "Vị thế chưa được sàn bảo vệ"], [])

    def test_warns_when_native_sltp_is_off(self):
        tk(self.s, 100.0)
        self.s.send_order(SYM, "buy", 0.02, 90.0)
        link_tick(self.s)
        self.assertEqual(len([a for a in self.s.alarm_log if a[0] == "Vị thế chưa được sàn bảo vệ"]), 1)


class TestUnprotectedWarning(unittest.TestCase):
    def test_live_positions_watched_only_by_the_app_get_one_clear_warning(self):
        s = paper()
        tk_paper(s)
        s.sync = False
        s.send_order("BTCUSDT", "buy", 0.5, sl=90.0)
        s.send_order("BTCUSDT", "buy", 0.2)
        link_tick(s)
        link_tick(s)
        al = [a for a in s.alarm_log if a[0] == "Vị thế chưa được sàn bảo vệ"]
        self.assertEqual(len(al), 1)
        self.assertFalse(al[0][2])
        self.assertIn("1 chỉ do app canh SL/TP, 1 không có SL/TP", al[0][1])
        self.assertIn("SL/TP native", al[0][1])

    def test_no_warning_in_paper_mode_or_without_positions(self):
        s = paper()
        s.broker = None
        tk_paper(s)
        s.sync = False
        s.send_order("BTCUSDT", "buy", 0.5, sl=90.0)
        link_tick(s)
        self.assertEqual(s.alarm_log, [])
        s2 = paper()
        s2.sync = False
        tk_paper(s2)
        link_tick(s2)
        self.assertEqual(s2.alarm_log, [])


def tk_paper(s, px=100.0):
    s.process_tick(Tick("BTCUSDT", time.time(), px, px))


if __name__ == "__main__":
    unittest.main()
