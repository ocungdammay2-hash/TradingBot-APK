"""Đồng bộ lịch sử giao dịch + số dư từ sàn."""
import json
import os
import sys
import tempfile
import time
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX                                            # noqa: E402
from pyea.backtest import _ReplayFeed                                              # noqa: E402
from pyea.broker import BinanceFuturesBroker, BrokerError, Fill                    # noqa: E402
from pyea.controller import LocalController                                        # noqa: E402
from pyea.engine import Account, TradingSession                                    # noqa: E402
from pyea.sdk import Tick                                                          # noqa: E402
from pyea.settings import default_settings                                         # noqa: E402


class SyncBroker:
    supports_short, netting = True, False

    def __init__(self, balance=100000.0, rows=None):
        self.bal, self.rows, self.hist_calls = balance, list(rows or []), []
        self.bal_fail = self.hist_fail = None

    def balance(self):
        if self.bal_fail:
            raise BrokerError(self.bal_fail)
        return self.bal

    def history(self, since=0.0, symbols=None):
        self.hist_calls.append((since, list(symbols or [])))
        if self.hist_fail:
            raise BrokerError(self.hist_fail)
        return [r for r in self.rows if r["time"] >= since]

    def market_order(self, symbol, side, qty, reduce_only=False):
        return Fill(100.0, qty)


def trade(i, t, pnl=0.0, sym="BTCUSDT"):
    return {"id": str(i), "time": t, "symbol": sym, "side": "buy", "qty": 0.1, "price": 100.0, "fee": 0.01, "pnl": pnl, "order_id": "o%d" % i}


def make(d=None, **over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0)
    st.update(over)
    alarms = []
    sf = os.path.join(d, "session_state.json") if d else None
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=sf, alarm_cb=lambda t, x: alarms.append(t))
    s.events = deque(maxlen=1000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = ["BTCUSDT"]
    s.alarms = alarms
    return s


class TestBalanceSync(unittest.TestCase):
    def test_match_within_threshold_is_ok(self):
        s = make()
        s.broker = SyncBroker(100000.0 * 1.005)                      # lệch 0.5% < ngưỡng 1%
        ex = s.sync_exchange(force=True)
        self.assertIs(ex["ok"], True)
        self.assertAlmostEqual(ex["balance_remote"], 100500.0, 6)
        self.assertEqual(s.alarms, [])

    def test_drift_alerts_once_per_distinct_amount_and_clears(self):
        s = make()
        s.broker = SyncBroker(95000.0)
        s.sync_exchange(force=True)
        self.assertIs(s.exch["ok"], False)
        self.assertAlmostEqual(s.exch["drift"], -5000.0)
        s.sync_exchange(force=True)
        self.assertEqual(len(s.alarms), 1)                           # cùng mức lệch: không báo lại
        s.broker.bal = 90000.0
        s.sync_exchange(force=True)
        self.assertEqual(len(s.alarms), 2)                           # lệch thêm: báo mới
        self.assertEqual(s.account.balance, 100000.0)                # alert: KHÔNG tự sửa sổ
        s.broker.bal = 100000.0
        s.sync_exchange(force=True)
        self.assertIs(s.exch["ok"], True)
        s.broker.bal = 90000.0
        s.sync_exchange(force=True)
        self.assertEqual(len(s.alarms), 3)                           # đã khỏi rồi lệch lại -> báo lại

    def test_adopt_policy_sets_book_balance(self):
        s = make(balance_sync_policy="adopt")
        s.broker = SyncBroker(97500.0)
        s.sync_exchange(force=True)
        self.assertEqual(s.account.balance, 97500.0)

    def test_off_policy_skips_balance_but_still_syncs_history(self):
        s = make(balance_sync_policy="off")
        s.broker = SyncBroker(1.0, [trade(1, time.time())])
        ex = s.sync_exchange(force=True)
        self.assertIsNone(ex["balance_remote"])
        self.assertEqual(ex["total_trades"], 1)

    def test_threshold_zero_disables_alerts(self):
        s = make(balance_drift_pct=0)
        s.broker = SyncBroker(1.0)
        s.sync_exchange(force=True)
        self.assertIs(s.exch["ok"], True)

    def test_errors_are_reported_not_raised(self):
        s = make()
        s.broker = SyncBroker()
        s.broker.bal_fail, s.broker.hist_fail = "mạng lỗi", "502"
        ex = s.sync_exchange(force=True)
        self.assertIn("số dư: mạng lỗi", ex["error"])
        self.assertIn("lịch sử: 502", ex["error"])
        self.assertEqual(ex["history_error"], "502")
        warns = [l for l in s.logs if "Đồng bộ với sàn" in l[3]]
        s.sync_exchange(force=True)
        self.assertEqual(len([l for l in s.logs if "Đồng bộ với sàn" in l[3]]), len(warns))     # không spam log

    def test_unsupported_broker_and_none(self):
        s = make()
        self.assertFalse(s.sync_exchange(force=True)["supported"])      # không có broker (paper)

        class Bare:
            supports_short = netting = False
        s.broker = Bare()
        s._check_exchange_sync()                                         # không ném
        self.assertIsNone(s.exch["balance_remote"])


class TestHistorySync(unittest.TestCase):
    def test_incremental_dedup_and_file(self):
        with tempfile.TemporaryDirectory() as d:
            s = make(d)
            now = time.time()
            s.broker = SyncBroker(100000.0, [trade(1, now - 100), trade(2, now - 50)])
            s.sync_exchange(force=True)
            self.assertEqual((s.exch["new_trades"], s.exch["total_trades"]), (2, 2))
            s.sync_exchange(force=True)
            self.assertEqual((s.exch["new_trades"], s.exch["total_trades"]), (0, 2))          # khử trùng
            s.broker.rows.append(trade(3, now - 10))
            s.sync_exchange(force=True)
            self.assertEqual((s.exch["new_trades"], s.exch["total_trades"]), (1, 3))
            lines = open(os.path.join(d, "exchange_history.jsonl"), encoding="utf-8").read().splitlines()
            self.assertEqual([json.loads(x)["id"] for x in lines], ["1", "2", "3"])
            since_args = [c[0] for c in s.broker.hist_calls]
            self.assertAlmostEqual(since_args[0], now - 7 * 86400, delta=5)                  # lần đầu: lookback 7 ngày
            self.assertAlmostEqual(since_args[1], now - 50 - 120, delta=1)                   # sau đó: chỉ phần mới (chồng 120s)

    def test_persists_across_restart(self):
        with tempfile.TemporaryDirectory() as d:
            now = time.time()
            s1 = make(d)
            s1.broker = SyncBroker(100000.0, [trade(1, now - 100), trade(2, now - 50)])
            s1.sync_exchange(force=True)
            s2 = make(d)                                                  # "khởi động lại"
            self.assertEqual(s2.exch["total_trades"], 2)
            s2.broker = SyncBroker(100000.0, [trade(1, now - 100), trade(2, now - 50), trade(3, now - 5)])
            s2.sync_exchange(force=True)
            self.assertEqual((s2.exch["new_trades"], s2.exch["total_trades"]), (1, 3))
            self.assertGreater(s2.broker.hist_calls[0][0], now - 200)        # hỏi từ mốc đã lưu, không lấy lại 7 ngày

    def test_lookback_setting_and_symbols_passed(self):
        s = make(sync_lookback_days=2)
        s.broker = SyncBroker()
        s.sync_exchange(force=True)
        since, syms = s.broker.hist_calls[0]
        self.assertAlmostEqual(since, time.time() - 2 * 86400, delta=5)
        self.assertIn("BTCUSDT", syms)

    def test_exchange_trades_newest_first_and_limit(self):
        with tempfile.TemporaryDirectory() as d:
            s = make(d)
            now = time.time()
            s.broker = SyncBroker(100000.0, [trade(i, now - 100 + i) for i in range(1, 6)])
            s.sync_exchange(force=True)
            self.assertEqual([t["id"] for t in s.exchange_trades(3)], ["5", "4", "3"])

    def test_pnl_since_session_start_compared(self):
        s = make()
        now = time.time()
        s.broker = SyncBroker(100000.0, [trade(1, now - 99999, pnl=500.0), trade(2, now + 1, pnl=12.5)])
        s.sync_exchange(force=True)
        self.assertEqual(s.exch["pnl_exchange"], 12.5)                      # chỉ tính các lần khớp từ lúc phiên bắt đầu

    def test_corrupt_history_file_does_not_crash(self):
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "exchange_history.jsonl"), "w", encoding="utf-8") as f:
                f.write('{"id": "1", "time": 5}\nnot json\n{"id": "2"}\n')
            s = make(d)
            self.assertEqual(s.exch["total_trades"], 2)


class TestScheduling(unittest.TestCase):
    def test_interval_gate_and_disable(self):
        s = make(sync_interval=1000)
        s.broker = SyncBroker()
        s._check_exchange_sync()
        s._check_exchange_sync()
        self.assertEqual(len(s.broker.hist_calls), 1)                       # lần hai chưa tới hạn
        s2 = make(sync_interval=0)
        s2.broker = SyncBroker()
        s2._check_exchange_sync()
        self.assertEqual(s2.broker.hist_calls, [])

    def test_snapshot_exposes_exchange_sync_and_controller_triggers(self):
        s = make()
        s.broker = SyncBroker(99000.0, [trade(1, time.time())])
        ctl = LocalController.__new__(LocalController)
        ctl.session = s
        ctl.sync_exchange_now()
        end = time.time() + 3
        while time.time() < end and not s.exch["last"]:
            time.sleep(0.02)
        snap = s.snapshot()
        self.assertEqual(snap["exchange_sync"]["balance_remote"], 99000.0)
        self.assertEqual(snap["exchange_sync"]["total_trades"], 1)


class TestWithRealBrokerOverHttp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def test_futures_balance_and_history(self):
        self.fx.reset()
        s = make()
        s.broker = BinanceFuturesBroker("key123", "sekret", self.fx.base)
        s.account.balance = s.broker.prepare("BTCUSDT")                      # số dư khả dụng 4990 (fake: ví 5000 - 10)
        s.broker.market_order("BTCUSDT", "buy", 0.02)
        s.sync_exchange(force=True)
        self.assertEqual(s.exch["balance_remote"], 5000.0)                   # walletBalance
        self.assertEqual(s.exch["total_trades"], 1)
        self.assertEqual(s.exch["error"], "")
        self.assertIs(s.exch["ok"], True)                                    # 4990 vs 5000 = 0.2% < 1%


if __name__ == "__main__":
    unittest.main()
