"""Lịch sử Binance SPOT qua bộ máy chung: /api/v3/myTrades theo mã, cửa sổ ≤24 giờ (sàn giả từ chối cửa sổ dài hơn), dựng vị thế từ lần khớp,
KHÔNG bịa lãi/lỗ (Spot không báo), phí chỉ cộng khi trả bằng đồng quote."""
import os
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX                      # noqa: E402
from pyea import brokerhist as bh                            # noqa: E402

DAY = 86400.0


class TestSpotHistory(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fake = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        self.fake.reset()
        self.t0 = time.time() - 5 * DAY

    def settings(self):
        return {"mode": "live", "exchange": "binance_spot", "api_key": self.fake.KEY, "api_secret": self.fake.SECRET.decode(), "base_url": self.fake.base,
                "watchlist": "BTCUSDT"}

    def test_builds_positions_from_fills_across_days_without_inventing_profit(self):
        f, t = self.fake, self.t0
        f.add_spot_trade("BTCUSDT", True, 0.5, 100.0, t + 100, fee=0.0005, asset="BTC")      # phí bằng coin: không cộng
        f.add_spot_trade("BTCUSDT", True, 0.5, 102.0, t + 2 * DAY, fee=0.05)
        f.add_spot_trade("BTCUSDT", False, 1.0, 110.0, t + 3.5 * DAY, fee=0.11)
        res = bh.fetch_for_settings(self.settings(), t - 60, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 3)                       # 3 lần khớp -> 1 vị thế
        self.assertEqual(res["summary"]["profit"], 0.0)
        self.assertAlmostEqual(res["summary"]["commission"], -(0.05 + 0.11))
        pos = res["positions"]
        self.assertEqual(len(pos), 1)
        self.assertEqual((pos[0]["symbol"], pos[0]["side"], pos[0]["volume"]), ("BTCUSDT", "buy", 1.0))
        self.assertAlmostEqual(pos[0]["open_price"], 101.0)
        self.assertAlmostEqual(pos[0]["close_price"], 110.0)
        self.assertTrue(any("KHÔNG bịa" in n for n in res["notes"]))

    def test_every_request_window_is_within_24_hours(self):
        self.fake.add_spot_trade("BTCUSDT", True, 1.0, 100.0, self.t0 + 10)
        self.fake.add_spot_trade("BTCUSDT", False, 1.0, 101.0, self.t0 + 4 * DAY)
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        calls = [c for c in self.fake.calls if c[1] == "/api/v3/myTrades"]
        self.assertGreaterEqual(len(calls), 5)
        for _, _, q in calls:
            self.assertLessEqual(int(q["endTime"]) - int(q["startTime"]), 86400 * 1000)
        self.assertEqual(len(res["deals"]), 2)
        self.assertFalse([n for n in res["notes"] if "lỗi" in n.lower() and "CHÚ Ý" in n])


if __name__ == "__main__":
    unittest.main()
