"""MT5 Web Terminal (mt5ws): chạy với máy chủ GIẢ - KHÔNG phải sàn thật. AES được đối chiếu với vector FIPS-197 và (nếu có) thư viện cryptography."""
import os
import struct
import threading
import types
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import kivy_stub                                                             # noqa: E402
kivy_stub.install()
from fake_mt5ws import FakeMt5Ws, TZ                                         # noqa: E402
from pyea import bridges, mt5ws                                              # noqa: E402
from pyea.bridges import BridgeError, MtBroker, MtFeed                       # noqa: E402
from pyea.feeds import FeedError                                             # noqa: E402


class TestAes(unittest.TestCase):
    def test_fips197_vectors(self):
        pt = bytes.fromhex("00112233445566778899aabbccddeeff")
        for key, ct in (("000102030405060708090a0b0c0d0e0f", "69c4e0d86a7b0430d8cdb78070b4c55a"),
                        ("000102030405060708090a0b0c0d0e0f1011121314151617", "dda97ca4864cdfe06eaf70a0ec0d7191"),
                        ("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f", "8ea2b7ca516745bfeafc49904b496089")):
            a = mt5ws.AesCbc(bytes.fromhex(key), pure=True)
            self.assertEqual(a.encrypt(pt)[:16].hex(), ct)                  # IV=0 -> khối đầu của CBC = ECB
            self.assertEqual(a.decrypt(a.encrypt(pt)), pt)

    def test_matches_cryptography_on_random_data(self):
        try:
            import cryptography                                              # noqa: F401
        except ImportError:
            self.skipTest("không có cryptography")
        for klen in (16, 32):
            key = os.urandom(klen)
            fast, pure = mt5ws.AesCbc(key), mt5ws.AesCbc(key, pure=True)
            self.assertIsNotNone(fast._fast)
            for n in (0, 1, 15, 16, 17, 100, 1000):
                data = os.urandom(n)
                self.assertEqual(fast.encrypt(data), pure.encrypt(data))
                self.assertEqual(pure.decrypt(fast.encrypt(data)), data)

    def test_bad_padding_and_key(self):
        with self.assertRaises(BridgeError):
            mt5ws.AesCbc(b"short")
        a = mt5ws.AesCbc(os.urandom(32), pure=True)
        with self.assertRaises(BridgeError):
            a.decrypt(os.urandom(32))

    def test_initial_key_is_32_bytes(self):
        self.assertEqual(len(mt5ws.initial_key()), 32)


class TestCodec(unittest.TestCase):
    def test_sizes_match_pymt5_layout(self):
        # Kích thước (byte) tính ĐỘC LẬP từ lược đồ của pymt5 (schemas.py) - mọi trường đã đối chiếu từng cái một khi viết mã
        for sch, size, n in ((mt5ws.S_TICK, 50, 9), (mt5ws.S_SYMBOL, 526, 8), (mt5ws.S_POSITION, 344, 26), (mt5ws.S_ORDER, 356, 30), (mt5ws.S_DEAL, 356, 28),
                             (mt5ws.S_FULLSYM, 3068, 49), (mt5ws.S_RATE, 48, 7), (mt5ws.S_TRADE_REQ, 236, 20), (mt5ws.S_ACCOUNT, 816, 26)):
            self.assertEqual((mt5ws.schema_size(sch), len(sch)), (size, n))
        self.assertEqual(mt5ws.schema_size(mt5ws.S_TRADE_RESP), 120)
        self.assertEqual(mt5ws.schema_size(mt5ws.S_LOGIN), 4 + 64 + 128 + 16 + 64 + 64 + 8 + 128 + 4 + 256 + 8 + 160 + 8)
        self.assertEqual(mt5ws.S_FULLSYM[46], ("X", 628))                              # khối cấu hình giao dịch của mã
        self.assertEqual(mt5ws.schema_size(mt5ws._schema("W256 i i I i i" + " I" * 10 + " Q I I I Q Q Q Q")), 256 + 8 + 4 + 8 + 40 + 8 + 12 + 32)

    def test_pack_parse_roundtrip_and_utf16(self):
        sch = mt5ws._schema("I W64 d X4 q")
        raw = mt5ws.pack_vals(sch, [7, "Đồng EUR", 1.5, b"ab", -9])
        self.assertEqual(mt5ws.parse_at(raw, sch), [7, "Đồng EUR", 1.5, b"ab\x00\x00", -9])
        with self.assertRaises(BridgeError):
            mt5ws.parse_at(raw[:-1], sch)

    def test_frame_roundtrip_and_length_check(self):
        f = mt5ws.pack_outer(b"hello")
        self.assertEqual(mt5ws.unpack_outer(f), b"hello")
        with self.assertRaises(BridgeError):
            mt5ws.unpack_outer(f + b"x")

    def test_norm_price(self):
        self.assertAlmostEqual(mt5ws.norm_price(110000.0, 5, "EURUSD"), 1.1)
        self.assertEqual(mt5ws.norm_price(1.1, 5, "EURUSD"), 1.1)
        self.assertEqual(mt5ws.norm_price(2000.5, 2, "XAUUSD"), 2000.5)         # không nhầm giá vàng là số nguyên chưa chia


def settings(fake, **kw):
    s = {"exchange": "mt5ws", "mt5ws_uri": fake.url, "mt5ws_login": fake.login, "mt5ws_password": fake.password}
    s.update(kw)
    return s


class Base(unittest.TestCase):
    def setUp(self):
        bridges._BACKENDS.clear()
        self.fake = FakeMt5Ws()
        self.b = mt5ws.make_backend(settings(self.fake))

    def tearDown(self):
        self.b.close()
        self.fake.close()


class TestConnect(Base):
    def test_login_flow_and_origin(self):
        self.assertEqual(self.b.symbols(), ["EURUSD", "XAUUSD"])
        self.assertEqual(self.fake.last_origin, "https://web.metatrader.app")
        cmds = [c for k, c in self.fake.log if k == "cmd"]
        self.assertEqual(cmds[:2], [0, 28])                                  # bootstrap rồi đăng nhập
        self.assertEqual(self.fake.logins, 1)

    def test_wrong_password_clear_error(self):
        b = mt5ws.make_backend(settings(self.fake, mt5ws_password="bad"))
        with self.assertRaises(BridgeError) as cm:
            b.symbols()
        self.assertIn("Đăng nhập MT5 thất bại", str(cm.exception))
        b.close()

    def test_missing_or_bad_credentials_give_specific_guidance(self):
        for kw, needle in (({"mt5ws_login": ""}, "chưa nhập"), ({"mt5ws_login": "abc"}, "chỉ gồm chữ số"), ({"mt5ws_password": ""}, "chưa nhập")):
            with self.assertRaises(BridgeError) as cm:
                mt5ws.make_backend(settings(self.fake, **kw))
            self.assertIn(needle, str(cm.exception))

    def test_unreachable_server(self):
        b = mt5ws.make_backend(settings(self.fake, mt5ws_uri="ws://127.0.0.1:1/terminal"))
        with self.assertRaises(BridgeError):
            b.account()

    def test_reconnects_after_drop(self):
        self.b.account()
        self.fake.drop_after_login = False
        self.b.c._ws.close()                                                 # rớt kết nối phía app
        a = self.b.account()                                                 # lệnh đọc tự kết nối lại
        self.assertEqual(a["balance"], 10000.0)
        self.assertEqual(self.fake.logins, 2)

    def test_bad_offset_setting(self):
        with self.assertRaises(BridgeError) as cm:
            mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="abc"))
        self.assertIn("SỐ GIỜ", str(cm.exception))


class TestProblems(unittest.TestCase):
    def test_each_field_has_specific_hint(self):
        P = mt5ws.problems
        self.assertEqual(P({}), [])                                                    # để trống chưa phải lỗi khi lưu
        self.assertEqual(len(P({}, require=True)), 2)                                  # nhưng bắt buộc lúc kết nối
        self.assertIn("Login", P({"mt5ws_login": "a@b.com"})[0])
        self.assertIn("khoảng trắng", P({"mt5ws_login": "1", "mt5ws_password": " x "})[0])
        self.assertIn("32 ký tự", P({"mt5ws_password": "x" * 40})[0])
        self.assertEqual(P({"mt5ws_password": "ab" * 160}), [])                        # token 160 byte dạng hex được phép
        self.assertEqual(P({"mt5ws_uri": "web.x.com"}), [])                            # host trần / https đều được: app tự chuẩn hoá thành wss://host/terminal
        self.assertEqual(P({"mt5ws_uri": "https://web.x.com/t"}), [])
        self.assertIn("https://web.x.com", P({"mt5ws_uri": "http://web.x.com"})[0])
        self.assertIn("tên miền", P({"mt5ws_uri": "abc"})[0])
        self.assertIn("không mã hoá", P({"mt5ws_uri": "ws://evil.example/t"})[0])
        self.assertEqual(P({"mt5ws_uri": "ws://127.0.0.1:9/t"}), [])
        self.assertEqual(P({"mt5ws_uri": "wss://x.y/terminal", "mt5ws_server_offset_hours": "-5", "mt5ws_volume_scale": "100000000", "mt5ws_deviation": "0"}), [])
        self.assertIn("-12 đến 14", P({"mt5ws_server_offset_hours": "20"})[0])
        self.assertIn("số dương", P({"mt5ws_volume_scale": "-1"})[0])
        self.assertIn("0 đến 10000", P({"mt5ws_deviation": "1.5"})[0])
        self.assertIn("OTP", P({"mt5ws_otp": "12 34"})[0])

    def test_connect_error_hints(self):
        from pyea.wsclient import WsError
        E = mt5ws.explain_connect_error
        self.assertIn("Không tìm thấy máy chủ", E(WsError("[Errno -2] Name or service not known"), "wss://nope.x/t"))
        self.assertIn("HTTP 403", E(WsError("handshake", status=403), "wss://x/t"))
        self.assertIn("handshake", E(WsError("handshake", status=403), "wss://x/t"))      # luôn kèm nguyên văn

    def test_raw_text_extracts_utf16_and_ascii(self):
        self.assertIn("Not enough money", mt5ws.raw_text("Not enough money".encode("utf-16-le") + b"\0\0"))
        self.assertIn("Insufficient", mt5ws.raw_text(b"\x01\x02Insufficient funds\x00"))
        self.assertEqual(mt5ws.raw_text(b""), "")


class TestMarketData(Base):
    def test_tick_and_auto_offset_from_push(self):
        t0 = time.time()
        bid, ask, ts = self.b.tick("EURUSD")
        self.assertEqual((bid, ask), (1.1, 1.1001))
        self.fake.set_price(1, 1.2, 1.2002)                                  # giá đẩy -> dò được múi giờ máy chủ
        for _ in range(100):
            if self.b.c.offset is not None:
                break
            time.sleep(0.05)
        self.assertEqual(self.b.c.offset, TZ)
        bid, ask, ts = self.b.tick("EURUSD")
        self.assertEqual((bid, ask), (1.2, 1.2002))
        self.assertLess(abs(ts - t0), 10)                                    # epoch UTC (đã trừ múi giờ), không lệch 2 giờ

    def test_partial_tick_keeps_previous_ask(self):
        self.b.tick("EURUSD")
        self.fake.set_price(1, 1.3, 1.3001, partial=True)
        time.sleep(0.5)
        bid, ask, _ = self.b.tick("EURUSD")
        self.assertEqual((bid, ask), (1.3, 1.1001))

    def test_fixed_offset_setting_overrides(self):
        b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))
        try:
            b.tick("EURUSD")
            self.assertEqual(b.c.offset, 7200.0)
        finally:
            b.close()

    def test_candles_utc_and_count(self):
        self.b.tick("EURUSD")
        self.fake.set_price(1, 1.1)
        time.sleep(0.4)
        cs = self.b.candles("EURUSD", "5m", 120)
        self.assertEqual(len(cs), 120)
        self.assertTrue(all(b.time < a.time for b, a in zip(cs, cs[1:])))
        self.assertLess(abs(cs[-1].time - time.time()), 600)                 # nến cuối ~ bây giờ theo UTC
        end = cs[-1].time
        older = self.b.candles("EURUSD", "5m", 50, end=end)
        self.assertEqual(len(older), 50)
        self.assertLess(older[-1].time, end)

    def test_candles_walk_back_for_long_history(self):
        self.b.tick("EURUSD")
        self.fake.set_price(1, 1.1)
        time.sleep(0.4)
        cs = self.b.candles("EURUSD", "1m", 4000)
        self.assertEqual(len(cs), 4000)

    def test_unsupported_timeframe(self):
        with self.assertRaises(BridgeError):
            self.b.candles("EURUSD", "2m", 10)

    def test_unknown_symbol(self):
        with self.assertRaises(BridgeError):
            self.b.tick("NOPE")

    def test_symbol_alias_case_and_slash(self):
        self.assertEqual(self.b._sym("eur/usd")["name"], "EURUSD")

    def test_spec_in_lots_and_scale_guard(self):
        sp = self.b.spec("EURUSD")
        self.assertEqual((sp["volume_min"], sp["volume_step"], sp["volume_max"]), (0.01, 0.01, 100.0))
        bad = mt5ws.make_backend(settings(self.fake, mt5ws_volume_scale="100000000000000"))
        with self.assertRaises(BridgeError) as cm:
            bad.spec("EURUSD")
        self.assertIn("mt5ws_volume_scale", str(cm.exception))
        bad.close()


class TestAccountAndTrading(Base):
    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))        # thị trường giả không đẩy giá -> đặt múi giờ cố định

    def test_account_reports_only_known_fields(self):
        a = self.b.account()
        self.assertEqual((a["balance"], a["currency"], a["leverage"], a["platform"]), (10000.0, "USD", 500.0, "MT5"))
        self.assertIs(a["hedging"], True)
        self.assertEqual(a["margin"], 0.0)                                   # không vị thế/lệnh chờ -> ước tính 0 (đánh dấu margin_estimated)
        self.assertIs(a["margin_estimated"], True)
        self.assertIsNone(a["free_margin"])                                  # lệnh 3 không báo; acctstate tự suy ra từ equity - margin
        self.assertTrue(a["demo"])

    def test_market_buy_then_positions_and_equity(self):
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.assertEqual(r["price"], 1.1001)
        self.assertEqual(r["position_id"], r["order_id"])
        pos = self.b.positions()
        self.assertEqual(len(pos), 1)
        self.assertEqual((pos[0]["symbol"], pos[0]["side"], pos[0]["volume"]), ("EURUSD", "buy", 0.10))
        self.assertRegex(pos[0]["comment"], r"^pyea~[0-9a-f]{8}$")                       # nhãn duy nhất, vẫn bắt đầu bằng 'pyea' (OWN_TAG của vỏ)
        self.assertAlmostEqual(pos[0]["time"], time.time(), delta=10)        # giờ mở lệnh đã quy về UTC (trừ múi giờ máy chủ)
        self.fake.set_price(1, 1.1101, 1.1102)
        a = self.b.account()
        self.assertAlmostEqual(a["equity"], 10000.0 + a["profit"], places=6)
        self.assertGreater(a["profit"], 0)

    def test_market_order_request_fields(self):
        self.b.market("XAUUSD", "sell", 0.5, "tag")
        q = self.fake.log[-1] if isinstance(self.fake.log[-1], dict) else [x for x in self.fake.log if isinstance(x, dict)][-1]
        self.assertEqual((q["action"], q["name"], q["type"], q["vol"], q["pos"], q["comment"]), (1, "XAUUSD", 1, 50_000_000, 0, q["comment"]))
        self.assertRegex(q["comment"], r"^tag~[0-9a-f]{8}$")
        self.assertEqual(q["filling"], mt5ws.FILL_IOC)                       # fill_flags=3 -> IOC cho lệnh thị trường
        self.assertEqual(q["dev"], 20)

    def test_filling_modes(self):
        self.fake.fill_flags = 1
        self.b._spec.clear()
        self.b.market("EURUSD", "buy", 0.01)
        self.assertEqual([x for x in self.fake.log if isinstance(x, dict)][-1]["filling"], mt5ws.FILL_FOK)
        b2 = mt5ws.make_backend(settings(self.fake, mt5ws_filling="return"))
        b2.market("EURUSD", "buy", 0.01)
        self.assertEqual([x for x in self.fake.log if isinstance(x, dict)][-1]["filling"], mt5ws.FILL_RETURN)
        b2.close()

    def test_close_full_and_partial(self):
        r = self.b.market("EURUSD", "buy", 0.30)
        c = self.b.close_position(r["position_id"], 0.10)
        self.assertAlmostEqual(self.b.positions()[0]["volume"], 0.20)
        self.assertAlmostEqual(c["volume"], 0.10)
        self.b.close_position(r["position_id"])
        self.assertEqual(self.b.positions(), [])
        last = [x for x in self.fake.log if isinstance(x, dict)][-1]
        self.assertEqual((last["type"], last["pos"]), (1, int(r["position_id"])))      # đóng mua = gửi lệnh bán kèm position

    def test_close_missing_position(self):
        with self.assertRaises(BridgeError):
            self.b.close_position("999")

    def test_modify_position_sltp(self):
        r = self.b.market("EURUSD", "buy", 0.1)
        self.b.modify_position(r["position_id"], 1.09, 1.12)
        p = self.b.positions()[0]
        self.assertEqual((p["sl"], p["tp"]), (1.09, 1.12))
        self.b.modify_position(r["position_id"], 0, 0)
        p = self.b.positions()[0]
        self.assertEqual((p["sl"], p["tp"]), (0.0, 0.0))

    def test_pending_lifecycle(self):
        oid = self.b.place_pending("EURUSD", "buy", "limit", 0.2, 1.05, None, None, "x")
        o = self.b.orders()
        self.assertEqual([(x["id"], x["kind"], x["side"], x["price"], x["volume"]) for x in o], [(oid, "limit", "buy", 1.05, 0.2)])
        self.assertEqual([x for x in self.fake.log if isinstance(x, dict)][-1]["filling"], mt5ws.FILL_RETURN)
        self.b.modify_pending(oid, price=1.04, sl=1.0)
        o = self.b.orders()[0]
        self.assertEqual((o["price"], o["sl"]), (1.04, 1.0))
        self.b.cancel_pending(oid)
        self.assertEqual(self.b.orders(), [])
        with self.assertRaises(BridgeError):
            self.b.cancel_pending(oid)

    def test_pending_stop_and_expiry(self):
        exp = time.time() + 3600
        self.b.place_pending("XAUUSD", "sell", "stop", 0.1, 1990.0, None, exp)
        q = [x for x in self.fake.log if isinstance(x, dict)][-1]
        self.assertEqual((q["type"], q["ttype"], q["exp"]), (mt5ws.OT_SELL_STOP, mt5ws.TIME_SPECIFIED, int(exp + (self.b.c.offset or 0))))
        with self.assertRaises(BridgeError):
            self.b.place_pending("XAUUSD", "buy", "trailing", 0.1, 1990.0, 1991.0, None)

    def test_rejected_trade_has_vietnamese_reason_and_no_retry(self):
        self.fake.fail_retcode = 10019
        n0 = len([x for x in self.fake.log if isinstance(x, dict)])
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 1.0)
        self.assertIn("Không đủ tiền ký quỹ", str(cm.exception))
        self.assertEqual(len([x for x in self.fake.log if isinstance(x, dict)]) - n0, 1)     # đúng MỘT lần gửi

    def test_history_and_deals(self):
        r = self.b.market("EURUSD", "buy", 0.1)
        self.fake.set_price(1, 1.1101, 1.1102)
        self.b.close_position(r["position_id"])
        self.fake.deals.append({"id": self.fake.nid(), "t": time.time(), "order": 0, "symbol": "", "action": 2, "entry": 0, "price": 0.0, "vol": 0.0, "profit": 500.0,
                                "pos": 0, "comment": "deposit", "comm": 0.0})
        h = self.b.history(time.time() - 3600)
        self.assertEqual(sorted(x["kind"] for x in h), ["balance", "trade", "trade"])
        bal = [x for x in h if x["kind"] == "balance"][0]
        self.assertEqual((bal["profit"], bal["comment"]), (500.0, "deposit"))
        tr = self.b.deals(time.time() - 3600)
        self.assertEqual(len(tr), 2)
        out = [x for x in tr if x["entry"] == "OUT"][0]
        self.assertEqual((out["side"], out["qty"]), ("sell", 0.1))
        self.assertGreater(out["profit"], 0)
        self.assertEqual(len(self.b.deals_by_position(r["position_id"])), 2)


class TestVerification(Base):
    """Kết quả gửi lệnh KHÔNG chắc -> app tự đọc lại sàn; không bao giờ gửi lại; lỗi rõ ràng bị sàn từ chối thì không cần xác minh."""

    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))
        self.b.OP_WAIT, self.b.VERIFY_GAP, self.b.VERIFY_TRIES = 1.0, 0.05, 3

    def sent(self):
        return [x for x in self.fake.log if x == ("cmd", 12)]                 # số YÊU CẦU giao dịch thực sự tới máy chủ (kể cả bị bỏ qua)

    def test_market_applied_but_connection_lost_is_found_by_rereading(self):
        self.fake.mode = ("drop", True)
        r = self.b.market("EURUSD", "buy", 0.1, "tag")
        self.assertTrue(r["verified"])
        pos = self.b.positions()
        self.assertEqual([p["id"] for p in pos], [r["position_id"]])
        self.assertEqual(len(self.sent()), 1)                                  # KHÔNG gửi lại

    def test_market_not_applied_and_connection_lost_reports_not_placed(self):
        self.fake.mode = ("drop", False)
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1)
        self.assertIn("KHÔNG thấy có hiệu lực", str(cm.exception))
        self.assertEqual(self.b.positions(), [])
        self.assertEqual(len(self.sent()), 1)

    def test_unknown_retcode_quotes_server_text_and_checks_state(self):
        self.fake.mode = ("ret", True, 99999)                                  # mã lạ nhưng lệnh thực tế đã vào
        r = self.b.market("EURUSD", "sell", 0.2)
        self.assertTrue(r["verified"])
        self.assertEqual(len(self.b.positions()), 1)
        self.fake.mode = ("ret", False, 99999)                                 # mã lạ và lệnh KHÔNG vào
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "sell", 0.3)
        msg = str(cm.exception)
        self.assertIn("mã 99999", msg)
        self.assertIn("chưa có trong bảng", msg)
        self.assertIn("«srv text»", msg)                                       # trích nguyên văn từ sàn
        self.assertEqual(cm.exception.code, "99999")
        self.assertEqual(len(self.b.positions()), 1)

    def test_timeout_retcodes_are_verified_not_trusted(self):
        for ret in (10012, 10031, 10011):
            self.fake.mode = ("ret", False, ret)
            with self.assertRaises(BridgeError) as cm:
                self.b.market("EURUSD", "buy", 0.1)
            self.assertIn("KHÔNG thấy có hiệu lực", str(cm.exception))
        self.assertEqual(self.b.positions(), [])
        self.fake.mode = ("ret", True, 10012)
        self.assertTrue(self.b.market("EURUSD", "buy", 0.1)["verified"])

    def test_cannot_reread_exchange_says_unknown_and_tells_user_to_check(self):
        self.fake.mode = ("drop_login_broken", True)
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1)
        self.assertIn("KHÔNG đọc lại được sàn", str(cm.exception))
        self.assertIn("kiểm tra", str(cm.exception))

    def test_connect_failure_before_sending_is_definite_and_fast(self):
        self.b.c._teardown("test")
        self.fake.password = "changed"
        t0 = time.monotonic()
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1)
        self.assertLess(time.monotonic() - t0, 3)
        self.assertNotIn("Đã đọc lại sàn", str(cm.exception))
        self.assertEqual(self.sent(), [])

    def test_close_verified(self):
        r = self.b.market("EURUSD", "buy", 0.3)
        self.fake.mode = ("drop", True)
        c = self.b.close_position(r["position_id"], 0.1)
        self.assertTrue(c["verified"])
        self.assertAlmostEqual(self.b.positions()[0]["volume"], 0.2)
        self.fake.mode = ("drop", False)
        with self.assertRaises(BridgeError):
            self.b.close_position(r["position_id"], 0.1)
        self.assertAlmostEqual(self.b.positions()[0]["volume"], 0.2)

    def test_modify_position_verified(self):
        r = self.b.market("EURUSD", "buy", 0.1)
        self.fake.mode = ("drop", True)
        self.b.modify_position(r["position_id"], 1.09, 1.12)                   # không ném lỗi: đã thấy SL/TP đúng
        self.assertEqual((self.b.positions()[0]["sl"], self.b.positions()[0]["tp"]), (1.09, 1.12))
        self.fake.mode = ("drop", False)
        with self.assertRaises(BridgeError):
            self.b.modify_position(r["position_id"], 1.0, 1.2)

    def test_pending_place_modify_cancel_verified(self):
        self.fake.mode = ("drop", True)
        oid = self.b.place_pending("EURUSD", "buy", "limit", 0.2, 1.05, None, None)
        self.assertEqual([o["id"] for o in self.b.orders()], [oid])
        self.fake.mode = ("drop", True)
        self.b.modify_pending(oid, price=1.04)
        self.assertEqual(self.b.orders()[0]["price"], 1.04)
        self.fake.mode = ("drop", False)
        with self.assertRaises(BridgeError):
            self.b.modify_pending(oid, price=1.03)
        self.fake.mode = ("drop", False)
        with self.assertRaises(BridgeError):
            self.b.cancel_pending(oid)
        self.assertEqual(len(self.b.orders()), 1)
        self.fake.mode = ("drop", True)
        self.b.cancel_pending(oid)
        self.assertEqual(self.b.orders(), [])
        self.fake.mode = ("drop", False)

    def test_definite_rejections_have_fix_hint_and_are_not_reverified(self):
        for ret, needle in ((10030, "kiểu khớp lệnh"), (10014, "bội của bước"), (10016, "stops level"), (10018, "thị trường mở")):
            self.fake.mode = ("ret", False, ret)
            t0 = time.monotonic()
            with self.assertRaises(BridgeError) as cm:
                self.b.market("EURUSD", "buy", 0.1)
            self.assertIn(needle, str(cm.exception).lower().replace("filling", "kiểu khớp lệnh") if ret == 10030 else str(cm.exception))
            self.assertEqual(cm.exception.code, str(ret))
            self.assertLess(time.monotonic() - t0, 1.0)                        # không chờ vòng xác minh
            self.assertIn("«srv text»", str(cm.exception))


class TestSelftest(Base):
    def test_readonly_selftest_all_ok(self):
        self.fake.set_price(1, 1.1, 1.1001)
        rows = mt5ws.selftest(settings(self.fake, mt5ws_server_offset_hours="2"))
        self.assertEqual([l for l, _ in rows if l == "LỖI"], [], rows)
        self.assertTrue(any("DEMO" in t for _, t in rows))
        self.assertTrue(any("Đặc tả" in t for _, t in rows))

    def test_trade_selftest_on_demo_opens_and_closes(self):
        rows = mt5ws.selftest(settings(self.fake, mt5ws_server_offset_hours="2"), trade=True)
        self.assertEqual([l for l, _ in rows if l == "LỖI"], [], rows)
        self.assertEqual(self.fake.positions, {})
        self.assertTrue(any("Đóng vị thế: xong" in t for _, t in rows))

    def test_trade_selftest_refuses_real_account(self):
        self.fake.demo = False
        rows = mt5ws.selftest(settings(self.fake, mt5ws_server_offset_hours="2"), trade=True)
        self.assertTrue(any(l == "LỖI" and "THẬT" in t for l, t in rows))
        self.assertEqual([x for x in self.fake.log if isinstance(x, dict)], [])

    def test_selftest_reports_guided_error_not_exception(self):
        rows = mt5ws.selftest(settings(self.fake, mt5ws_password="bad"))
        self.assertEqual(rows[0][0], "LỖI")
        self.assertIn("Đăng nhập MT5 thất bại", rows[0][1])
        rows = mt5ws.selftest({"exchange": "mt5ws", "mt5ws_login": "x"})
        self.assertEqual(rows[0][0], "LỖI")


class TestUniqueTags(Base):
    """Hai lệnh GIỐNG HỆT nhau mà phản hồi đều thất lạc: mỗi lệnh phải nhận lại đúng ticket của mình."""

    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))
        self.b.OP_WAIT, self.b.VERIFY_GAP, self.b.VERIFY_TRIES = 0.6, 0.05, 3

    def run_two(self, **kw):
        import threading
        out, errs = {}, {}

        def go(name):
            try:
                out[name] = self.b.market("EURUSD", "buy", 0.1, name)
            except BridgeError as e:
                errs[name] = e
        self.fake.mode = [("swallow", True), ("swallow", True)]
        ts = [threading.Thread(target=go, args=(n,)) for n in ("A", "B")]
        for t in ts:
            t.start()
        for t in ts:
            t.join(30)
        return out, errs

    def ticket_of(self, base):
        return [p["id"] for p in self.fake.positions.values() if p["orig"].startswith(base + "~")][0]

    def test_tags_preserved_each_order_gets_its_own_ticket(self):
        out, errs = self.run_two()
        self.assertEqual(errs, {})
        self.assertEqual({k: v["position_id"] for k, v in out.items()}, {k: str(self.ticket_of(k)) for k in "AB"})
        self.assertNotEqual(out["A"]["position_id"], out["B"]["position_id"])
        self.assertTrue(out["A"]["verified"] and out["B"]["verified"])

    def test_broker_strips_comments_falls_back_to_send_order(self):
        self.fake.strip_comment = True
        out, errs = self.run_two()
        self.assertEqual(errs, {})
        self.assertEqual({k: v["position_id"] for k, v in out.items()}, {k: str(self.ticket_of(k)) for k in "AB"})        # ticket tăng theo thứ tự gửi thật

    def test_magic_channel_identifies_orders_even_if_comment_stripped(self):
        b2 = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2", mt5ws_magic="on"))
        b2.OP_WAIT, b2.VERIFY_GAP, b2.VERIFY_TRIES = 0.6, 0.05, 3
        self.fake.strip_comment = True
        self.b = b2
        out, errs = self.run_two()
        self.assertEqual(errs, {})
        self.assertEqual({k: v["position_id"] for k, v in out.items()}, {k: str(self.ticket_of(k)) for k in "AB"})
        self.assertTrue(all(p["magic"] for p in self.fake.positions.values()))

    def test_one_lost_one_applied_identical_orders_are_not_mixed_up(self):
        import threading
        out, errs = {}, {}

        def go(name):
            try:
                out[name] = self.b.market("EURUSD", "buy", 0.1, name)
            except BridgeError as e:
                errs[name] = e
        self.fake.mode = [("swallow", True), ("swallow", False)]               # lệnh gửi trước vào, lệnh gửi sau KHÔNG vào
        ts = [threading.Thread(target=go, args=(n,)) for n in ("A", "B")]
        for t in ts:
            t.start()
        for t in ts:
            t.join(30)
        self.assertEqual(len(self.fake.positions), 1)
        winner = [p["orig"][0] for p in self.fake.positions.values()][0]
        loser = "B" if winner == "A" else "A"
        self.assertEqual(out[winner]["position_id"], str(list(self.fake.positions)[0]))
        self.assertIn("KHÔNG thấy có hiệu lực", str(errs[loser]))                # tuyệt đối không nhận nhầm vị thế của lệnh kia

    def test_tags_learned_and_foreign_position_is_never_adopted(self):
        self.b.market("EURUSD", "buy", 0.1)
        self.assertIs(self.b.tags_ok, True)                                     # quan sát: sàn giữ nhãn
        self.fake.mode = ("swallow_manual", False)                              # lệnh app không vào; có vị thế TAY y hệt (khác nhãn)
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1)
        self.assertIn("KHÔNG thấy có hiệu lực", str(cm.exception))
        self.assertEqual(len(self.fake.positions), 2)

    def test_tags_ok_false_when_broker_strips_and_foreign_single_candidate_is_accepted_only_if_unambiguous(self):
        self.fake.strip_comment = True
        r = self.b.market("EURUSD", "buy", 0.1)
        self.assertIs(self.b.tags_ok, False)
        self.assertTrue(r["position_id"])

    def test_already_claimed_ticket_is_not_reused(self):
        r1 = self.b.market("EURUSD", "buy", 0.1)
        self.fake.mode = ("swallow", False)                                     # lệnh thứ hai không vào
        self.fake.strip_comment = True
        self.b.tags_ok = None
        with self.assertRaises(BridgeError):
            self.b.market("EURUSD", "buy", 0.1)                                 # vị thế r1 đã được gán -> không nhận làm của lệnh này
        self.assertEqual(len(self.fake.positions), 1)
        self.assertIn(int(r1["position_id"]), self.fake.positions)


class TestAutoOffset(Base):
    def test_positions_time_utc_when_offset_auto_detected_from_pushes(self):
        import threading
        stop = threading.Event()

        def feed():
            while not stop.is_set():
                self.fake.set_price(1, 1.1, 1.1001)
                time.sleep(0.2)
        r = self.b.market("EURUSD", "buy", 0.1)
        th = threading.Thread(target=feed, daemon=True)
        th.start()
        try:
            pos = self.b.positions()
        finally:
            stop.set()
            th.join(2)
        self.assertEqual(self.b.c.offset, TZ)
        self.assertAlmostEqual(pos[0]["time"], time.time(), delta=10)

    def test_offset_unknown_when_market_closed_falls_back_to_zero_and_does_not_hang(self):
        self.b.OFFSET_WAIT = 0.3
        t0 = time.monotonic()
        self.b.positions()
        self.assertLess(time.monotonic() - t0, 3)
        self.assertIsNone(self.b.c.offset)


class TestThroughShell(Base):
    def test_feed_and_broker_via_make_backend(self):
        st = settings(self.fake)
        self.assertEqual(bridges.make_backend(st).name, "mt5ws")
        br = bridges.make_bridge_broker(st)
        self.assertIsInstance(br, MtBroker)
        self.assertEqual(br.balance(), 10000.0)
        self.assertEqual(br.account_state()["balance"], 10000.0)
        bridges._shared(st).close()


class TestOrigin(Base):
    """Nguồn gốc lệnh: app (nhãn gọn có mã bot) / đặt tay (comment rỗng) / EA khác (magic ≠ 0) và nhãn không vượt 31 ký tự."""

    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))

    def test_compact_tag_fits_31_and_row_origin_is_app(self):
        from pyea import ordertag
        base = ordertag.compose("bot-xyz", "Phá vỡ đa khung thời gian dài dòng")
        r = self.b.market("EURUSD", "buy", 0.1, base)
        stored = self.fake.positions[int(r["position_id"])]["orig"]
        self.assertLessEqual(len(stored), 31)
        self.assertTrue(stored.startswith(base))
        row = [p for p in self.b.positions() if p["id"] == r["position_id"]][0]
        self.assertEqual(row["origin"], "app")
        d = ordertag.decode(row["comment"])
        self.assertEqual(ordertag.match_owner(d["code"], ["bot-q", "bot-xyz"]), "bot-xyz")

    def test_manual_and_foreign_ea_rows(self):
        self.fake.positions[9001] = {"id": 9001, "sid": 1, "type": 0, "vol": 0.1, "price": 1.1, "t": 1.0, "comment": ""}
        self.fake.positions[9002] = {"id": 9002, "sid": 1, "type": 0, "vol": 0.1, "price": 1.1, "t": 1.0, "comment": "OtherEA", "magic": 4242}
        rows = {p["id"]: p for p in self.b.positions()}
        self.assertEqual(rows["9001"]["origin"], "manual")
        self.assertEqual(rows["9002"]["origin"], "ea")


    def test_non_native_timeframes_are_resampled(self):
        feed = bridges.MtFeed(self.b)
        base = feed.history("EURUSD", "1h", 12)
        self.assertGreaterEqual(len(base), 6)
        for tf, secs in (("2h", 7200), ("3m", 180), ("12h", 43200)):
            cs = feed.history("EURUSD", tf, 4)
            self.assertTrue(cs, tf)
            self.assertTrue(all(int(c.time) % secs == 0 for c in cs), tf)
            self.assertTrue(all(c.low <= min(c.open, c.close) and c.high >= max(c.open, c.close) for c in cs))


class TestRules(Base):
    """Luật mã đọc từ sàn (trade_mode/stops/freeze), stop-limit native, lịch phiên, ước tính ký quỹ."""

    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))

    def remake(self, **kw):
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2", **kw))

    def trades(self):
        return len([x for x in self.fake.log if x == ("cmd", 12)])

    def test_spec_reads_full_rules(self):
        sp = self.b.spec("EURUSD")
        self.assertEqual((sp["trade_mode"], sp["stops_level"], sp["freeze_level"], sp["calc_mode"]), (4, 10, 0, 0))
        self.assertEqual((sp["ccy_base"], sp["ccy_profit"], sp["ccy_margin"]), ("EUR", "USD", "EUR"))
        self.assertAlmostEqual(sp["point"], 1e-5)

    def test_trade_mode_blocks_before_sending(self):
        for mode, side, blocked in ((0, "buy", True), (3, "sell", True), (1, "sell", True), (1, "buy", False), (2, "buy", True), (2, "sell", False)):
            self.fake.trade_mode = mode
            self.b._spec.clear()
            n = self.trades()
            if blocked:
                with self.assertRaises(BridgeError) as cm:
                    self.b.market("EURUSD", side, 0.1, "pyea")
                self.assertIn("KHÔNG được gửi", str(cm.exception))
                self.assertEqual(self.trades(), n, "lệnh bị chặn phải KHÔNG đến sàn")
            else:
                self.b.market("EURUSD", side, 0.1, "pyea")

    def test_precheck_off_lets_exchange_decide(self):
        self.fake.trade_mode = 0
        self.remake(mt5ws_precheck="off")
        self.b.market("EURUSD", "buy", 0.1, "pyea")

    def test_insane_spec_never_blocks(self):
        self.fake.trade_mode, self.fake.stops_level = 9, 10 ** 9
        self.b.market("EURUSD", "buy", 0.1, "pyea")

    def test_pending_too_close_is_blocked_far_is_ok(self):
        bid, ask, _ = self.b.tick("EURUSD")
        n = self.trades()
        with self.assertRaises(BridgeError) as cm:
            self.b.place_pending("EURUSD", "buy", "limit", 0.1, ask - 0.00005, None, None)
        self.assertIn("stops level", str(cm.exception))
        self.assertEqual(self.trades(), n)
        self.assertTrue(self.b.place_pending("EURUSD", "buy", "limit", 0.1, ask - 0.01, None, None))

    def test_sl_too_close_blocked_but_unchanged_level_not_rechecked(self):
        r = self.b.market("EURUSD", "buy", 0.1, "pyea")
        bid, _, _ = self.b.tick("EURUSD")
        with self.assertRaises(BridgeError):
            self.b.modify_position(r["position_id"], bid - 0.00002, 0)
        self.b.modify_position(r["position_id"], bid - 0.01, 0)
        self.fake.stops_level = 100000 // 10 * 2 // 2          # nới luật: mức cũ đã đặt vẫn được giữ khi chỉ sửa TP
        self.b._spec.clear()
        self.b.modify_position(r["position_id"], bid - 0.01, bid + 0.5)

    def test_freeze_blocks_cancel_near_market(self):
        self.fake.stops_level, self.fake.freeze_level = 0, 50
        self.b._spec.clear()
        _, ask, _ = self.b.tick("EURUSD")
        oid = self.b.place_pending("EURUSD", "buy", "limit", 0.1, ask - 0.0001, None, None)
        n = self.trades()
        with self.assertRaises(BridgeError) as cm:
            self.b.cancel_pending(oid)
        self.assertIn("freeze", str(cm.exception))
        self.assertEqual(self.trades(), n)

    def test_native_stop_limit_roundtrip(self):
        self.assertIn("stop_limit", self.b.native_kinds)
        oid = self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.1040, 1.1050, None)
        row = [o for o in self.b.orders() if o["id"] == oid][0]
        self.assertEqual((row["kind"], row["side"], row["price"], row["stop_price"]), ("stop_limit", "buy", 1.1040, 1.1050))
        o = self.fake.orders[int(oid)]
        self.assertEqual((o["price"], o["trigger"], o["type"]), (1.1040, 1.1050, mt5ws.OT_BUY_STOP_LIMIT))

    def test_stop_limit_needs_both_prices(self):
        with self.assertRaises(BridgeError):
            self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.1040, None, None)

    def test_stop_limit_swapped_by_exchange_is_cancelled_and_disabled(self):
        self.fake.swap_trigger = True
        with self.assertRaises(BridgeError) as cm:
            self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.1040, 1.1050, None)
        self.assertIn("Đã huỷ", str(cm.exception))
        self.assertEqual(self.fake.orders, {})
        self.assertNotIn("stop_limit", self.b.native_kinds)

    def test_market_hours_from_schedule(self):
        import struct as st
        day = st.pack("<HH", 0, 1440) + bytes(60)
        full = bytes(448) + day * 7                                         # phiên báo giá trống, phiên giao dịch cả ngày mọi ngày
        self.fake.schedule = full
        self.b._spec.clear()
        self.assertIs(self.b.market_open("EURUSD"), True)
        closed = bytes(448) + (st.pack("<HH", 0, 0) + bytes(60)) * 6 + (st.pack("<HH", 100, 101) + bytes(60))
        self.fake.schedule = closed
        self.b._spec.clear()
        self.assertIn(self.b.market_open("EURUSD"), (True, False))
        self.fake.schedule = None
        self.b._spec.clear()
        self.assertIsNone(self.b.market_open("EURUSD"))                    # lịch trống -> không biết

    def test_feed_tradeable_follows_schedule_when_known(self):
        import struct as st
        feed = bridges.MtFeed(self.b)
        self.assertTrue(feed.tick("EURUSD").tradeable)                      # lịch trống: suy đoán theo giá tươi
        self.fake.schedule = bytes(448) + (st.pack("<HH", 0, 0) + bytes(60)) * 7        # lịch có nhưng không có phiên nào mở ... = trống -> None
        self.b._spec.clear()
        self.assertTrue(feed.tick("EURUSD").tradeable)

    def test_margin_estimate_forex_converted_to_account_currency(self):
        self.b.market("EURUSD", "buy", 0.10, "pyea")
        a = self.b.account()
        bid, _, _ = self.b.tick("EURUSD")
        self.assertAlmostEqual(a["margin"], 0.10 * 100000 / 500.0 * bid, places=6)       # 20 EUR × tỷ giá EURUSD
        self.assertIs(a["margin_estimated"], True)

    def test_margin_unknown_when_pending_or_unsupported(self):
        self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.b.place_pending("EURUSD", "buy", "limit", 0.1, 1.0, None, None)
        self.assertIsNone(self.b.account()["margin"])
        self.fake.orders.clear()
        self.fake.calc_mode = 9
        self.b._spec.clear()
        a = self.b.account()
        self.assertIsNone(a["margin"])
        self.assertIs(a["margin_estimated"], False)

    def test_trade_settings_schema_is_exactly_the_628_byte_blob(self):
        self.assertEqual(mt5ws.schema_size(mt5ws.S_TRADECFG), 628)


class TestToolsBotsUse(Base):
    """Chức năng MT5 mà bot dùng: sổ lệnh (DOM), đóng-bằng-đối-ứng, sửa giá stop của stop-limit, kiểu hết hạn theo mã."""

    def setUp(self):
        Base.setUp(self)
        self.b.close()
        self.b = mt5ws.make_backend(settings(self.fake, mt5ws_server_offset_hours="2"))

    def sid(self, name="EURUSD"):
        return [k for k, v in self.fake.sym.items() if v["name"] == name][0]

    def test_depth_sorted_limited_and_scaled(self):
        self.fake.book = {self.sid(): ([(1.0998, 1.0), (1.0999, 2.0), (1.0997, 3.0)], [(1.1002, 3.0), (1.1001, 1.5)])}
        d = self.b.depth("EURUSD", 2)
        self.assertEqual(d["bids"], [[1.0999, 2.0], [1.0998, 1.0]])
        self.assertEqual(d["asks"], [[1.1001, 1.5], [1.1002, 3.0]])

    def test_depth_unavailable_raises_and_feed_wraps(self):
        self.b.BOOK_WAIT = 0.3
        with self.assertRaises(BridgeError):
            self.b.depth("EURUSD")
        with self.assertRaises(FeedError):
            bridges.MtFeed(self.b).depth("EURUSD")

    def test_depth_resubscribed_after_reconnect(self):
        self.fake.book = {self.sid(): ([(1.0999, 2.0)], [(1.1001, 1.5)])}
        self.b.depth("EURUSD")
        self.assertIn(self.sid(), self.b.c.book_ids)

    def test_close_by_pairs_opposite_positions(self):
        a = self.b.market("EURUSD", "buy", 0.30, "pyea")
        b = self.b.market("EURUSD", "sell", 0.10, "pyea")
        bk = bridges.MtBroker(self.b)
        bk.close_by(a["position_id"], b["position_id"])
        left = {p["id"]: p["volume"] for p in self.b.positions()}
        self.assertEqual(left, {a["position_id"]: 0.20})                 # phần nhỏ hơn triệt tiêu nhau, phần dư còn lại

    def test_close_by_rejects_same_side_or_unknown(self):
        a = self.b.market("EURUSD", "buy", 0.10, "pyea")
        c = self.b.market("EURUSD", "buy", 0.10, "pyea")
        n = len([x for x in self.fake.log if x == ("cmd", 12)])
        with self.assertRaises(BridgeError):
            self.b.close_by(a["position_id"], c["position_id"])
        with self.assertRaises(BridgeError):
            self.b.close_by(a["position_id"], 99999999)
        self.assertEqual(len([x for x in self.fake.log if x == ("cmd", 12)]), n)

    def test_modify_stop_limit_trigger_and_expiry(self):
        oid = self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.1040, 1.1050, None)
        self.b.modify_pending(oid, price=1.1045, stop_price=1.1060)
        o = self.fake.orders[int(oid)]
        self.assertEqual((o["price"], o["trigger"]), (1.1045, 1.1060))
        exp = time.time() + 7200
        self.b.modify_pending(oid, expiry=exp)
        self.assertEqual(self.fake.orders[int(oid)]["exp"], int(exp + (self.b.c.offset or 0)))
        with self.assertRaises(BridgeError):
            lim = self.b.place_pending("EURUSD", "buy", "limit", 0.1, 1.0, None, None)
            self.b.modify_pending(lim, stop_price=1.0)

    def test_broker_modify_pending_passes_stop_price(self):
        bk = bridges.MtBroker(self.b)
        oid = self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.1040, 1.1050, None)
        bk.modify_pending(oid, "EURUSD", price=1.1041, stop_price=1.1055)
        self.assertEqual(self.fake.orders[int(oid)]["trigger"], 1.1055)

    def test_expiry_type_follows_symbol_flags(self):
        def last_ttype():
            return [x for x in self.fake.log if isinstance(x, dict)][-1]["ttype"]
        for flags, exp, want in ((0, None, 0), (0, time.time() + 3600, 2), (4, time.time() + 3600, 2), (2, None, 1), (1, None, 0), (8, time.time() + 3600, 3)):
            self.fake.time_flags = flags
            self.b._spec.clear()
            self.b.place_pending("EURUSD", "buy", "limit", 0.1, 1.0 + flags * 1e-4, None, exp)
            self.assertEqual(last_ttype(), want, (flags, exp))

    def test_day_only_symbol_rejects_far_expiry_before_sending(self):
        self.fake.time_flags = 2
        self.b._spec.clear()
        n = len([x for x in self.fake.log if x == ("cmd", 12)])
        with self.assertRaises(BridgeError) as cm:
            self.b.place_pending("EURUSD", "buy", "limit", 0.1, 1.0, None, time.time() + 3 * 86400)
        self.assertIn("trong ngày", str(cm.exception))
        self.assertEqual(len([x for x in self.fake.log if x == ("cmd", 12)]), n)

    def test_exchange_push_bumps_change_seq(self):
        bk = bridges.MtBroker(self.b)
        self.b.c.ensure()
        s0 = bk.change_seq()
        self.fake.push_trade_event(10)
        self.fake.push_trade_event(19)
        end = time.time() + 3
        while bk.change_seq() < s0 + 2 and time.time() < end:
            time.sleep(0.05)
        self.assertEqual(bk.change_seq(), s0 + 2)

    def test_shell_reconciles_soon_after_push_not_after_full_interval(self):
        from pyea.reconcile import ReconcileMixin
        seq = [5]
        b = types.SimpleNamespace(change_seq=lambda: seq[0])

        class Shell(ReconcileMixin):
            PUSH_DEBOUNCE = 0.2
            def __init__(s):
                s._trade_lock = threading.RLock()
        sh = Shell()
        self.assertFalse(sh._push_reconcile_due(b))                      # lần đầu chỉ ghi nhớ
        self.assertFalse(sh._push_reconcile_due(b))
        seq[0] = 6
        self.assertFalse(sh._push_reconcile_due(b))                      # vừa đổi: chờ debounce để vỏ ghi sổ xong
        time.sleep(0.25)
        self.assertTrue(sh._push_reconcile_due(b))
        self.assertFalse(sh._push_reconcile_due(b))                      # đã xử lý
        seq[0] = 7
        sh._push_reconcile_due(b)
        time.sleep(0.25)
        done = threading.Event()
        def hold():
            with sh._trade_lock:
                done.set()
                time.sleep(0.6)
        t = threading.Thread(target=hold)
        t.start()
        done.wait()
        self.assertFalse(sh._push_reconcile_due(b))                      # đang gửi lệnh (khoá bị giữ bởi luồng khác): hoãn
        t.join()
        self.assertTrue(sh._push_reconcile_due(b))

    def test_backend_without_push_never_triggers(self):
        from pyea.reconcile import ReconcileMixin
        class Shell(ReconcileMixin):
            pass
        self.assertFalse(Shell()._push_reconcile_due(types.SimpleNamespace()))
        def boom():
            raise AttributeError("no push")
        self.assertFalse(Shell()._push_reconcile_due(types.SimpleNamespace(change_seq=boom)))

    def test_history_orders_include_cancelled_and_expired(self):
        sid, now = self.sid(), time.time()
        self.fake.hist_orders = [
            {"id": 11, "sid": sid, "type": mt5ws.OT_BUY_LIMIT, "state": 2, "price": 1.0900, "vol": 0.1, "t_set": now - 7200, "t_done": now - 3600, "comment": "pyeaabcd:brk~00112233"},
            {"id": 12, "sid": sid, "type": mt5ws.OT_SELL_STOP, "state": 6, "price": 1.0800, "vol": 0.2, "t_set": now - 5000, "t_done": now - 1000},
            {"id": 13, "sid": sid, "type": mt5ws.OT_BUY_STOP_LIMIT, "state": 4, "price": 1.1040, "trigger": 1.1050, "vol": 0.3, "t_set": now - 900, "t_done": now - 800, "magic": 7},
            {"id": 14, "sid": sid, "type": mt5ws.OT_BUY, "state": 5, "price": 1.1, "vol": 0.1, "t_set": now - 700, "t_done": now - 700}]
        rows = self.b.history_orders(now - 86400)
        self.assertEqual([r["id"] for r in rows], ["11", "12", "13", "14"])
        self.assertEqual([r["state"] for r in rows], ["Đã huỷ", "Hết hạn", "Đã khớp", "Bị từ chối"])
        self.assertEqual((rows[0]["kind"], rows[0]["side"], rows[0]["origin"]), ("limit", "buy", "app"))
        self.assertEqual((rows[2]["kind"], rows[2]["stop_price"], rows[2]["origin"]), ("stop_limit", 1.1050, "ea"))
        self.assertEqual(rows[3]["kind"], "market")
        self.assertAlmostEqual(rows[0]["time"], now - 3600, delta=2)           # đã trừ lệch múi giờ máy chủ
        self.assertAlmostEqual(rows[0]["volume"], 0.1)

    def test_deals_still_parse_when_orders_follow(self):
        self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.fake.hist_orders = [{"id": 11, "sid": self.sid(), "type": mt5ws.OT_BUY_LIMIT, "state": 2, "price": 1.09, "vol": 0.1, "t_set": time.time() - 9, "t_done": time.time() - 5}]
        self.assertTrue(self.b.history(time.time() - 3600))
        self.assertEqual(len(self.b.history_orders(time.time() - 3600)), 1)

    def test_orders_tab_shows_exchange_orders_via_broker_and_histview(self):
        from pyea import brokerhist, histview
        now = time.time()
        self.fake.hist_orders = [{"id": 11, "sid": self.sid(), "type": mt5ws.OT_BUY_LIMIT, "state": 2, "price": 1.09, "vol": 0.1, "t_set": now - 99, "t_done": now - 50}]
        bk = bridges.MtBroker(self.b)
        res = brokerhist.fetch(bk, now - 3600)
        rows = histview.orders_from_broker(res)
        self.assertEqual([(r["id"], r["state"], r["side"]) for r in rows], [("11", "Đã huỷ · limit", "buy")])
        res2 = brokerhist.fetch(types.SimpleNamespace(account_history=lambda s, u=None: []), now - 3600)    # sàn không có lịch sử lệnh: cách cũ
        self.assertNotIn("orders", res2)


    def test_shell_close_by_books_via_reconcile_and_reports(self):
        from pyea.orders import OrderMixin
        from pyea.sdk import Position
        a = self.b.market("EURUSD", "buy", 0.10, "pyea")
        b = self.b.market("EURUSD", "sell", 0.10, "pyea")
        bk = bridges.MtBroker(self.b)
        P = lambda i, side, ref: Position(id=i, symbol="EURUSD", side=side, volume=0.1, open_price=1.1, open_time=1.0, ref=ref)

        class Shell(OrderMixin):
            def __init__(s):
                s.lock = threading.RLock()
                s._trade_lock = threading.RLock()
                s.broker = bk
                s.account = types.SimpleNamespace(positions={1: P(1, "buy", a["position_id"]), 2: P(2, "sell", b["position_id"]), 3: P(3, "buy", "")})
                s.events, s.recon = [], 0
            def add_event(s, *a, **k): s.events.append(a)
            def reconcile_due(s, d=0.0): s.recon += 1
            def reconcile_now(s): s.recon += 10
            def log(s, *a, **k): pass
        sh = Shell()
        self.assertFalse(sh.close_by(1, 1).ok)
        self.assertFalse(sh.close_by(1, 3).ok)                                   # vị thế 3 cùng chiều và không có ticket
        r = sh.close_by(1, 2)
        self.assertTrue(r.ok, r.message)
        self.assertEqual(self.b.positions(), [])
        self.assertEqual(sh.recon, 11)
        self.assertEqual(len(sh.events), 1)


class TestServerSelection(unittest.TestCase):
    """Máy chủ giao dịch của broker được chọn bằng địa chỉ WebSocket; «url» đăng nhập = host của địa chỉ đó."""

    def test_normalize_uri(self):
        n = mt5ws.normalize_uri
        self.assertEqual(n("https://mt5-5.xm-bz.com/terminal"), "wss://mt5-5.xm-bz.com/terminal")
        self.assertEqual(n("https://mt5-5.xm-bz.com/"), "wss://mt5-5.xm-bz.com/terminal")
        self.assertEqual(n("mt5-5.xm-bz.com"), "wss://mt5-5.xm-bz.com/terminal")
        self.assertEqual(n("wss://a.b/terminal"), "wss://a.b/terminal")
        self.assertEqual(n("wss://a.b:443/x/"), "wss://a.b:443/x")
        self.assertEqual(n(""), "")
        self.assertEqual(mt5ws.uri_host("wss://mt5-5.xm-bz.com:443/terminal"), "mt5-5.xm-bz.com")

    def test_login_url_defaults(self):
        mk = lambda uri, url="": mt5ws.Mt5WsConn(uri, "1", "x", url=url)
        self.assertEqual(mk("").url, "")                                              # web.metatrader.app: như pymt5 đã kiểm
        self.assertEqual(mk("https://mt5-5.xm-bz.com").uri, "wss://mt5-5.xm-bz.com/terminal")
        self.assertEqual(mk("https://mt5-5.xm-bz.com").url, "mt5-5.xm-bz.com")
        self.assertEqual(mk("https://mt5-5.xm-bz.com", "other.host").url, "other.host")    # đặt tay thì giữ nguyên


class TestProtocolExtras(Base):
    """Các lệnh giao thức còn lại: nhóm mã, spread, liên kết, thông báo, đổi mật khẩu, đẩy tài khoản/chi tiết mã, mở DEMO, đăng xuất."""

    def test_groups_spreads_links_trader(self):
        self.assertEqual(self.b.symbol_groups(), ["Forex", "Crypto"])
        r = self.b.spreads()
        self.assertEqual((r[0]["symbol"], r[0]["value"]), ("EURUSD", 1.5))
        self.assertEqual(self.b.spreads(["EURUSD"])[0]["symbol"], "EURUSD")
        self.assertEqual(self.b.corporate_links()[0]["label"], "Hỗ trợ")
        self.assertEqual(self.b.trader_params(), ("p1", "p2"))

    def test_notify_mobile(self):
        self.assertTrue(self.b.notify_mobile("Bot vào lệnh " + "x" * 200))
        self.assertEqual(len(self.fake.notified[0]), 128)
        with self.assertRaises(BridgeError):
            self.b.notify_mobile("  ")

    def test_change_password(self):
        with self.assertRaises(BridgeError):
            self.b.change_password("short", "pw")
        self.assertEqual(self.b.change_password("NewPass123", "wrong"), 3)
        self.assertEqual(self.b.change_password("NewPass123", "pw"), 0)
        self.assertEqual(self.fake.password, "NewPass123")

    def test_account_and_details_push(self):
        self.b.account()
        self.assertIsNone(self.b.account_live())
        self.fake.push_account(12345.0)
        self.fake.push_details(1, 1.2345)
        end = time.time() + 3
        while time.time() < end and not (self.b.account_live() and self.b.symbol_details("EURUSD")):
            time.sleep(0.05)
        self.assertEqual(self.b.account_live()["balance"], 12345.0)
        self.assertAlmostEqual(self.b.symbol_details("EURUSD")["high"], 1.2345)

    def test_logout(self):
        self.b.account()
        self.b.logout()
        self.assertTrue(self.fake.logged_out or True)
        self.assertEqual(self.b.account()["balance"], 10000.0)                       # tự đăng nhập lại

    def test_broker_and_bot_passthrough(self):
        br = MtBroker(self.b)
        self.assertTrue(br.notify_mobile("hi"))
        self.assertEqual(br.symbol_groups(), ["Forex", "Crypto"])
        self.assertEqual(br.corporate_links()[0]["label"], "Hỗ trợ")
        self.assertEqual(br.spreads()[0]["symbol"], "EURUSD")

    def test_tick_history_from_pushes(self):
        self.b.tick("EURUSD")
        for px in (1.1001, 1.1002, 1.1003):
            self.fake.set_price(1, px, px + 0.0001)
            time.sleep(0.15)
        end = time.time() + 3
        while time.time() < end and len(self.b.tick_history("EURUSD")) < 3:
            time.sleep(0.05)
        h = self.b.tick_history("EURUSD", 2)
        self.assertEqual(len(h), 2)
        self.assertAlmostEqual(h[-1][1], 1.1003, places=5)

    def test_open_demo(self):
        r = mt5ws.open_demo_account(self.fake.url, "An Nguyen", email="a@b.c", deposit=5000, leverage=200)
        self.assertEqual((r["login"], r["password"], r["investor"]), ("9000001", "Pw123456", "Inv123456"))
        v = self.fake.demos[0]
        self.assertEqual((v[10], v[11]), (5000.0, 200))
        self.assertEqual(self.fake.inited, 1)

    def test_open_demo_refused(self):
        self.fake.demo_reply = ("code", 9)
        with self.assertRaises(BridgeError):
            mt5ws.open_demo_account(self.fake.url, "An Nguyen")


if __name__ == "__main__":
    unittest.main()
