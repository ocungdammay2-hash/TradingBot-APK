"""EA GIẢ nói giao thức PyEA-EA v1 (pyea/mt5ea.py) với sổ lệnh giả - để test máy chủ cục bộ/backend mà không cần MT5. KHÔNG chứng minh EA MQL5 thật chạy đúng."""
import socket
import threading
import time

from pyea import mt5ea
from pyea.mt5ea import dec, enc


class FakeEA:
    def __init__(self, port, token="secret-token", dead_fired=False, version=1):
        self.port, self.token, self.version = port, token, version
        self.sock = None
        self.stop = threading.Event()
        self.balance = 10000.0
        self.pos = {}                  # id -> dict
        self.orders = {}
        self.deals = []
        self.prices = {"EURUSD": (1.1000, 1.1002), "XAUUSD": (2000.0, 2000.5)}
        self.log = []
        self.next_id = 1000
        self.dead_fired = dead_fired
        self.dead_s, self.policy = 0.0, "hold"
        self.last_app = time.monotonic()
        self.subs = set()
        self.drop_replies = set()      # op bị "nuốt" trả lời (mô phỏng mất phản hồi)
        self.reject = None             # (code, err) cho lệnh giao dịch
        self.notified = []
        self.conn, self.ta = 1, 1
        self.dead_acted = 0
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        return self

    def close(self):
        self.stop.set()
        try:
            self.sock.close()
        except Exception:
            pass

    def bye_and_close(self, reason):
        self.send("BYE", reason=reason)
        time.sleep(0.1)
        self.kill_link()

    def kill_link(self):
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass

    def send(self, typ, **kv):
        try:
            self.sock.sendall(enc(typ, **kv))
        except Exception:
            pass

    def _run(self):
        s = socket.create_connection(("127.0.0.1", self.port), timeout=5)
        self.sock = s
        s.settimeout(0.2)
        hello = dict(v=self.version, token=self.token, login="123", server="Demo-1", company="Fake Broker", build=4000, ea="1.0", hedging=1, demo=1)
        if self.dead_fired:
            hello.update(dead_fired=1, dead_policy=getattr(self, 'dead_policy_sent', 'close_all'), dead_at=time.time() - 30, dead_acted=self.dead_acted)
        self.send("HELLO", **hello)
        buf = b""
        last_hb = last_tick = 0.0
        while not self.stop.is_set():
            try:
                chunk = s.recv(65536)
                if not chunk:
                    return
                buf += chunk
            except socket.timeout:
                pass
            except OSError:
                return
            while b"\n" in buf:
                raw, buf = buf.split(b"\n", 1)
                typ, d = dec(raw.decode())
                self.last_app = time.monotonic()
                self.log.append((typ, d))
                if typ == "WELCOME":
                    self.dead_s, self.policy = float(d["dead_s"]), d["policy"]
                elif typ == "CFG":
                    self.dead_s, self.policy = float(d["dead_s"]), d["policy"]
                elif typ == "SUB":
                    self.subs |= set(d["s"].split(","))
                elif typ == "REQ":
                    self._req(d)
            now = time.monotonic()
            if now - last_hb > 0.3:
                last_hb = now
                self.send("HB", t=time.time(), bal=self.balance, eq=self.balance, conn=self.conn, ta=self.ta)
            if now - last_tick > 0.2:
                last_tick = now
                for sym in self.subs:
                    if sym in self.prices:
                        b, a = self.prices[sym]
                        self.send("TICK", s=sym, b=b, a=a, t=time.time())

    def set_price(self, sym, b, a):
        self.prices[sym] = (b, a)

    def fire_deadman(self):
        """Mô phỏng EA áp chính sách người chết cho vị thế 'pyea'."""
        if self.policy == "close_all":
            for pid in [k for k, p in self.pos.items() if p["comment"].startswith("pyea")]:
                del self.pos[pid]
        elif self.policy == "breakeven":
            for p in self.pos.values():
                if p["comment"].startswith("pyea"):
                    p["sl"] = p["price"]

    def _oid(self):
        self.next_id += 1
        return str(self.next_id)

    def _res(self, rid, op, **kv):
        if op in self.drop_replies:
            return
        self.send("RES", rid=rid, ok=1, **kv)

    def _fail(self, rid, err, code=0):
        self.send("RES", rid=rid, ok=0, err=err, code=code)

    def _req(self, d):
        rid, op = d["rid"], d["op"]
        if op == "info":
            return self._res(rid, op, login="123")
        if op == "account":
            fl = sum(p.get("profit", 0.0) for p in self.pos.values())
            return self._res(rid, op, balance=self.balance, equity=self.balance + fl, margin=0.0, free_margin=self.balance, margin_level=0, profit=fl, credit=0, leverage=100,
                             currency="USD", hedging=1, demo=1, server="Demo-1", company="Fake Broker", name="Tester", trade_allowed=1)
        if op == "symbols":
            for n in self.prices:
                self.send("ROW", rid=rid, s=n)
            return self._res(rid, op, n=len(self.prices))
        if op == "tick":
            b, a = self.prices.get(d["s"], (0, 0))
            return self._res(rid, op, b=b, a=a, t=time.time())
        if op == "spec":
            return self._res(rid, op, volume_min=0.01, volume_max=100, volume_step=0.01, digits=5, contract_size=100000, tick_size=0.00001, tick_value=1, point=0.00001,
                             stops_level=10, freeze_level=0, trade_mode=4, fill_flags=3, time_flags=15, calc_mode=0, ccy_base="EUR", ccy_profit="USD", ccy_margin="EUR")
        if op == "candles":
            n, step = int(d["n"]), int(d["tf"]) * 60
            t0 = 1_700_000_000 - n * step
            for i in range(n):
                self.send("ROW", rid=rid, t=t0 + i * step, o=1.1, h=1.101, l=1.099, c=1.1005, v=10)
            return self._res(rid, op, n=n)
        if op == "positions":
            for pid, p in self.pos.items():
                self.send("ROW", rid=rid, **{**p, "id": pid})
            return self._res(rid, op, n=len(self.pos))
        if op == "orders":
            for oid, o in self.orders.items():
                self.send("ROW", rid=rid, **{**o, "id": oid})
            return self._res(rid, op, n=len(self.orders))
        if op in ("market", "close", "pending", "modify_pos", "modify_pending", "cancel") and self.reject:
            return self._fail(rid, self.reject[1], self.reject[0])
        if op == "market":
            pid = self._oid()
            b, a = self.prices[d["s"]]
            px = a if d["side"] == "buy" else b
            self.pos[pid] = {"s": d["s"], "side": d["side"], "vol": float(d["vol"]), "price": px, "sl": 0, "tp": 0, "t": time.time(), "comment": d["comment"], "profit": 0.0,
                             "swap": 0, "magic": 0, "reason": 3}
            self.send("EVT", k="trade")
            return self._res(rid, op, order=pid, position=pid, price=px, volume=d["vol"])
        if op == "close":
            p = self.pos.get(d["id"])
            if not p:
                return self._fail(rid, "Position not found", 10013)
            vol = float(d.get("vol") or p["vol"])
            if vol >= p["vol"] - 1e-9:
                del self.pos[d["id"]]
            else:
                p["vol"] -= vol
            self.send("EVT", k="trade")
            return self._res(rid, op, order=self._oid(), price=1.1, volume=vol)
        if op == "modify_pos":
            p = self.pos.get(d["id"])
            if not p:
                return self._fail(rid, "Position not found", 10013)
            p["sl"], p["tp"] = float(d["sl"]), float(d["tp"])
            return self._res(rid, op)
        if op == "pending":
            oid = self._oid()
            self.orders[oid] = {"s": d["s"], "side": d["side"], "kind": d["kind"], "vol": float(d["vol"]), "price": float(d["price"]), "sl": 0, "tp": 0,
                                "stop": float(d.get("stop") or 0), "type": 2, "comment": d["comment"], "magic": 0}
            return self._res(rid, op, order=oid, price=d["price"], volume=d["vol"])
        if op == "modify_pending":
            o = self.orders.get(d["id"])
            if not o:
                return self._fail(rid, "Order not found", 10013)
            if d.get("price"):
                o["price"] = float(d["price"])
            return self._res(rid, op)
        if op == "cancel":
            self.orders.pop(d["id"], None)
            return self._res(rid, op)
        if op == "history":
            for i, dl in enumerate(self.deals):
                self.send("ROW", rid=rid, **dl)
            return self._res(rid, op, n=len(self.deals))
        if op == "notify":
            self.notified.append(d["text"])
            return self._res(rid, op)
        self._fail(rid, "op lạ " + op)
