"""Các mục VỎ bổ sung (API 1.2): khớp một phần, chế độ Trace, cờ tài khoản từ sàn (canTrade/loại ký quỹ/tiền tệ),
lấp khoảng trống nến khi chạy live, đổi tên tham số bot (param_aliases), giờ hiển thị + âm/rung, SL/TP mặc định."""
import os
import sys
import tempfile
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX, FakeOandaX                    # noqa: E402
from pyea import loader, prefs                                         # noqa: E402
from pyea.backtest import _ReplayFeed                                  # noqa: E402
from pyea.broker import BinanceBroker, BinanceFuturesBroker, Fill, OandaBroker      # noqa: E402
from pyea.controller import LocalController                            # noqa: E402
from pyea.engine import Account, CandleBuilder, TradingSession         # noqa: E402
from pyea.feeds import FeedError                                       # noqa: E402
from pyea.sdk import API_VERSION, AccountInfo, Candle, OrderResult, Ret, Tick      # noqa: E402
from pyea.settings import clean_settings, default_settings             # noqa: E402
from pyea.shell import LOG_WINDOWS, AlertBook, default_stops, deploy_cfg, log_match  # noqa: E402


def make(alarms=None, **over):
    st = default_settings()
    st.update(mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0)
    st.update(over)
    sess = TradingSession(st, sync=True, feed=_ReplayFeed(), alarm_cb=(lambda t, x: alarms.append((t, x))) if alarms is not None else None)
    sess.events = deque(maxlen=100000)
    sess.account = Account(st["initial_balance"], st["commission_pct"], st["leverage"])
    sess.status = "running"
    sess.ready.set()
    return sess


def tk(sess, sym, bid, ask=None, t=1000.0):
    tick = Tick(sym, t, bid, bid if ask is None else ask)
    sess.process_tick(tick)
    return tick


def write_bot(d, name, body):
    p = os.path.join(d, name)
    with open(p, "w", encoding="utf-8") as f:
        f.write(body)
    return p


def log_levels(s):
    return [(lv, msg) for _, _, lv, msg in s.logs]


# ================================================================================ khớp một phần
class TestPartialFill(unittest.TestCase):
    class Half:
        supports_short, netting = True, False
        ratio = 0.5

        def market_order(self, sym, side, qty, reduce_only=False):
            return Fill(100.0, qty * self.ratio)

    def test_partial_fill_reported_and_booked(self):
        alarms = []
        s = make(alarms)
        s.broker = self.Half()
        tk(s, "BTCUSD", 100.0, 100.0)
        r = s.send_order("BTCUSD", "buy", 2)
        self.assertTrue(r)                                           # vẫn ok: có vị thế thật
        self.assertTrue(r.partial)
        self.assertAlmostEqual(r.volume, 1.0)
        self.assertAlmostEqual(r.remaining, 1.0)
        self.assertAlmostEqual(r.requested_volume, 2.0)
        self.assertIn("MỘT PHẦN", r.message)
        self.assertAlmostEqual(list(s.account.positions.values())[0].volume, 1.0)      # sổ chỉ ghi phần đã khớp
        self.assertTrue(any("một phần" in t.lower() for t, _ in alarms), alarms)
        ev = [e for e in s.events if e.kind == "open"][-1]
        self.assertIn("khớp một phần", ev.details)

    def test_full_fill_and_spot_fee_tolerance_are_not_partial(self):
        s = make()
        s.broker = self.Half()
        self.Half.ratio = 1.0
        tk(s, "BTCUSD", 100.0, 100.0)
        self.assertFalse(s.send_order("BTCUSD", "buy", 1).partial)
        self.Half.ratio = 0.999                                      # Spot trừ phí 0.1% bằng coin: không phải khớp một phần
        r = s.send_order("BTCUSD", "buy", 1)
        self.assertFalse(r.partial)
        self.assertEqual(r.remaining, 0.0)
        self.Half.ratio = 0.5

    def test_defaults_on_dataclasses(self):
        r = OrderResult()
        self.assertEqual((r.partial, r.remaining), (False, 0.0))
        self.assertEqual(AccountInfo().margin_mode, "")
        self.assertEqual(API_VERSION, "1.5")


# ================================================================================ Trace
BOT_TRACE = """from pyea import BaseBot
class B(BaseBot):
    def on_init(self):
        self.enabled_seen = []
    def on_tick(self, t):
        self.enabled_seen.append(self.api.trace_enabled)
        self.api.trace("kiểm tra điều kiện", rsi=31.123456789012, nhan="x" * 200)
        if not self.api.positions():
            self.api.buy(1)
"""


class TestTrace(unittest.TestCase):
    def _run(self, trace):
        d = tempfile.mkdtemp()
        p = write_bot(d, "tr.py", BOT_TRACE)
        s = make()
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="tr1")
        inst.trace_on = trace
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        tk(s, "BTCUSD", 100.0, 100.0, t=1010)
        tk(s, "BTCUSD", 101.0, 101.0, t=1020)
        return s, inst

    def test_off_by_default_writes_nothing(self):
        s, inst = self._run(False)
        self.assertEqual(len(inst.trace_buf), 0)
        self.assertFalse([1 for lv, _ in log_levels(s) if lv == "TRACE"])
        self.assertEqual(set(inst.bot.enabled_seen), {False})
        self.assertFalse(inst.summary()["trace"])

    def test_on_records_api_trace_orders_and_callbacks(self):
        s, inst = self._run(True)
        lines = [m for lv, m in log_levels(s) if lv == "TRACE"]
        self.assertTrue(any("kiểm tra điều kiện" in m and "rsi=31.123457" in m for m in lines), lines[:3])
        self.assertTrue(any("buy 1" in m and "OK" in m for m in lines), lines)       # kết quả lệnh của bot được ghi vết
        self.assertTrue(any("callback on_init" in m for m in lines), lines)          # callback khác on_tick được ghi
        self.assertFalse(any("callback on_tick" in m for m in lines))                 # on_tick không ghi tự động (mỗi tick)
        self.assertTrue(all(len(m) < 700 for m in lines))                             # giá trị dài bị cắt
        self.assertTrue(len(inst.trace_buf) > 0)
        self.assertTrue(inst.summary()["trace"])
        self.assertEqual(set(inst.bot.enabled_seen), {True})

    def test_set_trace_toggles_and_controller(self):
        d = tempfile.mkdtemp()
        p = write_bot(d, "tr.py", BOT_TRACE)
        s = make()
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="tr2")
        ctl = LocalController(s)
        self.assertTrue(ctl.set_trace("tr2", True))
        self.assertTrue(inst.trace_on)
        self.assertTrue(ctl.set_trace("tr2", False))
        self.assertFalse(inst.trace_on)
        self.assertFalse(ctl.set_trace("không-có", True))


# ================================================================================ cờ tài khoản
class StubBroker:
    supports_short, netting = True, False

    def __init__(self, flags):
        self.flags = flags
        self.calls = 0

    def account_flags(self):
        self.calls += 1
        return dict(self.flags)

    def market_order(self, sym, side, qty, reduce_only=False):
        return Fill(100.0, qty)


class TestAccountFlags(unittest.TestCase):
    def test_flags_flow_into_account_info_and_gate(self):
        alarms = []
        s = make(alarms)
        b = s.broker = StubBroker({"currency": "EUR", "margin_mode": "isolated", "can_trade": True})
        tk(s, "BTCUSD", 100.0, 100.0)
        pos = s.send_order("BTCUSD", "buy", 1)
        self.assertTrue(pos)
        s._check_account_flags()
        ai = s.account_info()
        self.assertEqual((ai.currency, ai.margin_mode, ai.trade_allowed), ("EUR", "isolated", True))
        s._check_account_flags()
        self.assertEqual(b.calls, 1)                                  # có giới hạn tần suất, không gọi sàn mỗi lần poll
        b.flags["can_trade"] = False
        s._flags_t = 0.0
        s._check_account_flags()
        self.assertFalse(s.account_info().trade_allowed)
        r = s.send_order("BTCUSD", "buy", 1)
        self.assertEqual(r.retcode, Ret.TRADE_DISABLED)
        self.assertIn("canTrade", r.message)
        self.assertTrue(any("không được phép" in t for t, _ in alarms), alarms)
        self.assertTrue(s.close_position(pos.id))                     # đóng lệnh vẫn được phép
        b.flags["can_trade"] = True
        s._flags_t = 0.0
        s._check_account_flags()
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))

    def test_broker_without_flags_keeps_defaults(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        s._check_account_flags()                                      # không broker: không lỗi
        ai = s.account_info()
        self.assertEqual((ai.currency, ai.margin_mode, ai.trade_allowed), ("USD", "", True))

    def test_failing_flags_do_not_break_polling(self):
        class Bad(StubBroker):
            def account_flags(self):
                raise RuntimeError("mạng chập chờn")
        s = make()
        s.broker = Bad({})
        s._check_account_flags()
        self.assertTrue(any("cờ tài khoản" in m for _, m in log_levels(s)))
        self.assertTrue(s.account_info().trade_allowed)


class TestBrokerFlags(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()
        cls.ox = FakeOandaX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()
        cls.ox.close()

    def setUp(self):
        self.fx.reset()
        self.ox.reset()

    def test_futures_flags(self):
        b = BinanceFuturesBroker("key123", "sekret", self.fx.base)
        self.assertEqual(b.account_flags(), {"currency": "USDT", "can_trade": True, "margin_mode": "cross"})
        self.fx.margin_type, self.fx.can_trade = "isolated", False
        f = b.account_flags()
        self.assertEqual((f["margin_mode"], f["can_trade"]), ("isolated", False))

    def test_spot_flags(self):
        b = BinanceBroker("key123", "sekret", self.fx.base)
        self.fx.can_trade = False
        f = b.account_flags()
        self.assertEqual((f["currency"], f["can_trade"]), ("USDT", False))
        self.assertNotIn("margin_mode", f)

    def test_bad_credentials_return_only_currency(self):
        b = BinanceFuturesBroker("key123", "sai-secret", self.fx.base)
        self.assertEqual(b.account_flags(), {"currency": "USDT"})     # lỗi chữ ký: bỏ qua trường, không ném lỗi

    def test_oanda_currency(self):
        self.ox.currency = "EUR"
        b = OandaBroker(self.ox.TOKEN, self.ox.ACC, self.ox.base)
        self.assertEqual(b.account_flags(), {"currency": "EUR"})


# ================================================================================ lấp khoảng trống nến live
BASE = 600000          # chia hết 60 và 3600


class StubFeed:
    def __init__(self, bars=None, fail=False):
        self.bars, self.fail, self.calls = bars or [], fail, []

    def history(self, sym, tf, n):
        self.calls.append((sym, tf, n))
        if self.fail:
            raise FeedError("sập")
        return list(self.bars)[-n:]


def bars(first, last, step=60):
    return [Candle(t, 10.0, 11.0, 9.0, 10.5) for t in range(first, last + 1, step)]


class TestBuilderGap(unittest.TestCase):
    def test_gap_detected_and_backfilled_in_order(self):
        b = CandleBuilder(60, tf="1m")
        b.seed(bars(BASE - 120, BASE), BASE + 30)                     # đóng: BASE-120, BASE-60 ; hiện tại: BASE
        b.update(BASE + 30, 10.0)
        self.assertIsNone(b.gap)
        b.update(BASE + 60 * 5 + 5, 12.0)                             # nhảy cóc: thiếu BASE+60 .. BASE+240 (4 nến)
        self.assertEqual(b.gap, (BASE, BASE + 300))
        n = b.backfill(bars(BASE - 300, BASE + 300))
        self.assertEqual(n, 4)
        self.assertEqual([c.time for c in b.closed], [BASE - 120, BASE - 60, BASE, BASE + 60, BASE + 120, BASE + 180, BASE + 240])
        self.assertIsNone(b.gap)
        self.assertEqual(b.backfill(bars(BASE - 300, BASE + 300)), 0)  # gọi lại: không chèn trùng

    def test_consecutive_bars_make_no_gap(self):
        b = CandleBuilder(60, tf="1m")
        b.update(BASE + 1, 1.0)
        b.update(BASE + 61, 1.0)
        b.update(BASE + 121, 1.0)
        self.assertIsNone(b.gap)


class TestSessionBackfill(unittest.TestCase):
    def _live(self, feed, exchange="binance"):
        s = make(exchange=exchange)
        s.sync = False                                                # như phiên live (không luồng nền nào được bật trong test)
        s.settings["exchange"] = exchange
        s.feed = feed
        b = CandleBuilder(60, tf="1m")
        b.seed(bars(BASE - 240, BASE), BASE + 10)
        s.builders[("BTCUSD", "1m")] = b
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 10)
        return s, b

    def test_gap_filled_before_next_tick_is_delivered(self):
        feed = StubFeed(bars(BASE - 600, BASE + 360))                 # như sàn thật: lịch sử kết thúc ở nến đang chạy (hiện tại)
        s, b = self._live(feed)
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 6 + 3)              # feed mất 5 nến
        self.assertEqual(len(feed.calls), 1)
        times = [c.time for c in b.closed]
        self.assertEqual(times[-6:], [BASE + 60 * i for i in range(0, 6)])
        self.assertIsNone(b.gap)
        msgs = [m for _, m in log_levels(s)]
        self.assertTrue(any("khoảng trống dữ liệu" in m for m in msgs))
        self.assertTrue(any("Đã lấp 5/5" in m for m in msgs), msgs)

    def test_failed_download_is_retried_after_cooldown_only(self):
        feed = StubFeed(fail=True)
        s, b = self._live(feed)
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 4 + 3)
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 4 + 6)
        self.assertEqual(len(feed.calls), 1)                          # chặn gọi dồn dập (20 giây)
        self.assertIsNotNone(b.gap)                                   # vẫn nhớ để thử lại
        feed.fail, feed.bars = False, bars(BASE - 600, BASE + 600)
        s._bf_last.clear()
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 4 + 9)
        self.assertIsNone(b.gap)
        self.assertEqual(len(feed.calls), 2)

    def test_forex_weekend_is_not_a_gap(self):
        feed = StubFeed(bars(BASE - 600, BASE + 600))
        s, b = self._live(feed, exchange="oanda")
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 2 * 86400 + 3)           # nghỉ 2 ngày (cuối tuần)
        self.assertEqual(feed.calls, [])
        self.assertIsNone(b.gap)

    def test_backtest_and_simulated_never_backfill(self):
        feed = StubFeed(bars(BASE - 600, BASE + 600))
        s, b = self._live(feed)
        s.sync = True
        tk(s, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 6 + 3)
        self.assertEqual(feed.calls, [])
        s2, b2 = self._live(StubFeed(bars(BASE - 600, BASE + 600)), exchange="simulated")
        tk(s2, "BTCUSD", 10.0, 10.0, t=BASE + 60 * 6 + 3)
        self.assertEqual(s2.feed.calls, [])


# ================================================================================ param_aliases
BOT_ALIAS = """from pyea import BaseBot, Input
class B(BaseBot):
    inputs = {"lot": Input(0.01, "Khối lượng"), "period": Input(14, "Chu kỳ")}
    param_aliases = {"lot_size": "lot"}
    def on_init(self):
        self.seen = dict(self.p.__dict__) if hasattr(self.p, "__dict__") else {}
"""


class TestParamAliases(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.path = write_bot(self.d, "al.py", BOT_ALIAS)
        cls, _ = loader.load_bot_class(self.path, False)
        self.inputs = loader.collect_inputs(cls, self.path)

    def test_aliases_collected_and_old_values_migrate(self):
        self.assertEqual(self.inputs.aliases, {"lot_size": "lot"})
        out = loader.build_params(self.inputs, {"lot_size": 0.5, "period": 20})
        self.assertEqual((out["lot"], out["period"]), (0.5, 20))

    def test_new_name_wins_when_both_saved(self):
        out = loader.build_params(self.inputs, {"lot_size": 0.5, "lot": 0.2})
        self.assertEqual(out["lot"], 0.2)

    def test_report_lists_dropped_and_new(self):
        dropped, fresh = loader.params_report(self.inputs, {"lot_size": 0.5, "zzz": 1})
        self.assertEqual(dropped, ["zzz"])                            # tên cũ có alias không bị coi là bỏ
        self.assertEqual(fresh, ["period"])                           # 'lot' đã có giá trị (qua alias)

    def test_plain_dict_inputs_still_work(self):
        from collections import OrderedDict
        plain = OrderedDict(self.inputs)
        self.assertEqual(loader.build_params(plain, {"lot": 1.5})["lot"], 1.5)

    def test_engine_logs_dropped_and_applies_alias(self):
        s = make()
        inst = s.attach(self.path, "BTCUSD", "1m", {"lot_size": 0.5, "zzz": 1}, iid="al1")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        self.assertEqual(inst.bot_params["lot"], 0.5)
        msgs = [m for lv, m in log_levels(s) if lv == "WARN"]
        self.assertTrue(any("zzz" in m and "KHÔNG còn" in m for m in msgs), msgs)
        self.assertTrue(any("Tham số mới" in m and "period" in m for _, m in log_levels(s)))


# ================================================================================ giờ hiển thị / âm-rung / SL-TP mặc định
class TestPrefsAndSettings(unittest.TestCase):
    def tearDown(self):
        prefs.apply(default_settings())

    def test_time_display_modes(self):
        prefs.apply({"time_display": "utc"})
        self.assertEqual(prefs.fmt_time("%d/%m %H:%M", 3600 * 5), "01/01 05:00")
        self.assertEqual(prefs.time_label(), "UTC")
        prefs.apply({"time_display": "offset", "time_offset_hours": 7})
        self.assertEqual(prefs.fmt_time("%H:%M", 0), "07:00")
        self.assertEqual(prefs.time_label(), "UTC+7")
        prefs.apply({"time_display": "offset", "time_offset_hours": -3.5})
        self.assertEqual(prefs.fmt_time("%H:%M", 0), "20:30")
        prefs.apply({"time_display": "gì-đó", "time_offset_hours": "abc"})          # hỏng -> mặc định an toàn
        self.assertEqual(prefs.time_label(), "giờ máy")
        prefs.apply({"time_display": "offset", "time_offset_hours": 99})            # kẹp trong ±14
        self.assertEqual(prefs.fmt_time("%H", 0), "14")

    def test_alarm_prefs(self):
        self.assertEqual(prefs.alarm_prefs(), (True, True))
        prefs.apply({"notify_sound": False, "notify_vibrate": True})
        self.assertEqual(prefs.alarm_prefs(), (False, True))

    def test_new_settings_have_defaults_and_coerce(self):
        d = default_settings()
        for k, v in (("notify_sound", True), ("notify_vibrate", True), ("time_display", "local"), ("time_offset_hours", 0.0),
                     ("default_sl_pct", 0.0), ("default_tp_pct", 0.0)):
            self.assertEqual(d[k], v, k)
        c = clean_settings({"time_display": "xyz", "time_offset_hours": 99, "default_sl_pct": -5, "notify_sound": False})
        self.assertEqual(c["time_display"], "local")
        self.assertLessEqual(c["time_offset_hours"], 14.0)
        self.assertGreaterEqual(c["default_sl_pct"], 0.0)
        self.assertFalse(c["notify_sound"])

    def test_default_stops(self):
        self.assertEqual(default_stops("buy", 100, 2, 4), (98.0, 104.0))
        sl, tp = default_stops("sell", 100, 2, 4)
        self.assertAlmostEqual(sl, 102.0)
        self.assertAlmostEqual(tp, 96.0)
        self.assertEqual(default_stops("buy", 100, 0, 0), (0.0, 0.0))
        self.assertEqual(default_stops("buy", 0, 2, 4), (0.0, 0.0))
        self.assertEqual(default_stops("buy", float("nan"), 2, 4), (0.0, 0.0))
        self.assertEqual(default_stops("buy", "abc", 2, 4), (0.0, 0.0))
        self.assertEqual(default_stops("buy", 100, 150, 0)[0], 0.0)    # SL âm không hợp lệ -> bỏ



class TestLotDisplay(unittest.TestCase):
    def tearDown(self):
        prefs.apply(default_settings())
        prefs.set_contracts({})

    def test_modes_and_contract_size(self):
        prefs.set_contracts({"EURUSD": 100000.0, "BTCUSD": 1.0, "BAD": "x", "NEG": -5})
        self.assertEqual(prefs.fmt_vol(0.1, "EURUSD"), "0.1")                        # native: như sàn (lot)
        prefs.apply({"lot_display": "units"})
        self.assertEqual(prefs.fmt_vol(0.1, "EURUSD"), "10000 đv")
        self.assertEqual(prefs.fmt_vol(0.5, "BTCUSD"), "0.5")                        # hợp đồng = 1: luôn như cũ
        self.assertEqual(prefs.fmt_vol(2.0, "KHONGCO"), "2")                         # mã lạ: như cũ
        self.assertEqual(prefs.fmt_vol(2.0), "2")
        prefs.apply({"lot_display": "both"})
        self.assertEqual(prefs.fmt_vol(0.1, "EURUSD"), "0.1 lot (10000 đv)")
        self.assertEqual(prefs.fmt_vol(0.123456789, "EURUSD"), "0.123457 lot (12345.7 đv)")
        prefs.apply({"lot_display": "rác"})                                          # giá trị lạ -> native
        self.assertEqual(prefs.fmt_vol(0.1, "EURUSD"), "0.1")
        prefs.set_contracts(None)
        prefs.apply({"lot_display": "units"})
        self.assertEqual(prefs.fmt_vol(0.1, "EURUSD"), "0.1")

    def test_setting_default_and_clean(self):
        self.assertEqual(default_settings()["lot_display"], "native")
        self.assertEqual(clean_settings({"lot_display": "xyz"})["lot_display"], "native")
        self.assertEqual(clean_settings({"lot_display": "both"})["lot_display"], "both")

    def test_snapshot_carries_contract_sizes_only_when_not_one(self):
        import json
        s = make(symbol_overrides='{"EURUSD": {"contract_size": 100000}}')
        s.watch = ["EURUSD", "BTCUSD"]
        tk(s, "EURUSD", 1.1, 1.1)
        tk(s, "BTCUSD", 100.0, 100.0)
        snap = s.snapshot()
        self.assertEqual(snap["contracts"], {"EURUSD": 100000.0})
        json.dumps(snap["contracts"])                                                # đi qua ipc được
        s.send_order("EURUSD", "buy", 0.1)
        self.assertEqual(s.snapshot()["contracts"], {"EURUSD": 100000.0})


class TestDeployCfg(unittest.TestCase):
    def test_paper_runs_immediately_with_backtest_params(self):
        c = deploy_cfg("/x/bots/ma_cross.py", "btcusd", "5m", {"fast": 8, "slow": 24}, [], live=False)
        self.assertEqual((c["iid"], c["symbol"], c["tf"], c["auto"]), ("ma_cross-BTCUSD-1", "BTCUSD", "5m", True))
        self.assertEqual(c["params"], {"fast": 8, "slow": 24})
        self.assertNotIn("account", c)

    def test_live_is_attached_but_not_started_and_params_are_copied(self):
        p = {"fast": 8}
        c = deploy_cfg("/x/dca.py", "ETHUSDT", "1h", p, [], live=True)
        self.assertFalse(c["auto"])
        p["fast"] = 99
        self.assertEqual(c["params"], {"fast": 8})                       # bản sao, không dính tham chiếu

    def test_unique_iid_including_other_accounts(self):
        taken = ["dca-ETHUSDT-1", "dca-ETHUSDT-2", "dca-BTCUSDT-1@acc9"]
        self.assertEqual(deploy_cfg("/x/dca.py", "ethusdt", "1h", {}, taken)["iid"], "dca-ETHUSDT-3")
        c = deploy_cfg("/x/dca.py", "BTCUSDT", "1h", {}, taken, account="acc9")
        self.assertEqual((c["iid"], c["account"]), ("dca-BTCUSDT-2@acc9", "acc9"))
        self.assertNotIn("account", deploy_cfg("/x/dca.py", "BTCUSDT", "1h", {}, [], account="main"))



def _falling_then_rising(n_down=30, n_up=25, start=100.0):
    out, px = [], start
    for _ in range(n_down):
        px -= 0.7
        out.append(px)
    for _ in range(n_up):
        px += 0.9
        out.append(px)
    return out


class TestIndicatorAlerts(unittest.TestCase):
    def book(self):
        return AlertBook(os.path.join(tempfile.mkdtemp(), "alerts.json"))

    def fires(self, b, closes, sym="BTCUSD", tf="1m", start=20):
        out = []
        for i in range(start, len(closes) + 1):                       # mô phỏng từng nến đóng: chuỗi dài dần
            out += b.check_candles(sym, tf, closes[:i])
        return out

    def test_validation(self):
        b = self.book()
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "rsi_above", 50, tf="")                   # thiếu khung
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "rsi_above", 50, tf="7z")                 # khung lạ
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "rsi_above", 120, tf="1m")                # mức RSI ngoài (0,100)
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "rsi_above", 50, tf="1m", period=1)       # chu kỳ quá nhỏ
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "ma_up", 0, tf="1m", period=26, period2=12)   # nhanh phải < chậm
        with self.assertRaises(ValueError):
            b.add("BTCUSD", "xyz", 1)
        a = b.add("btcusd", "ma_up", 0, tf="5m", period=9, period2=21)
        self.assertEqual((a.symbol, a.kind, a.tf, a.period, a.period2, a.value), ("BTCUSD", "ma_up", "5m", 9, 21, 9.0))
        self.assertIn("EMA(9) cắt LÊN EMA(21) (5m)", a.describe())
        self.assertIn("RSI(14,1h) cắt XUỐNG mức 70", b.add("ETHUSD", "rsi_below", 70, tf="1h").describe())

    def test_rsi_cross_up_fires_once_on_the_crossing_candle(self):
        closes = _falling_then_rising()
        b = self.book()
        b.add("BTCUSD", "rsi_above", 50, tf="1m", period=5)
        f = self.fires(b, closes)
        self.assertEqual(len(f), 1)
        self.assertIn("RSI", f[0][1])
        self.assertIn("cắt LÊN", f[0][1])
        self.assertFalse(b.list()[0].active)                           # báo 1 lần
        self.assertEqual(self.fires(b, closes), [])                    # đã tắt: không báo nữa

    def test_rsi_cross_down_and_repeat(self):
        import math
        closes = [100.0 + 10.0 * math.sin(i / 4.0) for i in range(120)]    # dao động qua lại: RSI cắt mức 50 nhiều lần
        b = self.book()
        b.add("BTCUSD", "rsi_below", 50, tf="1m", period=5, repeat=True)
        f = self.fires(b, closes)
        self.assertGreaterEqual(len(f), 2)                             # lặp lại: mỗi lần cắt xuống đều báo
        self.assertTrue(b.list()[0].active)
        self.assertEqual(b.list()[0].count, len(f))

    def test_ema_cross_up_and_down(self):
        up = _falling_then_rising(30, 30)
        b = self.book()
        b.add("BTCUSD", "ma_up", 0, tf="1m", period=5, period2=15)
        self.assertEqual(len(self.fires(b, up, start=16)), 1)
        down = [100 + (i % 2) * 0.01 for i in range(20)] + [100 - 0.8 * i for i in range(1, 30)]
        b2 = self.book()
        b2.add("BTCUSD", "ma_down", 0, tf="1m", period=5, period2=15)
        f = self.fires(b2, down, start=16)
        self.assertEqual(len(f), 1)
        self.assertIn("cắt XUỐNG", f[0][1])

    def test_only_matching_symbol_tf_and_not_enough_data(self):
        closes = _falling_then_rising()
        b = self.book()
        b.add("BTCUSD", "rsi_above", 50, tf="1m", period=5)
        self.assertEqual(self.fires(b, closes, sym="ETHUSD"), [])
        self.assertEqual(self.fires(b, closes, tf="5m"), [])
        self.assertEqual(b.check_candles("BTCUSD", "1m", closes[:3]), [])      # chưa đủ nến cho RSI
        self.assertEqual(b.check_candles("BTCUSD", "1m", []), [])
        self.assertEqual(b.ind_needs(), {("BTCUSD", "1m")})

    def test_tick_check_ignores_indicator_alerts_and_persistence(self):
        b = self.book()
        b.add("BTCUSD", "rsi_above", 50, tf="1m", period=5)
        b.add("BTCUSD", "above", 105.0)
        self.assertEqual(b.check(Tick("BTCUSD", 1.0, 1000.0, 1000.0))[0][0].kind, "above")   # chỉ cảnh báo giá được kích bởi tick
        self.assertEqual(len(b.list()), 2)
        b2 = AlertBook(b.path)                                         # lưu/nạp giữ nguyên trường chỉ báo
        ind = [a for a in b2.list() if a.kind == "rsi_above"][0]
        self.assertEqual((ind.tf, ind.period, ind.active), ("1m", 5, True))
        import json
        with open(b.path, "r", encoding="utf-8") as f:                 # file cũ (trước v1.5) không có tf/period vẫn nạp được
            d = json.load(f)
        for a in d["alerts"]:
            for k in ("tf", "period", "period2"):
                a.pop(k, None)
        with open(b.path, "w", encoding="utf-8") as f:
            json.dump(d, f)
        self.assertEqual(len(AlertBook(b.path).list()), 2)

    def _session(self, **kw):
        s = make(**kw)
        return s

    def test_session_fires_on_closing_candle_and_notifies(self):
        alarms = []
        d = tempfile.mkdtemp()
        s = TradingSession(dict(default_settings(), mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0,
                                spread_pct=0.0, max_loss_pct=0.0), sync=True, feed=_ReplayFeed(), alerts_file=os.path.join(d, "a.json"),
                           alarm_cb=lambda t, x: alarms.append((t, x)))
        s.events = deque(maxlen=1000)
        s.account = Account(10000.0, 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        allc = _falling_then_rising(30, 25)
        pre, closes = allc[:30], allc[30:]                             # lịch sử đã giảm sẵn; các tick sau đó tăng dần
        b = CandleBuilder(60, tf="1m")
        b.seed([Candle(BASE - 60 * (len(pre) - i), p, p, p, p) for i, p in enumerate(pre)], BASE)
        s.builders[("BTCUSD", "1m")] = b
        s.alert_add("BTCUSD", "rsi_above", 50, "test", False, "1m", 5, 0)
        for i, px in enumerate(closes):                                # mỗi nến 1 tick; nến i đóng khi tick nến i+1 đến
            tk(s, "BTCUSD", px, px, t=BASE + 60 * i + 5)
        tk(s, "BTCUSD", closes[-1], closes[-1], t=BASE + 60 * len(closes) + 5)
        ev = [e for e in s.events if e.kind == "note"]
        self.assertEqual(len(ev), 1)
        self.assertIn("Cảnh báo chỉ báo", ev[0].reason)
        self.assertTrue(any(t.startswith("Cảnh báo chỉ báo") for t, _ in alarms), alarms)
        self.assertFalse(s.alerts.list()[0].active)

    def test_session_add_needs_candles_and_rolls_back_on_failure(self):
        d = tempfile.mkdtemp()
        s = TradingSession(dict(default_settings(), mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0,
                                spread_pct=0.0, max_loss_pct=0.0), sync=True, feed=StubFeed(fail=True), alerts_file=os.path.join(d, "a.json"))
        s.account = Account(10000.0, 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        tk(s, "BTCUSD", 100.0, 100.0, t=BASE)
        with self.assertRaises(ValueError) as cm:
            s.alert_add("BTCUSD", "rsi_above", 50, "", False, "1m", 14, 0)
        self.assertIn("nạp được nến", str(cm.exception))
        self.assertEqual(s.alerts.list(), [])                          # không để lại cảnh báo không tính được

    def test_restart_builds_missing_builders_for_saved_alerts(self):
        d = tempfile.mkdtemp()
        path = os.path.join(d, "a.json")
        AlertBook(path).add("BTCUSD", "ma_up", 0, tf="1m", period=5, period2=15)
        feed = StubFeed(bars(BASE - 60 * 30, BASE))
        s = TradingSession(dict(default_settings(), mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0,
                                spread_pct=0.0, max_loss_pct=0.0), sync=True, feed=feed, alerts_file=path)
        s.account = Account(10000.0, 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        tk(s, "BTCUSD", 100.0, 100.0, t=BASE)
        s.sync = False
        s._ensure_alert_builders()
        self.assertIn(("BTCUSD", "1m"), s.builders)
        n = len(feed.calls)
        s._ensure_alert_builders()
        self.assertEqual(len(feed.calls), n)                           # đã có thì không tải lại


class TestLogMatch(unittest.TestCase):
    NOW = 100000.0

    def m(self, line="bot ma_cross mở lệnh", rank=0, min_rank=0, text="", ts=None, window=0.0):
        return log_match(line, rank, min_rank, text, ts, window, self.NOW)

    def test_level_text_and_window_combine(self):
        self.assertTrue(self.m())
        self.assertFalse(self.m(rank=0, min_rank=1))
        self.assertTrue(self.m(rank=2, min_rank=1))
        self.assertTrue(self.m(text="MA_CROSS"))                                 # không phân biệt hoa thường
        self.assertFalse(self.m(text="rsi"))
        self.assertTrue(self.m(ts=self.NOW - 100, window=900))
        self.assertFalse(self.m(ts=self.NOW - 1000, window=900))
        self.assertTrue(self.m(ts=self.NOW - 900, window=900))                   # đúng mép: còn hiện
        self.assertTrue(self.m(ts=1.0, window=0.0))                              # mọi lúc: cũ đến đâu cũng hiện
        self.assertTrue(self.m(ts=None, window=900))                             # không có ts: không loại
        self.assertFalse(self.m(ts=self.NOW - 1000, window=900, text="ma_cross"))

    def test_windows_are_ordered_and_start_with_all(self):
        vals = list(LOG_WINDOWS.values())
        self.assertEqual(vals[0], 0.0)
        self.assertEqual(vals[1:], sorted(vals[1:]))


class TestChangelog(unittest.TestCase):
    def test_changelog_matches_versions(self):
        from pyea import __version__
        from pyea.changelog import API_CHANGES, CHANGELOG, api_changes_text, changelog_text
        self.assertEqual(CHANGELOG[0][0], __version__)                    # quên ghi changelog khi tăng phiên bản -> test đỏ
        self.assertEqual(API_CHANGES[0][0], API_VERSION)                  # quên ghi lịch sử API khi tăng API_VERSION -> test đỏ
        self.assertIn("Trace", changelog_text(32))                          # 1.5.0 là bản thứ 32 từ 1.9.25 (đổi số khi thêm bản mới)
        self.assertIn("param_aliases", api_changes_text())


if __name__ == "__main__":
    unittest.main()
