"""Cô lập bot trên ANDROID: dịch vụ worker p4a qua socket loopback (botproc.py + service_botworker.py).

Môi trường phát triển không có Android, nên: đường truyền socket, giao thức, worker (service_botworker.main) và cưỡng chế quyền mạng được chạy bằng TIẾN TRÌNH
PYTHON THẬT khởi động qua điểm tiêm `botproc.LAUNCHER`/`KILLER` (giả lập «startService/stopService» của p4a: môi trường sạch, chỉ có PYTHON_SERVICE_ARGUMENT).
Toàn bộ bộ test chế độ process có sẵn (test_botproc, test_bot_store_perms) được CHẠY LẠI trên đường truyền socket bằng lớp con - không viết lại kịch bản.
Phần pyjnius (autoclass/start/stop) chỉ kiểm bằng jnius giả theo đúng tài liệu p4a; chưa chạy trên thiết bị thật."""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import types
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

import test_bot_store_perms as tp                                              # noqa: E402
import test_botproc as tb                                                      # noqa: E402
from pyea import android_native, botproc                                       # noqa: E402


class Android:
    """Giả lập startService/stopService của p4a bằng tiến trình thật: môi trường SẠCH (dịch vụ khác tiến trình không thừa hưởng os.environ của cha)."""

    def __init__(self):
        self.procs, self.launched, self.killed = {}, [], []
        self.cwd = tempfile.mkdtemp()

    def launch(self, slot, argument):
        self.launched.append((slot, json.loads(argument)))
        code = "import sys; sys.path.insert(0, %r); import service_botworker; service_botworker.main()" % ROOT
        env = {"PATH": os.defpath, "PYTHON_SERVICE_ARGUMENT": argument, "PYTHONDONTWRITEBYTECODE": "1", "LANG": "C.UTF-8"}
        self.procs[slot] = subprocess.Popen([sys.executable, "-s", "-c", code], env=env, cwd=self.cwd, stdin=subprocess.DEVNULL,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True, ""

    def kill(self, slot):
        self.killed.append(slot)
        p = self.procs.get(slot)
        if p is not None and p.poll() is None:
            p.kill()

    def alive(self, slot):
        p = self.procs.get(slot)
        return p is not None and p.poll() is None

    def cleanup(self):
        for p in self.procs.values():
            if p.poll() is None:
                p.kill()
            try:
                p.wait(3)
            except subprocess.TimeoutExpired:
                pass


class SocketTransport:
    """Mixin: chạy mọi test của lớp cha trên đường truyền socket + worker giả lập."""
    SLOTS = 4

    def setUp(self):
        super().setUp()
        self.android = Android()
        self._saved = (botproc.TRANSPORT, botproc.LAUNCHER, botproc.KILLER, botproc.POOL, botproc.SLOT_COOLDOWN_S, botproc.ACCEPT_S)
        botproc.TRANSPORT, botproc.LAUNCHER, botproc.KILLER = "socket", self.android.launch, self.android.kill
        botproc.POOL, botproc.SLOT_COOLDOWN_S, botproc.ACCEPT_S = botproc.SlotPool(self.SLOTS), 0.0, 30.0

    def tearDown(self):
        super().tearDown()
        (botproc.TRANSPORT, botproc.LAUNCHER, botproc.KILLER, botproc.POOL, botproc.SLOT_COOLDOWN_S, botproc.ACCEPT_S) = self._saved
        self.android.cleanup()


# ================================================================== chạy lại bộ test chế độ process có sẵn trên đường truyền socket
class TestProcessRunnerOverSocket(SocketTransport, tb.TestProcessRunner):
    def test_hanging_bot_is_killed(self):                                       # bản gốc đọc pid số từ nhật ký + /proc; ở đây worker dừng bằng «stopService»
        body = tb.HEAD + "class H(BaseBot):\n    def on_tick(self, t):\n        while True:\n            pass\n"
        s, inst = self.run_bot(body, bot_hang_kill_s=1.5)
        self.assertTrue(tb.wait(lambda: inst.status == "error", 25), self.logs(s))
        self.assertIn("treo", self.logs(s))
        self.assertIn("đã giết", self.logs(s))
        self.assertTrue(s.is_alive())
        self.assertTrue(tb.wait(lambda: 0 in self.android.killed))             # vỏ gọi dừng dịch vụ worker (p4a: onDestroy -> killProcess)
        self.assertTrue(tb.wait(lambda: not self.android.alive(0), 5))         # tiến trình worker thật sự biến mất

    def test_falls_back_to_thread_mode_when_unavailable(self):                  # bản gốc dựa vào «Android không có thông dịch»; ở đây làm worker không khởi động được
        botproc.LAUNCHER = lambda slot, arg: (False, "Traceback...\nClassNotFound: ServiceBotworker0")
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: s.account is not None and len(s.account.positions) == 1), self.logs(s))
        self.assertIn("Cô lập tiến trình không dùng được", self.logs(s))
        self.assertIn("ClassNotFound: ServiceBotworker0", self.logs(s))
        self.assertNotIn("TIẾN TRÌNH RIÊNG (pid", self.logs(s))
        self.assertEqual(botproc.POOL.free(), self.SLOTS)                       # chỗ được trả lại

    def test_process_is_cleaned_up_on_stop(self):
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: inst.status == "running"))
        proc = inst.bot.proc
        inst.stop()
        self.assertTrue(tb.wait(lambda: proc.poll() is not None, 15))
        self.assertTrue(tb.wait(lambda: not self.android.alive(0), 10))        # worker tự kết thúc (hoặc bị dừng): không sót tiến trình
        self.assertTrue(tb.wait(lambda: botproc.POOL.free() == self.SLOTS, 5))


class TestNetworkPermissionsOverSocket(SocketTransport, tp.TestNetworkPermissionsInProcessMode):
    """Quyền mạng của bot (mặc định không có mạng) vẫn cưỡng chế trong worker - và rào không làm hỏng chính kênh socket của vỏ."""


# ================================================================== riêng đường truyền socket
class TestSocketTransport(SocketTransport, tb.ProcBase):
    def run_two(self, n):
        path = tb.write(self.d, "b.py", tb.TRADER)
        s = tb.TradingSession(tb.S(), log_file=None)
        s.data_dir = self.d
        self.sessions.append(s)
        insts = [s.attach(path, "BTCUSD", "1m", {"lot": 0.01}, iid="p%d" % k) for k in range(n)]
        s.start()
        for i in insts:
            i.start()
        return s, insts

    def test_worker_gets_a_slot_a_private_port_and_a_one_time_token(self):
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: inst.status == "running"), self.logs(s))
        slot, arg = self.android.launched[0]
        self.assertEqual((slot, sorted(arg)), (0, ["data_dir", "port", "slot", "token"]))
        self.assertGreaterEqual(len(arg["token"]), 32)
        self.assertIn("pid worker0", self.logs(s))
        with self.assertRaises(OSError):                                       # cổng chỉ nhận MỘT kết nối rồi đóng: không còn ai nghe
            socket.create_connection(("127.0.0.1", arg["port"]), timeout=1).close()

    def test_print_from_bot_goes_to_child_log_not_to_the_protocol_channel(self):
        body = tb.HEAD + 'class P(BaseBot):\n    def on_init(self):\n        print("HELLO-FROM-BOT-STDOUT")\n    def on_tick(self, t):\n        pass\n'
        s, inst = self.run_bot(body)
        self.assertTrue(tb.wait(lambda: inst.status == "running"), self.logs(s))
        wd = os.path.join(self.d, "bot_data")
        log = None
        for root, _, files in os.walk(self.d):
            if "child.log" in files:
                log = os.path.join(root, "child.log")
        self.assertIsNotNone(log, os.listdir(self.d))
        self.assertTrue(tb.wait(lambda: "HELLO-FROM-BOT-STDOUT" in open(log, encoding="utf-8").read()))
        self.assertEqual(inst.status, "running")                               # không làm hỏng giao thức JSON

    def test_slot_is_released_and_reused_after_stop(self):
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: inst.status == "running"))
        inst.stop()
        self.assertTrue(tb.wait(lambda: inst.status in ("stopped", "error"), 15), self.logs(s))
        self.assertTrue(tb.wait(lambda: botproc.POOL.free() == self.SLOTS, 5))
        s2, inst2 = self.run_bot(tb.TRADER, {"lot": 0.01}, name="b2.py")
        self.assertTrue(tb.wait(lambda: inst2.status == "running"), self.logs(s2))
        self.assertEqual([a[0] for a in self.android.launched], [0, 0])

    def test_two_bots_get_two_workers(self):
        s, insts = self.run_two(2)
        self.assertTrue(tb.wait(lambda: all(i.status == "running" for i in insts)), self.logs(s))
        self.assertEqual(sorted(a[0] for a in self.android.launched), [0, 1])
        self.assertTrue(tb.wait(lambda: len(s.account.positions) >= 1))

    def test_when_all_slots_are_busy_the_next_bot_falls_back_to_a_thread_with_a_clear_warning(self):
        botproc.POOL = botproc.SlotPool(1)
        s, insts = self.run_two(2)
        self.assertTrue(tb.wait(lambda: all(i.status == "running" for i in insts), 30), self.logs(s))
        self.assertEqual(len(self.android.launched), 1)                        # chỉ một worker được dựng
        self.assertIn("Cô lập tiến trình không dùng được", self.logs(s))
        self.assertIn("hết", self.logs(s))

    def test_worker_that_never_connects_times_out_cleans_up_and_falls_back(self):
        botproc.ACCEPT_S = 1.0
        botproc.LAUNCHER = lambda slot, arg: (True, "")                         # dịch vụ «khởi động» nhưng không bao giờ nối vào
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: s.account is not None and len(s.account.positions) == 1, 30), self.logs(s))
        self.assertIn("không nối vào", self.logs(s))
        self.assertIn(0, self.android.killed)                                  # dừng dịch vụ kẹt để lần sau dùng lại được
        self.assertEqual(botproc.POOL.free(), self.SLOTS)

    def test_rogue_connection_with_a_wrong_token_is_dropped_and_does_not_block_the_real_worker(self):
        rogue = {}

        def launcher(slot, argument):
            arg = json.loads(argument)
            c = socket.create_connection(("127.0.0.1", arg["port"]), timeout=3)          # ứng dụng khác dò cổng loopback
            c.sendall((json.dumps({"t": "hello", "token": "x" * 32}) + "\n").encode())
            rogue["c"] = c
            return self.android.launch(slot, argument)
        botproc.LAUNCHER = launcher
        s, inst = self.run_bot(tb.TRADER, {"lot": 0.01})
        self.assertTrue(tb.wait(lambda: inst.status == "running"), self.logs(s))
        rogue["c"].settimeout(3)
        self.assertEqual(rogue["c"].recv(10), b"")                              # bị đóng, không nhận được dữ liệu của vỏ
        rogue["c"].close()

    def test_dead_worker_is_reported_as_process_error_and_the_app_survives(self):
        body = tb.HEAD + "class X(BaseBot):\n    def on_tick(self, t):\n        __import__('os')._exit(3)\n"
        s, inst = self.run_bot(body, dev_mode=True)
        self.assertTrue(tb.wait(lambda: inst.status == "error", 20), self.logs(s))
        self.assertIn("thoát đột ngột", self.logs(s))
        self.assertTrue(s.is_alive())
        self.assertTrue(tb.wait(lambda: botproc.POOL.free() == self.SLOTS, 5))

    def test_wrong_hello_does_not_crash_the_worker_entry(self):
        """service_botworker.main nối vào cổng của vỏ, trình mã rồi chờ yêu cầu; vỏ đóng kết nối thì worker tự kết thúc (p4a sẽ stopSelf)."""
        srv = socket.socket()
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        arg = json.dumps({"port": srv.getsockname()[1], "token": "t" * 32, "slot": 3, "data_dir": tempfile.mkdtemp()})
        self.android.launch(3, arg)
        srv.settimeout(15)
        conn, _ = srv.accept()
        hello = json.loads(conn.makefile("r").readline())
        self.assertEqual((hello["t"], hello["token"], hello["slot"]), ("hello", "t" * 32, 3))
        conn.close()
        p = self.android.procs[3]
        self.assertTrue(tb.wait(lambda: p.poll() is not None, 10))              # vỏ biến mất -> worker thoát sạch
        self.assertEqual(p.returncode, 0)
        srv.close()


class TestSlotPool(unittest.TestCase):
    def test_acquire_release_exhaust(self):
        p = botproc.SlotPool(2)
        a, b = p.acquire(), p.acquire()
        self.assertEqual((a, b), (0, 1))
        self.assertIsNone(p.acquire())
        p.release(a)
        self.assertEqual(p.acquire(), 0)

    def test_released_slot_cools_down_before_reuse(self):
        """Dừng dịch vụ p4a là bất đồng bộ (onDestroy -> killProcess chạy sau): khởi động lại NGAY có thể bị lệnh dừng cũ giết nhầm."""
        p = botproc.SlotPool(1)
        k = p.acquire()
        p.release(k, cooldown=0.4)
        t0 = time.monotonic()
        self.assertEqual(p.acquire(), 0)
        self.assertGreaterEqual(time.monotonic() - t0, 0.35)

    def test_all_busy_does_not_wait(self):
        p = botproc.SlotPool(1)
        p.acquire()
        t0 = time.monotonic()
        self.assertIsNone(p.acquire())
        self.assertLess(time.monotonic() - t0, 0.2)

    def test_free_counts_cooling_slots_but_not_busy_ones(self):
        p = botproc.SlotPool(3)
        a = p.acquire()
        p.acquire()
        p.release(a, cooldown=5.0)
        self.assertEqual(p.free(), 2)


class TestAvailability(unittest.TestCase):
    def setUp(self):
        self._saved = (botproc.TRANSPORT, botproc.LAUNCHER, botproc.POOL)
        self._env = os.environ.get("ANDROID_ARGUMENT")
        botproc.TRANSPORT, botproc.LAUNCHER = None, None
        os.environ["ANDROID_ARGUMENT"] = "x"

    def tearDown(self):
        botproc.TRANSPORT, botproc.LAUNCHER, botproc.POOL = self._saved
        if self._env is None:
            os.environ.pop("ANDROID_ARGUMENT", None)
        else:
            os.environ["ANDROID_ARGUMENT"] = self._env

    def test_android_without_jnius_is_unavailable_with_a_clear_reason(self):
        ok, why = botproc.available()
        self.assertFalse(ok)
        self.assertIn("Android", why)

    def test_apk_built_from_old_spec_without_worker_services_says_so(self):
        orig = android_native.worker_services_present
        android_native.worker_services_present = lambda slots=None: False
        try:
            ok, why = botproc.available()
        finally:
            android_native.worker_services_present = orig
        self.assertFalse(ok)
        self.assertIn("không có dịch vụ worker", why)

    def test_apk_with_worker_services_is_available(self):
        orig = android_native.worker_services_present
        android_native.worker_services_present = lambda slots=None: True
        try:
            self.assertEqual(botproc.available(), (True, ""))
        finally:
            android_native.worker_services_present = orig

    def test_no_free_slot_is_unavailable(self):
        botproc.LAUNCHER = lambda *a: (True, "")
        botproc.POOL = botproc.SlotPool(1)
        botproc.POOL.acquire()
        ok, why = botproc.available()
        self.assertFalse(ok)
        self.assertIn("hết", why)

    def test_desktop_still_uses_pipes(self):
        os.environ.pop("ANDROID_ARGUMENT", None)
        if "ANDROID_ROOT" in os.environ and "ANDROID_DATA" in os.environ:
            self.skipTest("đang chạy trên Android thật")
        self.assertFalse(botproc.use_socket())
        self.assertTrue(botproc.available()[0])


# ================================================================== pyjnius (giả) theo tài liệu p4a
class FakeCls:
    def __init__(self, log, name, fail_5arg=False):
        self.log, self.name, self.fail_5arg = log, name, fail_5arg

    def start(self, *a):
        self.log.append(("start", self.name) + a)

    def stop(self, *a):
        self.log.append(("stop", self.name) + a)


class TestAndroidNativeServices(unittest.TestCase):
    def setUp(self):
        self.log = []
        self.svc = types.SimpleNamespace(mService="SERVICE-CTX", getPackageName=lambda: "org.pyea.runner")

        def autoclass(name):
            if name == "org.kivy.android.PythonService":
                return types.SimpleNamespace(mService=self.svc.mService)
            if name == "org.kivy.android.PythonActivity":
                return types.SimpleNamespace(mActivity=types.SimpleNamespace(getPackageName=lambda: "org.pyea.runner"))
            if name.startswith("org.pyea.runner.Service"):
                if name.split("Service")[-1] in self.missing:
                    raise RuntimeError("ClassNotFound " + name)
                return FakeCls(self.log, name)
            raise RuntimeError(name)
        self.missing = set()
        self._jn = sys.modules.get("jnius")
        sys.modules["jnius"] = types.SimpleNamespace(autoclass=autoclass)
        self._ctx = android_native.context
        android_native.context = lambda: types.SimpleNamespace(getPackageName=lambda: "org.pyea.runner", tag="CTX")
        self._is = android_native.IS_ANDROID
        android_native.IS_ANDROID = True

    def tearDown(self):
        android_native.context = self._ctx
        android_native.IS_ANDROID = self._is
        if self._jn is None:
            sys.modules.pop("jnius", None)
        else:
            sys.modules["jnius"] = self._jn

    def test_worker_start_is_a_background_service_started_with_context_and_argument(self):
        ok, err = android_native.start_service('{"port": 1}', name=android_native.worker_name(2), foreground=False)
        self.assertTrue(ok, err)
        e = self.log[-1]
        self.assertEqual((e[0], e[1]), ("start", "org.pyea.runner.ServiceBotworker2"))
        self.assertEqual(e[3], '{"port": 1}')                                    # (ctx, argument) như tài liệu p4a: service.start(mActivity, argument)
        self.assertEqual(len(e), 4)

    def test_main_service_start_keeps_the_foreground_form(self):
        android_native.start_service("arg", "T", "X")
        e = self.log[-1]
        self.assertEqual((e[1], e[3:]), ("org.pyea.runner.ServiceBotservice", ("icon", "T", "X", "arg")))

    def test_stop_uses_the_named_service(self):
        self.assertTrue(android_native.stop_service("Botworker1"))
        self.assertEqual(self.log[-1][:2], ("stop", "org.pyea.runner.ServiceBotworker1"))
        self.assertTrue(android_native.stop_service())
        self.assertEqual(self.log[-1][1], "org.pyea.runner.ServiceBotservice")

    def test_worker_services_present_requires_all_slots(self):
        self.assertTrue(android_native.worker_services_present())
        self.missing = {"Botworker3"}
        self.assertFalse(android_native.worker_services_present())

    def test_start_failure_is_reported_not_raised(self):
        self.missing = {"Botworker0"}
        ok, err = android_native.start_service("a", name="Botworker0", foreground=False)
        self.assertFalse(ok)
        self.assertIn("ClassNotFound", err)

    def test_buildozer_spec_declares_every_worker_slot_and_the_entry_script_exists(self):
        spec = open(os.path.join(ROOT, "buildozer.spec"), encoding="utf-8").read()
        line = [x for x in spec.splitlines() if x.startswith("services =")][0]
        names = [p.split(":")[0].strip() for p in line.split("=", 1)[1].split(",")]
        for k in range(botproc.WORKER_SLOTS):
            self.assertIn(android_native.worker_name(k), names)
        self.assertIn("Botservice:service_main.py:foreground:sticky", line)
        for p in line.split("=", 1)[1].split(","):
            if p.split(":")[0].startswith("Botworker"):
                self.assertEqual(p.split(":")[1:], ["service_botworker.py"])      # nền, KHÔNG sticky (không tự sống lại ngoài tầm vỏ)
        self.assertTrue(os.path.exists(os.path.join(ROOT, "service_botworker.py")))


if __name__ == "__main__":
    unittest.main()
