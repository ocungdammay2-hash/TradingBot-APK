"""Kênh giám sát -> app: server THẬT + script run_mt5_termux.sh THẬT với lệnh MT5/MetaEditor giả (không có MT5/Wine ở đây)."""
import base64
import os
import socket
import subprocess
import tempfile
import time
import unittest

from pyea import mt5ea

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(os.path.dirname(HERE), "tools", "mt5_phone", "run_mt5_termux.sh")
TOKEN = "tok-12345678"


def server():
    s = mt5ea.Mt5EaServer(0, TOKEN)
    s.provision = {"PyEABridge.mq5": "// ea ünï\n", "bridge.set": "InpToken=%s\n" % TOKEN, "startup.ini": "[Common]\n"}
    s.start()
    return s


def env_for(srv, d, **extra):
    extra = dict({"LOG_POLL": "0"}, **extra)
    e = dict(os.environ, NO_XVFB="1", STATUS_FILE=os.path.join(d, "st"), LOG_FILE=os.path.join(d, "log"), NOTIFY_CMD="/bin/true", BACKOFF_START="0.05", BACKOFF_MAX="0.1",
             PYEA_PORT=str(srv.port), PYEA_TOKEN=TOKEN, MT5_DIR=d, **extra)
    return e


def wait(cond, t=8.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.05)
    return False


def kinds(srv):
    return [a["kind"] for a in list(srv.alerts)]


class TestServerSup(unittest.TestCase):
    def setUp(self):
        self.srv = server()

    def tearDown(self):
        self.srv.close()

    def sup(self, *lines, token=TOKEN):
        c = socket.create_connection(("127.0.0.1", self.srv.port), timeout=3)
        c.sendall(("SUPHELLO|v=1|token=%s\n" % token + "".join(l + "\n" for l in lines)).encode())
        return c

    def test_wrong_token_denied(self):
        c = self.sup("SLOG|lvl=I|m=x", token="bad-token-1")
        self.assertIn(b"DENY", c.recv(200))
        self.assertTrue(wait(lambda: "token" in kinds(self.srv)))
        self.assertFalse(any("x" == t for *_, t in self.srv.diag))

    def test_exit_codes_classified(self):
        self.assertIn("Android", mt5ea.classify_exit(137)[0])
        self.assertIn("SIGSEGV", mt5ea.classify_exit(139)[0])
        self.assertIn("77", mt5ea.classify_exit(77)[0])
        self.assertTrue(mt5ea.classify_exit("x")[1])

    def test_mt5_exit_event_makes_alert_with_cause_auto_need(self):
        self.sup("SEVT|kind=mt5_exit|code=137|up=42|restarts=3|will_restart=1|wait=5")
        self.assertTrue(wait(lambda: "mt5_exit" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "mt5_exit"][0]
        self.assertIn("137", a["title"]); self.assertIn("Android", a["text"]); self.assertIn("• Tự khắc phục:", a["text"]); self.assertTrue(a["auto"])
        self.assertTrue(self.srv.is_supervised())                 # tự phát hiện, không cần cài đặt

    def test_compile_fail_carries_log_excerpt_to_app(self):
        self.sup("SEVT|kind=compile|ok=0|errors=2|warnings=0|excerpt=PyEABridge.mq5 12:3 error 256: undeclared identifier")
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "compile_fail"][0]
        self.assertIn("undeclared identifier", a["text"]); self.assertTrue(a["critical"])

    def test_logline_rules_login_failed_and_socket_blocked_rate_limited(self):
        self.sup("LOGLINE|src=journal|text=2026.11.10 12:00:00 Network '123': authorization on Server failed (invalid account)",
                 "LOGLINE|src=journal|text=again authorization on Server failed (invalid account)",
                 "LOGLINE|src=experts|text=PyEABridge: SocketConnect failed, error 4014 (127.0.0.1:18765)")
        self.assertTrue(wait(lambda: "socket_blocked" in kinds(self.srv)))
        self.assertEqual(kinds(self.srv).count("login_failed"), 1)  # lặp lại trong 10 phút không báo lại
        self.assertEqual(len(self.srv.diag), 3)                   # nhưng cả 3 dòng đều vào nhật ký

    def test_get_provision_and_unknown(self):
        c = self.sup("GET|name=PyEABridge.mq5", "GET|name=evil.exe")
        c.settimeout(3)
        buf = b""
        while buf.count(b"\n") < 3:
            buf += c.recv(4096)
        lines = buf.decode().split("\n")
        self.assertTrue(lines[0].startswith("SUPWELCOME"))
        self.assertEqual(base64.b64decode(mt5ea.dec(lines[1])[1]["b64"]).decode(), "// ea ünï\n")
        self.assertIn("err", mt5ea.dec(lines[2])[1])

    def test_sup_does_not_replace_ea_connection(self):
        from tests.fake_ea import FakeEA
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        self.sup("SLOG|lvl=I|m=hi")
        self.assertTrue(wait(lambda: any(t == "hi" for *_, t in self.srv.diag)))
        self.assertTrue(self.srv.alive())
        ea.close()

    def test_diagnostics_masks_token_everywhere(self):
        self.srv.diag_add("ea", "E", "boom token=" + TOKEN)
        self.srv.info = {"login": "1", "token": TOKEN}
        txt = self.srv.diagnostics_text()
        self.assertNotIn(TOKEN, txt); self.assertIn("boom", txt); self.assertIn("login=1", txt)

    def test_ea_log_message_enters_diag_and_error_alerts(self):
        from tests.fake_ea import FakeEA
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        ea.send("LOG", lvl="E", m="OrderSend failed 10027")
        self.assertTrue(wait(lambda: "ea_error" in kinds(self.srv)))
        ea.close()

    def test_lost_while_mt5_running_is_distinguished(self):
        from tests.fake_ea import FakeEA
        self.sup("SEVT|kind=started|restarts=0")
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        self.srv.alerts.clear()
        ea.kill_link()
        self.assertTrue(wait(lambda: "lost_mt5_up" in kinds(self.srv)))
        ea.close()


class TestScriptToApp(unittest.TestCase):
    def setUp(self):
        self.srv = server()
        self.d = tempfile.mkdtemp()

    def tearDown(self):
        self.srv.close()

    def run_script(self, *args, **extra):
        return subprocess.run(["bash", SCRIPT, *args], env=env_for(self.srv, self.d, **extra), capture_output=True, text=True, timeout=60)

    def test_crash_loop_reports_each_exit_and_gave_up(self):
        p = self.run_script(MT5_CMD="sh -c 'exit 137'", MAX_FAST_CRASHES="3", MIN_UP="60")
        self.assertEqual(p.returncode, 2)
        self.assertTrue(wait(lambda: "gave_up" in kinds(self.srv)))
        self.assertGreaterEqual(kinds(self.srv).count("mt5_exit"), 2)
        a = [x for x in self.srv.alerts if x["kind"] == "gave_up"][0]
        self.assertIn("137", a["text"]); self.assertFalse(a["auto"])
        self.assertTrue(any("đuôi log" in t for *_, t in self.srv.diag))

    def test_provision_writes_files_from_app_exactly(self):
        p = self.run_script("provision")
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertEqual(open(os.path.join(self.d, "MQL5/Experts/PyEABridge.mq5"), encoding="utf-8").read(), "// ea ünï\n")
        self.assertIn(TOKEN, open(os.path.join(self.d, "MQL5/Profiles/Tester/bridge.set")).read())
        self.assertTrue(os.path.exists(os.path.join(self.d, "startup.ini")))

    def test_provision_wrong_token_fails_clearly(self):
        p = subprocess.run(["bash", SCRIPT, "provision"], env=dict(env_for(self.srv, self.d), PYEA_TOKEN="wrong-token-9"), capture_output=True, text=True, timeout=60)
        self.assertNotEqual(p.returncode, 0)
        self.assertTrue(wait(lambda: "token" in kinds(self.srv)))

    def _fake_metaeditor(self, body):
        f = os.path.join(self.d, "me.sh")
        with open(f, "w") as fh:
            fh.write("#!/bin/bash\n" + body)
        os.chmod(f, 0o755)
        return f

    def test_compile_ok_and_fail_reported_from_log_without_opening_metaeditor(self):
        os.makedirs(os.path.join(self.d, "MQL5/Experts"))
        open(os.path.join(self.d, "MQL5/Experts/PyEABridge.mq5"), "w").write("x")
        ok = self._fake_metaeditor('src="${1#/compile:}"; src="${src#Z:}"; src="${src//\\\\//}"; : > "${src%.mq5}.ex5"; '
                                   'echo "Result: 0 errors, 1 warnings" | iconv -t UTF-16 > "${src%.mq5}.log"\n')
        p = self.run_script("compile", METAEDITOR_CMD=ok)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertTrue(wait(lambda: "compile_ok" in kinds(self.srv)))
        bad = self._fake_metaeditor('src="${1#/compile:}"; src="${src#Z:}"; src="${src//\\\\//}"; '
                                    'printf "PyEABridge.mq5 (12,3) : error 256: undeclared identifier\\nResult: 1 errors, 0 warnings\\n" | iconv -t UTF-16LE > "${src%.mq5}.log"\n')
        os.remove(os.path.join(self.d, "MQL5/Experts/PyEABridge.ex5"))
        p = self.run_script("compile", METAEDITOR_CMD=bad)
        self.assertEqual(p.returncode, 1)
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "compile_fail"][0]
        self.assertIn("undeclared identifier", a["text"])

    def test_compile_without_source_reports_not_crash(self):
        p = self.run_script("compile", METAEDITOR_CMD="/bin/true")
        self.assertEqual(p.returncode, 1)
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))

    def test_log_tailer_forwards_utf16_lines_and_alerts(self):
        os.makedirs(os.path.join(self.d, "logs")); os.makedirs(os.path.join(self.d, "MQL5/Logs"))
        lf = os.path.join(self.d, "logs/20261110.log")
        txt = "boring line\nNetwork '123': authorization on Srv failed (invalid account)\n"
        with open(lf, "wb") as f:
            f.write(b"\xff\xfe" + txt.encode("utf-16le"))
        ef = os.path.join(self.d, "MQL5/Logs/20261110.log")
        with open(ef, "wb") as f:
            f.write(b"\xff\xfe" + "PyEABridge: SocketConnect failed, error 4014\n".encode("utf-16le"))
        p = subprocess.Popen(["bash", SCRIPT], env=env_for(self.srv, self.d, MT5_CMD="sleep 20", LOG_POLL="0.2"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self.assertTrue(wait(lambda: "login_failed" in kinds(self.srv) and "socket_blocked" in kinds(self.srv), 10))
            self.assertFalse(any("boring" in t for *_, t in self.srv.diag))      # chỉ đẩy dòng đáng chú ý
            with open(lf, "ab") as f:                                              # dòng mới nối thêm cũng được đọc, không đọc lại dòng cũ
                f.write("PyEA late error\n".encode("utf-16le"))
            self.assertTrue(wait(lambda: any("late error" in t for *_, t in self.srv.diag), 10))
            self.assertEqual(sum("authorization" in t for *_, t in self.srv.diag), 1)
        finally:
            p.terminate(); p.wait(10)

    def test_no_token_means_script_still_works_silently(self):
        p = subprocess.run(["bash", SCRIPT], env=dict(env_for(self.srv, self.d, MT5_CMD="sh -c 'exit 3'", MAX_FAST_CRASHES="2"), PYEA_TOKEN=""), capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 2)
        self.assertEqual(kinds(self.srv), [])


if __name__ == "__main__":
    unittest.main()
