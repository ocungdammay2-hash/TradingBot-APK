"""Phần app của MT5 NHÚNG: chuẩn bị (cài đặt lean, mật khẩu chỉ RAM, bật dịch vụ), đọc tiến trình/CPU-RAM, các câu trạng thái, file .set chế độ nhẹ, EA có chế độ nhẹ.
Dịch vụ Emu/proot thật chạy ở tests/test_embedded.py (proot giả); ở đây dịch vụ được thay bằng hàm giả."""
import base64
import json
import os
import socket
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import embedded as em                  # noqa: E402
from pyea import mt5ea, mt5emu                   # noqa: E402
from test_mt5emu import free_port, get_file, sup_exchange      # noqa: E402


def served(port, tok, name):
    d = get_file(port, tok, name)
    return base64.b64decode(d["b64"]).decode("utf-8")


class TestPrepareEmbedded(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.s = {"mt5ea_port": str(free_port())}
        self.calls = []
        self.upd, self.srv, self.res = mt5emu.prepare_embedded(self.s, "5550123", "Pw!1secret", "Demo-1", "https://b.example/mt5.exe", data_dir=self.tmp.name,
                                                               launcher=lambda a: self.calls.append(json.loads(a)) or (True, ""))
        self.port, self.tok = self.srv.port, self.upd["mt5ea_token"]
        self.addCleanup(lambda: (self.srv.close(), mt5ea._SERVERS.pop(self.port, None)))

    def test_settings_lean_and_service_started(self):
        self.assertEqual(self.upd["mt5ea_lean"], "yes")
        self.assertEqual(self.upd["mt5ea_supervised"], "yes")
        self.assertEqual(self.res, (True, ""))
        self.assertEqual(self.calls, [{"data_dir": self.tmp.name}])
        q = em.read_request(self.tmp.name)
        self.assertEqual((q["want"], q["port"], q["token"], q["profile"], q["mt5_url"]), ("run", self.port, self.tok, "lean", "https://b.example/mt5.exe"))

    def test_password_only_in_app_ram_never_in_files_or_args(self):
        for root, _, files in os.walk(self.tmp.name):
            for f in files:
                self.assertNotIn("Pw!1secret", open(os.path.join(root, f), errors="replace").read(), f)
        self.assertNotIn("Pw!1secret", json.dumps(self.calls))
        ini = served(self.port, self.tok, "startup.ini")                 # script trong Ubuntu lấy qua cổng cục bộ
        self.assertIn("Password=Pw!1secret", ini)
        self.srv.set_first_login_password(None)
        self.assertNotIn("Password", served(self.port, self.tok, "startup.ini"))

    def test_bridge_set_is_lean(self):
        d = served(self.port, self.tok, "bridge.set")
        self.assertIn("InpLean=true", d)
        self.assertIn("InpTimerMs=%d" % mt5ea.LEAN_TIMER_MS, d)

    def test_bad_input_refused_before_anything_starts(self):
        with self.assertRaises(ValueError):
            mt5emu.prepare_embedded({}, "abc", "pw", "S", data_dir=self.tmp.name, launcher=lambda a: self.fail("không được bật dịch vụ"))

    def test_launch_failure_is_returned_not_raised(self):
        s = {"mt5ea_port": str(free_port())}
        upd, srv, res = mt5emu.prepare_embedded(s, "5550123", "pw", "S", data_dir=self.tmp.name, launcher=lambda a: (False, "ClassNotFound: ServiceEmu"))
        self.addCleanup(lambda: (srv.close(), mt5ea._SERVERS.pop(srv.port, None)))
        self.assertEqual(res, (False, "ClassNotFound: ServiceEmu"))


class TestSetFile(unittest.TestCase):
    def test_default_not_lean(self):
        d = mt5ea.make_set_file({"mt5ea_port": "19999", "mt5ea_token": "tok-12345678"})
        self.assertIn("InpLean=false", d)
        self.assertIn("InpTimerMs=100", d)

    def test_setting_registered(self):
        from pyea import settings
        self.assertEqual(settings.default_settings()["mt5ea_lean"], "no")
        self.assertIn("mt5ea_lean", settings.API_KEYS["mt5ea"])


class TestProgressEmbedded(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.d = self.tmp.name
        self.srv = mt5ea.Mt5EaServer(0, "tok_progress_123")
        self.srv.start()
        self.addCleanup(self.srv.close)

    def state(self, **kv):
        lo = em.Layout(self.d)
        os.makedirs(lo.root, exist_ok=True)
        kv.setdefault("t", time.time())
        open(lo.state, "w").write(json.dumps(kv))

    def ev(self, stage, state, detail=""):
        sup_exchange(self.srv.port, "tok_progress_123", "SEVT|kind=install|stage=%s|state=%s|detail=%s" % (stage, state, detail))

    def test_rows_are_embedded_stages_in_order(self):
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual([r[0] for r in p["rows"]], [i for i, _ in mt5ea.EMBED_STAGES])
        self.assertNotIn("termux_pkgs", [r[0] for r in p["rows"]])               # không còn bước Termux
        self.assertEqual(p["pct"], 0)

    def test_progress_from_server_events(self):
        for st in ("precheck", "proot", "rootfs"):
            self.ev(st, "ok")
        self.ev("apt", "start", "Cài thư viện")
        p = mt5emu.progress_embedded(self.srv, self.d)
        stt = {r[0]: r[2] for r in p["rows"]}
        self.assertEqual((stt["precheck"], stt["proot"], stt["rootfs"], stt["apt"], stt["wine"]), ("ok", "ok", "ok", "run", "todo"))
        self.assertGreater(p["pct"], 0)
        self.assertIn("Đang cài", mt5emu.headline_embedded(p)[0])

    def test_failure_from_service_state_when_server_missed_it(self):
        self.state(phase="failed", failed_stage="proot", error="proot không chạy được")
        p = mt5emu.progress_embedded(None, self.d)                                # app chưa có máy chủ: vẫn hiện lỗi thật từ state.json
        text, tone = mt5emu.headline_embedded(p)
        self.assertEqual(tone, "fail")
        self.assertIn("Tải proot", text)
        self.assertIn("proot không chạy được", mt5emu.render(p))

    def test_stopped_and_dead_service_messages(self):
        self.state(phase="stopped")
        self.assertIn("DỪNG", mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))[0])
        self.state(phase="installing", t=time.time() - 600)                       # đang «cài» nhưng 10 phút không có nhịp
        self.assertIn("CHƯA thấy dịch vụ nền", mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))[0])

    def test_resources_shown_from_server_and_fallback_to_state(self):
        sup_exchange(self.srv.port, "tok_progress_123", "SEVT|kind=res|cpu=37.5|rss=412|procs=9|top=terminal64.exe:30%25/300MB")
        self.state(phase="running")
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual((p["res"]["cpu"], p["res"]["rss_mb"], p["res"]["procs"]), (37.5, 412, 9))
        self.assertIn("RAM 412 MB", mt5emu.headline_embedded(p)[0])
        self.state(phase="running", res={"cpu": 5.0, "rss_mb": 200, "procs": 3, "top": "x"})
        p2 = mt5emu.progress_embedded(None, self.d)
        self.assertEqual(p2["res"]["rss_mb"], 200)

    def test_res_events_do_not_flood_diagnostics(self):
        n0 = len(self.srv.diag)
        for _ in range(30):
            self.srv._sup_event({"kind": "res", "cpu": "1", "rss": "2", "procs": "3", "top": "a"})
        self.assertLessEqual(len(self.srv.diag) - n0, 1)
        self.assertIn("tài nguyên giả lập nhúng: CPU", self.srv.diagnostics_text())

    def test_emu_exit_and_profile_events_make_alerts(self):
        self.srv._sup_event({"kind": "emu_exit", "code": "1", "up": "5", "profile": "lean"})
        self.srv._sup_event({"kind": "profile", "to": "stable", "why": "MT5 chết nhanh"})
        kinds = [a["kind"] for a in self.srv.alerts]
        self.assertIn("emu_exit", kinds)
        self.assertIn("profile", kinds)

    def test_connected_headline_has_cost_and_hides_steps(self):
        p = mt5emu.progress_embedded(self.srv, self.d)
        p.update(connected=True, login=5550123, server="Demo-1", res={"cpu": 12.0, "rss_mb": 300, "procs": 5})
        text, tone = mt5emu.headline_embedded(p)
        self.assertEqual(tone, "ok")
        self.assertIn("5550123", text)
        self.assertIn("CPU 12%", text)


class TestSourcesConsistent(unittest.TestCase):
    def test_ea_has_lean_mode(self):
        ea = mt5ea.ea_source()
        for w in ("input bool   InpLean", "void LeanChart()", "void LeanWatch()", "CHART_SHOW, false", "SymbolSelect(s, false)", "TERMINAL_CONNECTED"):
            self.assertIn(w, ea)
        self.assertEqual(ea.count("{"), ea.count("}"))
        self.assertEqual(ea.count("("), ea.count(")"))

    def test_embedded_stage_ids_match_installer_script(self):
        inst = mt5ea.script_source("install_mt5_termux.sh")
        for sid, _ in mt5ea.EMBED_STAGES:
            if sid in ("precheck", "proot", "login"):
                continue                                              # do Python báo
            self.assertIn("stage %s " % sid, inst, sid)

    def test_service_declared_and_entry_exists(self):
        spec = open(os.path.join(HERE, "..", "buildozer.spec"), encoding="utf-8").read()
        self.assertIn("Emu:service_emu.py:foreground:sticky", spec)
        self.assertTrue(os.path.exists(os.path.join(HERE, "..", "service_emu.py")))
        from pyea import android_native
        self.assertEqual(android_native.EMU_SERVICE_NAME, "Emu")
        self.assertNotEqual(android_native.NOTIF_EMU, android_native.NOTIF_RUN)


if __name__ == "__main__":
    unittest.main()
