"""Báo cáo HTML kiểu MT5 (pyea/report.py): đường vốn, sụt vốn, phân tích theo mã/phiên/giờ, thoát HTML, trang rỗng hợp lệ."""
import os
import re
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import report as R                                  # noqa: E402
from pyea.sdk import Trade                                    # noqa: E402

T0 = 1700000000.0 - (1700000000 % 86400)                       # 00:00 UTC một ngày thứ Ba


def tr(i, profit, hour=1, sym="BTCUSD", side="buy", owner="botA", reason="TP"):
    o = T0 + hour * 3600 + i * 86400
    return Trade(i, sym, side, 1.0, 100.0, 101.0, o, o + 600, profit, reason, "", owner)


class TestCurve(unittest.TestCase):
    def test_curve_and_drawdown(self):
        trades = [tr(1, 100), tr(2, -50), tr(3, -50), tr(4, 200)]
        c = R.equity_curve(trades, 1000.0)
        self.assertEqual([round(x[1]) for x in c], [1000, 1100, 1050, 1000, 1200])
        dd = R.drawdown_series(c)
        self.assertAlmostEqual(max(v for _t, v in dd), (1100 - 1000) / 1100 * 100)
        self.assertEqual(dd[-1][1], 0.0)

    def test_sessions(self):
        self.assertTrue(R.session_of(T0 + 3 * 3600).startswith("Á"))
        self.assertTrue(R.session_of(T0 + 9 * 3600).startswith("Âu ("))
        self.assertTrue(R.session_of(T0 + 14 * 3600).startswith("Âu-Mỹ"))
        self.assertTrue(R.session_of(T0 + 18 * 3600).startswith("Mỹ"))
        self.assertTrue(R.session_of(T0 + 23 * 3600).startswith("Ngoài"))

    def test_breakdown_numbers(self):
        trades = [tr(1, 100, sym="A"), tr(2, -40, sym="A"), tr(3, 10, sym="B")]
        rows = {r["key"]: r for r in R.breakdown(trades, lambda t: t.symbol)}
        self.assertEqual((rows["A"]["n"], rows["A"]["net"], rows["A"]["win"]), (2, 60, 50.0))
        self.assertAlmostEqual(rows["A"]["pf"], 100 / 40)
        self.assertEqual(rows["B"]["pf"], float("inf"))


class TestHtml(unittest.TestCase):
    def test_full_report_contains_core_sections_and_values(self):
        trades = [tr(1, 100, 2), tr(2, -50, 9, "ETHUSD", "sell", "botB", "SL"), tr(3, 200, 15)]
        h = R.build_html(trades, 1000.0, now=T0)
        for s in ("Chỉ số", "Tăng trưởng số dư", "Sụt vốn", "Theo mã", "Theo phiên giao dịch", "Theo giờ mở", "Danh sách lệnh", "BTCUSD", "ETHUSD"):
            self.assertIn(s, h)
        self.assertIn("<svg", h)
        self.assertIn("1250.00", h)                                  # số dư cuối = 1000 + 250
        self.assertIsNone(re.search(r"<script", h, re.I))             # không JavaScript
        self.assertTrue(h.startswith("<!doctype html>") and h.rstrip().endswith("</html>"))

    def test_html_is_escaped(self):
        t = tr(1, 5, sym="<script>alert(1)</script>", owner="a&b")
        h = R.build_html([t], 100.0, title="<b>x</b>", notes=["<img src=x onerror=1>"])
        self.assertNotIn("<script>alert", h)
        self.assertNotIn("<img src=x", h)
        self.assertIn("&lt;script&gt;", h)
        self.assertIn("a&amp;b", h)

    def test_empty_is_valid_page(self):
        h = R.build_html([], 1000.0)
        self.assertIn("Chưa có lệnh", h)
        self.assertTrue(h.rstrip().endswith("</html>"))

    def test_storage_saves_file(self):
        from pyea.storage import Store
        st = Store(tempfile.mkdtemp())
        path = st.save_report_html(R.build_html([tr(1, 5)], 100.0))
        self.assertTrue(os.path.isfile(path) and path.endswith(".html"))
        self.assertIn("Chỉ số", open(path, encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()
