import os
import subprocess
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(os.path.dirname(HERE), "tools", "mt5_phone")


def run(cmd, extra, timeout=60):
    d = tempfile.mkdtemp()
    env = dict(os.environ, NO_XVFB="1", STATUS_FILE=os.path.join(d, "st"), LOG_FILE=os.path.join(d, "log"), NOTIFY_CMD=os.path.join(d, "n.sh"), BACKOFF_START="0.05",
               BACKOFF_MAX="0.2", MT5_CMD=cmd, **extra)
    with open(os.path.join(d, "n.sh"), "w") as f:
        f.write('#!/bin/sh\necho "$1|$2" >> "%s"\n' % os.path.join(d, "notes"))
    os.chmod(os.path.join(d, "n.sh"), 0o755)
    p = subprocess.run(["bash", os.path.join(TOOLS, "run_mt5_termux.sh")], env=env, capture_output=True, timeout=timeout)
    rd = lambda n: open(os.path.join(d, n)).read() if os.path.exists(os.path.join(d, n)) else ""
    return p.returncode, rd("st"), rd("log"), rd("notes")


class TestSupervisor(unittest.TestCase):
    def test_crash_loop_gives_up_and_notifies(self):
        rc, st, log, notes = run("sh -c 'exit 3'", {"MAX_FAST_CRASHES": "3", "MIN_UP": "60"})
        self.assertEqual(rc, 2)
        self.assertIn("state=gave_up", st)
        self.assertIn("BỎ CUỘC", notes)
        self.assertEqual(log.count("MT5 dừng"), 2)                      # 2 lần chờ khởi động lại rồi lần thứ 3 bỏ cuộc

    def test_stable_run_resets_counter_and_notifies_each_stop(self):
        # mỗi lần sống >= MIN_UP (1s) rồi chết: không bao giờ tính là «chết nhanh» -> không bỏ cuộc; ta dừng bằng timeout
        d = tempfile.mkdtemp()
        env = dict(os.environ, NO_XVFB="1", STATUS_FILE=os.path.join(d, "st"), LOG_FILE=os.path.join(d, "log"), NOTIFY_CMD=os.path.join(d, "n.sh"), BACKOFF_START="0.05",
                   MT5_CMD="sh -c 'sleep 1.2; exit 1'", MIN_UP="1", MAX_FAST_CRASHES="2")
        with open(os.path.join(d, "n.sh"), "w") as f:
            f.write('#!/bin/sh\necho "$1|$2" >> "%s"\n' % os.path.join(d, "notes"))
        os.chmod(os.path.join(d, "n.sh"), 0o755)
        p = subprocess.Popen(["bash", os.path.join(TOOLS, "run_mt5_termux.sh")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            time.sleep(4.5)
            self.assertIsNone(p.poll(), "không được bỏ cuộc khi mỗi lần đều chạy ổn định")
        finally:
            p.terminate()
            p.wait(10)
        notes = open(os.path.join(d, "notes")).read()
        self.assertGreaterEqual(notes.count("đã dừng"), 2)
        self.assertIn("state=stopped", open(os.path.join(d, "st")).read())     # SIGTERM -> dọn dẹp, ghi trạng thái

    def test_scripts_parse(self):
        for n in ("run_mt5_termux.sh", "setup_check.sh"):
            self.assertEqual(subprocess.run(["bash", "-n", os.path.join(TOOLS, n)]).returncode, 0, n)

    def test_startup_template_has_expert(self):
        self.assertIn("Expert=PyEABridge", open(os.path.join(TOOLS, "startup.ini"), encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()


class TestListDlls(unittest.TestCase):
    def test_counts_unique_lowercased_dlls_only_from_loaddll_lines(self):
        d = tempfile.mkdtemp()
        f = os.path.join(d, "l.log")
        with open(f, "w") as fh:
            fh.write('0024:trace:loaddll:build_module Loaded L"C:\\windows\\system32\\KERNEL32.dll" at 0000\n'
                     '0024:trace:loaddll:build_module Loaded L"C:\\windows\\system32\\ws2_32.dll" at 0000\n'
                     '0025:trace:loaddll:build_module Loaded L"C:\\windows\\system32\\kernel32.DLL" at 0000\n'
                     '0025:err:other: nothing.dll mentioned here\n')
        p = subprocess.run(["bash", os.path.join(TOOLS, "list_dlls.sh"), f], capture_output=True, text=True)
        self.assertEqual(p.stdout.split("\n")[:2], ["2 kernel32.dll", "1 ws2_32.dll"])
        self.assertNotIn("nothing.dll", p.stdout)
        self.assertEqual(subprocess.run(["bash", os.path.join(TOOLS, "list_dlls.sh")], capture_output=True).returncode, 64)
