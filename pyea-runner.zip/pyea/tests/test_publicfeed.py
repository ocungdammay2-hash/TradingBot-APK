import os, sys, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import publicfeed as P
from pyea.feeds import FeedError, make_feed


def yahoo_json(n=5, t0=1_700_000_000, step=60, holes=()):
    ts = [t0 + i * step for i in range(n)]
    f = lambda base: [None if i in holes else base + i for i in range(n)]
    return {"chart": {"result": [{"meta": {"regularMarketPrice": 2300.5, "symbol": "GC=F"}, "timestamp": ts,
                                  "indicators": {"quote": [{"open": f(10), "high": f(12), "low": f(9), "close": f(11), "volume": f(100)}]}}], "error": None}}


class T(unittest.TestCase):
    def test_route(self):
        r = P.route
        self.assertEqual(r("BTCUSDT"), ("binance", "BTCUSDT"))
        self.assertEqual(r("BTCUSD"), ("binance", "BTCUSDT"))
        self.assertEqual(r("ETH/USDT"), ("binance", "ETHUSDT"))
        self.assertEqual(r("EURUSD"), ("yahoo", "EURUSD=X"))
        self.assertEqual(r("XAUUSD"), ("yahoo", "GC=F"))
        self.assertEqual(r("US500"), ("yahoo", "^GSPC"))
        self.assertEqual(r("AAPL"), ("yahoo", "AAPL"))
        self.assertEqual(r("BTC-USD"), ("yahoo", "BTC-USD"))

    def test_parse_skips_none(self):
        cs, meta = P.parse_yahoo(yahoo_json(5, holes=(2,)))
        self.assertEqual(len(cs), 4)
        self.assertEqual(meta["regularMarketPrice"], 2300.5)
        with self.assertRaises(FeedError):
            P.parse_yahoo({"chart": {"result": None, "error": {"description": "No data"}}}, "X")

    def test_history_and_tick(self):
        calls = []
        orig = P.http_json
        def fake(url, params=None, **kw):
            calls.append((url, params))
            return yahoo_json(30)
        P.http_json = fake
        try:
            f = P.PublicFeed()
            h = f.history("XAUUSD", "1m", 10)
            self.assertEqual(len(h), 10)
            self.assertIn("GC=F", calls[0][0])
            self.assertEqual(calls[0][1]["interval"], "1m")
            h2 = f.history("XAUUSD", "4h", 3) if False else None
            t = f.tick("XAUUSD")
            self.assertEqual(t.bid, 2300.5)
            n = len(calls)
            f.tick("XAUUSD")
            self.assertEqual(len(calls), n)                       # cache 2 giây
        finally:
            P.http_json = orig

    def test_make_feed_and_no_live(self):
        self.assertIsInstance(make_feed("public", {}), P.PublicFeed)
        from pyea.settings import api_keys_for, EXCHANGE_WATCH
        self.assertEqual(api_keys_for("public"), {"twelvedata_key"})
        self.assertIn("public", EXCHANGE_WATCH)


if __name__ == "__main__":
    unittest.main()


class TestFallback(unittest.TestCase):
    def setUp(self):
        import pyea.feeds as F
        self.orig, self.orig_f = P.http_json, F.http_json
        self.calls = []

    def tearDown(self):
        import pyea.feeds as F
        P.http_json, F.http_json = self.orig, self.orig_f

    def fake(self, handlers):
        def f(url, params=None, **kw):
            self.calls.append(url)
            for key, fn in handlers.items():
                if key in url:
                    return fn(url, params)
            raise FeedError("chặn: " + url)
        P.http_json = f
        import pyea.feeds as F
        F.http_json = f                                           # BinanceFeed dùng http_json của feeds

    def test_crypto_falls_through_to_bybit_then_okx(self):
        bybit = lambda u, p: {"result": {"list": [{"bid1Price": "100.5", "ask1Price": "100.7"}]}}
        self.fake({"bybit": bybit})
        f = P.PublicFeed()
        t = f.tick("BTCUSDT")
        self.assertEqual((t.bid, t.ask), (100.5, 100.7))
        self.assertEqual(f.active["BTCUSDT"], "Bybit")
        self.assertIn("Binance", f._down)                         # Binance bị cho nghỉ
        n = len(self.calls)
        f._tick.clear()
        f.tick("BTCUSDT")
        self.assertFalse(any("binance" in u for u in self.calls[n:]))   # lần sau bỏ qua nguồn đang nghỉ

    def test_okx_and_coinbase_candle_parsing(self):
        okx = lambda u, p: {"data": [["1700000120000", "3", "4", "2", "3.5", "10"], ["1700000060000", "2", "3", "1", "2.5", "9"]]}
        cb = lambda u, p: [[1700000120, 2, 4, 3, 3.5, 7], [1700000060, 1, 3, 2, 2.5, 6]]
        self.fake({"okx": okx})
        f = P.PublicFeed()
        h = f.history("ETHUSDT", "1m", 5)
        self.assertEqual([c.time for c in h], [1700000060.0, 1700000120.0])     # đã đảo về cũ -> mới
        self.assertEqual(f.active["ETHUSDT"], "OKX")
        self.fake({"coinbase": cb})
        f = P.PublicFeed()
        h = f.history("ETHUSDT", "1m", 5)
        self.assertEqual(f.active["ETHUSDT"], "Coinbase")
        c = h[-1]
        self.assertEqual((c.open, c.high, c.low, c.close), (3.0, 4.0, 2.0, 3.5))

    def test_gold_falls_to_twelvedata_then_paxg(self):
        td = lambda u, p: {"price": "2311.25"} if "/price" in u else {"status": "error", "message": "limit"}
        self.fake({"twelvedata": td})
        f = P.PublicFeed(twelvedata_key="k")
        t = f.tick("XAUUSD")
        self.assertEqual(t.bid, 2311.25)
        self.assertEqual(f.active["XAUUSD"], "TwelveData")
        bin_ = lambda u, p: {"bidPrice": "2300", "askPrice": "2301"} if "bookTicker" in u else {"serverTime": 1}
        self.fake({"binance.com": bin_})
        f = P.PublicFeed()                                          # không khoá TD: Yahoo lỗi -> PAXG
        t = f.tick("XAUUSD")
        self.assertEqual(f.active["XAUUSD"], "Binance")
        self.assertEqual(t.symbol, "XAUUSD")

    def test_all_fail(self):
        self.fake({})
        with self.assertRaises(FeedError):
            P.PublicFeed().tick("BTCUSDT")

    def test_td_symbol_map(self):
        S = P.TwelveDataSrc.symbol
        self.assertEqual(S("EURUSD"), "EUR/USD")
        self.assertEqual(S("XAUUSD"), "XAU/USD")
        self.assertEqual(S("AAPL"), "AAPL")
        self.assertIsNone(S("US500"))


class TestClean(unittest.TestCase):
    def test_drops_garbage_candles(self):
        from pyea.sdk import Candle
        good = [Candle(float(i), 100, 101, 99, 100.5, 1) for i in range(10)]
        bad = [Candle(20.0, 100, 101, -193000.0, 100, 1), Candle(21.0, 0, 5, 0, 1, 1), Candle(22.0, 100, 9999, 99, 100, 1)]
        out = P.clean_candles(good + bad)
        self.assertEqual(len(out), 10)
        c = P.clean_candles([Candle(1.0, 100, 99, 101, 100.5, 1)])[0]            # râu sai chiều được sửa
        self.assertGreaterEqual(c.high, max(c.open, c.close))
        self.assertLessEqual(c.low, min(c.open, c.close))
