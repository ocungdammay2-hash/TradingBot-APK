"""Cache build của CI. Người dùng: «mỗi lần build là đợi lâu quá, sao ko lưu cache». Nguyên nhân tìm được trong build-apk.yml cũ: khoá cache =
hashFiles('**/buildozer.spec') mà file đó có dòng `version = ...` nên MỖI lần tăng phiên bản là trượt cache và build lại từ đầu; Gradle/ccache không được
cache; mỗi lần chạy lại lưu thêm một bản sao nhiều GB; không có khoá ký cố định nên APK mới khác chữ ký bản cũ (không cài đè được => mất dữ liệu app).
Đây KHÔNG chạy được GitHub Actions: test chỉ kiểm tra mã băm và cấu trúc workflow."""
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_spec = importlib.util.spec_from_file_location("ci_fingerprint", os.path.join(ROOT, "tools", "ci_fingerprint.py"))
fpmod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fpmod)

SPEC = """[app]
title = Demo
version = 1.0.0
requirements = python3,kivy,requests
android.api = 36
android.minapi = 24
android.ndk = 28c
android.ndk_api = 24
android.archs = arm64-v8a, armeabi-v7a
p4a.branch = v2026.05.09
p4a.local_recipes = tools/p4a_recipes
android.permissions = INTERNET
services = Bot:service.py:foreground
"""


class TestFingerprint(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.d, True)
        os.makedirs(os.path.join(self.d, "tools", "p4a_recipes", "r1"))
        with open(os.path.join(self.d, "tools", "p4a_recipes", "r1", "__init__.py"), "w") as f:
            f.write("recipe = 1\n")
        with open(os.path.join(self.d, "tools", "p4a_constraints.txt"), "w") as f:
            f.write("pip==25.3\n")

    def fp(self, text=SPEC):
        p = os.path.join(self.d, "buildozer.spec")
        with open(p, "w", encoding="utf-8") as f:
            f.write(text)
        t, c, _ = fpmod.fingerprints(p)
        return t, c

    def test_version_and_app_only_settings_do_not_change_the_cache_keys(self):
        base = self.fp()
        self.assertEqual(self.fp(SPEC.replace("version = 1.0.0", "version = 9.9.9")), base)        # đây là lỗi cũ: tăng version = mất cache
        self.assertEqual(self.fp(SPEC.replace("android.permissions = INTERNET", "android.permissions = INTERNET, CAMERA")), base)
        self.assertEqual(self.fp(SPEC.replace("services = Bot:service.py:foreground", "services = Bot:service.py:foreground, Emu:e.py:foreground")), base)
        self.assertEqual(self.fp("# ghi chú mới\n" + SPEC), base)
        self.assertEqual(self.fp(SPEC.replace("title = Demo", "title = Tên khác")), base)

    def test_things_that_change_compiled_output_change_comp_key(self):
        t0, c0 = self.fp()
        for old, new in (("requirements = python3,kivy,requests", "requirements = python3,kivy,requests,numpy"),
                         ("android.archs = arm64-v8a, armeabi-v7a", "android.archs = arm64-v8a"),
                         ("android.ndk = 28c", "android.ndk = 27c"),
                         ("android.api = 36", "android.api = 35"),
                         ("p4a.branch = v2026.05.09", "p4a.branch = develop")):
            t, c = self.fp(SPEC.replace(old, new))
            self.assertNotEqual(c, c0, new)
        # thứ tự khai báo không quan trọng
        self.assertEqual(self.fp(SPEC.replace("python3,kivy,requests", "requests, kivy ,python3"))[1], c0)
        self.assertEqual(self.fp(SPEC.replace("arm64-v8a, armeabi-v7a", "armeabi-v7a,arm64-v8a"))[1], c0)

    def test_tool_key_ignores_requirements_and_archs_but_follows_sdk_ndk_p4a(self):
        t0, _ = self.fp()
        self.assertEqual(self.fp(SPEC.replace("python3,kivy,requests", "python3,kivy,numpy"))[0], t0)     # SDK/NDK giữ nguyên khi đổi module
        self.assertEqual(self.fp(SPEC.replace("arm64-v8a, armeabi-v7a", "arm64-v8a"))[0], t0)
        for old, new in (("android.ndk = 28c", "android.ndk = 27c"), ("android.api = 36", "android.api = 35"),
                         ("p4a.branch = v2026.05.09", "p4a.branch = develop")):
            self.assertNotEqual(self.fp(SPEC.replace(old, new))[0], t0, new)

    def test_local_recipe_and_constraints_content_change_comp_key_only(self):
        t0, c0 = self.fp()
        with open(os.path.join(self.d, "tools", "p4a_recipes", "r1", "__init__.py"), "w") as f:
            f.write("recipe = 2\n")
        t1, c1 = self.fp()
        self.assertNotEqual(c1, c0)
        self.assertEqual(t1, t0)
        with open(os.path.join(self.d, "tools", "p4a_constraints.txt"), "w") as f:
            f.write("pip==26.0\n")
        self.assertNotEqual(self.fp()[1], c1)

    def test_pycache_in_recipes_is_ignored(self):
        _, c0 = self.fp()
        os.makedirs(os.path.join(self.d, "tools", "p4a_recipes", "r1", "__pycache__"))
        with open(os.path.join(self.d, "tools", "p4a_recipes", "r1", "__pycache__", "x.cpython-313.pyc"), "wb") as f:
            f.write(b"\x00\x01")
        self.assertEqual(self.fp()[1], c0)

    def test_cli_prints_and_appends_github_output(self):
        p = os.path.join(self.d, "buildozer.spec")
        open(p, "w", encoding="utf-8").write(SPEC)
        out = os.path.join(self.d, "gh_out")
        r = subprocess.run([sys.executable, "-I", os.path.join(ROOT, "tools", "ci_fingerprint.py"), p, "--github-output", out], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        t, c, _ = fpmod.fingerprints(p)
        self.assertEqual(r.stdout.split(), ["tool=" + t, "comp=" + c])
        self.assertEqual(open(out).read().split(), ["tool=" + t, "comp=" + c])
        self.assertRegex(t, r"^[0-9a-f]{12}$")

    def test_real_spec_is_stable_across_a_version_bump(self):
        real = os.path.join(ROOT, "buildozer.spec")
        text = open(real, encoding="utf-8").read()
        self.assertRegex(text, r"(?m)^version\s*=")
        bumped = os.path.join(self.d, "buildozer.spec")
        os.makedirs(os.path.join(self.d, "tools"), exist_ok=True)
        shutil.copytree(os.path.join(ROOT, "tools", "p4a_recipes"), os.path.join(self.d, "tools", "p4a_recipes"), dirs_exist_ok=True)
        shutil.copy(os.path.join(ROOT, "tools", "p4a_constraints.txt"), os.path.join(self.d, "tools", "p4a_constraints.txt"))
        shutil.copy(real, bumped)
        a = fpmod.fingerprints(bumped)[:2]
        with open(bumped, "w", encoding="utf-8") as f:
            f.write(re.sub(r"(?m)^version\s*=.*$", "version = 99.99.99", text))
        self.assertEqual(fpmod.fingerprints(bumped)[:2], a)


class TestWorkflowCache(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, ".github", "workflows", "build-apk.yml"), encoding="utf-8") as f:
            cls.wf = f.read()

    def test_workflow_is_valid_yaml_with_expected_steps(self):
        import yaml
        d = yaml.safe_load(self.wf)
        names = [st.get("name", st.get("uses", "")) for st in d["jobs"]["build"]["steps"]]
        for need in ("Mã băm cache", "Cache 1/4 - công cụ (SDK/NDK/p4a)", "Cache 2/4 - phần đã biên dịch", "Cache 3/4 - Gradle", "Cache 4/4 - ccache",
                     "Khoá ký APK - chuẩn bị", "Dọn trước khi lưu cache", "Tóm tắt cache và chữ ký"):
            self.assertIn(need, names)
        ids = {st.get("id") for st in d["jobs"]["build"]["steps"]}
        self.assertTrue({"fp", "c_tool", "c_comp", "c_grad", "c_cc", "sign", "build"} <= ids)

    def test_keys_use_fingerprint_not_hashfiles_of_the_spec(self):
        code = "\n".join(x for x in self.wf.splitlines() if not x.lstrip().startswith("#"))      # bỏ dòng chú thích (có nhắc cách cũ)
        self.assertNotIn("hashFiles(", code)
        self.assertIn("tools/ci_fingerprint.py", self.wf)
        for key in ("bz-tool-v4-${{ runner.os }}-${{ steps.fp.outputs.tool }}", "bz-comp-v4-${{ runner.os }}-${{ steps.fp.outputs.comp }}-ok",
                    "gradle-v1-${{ runner.os }}-${{ steps.fp.outputs.tool }}", "ccache-v1-${{ runner.os }}-${{ steps.fp.outputs.comp }}"):
            self.assertIn(key, self.wf)

    def test_saves_only_when_not_already_cached_and_never_a_new_copy_per_run(self):
        saves = re.findall(r"- name: (Lưu cache[^\n]*)\n\s+if: ([^\n]*)\n\s+uses: actions/cache/save@v4\n\s+with:\n\s+path:[^\n]*\n(?:\s+[~$][^\n]*\n)*\s+key: ([^\n]*)", self.wf)
        self.assertEqual(len(saves), 5, saves)
        for name, cond, key in saves:
            if "build lỗi" in name:
                self.assertIn("partial", key)                      # build lỗi giữa chừng: giữ phần đã biên dịch, khoá riêng
                self.assertIn("github.run_id", key)
            else:
                self.assertIn("cache-hit != 'true'", cond, name)   # đã có đúng khoá thì không lưu lại (không tải lên lại vài GB)
                self.assertNotIn("run_id", key, name)              # khoá ổn định: không sinh một bản sao mới mỗi lần chạy, không đẩy cache khác ra khỏi hạn mức 10 GB
            self.assertIn("always()", cond)
        tool = [c for n, c, k in saves if "công cụ" in n][0]
        self.assertIn("steps.build.outcome == 'success'", tool)    # không đóng băng SDK/NDK tải dở

    def test_gradle_and_ccache_are_cached(self):
        self.assertIn("~/.gradle/caches", self.wf)
        self.assertIn("~/.gradle/wrapper", self.wf)
        self.assertIn("~/.ccache", self.wf)
        self.assertIn("CCACHE_DIR", self.wf)

    def test_dist_and_venv_are_pruned_before_saving(self):
        i = self.wf.index("name: Dọn trước khi lưu cache")
        j = self.wf.index("name: Lưu cache 1/4")
        seg = self.wf[i:j]
        self.assertIn("build-*/dists", seg)
        self.assertIn("build-*/build/venv", seg)
        # dọn SAU bước kiểm tra manifest (bước đó đọc dist)
        self.assertGreater(i, self.wf.index("Verify"))

    def test_stable_signing_key_so_updates_install_over_the_old_app(self):
        self.assertIn("PYEA_KEYSTORE_B64", self.wf)
        self.assertIn("pyea-debug-keystore-v1", self.wf)
        self.assertIn("-alias androiddebugkey", self.wf)
        self.assertIn("-storepass android", self.wf)
        self.assertIn("verify --print-certs", self.wf)                   # đối chiếu chữ ký APK với khoá cố định
        self.assertIn("KHÔNG ký bằng khoá cố định", self.wf)
        i, j = self.wf.index("Khoá ký APK - chuẩn bị"), self.wf.index("name: Build debug APK")
        self.assertLess(i, j)                                       # khoá phải có TRƯỚC khi Gradle build
        self.assertNotRegex(self.wf, r"(?i)BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY")
        self.assertNotIn("license_private", self.wf)

    def test_manual_run_can_pick_architectures_and_cache_follows(self):
        self.assertIn("archs:", self.wf)
        self.assertIn("arm64-v8a", self.wf)
        i, j = self.wf.index("Chọn kiến trúc CPU"), self.wf.index("name: Mã băm cache")
        self.assertLess(i, j)                                       # sửa spec TRƯỚC khi tính mã băm cache

    def test_workflow_copy_in_docs_identical(self):
        with open(os.path.join(ROOT, "docs", "build-apk.yml"), encoding="utf-8") as f:
            self.assertEqual(f.read(), self.wf)


if __name__ == "__main__":
    unittest.main()
