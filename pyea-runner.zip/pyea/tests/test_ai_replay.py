"""Ghi & phát lại tín hiệu AI (pyea.airec): backtest bot dùng api.ai_signal tái lập được, không nhìn trước, và nói rõ giới hạn."""
import json
import math
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub
kivy_stub.install()

from pyea import ai, airec, redact                                                # noqa: E402
from pyea.backtest import intrabar_sensitivity, optimize, run_backtest, run_portfolio, walk_forward   # noqa: E402
from pyea.sdk import Candle                                                       # noqa: E402
from pyea.settings import default_settings                                        # noqa: E402
from pyea.storage import Store                                                    # noqa: E402

TMP = tempfile.mkdtemp()
T0, STEP = 1_700_000_000, 300


def rec(t, action="buy", sid=1, symbol="BTCUSD", **kw):
    d = {"time": float(t), "action": action, "id": sid, "confidence": 0.8, "sl_pct": 0.0, "tp_pct": 0.0, "reason": "r", "by": "A",
         "model": "m1", "symbol": symbol, "timeframe": "5m", "prompt_hash": "abcd" * 4, "v": 1, "uid": "%d-%d" % (int(t * 1000), sid)}
    d.update(kw)
    return d


class TestHelpers(unittest.TestCase):
    def test_prompt_hash_is_stable_and_content_sensitive(self):
        a = [{"role": "system", "content": "x"}, {"role": "user", "content": "y"}]
        b = [{"content": "x", "role": "system"}, {"content": "y", "role": "user"}]            # khác thứ tự khoá -> cùng hash
        self.assertEqual(airec.prompt_hash(a), airec.prompt_hash(b))
        self.assertEqual(len(airec.prompt_hash(a)), 16)
        self.assertNotEqual(airec.prompt_hash(a), airec.prompt_hash(a[:1] + [{"role": "user", "content": "z"}]))

    def test_combine_hashes_ignores_order_and_blanks(self):
        self.assertEqual(airec.combine_hashes(["a", "b", None, ""]), airec.combine_hashes(["b", "a"]))
        self.assertEqual(airec.combine_hashes([None, ""]), "")

    def test_valid_rejects_garbage(self):
        self.assertTrue(airec.valid(rec(100)))
        for bad in (None, 5, {}, rec(0), rec(-1), dict(rec(100), time=float("nan")), dict(rec(100), time=float("inf")), rec(100, action="yolo"), {"action": "buy"}):
            self.assertFalse(airec.valid(bad), bad)

    def test_to_record_keeps_audit_fields_drops_discussion_and_redacts(self):
        key = "sk-abcdefghijklmnopqrstuvwx1234"
        sig = {"id": 7, "time": 1700000123.4, "action": "buy", "confidence": 0.7, "sl_pct": 1, "tp_pct": 2, "by": "A", "model": "gpt-x",
               "mode": "1 AI chốt", "reason": "dùng key %s để vào" % key, "discussion": [{"agent": "A", "text": "dài"}] * 50,
               "prompt_hash": "0123456789abcdef", "votes": [{"agent": "A", "model": "gpt-x", "action": "buy", "confidence": 0.7,
                                                             "reason": "r", "prompt_hash": "0123456789abcdef", "api_key": key}]}
        r = airec.to_record(sig, symbol="XAUUSD", timeframe="5m", provider="Groq")
        self.assertNotIn("discussion", r)
        self.assertEqual((r["symbol"], r["timeframe"], r["provider"], r["v"]), ("XAUUSD", "5m", "Groq", 1))
        self.assertEqual(r["uid"], "1700000123400-7")
        self.assertEqual(r["model"], "gpt-x")
        self.assertEqual(r["prompt_hash"], "0123456789abcdef")
        self.assertNotIn(key, json.dumps(r))                                    # che bí mật cả ở reason lẫn votes (khoá lạ bị bỏ)
        self.assertNotIn("api_key", r["votes"][0])


class TestSignalLog(unittest.TestCase):
    def setUp(self):
        self.p = os.path.join(tempfile.mkdtemp(), "s.jsonl")
        self.log = airec.SignalLog(self.p)

    def test_roundtrip_sorted_and_tolerates_bad_lines(self):
        self.assertTrue(self.log.append(rec(300, sid=2)))
        self.assertTrue(self.log.append(rec(100, sid=1)))
        with open(self.p, "a", encoding="utf-8") as f:
            f.write("not json\n{\"action\": \"buy\"}\n\n")                         # dòng hỏng + bản ghi thiếu thời gian
        self.log.append(rec(200, sid=3))
        got = self.log.load()
        self.assertEqual([r["time"] for r in got], [100.0, 200.0, 300.0])

    def test_filters(self):
        for t, s in ((100, "BTCUSD"), (200, "ETHUSD"), (300, "btcusd")):
            self.log.append(rec(t, symbol=s, sid=t))
        self.assertEqual([r["time"] for r in self.log.load(since=150)], [200.0, 300.0])
        self.assertEqual([r["time"] for r in self.log.load(until=250)], [100.0, 200.0])
        self.assertEqual([r["time"] for r in self.log.load(symbol="BTCUSD")], [100.0, 300.0])      # không phân biệt hoa/thường

    def test_unknown_symbol_records_are_kept_for_any_symbol(self):
        self.log.append(rec(100, symbol="", sid=1))
        self.assertEqual(len(self.log.load(symbol="BTCUSD")), 1)

    def test_nan_cannot_be_written_and_missing_file_is_empty(self):
        self.assertFalse(self.log.append(rec(100, confidence=float("nan"))))
        self.assertEqual(self.log.load(), [])
        self.assertEqual(airec.SignalLog(os.path.join(tempfile.mkdtemp(), "none.jsonl")).load(), [])
        self.assertFalse(airec.SignalLog(os.path.join(tempfile.mkdtemp(), "no", "dir", "x.jsonl")).append(rec(100)))   # lỗi ghi không ném ra


class TestReplayHub(unittest.TestCase):
    def hub(self, sigs, now, ttl=1.0, window=None):
        clock = {"t": now}
        h = airec.ReplayHub(sigs, lambda: clock["t"], ttl, window)
        h.clk = clock
        return h

    def test_no_lookahead_and_latest_wins(self):
        h = self.hub([rec(1000, "buy", 1), rec(1030, "sell", 2)], now=999)
        self.assertIsNone(h.get_signal())                                       # chưa có tín hiệu nào tại thời điểm này
        h.clk["t"] = 1000
        self.assertEqual(h.get_signal()["action"], "buy")                      # đúng lúc = đã có
        h.clk["t"] = 1029.9
        self.assertEqual(h.get_signal()["action"], "buy")
        h.clk["t"] = 1030
        self.assertEqual(h.get_signal()["action"], "sell")

    def test_ttl_expiry_and_age(self):
        h = self.hub([rec(1000)], now=1030, ttl=1.0)                            # ttl 1 phút = 60s
        s = h.get_signal()
        self.assertAlmostEqual(s["age"], 30.0)
        self.assertTrue(s["replayed"])
        h.clk["t"] = 1060.5
        self.assertIsNone(h.get_signal())

    def test_returns_a_copy(self):
        h = self.hub([rec(1000)], now=1001)
        s = h.get_signal()
        s["action"] = "hacked"
        self.assertEqual(h.get_signal()["action"], "buy")

    def test_bad_clock_values_never_raise(self):
        h = self.hub([rec(1000)], now=float("nan"))
        self.assertIsNone(h.get_signal())
        h.clk["t"] = float("-inf")
        self.assertIsNone(h.get_signal())
        h.clock = lambda: None
        self.assertIsNone(h.get_signal())

    def test_unsorted_and_invalid_input_is_sanitised(self):
        h = self.hub([rec(1030, "sell", 2), {"junk": 1}, rec(1000, "buy", 1)], now=1010)
        self.assertEqual(h.get_signal()["action"], "buy")

    def test_summary_variants_are_honest(self):
        none = self.hub([], now=0)
        self.assertIn("KHÔNG có tín hiệu", none.summary())
        outside = self.hub([rec(10)], now=5000, window=(1000, 2000))
        self.assertIn("KHÔNG cái nào nằm trong", outside.summary())
        inside = self.hub([rec(1500)], now=1600, ttl=10.0, window=(1000, 2000))
        inside.get_signal()
        inside.get_signal()
        txt = inside.summary()
        self.assertIn("1 nằm trong khoảng dữ liệu", txt)
        self.assertIn("đọc 2 lần, 2 lần thấy", txt)
        self.assertIn("KHÔNG sinh lại", txt)

    def test_null_hub_only_speaks_when_the_bot_actually_reads(self):
        n = airec.NullHub()
        self.assertEqual(n.summary(), "")
        self.assertIsNone(n.get_signal())
        self.assertIn("KHÔNG phát lại", n.summary())
        self.assertIn("1 lần", n.summary())


# ========================================================================================= backtest
def settings(**over):
    s = default_settings()
    s.update(initial_balance=10000.0, leverage=10.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0)
    s.update(over)
    return s


def candles(n=80):
    return [Candle(T0 + i * STEP, 100.0 + i * 0.1, 100.0 + i * 0.1, 100.0 + i * 0.1, 100.0 + i * 0.1, 1.0) for i in range(n)]


def write(name, body):
    p = os.path.join(TMP, name)
    open(p, "w", encoding="utf-8").write(body)
    return p


AIBOT = write("aibot.py", '''
from pyea import BaseBot
class A(BaseBot):
    def on_init(self):
        self.seen = []
    def on_bar(self, c):
        s = self.api.ai_signal
        if s and s["action"] == "buy" and not self.api.positions():
            self.api.buy(1.0, reason="theo AI", ai=True)
''')
PLAIN = write("noai.py", "from pyea import BaseBot\nclass P(BaseBot):\n    pass\n")


def bt(sigs, bot=AIBOT, **kw):
    return run_backtest(bot, {}, settings(), "BTCUSD", "5m", candles(), warmup=30, mode="open", ai_signals=sigs, **kw)


class TestBacktestReplay(unittest.TestCase):
    t_sig = T0 + 50 * STEP + 10                                                   # giữa vùng test (warm-up là 30 nến đầu)

    def test_replay_opens_only_after_signal_time_with_provenance(self):
        r = bt([rec(self.t_sig, "buy", 5, prompt_hash="feedfacefeedface", model="gpt-x")])
        self.assertTrue(r.ok, r.error)
        ev = [e for e in r.events if e.kind == "open"]
        self.assertEqual(len(ev), 1)
        self.assertGreaterEqual(ev[0].time, self.t_sig)                           # không nhìn trước tương lai
        self.assertEqual(ev[0].ai["prompt_hash"], "feedfacefeedface")             # sự kiện lưu model + dấu vân tay prompt
        self.assertEqual(ev[0].ai["model"], "gpt-x")
        self.assertTrue(ev[0].ai["replayed"])
        self.assertIn("Phát lại 1 tín hiệu", r.report["Tín hiệu AI"])

    def test_without_replay_the_bot_sees_nothing_and_the_report_says_so(self):
        r = bt(None)
        self.assertEqual(r.trades, [])
        self.assertIn("KHÔNG phát lại", r.report["Tín hiệu AI"])

    def test_bot_that_never_reads_ai_gets_no_noise_in_the_report(self):
        self.assertNotIn("Tín hiệu AI", bt(None, PLAIN).report)

    def test_signals_outside_the_window_are_called_out_not_silently_ignored(self):
        r = bt([rec(T0 - 10 ** 7, "buy")])
        self.assertEqual(r.trades, [])
        self.assertIn("KHÔNG cái nào nằm trong", r.report["Tín hiệu AI"])

    def test_expired_signal_is_not_replayed(self):
        s = settings(ai_signal_ttl=1)                                              # 1 phút < 1 nến 5 phút
        r = run_backtest(AIBOT, {}, s, "BTCUSD", "5m", candles(), warmup=30, mode="open", ai_signals=[rec(T0 + 40 * STEP + 1, "buy")])
        self.assertTrue(all(e.time < T0 + 40 * STEP + 90 for e in r.events if e.kind == "open"))

    def test_replay_is_deterministic(self):
        sigs = [rec(self.t_sig, "buy", 5)]
        a, b = bt(sigs), bt(sigs)
        self.assertEqual([(t.open_time, t.close_time, t.profit) for t in a.trades], [(t.open_time, t.close_time, t.profit) for t in b.trades])

    def test_portfolio_replay(self):
        entries = [{"bot_path": AIBOT, "params": {}, "symbol": "BTCUSD", "tf": "5m", "candles": candles(), "warmup": 30}]
        r = run_portfolio(entries, settings(), warmup=30, mode="open", ai_signals=[rec(self.t_sig, "buy")])
        self.assertTrue(r.ok, r.error)
        self.assertIn("Phát lại 1 tín hiệu", r.report["Tín hiệu AI"])
        self.assertTrue(any(e.kind == "open" for e in r.events))
        self.assertIn("KHÔNG phát lại", run_portfolio(entries, settings(), warmup=30, mode="open").report["Tín hiệu AI"])

    def test_signals_pass_through_optimize_sensitivity_and_walk_forward(self):
        sigs = [rec(self.t_sig, "buy")]
        out = optimize(AIBOT, {}, {"x": [1, 2]}, settings(), "BTCUSD", "5m", candles(), warmup=30, ai_signals=sigs)
        self.assertTrue(all("Phát lại" in o["report"]["Tín hiệu AI"] for o in out))
        sens = intrabar_sensitivity(AIBOT, {}, settings(), "BTCUSD", "5m", candles(), warmup=30, ai_signals=sigs)
        self.assertTrue(sens["ok"])
        self.assertTrue(all(v["trades"] >= 1 for v in sens["results"].values()))
        wf = walk_forward(AIBOT, {}, {}, settings(), "BTCUSD", "5m", candles(300), warmup=30, is_bars=100, oos_bars=50, ai_signals=sigs)
        self.assertTrue(wf["ok"], wf["error"])


# ========================================================================================= AIHub ghi tín hiệu
class TestHubRecords(unittest.TestCase):
    KEY = "sk-abcdefghijklmnopqrstuvwx9876"

    @staticmethod
    def snap():
        cs = [Candle(i * 60, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(60)]
        return {"ready": True, "candles": cs, "symbol": "XAUUSD", "timeframe": "1m", "mode": "paper", "bid": 160, "ask": 160.1,
                "balance": 1000, "equity": 1000, "pnl_pct": 0, "max_dd": 0, "n_trades": 0, "win_rate": 0, "positions": [], "trades": [], "plots": {}}

    def run_session(self, mode, agents, reasons=None):
        sent = []

        def fake(agent, messages, max_tokens=800, timeout=90):
            if "QUYẾT ĐỊNH CUỐI" in messages[-1]["content"]:
                sent.append((agent["name"], airec.prompt_hash(messages)))
                return json.dumps({"action": "buy", "confidence": 0.8, "sl_pct": 1, "tp_pct": 2,
                                   "reason": (reasons or {}).get(agent["name"], "lý do " + agent["name"])})
            return "ý kiến " + agent["name"]
        orig = ai.chat_completion
        ai.chat_completion = fake
        d = tempfile.mkdtemp()
        try:
            store = Store(d)
            hub = ai.AIHub(store, self.snap, lambda: ("b", "src", {}), lambda: dict(default_settings(), ai_decision_mode=mode, ai_rounds=1))
            hub.set_agents(agents)
            hub._auto_session()
        finally:
            ai.chat_completion = orig
        return d, hub, sent

    def test_single_decider_is_recorded_with_model_and_exact_prompt_hash(self):
        a = dict(ai.default_agent(1), name="A", model="model-a", preset="Groq")
        b = dict(ai.default_agent(2), name="B", model="model-b", preset="Mistral", decider=True)
        d, hub, sent = self.run_session("decider", [a, b])
        recs = airec.load_dir(d)
        self.assertEqual(len(recs), 1)
        r = recs[0]
        self.assertEqual((r["action"], r["by"], r["model"], r["symbol"], r["timeframe"], r["provider"]), ("buy", "B", "model-b", "XAUUSD", "1m", "Mistral"))
        self.assertEqual(r["prompt_hash"], dict(sent)["B"])                       # đúng hash của prompt đã gửi cho AI chốt
        self.assertEqual(r["votes"][0]["prompt_hash"], r["prompt_hash"])
        self.assertNotIn("discussion", r)
        self.assertEqual(hub.get_signal()["prompt_hash"], r["prompt_hash"])       # bot đọc live cũng thấy cùng dấu vân tay
        self.assertEqual(r["uid"], "%d-%d" % (int(r["time"] * 1000), r["id"]))

    def test_majority_records_combined_hash_and_all_votes(self):
        ag = [dict(ai.default_agent(i), name=n, model="m" + n, preset="Groq") for i, n in enumerate("ABC", 1)]
        d, hub, sent = self.run_session("majority", ag)
        r = airec.load_dir(d)[0]
        self.assertEqual(len(r["votes"]), 3)
        self.assertEqual(r["prompt_hash"], airec.combine_hashes(h for _, h in sent))
        self.assertEqual({v["prompt_hash"] for v in r["votes"]}, {h for _, h in sent})
        self.assertEqual(r["provider"], "Groq")

    def test_api_key_never_reaches_the_signal_file(self):
        a = dict(ai.default_agent(1), name="A", decider=True, api_key=self.KEY)
        d, hub, _ = self.run_session("decider", [a], reasons={"A": "đã dùng khoá %s" % self.KEY})
        raw = open(os.path.join(d, airec.SIGNAL_FILE), encoding="utf-8").read()
        self.assertTrue(raw.strip())
        self.assertNotIn(self.KEY, raw)

    def test_hub_without_a_store_path_still_works(self):
        class Bare:
            pass
        st = Store(tempfile.mkdtemp())
        h = ai.AIHub(st, lambda: {}, lambda: None, lambda: default_settings())
        h.sigs = None
        self.assertIsNone(h.get_signal())


class TestRoundTrip(unittest.TestCase):
    def test_live_recorded_signal_replays_in_backtest(self):
        d = tempfile.mkdtemp()
        airec.SignalLog(os.path.join(d, airec.SIGNAL_FILE)).append(airec.to_record(
            {"id": 1, "time": TestBacktestReplay.t_sig, "action": "buy", "confidence": 0.9, "sl_pct": 0, "tp_pct": 0, "reason": "r", "by": "A",
             "model": "mm", "prompt_hash": "0123456789abcdef"}, symbol="BTCUSD", timeframe="5m"))
        sigs = airec.load_dir(d, symbol="BTCUSD")
        r = bt(sigs)
        self.assertTrue(any(e.kind == "open" and e.ai["model"] == "mm" for e in r.events))


if __name__ == "__main__":
    unittest.main()
