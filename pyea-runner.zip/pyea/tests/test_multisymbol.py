"""Đa mã trong một bot: api.candles/closes/tick_of/buy(symbol=...)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402,F401
from test_mtf_cache import ST, series, bot_file          # noqa: E402
from pyea.backtest import run_backtest                   # noqa: E402


class TestMultiSymbolBacktest(unittest.TestCase):
    def test_read_other_symbol_no_lookahead(self):
        base = series(300, 1200)
        eth = series(300, 1500, seed=9, base=50.0)
        body = 'e = self.api.candles(3, symbol="eth")\nself.api.log("E|%d|%d|%d" % (e[-1].time, len(e), c.time))'
        res = run_backtest(bot_file(body), {}, ST, "X", "5m", base, 100, "open", extra={"ETH": {"5m": eth}})
        self.assertTrue(res.ok, res.error)
        rows = [l[l.index("E|"):].split("|") for l in res.logs if "E|" in l]
        self.assertTrue(rows)
        for _e, last, n, now in rows:
            self.assertEqual(int(n), 3)
            self.assertLessEqual(int(last) + 300, int(now) + 300)

    def test_missing_symbol_errors_clearly(self):
        res = run_backtest(bot_file('self.api.candles(3, symbol="NOPE")'), {}, ST, "X", "5m", series(300, 600), 100, "open")
        self.assertFalse(res.ok)
        self.assertIn("NOPE", res.error)

    def test_own_symbol_unchanged(self):
        res = run_backtest(bot_file('x = self.api.closes(5, symbol="x")\nself.api.log("N|%d" % len(x))'), {}, ST, "X", "5m", series(300, 600), 100, "open")
        self.assertTrue(res.ok, res.error)
        self.assertTrue(any("N|5" in l for l in res.logs))


if __name__ == "__main__":
    unittest.main()


class TestMultiSymbolLive(unittest.TestCase):
    def test_bot_trades_other_symbol(self):
        import tempfile, time
        from pyea.engine import TradingSession
        from pyea.settings import default_settings
        body = ("from pyea import BaseBot\nclass H(BaseBot):\n    def on_tick(self, t):\n"
                "        if not self.api.positions(symbol='EURUSD'):\n"
                "            r = self.api.buy(1000, symbol='eurusd', reason='đa mã')\n"
                "            self.api.log('R|%s|%s' % (r.retcode, len(self.api.closes(5, symbol='EURUSD'))))\n")
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "ms.py")
            open(p, "w", encoding="utf-8").write(body)
            s = default_settings()
            s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=True, initial_balance=100000.0)
            sess = TradingSession(s, log_file=None)
            inst = sess.attach(p, "BTCUSD", "1m")
            sess.start(); inst.start()
            end = time.time() + 15
            while time.time() < end and not (sess.account and any(x.symbol == "EURUSD" for x in sess.account.positions.values())):
                time.sleep(0.1)
            try:
                pos = [x for x in sess.account.positions.values()]
                self.assertTrue(pos, [l[3] for l in sess.logs][-8:])
                self.assertEqual(pos[0].symbol, "EURUSD")
                self.assertEqual(pos[0].owner, inst.iid)
                self.assertTrue(any("R|OK|5" in l[3] for l in sess.logs), [l[3] for l in sess.logs][-8:])
            finally:
                sess.stop()
