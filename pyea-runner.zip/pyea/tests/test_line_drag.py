"""Kéo thả đường SL/TP trên biểu đồ như MT5: nhấn giữ -> kéo -> thả = áp dụng; kéo mượt (lớp phủ, không vẽ lại nến); popup chỉ để sửa chi tiết."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402
import test_chart as C                                   # noqa: E402


def chart_with_lines():
    ch = C.make_chart(200, 60)
    last = ch.candles[-1].close
    hl = [(last * 1.01, (0, 1, 0, 1), "TP #7", ("pos", 7, "tp")), (last * 0.99, (1, 0, 0, 1), "SL #7", ("pos", 7, "sl")),
          (last, (1, 1, 1, 1), "BUY 0.1 +1", ("pos", 7, "entry")), (last * 0.97, (1, 1, 0, 1), "SL #9", ("pend", 9, "sl"))]
    ch.update(ch.candles, {}, [], hl)
    ch.redraw()
    return ch, last


def line_y(ch, tag):
    return next(h[0] for h in ch._hlhits if h[1] == tag)


class TestLongPressDrag(unittest.TestCase):
    def setUp(self):
        self.ch, self.last = chart_with_lines()
        self.got = []
        self.ch.on_line_drag = lambda tag, price: self.got.append((tag, price))
        self.toasts = []
        self.ch.on_toast = self.toasts.append

    def test_hold_drag_release_applies(self):
        ch = self.ch
        y = line_y(ch, ("pos", 7, "sl"))
        t = C.down(ch, 100, y)
        self.assertIsNotNone(ch._arm_ev)                     # đã hẹn «nhấn giữ»
        ch._arm_drag()                                       # giả lập đủ 0.4 giây
        self.assertIsNotNone(ch._ldrag)
        C.move(ch, t, 100, y + 40)                           # Kivy: y tăng = lên cao
        C.up(ch, t)
        self.assertEqual(len(self.got), 1)
        tag, price = self.got[0]
        self.assertEqual(tag, ("pos", 7, "sl"))
        self.assertAlmostEqual(price, ch._pm.price(y + 40), places=6)
        self.assertGreater(price, self.last * 0.99)          # kéo lên = giá cao hơn
        self.assertIsNone(ch._ldrag)

    def test_quick_tap_opens_dialog_not_drag(self):
        ch = self.ch
        taps = []
        ch.on_line_tap = taps.append
        y = line_y(ch, ("pos", 7, "tp"))
        t = C.down(ch, 100, y)
        C.up(ch, t)                                          # nhả trước 0.4 s
        self.assertEqual(taps, [("pos", 7, "tp")])
        self.assertEqual(self.got, [])
        self.assertIsNone(ch._arm_ev)

    def test_pan_before_hold_cancels_arm(self):
        ch = self.ch
        y = line_y(ch, ("pos", 7, "sl"))
        t = C.down(ch, 100, y)
        C.move(ch, t, 160, y + 2)                            # kéo ngang quá ngưỡng = lướt biểu đồ
        self.assertIsNone(ch._arm_ev)
        ch._arm_drag()
        self.assertIsNone(ch._ldrag)
        C.up(ch, t)
        self.assertEqual(self.got, [])

    def test_entry_of_open_position_not_draggable(self):
        ch = self.ch
        t = C.down(ch, 100, line_y(ch, ("pos", 7, "entry")))
        self.assertIsNone(ch._arm_ev)
        C.up(ch, t)

    def test_pending_sl_draggable(self):
        ch = self.ch
        t = C.down(ch, 100, line_y(ch, ("pend", 9, "sl")))
        ch._arm_drag()
        C.move(ch, t, 100, line_y(ch, ("pend", 9, "sl")) + 30)
        C.up(ch, t)
        self.assertEqual(self.got[0][0], ("pend", 9, "sl"))

    def test_release_without_move_no_call(self):
        ch = self.ch
        t = C.down(ch, 100, line_y(ch, ("pos", 7, "sl")))
        ch._arm_drag()
        C.up(ch, t)
        self.assertEqual(self.got, [])

    def test_empty_area_never_arms(self):
        ch = self.ch
        t = C.down(ch, 100, 5)
        self.assertIsNone(ch._arm_ev)
        C.up(ch, t)

    def test_disabled_when_no_callback(self):
        ch = self.ch
        ch.on_line_drag = None
        t = C.down(ch, 100, line_y(ch, ("pos", 7, "sl")))
        self.assertIsNone(ch._arm_ev)
        C.up(ch, t)

    def test_not_armed_in_crosshair_mode(self):
        ch = self.ch
        ch.crosshair_mode = True
        t = C.down(ch, 100, line_y(ch, ("pos", 7, "sl")))
        self.assertIsNone(ch._arm_ev)
        C.up(ch, t)


class TestSmooth(unittest.TestCase):
    def test_line_drag_never_redraws_candles(self):
        ch, _ = chart_with_lines()
        ch.on_line_drag = lambda *a: None
        n = {"full": 0, "ov": 0}
        orig_redraw, orig_ov = ch.redraw, ch._redraw_overlay
        ch.redraw = lambda *a: (n.__setitem__("full", n["full"] + 1), orig_redraw())
        ch._redraw_overlay = lambda: (n.__setitem__("ov", n["ov"] + 1), orig_ov())
        y = line_y(ch, ("pos", 7, "sl"))
        t = C.down(ch, 100, y)
        ch._arm_drag()
        for i in range(60):
            C.move(ch, t, 100, y + i)
            for fn in [f for f in kivy_stub.SCHEDULED if getattr(f, "__self__", None) is ch]:       # chạy các lần hẹn vẽ (khung hình)
                fn()
                kivy_stub.SCHEDULED.remove(fn)
        C.up(ch, t)
        self.assertEqual(n["full"], 0)                       # KHÔNG vẽ lại nến + chỉ báo trong lúc kéo
        self.assertGreaterEqual(n["ov"], 1)

    def test_draft_drag_overlay_only_and_throttled_callback(self):
        ch = C.make_chart(200, 60)
        last = ch.candles[-1].close
        ch.draft = {"side": "buy", "price": last, "sl": last * 0.99, "tp": last * 1.01, "bid": last, "ask": last}
        calls = {"draft": 0, "full": 0}
        ch.on_draft = lambda: calls.__setitem__("draft", calls["draft"] + 1)
        orig = ch.redraw
        ch.redraw = lambda *a: (calls.__setitem__("full", calls["full"] + 1), orig())
        ch.redraw_ = orig
        ch.redraw()
        calls["full"] = 0
        ch.redraw = lambda *a: calls.__setitem__("full", calls["full"] + 1)
        t = C.down(ch, 100, ch._pm.y(last * 0.99))
        for i in range(80):
            C.move(ch, t, 100, ch._pm.y(last * 0.99) + i * 0.5)
        C.up(ch, t)
        self.assertEqual(calls["full"], 0)
        self.assertLess(calls["draft"], 20)                  # 80 lần kéo -> thanh nút dựng lại ít lần (trước đây 80)
        self.assertGreaterEqual(calls["draft"], 1)           # nhưng thả tay luôn cập nhật lần cuối

    def test_overlay_group_present_after_redraw(self):
        ch, _ = chart_with_lines()
        self.assertIn(ch._ov, ch.canvas.children)


class FakeCtl:
    def __init__(self):
        self.calls = []

    def modify_position(self, pid, sl, tp):
        self.calls.append(("pos", pid, sl, tp))
        return True

    def modify_order(self, oid, price, sl, tp):
        self.calls.append(("pend", oid, price, sl, tp))
        return True


class TestApply(unittest.TestCase):
    def app(self):
        import test_ui_smoke as S
        from pyea.sdk import PendingOrder, Position
        app = S.make_app()
        app.ctl = FakeCtl()
        app.chart_sym = "BTCUSDT"
        app.chart_tab._bid, app.chart_tab._ask = 100.0, 100.1
        pos = Position(id=7, symbol="BTCUSDT", side="buy", volume=1, open_price=100.0, open_time=0, sl=95.0, tp=110.0)
        sell = Position(id=8, symbol="BTCUSDT", side="sell", volume=1, open_price=100.0, open_time=0, sl=105.0, tp=90.0)
        import dataclasses
        flds = {f.name for f in dataclasses.fields(PendingOrder)}
        kw = dict(id=9, symbol="BTCUSDT", side="buy", volume=1, kind="limit", price=98.0, sl=96.0, tp=104.0)
        kw = {k: v for k, v in kw.items() if k in flds}
        app.last_snap = {"positions": [pos, sell], "pending": [PendingOrder(**kw)]}
        app.toasts = []
        app.toast = app.toasts.append
        return app

    def test_buy_sl_ok(self):
        app = self.app()
        self.assertTrue(app.apply_line_drag(("pos", 7, "sl"), 96.123456789))
        self.assertEqual(app.ctl.calls[-1], ("pos", 7, 96.12346, 110.0))   # làm tròn 5 số lẻ (giá < 100), giữ nguyên TP

    def test_buy_sl_above_bid_rejected(self):
        app = self.app()
        self.assertFalse(app.apply_line_drag(("pos", 7, "sl"), 101.0))
        self.assertEqual(app.ctl.calls, [])
        self.assertIn("DƯỚI", app.toasts[-1])

    def test_buy_tp_below_ask_rejected(self):
        app = self.app()
        self.assertFalse(app.apply_line_drag(("pos", 7, "tp"), 100.0))

    def test_sell_rules(self):
        app = self.app()
        self.assertTrue(app.apply_line_drag(("pos", 8, "sl"), 106.0))
        self.assertFalse(app.apply_line_drag(("pos", 8, "sl"), 99.0))
        self.assertTrue(app.apply_line_drag(("pos", 8, "tp"), 92.0))
        self.assertFalse(app.apply_line_drag(("pos", 8, "tp"), 101.0))

    def test_open_entry_not_movable(self):
        app = self.app()
        self.assertFalse(app.apply_line_drag(("pos", 7, "entry"), 99.0))
        self.assertEqual(app.ctl.calls, [])

    def test_pending_entry_and_levels(self):
        app = self.app()
        self.assertTrue(app.apply_line_drag(("pend", 9, "entry"), 97.5))
        self.assertEqual(app.ctl.calls[-1], ("pend", 9, 97.5, 96.0, 104.0))
        self.assertTrue(app.apply_line_drag(("pend", 9, "tp"), 105.0))
        self.assertFalse(app.apply_line_drag(("pend", 9, "sl"), 99.5))        # SL phải DƯỚI giá vào (98) với lệnh mua

    def test_vanished_order(self):
        app = self.app()
        self.assertFalse(app.apply_line_drag(("pos", 123, "sl"), 90.0))
        self.assertFalse(app.apply_line_drag(("pend", 123, "sl"), 90.0))

    def test_failed_modify_reports(self):
        app = self.app()
        app.ctl.modify_position = lambda *a: types_ns(ok=False, message="sàn từ chối")
        self.assertFalse(app.apply_line_drag(("pos", 7, "sl"), 96.0))
        self.assertIn("sàn từ chối", app.toasts[-1])


def types_ns(**kw):
    import types
    return types.SimpleNamespace(**kw)


class TestChartTabWiring(unittest.TestCase):
    def test_tags_and_pending_lines(self):
        import test_ui_smoke as S
        app = S.make_app()
        self.assertTrue(callable(app.chart_tab.panel.chart.on_line_drag))


if __name__ == "__main__":
    unittest.main()
