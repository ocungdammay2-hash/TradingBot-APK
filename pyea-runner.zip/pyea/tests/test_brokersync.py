"""Số liệu do SÀN báo hiển thị như MT5: lãi/lỗ + swap + hoa hồng từng vị thế, và lịch sử sàn (Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư).

Kiểm: (1) hàm thuần của pyea/brokerhist.py theo định nghĩa «History» của MT5 mobile, (2) vòng đọc ở luồng poll (chu kỳ, số cũ bị bỏ, lỗi -> giãn nhịp,
không có vị thế thì không gọi sàn, paper thì không gọi), (3) cùng một bộ kịch bản qua MetaApi / cổng MT5 / cổng + EA relay, (4) giao diện:
khung «Giao dịch» đổi nhãn «SÀN»/«sổ app», dòng vị thế dùng số của sàn, mục «Lịch sử từ sàn» tải ở luồng nền và nói rõ khi sàn chưa hỗ trợ."""
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))
sys.path.insert(0, HERE)

import test_protect_contract as tc                                             # noqa: E402
import test_gateway_protect as tg                                              # noqa: E402
from pyea import acctstate, brokerhist as bh                                   # noqa: E402
from pyea.broker import BrokerError                                            # noqa: E402


def deal(i, t, side, qty, price, entry, pos, profit=0.0, comm=0.0, swap=0.0, sym="EURUSD", **kw):
    return dict({"id": str(i), "time": t, "kind": "trade", "symbol": sym, "side": side, "qty": qty, "price": price, "entry": entry,
                 "position_id": str(pos), "profit": profit, "commission": comm, "swap": swap, "fee": 0.0}, **kw)


class TestBrokerHistPure(unittest.TestCase):
    def test_classify_covers_mt_and_generic_type_names(self):
        for raw, kind in (("DEAL_TYPE_BUY", "trade"), ("sell", "trade"), ("DEAL_TYPE_BALANCE", "balance"), ("deposit", "balance"), ("Withdrawal", "balance"),
                          ("DEAL_TYPE_CREDIT", "credit"), ("DEAL_TYPE_CHARGE", "other"), ("swap_fee", "other"), (None, "other")):
            self.assertEqual(bh.classify(raw), kind, raw)

    def test_norm_deal_fills_every_key_with_right_types_and_never_invents(self):
        n = bh.norm_deal({"id": 7, "time": "12.5", "profit": "x", "commission": None, "kind": "weird"})
        self.assertEqual((n["id"], n["time"], n["profit"], n["commission"], n["swap"], n["fee"]), ("7", 12.5, 0.0, 0.0, 0.0, 0.0))
        self.assertEqual((n["kind"], n["entry"], n["position_id"], n["comment"]), ("trade", "", "", ""))
        self.assertEqual(bh.norm_deal({"profit": float("nan")})["profit"], 0.0)
        self.assertEqual(bh.norm_deal({"profit": float("inf")})["profit"], 0.0)

    def test_summary_follows_mt5_definitions(self):
        ds = [{"id": "b", "time": 1, "kind": "balance", "profit": 1000.0},
              deal(1, 10, "buy", 0.1, 1.1000, "IN", 1, comm=-0.7),
              deal(2, 20, "sell", 0.1, 1.1100, "OUT", 1, profit=100.0, comm=-0.7, swap=-1.5),
              {"id": "c", "time": 30, "kind": "credit", "profit": 50.0}]
        s = bh.summarize(ds)
        self.assertAlmostEqual(s["deposit"], 1000.0)
        self.assertAlmostEqual(s["profit"], 100.0)                               # lợi nhuận KHÔNG gồm swap/hoa hồng
        self.assertAlmostEqual(s["swap"], -1.5)
        self.assertAlmostEqual(s["commission"], -1.4)
        self.assertAlmostEqual(s["other"], 50.0)
        self.assertAlmostEqual(s["balance"], 1000 + 100 - 1.5 - 1.4 + 50)        # số dư = tổng mọi thao tác trong kỳ
        self.assertEqual((s["trades"], s["positions"], s["deposits"]), (2, 1, 1))

    def test_withdrawal_is_negative_deposit_and_fee_counts_as_commission(self):
        s = bh.summarize([{"id": "a", "time": 1, "kind": "balance", "profit": 500.0}, {"id": "w", "time": 2, "kind": "balance", "profit": -200.0},
                          dict(deal(3, 3, "buy", 1, 1, "OUT", 9, profit=5.0), fee=-0.25)])
        self.assertAlmostEqual(s["deposit"], 300.0)
        self.assertAlmostEqual(s["commission"], -0.25)

    def test_empty_and_none_inputs(self):
        for x in (None, []):
            s = bh.summarize(x)
            self.assertEqual((s["profit"], s["deposit"], s["swap"], s["commission"], s["balance"], s["positions"]), (0, 0, 0, 0, 0, 0))
            self.assertEqual(bh.positions_from_deals(x), [])

    def test_positions_group_deals_with_weighted_prices_and_exclude_open_ones(self):
        ds = [deal(1, 10, "buy", 0.1, 1.1000, "IN", 5),
              deal(2, 11, "buy", 0.3, 1.1100, "IN", 5),                          # cộng thêm: giá mở bình quân gia quyền
              deal(3, 20, "sell", 0.2, 1.1200, "OUT", 5, profit=20.0, comm=-0.1, swap=-0.4),
              deal(4, 30, "sell", 0.2, 1.1300, "OUT", 5, profit=44.0, comm=-0.1),   # đóng từng phần: giá đóng bình quân
              deal(5, 40, "buy", 0.5, 1.2000, "IN", 6)]                          # còn mở -> không có trong lịch sử
        rows = bh.positions_from_deals(ds)
        self.assertEqual(len(rows), 1)
        r = rows[0]
        self.assertEqual((r["position_id"], r["symbol"], r["side"]), ("5", "EURUSD", "buy"))
        self.assertAlmostEqual(r["volume"], 0.4)
        self.assertAlmostEqual(r["open_price"], (0.1 * 1.10 + 0.3 * 1.11) / 0.4)
        self.assertAlmostEqual(r["close_price"], 1.125)
        self.assertEqual((r["open_time"], r["close_time"]), (10, 30))
        self.assertAlmostEqual(r["profit"], 64.0)
        self.assertAlmostEqual(r["swap"], -0.4)
        self.assertAlmostEqual(r["commission"], -0.2)

    def test_position_opened_before_the_period_takes_side_from_closing_deal(self):
        rows = bh.positions_from_deals([deal(9, 50, "sell", 1.0, 1.0, "OUT", 77, profit=3.0)])     # deal đóng là SELL -> vị thế là BUY
        self.assertEqual((rows[0]["side"], rows[0]["open_time"], rows[0]["open_price"], rows[0]["volume"]), ("buy", None, 0.0, 1.0))
        rows = bh.positions_from_deals([deal(9, 50, "buy", 1.0, 1.0, "OUT", 77, profit=3.0)])
        self.assertEqual(rows[0]["side"], "sell")

    def test_newest_close_first_and_deals_without_position_id_stay_separate(self):
        ds = [deal(1, 10, "sell", 1, 1, "OUT", "", profit=1.0), deal(2, 20, "sell", 1, 1, "OUT", "", profit=2.0), deal(3, 15, "sell", 1, 1, "OUT", 3, profit=3.0)]
        rows = bh.positions_from_deals(ds)
        self.assertEqual([r["profit"] for r in rows], [2.0, 3.0, 1.0])
        self.assertEqual(rows[0]["position_id"], "")

    def test_non_trade_deals_never_become_positions(self):
        self.assertEqual(bh.positions_from_deals([{"id": "b", "time": 1, "kind": "balance", "profit": 10.0, "position_id": "1", "entry": "OUT"}]), [])

    def test_day_start_is_local_midnight(self):
        now = 1_700_000_000.0                                                    # 2023-11-14 22:13:20 UTC
        self.assertEqual(bh.day_start(now, 0.0), 1_699_920_000.0)                # 00:00 UTC
        self.assertEqual(bh.day_start(now, 7 * 3600.0), 1_699_981_200.0)         # UTC+7: lúc đó đã là 05:13 ngày 15/11 -> 0h15/11 = 17:00 UTC 14/11
        self.assertLessEqual(bh.day_start(now, 7 * 3600.0), now)
        self.assertLess(now - bh.day_start(now, 7 * 3600.0), 86400.0)
        self.assertLess(now - bh.day_start(now, -5 * 3600.0), 86400.0)

    def test_money_groups_thousands_like_mt5(self):
        self.assertEqual(bh.money(-95376.37), "-95 376.37")
        self.assertEqual(bh.money(12345.6), "12 345.60")
        self.assertEqual(bh.money(1234567.891), "1 234 567.89")
        self.assertEqual(bh.money(0), "0.00")
        self.assertEqual(bh.money(999.999), "1 000.00")
        self.assertEqual(bh.money(None), "0.00")

    def test_fetch_normalises_and_summarises(self):
        class B:
            def account_history(self, since, until=None):
                self.args = (since, until)
                return [{"id": 1, "time": 5, "kind": "balance", "profit": 10}]
        b = B()
        r = bh.fetch(b, 100, 200)
        self.assertEqual(b.args, (100.0, 200.0))
        self.assertEqual(r["summary"]["deposit"], 10.0)
        self.assertEqual(r["deals"][0]["id"], "1")
        bh.fetch(b, 100)
        self.assertEqual(b.args, (100.0, None))

    def test_broker_without_history_gives_clear_message(self):
        with self.assertRaises(NotImplementedError) as cm:
            bh.fetch(object(), 0)
        self.assertIn("chưa có lịch sử", str(cm.exception))

    def test_paper_mode_has_no_exchange_history(self):
        for st in ({"mode": "paper", "exchange": "mt5gw"}, {"mode": "live", "exchange": "simulated"}, {}):
            with self.assertRaises(NotImplementedError) as cm:
                bh.fetch_for_settings(st, 0)
            self.assertIn("giả lập", str(cm.exception))

    def test_fetch_for_settings_builds_a_temporary_broker_and_always_closes_it(self):
        import pyea.broker as pb
        made = []

        class B:
            closed = False
            def __init__(self): made.append(self)
            def account_history(self, since, until=None):
                raise BrokerError("mạng lỗi")
            def close(self): self.closed = True
        orig = pb.make_broker
        pb.make_broker = lambda st: B()
        try:
            with self.assertRaises(BrokerError):
                bh.fetch_for_settings({"mode": "live", "exchange": "mt5gw"}, 0)
        finally:
            pb.make_broker = orig
        self.assertTrue(made[0].closed)                                          # đóng dù lỗi: không rò kết nối


class TestNormalizePositionStats(unittest.TestCase):
    def test_aliases_and_missing_fields_stay_absent(self):
        n = acctstate.normalize_position_stats([{"id": 5, "profit": 12.5, "swap": -1, "commission": -0.7, "price_now": 1.2},
                                                {"ref": "6", "unrealizedProfit": 3, "currentPrice": 9}, {"id": 7}, {"profit": 1}, "junk", None])
        self.assertEqual(n["5"], {"profit": 12.5, "swap": -1.0, "commission": -0.7, "price": 1.2})
        self.assertEqual(n["6"], {"profit": 3.0, "price": 9.0})              # trường sàn không báo thì VẮNG mặt, không bịa 0
        self.assertNotIn("7", n)                                              # không có trường nào -> bỏ
        self.assertEqual(len(n), 2)                                           # không có mã vị thế -> bỏ
        self.assertEqual(acctstate.normalize_position_stats(None), {})


# ------------------------------------------------------------------------------------------------------------- vòng đọc + 3 đường MT
class LiveBase:
    H = None
    POS_COMMISSION = True            # MetaApi có commission theo vị thế; MT5 python / EA MQL5 KHÔNG có (chỉ có ở deal) -> app không được bịa

    @classmethod
    def setUpClass(cls):
        cls.h = cls.H()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        h = self.h
        h.reset()
        self.s = h.session(tempfile.mkdtemp(), native_sltp=False)
        self.s.settings["mode"] = "live"
        self.s.settings["account_state_interval"] = 15.0
        h.tick(self.s, h.P0)

    def open_pos(self, vol=0.10):
        r = self.s.send_order(self.h.SYM, "buy", vol)
        self.assertTrue(r, r.message)
        return next(iter(self.s.account.positions.values()))

    def test_profit_swap_commission_come_from_the_exchange_for_that_exact_ticket(self):
        h, s = self.h, self.s
        p = self.open_pos()
        self.assertTrue(p.ref)
        h.core.positions[p.ref]["swap"] = -2.5
        h.exchange_price(1.1100)
        h.tick(s, 1.1100, 1001.0)
        s._check_position_stats()
        bp = s.broker_positions()
        self.assertIn(p.ref, bp)
        self.assertAlmostEqual(bp[p.ref]["profit"], 98.0, delta=0.5)         # mua ở ask 1.1002, bid mới 1.1100: 0.0098 × 0.10 × 100000
        self.assertAlmostEqual(bp[p.ref]["swap"], -2.5)
        if self.POS_COMMISSION:
            self.assertAlmostEqual(bp[p.ref]["commission"], -0.07)
        else:
            self.assertNotIn("commission", bp[p.ref])                            # sàn không báo thì VẮNG mặt, không điền 0
        self.assertAlmostEqual(bp[p.ref]["price"], 1.1100, 4)
        self.assertLess(abs(p.profit), 1.0)                                      # sổ app: Δgiá × lot ≈ 0.001 - KHÔNG phải số của sàn
        snap = s.snapshot()
        self.assertAlmostEqual(snap["broker_positions"][p.ref]["profit"], 98.0, delta=0.5)

    def test_only_the_asked_position_is_matched_when_several_exist(self):
        h, s = self.h, self.s
        a = self.open_pos(0.10)
        r = s.send_order(h.SYM, "buy", 0.04)
        self.assertTrue(r, r.message)
        b = next(p for p in s.account.positions.values() if p.ref != a.ref)
        h.exchange_price(1.1100)
        s._check_position_stats()
        bp = s.broker_positions()
        self.assertAlmostEqual(bp[a.ref]["profit"], 98.0, delta=0.5)
        self.assertAlmostEqual(bp[b.ref]["profit"], 39.2, delta=0.5)

    def test_no_position_means_no_exchange_call(self):
        s = self.s
        calls = []
        orig = s.broker.position_stats
        s.broker.position_stats = lambda: (calls.append(1), orig())[1]
        s._check_position_stats()
        self.assertEqual(calls, [])
        self.assertEqual(s.broker_positions(), {})

    def test_new_position_is_read_soon_after_an_empty_period(self):
        s = self.s
        s._check_position_stats()                                                # không vị thế: ghi nhận rỗng, lần sau đọc sớm (≤ 5s)
        self.assertLessEqual(s._bpos_next - time.time(), 5.0 + 0.1)

    def test_stale_numbers_are_dropped(self):
        s = self.s
        p = self.open_pos()
        s._check_position_stats()
        self.assertIn(p.ref, s.broker_positions())
        s._bpos["t"] -= 1000.0
        self.assertIsNone(s.broker_positions())
        self.assertIsNone(s.snapshot()["broker_positions"])

    def test_interval_zero_and_paper_never_call_the_exchange(self):
        s = self.s
        self.open_pos()
        calls = []
        s.broker.position_stats = lambda: calls.append(1) or {}
        s.settings["account_state_interval"] = 0.0
        s._check_position_stats()
        s.settings["account_state_interval"] = 15.0
        s.settings["mode"] = "paper"
        s._check_position_stats()
        self.assertEqual(calls, [])

    def test_respects_the_interval_between_reads(self):
        s = self.s
        self.open_pos()
        calls = []
        orig = s.broker.position_stats
        s.broker.position_stats = lambda: (calls.append(1), orig())[1]
        s._check_position_stats()
        s._check_position_stats()
        s._check_position_stats()
        self.assertEqual(len(calls), 1)

    def test_errors_back_off_warn_once_and_never_crash(self):
        s = self.s
        self.open_pos()
        logs = []
        s.log = lambda m, lvl="INFO": logs.append((lvl, m))
        calls = []

        def boom():
            calls.append(1)
            raise BrokerError("mạng đứt")
        s.broker.position_stats = boom
        s._check_position_stats()
        self.assertEqual(len([m for m in logs if m[0] == "WARN"]), 1)
        first_wait = s._bpos_next - time.time()
        s._check_position_stats()                                                # còn trong thời gian giãn nhịp -> không gọi lại
        self.assertEqual(len(calls), 1)
        s._bpos_next = 0.0
        s._check_position_stats()
        self.assertEqual(len(calls), 2)
        self.assertGreater(s._bpos_next - time.time(), first_wait * 1.5)         # lần lỗi thứ hai giãn gấp đôi (không phải chênh vài micro giây)
        self.assertGreater(first_wait, 15.0)                                     # và đã lớn hơn chu kỳ thường ngay lần lỗi đầu
        self.assertEqual(len([m for m in logs if m[0] == "WARN"]), 1)            # không spam nhật ký
        s.broker.position_stats = lambda: {}                                     # hồi phục
        s._bpos_next = 0.0
        s._check_position_stats()
        self.assertEqual(s._bpos_fail, 0)

    def test_session_applies_the_exchange_specific_field_override_to_account_numbers(self):
        from pyea import fieldmap
        s = self.s
        s.settings["exchange"] = "acme"
        s.broker.account_state = lambda: {"cash": 900.0, "nav_total": 950.0, "im": 50.0}
        try:
            fieldmap.configure({"field_overrides": {"acme": {"account": {"balance": "cash", "equity": "nav_total", "margin": "im"}}}})
            s._check_account_state()
            ba = s.broker_account()
            self.assertIsNotNone(ba)
            self.assertEqual((ba["balance"], ba["equity"], ba["margin"]), (900.0, 950.0, 50.0))
        finally:
            fieldmap.configure("")

    def test_broker_without_position_stats_is_silently_skipped(self):
        s = self.s
        self.open_pos()

        class NoStats:
            pass
        s.broker = NoStats()
        s._check_position_stats()
        self.assertIsNone(s.broker_positions())

    # ---- lịch sử sàn
    def test_account_history_reports_deposit_profit_and_fees_like_mt5(self):
        h, s = self.h, self.s
        p = self.open_pos(0.10)
        h.exchange_price(1.1100)
        h.tick(s, 1.1100, 1001.0)
        self.assertTrue(s.close_position(p.id))
        res = bh.fetch(s.broker, time.time() - 3600, time.time() + 3600)
        sm = res["summary"]
        self.assertAlmostEqual(sm["deposit"], 1000.0)                            # nạp 1000 do sàn giả ghi
        self.assertAlmostEqual(sm["profit"], 98.0, delta=0.5)                    # (bid 1.1100 - ask 1.1002) × 0.10 × 100000
        self.assertAlmostEqual(sm["commission"], -0.14, places=6)                # 2 deal × -0.07
        self.assertAlmostEqual(sm["balance"], sm["deposit"] + sm["profit"] + sm["swap"] + sm["commission"], 6)
        self.assertEqual(sm["positions"], 1)
        row = res["positions"][0]
        self.assertEqual((row["symbol"], row["side"]), (h.SYM, "buy"))
        self.assertAlmostEqual(row["volume"], 0.10)
        self.assertAlmostEqual(row["open_price"], 1.1002, 4)                     # mua ở ask
        self.assertAlmostEqual(row["close_price"], 1.1100, 4)                    # đóng ở bid
        self.assertAlmostEqual(row["profit"], sm["profit"], 6)

    def test_account_history_only_reports_the_asked_period(self):
        s = self.s
        p = self.open_pos()
        self.assertTrue(s.close_position(p.id))
        res = bh.fetch(s.broker, time.time() + 3600, time.time() + 7200)         # khoảng chưa có gì
        self.assertEqual(res["summary"]["trades"], 0)
        self.assertEqual(res["positions"], [])

    def test_manual_trades_outside_the_app_also_appear(self):
        h, s = self.h, self.s
        pid, _, _ = h.core.open(h.SYM, "sell", 0.02, "")                         # đặt tay trên MT, không qua app
        h.core.close(pid, None)
        res = bh.fetch(s.broker, time.time() - 3600, time.time() + 3600)
        self.assertEqual(res["summary"]["positions"], 1)
        self.assertEqual(res["positions"][0]["side"], "sell")


class TestLive_metaapi(LiveBase, unittest.TestCase):
    H = tc.MtH


class TestLive_gateway_mt5(LiveBase, unittest.TestCase):
    H = tg.GwMt5H
    POS_COMMISSION = False

    def test_history_right_after_gateway_start_detects_server_offset_instead_of_missing_recent_deals(self):
        h, s = self.h, self.s
        p = self.open_pos()
        self.assertTrue(s.close_position(p.id))
        h.be.offset, h.be._off_retry = None, 0.0                                 # cổng vừa khởi động: chưa tick nào đi qua nên chưa biết giờ máy chủ lệch bao nhiêu
        res = bh.fetch(s.broker, time.time() - 3600, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 2)                            # trước đây: hỏi MT5 sai múi giờ -> lệnh vừa đóng bị bỏ sót
        self.assertEqual(h.be.offset, 7200.0)
        self.assertAlmostEqual(res["deals"][0]["time"], time.time(), delta=5.0)  # và giờ deal quy về UTC đúng


class TestLive_gateway_ea(LiveBase, unittest.TestCase):
    H = tg.GwEaH
    POS_COMMISSION = False

    def test_old_ea_without_history_capability_says_so_clearly(self):
        h = self.h
        h.ea.caps = ""
        n = h.ea.polls
        tg.wait(lambda: h.ea.polls >= n + 3)
        with self.assertRaises(Exception) as cm:
            self.s.broker.account_history(0, time.time() + 10)
        self.assertRegex(str(cm.exception), r"(?i)EA|history|lịch sử")
        h.ea.caps = "sltp,posdeals,comment,history"


# ------------------------------------------------------------------------------------------------------------- hợp đồng + Kiểm tra hệ thống
from pyea import contract, ratelimit, selfcheck                                # noqa: E402


class TestContractShapes(unittest.TestCase):
    def test_account_state_shape(self):
        bad, st = contract.check_account_state({"balance": 10, "equity": 11, "margin": 2})
        self.assertEqual(bad, [])
        self.assertEqual(st["equity"], 11.0)
        for raw in (None, [], "x", {}, {"foo": 1}):
            bad, st = contract.check_account_state(raw)
            self.assertTrue(bad, raw)
            self.assertIsNone(st)

    def test_position_stats_shape(self):
        self.assertEqual(contract.check_position_stats({}), [])
        self.assertEqual(contract.check_position_stats({"7": {"profit": 1.5, "swap": -1.0, "price": 2.0}}), [])
        for bad in (None, [], {7: {"profit": 1}}, {"7": {}}, {"7": {"profit": "x"}}, {"7": {"profit": True}}, {"7": {"pnl": 1}}, {"": {"profit": 1}}, {"7": 5}):
            self.assertTrue(contract.check_position_stats(bad), bad)

    def test_history_deals_shape(self):
        ok = bh.norm_deal({"id": 1, "time": 5, "kind": "trade", "symbol": "EURUSD", "side": "buy"})
        self.assertEqual(contract.check_history_deals([ok]), [])
        self.assertEqual(contract.check_history_deals([]), [])
        self.assertTrue(contract.check_history_deals(None))
        self.assertTrue(contract.check_history_deals([{"id": 1}]))                                        # thiếu khoá
        self.assertTrue(contract.check_history_deals([dict(ok, kind="weird")]))
        self.assertTrue(contract.check_history_deals([dict(ok, profit="1")]))
        self.assertTrue(contract.check_history_deals([dict(ok, time=0)]))
        self.assertTrue(contract.check_history_deals([dict(ok, side="")]))                                # deal giao dịch phải có chiều
        self.assertEqual(contract.check_history_deals([dict(ok, kind="balance", symbol="", side="")]), [])   # nạp/rút không cần mã/chiều

    def test_signature_contract_covers_the_new_calls(self):
        class Good:
            def account_state(self): pass
            def position_stats(self): pass
            def account_history(self, since, until=None): pass

        class Bad:
            def account_state(self, x): pass
            def position_stats(self, x): pass
            def account_history(self, since): pass                                                         # vỏ gọi (since, until)
        got = contract.check_class(Good, {k: v for k, v in contract.BROKER_CALLS.items() if k in ("account_state", "position_stats", "account_history")})
        self.assertEqual(got, [])
        got = contract.check_class(Bad, {k: v for k, v in contract.BROKER_CALLS.items() if k in ("account_state", "position_stats", "account_history")})
        self.assertEqual(len(got), 3, got)


class TestSelfcheckNumbers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fake_mt import FakeMetaApi, MtCore
        cls.core = MtCore()
        cls.api = FakeMetaApi(cls.core)

    @classmethod
    def tearDownClass(cls):
        cls.api.close()

    def setUp(self):
        from pyea.bridges import MetaApiBackend, MtBroker, MtFeed
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.api.deals_as_dict = True
        be = MetaApiBackend(self.api.TOKEN, self.api.ACC, client_url=self.api.base, data_url=self.api.base)
        self.feed, self.broker = MtFeed(be), MtBroker(be)

    def run_check(self, trade=False):
        ratelimit.reset_all()
        rows, _, _ = selfcheck.run({"exchange": "metaapi"}, trade=trade, symbol="EURUSD", tfs=("1m",), poll=4.0, feed=self.feed, broker=self.broker, deep=False)
        return {r["name"]: r for r in rows}

    def test_readonly_run_reports_the_three_exchange_number_sources(self):
        r = self.run_check()
        for name in ("Broker: account_state() (số của sàn)", "Broker: position_stats() (lãi/lỗ vị thế)", "Broker: account_history() (lịch sử sàn)"):
            self.assertIn(name, r)
            self.assertNotEqual(r[name]["status"], selfcheck.FAIL, r[name])
        self.assertIn("Số dư 10000", r["Broker: account_state() (số của sàn)"]["detail"])
        self.assertEqual(r["Broker: position_stats() (lãi/lỗ vị thế)"]["status"], selfcheck.SKIP)           # chưa có vị thế
        self.assertIn("Lợi nhuận", r["Broker: account_history() (lịch sử sàn)"]["detail"])
        self.assertIn("Tiền nạp 1 000.00", r["Broker: account_history() (lịch sử sàn)"]["detail"])

    def test_trade_cycle_checks_the_new_position_by_ticket_and_the_deals_it_produced(self):
        r = self.run_check(trade=True)
        st = r["Broker: position_stats() thấy vị thế vừa mở"]
        self.assertEqual(st["status"], selfcheck.OK, st)
        self.assertIn("profit=", st["detail"])
        ah = r["Broker: account_history() thấy lệnh vừa chạy"]
        self.assertEqual(ah["status"], selfcheck.OK, ah)
        self.assertIn("IN", ah["detail"])
        self.assertIn("OUT", ah["detail"])
        self.assertEqual([x for x in r.values() if x["status"] == selfcheck.FAIL], [])

    def test_mapping_step_flags_unmatched_core_fields_with_candidates_and_an_override_clears_it(self):
        from pyea import fieldmap
        fieldmap.configure(""); fieldmap.forget()
        try:
            self.broker.account_state = lambda: {"balance": 500.0, "mystery_equity": 480.0, "im": 20.0}
            r = self.run_check()
            row = r["Ánh xạ trường"]
            self.assertEqual(row["status"], selfcheck.WARN, row)
            self.assertIn("mystery_equity", row["detail"])                                   # ứng viên để ghi đè
            self.assertIn("Ánh xạ trường tuỳ chỉnh", row["detail"])                          # nói rõ chữa ở đâu (không phải sửa mã)
            fieldmap.configure({"field_overrides": {"metaapi": {"account": {"equity": "mystery_equity", "margin": "im"}}}})
            fieldmap.forget()
            r = self.run_check()
            self.assertEqual(r["Ánh xạ trường"]["status"], selfcheck.OK, r["Ánh xạ trường"])
            self.assertIn("equity←mystery_equity", r["Ánh xạ trường"]["detail"])
        finally:
            fieldmap.configure(""); fieldmap.forget()

    def test_capabilities_line_lists_the_new_calls(self):
        r = self.run_check()
        d = r["Khai báo khả năng broker"]["detail"]
        for n in ("account_state", "position_stats", "account_history"):
            self.assertIn(n, d)

    def test_position_missing_from_exchange_stats_is_a_warning_not_a_pass(self):
        self.broker.position_stats = lambda: {"999999": {"profit": 1.0}}                  # sàn báo số của vị thế KHÁC, không phải ticket vừa mở
        r = self.run_check(trade=True)
        row = r["Broker: position_stats() thấy vị thế vừa mở"]
        self.assertEqual(row["status"], selfcheck.WARN, row)
        self.assertIn("số tự tính của app", row["detail"])

    def test_missing_deals_of_the_cycle_is_a_warning_not_a_pass(self):
        orig = self.broker.account_history
        self.broker.account_history = lambda since, until=None: [d for d in orig(since, until) if d["entry"] != "OUT"]     # lịch sử thiếu deal ĐÓNG
        r = self.run_check(trade=True)
        row = r["Broker: account_history() thấy lệnh vừa chạy"]
        self.assertEqual(row["status"], selfcheck.WARN, row)
        self.assertIn("kỳ vọng ≥2", row["detail"])

    def test_broken_shapes_are_reported_as_failures_not_swallowed(self):
        b = self.broker
        b.account_state = lambda: {"foo": 1}
        b.position_stats = lambda: {"7": {"profit": "x"}}
        b.account_history = lambda since, until=None: [{"id": 1}]
        r = self.run_check()
        for name in ("Broker: account_state() (số của sàn)", "Broker: position_stats() (lãi/lỗ vị thế)", "Broker: account_history() (lịch sử sàn)"):
            self.assertEqual(r[name]["status"], selfcheck.FAIL, name)

    def test_exchange_that_does_not_report_fields_gets_a_warning_listing_them(self):
        self.broker.account_state = lambda: {"balance": 500.0, "equity": 500.0}
        r = self.run_check()
        row = r["Broker: account_state() (số của sàn)"]
        self.assertEqual(row["status"], selfcheck.WARN)
        self.assertIn("free_margin", row["detail"])
        self.assertIn("«-»", row["detail"])

    def test_adapter_without_these_calls_is_skipped_with_the_reason(self):
        def absent(self):
            raise AttributeError("adapter tối thiểu: không có hàm này (vd OANDA hiện tại)")
        Minimal = type("Minimal", (type(self.broker),), {n: property(absent) for n in ("account_state", "position_stats", "account_history")})
        self.broker.__class__ = Minimal
        ratelimit.reset_all()
        rows, _, _ = selfcheck.run({"exchange": "metaapi"}, trade=True, symbol="EURUSD", tfs=("1m",), poll=4.0, feed=self.feed, broker=self.broker, deep=False)
        r = {x["name"]: x for x in rows}
        for name in ("Broker: account_state() (số của sàn)", "Broker: position_stats() (lãi/lỗ vị thế)", "Broker: account_history() (lịch sử sàn)"):
            self.assertEqual(r[name]["status"], selfcheck.SKIP, name)
        self.assertNotIn("Broker: position_stats() thấy vị thế vừa mở", r)
        self.assertEqual([x for x in rows if x["status"] == selfcheck.FAIL], [])


if __name__ == "__main__":
    unittest.main()
