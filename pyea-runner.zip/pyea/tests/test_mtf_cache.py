"""Đa khung: nến khung khác THẬT cho backtest (`# @mtf:`), không nhìn trước; ghi cache khi nến đóng; màn «Khung dữ liệu bot dùng»."""
import os
import random
import sys
import tempfile
import threading
import time
import unittest
from collections import deque

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402
from pyea.backtest import run_backtest                   # noqa: E402
from pyea.sdk import Candle                              # noqa: E402

ST = {"initial_balance": 10000, "leverage": 100, "spread_pct": 0.0, "commission_pct": 0.0, "max_loss_pct": 0}
T0 = 1_700_000_000 - 1_700_000_000 % 86400               # 00:00 UTC


def series(step, n, t0=T0, seed=1, base=100.0):
    random.seed(seed)
    p, out = base, []
    for i in range(n):
        o = p
        p *= 1 + random.gauss(0, 0.002)
        out.append(Candle(t0 + i * step, o, max(o, p) * 1.0005, min(o, p) * 0.9995, p, 1.0))
    return out


def bot_file(body, header=""):
    d = tempfile.mkdtemp()
    path = os.path.join(d, "mtfbot.py")
    with open(path, "w") as f:
        f.write(header + "\nfrom pyea import BaseBot\nclass B(BaseBot):\n    name = 'mtf'\n    def on_bar(self, c):\n" + "".join("        " + ln + "\n" for ln in body.splitlines()))
    return path


class TestRealHtf(unittest.TestCase):
    def run_bt(self, body, htf, base=None, warm=100, header=""):
        base = base or series(300, 1500)
        return run_backtest(bot_file(body, header), {}, ST, "X", "5m", base, warm, "open", htf=htf), base

    def test_real_candles_no_lookahead(self):
        h1 = series(3600, 200, seed=7)
        res, base = self.run_bt('h = self.api.candles(3, timeframe="1h")\nself.api.log("H|%d|%d|%d" % (h[-1].time, len(h), c.time))', {"1h": h1})
        self.assertTrue(res.ok, res.error)
        rows = [l[l.index("H|"):].split("|") for l in res.logs if "H|" in l]
        self.assertTrue(rows)
        for _h, last, n, now in rows:
            self.assertLessEqual(int(last) + 3600, int(now) + 300)      # nến 1h cuối đã ĐÓNG (tối đa tới hết nến 5m hiện tại)
            self.assertEqual(int(n), 3)
        self.assertEqual(res.mtf["1h"]["source"], "real")

    def test_real_uses_provided_ohlc_not_resample(self):
        h1 = series(3600, 200, seed=7)
        res, _ = self.run_bt('h = self.api.candles(1, timeframe="1h")\nself.api.log("C|%.6f|%d" % (h[-1].close, h[-1].time))', {"1h": h1})
        by_t = {c.time: c.close for c in h1}
        got = [l for l in res.logs if "C|" in l]
        self.assertTrue(got)
        for l in got:
            _c, close, t = l[l.index("C|"):].split("|")
            self.assertAlmostEqual(float(close), by_t[int(t)], places=5)

    def test_daily_depth_beyond_warmup(self):
        d1 = series(86400, 60, t0=T0 - 40 * 86400, seed=3)             # 40 ngày TRƯỚC đoạn test
        res, _ = self.run_bt('d = self.api.candles(50, timeframe="1d")\nself.api.log("D|%d" % len(d))', {"1d": d1}, base=series(300, 800, t0=T0 + 86400))
        ns = [int(l.split("D|")[1]) for l in res.logs if "D|" in l]
        self.assertTrue(ns)
        self.assertGreaterEqual(min(ns), 40)                          # warm-up 100 nến 5m chưa tới nửa ngày nhưng vẫn có >=40 nến ngày thật

    def test_smaller_tf_allowed_when_real(self):
        base = series(900, 400)
        m5 = series(300, 1200, seed=2)
        res = run_backtest(bot_file('m = self.api.candles(3, timeframe="5m")\nself.api.log("M|%d|%d" % (m[-1].time, c.time))'), {}, ST, "X", "15m", base, 50, "open", htf={"5m": m5})
        self.assertTrue(res.ok, res.error)
        for l in res.logs:
            if "M|" in l:
                _m, last, now = l[l.index("M|"):].split("|")
                self.assertLessEqual(int(last) + 300, int(now) + 900)

    def test_include_current_only_from_past(self):
        h1 = series(3600, 200, seed=7)
        res, _ = self.run_bt('h = self.api.candles(1, include_current=True, timeframe="1h")\nself.api.log("P|%.6f|%.6f|%d" % (h[-1].high, h[-1].close, c.time))', {"1h": h1})
        self.assertTrue(res.ok, res.error)
        # nến đang hình thành dựng từ nến 5m ĐÃ xảy ra: close của nó = close nến 5m hiện tại hoặc liền trước, KHÔNG phải close cả giờ thật
        self.assertTrue([l for l in res.logs if "P|" in l])

    def test_resample_fallback_and_partial_first_dropped(self):
        base = series(300, 1500, t0=T0 + 3 * 300)                       # bắt đầu lệch giữa giờ
        res, _ = self.run_bt('h = self.api.candles(200, timeframe="1h")\nself.api.log("R|%d" % h[0].time)', None, base=base)
        self.assertTrue(res.ok, res.error)
        self.assertEqual(res.mtf["1h"]["source"], "resampled")
        for l in res.logs:
            if "R|" in l:
                self.assertGreaterEqual(int(l.split("R|")[1]), base[0].time)      # nến 1h đầu (thiếu 3 nến 5m) đã bị bỏ
        for l in res.logs:
            if "R|" in l:
                self.assertEqual(int(l.split("R|")[1]) % 3600, 0)

    def test_too_small_tf_error_mentions_mtf(self):
        res, _ = self.run_bt('self.api.candles(3, timeframe="1m")', None)
        self.assertFalse(res.ok)
        self.assertIn("@mtf", res.error + " ".join(res.logs))


class TestPortfolioHtf(unittest.TestCase):
    def test_each_bot_sees_own_symbol(self):
        from pyea.backtest import run_portfolio
        body = 'h = self.api.candles(1, timeframe="1h")\nself.api.log("Q|%s|%.6f" % (self.api.symbol, h[-1].close))'
        a_h, b_h = series(3600, 120, seed=11, base=100.0), series(3600, 120, seed=12, base=5000.0)
        entries = [{"bot_path": bot_file(body), "params": {}, "symbol": "AAA", "tf": "5m", "candles": series(300, 900, seed=1), "htf": {"1h": a_h}},
                   {"bot_path": bot_file(body), "params": {}, "symbol": "BBB", "tf": "5m", "candles": series(300, 900, seed=2, base=5000.0), "htf": {"1h": b_h}}]
        res = run_portfolio(entries, dict(ST, exchange="simulated"), 100, "open")
        self.assertTrue(res.ok, res.error)
        got = {}
        for l in res.logs:
            if "Q|" in l:
                _q, sym, close = l[l.index("Q|"):].split("|")
                got.setdefault(sym, set()).add(round(float(close), 4))
        self.assertTrue(got.get("AAA") and got.get("BBB"))
        self.assertTrue(all(c < 1000 for c in got["AAA"]))             # AAA ~100, không lẫn nến của BBB ~5000
        self.assertTrue(all(c > 1000 for c in got["BBB"]))


class TestAutoDetect(unittest.TestCase):
    def test_detect(self):
        from pyea.loader import detect_mtf
        self.assertEqual(detect_mtf('x.candles(5, timeframe="4h"); y.closes(3, timeframe = \'1d\'); timeframe=tf'), ["1d", "4h"])
        self.assertEqual(detect_mtf(""), [])

    def test_inspect_auto_excludes_declared(self):
        from pyea.loader import inspect_bot
        p = bot_file('self.api.candles(3, timeframe="1h")\nself.api.candles(3, timeframe="1d")', header="# @mtf: 1h")
        info = inspect_bot(p)
        self.assertEqual(info.mtf, ["1h"])
        self.assertEqual(info.mtf_auto, ["1d"])

    def test_dynamic_tf_reported_resampled(self):
        base = series(300, 1500)
        res = run_backtest(bot_file('t = "1" + "h"\nself.api.candles(3, timeframe=t)'), {}, ST, "X", "5m", base, 100, "open")
        self.assertEqual(res.mtf["1h"]["source"], "resampled")          # UI thấy và tự nạp nến thật rồi chạy lại

    def test_ui_loads_auto_and_extra(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        got = []
        bt._candles = lambda vals, st, sym, tf, n, end, progress=None: (got.append(tf), series(3600, 40))[1]
        p = bot_file('self.api.candles(3, timeframe="1d")')
        htf, _n = bt._load_htf(p, {"symbol": "x", "timeframe": "5m"}, {}, series(300, 400), 50, extra=["4h"])
        self.assertEqual(sorted(got), ["1d", "4h"])


class TestUtcGuard(unittest.TestCase):
    class F:
        def __init__(self, misalign):
            self.mis, self.calls = misalign, []

        def history(self, symbol, tf, n, end=None):
            from pyea.feeds import utc_guard
            return utc_guard(self, lambda: self.native(symbol, tf, n, end), symbol, tf, n, end)

        def native(self, symbol, tf, n, end=None):
            self.calls.append(tf)
            step = {"1h": 3600, "1d": 86400}[tf]
            off = 22 * 3600 if (tf == "1d" and self.mis) else 0                 # ngày theo giờ máy chủ (mở 22:00 UTC)
            last = (end if end is not None else T0 + 40 * 86400)
            last = last - last % step - off if off else last - last % step
            return [Candle(last - (n - 1 - i) * step, 1.0, 2.0, 0.5, 1.5, 1.0) for i in range(n)]

        max_chunk = 1000

    def test_misaligned_daily_rebuilt_from_1h(self):
        f = self.F(True)
        out = f.history("X", "1d", 5)
        self.assertTrue(f._utc_bad)
        self.assertTrue(out and all(c.time % 86400 == 0 for c in out))
        n_native = f.calls.count("1d")
        f.history("X", "1d", 5)
        self.assertEqual(f.calls.count("1d"), n_native)                  # lần sau không thử khung gốc nữa

    def test_aligned_untouched(self):
        f = self.F(False)
        out = f.history("X", "1d", 5)
        self.assertFalse(getattr(f, "_utc_bad", False))
        self.assertEqual(len(out), 5)
        self.assertEqual(set(f.calls), {"1d"})

    def test_intraday_never_touched(self):
        f = self.F(True)
        f.history("X", "1h", 5)
        self.assertEqual(f.calls, ["1h"])

    def test_feeds_wrapped(self):
        from pyea.bridges import MtFeed
        from pyea.ccxt_adapter import CcxtFeed
        from pyea.exness import ExnFeed
        for cls in (MtFeed, ExnFeed, CcxtFeed):
            self.assertTrue(hasattr(cls, "_native_history"), cls)


class TestManifest(unittest.TestCase):
    def test_parse(self):
        from pyea.loader import parse_manifest
        self.assertEqual(parse_manifest("# @mtf: 1h, 1d\nx=1")["mtf"], ["1h", "1d"])
        self.assertEqual(parse_manifest("x=1")["mtf"], [])

    def test_inspect_bot(self):
        from pyea.loader import inspect_bot
        p = bot_file("pass", header="# @mtf: 4h, 1d, 7x")
        info = inspect_bot(p)
        self.assertTrue(info.ok, info.error)
        self.assertEqual(info.mtf, ["4h", "1d"])
        self.assertTrue(any("7x" in w for w in info.warnings))


class FakeCache:
    def __init__(self):
        self.saved = []

    def save(self, ex, sym, tf, closed):
        self.saved.append((ex, sym, tf, len(closed)))
        return True


class TestFlushCache(unittest.TestCase):
    def sess(self, exchange="binance", sync=False):
        from pyea.engine import TradingSession
        s = TradingSession.__new__(TradingSession)
        s.sync, s.cache, s.settings = sync, FakeCache(), {"exchange": exchange}
        s.lock = threading.RLock()
        s._cache_dirty, s._cache_last = set(), {}
        b5, b1h = type("B", (), {})(), type("B", (), {})()
        b5.closed, b1h.closed = deque([Candle(0, 1, 1, 1, 1, 1)] * 3), deque([Candle(0, 1, 1, 1, 1, 1)] * 5)
        s.builders = {("X", "5m"): b5, ("X", "1h"): b1h}
        return s

    def test_htf_written_immediately_small_tf_throttled(self):
        s = self.sess()
        s._cache_dirty |= {("X", "5m"), ("X", "1h")}
        self.assertEqual(s.flush_cache(), 2)
        self.assertEqual(sorted(x[2] for x in s.cache.saved), ["1h", "5m"])
        s._cache_dirty.add(("X", "5m"))
        self.assertEqual(s.flush_cache(), 0)                           # < 120 s kể từ lần ghi trước
        self.assertIn(("X", "5m"), s._cache_dirty)                      # vẫn chờ
        self.assertEqual(s.flush_cache(force=True), 1)                  # dừng phiên: ghi hết
        self.assertFalse(s._cache_dirty)

    def test_not_for_sim_or_backtest_or_clean(self):
        for kw in ({"exchange": "simulated"}, {"sync": True}):
            s = self.sess(**kw)
            s._cache_dirty.add(("X", "1h"))
            self.assertEqual(s.flush_cache(force=True), 0)
            self.assertEqual(s.cache.saved, [])
        s = self.sess()
        self.assertEqual(s.flush_cache(), 0)                           # không có gì bẩn

    def test_missing_builder_cleared(self):
        s = self.sess()
        s._cache_dirty.add(("X", "4h"))
        self.assertEqual(s.flush_cache(), 0)
        self.assertFalse(s._cache_dirty)

    def test_marked_dirty_on_candle_close(self):
        import test_ui_smoke as S                                       # noqa: F401 - cài giao diện giả
        from pyea.engine import TradingSession
        from pyea.sdk import Tick
        st = dict(S.make_app().settings, mode="paper", exchange="simulated", state_file=None)
        s = TradingSession(st, sync=True, feed=None)
        self.assertEqual(s._cache_dirty, set())


class TestText(unittest.TestCase):
    def test_text(self):
        from pyea.mtf import mtf_lines, mtf_text
        m = {"1h": {"source": "real", "n": 300, "first": T0, "last": T0 + 3600}, "1d": {"source": "resampled", "n": 4, "first": T0, "last": T0}}
        ls = mtf_lines(m)
        self.assertEqual(len(ls), 2)
        self.assertTrue(any("nến thật" in x for x in ls))
        t = mtf_text(m, ["ghi chú"])
        self.assertIn("# @mtf: 1d", t)
        self.assertIn("ghi chú", t)
        self.assertEqual(mtf_text({}, None), "")


class TestUi(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_load_htf_and_dialog(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        p = bot_file("pass", header="# @mtf: 1h, 1d")
        calls = []

        def fake(vals, st, sym, tf, n, end, progress=None):
            calls.append((tf, n, end))
            if tf == "1d":
                raise ValueError("mạng lỗi")
            return series(3600, 50)
        bt._candles = fake
        base = series(300, 500)
        htf, notes = bt._load_htf(p, {"symbol": "x", "timeframe": "5m"}, {}, base, 100)
        self.assertEqual(list(htf), ["1h"])
        self.assertTrue(any("1d" in n and "mạng lỗi" in n for n in notes))
        self.assertGreaterEqual(calls[0][1], bt.HTF_DEPTH)              # nạp đủ độ sâu trước đoạn test
        n0 = len(kivy_stub.OPEN_POPUPS)
        app.mtf_dialog(mtf={"1h": {"source": "real", "n": 3, "first": 0, "last": 0}}, path=p, title="t")
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)

    def test_no_declared_means_no_load(self):
        import test_ui_smoke as S
        app = S.make_app()
        bt = app.bt_tab
        bt._candles = lambda *a, **k: self.fail("không được tải khi bot không khai báo")
        self.assertEqual(bt._load_htf(bot_file("pass"), {"symbol": "x", "timeframe": "5m"}, {}, series(300, 300), 50), ({}, []))


if __name__ == "__main__":
    unittest.main()
