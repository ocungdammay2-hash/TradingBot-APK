"""Giao diện của các tính năng vỏ (Kivy GIẢ - không kiểm tra hiển thị thật) + lệnh mới chạy qua dịch vụ nền (IPC)."""
import os, sys, tempfile, time, unittest, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub
kivy_stub.install()
import test_ui_smoke as T                                           # noqa: E402
from pyea.shell import AlertBook, load_trades_csv                   # noqa: E402


class TestShellUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def drive(self, app, cond, timeout=15.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.1)
        return False

    def connected_app(self):
        app = T.make_app()
        app.start_session()
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and "BTCUSD" in app.last_snap["watch"], 20))
        return app

    def test_safety_bar_kill_switch_and_resume(self):
        app = self.connected_app()
        bar = app.trade_tab.bar
        # giá mô phỏng của từng mã về hơi lệch nhau lúc mới kết nối (máy bận -> chập chờn): chờ trạng thái ổn định rồi mới khẳng định
        self.drive(app, lambda: "Kết nối giá OK" in bar.l_health.text, 15)
        self.assertIn("Kết nối giá OK", bar.l_health.text)
        self.assertIn("Mức ký quỹ", bar.l_margin.text)
        self.assertTrue(bar.resume.disabled)
        app.ctl.place_order("BTCUSD", "buy", 0.01)
        app.ctl.place_pending("BTCUSD", "buy", "limit", 0.01, app.last_snap["watch"]["BTCUSD"]["bid"] * 0.5)
        self.assertTrue(self.drive(app, lambda: app.last_snap["positions"] and app.last_snap["pending"]))
        app.kill_switch_dialog()
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "KÍCH HOẠT")
        self.assertTrue(self.drive(app, lambda: app.last_snap.get("halted") and not app.last_snap["positions"] and not app.last_snap["pending"], 15))
        self.assertIn("KILL SWITCH", bar.l_flag.text)
        self.assertFalse(bar.resume.disabled)
        status, res = app.ctl.place_order("BTCUSD", "buy", 0.01)                   # lệnh mới bị chặn
        self.assertEqual((status, res.retcode), ("fail", "TRADE_DISABLED"))
        app.resume_trading_action()
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Mở lại")
        self.assertTrue(self.drive(app, lambda: not app.last_snap.get("halted"), 10))
        self.assertEqual(app.ctl.place_order("BTCUSD", "buy", 0.01)[0], "ok")

    def test_pending_rows_edit_cancel_and_order_dialog_types(self):
        app = self.connected_app()
        bid = app.last_snap["watch"]["BTCUSD"]["bid"]
        status, res = app.ctl.place_pending("BTCUSD", "buy", "limit", 0.01, bid * 0.9, 0.0, bid * 0.8, 0.0, "t")
        self.assertEqual(status, "ok")
        oid = res.order.id
        self.assertTrue(self.drive(app, lambda: oid in app.trade_tab._prows))
        self.assertIn("limit", app.trade_tab._prows[oid][0].text)
        # sửa giá
        app.open_pending_dialog(oid)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[0].text = "%.4f" % (bid * 0.85)
        T.press(dlg.content, "Lưu")
        self.assertAlmostEqual(app.ctl.session.account.pending[oid].price, round(bid * 0.85, 4), places=2)
        # nhập sai phía -> báo lỗi, hộp vẫn mở
        app.open_pending_dialog(oid)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        T.inputs_of(dlg.content)[0].text = "%.4f" % (bid * 1.5)
        T.press(dlg.content, "Lưu")
        self.assertIn("Buy limit", T.texts(dlg.content))
        # hộp đặt lệnh có đủ loại và nhập đủ giá
        app.open_order_dialog("BTCUSD")
        blob = T.texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("MUA", blob)
        # huỷ
        app.cancel_pending(oid)
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Huỷ lệnh")
        self.assertTrue(self.drive(app, lambda: oid not in app.trade_tab._prows))

    def test_order_dialog_places_limit_with_expiry_via_dialog(self):
        app = self.connected_app()
        bid = app.last_snap["watch"]["BTCUSD"]["bid"]
        app.open_order_dialog("BTCUSD")
        dlg = kivy_stub.OPEN_POPUPS[-1]
        spinners = [x for x in T.walk(dlg.content) if getattr(x, "values", None)]
        sp_type = next(x for x in spinners if "Thị trường" in x.values)
        sp_type.text = "Limit (chờ giá tốt hơn)"
        for cb in sp_type._binds.get("text", []):                                  # Kivy thật tự gọi khi đổi text
            cb(sp_type, sp_type.text)
        sp_exp = next(x for x in T.walk(dlg.content) if getattr(x, "values", None) and "1 giờ" in x.values)
        sp_exp.text = "1 giờ"
        ins = T.inputs_of(dlg.content)                                              # [khối lượng, giá đặt, SL, TP]
        ins[0].text = "0.02"
        ins[1].text = "%.4f" % (bid * 0.9)
        T.press(dlg.content, "MUA")
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")
        o = list(app.ctl.session.account.pending.values())[-1]
        self.assertEqual((o.kind, o.side, o.volume), ("limit", "buy", 0.02))
        self.assertGreater(o.expiration, o.created + 3000)                          # 1 giờ tính theo giờ thị trường
        # thiếu giá đặt -> báo lỗi tại chỗ, không đặt
        n = len(app.ctl.session.account.pending)
        app.open_order_dialog("BTCUSD")
        dlg = kivy_stub.OPEN_POPUPS[-1]
        sp_type = next(x for x in T.walk(dlg.content) if getattr(x, "values", None) and "Stop-limit" in x.values)
        sp_type.text = "Stop-limit"
        for cb in sp_type._binds.get("text", []):
            cb(sp_type, sp_type.text)
        T.press(dlg.content, "MUA")
        self.assertIn("giá đặt", T.texts(dlg.content))
        self.assertEqual(len(app.ctl.session.account.pending), n)

    def test_partial_close_from_modify_dialog(self):
        app = self.connected_app()
        status, res = app.ctl.place_order("BTCUSD", "buy", 0.04)
        pid = res.id
        self.assertTrue(self.drive(app, lambda: any(p.id == pid for p in app.last_snap["positions"])))
        app.open_modify_dialog(pid)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        T.press(dlg.content, "50%")
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Đóng")
        self.assertAlmostEqual(app.ctl.session.account.positions[pid].volume, 0.02)

    def test_alerts_dialog_connected_and_idle(self):
        app = T.make_app()
        # chưa kết nối: thêm cảnh báo giá thẳng vào file
        app.open_alerts_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = T.inputs_of(dlg.content)
        ins[0].text = "99999"
        ins[1].text = "phá đỉnh"
        T.press(dlg.content, "Thêm cảnh báo")
        al = AlertBook(app.store.alerts_path).list()
        self.assertEqual((al[0].symbol, al[0].kind, al[0].value, al[0].note), ("BTCUSD", "above", 99999.0, "phá đỉnh"))
        kivy_stub.OPEN_POPUPS.clear()
        # đang kết nối: phiên nạp cảnh báo đã lưu, thêm/xoá qua phiên
        app.start_session()
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready"), 20))
        self.assertEqual(len(app.ctl.session.alerts.list()), 1)
        app.open_alerts_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("BTCUSD ≥ 99999", T.texts(dlg.content))
        ins = T.inputs_of(dlg.content)
        ins[0].text = "-5"
        T.press(dlg.content, "Thêm cảnh báo")
        self.assertIn("phải > 0", T.texts(dlg.content))                              # nhập sai được báo ngay
        self.assertEqual(len(app.ctl.session.alerts.list()), 1)

    def test_history_dialog_stats_and_exports(self):
        app = self.connected_app()
        for i in range(3):
            status, res = app.ctl.place_order("BTCUSD", "buy", 0.01)
            self.assertEqual(status, "ok")
            self.assertTrue(app.ctl.close_position(res.id))
        self.assertTrue(len(load_trades_csv(app.store.trades_csv)) >= 3)
        app.open_history_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        blob = T.texts(dlg.content)
        self.assertIn("Tổng lệnh: 3", blob)
        self.assertIn("THEO TỪNG BOT", blob)
        T.press(dlg.content, "Lưu CSV")
        files = [f for f in os.listdir(app.store.exports_dir) if f.startswith("pyea-statement")]
        self.assertEqual(len(files), 1)
        T.press(dlg.content, "Sao chép CSV")

    def test_backup_restore_and_diag_from_ui(self):
        app = T.make_app()
        app.store.save_settings(dict(app.settings, api_key="SECRET-KEY-1"))
        app.settings = app.store.load_settings()
        app.backup_dialog()
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Sao lưu (không kèm API key)")
        z = [f for f in os.listdir(app.store.exports_dir) if f.startswith("pyea-backup")]
        self.assertEqual(len(z), 1)
        zp = os.path.join(app.store.exports_dir, z[0])
        self.assertNotIn(b"SECRET-KEY-1", zipfile.ZipFile(zp).read("settings.json"))
        kivy_stub.OPEN_POPUPS.clear()
        app.store.install_bot_text("them.py", "from pyea import BaseBot\nclass B(BaseBot): pass\n")
        os.remove(os.path.join(app.store.bots_dir, "them.py"))
        app.restore_dialog()
        T.press(kivy_stub.OPEN_POPUPS[-1].content, z[0])
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Khôi phục")
        self.assertEqual(app.settings["api_key"], "SECRET-KEY-1")                    # khoá hiện có được giữ
        app.diag_bundle_dialog()
        d = [f for f in os.listdir(app.store.exports_dir) if f.startswith("pyea-diag")]
        self.assertEqual(len(d), 1)
        self.assertNotIn(b"SECRET-KEY-1", b"".join(zipfile.ZipFile(os.path.join(app.store.exports_dir, d[0])).read(n)
                                                   for n in zipfile.ZipFile(os.path.join(app.store.exports_dir, d[0])).namelist()))

    def test_reset_paper_and_restore_blocked_while_connected(self):
        app = self.connected_app()
        app.ctl.place_order("BTCUSD", "buy", 0.01)
        self.assertTrue(self.drive(app, lambda: app.last_snap["positions"]))
        app.restore_dialog()
        self.assertFalse([p for p in kivy_stub.OPEN_POPUPS if "Khôi phục từ sao lưu" in str(getattr(p, "title", ""))])      # bị chặn khi đang chạy
        kivy_stub.OPEN_POPUPS.clear()
        app.reset_paper_dialog()
        T.press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lại")
        self.assertTrue(self.drive(app, lambda: not app.last_snap["positions"] and abs(app.last_snap["balance"] - 100000.0) < 1e-6, 10))

    def test_log_filter_and_workspace_memory(self):
        app = T.make_app()
        lt = app.log_tab
        lt.append([(1, 1000.0, "INFO", "bot ma_cross mở lệnh"), (2, 1001.0, "ERROR", "lỗi bot rsi_bot"), (3, 1002.0, "WARN", "giá cũ")])
        self.assertEqual(len(lt.lines), 3)
        lt.sp_level.text = "Chỉ lỗi"
        lt.refilter()
        self.assertEqual(len(lt.lines), 1)
        lt.sp_level.text = "Tất cả"
        lt.f_text.text = "ma_cross"
        lt.refilter()
        self.assertEqual([l for l in lt.lines if "ma_cross" in l].__len__(), 1)
        self.assertEqual(len(lt.lines), 1)
        # khu vực làm việc: nhớ tab + mã/khung biểu đồ
        app.set_chart("EURUSD", "3h")
        ws = app.store.load_prefs()["workspace"]
        self.assertEqual((ws["chart_sym"], ws["chart_tf"]), ("EURUSD", "3h"))

    def test_alerts_dialog_indicator_kinds(self):
        app = T.make_app()
        app.open_alerts_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        sp_kind = next(x for x in T.walk(dlg.content) if getattr(x, "values", None) and "RSI cắt LÊN mức (nến đóng)" in x.values)
        ins = T.inputs_of(dlg.content)                                  # thứ tự: giá trị, ghi chú, chu kỳ RSI/EMA nhanh, EMA chậm
        sp_kind.text = "RSI cắt LÊN mức (nến đóng)"
        ins[0].text, ins[2].text = "30", "9"
        T.press(dlg.content, "Thêm cảnh báo")
        al = AlertBook(app.store.alerts_path).list()
        self.assertEqual((al[0].kind, al[0].value, al[0].tf, al[0].period), ("rsi_above", 30.0, "15m", 9))
        sp_kind.text = "EMA nhanh cắt LÊN EMA chậm"                    # EMA cắt: không dùng ô «Giá trị»
        ins[0].text, ins[2].text, ins[3].text = "", "12", "26"
        T.press(dlg.content, "Thêm cảnh báo")
        al = AlertBook(app.store.alerts_path).list()
        self.assertEqual((al[1].kind, al[1].period, al[1].period2), ("ma_up", 12, 26))
        ins[2].text, ins[3].text = "30", "10"                           # nhanh >= chậm: báo lỗi tại chỗ, không lưu
        T.press(dlg.content, "Thêm cảnh báo")
        self.assertIn("EMA nhanh phải ngắn hơn", T.texts(dlg.content))
        self.assertEqual(len(AlertBook(app.store.alerts_path).list()), 2)

    def test_log_time_window_filter(self):
        app = T.make_app()
        lt = app.log_tab
        now = time.time()
        lt.append([(1, now - 7200, "INFO", "dòng cũ"), (2, now - 30, "INFO", "dòng mới"), (3, now - 5000, "ERROR", "lỗi cũ")])
        self.assertEqual(len(lt.lines), 3)
        lt.sp_time.text = "1 giờ"
        lt.refilter()
        self.assertEqual(len(lt.lines), 1)
        self.assertIn("dòng mới", lt.lines[0])
        lt.sp_time.text = "6 giờ"
        lt.sp_level.text = "Chỉ lỗi"
        lt.refilter()
        self.assertEqual(len(lt.lines), 1)
        self.assertIn("lỗi cũ", lt.lines[0])                               # lọc mức + thời gian kết hợp
        lt.append([(4, now, "ERROR", "lỗi vừa xảy ra")])                  # dòng mới đến cũng tuân theo bộ lọc hiện hành
        self.assertEqual(len(lt.lines), 2)

    def test_safety_bar_shows_reconcile_state(self):
        app = T.make_app()
        bar = app.trade_tab.bar
        base = {"ready": True, "health": {"state": "connected", "max_age": 1}, "margin_level": None, "free_margin": 1.0, "reserved": 0.0}
        bar.update(dict(base, reconcile={"supported": True, "last": time.time(), "ok": True, "issues": []}))
        self.assertIn("khớp", bar.l_recon.text)
        bar.update(dict(base, reconcile={"supported": True, "last": time.time(), "ok": False,
                                         "issues": ["Sàn có vị thế BTCUSDT 0.5 nhưng sổ app KHÔNG có"]}))
        self.assertIn("LỆCH", bar.l_recon.text)
        self.assertIn("BTCUSDT", bar.l_recon.text)
        bar.update(dict(base, reconcile={"supported": False, "last": 0.0, "ok": None, "issues": []}))
        self.assertEqual(bar.l_recon.text, "")                                       # paper/spot: không hiện gì

    def test_bot_row_shows_metrics_line(self):
        app = self.connected_app()
        self.assertTrue(self.drive(app, lambda: app.attach_tab._att and any(
            ("on_tick" in x[4].text) for x in app.attach_tab._att.values()), 15))


class TestServicePath(unittest.TestCase):
    """Lệnh chờ / Kill switch / cảnh báo / đóng một phần đi qua IPC (dịch vụ nền)."""

    def test_service_commands(self):
        from pyea.ipc import ServiceClient, ServiceHandle, ServiceHost
        from pyea.settings import default_settings
        import threading
        d = tempfile.mkdtemp()
        from pyea.storage import Store
        store = Store(d)
        store.seed_examples()
        host = ServiceHost(d, sleep=0.05, exit_grace=0.5, idle_exit=60)
        client = ServiceClient(d)
        stop_ui = threading.Event()
        threading.Thread(target=lambda: [client.touch_ui() or time.sleep(0.3) for _ in iter(stop_ui.is_set, True)], daemon=True).start()
        s = default_settings()
        s.update(tick_interval=0.2, sim_speed=200.0, history_bars=100, initial_balance=100000.0, max_loss_pct=0.0,
                 watchlist="BTCUSD,EURUSD", ui_refresh=0.3)
        h = ServiceHandle(client, store.events_path)
        t = threading.Thread(target=host.run, daemon=True)
        t.start()
        try:
            h.start({"settings": s, "instances": []})
            self.assertTrue(T.wait(lambda: (h.snapshot() or {}).get("ready") and "BTCUSD" in h.snapshot()["watch"], 20))
            bid = h.snapshot()["watch"]["BTCUSD"]["bid"]
            h.place_order("BTCUSD", "buy", 0.04)
            h.place_pending("BTCUSD", "buy", "limit", 0.01, bid * 0.5)
            h.alert_add("BTCUSD", "above", bid * 10, "xa")
            self.assertTrue(T.wait(lambda: h.snapshot()["positions"] and h.snapshot()["pending"] and h.snapshot()["alerts"], 10))
            pid = h.snapshot()["positions"][0].id
            oid = h.snapshot()["pending"][0].id
            h.close_position(pid, 0.01)                                              # đóng một phần
            self.assertTrue(T.wait(lambda: abs(h.snapshot()["positions"][0].volume - 0.03) < 1e-9, 10))
            h.modify_order(oid, price=bid * 0.4)
            self.assertTrue(T.wait(lambda: abs(h.snapshot()["pending"][0].price - bid * 0.4) < 1e-6, 10))
            h.alert_remove(h.snapshot()["alerts"][0].id)
            self.assertTrue(T.wait(lambda: not h.snapshot()["alerts"], 10))
            h.kill_switch("thử nghiệm")
            self.assertTrue(T.wait(lambda: h.snapshot().get("halted") and not h.snapshot()["positions"] and not h.snapshot()["pending"], 15))
            h.resume_trading()
            self.assertTrue(T.wait(lambda: not h.snapshot().get("halted"), 10))
            h.reset_paper()
            self.assertTrue(T.wait(lambda: abs(h.snapshot()["balance"] - 100000.0) < 1e-6, 10))
        finally:
            stop_ui.set()
            h.stop()
            t.join(timeout=10)


if __name__ == "__main__":
    unittest.main()
