"""Kivy GIẢ (chỉ để chạy logic giao diện trong test, không vẽ gì). Dùng: kivy_stub.install()"""
import sys
import types

OPEN_POPUPS = []
SCHEDULED = []


class _Ctx:
    def __enter__(self): return self
    def __exit__(self, *a): return False


class _Canvas(_Ctx):
    def __init__(self):
        self.before = _Ctx()
        self.children = []

    def clear(self): self.children = []

    def add(self, c): self.children.append(c)


class Stub:
    def __init__(self, *a, **kw):
        self.children, self.parent, self._binds = [], None, {}
        self.canvas = _Canvas()
        self.pos, self.size = (0, 0), (360, 300)
        self.x, self.y, self.width, self.height = 0, 0, 360, 300
        self.text, self.color, self.opacity, self.disabled = "", (1, 1, 1, 1), 1, False
        self.state = "normal"
        for k, v in kw.items():
            setattr(self, k, v)

    def bind(self, **kw):
        for k, v in kw.items():
            self._binds.setdefault(k, []).append(v)

    def setter(self, name):
        return lambda *a: None

    def add_widget(self, w, index=0, *a, **k):
        w.parent = self
        self.children.insert(index, w)

    def remove_widget(self, w):
        if w in self.children:
            self.children.remove(w)
            w.parent = None

    def clear_widgets(self):
        for w in self.children:
            w.parent = None
        self.children = []

    def collide_point(self, x, y): return True
    def dispatch(self, *a, **k): return False
    def grab(self, *a): pass
    def ungrab(self, *a): pass
    def on_touch_down(self, t): return False
    def on_touch_up(self, t): return False


class _Instr(Stub):
    pass


def _mod(name, **attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


class _Popup(Stub):
    def open(self, *a): OPEN_POPUPS.append(self)
    def dismiss(self, *a):
        if self in OPEN_POPUPS:
            OPEN_POPUPS.remove(self)


class _App(Stub):
    title = "app"
    user_data_dir = "."

    def run(self): pass
    def stop(self): self.stopped = True


class _TabbedPanel(Stub):
    def switch_to(self, h, *a): self.current = h


class _Clock:
    class _Ev:
        def cancel(self): pass

    def schedule_interval(self, fn, dt): return self._Ev()

    def schedule_once(self, fn, dt=0):
        SCHEDULED.append(fn)
        return self._Ev()


def install():
    if "kivy" in sys.modules and getattr(sys.modules["kivy"], "_is_stub", False):
        return
    k = _mod("kivy"); k._is_stub = True
    _mod("kivy.app", App=_App)

    class _EM:
        PASS = "pass"
        def add_handler(self, h): pass
    _mod("kivy.base", ExceptionHandler=type("ExceptionHandler", (), {"__init__": lambda self: None}), ExceptionManager=_EM())
    _mod("kivy.clock", Clock=_Clock(), mainthread=lambda f: f)
    _mod("kivy.core")
    _mod("kivy.core.clipboard", Clipboard=types.SimpleNamespace(copy=lambda t: setattr(sys.modules["kivy"], "clip", t),
                                                                  paste=lambda: getattr(sys.modules["kivy"], "clip", "")))

    class _CoreLabel:
        def __init__(self, **kw): self.texture = types.SimpleNamespace(size=(20, 10))
        def refresh(self): pass
    _mod("kivy.core.text", Label=_CoreLabel, LabelBase=types.SimpleNamespace(register=lambda **k: None))
    win = Stub(); win.width = 360; win.clearcolor = None
    _mod("kivy.core.window", Window=win)
    names = ["Color", "Line", "Rectangle", "RoundedRectangle", "Ellipse", "Triangle", "Quad"]
    gm = {n: type(n, (_Instr,), {}) for n in names}
    gm["Canvas"] = _Canvas
    _mod("kivy.graphics", **gm)
    _mod("kivy.metrics", dp=lambda v: float(v), sp=lambda v: float(v))

    def escape_markup(t): return str(t).replace("&", "&amp;").replace("[", "&bl;").replace("]", "&br;")
    _mod("kivy.utils", escape_markup=escape_markup, platform="linux")
    _mod("kivy.uix")
    ui = {"boxlayout": ["BoxLayout"], "button": ["Button"], "gridlayout": ["GridLayout"], "label": ["Label"],
          "scrollview": ["ScrollView"], "spinner": ["Spinner"], "switch": ["Switch"], "textinput": ["TextInput"],
          "togglebutton": ["ToggleButton"], "widget": ["Widget"], "filechooser": ["FileChooserListView"]}
    for mod, classes in ui.items():
        _mod("kivy.uix." + mod, **{c: type(c, (Stub,), {}) for c in classes})
    _mod("kivy.uix.popup", Popup=_Popup)
    _mod("kivy.uix.tabbedpanel", TabbedPanel=_TabbedPanel, TabbedPanelHeader=type("TabbedPanelHeader", (Stub,), {}))
