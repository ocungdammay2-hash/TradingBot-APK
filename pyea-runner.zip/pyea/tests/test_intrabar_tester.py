"""Thứ tự giá trong nến (ohlc_hl / ohlc_lh / ohlc_worst), độ nhạy, và on_tester() làm fitness cho tối ưu hoá."""
import math
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import backtest                                                          # noqa: E402
from pyea.backtest import (FITNESS_KEY, MODES, candle_ticks, intrabar_sensitivity, optimize, run_backtest,       # noqa: E402
                           run_portfolio, walk_forward)
from pyea.loader import inspect_bot                                                # noqa: E402
from pyea.sdk import Candle                                                        # noqa: E402
from pyea.settings import default_settings                                         # noqa: E402

TMP = tempfile.mkdtemp()
T0, STEP = 1_700_000_000, 300


def settings(**over):
    s = default_settings()
    s.update(initial_balance=10000.0, leverage=10.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0, close_on_stop=True)
    s.update(over)
    return s


def flat(i, px=100.0):
    return Candle(T0 + i * STEP, px, px, px, px, 1.0)


def candles_with_trap(n_warm=30):
    """warm-up phẳng, 1 nến phẳng (bot vào lệnh khi nó đóng), rồi 1 nến chứa CẢ SL lẫn TP của lệnh mua 100 (SL 99, TP 101), rồi nến phẳng."""
    cs = [flat(i) for i in range(n_warm + 1)]
    i = n_warm + 1
    cs.append(Candle(T0 + i * STEP, 100.0, 102.0, 98.0, 101.0, 1.0))           # O100 H102 L98 C101: nến tăng, chứa SL 99 và TP 101
    cs += [flat(i + 1 + k, 101.0) for k in range(4)]
    return cs


def write(name, body):
    p = os.path.join(TMP, name)
    open(p, "w", encoding="utf-8").write(body)
    return p


LONG = write("long_trap.py", '''
from pyea import BaseBot
class L(BaseBot):
    def on_init(self):
        self.done = False
    def on_bar(self, c):
        if not self.done:
            self.done = True
            self.api.buy(1.0, sl=99.0, tp=101.0, reason="trap")
''')
SHORT = write("short_trap.py", '''
from pyea import BaseBot
class S(BaseBot):
    def on_init(self):
        self.done = False
    def on_bar(self, c):
        if not self.done:
            self.done = True
            self.api.sell(1.0, sl=101.0, tp=99.0, reason="trap")
''')
BOTH_NEUTRAL = write("neutral.py", '''
from pyea import BaseBot
class N(BaseBot):
    def on_init(self):
        self.done = False
    def on_bar(self, c):
        if not self.done:
            self.done = True
            self.api.buy(1.0, sl=90.0, tp=110.0, reason="xa")
''')


def net(path, mode, **kw):
    r = run_backtest(path, {}, settings(), "BTCUSD", "5m", candles_with_trap(), warmup=30, mode=mode, **kw)
    assert r.ok, r.error
    return r.report["Lợi nhuận ròng"], r


class TestPaths(unittest.TestCase):
    c_up = Candle(0.0, 100.0, 102.0, 98.0, 101.0, 1.0)
    c_dn = Candle(0.0, 100.0, 102.0, 98.0, 99.0, 1.0)

    def prices(self, c, mode, net_=0.0):
        return [p for _, p in candle_ticks(c, 300, mode, net_)]

    def test_fixed_orders(self):
        self.assertEqual(self.prices(self.c_up, "ohlc_hl"), [100, 102, 98, 101])
        self.assertEqual(self.prices(self.c_dn, "ohlc_hl"), [100, 102, 98, 99])
        self.assertEqual(self.prices(self.c_up, "ohlc_lh"), [100, 98, 102, 101])
        self.assertEqual(self.prices(self.c_dn, "ohlc_lh"), [100, 98, 102, 99])

    def test_default_ohlc_unchanged(self):
        self.assertEqual(self.prices(self.c_up, "ohlc"), [100, 98, 102, 101])           # nến tăng: đáy trước
        self.assertEqual(self.prices(self.c_dn, "ohlc"), [100, 102, 98, 99])            # nến giảm: đỉnh trước
        self.assertEqual([p for _, p in candle_ticks(self.c_up, 300, "open")], [100])

    def test_worst_depends_on_book(self):
        self.assertEqual(self.prices(self.c_dn, "ohlc_worst", +1.0), [100, 98, 102, 99])    # đang mua -> đáy trước dù nến giảm
        self.assertEqual(self.prices(self.c_up, "ohlc_worst", -1.0), [100, 102, 98, 101])   # đang bán -> đỉnh trước dù nến tăng
        self.assertEqual(self.prices(self.c_up, "ohlc_worst", 0.0), self.prices(self.c_up, "ohlc"))   # không có vị thế: theo hướng nến

    def test_times_are_monotonic_quarters_of_the_step(self):
        ts = [t for t, _ in candle_ticks(self.c_up, 300, "ohlc_hl")]
        self.assertEqual(ts, [0.0, 75.0, 150.0, 225.0])

    def test_all_modes_have_labels(self):
        for m in ("ohlc", "ohlc_hl", "ohlc_lh", "ohlc_worst", "open"):
            self.assertIn(m, MODES)


class TestTrapOutcome(unittest.TestCase):
    """Quy ước khớp của vỏ (giống chạy thật): thấy tick chạm mức SL/TP thì đóng ở GIÁ TICK đó. Nến mô phỏng chỉ có 4 tick
    nên bước nhảy O→H (100→102) khớp ở 102, O→L khớp ở 98 - vì vậy lãi/lỗ của bẫy là ±2 chứ không phải ±1."""

    def test_long_trade_flips_with_the_assumed_order(self):
        win, r = net(LONG, "ohlc_hl")
        self.assertAlmostEqual(win, 2.0, 6)                                      # đỉnh trước: TP 101 chạm ở tick 102
        self.assertEqual(r.trades[0].reason, "Take Profit")
        loss, r2 = net(LONG, "ohlc_lh")
        self.assertAlmostEqual(loss, -2.0, 6)                                    # đáy trước: SL 99 chạm ở tick 98
        self.assertEqual(r2.trades[0].reason, "Stop Loss")
        self.assertAlmostEqual(net(LONG, "ohlc")[0], -2.0, 6)                    # nến tăng -> mặc định đáy trước
        self.assertAlmostEqual(net(LONG, "ohlc_worst")[0], -2.0, 6)

    def test_worst_is_adverse_for_shorts_too(self):
        self.assertAlmostEqual(net(SHORT, "ohlc_worst")[0], -2.0, 6)             # bán: đỉnh trước -> SL 101 chạm ở tick 102
        self.assertAlmostEqual(net(SHORT, "ohlc_lh")[0], 2.0, 6)                 # đáy trước: TP 99 chạm ở tick 98
        self.assertAlmostEqual(net(SHORT, "ohlc_hl")[0], -2.0, 6)

    def test_worst_is_never_better_than_any_fixed_order(self):
        for bot in (LONG, SHORT):
            worst = net(bot, "ohlc_worst")[0]
            self.assertLessEqual(worst, min(net(bot, "ohlc_hl")[0], net(bot, "ohlc_lh")[0]) + 1e-9)

    def test_report_names_the_simulation_mode(self):
        _, r = net(LONG, "ohlc_worst")
        self.assertEqual(r.report["Mô phỏng tick"], MODES["ohlc_worst"])

    def test_portfolio_supports_worst_order_with_lazy_book_lookup(self):
        entries = [{"bot_path": LONG, "params": {}, "symbol": "BTCUSD", "tf": "5m", "candles": candles_with_trap(), "warmup": 30}]
        r = run_portfolio(entries, settings(), warmup=30, mode="ohlc_worst")
        self.assertTrue(r.ok, r.error)
        self.assertAlmostEqual(r.report["Lợi nhuận ròng"], -2.0, 6)
        r2 = run_portfolio(entries, settings(), warmup=30, mode="ohlc_hl")
        self.assertAlmostEqual(r2.report["Lợi nhuận ròng"], 2.0, 6)
        short = [dict(entries[0], bot_path=SHORT)]                                # nến tăng + đang BÁN: chỉ đường "xấu nhất" mới ra lỗ
        self.assertAlmostEqual(run_portfolio(short, settings(), warmup=30, mode="ohlc_worst").report["Lợi nhuận ròng"], -2.0, 6)
        self.assertAlmostEqual(run_portfolio(short, settings(), warmup=30, mode="ohlc").report["Lợi nhuận ròng"], 2.0, 6)


class TestSensitivity(unittest.TestCase):
    def run_sens(self, bot):
        return intrabar_sensitivity(bot, {}, settings(), "BTCUSD", "5m", candles_with_trap(), warmup=30)

    def test_trap_strategy_is_flagged_fragile(self):
        out = self.run_sens(LONG)
        self.assertTrue(out["ok"])
        self.assertEqual(set(out["results"]), {"ohlc_hl", "ohlc_lh", "ohlc_worst"})
        self.assertAlmostEqual(out["results"]["ohlc_hl"]["value"], 2.0, 6)
        self.assertAlmostEqual(out["results"]["ohlc_worst"]["value"], -2.0, 6)
        self.assertTrue(out["fragile"])
        self.assertIn("NHẠY", out["note"])
        self.assertAlmostEqual(out["spread"], 4.0, 6)

    def test_robust_strategy_is_not_flagged(self):
        out = self.run_sens(BOTH_NEUTRAL)
        self.assertFalse(out["fragile"])
        self.assertIn("ổn định", out["note"])

    def test_failing_bot_reports_error_instead_of_raising(self):
        bad = write("bad.py", "this is not python(\n")
        out = self.run_sens(bad)
        self.assertFalse(out["ok"])
        self.assertTrue(out["error"])


TESTER = write("tester.py", '''
from pyea import BaseBot, Input
class T(BaseBot):
    inputs = {"x": Input(3, "x", min=0, max=20)}
    def on_init(self):
        self.done = False
    def on_bar(self, c):
        if not self.done:
            self.done = True
            self.api.buy(1.0, sl=90.0, tp=110.0)
    def on_tester(self):
        s = self.api.stats()
        self.api.log("TESTER stats trades=%d" % s["trades"])
        return -float(self.p.x - 7) ** 2 + 0.0 * s["profit"]
''')
BAD_TESTER = write("bad_tester.py", '''
from pyea import BaseBot
class B(BaseBot):
    def on_tester(self):
        raise RuntimeError("hỏng trong on_tester")
''')
NAN_TESTER = write("nan_tester.py", '''
from pyea import BaseBot
class B(BaseBot):
    def on_tester(self):
        return float("nan")
''')
PLAIN = write("plain.py", "from pyea import BaseBot\nclass P(BaseBot):\n    pass\n")


class TestOnTester(unittest.TestCase):
    def bt(self, path, params=None):
        return run_backtest(path, params or {}, settings(), "BTCUSD", "5m", candles_with_trap(), warmup=30, mode="ohlc_hl")

    def test_fitness_is_reported_and_sees_closed_trades_via_api_stats(self):
        r = self.bt(TESTER, {"x": 5})
        self.assertTrue(r.ok, r.error)
        self.assertAlmostEqual(r.report[FITNESS_KEY], -4.0, 9)
        self.assertTrue(any("TESTER stats trades=1" in l for l in r.logs), r.logs)    # lệnh còn mở đã được đóng TRƯỚC on_tester

    def test_no_on_tester_means_no_key(self):
        self.assertNotIn(FITNESS_KEY, self.bt(PLAIN).report)

    def test_errors_and_non_finite_values_never_break_the_backtest(self):
        r = self.bt(BAD_TESTER)
        self.assertTrue(r.ok)
        self.assertNotIn(FITNESS_KEY, r.report)
        self.assertTrue(any("on_tester lỗi" in l for l in r.logs))
        r = self.bt(NAN_TESTER)
        self.assertTrue(r.ok)
        self.assertNotIn(FITNESS_KEY, r.report)

    def test_optimize_sorts_by_custom_fitness(self):
        out = optimize(TESTER, {}, {"x": [1, 3, 5, 7, 9, 12]}, settings(), "BTCUSD", "5m", candles_with_trap(), warmup=30, sort_key=FITNESS_KEY)
        self.assertEqual([o["params"]["x"] for o in out][:3], [7, 5, 9])                # |x-7| nhỏ nhất trước
        self.assertAlmostEqual(out[0]["report"][FITNESS_KEY], 0.0, 9)

    def test_walk_forward_accepts_fitness_key(self):
        cs = [flat(i) for i in range(400)]
        out = walk_forward(TESTER, {}, {"x": [1, 7, 12]}, settings(), "BTCUSD", "5m", cs, warmup=30, is_bars=150, oos_bars=50, sort_key=FITNESS_KEY)
        self.assertTrue(out["ok"], out["error"])
        self.assertTrue(out["windows"])
        self.assertTrue(all(w["params"]["x"] == 7 for w in out["windows"]))

    def test_bot_info_flags_custom_tester(self):
        self.assertTrue(inspect_bot(TESTER).has_tester)
        self.assertFalse(inspect_bot(PLAIN).has_tester)


if __name__ == "__main__":
    unittest.main()
