"""Nhiều tài sản + nhiều bot + lệnh thủ công + backtest + OANDA + dịch vụ nền (mô hình TradingSession)."""
import http.server, json, os, sys, tempfile, threading, time, unittest, urllib.parse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import explain
from pyea.backtest import candle_ticks, compute_report, optimize, run_backtest
from pyea.controller import LocalController
from pyea.engine import BotRunner, TradingSession, parse_watchlist
from pyea.feeds import OandaFeed, SimFeed, fetch_history, make_feed
from pyea.ipc import ServiceClient, ServiceHandle, ServiceHost, notification_text, snapshot_from_json, snapshot_to_json
from pyea.settings import default_settings
from pyea.storage import Store

TMP = tempfile.mkdtemp()
STORE = Store(TMP)
STORE.seed_examples()
BOTS = STORE.bots_dir


def S(**over):
    s = default_settings()
    s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=True)
    s.update(over)
    return s


def wait(cond, timeout=12.0, step=0.05):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:
            pass
        time.sleep(step)
    return False


def write_bot(d, name, body):
    p = os.path.join(d, name)
    open(p, "w", encoding="utf-8").write(body)
    return p


HOLD = ("from pyea import BaseBot\nclass H(BaseBot):\n"
        "    def on_tick(self, t):\n"
        "        if not self.api.positions(): self.api.buy(%s, reason='giữ %s')\n")


class TestMultiAsset(unittest.TestCase):
    def test_two_bots_two_assets_plus_manual(self):
        with tempfile.TemporaryDirectory() as d:
            b1 = write_bot(d, "h1.py", HOLD % ("0.01", "BTC"))
            b2 = write_bot(d, "h2.py", HOLD % ("1000", "EUR"))
            sess = TradingSession(S(initial_balance=100000.0), log_file=None)
            i1 = sess.attach(b1, "BTCUSD", "1m"); i2 = sess.attach(b2, "EURUSD", "5m")
            sess.start(); i1.start(); i2.start()
            self.assertTrue(wait(lambda: len(sess.account.positions) >= 2 if sess.account else False, 15), [l[3] for l in sess.logs][-6:])
            owners = {p.owner: p.symbol for p in sess.account.positions.values()}
            self.assertEqual(owners, {i1.iid: "BTCUSD", i2.iid: "EURUSD"})
            # bot chỉ thấy lệnh của mình
            self.assertEqual([p.symbol for p in i1.own_positions()], ["BTCUSD"])
            self.assertEqual([p.symbol for p in i2.own_positions()], ["EURUSD"])
            # lệnh thủ công trên mã khác, có SL/TP
            t = sess.get_tick("XAUUSD")
            pos = sess.place_order("xauusd", "sell", 0.5, sl=t.bid * 1.5, tp=t.bid * 0.5, comment="tay")
            self.assertIsNotNone(pos); self.assertEqual(pos.owner, "manual"); self.assertEqual(pos.symbol, "XAUUSD")
            self.assertTrue(wait(lambda: any(e.owner == "manual" and e.kind == "open" for e in sess.events), 5))
            ev = next(e for e in sess.events if e.owner == "manual" and e.kind == "open")
            self.assertEqual(ev.symbol, "XAUUSD"); self.assertEqual(ev.source, "manual")
            self.assertIn("thủ công", explain.describe_text(ev, list(sess.events)))
            # sửa SL/TP: sai phía bị từ chối
            self.assertFalse(sess.modify_position(pos.id, sl=t.ask * 0.5))
            self.assertTrue(sess.modify_position(pos.id, sl=t.bid * 2.0, tp=t.bid * 0.4))
            # đóng chỉ 1 mã
            n = sess.close_all("manual", "test", symbol="BTCUSD")
            self.assertEqual(n, 1)
            snap = sess.snapshot()
            self.assertIn("EURUSD", snap["watch"]); self.assertEqual(len(snap["instances"]), 2)
            self.assertTrue(any(p.symbol == "XAUUSD" for p in snap["positions"]))
            # biểu đồ của mã bất kỳ
            sess.set_chart("ETHUSD", "15m")
            self.assertTrue(wait(lambda: sess.chart("ETHUSD", "15m") is not None, 8))
            ch = sess.chart("EURUSD", "5m")
            self.assertGreater(len(ch["candles"]), 50)
            sess.stop(wait=True)
            self.assertEqual(len(sess.account.positions), 0)          # đóng hết khi dừng
            self.assertEqual(sess.status, "stopped")

    def test_sl_tp_applies_to_manual_positions_and_equity_shared(self):
        sess = TradingSession(S(sim_speed=2000.0, tick_interval=0.2, initial_balance=100000.0))
        sess.start()
        self.assertTrue(wait(lambda: sess.status == "running", 8))
        t = sess.get_tick("BTCUSD")
        sl = t.bid * 0.9999
        p = sess.place_order("BTCUSD", "buy", 0.1, sl=sl)                       # SL rất sát -> sớm chạm
        self.assertIsNotNone(p)

        def sl_hit():
            # ÉP giá rơi dưới SL cho tới khi vị thế đóng. Ghi giá MỘT lần là không đủ: `SimFeed.tick()` đọc-sửa-ghi st["price"] ở luồng phiên nên
            # bản ghi của test có thể bị đè (lost update) - test này từng đỏ ~1/8 lần chạy cả ở v1.6.0.
            if sess.account.positions:
                st = sess.feed._state("BTCUSD")
                st["price"] = min(st["price"], sl * 0.95)
            return not sess.account.positions
        self.assertTrue(wait(sl_hit, 20), "SL của lệnh thủ công không kích hoạt")
        tr = sess.account.trades[-1]
        self.assertEqual(tr.reason, "Stop Loss"); self.assertEqual(tr.owner, "manual")
        close_ev = [e for e in sess.events if e.kind == "close"][-1]
        self.assertEqual(close_ev.source, "sl")
        self.assertAlmostEqual(sess.account.equity(), sess.account.balance)
        sess.stop(wait=True)

    def test_controller_and_watchlist(self):
        self.assertEqual(parse_watchlist("btcusd, eurusd;XAUUSD  btcusd"), ["BTCUSD", "EURUSD", "XAUUSD"])
        sess = TradingSession(S(watchlist="BTCUSD,EURUSD", initial_balance=100000.0))
        ctl = LocalController(sess); ctl.start()
        self.assertTrue(wait(lambda: ctl.snapshot()["ready"], 8))
        self.assertTrue(wait(lambda: set(ctl.snapshot()["watch"]) >= {"BTCUSD", "EURUSD"}, 8))
        ctl.set_watch(["BTCUSD", "EURUSD", "US500"])
        self.assertTrue(wait(lambda: "US500" in ctl.snapshot()["watch"], 8))
        status, pos = ctl.place_order("US500", "buy", 1.0)
        self.assertEqual(status, "ok")
        self.assertTrue(ctl.close_position(pos.id))
        ctl.stop(); sess.stop(wait=True)

    def test_sim_universe_and_make_feed(self):
        f = make_feed("simulated", default_settings())
        self.assertGreaterEqual(len(f.symbols()), 6)
        a, b = f.tick("EURUSD"), f.tick("XAUUSD")
        self.assertLess(a.bid, 2); self.assertGreater(b.bid, 1000)


class TestBacktest(unittest.TestCase):
    def test_candle_ticks(self):
        from pyea.sdk import Candle
        up = candle_ticks(Candle(0, 10, 12, 9, 11), 60, "ohlc")
        self.assertEqual([p for _, p in up], [10, 9, 12, 11])
        dn = candle_ticks(Candle(0, 11, 12, 9, 10), 60, "ohlc")
        self.assertEqual([p for _, p in dn], [11, 12, 9, 10])
        self.assertEqual(len(candle_ticks(Candle(0, 1, 2, 0.5, 1.5), 60, "open")), 1)

    def test_report_matches_ledger_and_events_have_reasons(self):
        feed = SimFeed(seed=11)
        c = fetch_history(feed, "BTCUSD", "5m", 3000)
        s = S(initial_balance=10000.0)
        r = run_backtest(os.path.join(BOTS, "ma_cross.py"), {"fast": 8, "slow": 24, "lot": 0.05}, s, "BTCUSD", "5m", c, 100, "ohlc")
        self.assertTrue(r.ok, r.error)
        self.assertGreater(len(r.trades), 20)
        rp = r.report
        self.assertAlmostEqual(rp["Số dư cuối"], 10000 + sum(t.profit for t in r.trades), places=6)
        self.assertEqual(rp["Tổng số lệnh"], len(r.trades))
        self.assertEqual(rp["Lệnh lãi"] + rp["Lệnh lỗ"] + sum(1 for t in r.trades if t.profit == 0), len(r.trades))
        self.assertGreaterEqual(rp["Sụt vốn tối đa (%)"], 0)
        self.assertEqual(len(r.curve) >= len(c) - 100, True)
        ops = [e for e in r.events if e.kind == "open"]
        self.assertTrue(ops and all("cắt" in e.reason for e in ops))             # lý do bot ghi
        self.assertIn("SMA8 (trước → nay)", ops[0].details)
        self.assertTrue(r.plots and "SMA8" in r.plots)
        self.assertTrue(any(e.source == "sl" or e.source == "tp" for e in r.events if e.kind == "close"))
        # tất cả lệnh đã đóng khi kết thúc
        self.assertTrue(all(t.close_time >= t.open_time for t in r.trades))

    def test_determinism_and_open_mode(self):
        feed = SimFeed(seed=5)
        c = fetch_history(feed, "EURUSD", "15m", 2000)
        s = S(initial_balance=10000.0)
        a = run_backtest(os.path.join(BOTS, "ma_cross.py"), {"lot": 1000.0}, s, "EURUSD", "15m", c, 100, "ohlc")
        b = run_backtest(os.path.join(BOTS, "ma_cross.py"), {"lot": 1000.0}, s, "EURUSD", "15m", c, 100, "ohlc")
        self.assertEqual([round(t.profit, 8) for t in a.trades], [round(t.profit, 8) for t in b.trades])
        o = run_backtest(os.path.join(BOTS, "ma_cross.py"), {"lot": 1000.0}, s, "EURUSD", "15m", c, 100, "open")
        self.assertTrue(o.ok and len(o.trades) > 0)

    def test_errors_stop_and_risk(self):
        with tempfile.TemporaryDirectory() as d:
            boom = write_bot(d, "boom.py", "from pyea import BaseBot\nclass B(BaseBot):\n    def on_tick(self, t):\n        1/0\n")
            c = fetch_history(SimFeed(seed=3), "BTCUSD", "5m", 500)
            r = run_backtest(boom, {}, S(), "BTCUSD", "5m", c, 50)
            self.assertFalse(r.ok); self.assertIn("ZeroDivisionError", r.error)
            yolo = write_bot(d, "yolo.py", HOLD % ("0.03", "x"))
            r2 = run_backtest(yolo, {}, S(max_loss_pct=0.2, initial_balance=1000.0, commission_pct=0.5), "BTCUSD", "5m", c, 50)
            self.assertIn("lỗ tối đa", r2.error)
            ev = threading.Event(); ev.set()
            r3 = run_backtest(os.path.join(BOTS, "ma_cross.py"), {}, S(), "BTCUSD", "5m", c, 50, stop_event=ev)
            self.assertIn("dừng", r3.error)
            r4 = run_backtest(os.path.join(BOTS, "ma_cross.py"), {}, S(), "BTCUSD", "5m", c[:3], 50)
            self.assertFalse(r4.ok)
            bad = write_bot(d, "bad.py", "def (:\n")
            self.assertFalse(run_backtest(bad, {}, S(), "BTCUSD", "5m", c, 50).ok)

    def test_optimize_orders_results(self):
        c = fetch_history(SimFeed(seed=9), "BTCUSD", "5m", 1500)
        res = optimize(os.path.join(BOTS, "ma_cross.py"), {"lot": 0.05, "slow": 30}, {"fast": [3, 6, 10, 15]},
                       S(initial_balance=10000.0), "BTCUSD", "5m", c, 100)
        self.assertEqual(len(res), 4)
        profits = [r["report"]["Lợi nhuận ròng"] for r in res]
        self.assertEqual(profits, sorted(profits, reverse=True))

    def test_compute_report_edge_cases(self):
        rp = compute_report([], 1000.0, [], 0)
        self.assertEqual(rp["Tổng số lệnh"], 0); self.assertEqual(rp["Lợi nhuận ròng"], 0)
        self.assertIsNone(rp["Profit factor"])


# ----------------------------------------------------------------------------- OANDA giả
class FakeOanda(http.server.BaseHTTPRequestHandler):
    orders = []
    price = 1.0850

    def log_message(self, *a): pass

    def _send(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def _auth(self):
        return self.headers.get("Authorization") == "Bearer tok"

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); qs = urllib.parse.parse_qs(u.query)
        if not self._auth(): return self._send({"errorMessage": "Insufficient authorization"}, 401)
        if u.path.endswith("/instruments") and "/accounts/" in u.path:
            return self._send({"instruments": [{"name": "EUR_USD"}, {"name": "XAU_USD"}]})
        if u.path.endswith("/pricing"):
            p = FakeOanda.price
            return self._send({"prices": [{"instrument": qs["instruments"][0], "time": "2024-05-01T10:00:00.000000000Z",
                                           "bids": [{"price": "%.5f" % (p - 0.0001)}], "asks": [{"price": "%.5f" % (p + 0.0001)}]}]})
        if "/candles" in u.path:
            n = int(qs["count"][0])
            cs = [{"complete": True, "volume": 10, "time": "2024-05-01T%02d:00:00.000000000Z" % (i % 24),
                   "mid": {"o": "1.08", "h": "1.09", "l": "1.07", "c": "1.085"}} for i in range(n)]
            return self._send({"candles": cs})
        if u.path.endswith("/summary"):
            return self._send({"account": {"balance": "2500.50"}})
        return self._send({}, 404)

    def do_POST(self):
        if not self._auth(): return self._send({"errorMessage": "x"}, 401)
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        o = body["order"]; FakeOanda.orders.append(o)
        if abs(int(o["units"])) > 100000:
            return self._send({"orderCancelTransaction": {"reason": "INSUFFICIENT_MARGIN"}})
        return self._send({"orderFillTransaction": {"price": "%.5f" % FakeOanda.price, "units": o["units"]}})


class TestOanda(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), FakeOanda)
        cls.url = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_feed_and_broker(self):
        from pyea.broker import OandaBroker, BrokerError
        f = OandaFeed(self.url, "tok", "101-001-1")
        self.assertEqual(f.symbols(), ["EUR_USD", "XAU_USD"])
        t = f.tick("EUR_USD"); self.assertAlmostEqual(t.bid, 1.0849); self.assertAlmostEqual(t.ask, 1.0851)
        h = f.history("EUR_USD", "1h", 5); self.assertEqual(len(h), 5); self.assertAlmostEqual(h[0].high, 1.09)
        b = OandaBroker("tok", "101-001-1", self.url)
        self.assertEqual(b.prepare("EUR_USD"), 2500.5)
        FakeOanda.orders.clear()
        fl = b.market_order("EUR_USD", "sell", 1500.0)
        self.assertEqual(FakeOanda.orders[-1]["units"], "-1500"); self.assertEqual(fl.qty, 1500)
        b.market_order("EUR_USD", "buy", 1500.0, reduce_only=True)
        self.assertEqual(FakeOanda.orders[-1]["positionFill"], "REDUCE_ONLY")
        with self.assertRaises(BrokerError): b.market_order("EUR_USD", "buy", 999999)
        with self.assertRaises(BrokerError): OandaBroker("bad", "1", self.url).prepare("EUR_USD")

    def test_engine_live_oanda_short_and_netting(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "fx.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_init(self): self.k = 0\n"
                "    def on_tick(self, t):\n"
                "        self.k += 1\n"
                "        if self.k == 2: self.api.sell(1000, reason='short fx')\n"
                "        if self.k == 3: self.api.buy(1000, reason='đối chiều bị chặn')\n"
                "        if self.k == 6: self.api.close_all(reason='đóng fx')\n"))
            s = S(mode="live", exchange="oanda", testnet=True, base_url=self.url, oanda_token="tok", oanda_account="101-001-1",
                  live_confirm=True, symbol="EUR_USD", watchlist="EUR_USD", sim_speed=1.0, leverage=30.0)
            FakeOanda.orders.clear()
            r = BotRunner(p, s, {}); r.start()
            self.assertTrue(wait(lambda: r.account is not None and len(r.account.trades) == 1, 12), [l[3] for l in r.logs][-6:])
            r.stop(); r._thread.join(8)
            self.assertEqual([(o["units"], o["positionFill"]) for o in FakeOanda.orders], [("-1000", "DEFAULT"), ("1000", "REDUCE_ONLY")])
            self.assertIn("không giữ đồng thời", "\n".join(l[3] for l in r.logs))


# ----------------------------------------------------------------------------- dịch vụ nền (phiên nhiều tài sản)
class TestServiceHost(unittest.TestCase):
    def _cfg(self, **over):
        inst = [{"iid": "ma1", "bot_path": os.path.join(BOTS, "ma_cross.py"), "symbol": "BTCUSD", "tf": "1m",
                 "params": {"fast": 3, "slow": 8, "lot": 0.05}, "running": True}]
        c = {"settings": S(**over), "instances": inst, "log_file": None, "trades_csv": None}
        return c

    def test_full_flow(self):
        with tempfile.TemporaryDirectory() as d:
            notes = []
            host = ServiceHost(d, set_notification=lambda t, x: notes.append((t, x)), sleep=0.05, exit_grace=0.5, idle_exit=5)
            th = threading.Thread(target=host.run, daemon=True); th.start()
            client = ServiceClient(d)
            stop_ui = threading.Event()
            threading.Thread(target=lambda: [client.touch_ui() or time.sleep(0.3) for _ in iter(stop_ui.is_set, True)], daemon=True).start()
            h = ServiceHandle(client, host.store.events_path)
            h.start(self._cfg(initial_balance=100000.0))
            self.assertTrue(h.is_alive())
            self.assertTrue(wait(lambda: (h.snapshot() or {}).get("ready"), 15), "không có snapshot")
            h.set_chart("BTCUSD", "1m")
            self.assertTrue(wait(lambda: h.chart("BTCUSD", "1m") is not None, 10))
            self.assertGreater(len(h.chart("BTCUSD", "1m")["candles"]), 50)
            self.assertEqual(h.snapshot()["instances"][0]["iid"], "ma1")
            # lệnh thủ công qua IPC trên mã khác
            h.place_order("EURUSD", "buy", 1000.0, comment="ipc")
            self.assertTrue(wait(lambda: any(p.symbol == "EURUSD" for p in h.snapshot()["positions"]), 10))
            pid = next(p.id for p in h.snapshot()["positions"] if p.symbol == "EURUSD")
            t = h.snapshot()["watch"]["EURUSD"]
            h.modify_position(pid, sl=t["bid"] * 0.9, tp=t["bid"] * 1.1)
            self.assertTrue(wait(lambda: next(p for p in h.snapshot()["positions"] if p.id == pid).sl > 0, 8))
            self.assertTrue(wait(lambda: any(e.owner == "manual" and e.symbol == "EURUSD" for e in h.events()), 8))
            h.close_position(pid)
            self.assertTrue(wait(lambda: not any(p.id == pid for p in h.snapshot()["positions"]), 8))
            # gắn thêm bot khi đang chạy rồi gỡ
            h.attach({"iid": "rsi1", "bot_path": os.path.join(BOTS, "rsi_reversion.py"), "symbol": "ETHUSD", "tf": "5m", "params": {}}, True)
            self.assertTrue(wait(lambda: len(h.snapshot()["instances"]) == 2, 10))
            self.assertTrue(wait(lambda: all(i["status"] == "running" for i in h.snapshot()["instances"]), 15))
            h.inst_stop("rsi1")
            self.assertTrue(wait(lambda: next(i for i in h.snapshot()["instances"] if i["iid"] == "rsi1")["status"] in ("stopped", "stopping"), 8))
            h.detach("rsi1")
            self.assertTrue(wait(lambda: len(h.snapshot()["instances"]) == 1, 8))
            self.assertTrue(wait(lambda: notes, 5)); self.assertTrue(all("PyEA" in t for t, _ in notes))
            h.stop()
            self.assertTrue(wait(lambda: not h.is_alive(), 15))
            self.assertEqual(h.finished_state()[0], "stopped")
            self.assertTrue(wait(lambda: not client.host_alive(), 6))
            self.assertFalse(client.read_desired()["running"])
            stop_ui.set(); th.join(5)

    def test_snapshot_json_roundtrip(self):
        sess = TradingSession(S(initial_balance=100000.0)); sess.start()
        self.assertTrue(wait(lambda: sess.status == "running", 8))
        sess.place_order("BTCUSD", "buy", 0.01)
        sess.set_chart("BTCUSD", "1m"); self.assertTrue(wait(lambda: sess.chart("BTCUSD", "1m"), 8))
        time.sleep(0.5)
        raw = json.loads(json.dumps(snapshot_to_json(sess.snapshot(), sess.chart("BTCUSD", "1m"))))
        back = snapshot_from_json(raw); sess.stop(wait=True)
        self.assertEqual(len(back["positions"]), 1); self.assertEqual(back["positions"][0].symbol, "BTCUSD")
        self.assertGreater(len(back["chart"]["candles"]), 20)
        t, x = notification_text(back); self.assertIn("PyEA", t)

    def test_crash_recovery_and_storm_guard(self):
        with tempfile.TemporaryDirectory() as d:
            alarms = []
            p = write_bot(d, "hold.py", HOLD % ("0.01", "x"))
            cfg = {"settings": S(close_on_stop=False, initial_balance=100000.0), "token": "tok1", "log_file": None, "trades_csv": None,
                   "instances": [{"iid": "hold-1", "bot_path": p, "symbol": "BTCUSD", "tf": "1m", "params": {}, "running": True}]}
            h1 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
            h1.start_session(cfg)
            self.assertTrue(wait(lambda: h1.session.account is not None and h1.session.account.positions, 10))
            pid = list(h1.session.account.positions)[0]
            h1.session.stop(wait=True)                                    # "crash": phiên chết, desired vẫn running
            ServiceClient(d).write_desired({"running": True, "config": cfg})
            h2 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
            th = threading.Thread(target=h2.run, daemon=True); th.start()
            self.assertTrue(wait(lambda: h2.session is not None and h2.session.status == "running", 10))
            self.assertIn(pid, h2.session.account.positions)
            self.assertEqual(h2.session.account.positions[pid].owner, "hold-1")
            self.assertTrue(wait(lambda: h2.session.instances["hold-1"].status == "running", 10))
            time.sleep(1.0)
            self.assertEqual(len(h2.session.account.positions), 1)        # bot nhận lại lệnh của mình, không mở thêm
            self.assertTrue(any("khôi phục" in a for a in alarms), alarms)
            h2.session.stop(wait=True); th.join(10)
            # chống vòng lặp crash
            ServiceClient(d).write_desired({"running": True, "config": cfg, "restarts": [time.time()] * 3})
            h3 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, idle_exit=0.3)
            h3.run()
            self.assertIsNone(h3.session)
            self.assertTrue(any("crash liên tục" in a for a in alarms))


if __name__ == "__main__":
    unittest.main()
