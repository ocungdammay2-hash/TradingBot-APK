"""Chạy không giao diện: cổng LIVE, gắn bot, chạy-dừng đúng cách trên sàn giả lập."""
import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import headless
from pyea.storage import Store


class TestHeadless(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.d = self.tmp.name

    def test_live_needs_flag_and_confirm(self):
        store = headless.init_dir(self.d)
        s = store.load_settings()
        s.update(mode="live", exchange="binance_futures", live_confirm=False)
        store.save_settings(s)
        msgs = []
        self.assertEqual(headless.run(self.d, log=msgs.append), 2)
        self.assertIn("live_confirm", msgs[-1])
        s["live_confirm"] = True
        store.save_settings(s)
        self.assertEqual(headless.run(self.d, log=msgs.append), 2)
        self.assertIn("--accept-risk", msgs[-1])
        s.update(exchange="simulated")
        store.save_settings(s)
        self.assertEqual(headless.run(self.d, accept_risk=True, log=msgs.append), 2)
        self.assertIn("simulated", msgs[-1])

    def test_attach_and_cli(self):
        headless.init_dir(self.d)
        self.assertTrue(os.path.exists(os.path.join(self.d, "bots", "ma_cross.py")))
        self.assertEqual(headless.attach(self.d, "ma_cross.py", "btcusdt", "1m"), 1)
        inst = Store(self.d).load_instances()
        self.assertEqual((inst[0]["symbol"], inst[0]["tf"]), ("BTCUSDT", "1m"))
        with self.assertRaises(FileNotFoundError):
            headless.attach(self.d, "khong_co.py", "X", "1m")
        self.assertEqual(headless.main(["--data-dir", self.d, "--status"]), 0)

    def test_paper_run_then_graceful_stop(self):
        store = headless.init_dir(self.d)
        s = store.load_settings()
        s.update(mode="paper", exchange="simulated")
        store.save_settings(s)
        headless.attach(self.d, "ma_cross.py", "BTCUSDT", "1m")
        stop = threading.Event()
        out = {}
        logs = []
        t = threading.Thread(target=lambda: out.update(code=headless.run(self.d, stop, log=logs.append, host_kwargs={"sleep": 0.05})), daemon=True)
        t.start()
        deadline = time.time() + 20
        from pyea.ipc import ServiceClient
        c = ServiceClient(self.d)
        alive = False
        while time.time() < deadline and not alive:
            st = c.read_state()
            alive = bool(st and st.get("session_alive"))
            time.sleep(0.1)
        self.assertTrue(alive, "phiên không khởi động")
        stop.set()
        t.join(30)
        self.assertFalse(t.is_alive(), "host không thoát sau khi dừng")
        self.assertEqual(out["code"], 0)
        self.assertTrue(any("PyEA headless chạy" in x for x in logs))
        self.assertIn("đã dừng", headless.status_text(self.d))


if __name__ == "__main__":
    unittest.main()
