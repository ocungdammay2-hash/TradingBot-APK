"""Cô lập tiến trình cho bot: dùng TIẾN TRÌNH CON THẬT (không giả)."""
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import botproc                                                          # noqa: E402
from pyea.botproc import dec, enc                                                 # noqa: E402
from pyea.engine import BotRunner, TradingSession                                 # noqa: E402
from pyea.sdk import Candle, Position, Tick                                       # noqa: E402
from pyea.settings import default_settings                                        # noqa: E402

SECRET = "SECRET-IN-PARENT-MEMORY-4242"


def S(**over):
    s = default_settings()
    s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=False, initial_balance=100000.0,
             bot_isolation="process", watchlist="BTCUSD", api_secret=SECRET)
    s.update(over)
    return s


def wait(cond, timeout=20.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:
            pass
        time.sleep(0.05)
    return False


def write(d, name, body):
    p = os.path.join(d, name)
    open(p, "w", encoding="utf-8").write(body)
    return p


HEAD = "import os\nfrom pyea import BaseBot, Input\n"
TRADER = HEAD + '''
class T(BaseBot):
    inputs = {"lot": Input(0.01, "lot"), "tag": Input("a", "tag")}
    def on_init(self):
        self.api.log("init pid=%d lot=%s" % (os.getpid(), self.p.lot))
        self.n = 0
    def on_tick(self, t):
        self.n += 1
        if not self.api.positions():
            self.api.buy(self.p.lot, reason="proc " + self.p.tag)
'''


class TestSerialization(unittest.TestCase):
    def test_roundtrip_dataclasses_nested_and_plain(self):
        c = Candle(1.0, 2.0, 3.0, 1.0, 2.5, 10.0)
        t = Tick("X", 5.0, 1.0, 1.1)
        p = Position(7, "X", "buy", 0.5, 1.0, 5.0)
        back = dec(enc({"c": [c, c], "t": t, "p": p, "n": 3, "s": "x", "none": None, "tup": (1, 2)}))
        self.assertEqual(back["c"], [c, c])
        self.assertEqual((back["t"], back["p"]), (t, p))
        self.assertEqual(back["tup"], [1, 2])

    def test_unknown_types_rejected_not_pickled(self):
        with self.assertRaises(TypeError):
            enc(object())
        self.assertEqual(dec({"__t__": "EvilClass", "a": 1}), {"__t__": "EvilClass", "a": 1})        # tên lớp lạ KHÔNG được khởi tạo

    def test_availability_rules(self):
        ok, why = botproc.available()
        self.assertTrue(ok, why)
        old = os.environ.get("ANDROID_ARGUMENT")
        os.environ["ANDROID_ARGUMENT"] = "x"
        try:
            ok, why = botproc.available()
            self.assertFalse(ok)
            self.assertIn("Android", why)
        finally:
            if old is None:
                os.environ.pop("ANDROID_ARGUMENT")
            else:
                os.environ["ANDROID_ARGUMENT"] = old


class ProcBase(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.sessions = []

    def tearDown(self):
        for s in self.sessions:
            try:
                for i in list(s.instances.values()):
                    i.stop()
                s.stop(wait=True)
            except Exception:
                pass

    def run_bot(self, body, params=None, name="b.py", **settings):
        path = write(self.d, name, body)
        s = TradingSession(S(**settings), log_file=None)
        s.data_dir = self.d
        self.sessions.append(s)
        inst = s.attach(path, "BTCUSD", "1m", params or {}, iid="p1")
        s.start()
        inst.start()
        return s, inst

    def logs(self, s):
        return "\n".join(x[3] for x in s.get_logs(0))


class TestProcessRunner(ProcBase):
    def test_bot_trades_through_rpc_in_a_different_process(self):
        s, inst = self.run_bot(TRADER, {"lot": 0.02, "tag": "z"})
        self.assertTrue(wait(lambda: s.account is not None and len(s.account.positions) == 1), self.logs(s))
        self.assertEqual(inst.status, "running")
        pos = list(s.account.positions.values())[0]
        self.assertEqual((pos.owner, pos.volume, pos.symbol), ("p1", 0.02, "BTCUSD"))
        self.assertTrue(wait(lambda: "init pid=" in self.logs(s)))
        child_pid = int(self.logs(s).split("init pid=")[1].split()[0])
        self.assertNotEqual(child_pid, os.getpid())                         # bot THỰC SỰ chạy ở tiến trình khác
        self.assertTrue(wait(lambda: any(e.reason and "proc z" in e.reason for e in s.events)))      # lý do lệnh đi qua RPC đúng
        self.assertIn("TIẾN TRÌNH RIÊNG", self.logs(s))
        time.sleep(0.8)
        self.assertEqual(len(s.account.positions), 1)                       # bot chỉ thấy lệnh của chính nó, không mở thêm

    def test_params_inputs_discovery_and_live_param_change(self):
        s, inst = self.run_bot(TRADER, {"lot": 0.01})
        self.assertTrue(wait(lambda: inst.status == "running"), self.logs(s))
        self.assertEqual(set(inst.bot_inputs), {"lot", "tag"})
        self.assertEqual(inst.bot_inputs["lot"].kind, "float")
        self.assertTrue(wait(lambda: len(s.account.positions) == 1), self.logs(s))      # bot đã mở lệnh trước khi đổi tham số
        inst.apply_params({"lot": 0.05, "tag": "n"})
        self.assertTrue(wait(lambda: inst.bot_params.get("lot") == 0.05), self.logs(s))
        self.assertTrue(wait(lambda: "lot=0.05" in self.logs(s)))          # on_deinit('params') rồi on_init() lại trong tiến trình con
        self.assertEqual(len(s.account.positions), 1)                       # lệnh đang mở giữ nguyên

    def test_bot_reads_market_data_and_account_via_api(self):
        body = HEAD + '''
class R(BaseBot):
    def on_init(self):
        self.done = False
    def on_tick(self, t):
        if self.done:
            return
        self.done = True
        a = self.api
        cs = a.candles(5)
        self.api.log("R candles=%d last_close_type=%s tick_bid=%s sym=%s bal=%s" % (len(cs), type(cs[-1].close).__name__, type(a.tick.bid).__name__, a.symbol, a.balance > 0))
'''
        s, inst = self.run_bot(body)
        self.assertTrue(wait(lambda: "R candles=" in self.logs(s)), self.logs(s))
        line = [x for x in self.logs(s).splitlines() if "R candles=" in x][0]
        self.assertIn("candles=5", line)
        self.assertIn("last_close_type=float", line)
        self.assertIn("tick_bid=float", line)
        self.assertIn("sym=BTCUSD", line)
        self.assertIn("bal=True", line)

    def test_bot_exception_is_reported_with_child_traceback_and_runner_survives(self):
        body = HEAD + "class B(BaseBot):\n    def on_tick(self, t):\n        raise ValueError('hỏng trong bot')\n"
        s, inst = self.run_bot(body)
        self.assertTrue(wait(lambda: inst.status == "error"), self.logs(s))
        self.assertIn("hỏng trong bot", self.logs(s))
        self.assertTrue(s.is_alive())                                       # phiên (và app) vẫn sống

    def test_hanging_bot_is_killed(self):
        body = HEAD + "class H(BaseBot):\n    def on_tick(self, t):\n        while True:\n            pass\n"
        s, inst = self.run_bot(body, bot_hang_kill_s=1.5)
        self.assertTrue(wait(lambda: inst.status == "error", 25), self.logs(s))
        self.assertIn("treo", self.logs(s))
        self.assertIn("đã giết", self.logs(s))
        self.assertTrue(s.is_alive())
        pid_line = [x for x in self.logs(s).splitlines() if "TIẾN TRÌNH RIÊNG (pid" in x][0]
        pid = int(pid_line.split("pid ")[1].rstrip(") ").rstrip(")"))
        self.assertTrue(wait(lambda: not os.path.exists("/proc/%d" % pid) or open("/proc/%d/stat" % pid).read().split()[2] == "Z", 5))

    def test_bot_calling_os_exit_does_not_take_down_the_app(self):
        body = HEAD + "class X(BaseBot):\n    def on_tick(self, t):\n        __import__('os')._exit(3)\n"
        s, inst = self.run_bot(body, dev_mode=True)                        # dev_mode: cho phép import tuỳ ý để chứng minh cách ly
        self.assertTrue(wait(lambda: inst.status == "error", 20), self.logs(s))
        self.assertIn("thoát đột ngột", self.logs(s))
        self.assertTrue(s.is_alive())

    def test_stop_request_kills_a_busy_bot_after_grace(self):
        body = HEAD + "class H(BaseBot):\n    def on_tick(self, t):\n        while True:\n            pass\n"
        s, inst = self.run_bot(body)
        self.assertTrue(wait(lambda: inst.status == "running"))
        time.sleep(0.8)
        t0 = time.time()
        inst.stop()
        self.assertTrue(wait(lambda: inst.status in ("stopped", "error"), 15), self.logs(s))
        self.assertLess(time.time() - t0, 12)
        self.assertTrue(s.is_alive())

    def test_child_environment_is_clean_and_has_no_parent_secrets(self):
        os.environ["PYEA_TEST_SECRET_ENV"] = SECRET
        try:
            body = HEAD + '''
class E(BaseBot):
    def on_init(self):
        import gc
        env_leak = any("SECRET" in k or "SECRET" in str(v) for k, v in os.environ.items())
        mem_leak = False
        try:
            mem_leak = any(isinstance(o, str) and "SECRET-IN-PARENT-MEMORY" in o for o in gc.get_objects())
        except Exception:
            pass
        self.api.log("ENV env_leak=%s mem_leak=%s cwd_has_bot_data=%s" % (env_leak, mem_leak, "bot_data" in os.getcwd()))
'''
            s, inst = self.run_bot(body, dev_mode=True)
            self.assertTrue(wait(lambda: "ENV env_leak=" in self.logs(s)), self.logs(s))
            line = [x for x in self.logs(s).splitlines() if "ENV env_leak=" in x][0]
            self.assertIn("env_leak=False", line)                          # biến môi trường của cha KHÔNG lọt sang
            self.assertIn("mem_leak=False", line)                          # khoá/settings KHÔNG nằm trong bộ nhớ tiến trình con
            self.assertIn("cwd_has_bot_data=True", line)
        finally:
            os.environ.pop("PYEA_TEST_SECRET_ENV", None)

    def test_api_misuse_raises_inside_bot_not_in_app(self):
        body = HEAD + '''
class M(BaseBot):
    def on_init(self):
        self.done = False
    def on_tick(self, t):
        if self.done:
            return
        self.done = True
        try:
            self.api.candles(5, "khung-sai")
        except Exception as e:
            self.api.log("MISUSE %s" % type(e).__name__)
        try:
            self.api._secret_attr
        except AttributeError:
            self.api.log("PRIVATE_BLOCKED")
        try:
            self.api.khong_ton_tai
        except AttributeError:
            self.api.log("UNKNOWN_BLOCKED")
'''
        s, inst = self.run_bot(body)
        self.assertTrue(wait(lambda: "UNKNOWN_BLOCKED" in self.logs(s)), self.logs(s))
        self.assertIn("PRIVATE_BLOCKED", self.logs(s))
        self.assertEqual(inst.status, "running")

    def test_falls_back_to_thread_mode_when_unavailable(self):
        old = os.environ.get("ANDROID_ARGUMENT")
        os.environ["ANDROID_ARGUMENT"] = "x"
        try:
            s, inst = self.run_bot(TRADER, {"lot": 0.01})
            self.assertTrue(wait(lambda: s.account is not None and len(s.account.positions) == 1), self.logs(s))
            self.assertIn("Cô lập tiến trình không dùng được", self.logs(s))
            self.assertNotIn("TIẾN TRÌNH RIÊNG (pid", self.logs(s))
        finally:
            if old is None:
                os.environ.pop("ANDROID_ARGUMENT")
            else:
                os.environ["ANDROID_ARGUMENT"] = old

    def test_thread_mode_is_default_and_unchanged(self):
        s, inst = self.run_bot(TRADER, {"lot": 0.01}, bot_isolation="thread")
        self.assertTrue(wait(lambda: s.account is not None and len(s.account.positions) == 1), self.logs(s))
        self.assertNotIn("TIẾN TRÌNH RIÊNG", self.logs(s))
        self.assertEqual(default_settings()["bot_isolation"], "thread")

    def test_bad_bot_file_reports_load_error(self):
        s, inst = self.run_bot("this is not python(", name="bad.py")
        self.assertTrue(wait(lambda: inst.status == "error"), self.logs(s))
        self.assertTrue(s.is_alive())

    def test_process_is_cleaned_up_on_stop(self):
        s, inst = self.run_bot(TRADER, {"lot": 0.01})
        self.assertTrue(wait(lambda: inst.status == "running"))
        proc = inst.bot.proc
        inst.stop()
        self.assertTrue(wait(lambda: proc.poll() is not None, 15))


class TestBacktestUnaffected(unittest.TestCase):
    def test_backtest_ignores_process_mode(self):
        from pyea.backtest import run_backtest
        from pyea.feeds import SimFeed, fetch_history
        d = tempfile.mkdtemp()
        p = write(d, "t.py", TRADER)
        c = fetch_history(SimFeed(seed=1), "EURUSD", "15m", 400)
        r = run_backtest(p, {"lot": 1000.0}, S(initial_balance=10000.0), "EURUSD", "15m", c, 50, "ohlc")
        self.assertTrue(r.ok, r.error)
        self.assertTrue(r.trades)                                           # chạy đồng bộ trong tiến trình hiện tại


if __name__ == "__main__":
    unittest.main()
