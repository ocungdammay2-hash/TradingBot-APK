"""docs/BOT_DEV.md: mọi tên API được nhắc trong tài liệu phải CÓ THẬT (tài liệu không được hứa hão)."""
import os
import re
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import BaseBot, Input, Group, ta                      # noqa: E402
from pyea.engine import BotContext                              # noqa: E402
from pyea.feeds import TIMEFRAMES                               # noqa: E402
from pyea.sdk import Ret, API_VERSION                           # noqa: E402
from pyea.loader import _BLOCK_MODULES, _BLOCK_CALLS, _BLOCK_PYEA_SUB   # noqa: E402

DOC = open(os.path.join(os.path.dirname(__file__), "..", "docs", "BOT_DEV.md"), encoding="utf-8").read()


def test_api_methods_exist():
    sec = DOC.split("## 3.")[1].split("## 4.")[0]
    names = set(re.findall(r"`([a-z_]+)\(", sec)) | set(re.findall(r"`([a-z_]+)`", sec.split("**Thông tin:**")[1].split("\n")[0]))
    skip = {"if", "ta", "run_backtest"}
    for n in names - skip:
        assert hasattr(BotContext, n) or hasattr(ta, n) or n in ("sma",), n
    for n in ("buy", "sell", "buy_limit", "sell_limit", "buy_stop", "sell_stop", "buy_stop_limit", "sell_stop_limit", "oco", "positions",
              "orders", "cancel_order", "modify_order", "close", "close_all", "modify", "store", "shared", "stats", "set_timer", "log",
              "status", "tick_of", "order_book", "recent_trades", "draw_hline", "draw_trend", "draw_rect", "draw_fib", "draw_text", "draw_delete", "draw_clear", "plot", "signal", "trace", "calendar", "ask_ai", "candles", "closes", "symbol_info", "account_info", "time_info"):
        assert n in DOC and hasattr(BotContext, n), n


def test_hooks_ret_timeframes_blocklist():
    for h in ("on_init", "on_tick", "on_bar", "on_trade", "on_timer", "on_tester", "on_deinit"):
        assert hasattr(BaseBot, h) and h in DOC
    for k in [k for k in vars(Ret) if k.isupper()]:
        assert k in DOC, k
    for tf in TIMEFRAMES:
        assert tf in DOC, tf
    for m in _BLOCK_MODULES:
        assert m in DOC, m
    for m in _BLOCK_PYEA_SUB:
        assert "pyea." + m in DOC, m
    for c in _BLOCK_CALLS:
        assert c in DOC, c
    assert API_VERSION in DOC


def test_indicators_named_exist():
    for n in ("sma", "ema", "rsi", "atr", "macd", "bollinger"):
        assert hasattr(ta, n)
    assert Input and Group
