"""Tách «Kết nối» (giá + biểu đồ + đặt lệnh tay) khỏi «Chạy bot». Dùng giao diện giả Kivy; không kiểm được cảm ứng/Android."""
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import kivy_stub                                         # noqa: E402


class T(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def drive(self, app, cond, timeout=15.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.05)
        return False

    def stop(self, app):
        if app.is_connected():
            app.ctl.stop()

    def test_connect_only_does_not_run_bots(self):
        import test_ui_smoke as S
        app = S.make_app()
        self.assertTrue(app.attach_cfgs)                           # có bot mẫu gắn sẵn (auto=True)
        app.start_session(run_bots=False)
        try:
            self.assertTrue(self.drive(app, lambda: app.last_snap is not None and app.is_connected()))
            self.assertTrue(self.drive(app, lambda: app.last_snap and len(app.last_snap["instances"]) >= 1))
            self.assertFalse(any(i["status"] in ("running", "starting") for i in app.last_snap["instances"]))
            self.assertEqual(app.attach_tab.run_btn.text, "▶  CHẠY TẤT CẢ BOT")
        finally:
            self.stop(app)

    def test_run_all_bots_after_connect(self):
        import test_ui_smoke as S
        app = S.make_app()
        app.start_session(run_bots=False)
        try:
            self.assertTrue(self.drive(app, lambda: app.last_snap and len(app.last_snap["instances"]) >= 1))
            app.run_bots_or_connect()
            self.assertTrue(self.drive(app, lambda: any(i["status"] == "running" for i in app.last_snap["instances"]), 20))
        finally:
            self.stop(app)

    def test_connect_and_run_starts_bots(self):
        import test_ui_smoke as S
        app = S.make_app()
        app.run_bots_or_connect()                                    # chưa kết nối -> kết nối & chạy
        try:
            self.assertTrue(self.drive(app, lambda: app.last_snap and any(i["status"] == "running" for i in app.last_snap["instances"]), 20))
        finally:
            self.stop(app)

    def test_toggle_session_button_connects_without_bots(self):
        import test_ui_smoke as S
        app = S.make_app()
        app.toggle_session()
        try:
            self.assertTrue(self.drive(app, lambda: app.is_connected() and app.last_snap is not None))
            self.assertFalse(any(i["status"] == "running" for i in app.last_snap["instances"]))
        finally:
            self.stop(app)

    def test_not_connected_labels(self):
        import test_ui_smoke as S
        app = S.make_app()
        self.assertEqual(app.attach_tab.run_btn.text, "▶  KẾT NỐI & CHẠY BOT")

    def test_diagnostics_zip_includes_boot_log(self):
        import zipfile
        import test_ui_smoke as S
        from pyea import bootlog
        app = S.make_app()
        bootlog.crumb("test-crumb-diag")
        p = app.store.export_diagnostics()
        names = zipfile.ZipFile(p).namelist()
        if bootlog.path():
            self.assertIn("boot.log", names)


if __name__ == "__main__":
    unittest.main()
