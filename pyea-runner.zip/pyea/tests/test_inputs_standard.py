import enum, os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import Group, Input
from pyea.loader import inspect_bot


class Side(enum.Enum):
    CHI_MUA = "long"
    CA_HAI = "both"


class T(unittest.TestCase):
    def test_choices_forms(self):
        a = Input("long", "x", choices={"long": "Chỉ mua", "short": "Chỉ bán"})
        self.assertEqual(a.choices, ["long", "short"])
        self.assertEqual(a.label_of("long"), "Chỉ mua")
        self.assertEqual(a.coerce("Chỉ bán"), "short")           # nhận cả nhãn hiển thị
        self.assertEqual(a.coerce("long"), "long")
        with self.assertRaises(ValueError):
            a.coerce("zzz")
        e = Input(Side.CA_HAI, "x", choices=Side)
        self.assertEqual(e.default, "both")
        self.assertEqual(e.label_of("long"), "CHI MUA")
        self.assertEqual(Input("a", choices=["a", "b"]).label_of("a"), "a")

    def test_subtypes(self):
        c = Input("#ff8800", subtype="color")
        self.assertEqual(c.coerce("ff8800"), "#FF8800")
        with self.assertRaises(ValueError):
            c.coerce("xyz")
        t = Input("09:00", subtype="time")
        self.assertEqual(t.coerce("9:05"), "09:05")
        with self.assertRaises(ValueError):
            t.coerce("25:00")
        d = Input("2026-12-31 23:59", subtype="datetime")
        self.assertEqual(d.coerce("2026-12-31"), "2026-12-31 00:00")
        with self.assertRaises(ValueError):
            d.coerce("31/12/2026")
        self.assertEqual(Input("", subtype="text").coerce("a\nb"), "a\nb")
        with self.assertRaises(ValueError):
            Input("", subtype="nope")

    def test_group_and_demo_bot(self):
        from pyea.storage import EXAMPLES_DIR
        p = os.path.join(EXAMPLES_DIR, "inputs_standard.py.txt")
        d = tempfile.mkdtemp()
        q = os.path.join(d, "inputs_standard.py")
        open(q, "w", encoding="utf-8").write(open(p, encoding="utf-8").read())
        info = inspect_bot(q)
        self.assertTrue(info.ok, info.error)
        ins = info.inputs
        self.assertEqual(ins["fast"].group, "Tín hiệu")
        self.assertEqual(ins["lot"].group, "Quản lý vốn")
        self.assertEqual(ins["line_color"].group, "Thời gian & hiển thị")
        self.assertEqual(ins["side"].label_of("both"), "Cả hai")
        self.assertEqual(ins["mode"].default, "both")
        self.assertEqual(ins["start_time"].subtype, "time")

    def test_form_shows_labels_and_reads_back_values(self):
        import test_ui_smoke as T
        from pyea.ui_widgets import ParamForm
        i = {"side": Input("long", "Hướng", choices={"long": "Chỉ mua", "short": "Chỉ bán"}), "col": Input("#FF8800", "Màu", subtype="color")}
        f = ParamForm(i, {})
        self.assertEqual(f.ctrl["side"].text, "Chỉ mua")
        f.ctrl["side"].text = "Chỉ bán"
        f.ctrl["col"].text = "00ff00"
        vals, errs = f.read()
        self.assertEqual(errs, [])
        self.assertEqual((vals["side"], vals["col"]), ("short", "#00FF00"))
        f.ctrl["col"].text = "bad"
        self.assertTrue(f.read()[1])

    def test_ai_convert_prompt(self):
        import test_ui_smoke as T
        app = T.make_app()
        paths = app.store.list_bots()
        app.selected = paths[0]
        app.ai_convert_inputs()
        self.assertIn("CHUẨN THAM SỐ PYEA", app.ai_tab.inp.text)
        self.assertIn(os.path.basename(paths[0]), app.ai_tab.inp.text)


if __name__ == "__main__":
    unittest.main()
