import socket
import time
import unittest

from fake_ea import FakeEA
from pyea import mt5ea
from pyea.bridges import BridgeError, MtBroker


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait(cond, t=4.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.03)
    return False


SETTINGS = {"mt5ea_token": "secret-token", "mt5ea_deadman_s": "20", "mt5ea_policy": "hold"}


class Base(unittest.TestCase):
    def setUp(self):
        self.srv = mt5ea.Mt5EaServer(free_port(), "secret-token", dead_s=15, policy="breakeven", hb_s=0.3)
        self.b = mt5ea.Mt5EaBackend(self.srv)
        self.ea = FakeEA(self.srv.port).start()
        self.assertTrue(wait(lambda: self.srv.alive()), "EA giả không nối được")

    def tearDown(self):
        self.ea.close()
        self.srv.close()


class TestCodec(unittest.TestCase):
    def test_roundtrip_with_special_chars(self):
        line = mt5ea.enc("RES", id=7, txt="a|b=c%d\nx\r", n=1.5, ok=True, skip=None)
        self.assertTrue(line.endswith(b"\n") and line.count(b"\n") == 1)
        typ, d = mt5ea.dec(line.decode())
        self.assertEqual((typ, d["txt"], d["n"], d["ok"], "skip" in d), ("RES", "a|b=c%d\nx\r", "1.5", "1", False))

    def test_bad_line(self):
        self.assertEqual(mt5ea.dec("|x=1"), (None, {}))

    def test_problems(self):
        self.assertTrue(mt5ea.problems({"mt5ea_token": "short"}, require=True))
        self.assertTrue(mt5ea.problems({"mt5ea_token": "good-token-1", "mt5ea_port": "80"}))
        self.assertTrue(mt5ea.problems({"mt5ea_token": "good-token-1", "mt5ea_policy": "explode"}))
        self.assertTrue(mt5ea.problems({"mt5ea_token": "has space 123"}))
        self.assertEqual(mt5ea.problems({"mt5ea_token": "good-token-1", "mt5ea_policy": "close_all", "mt5ea_deadman_s": "30"}), [])

    def test_config_files(self):
        s = dict(SETTINGS, mt5ea_port="19999", mt5ea_login="555", mt5ea_server="Broker-Demo:443", mt5ea_symbol="XAUUSD")
        self.assertIn("InpPort=19999", mt5ea.make_set_file(s))
        self.assertIn("InpToken=secret-token", mt5ea.make_set_file(s))
        ini = mt5ea.make_startup_ini(s)
        for w in ("Login=555", "Server=Broker-Demo:443", "Expert=PyEABridge", "Symbol=XAUUSD", "ExpertParameters=bridge.set"):
            self.assertIn(w, ini)


class TestAuth(unittest.TestCase):
    def test_wrong_token_denied_and_alerted(self):
        srv = mt5ea.Mt5EaServer(free_port(), "secret-token", hb_s=0.3)
        srv.start()
        ea = FakeEA(srv.port, token="wrong-token!").start()
        try:
            self.assertTrue(wait(lambda: srv.alerts))
            self.assertFalse(srv.connected)
            self.assertIn("token", srv.alerts[0]["title"].lower())
            with self.assertRaises(BridgeError):
                srv.call("info")
        finally:
            ea.close()
            srv.close()

    def test_version_mismatch(self):
        srv = mt5ea.Mt5EaServer(free_port(), "secret-token", hb_s=0.3)
        srv.start()
        ea = FakeEA(srv.port, version=99).start()
        try:
            self.assertTrue(wait(lambda: srv.alerts))
            self.assertFalse(srv.connected)
        finally:
            ea.close()
            srv.close()

    def test_silent_connection_dropped(self):
        old = mt5ea.AUTH_WAIT
        mt5ea.AUTH_WAIT = 0.4
        srv = mt5ea.Mt5EaServer(free_port(), "secret-token", hb_s=0.3)
        srv.start()
        s = socket.create_connection(("127.0.0.1", srv.port))
        try:
            self.assertTrue(wait(lambda: srv.alerts))
            self.assertFalse(srv.connected)
        finally:
            s.close()
            srv.close()
            mt5ea.AUTH_WAIT = old

    def test_port_in_use_message(self):
        a = mt5ea.Mt5EaServer(free_port(), "secret-token")
        a.start()
        try:
            b = mt5ea.Mt5EaServer(a.port, "secret-token")
            with self.assertRaises(BridgeError) as cm:
                b.start()
            self.assertIn("mt5ea_port", str(cm.exception))
        finally:
            a.close()

    def test_listens_only_on_loopback(self):
        srv = mt5ea.Mt5EaServer(free_port(), "secret-token")
        srv.start()
        try:
            self.assertEqual(srv._lsock.getsockname()[0], "127.0.0.1")
        finally:
            srv.close()


class TestBackend(Base):
    def test_read_surface(self):
        self.assertEqual(self.b.symbols(), ["EURUSD", "XAUUSD"])
        a = self.b.account()
        self.assertEqual((a["balance"], a["currency"], a["hedging"], a["demo"], a["trade_allowed"]), (10000.0, "USD", True, True, True))
        bid, ask, _ = self.b.tick("EURUSD")
        self.assertEqual((bid, ask), (1.1, 1.1002))
        self.assertEqual(self.b.spec("EURUSD")["volume_step"], 0.01)
        c = self.b.candles("EURUSD", "1h", 5)
        self.assertEqual(len(c), 5)
        self.assertEqual(c[1].time - c[0].time, 3600)

    def test_candles_rejects_unsupported_tf(self):
        with self.assertRaises(BridgeError):
            self.b.candles("EURUSD", "7m", 5)

    def test_market_close_and_tag(self):
        r = self.b.market("EURUSD", "buy", 0.1, "pyea-abcd:x")
        self.assertTrue(r["position_id"])
        p = self.b.positions()[0]
        self.assertEqual((p["symbol"], p["side"], p["volume"]), ("EURUSD", "buy", 0.1))
        self.assertLessEqual(len(p["comment"]), 31)
        self.assertEqual(p["origin"], "app")
        self.b.close_position(p["id"])
        self.assertEqual(self.b.positions(), [])

    def test_partial_close_and_modify(self):
        self.b.market("EURUSD", "sell", 0.2, "pyea")
        p = self.b.positions()[0]
        self.b.modify_position(p["id"], 1.2, 1.0)
        p = self.b.positions()[0]
        self.assertEqual((p["sl"], p["tp"]), (1.2, 1.0))
        self.b.close_position(p["id"], 0.05)
        self.assertAlmostEqual(self.b.positions()[0]["volume"], 0.15)

    def test_pending_roundtrip(self):
        r = self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.09, 1.095, None, "pyea")
        o = self.b.orders()[0]
        self.assertEqual((o["kind"], o["price"], o["stop_price"]), ("stop_limit", 1.09, 1.095))
        self.b.modify_pending(r["order_id"], price=1.08)
        self.assertEqual(self.b.orders()[0]["price"], 1.08)
        self.b.cancel_pending(r["order_id"])
        self.assertEqual(self.b.orders(), [])
        with self.assertRaises(BridgeError):
            self.b.place_pending("EURUSD", "buy", "trailing", 0.1, 1, None, None)

    def test_rejection_text_reaches_user(self):
        self.ea.reject = (10019, "No money")
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.assertIn("No money", str(cm.exception))
        self.assertIn("10019", str(cm.exception))

    def test_lost_reply_is_verified_by_tag_not_guessed(self):
        self.ea.drop_replies = {"market"}
        self.b.VERIFY_GAP = 0.2
        orig = self.srv.call

        def quick(op, timeout=None, **kw):
            return orig(op, timeout=0.8 if op == "market" else timeout, **kw)
        self.srv.call = quick
        r = self.b.market("EURUSD", "buy", 0.1, "pyea-abcd:x")
        self.assertTrue(r.get("verified"))
        self.assertEqual(len(self.ea.pos), 1)                       # lệnh đã vào đúng MỘT lần, không gửi lại

    def test_lost_reply_and_not_found_raises_clearly(self):
        self.b.VERIFY_GAP = 0.1
        orig = self.srv.call

        def quick(op, timeout=None, **kw):
            if op == "market":
                raise BridgeError("EA không trả lời «market» trong 1 giây")
            return orig(op, timeout=timeout, **kw)
        self.srv.call = quick
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.assertIn("KIỂM TRA", str(cm.exception))

    def test_history_normalised(self):
        self.ea.deals = [dict(id="1", t=1700000000, s="EURUSD", type=0, entry=0, vol=0.1, price=1.1, commission=-0.5, swap=0, fee=0, profit=0, order="9", position="5", reason=3, comment="pyea", magic=0),
                         dict(id="2", t=1700000100, s="", type=2, entry=0, vol=0, price=0, commission=0, swap=0, fee=0, profit=500, order="0", position="0", reason=0, comment="dep", magic=0)]
        h = self.b.history(0)
        self.assertEqual([x["kind"] for x in h], ["trade", "balance"])
        self.assertEqual(h[0]["entry"], "IN")
        self.assertEqual([x["id"] for x in self.b.deals(0)], ["1"])

    def test_notify(self):
        self.b.notify_mobile("xin chào")
        self.assertEqual(self.ea.notified, ["xin chào"])


class TestBrokerIntegration(Base):
    def test_mtbroker_works_on_top(self):
        bk = MtBroker(self.b)
        self.assertEqual(bk.account()["balance"], 10000.0) if hasattr(bk, "account") else None
        seq0 = bk.change_seq()
        self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.assertTrue(wait(lambda: bk.change_seq() != seq0), "sự kiện EVT phải làm tăng push_seq (đối soát sớm)")


class TestLinkAndAlerts(Base):
    def test_not_connected_message(self):
        self.ea.close()
        self.assertTrue(wait(lambda: not self.srv.connected))
        with self.assertRaises(BridgeError) as cm:
            self.b.account()
        self.assertIn("mất kết nối", str(cm.exception))

    def test_link_loss_raises_critical_alert(self):
        self.srv.pop_alerts()
        self.ea.kill_link()
        self.assertTrue(wait(lambda: not self.srv.connected))
        al = self.b.pop_alerts()
        self.assertTrue(any("MẤT cầu nối" in a["title"] and a["critical"] for a in al))
        self.assertEqual(self.b.pop_alerts(), [])                   # lấy rồi thì hết, không báo lặp

    def test_reconnect_informs_user(self):
        self.srv.pop_alerts()
        self.ea.kill_link()
        self.assertTrue(wait(lambda: not self.srv.connected))
        self.srv.pop_alerts()
        ea2 = FakeEA(self.srv.port).start()
        try:
            self.assertTrue(wait(lambda: self.srv.alive()))
            self.assertTrue(any("nối lại" in a["title"] for a in self.srv.pop_alerts()))
        finally:
            ea2.close()

    def test_deadman_fired_reported_on_reconnect(self):
        self.ea.kill_link()
        self.assertTrue(wait(lambda: not self.srv.connected))
        self.srv.pop_alerts()
        ea2 = FakeEA(self.srv.port, dead_fired=True).start()
        try:
            self.assertTrue(wait(lambda: self.srv.alive()))
            al = self.srv.pop_alerts()
            self.assertTrue(any("người chết" in a["title"] and a["critical"] and "close_all" in a["text"] for a in al))
        finally:
            ea2.close()

    def test_frozen_ea_detected(self):
        self.srv.pop_alerts()
        self.ea.stop.set()                                           # EA ngừng gửi nhưng socket còn mở
        self.assertTrue(wait(lambda: any("không phản hồi" in a["title"] for a in list(self.srv.alerts)), 9.0))

    def test_config_pushed_to_ea(self):
        self.assertEqual((self.ea.dead_s, self.ea.policy), (15.0, "breakeven"))
        self.srv.configure(40, "close_all")
        self.assertTrue(wait(lambda: self.ea.policy == "close_all"))
        self.assertEqual(self.ea.dead_s, 40.0)

    def test_app_heartbeat_sent(self):
        self.assertTrue(wait(lambda: any(t == "PING" for t, _ in self.ea.log)))


class TestOptIn(unittest.TestCase):
    def test_nothing_listens_until_selected(self):
        import pyea.mt5ea as m
        self.assertEqual(m._SERVERS, {} if not m._SERVERS else m._SERVERS)      # module import không mở cổng
        srv = mt5ea.Mt5EaServer(free_port(), "secret-token")
        self.assertIsNone(srv._lsock)

    def test_make_backend_validates_and_is_reused(self):
        with self.assertRaises(BridgeError):
            mt5ea.make_backend({"mt5ea_token": "x"})
        port = free_port()
        s = dict(SETTINGS, mt5ea_port=str(port))
        b1 = mt5ea.make_backend(s)
        try:
            b2 = mt5ea.make_backend(s)
            self.assertIs(b1.c, b2.c)
        finally:
            b1.close()
            mt5ea._SERVERS.pop(port, None)

    def test_selftest_reports_missing_ea_then_ok(self):
        port = free_port()
        s = dict(SETTINGS, mt5ea_port=str(port))
        try:
            rows = mt5ea.selftest(s, wait=0.6)
            self.assertEqual(rows[-1][0], "LỖI")
            self.assertIn("EA chưa nối", rows[-1][1])
            ea = FakeEA(port).start()
            try:
                rows = mt5ea.selftest(s, wait=5)
                self.assertFalse([r for r in rows if r[0] == "LỖI"], rows)
                self.assertTrue(any("Công tắc người chết" in r[1] for r in rows))
            finally:
                ea.close()
        finally:
            srv = mt5ea._SERVERS.pop(port, None)
            if srv:
                srv.close()


if __name__ == "__main__":
    unittest.main()


class TestSessionAlertsAndAssets(unittest.TestCase):
    def test_reconcile_mixin_raises_alarms_from_broker(self):
        from pyea.reconcile import ReconcileMixin

        class S(ReconcileMixin):
            def __init__(self):
                self.got = []

            def alarm(self, title, text, critical=True):
                self.got.append((title, text, critical))

        class B:
            def pop_alerts(self):
                return [{"title": "MẤT cầu nối EA", "text": "x", "critical": True}, {"title": "Đã nối lại", "text": "y", "critical": False}]
        s = S()
        s._bridge_alerts_due(B())
        self.assertEqual([(t, c) for t, _, c in s.got], [("MẤT cầu nối EA", True), ("Đã nối lại", False)])
        s._bridge_alerts_due(object())                               # broker không khai: không lỗi

    def test_broken_pop_alerts_does_not_crash(self):
        from pyea.reconcile import ReconcileMixin

        class S(ReconcileMixin):
            def alarm(self, *a, **k):
                raise RuntimeError("x")

        class B:
            def pop_alerts(self):
                raise RuntimeError("boom")
        S()._bridge_alerts_due(B())

    def test_mtbroker_forwards_alerts(self):
        class Fake:
            name = "fake"
            native_kinds = ()

            def pop_alerts(self):
                return [{"title": "t", "text": "x"}]
        self.assertEqual(MtBroker(Fake()).pop_alerts()[0]["title"], "t")

    def test_ea_source_is_packaged_and_consistent_with_protocol(self):
        src = mt5ea.ea_source()
        for w in ("#property strict", "SocketConnect", "OnTimer", "Deadman", "HELLO", "WELCOME", "dead_fired", "pyea", "rid"):
            self.assertIn(w, src)
        for op in ("info", "account", "symbols", "tick", "spec", "candles", "positions", "orders", "history", "notify", "market", "close", "modify_pos", "pending", "modify_pending", "cancel"):
            self.assertIn('op == "%s"' % op, src, op)                 # EA xử lý đủ mọi op mà backend gọi
        self.assertEqual(src.count("{"), src.count("}"))              # kiểm tra thô cân ngoặc, KHÔNG thay cho biên dịch
        self.assertEqual(src.count("("), src.count(")"))
        self.assertIn("PROTO_VERSION %d" % mt5ea.PROTO, src)

    def test_backend_ops_all_known_to_ea_source(self):
        import re
        code = open(mt5ea.__file__, encoding="utf-8").read()
        used = set(re.findall(r'(?:call|_trade)\("(\w+)"', code))
        src = mt5ea.ea_source()
        for op in used:
            if op in ("market", "close", "pending", "modify_pos", "modify_pending", "cancel", "info", "account", "symbols", "tick", "spec", "candles", "positions", "orders", "history", "notify"):
                self.assertIn('op == "%s"' % op, src, op)
            else:
                self.fail("op %s không có trong EA" % op)

    def test_default_exchange_is_not_mt5ea(self):
        from pyea import settings
        d = settings.GLOBAL_INPUTS["exchange"]
        self.assertEqual(d.default, "simulated")
        self.assertIn("mt5ea", d.choices)


class TestAlertCatalogue(Base):
    """Mỗi cảnh báo phải nói rõ: chuyện gì, tự khắc phục gì (hay KHÔNG), bạn cần làm gì."""

    def _wait_alert(self, kind, t=6.0):
        got = []
        end = time.time() + t
        while time.time() < end:
            got += self.srv.pop_alerts()
            hit = [a for a in got if a["kind"] == kind]
            if hit:
                return hit[0]
            time.sleep(0.05)
        self.fail("không có cảnh báo %s; có: %s" % (kind, [a["kind"] for a in got]))

    def _assert_explained(self, a):
        self.assertIn("Tự khắc phục:", a["text"])
        self.assertIn("Bạn cần:", a["text"])

    def test_abrupt_loss_explained_and_marks_no_auto_recovery_without_supervisor(self):
        self.srv.pop_alerts()
        self.ea.kill_link()
        a = self._wait_alert("lost")
        self._assert_explained(a)
        self.assertIn("KHÔNG tự sống lại", a["text"])
        self.assertIsNone(a["auto"])

    def test_abrupt_loss_with_supervisor_mentions_restart(self):
        self.srv.supervised = True
        self.srv.pop_alerts()
        self.ea.kill_link()
        a = self._wait_alert("lost")
        self.assertIn("khởi động lại MT5", a["text"])
        self.assertTrue(a["auto"])

    def test_bye_reinit_is_auto_and_not_critical(self):
        self.srv.pop_alerts()
        self.ea.bye_and_close(5)                                    # đổi tham số EA
        a = self._wait_alert("bye")
        self._assert_explained(a)
        self.assertTrue(a["auto"])
        self.assertFalse(a["critical"])
        self.assertIn("đổi tham số", a["title"])

    def test_bye_removed_is_critical_and_needs_user(self):
        self.srv.pop_alerts()
        self.ea.bye_and_close(1)                                    # gỡ EA
        a = self._wait_alert("bye")
        self.assertFalse(a["auto"])
        self.assertTrue(a["critical"])
        self.assertIn("gắn lại EA", a["text"])

    def test_broker_disconnect_and_recovery(self):
        self.srv.pop_alerts()
        self.ea.conn = 0
        a = self._wait_alert("broker_down")
        self._assert_explained(a)
        self.assertTrue(a["critical"] and a["auto"])
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.assertIn("MẤT kết nối tới máy chủ broker", str(cm.exception))
        self.assertEqual(self.ea.pos, {})                            # không gửi lệnh khi biết MT5 đang đứt broker
        self.ea.conn = 1
        self._wait_alert("broker_up")
        self.b.market("EURUSD", "buy", 0.1, "pyea")                  # hết đứt thì đặt được

    def test_algo_trading_off(self):
        self.srv.pop_alerts()
        self.ea.ta = 0
        a = self._wait_alert("algo_off")
        self.assertFalse(a["auto"])
        self.assertIn("Algo Trading", a["text"])
        with self.assertRaises(BridgeError):
            self.b.market("EURUSD", "buy", 0.1, "pyea")
        self.ea.ta = 1
        self._wait_alert("algo_on")

    def test_no_repeat_alert_for_same_state(self):
        self.srv.pop_alerts()
        self.ea.conn = 0
        self._wait_alert("broker_down")
        time.sleep(1.0)                                              # nhiều HB conn=0 liên tiếp
        self.assertEqual([a for a in self.srv.pop_alerts() if a["kind"] == "broker_down"], [])

    def test_long_outage_reminder(self):
        self.srv.remind_first, self.srv.remind_every = 0.4, 0.5
        self.srv.pop_alerts()
        self.ea.kill_link()
        self._wait_alert("lost")
        a = self._wait_alert("lost_long")
        self._assert_explained(a)
        self.assertFalse(a["auto"])
        self.assertTrue(self._wait_alert("lost_long"))               # nhắc lại định kỳ, không chỉ một lần

    def test_reminder_stops_after_reconnect(self):
        self.srv.remind_first, self.srv.remind_every = 0.6, 0.4
        self.srv.pop_alerts()
        self.ea.kill_link()
        self._wait_alert("lost")
        ea2 = FakeEA(self.srv.port).start()
        try:
            self._wait_alert("restored")
            time.sleep(1.2)
            self.assertEqual([a for a in self.srv.pop_alerts() if a["kind"] == "lost_long"], [])
        finally:
            ea2.close()

    def test_restored_mentions_outage_duration(self):
        self.srv.pop_alerts()
        self.ea.kill_link()
        self._wait_alert("lost")
        time.sleep(0.3)
        ea2 = FakeEA(self.srv.port).start()
        try:
            a = self._wait_alert("restored")
            self.assertIn("sau", a["text"])
        finally:
            ea2.close()

    def test_deadman_alert_states_what_ea_did(self):
        self.ea.kill_link()
        self._wait_alert("lost")
        ea2 = FakeEA(self.srv.port, dead_fired=True)
        ea2.dead_acted = 3
        ea2.start()
        try:
            a = self._wait_alert("deadman")
            self._assert_explained(a)
            self.assertIn("3", a["text"])
            self.assertIn("đóng/huỷ", a["text"])
        finally:
            ea2.close()

    def test_frozen_alert_admits_no_auto_recovery(self):
        self.srv.pop_alerts()
        self.ea.stop.set()
        a = self._wait_alert("frozen", t=9.0)
        self._assert_explained(a)
        self.assertFalse(a["auto"])
        self.assertIn("KHÔNG", a["text"])

    def test_every_alert_site_uses_explain_format(self):
        src = open(mt5ea.__file__, encoding="utf-8").read()
        import re
        calls = re.findall(r"self\.alert\(", src)
        self.assertGreaterEqual(src.count("explain("), len(calls) - 1)   # trừ chính định nghĩa alert


class TestSupervisedSetting(unittest.TestCase):
    def test_make_backend_sets_supervised(self):
        port = free_port()
        s = dict(SETTINGS, mt5ea_port=str(port), mt5ea_supervised="yes")
        b = mt5ea.make_backend(s)
        try:
            self.assertTrue(b.c.supervised)
        finally:
            b.close()
            mt5ea._SERVERS.pop(port, None)
