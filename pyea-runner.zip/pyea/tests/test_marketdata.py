"""DOM (depth), tick thật (aggTrades), thông số mã - chạy với máy chủ Binance giả kiểm tra đúng quy tắc của tài liệu."""
import json
import os
import sys
import threading
import unittest
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pyea import specs, tickdata
from pyea.backtest import run_backtest, MODES
from pyea.feeds import BinanceFeed
from pyea.sdk import Candle

T0 = 1_700_000_000.0


class Fake:
    def __init__(self, futures=False):
        self.trades = []                                   # (id, ms, price, qty, m)
        self.calls = []
        self.futures = futures
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, obj):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                u = urllib.parse.urlparse(self.path)
                q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                outer.calls.append((u.path, q))
                if u.path.endswith("/depth"):
                    lim = int(q.get("limit", 100))
                    if outer.futures and lim not in (5, 10, 20, 50, 100, 500, 1000):
                        return self._send(400, {"code": -1121, "msg": "Invalid limit"})
                    return self._send(200, {"lastUpdateId": 7, "bids": [["99.5", "2"], ["99.0", "5"], ["98.5", "1"]],
                                            "asks": [["100.0", "1"], ["100.5", "4"], ["101.0", "2"]]})
                if u.path.endswith("/aggTrades"):
                    lim = min(int(q.get("limit", 500)), 1000)
                    if "fromId" in q:
                        rows = [t for t in outer.trades if t[0] >= int(q["fromId"])]
                    else:
                        a, b = int(q.get("startTime", 0)), int(q.get("endTime", 1 << 60))
                        if "startTime" in q and "endTime" in q and b - a >= 3600 * 1000:
                            return self._send(400, {"code": -1127, "msg": "Time interval must be less than 1 hour"})
                        rows = [t for t in outer.trades if a <= t[1] <= b]
                    rows = rows[:lim]
                    return self._send(200, [{"a": t[0], "p": "%.2f" % t[2], "q": str(t[3]), "f": t[0], "l": t[0], "T": t[1], "m": t[4]} for t in rows])
                if u.path.endswith("/exchangeInfo"):
                    return self._send(200, {"symbols": [{"symbol": q.get("symbol"), "status": "TRADING", "baseAsset": "BTC", "quoteAsset": "USDT",
                                                         "filters": [{"filterType": "PRICE_FILTER", "tickSize": "0.10"},
                                                                     {"filterType": "LOT_SIZE", "minQty": "0.001", "maxQty": "100", "stepSize": "0.001"},
                                                                     {"filterType": "NOTIONAL", "minNotional": "5"}]}]})
                self._send(404, {})
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def add(self, n, start_ms, per_ms=1, price=100.0):
        base = len(self.trades) + 1
        for i in range(n):
            self.trades.append((base + i, start_ms + i // per_ms, price + (i % 7) * 0.1, 0.01, bool(i % 2)))

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


class TestDepthAndSpec(unittest.TestCase):
    def test_depth_spot_and_futures_limit_rounding(self):
        f = Fake(futures=True)
        self.addCleanup(f.close)
        feed = BinanceFeed(f.base, futures=True)
        d = feed.depth("BTCUSDT", 15)                      # 15 không hợp lệ cho futures -> làm tròn lên 20
        self.assertEqual(f.calls[-1][1]["limit"], "20")
        self.assertEqual(d["bids"][0], [99.5, 2.0])
        s = specs.depth_summary(d, 10)
        self.assertAlmostEqual(s["spread"], 0.5)
        self.assertAlmostEqual(s["imbalance"], (8 - 7) / 15.0)
        self.assertEqual(s["wall_bid"], [99.0, 5.0])
        self.assertIn("Spread", specs.depth_text(d, 3))
        self.assertIsNone(specs.depth_summary({"bids": [], "asks": []}))

    def test_symbol_info_parse(self):
        f = Fake()
        self.addCleanup(f.close)
        info = specs.parse_symbol_info(BinanceFeed(f.base).symbol_info("BTCUSDT"))
        self.assertEqual((info["tick"], info["step"], info["min_qty"], info["min_notional"]), (0.1, 0.001, 0.001, 5.0))
        self.assertIn("Lệnh nhỏ nhất ≈ 100", specs.spec_text(info, 100000.0))


class TestTickFetch(unittest.TestCase):
    def test_windows_under_one_hour_and_dedupe_and_order(self):
        f = Fake()
        self.addCleanup(f.close)
        base_ms = int(T0 * 1000)
        f.add(2500, base_ms, per_ms=1)                      # 2.5 s
        f.add(40, base_ms + 2 * 3600 * 1000)                # 1 cụm nữa sau 2 giờ
        feed = BinanceFeed(f.base)
        r = tickdata.fetch(feed, "BTCUSDT", T0, T0 + 3 * 3600)
        self.assertEqual(len(r["ticks"]), 2540)
        self.assertFalse(r["truncated"])
        ts = [t for t, _ in r["ticks"]]
        self.assertEqual(ts, sorted(ts))
        for path, q in f.calls:
            if "startTime" in q and "endTime" in q:
                self.assertLess(int(q["endTime"]) - int(q["startTime"]), 3600 * 1000)

    def test_many_trades_same_millisecond_falls_back_to_fromid_without_loss(self):
        f = Fake()
        self.addCleanup(f.close)
        f.add(2600, int(T0 * 1000), per_ms=5000)            # 2600 giao dịch cùng 1 ms
        r = tickdata.fetch(BinanceFeed(f.base), "BTCUSDT", T0, T0 + 10)
        self.assertEqual(len(r["ticks"]), 2600)
        self.assertTrue(any("fromId" in q for _, q in f.calls))

    def test_cap_truncates_and_futures_48h_rule(self):
        f = Fake()
        self.addCleanup(f.close)
        f.add(3000, int(T0 * 1000), per_ms=1)
        r = tickdata.fetch(BinanceFeed(f.base), "BTCUSDT", T0, T0 + 60, max_trades=1500)
        self.assertTrue(r["truncated"])
        self.assertGreaterEqual(len(r["ticks"]), 1500)
        ff = Fake(futures=True)
        self.addCleanup(ff.close)
        with self.assertRaises(tickdata.TickError):
            tickdata.fetch(BinanceFeed(ff.base, futures=True), "BTCUSDT", T0, T0 + 60, now=T0 + 49 * 3600)
        tickdata.fetch(BinanceFeed(ff.base, futures=True), "BTCUSDT", T0, T0 + 60, now=T0 + 47 * 3600)      # trong 48h: được phép

    def test_by_candle_groups(self):
        g = tickdata.by_candle([(60.5, 1), (61, 2), (125, 3)], 60)
        self.assertEqual(sorted(g), [60, 120])
        self.assertEqual(len(g[60]), 2)


BOT = '''
from pyea.sdk import BaseBot
class Bot(BaseBot):
    def on_init(self):
        self.n = 0
        self.seen = []
    def on_tick(self, t):
        self.seen.append(t.bid)
'''


class TestRealTickBacktest(unittest.TestCase):
    def test_mode_registered_and_real_ticks_used_with_fallback(self):
        import tempfile
        from pyea.settings import default_settings
        self.assertIn("real", MODES)
        step = 60
        cs = [Candle(T0 - (T0 % step) + i * step, 100, 101, 99, 100.5, 5) for i in range(130)]
        t_first = cs[100].time
        ticks = [(t_first + 1, 100.0), (t_first + 2, 100.7), (t_first + 3, 99.9), (t_first + step + 1, 100.2)]
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "b.py")
            open(path, "w").write(BOT)
            st = default_settings()
            r = run_backtest(path, {}, st, "BTCUSDT", "1m", cs, warmup=100, mode="real", ticks=ticks)
            self.assertTrue(r.ok, r.error)
            self.assertEqual(r.report["Nến dùng tick thật"], "2/30 (còn lại dùng đường OHLC)")
            r2 = run_backtest(path, {}, st, "BTCUSDT", "1m", cs, warmup=100, mode="real", ticks=None)    # không có tick -> toàn OHLC, vẫn chạy
            self.assertTrue(r2.ok, r2.error)
            self.assertEqual(r2.report["Nến dùng tick thật"], "0/30 (còn lại dùng đường OHLC)")


class TestChartTabDialogs(unittest.TestCase):
    def test_dom_and_spec_dialogs_guard_unsupported_exchange(self):
        import kivy_stub
        import test_ui_smoke as T
        app = T.make_app()
        app.chart_sym = "EURUSD"
        msgs = []
        app.toast = msgs.append
        app.settings["exchange"] = "simulated"
        app.chart_tab.dom_dialog()
        app.chart_tab.spec_dialog()
        self.assertEqual(len(msgs), 2)
        self.assertIn("Binance", msgs[0])
        app.chart_sym = "-"
        app.chart_tab.dom_dialog()
        self.assertIn("Chọn mã", msgs[-1])


if __name__ == "__main__":
    unittest.main()
