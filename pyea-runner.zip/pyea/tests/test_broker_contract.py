"""Hợp đồng broker/feed: MỘT bộ test chạy trên MỌI adapter (chữ ký, khai báo khả năng, và hành vi qua máy chủ giả)."""
import inspect
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import bridges, broker, ccxt_adapter, contract, exness, feeds     # noqa: E402


class TestSignatures(unittest.TestCase):
    def test_every_broker_accepts_every_call_shape_the_shell_uses(self):
        bad = {}
        for name, bcls, _ in contract.adapters():
            if bcls is not None:
                p = contract.check_class(bcls, contract.BROKER_CALLS)
                if p:
                    bad[name] = p
        self.assertEqual(bad, {}, "\n" + "\n".join("%s: %s" % (k, "; ".join(v)) for k, v in bad.items()))

    def test_every_feed_accepts_every_call_shape_the_shell_uses(self):
        bad = {}
        for name, _, fcls in contract.adapters():
            if fcls is not None:
                p = contract.check_class(fcls, contract.FEED_CALLS)
                if p:
                    bad[name] = p
        self.assertEqual(bad, {}, "\n" + "\n".join("%s: %s" % (k, "; ".join(v)) for k, v in bad.items()))

    def test_no_adapter_class_escapes_the_registry(self):
        """Thêm class XxxBroker/XxxFeed mới mà quên đăng ký vào contract.adapters() -> test này đỏ."""
        reg = {c for _, b, f in contract.adapters() for c in (b, f) if c is not None}
        found = set()
        for mod in (broker, feeds, exness, bridges, ccxt_adapter):
            for n, c in vars(mod).items():
                if inspect.isclass(c) and c.__module__ == mod.__name__ and (n.endswith("Broker") or n.endswith("Feed")) and not n.startswith("_"):
                    found.add(c)
        missing = sorted(c.__name__ for c in found - reg)
        self.assertEqual(missing, [], "adapter chưa đăng ký trong pyea/contract.py:adapters(): %s" % missing)

    def test_capability_attributes_have_the_right_types(self):
        for name, bcls, _ in contract.adapters():
            if bcls is None:
                continue
            holder = type("H", (), {k: getattr(bcls, k) for k in contract.BROKER_ATTRS if hasattr(bcls, k)})()
            holder.native_pending = getattr(bcls, "native_pending", ())
            self.assertEqual(contract.check_broker_attrs(holder), [], name)

    def test_contract_checker_actually_detects_the_historic_bug(self):
        class Old:
            def history(self, since=0.0):
                return []
        p = contract.check_class(Old, {"history": contract.BROKER_CALLS["history"]})
        self.assertTrue(p and "history" in p[0], p)


class TestShapeCheckers(unittest.TestCase):
    def test_fill_positions_pending_result(self):
        self.assertEqual(contract.check_fill(broker.Fill(1.5, 2.0)), [])
        self.assertTrue(contract.check_fill(broker.Fill(0, 2.0)))
        self.assertTrue(contract.check_fill(None))
        self.assertEqual(contract.check_positions({"A": {"qty": -1.0, "price": 2.0}}), [])
        self.assertTrue(contract.check_positions({"A": {"qty": 0.0, "price": 2.0}}))
        self.assertTrue(contract.check_positions([]))
        self.assertEqual(contract.check_pending({"1": {"symbol": "A", "side": "buy", "price": 1.0, "qty": 1.0}}), [])
        self.assertTrue(contract.check_pending({"1": {"symbol": "A", "side": "buy", "price": 1.0, "volume": 1.0}}))
        self.assertEqual(contract.check_order_result(None), [])
        self.assertEqual(contract.check_order_result({"state": "open"}), [])
        self.assertTrue(contract.check_order_result({"state": "weird"}))

    def test_history_rows_and_candles(self):
        row = {"id": "1", "time": 1.7e9, "symbol": "A", "side": "buy", "qty": 1.0, "price": 1.0, "fee": 0.0, "pnl": 0.0}
        self.assertEqual(contract.check_history_rows([row]), [])
        self.assertTrue(contract.check_history_rows([dict(row, time=1.7e9), dict(row, time=1.6e9)]))
        self.assertTrue(contract.check_history_rows([{k: v for k, v in row.items() if k != "pnl"}]))
        from pyea.sdk import Candle
        ok = [Candle(60 * i + 1.7e9 // 60 * 60, 1, 2, 0.5, 1.5, 1) for i in range(3)]
        self.assertEqual(contract.check_candles(ok, 60), [])
        self.assertTrue(contract.check_candles(ok + [ok[-1]], 60))                          # trùng giờ
        self.assertTrue(contract.check_candles([Candle(1.7e9, 1, 0.5, 2, 1.5, 1)], 60))    # high < low
        self.assertTrue(contract.check_candles(ok, 60, before=ok[0].time))                  # vi phạm phân trang


if __name__ == "__main__":
    unittest.main()
