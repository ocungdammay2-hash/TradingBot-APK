"""Đo tải: loadprobe (đọc /proc), loadbench, và tách biểu đồ tĩnh khỏi state.json (ipc.split_chart/merge_chart)."""
import copy
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub  # noqa: E402,F401

from pyea import loadprobe  # noqa: E402
from pyea.ipc import ServiceClient, ServiceHandle, merge_chart, snapshot_from_json, split_chart  # noqa: E402


def chart(n=50, sym="BTCUSD", tf="1m", plots=True):
    cs = [[1000 + i * 60, 100 + i, 101 + i, 99 + i, 100.5 + i, 5.0] for i in range(n)]
    pl = {"ema": [[c[0], c[4] - 1] for c in cs]} if plots else {}
    return {"symbol": sym, "timeframe": tf, "candles": cs, "plots": pl, "bid": 1.0, "ask": 1.1, "positions": [], "pending": []}


class TestSplitChart(unittest.TestCase):
    def test_roundtrip_equals_original(self):
        d = {"chart": chart()}
        orig = copy.deepcopy(d["chart"])
        static, sig = split_chart(d)
        self.assertEqual(len(d["chart"]["candles"]), 1)                       # state.json chỉ còn nến cuối
        self.assertEqual(d["chart"]["candles"][0], orig["candles"][-1])
        merged = merge_chart(d["chart"], static)
        self.assertEqual(merged["candles"], orig["candles"])
        self.assertEqual(merged["plots"], orig["plots"])
        self.assertEqual(d["chart"]["static"], sig)

    def test_signature_stable_until_closed_bars_change(self):
        a = {"chart": chart()}
        b = {"chart": chart()}
        b["chart"]["candles"][-1][4] += 5                                    # chỉ nến ĐANG CHẠY đổi giá: chữ ký giữ nguyên
        self.assertEqual(split_chart(a)[1], split_chart(b)[1])
        c = {"chart": chart(51)}                                             # có nến mới đóng
        self.assertNotEqual(split_chart({"chart": chart()})[1], split_chart(c)[1])
        e = {"chart": chart()}
        e["chart"]["plots"]["ema"][5][1] += 1                                # bot sửa điểm vẽ CŨ: phải ghi lại
        self.assertNotEqual(split_chart({"chart": chart()})[1], split_chart(e)[1])
        g = {"chart": chart()}
        g["chart"]["candles"][10][4] += 1                                    # nến cũ đổi (lấp khoảng trống/nạp lại)
        self.assertNotEqual(split_chart({"chart": chart()})[1], split_chart(g)[1])

    def test_mismatch_symbol_or_missing_static_gives_no_chart(self):
        d = {"chart": chart()}
        static, _ = split_chart(d)
        self.assertIsNone(merge_chart(d["chart"], None))
        other = dict(static, symbol="ETHUSD")
        self.assertIsNone(merge_chart(d["chart"], other))
        self.assertEqual(merge_chart({"candles": []}, None), {"candles": []})       # bản cũ (không có `static`) đi qua nguyên vẹn

    def test_tiny_chart_not_split(self):
        d = {"chart": chart(1)}
        self.assertEqual(split_chart(d)[0], None)
        self.assertNotIn("static", d["chart"])

    def test_ui_handle_merges_and_rereads_only_on_new_signature(self):
        with tempfile.TemporaryDirectory() as tmp:
            client = ServiceClient(tmp)
            h = ServiceHandle(client, os.path.join(tmp, "ev.jsonl"), token="T")
            reads = []
            orig_read = client.read_chart
            client.read_chart = lambda: (reads.append(1), orig_read())[1]
            snap = {"ready": True, "chart": chart()}
            expect = copy.deepcopy(snap["chart"])
            static, sig = split_chart(snap)
            client.write_chart(static)
            client.write_state({"pub": 1, "token": "T", "snapshot": snap})
            s1 = h.snapshot()
            self.assertEqual(len(s1["chart"]["candles"]), len(expect["candles"]))
            self.assertEqual(s1["chart"]["candles"][-1].close, expect["candles"][-1][4])
            self.assertEqual(s1["chart"]["plots"]["ema"][0], tuple(expect["plots"]["ema"][0]))
            client.write_state({"pub": 2, "token": "T", "snapshot": snap})          # cùng chữ ký: KHÔNG đọc lại chart.json
            h.snapshot()
            self.assertEqual(len(reads), 1)
            snap2 = {"ready": True, "chart": chart(51)}
            st2, sig2 = split_chart(snap2)
            client.write_chart(st2)
            client.write_state({"pub": 3, "token": "T", "snapshot": snap2})
            self.assertEqual(len(h.snapshot()["chart"]["candles"]), 51)
            self.assertEqual(len(reads), 2)

    def test_stale_file_gives_empty_chart_not_wrong_chart(self):
        with tempfile.TemporaryDirectory() as tmp:
            client = ServiceClient(tmp)
            h = ServiceHandle(client, os.path.join(tmp, "ev.jsonl"), token="T")
            snap = {"ready": True, "chart": chart()}
            static, _ = split_chart(snap)
            client.write_chart(dict(static, sig="khác", symbol="ETHUSD"))          # chart.json của lần khác
            client.write_state({"pub": 1, "token": "T", "snapshot": snap})
            self.assertIsNone(h.snapshot()["chart"])


class TestLoadProbe(unittest.TestCase):
    def test_read_proc_self(self):
        r = loadprobe.read_proc(os.getpid())
        if os.path.exists("/proc/self/stat"):
            self.assertIsNotNone(r["cpu_s"])
            self.assertGreater(r["rss_mb"], 1)
        self.assertEqual(loadprobe.read_proc(2 ** 30), {"cpu_s": None, "rss_mb": None, "threads": None, "write_mb": None})

    def test_meter_report_and_rates(self):
        m = loadprobe.LoadMeter(every=0)
        self.assertIn("Chưa đủ", m.report())
        base = {"cpu_s": 1.0, "rss_mb": 50.0, "threads": 4, "write_mb": 1.0}
        m.rows.append({"t": 100.0, "ui": base, "host": None, "state_kb": 11.0})
        m.rows.append({"t": 160.0, "ui": dict(base, cpu_s=4.0, write_mb=2.0), "host": {"cpu_s": 7.0, "rss_mb": 80.0, "threads": 9, "write_mb": 7.0},
                       "state_kb": 11.8})
        m.note_refresh(0.010)
        m.note_refresh(0.030)
        txt = m.report()
        self.assertIn("CPU 5.0%", txt)                                  # (4-1)s / 60s
        self.assertIn("60.0 MB/giờ", txt)                               # 1 MB / 60 s
        self.assertIn("TB 20.0 ms", txt)
        self.assertIn("KHÔNG tự suy ra % giảm tải", txt)

    def test_sample_rate_limited(self):
        m = loadprobe.LoadMeter(every=5.0)
        self.assertTrue(m.sample(now=100.0))
        self.assertFalse(m.sample(now=102.0))
        self.assertTrue(m.sample(now=106.0))

    def test_loadbench_runs_small(self):
        from pyea import loadbench
        o = loadbench.run(n_bots=2, seconds=130, n_ind=3)
        self.assertGreater(o["total_ms_per_s"], 0)
        self.assertLess(o["state_bytes"], 30000)                         # đã tách chart tĩnh
        self.assertIn("TỔNG", loadbench.report(o))


class TestLoadDialog(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_button_and_dialog(self):
        import test_ui_smoke as T
        app = T.make_app()
        self.assertTrue(any("Tải thiết bị" in str(getattr(w, "text", "")) for w in T.walk(app.settings_tab)))
        app.load_dialog()
        self.assertIn("Tải thiết bị", kivy_stub.OPEN_POPUPS[-1].title)
        app.refresh(0.0)                                                  # vòng cập nhật vẫn chạy khi có đo tải
        self.assertGreaterEqual(app.meter.ref_n, 1)


if __name__ == "__main__":
    unittest.main()


class TestLazyTabsAndFps(unittest.TestCase):
    def test_hidden_tabs_skip_update_and_catch_up_on_switch(self):
        import test_ui_smoke as T
        app = T.make_app()
        calls = []
        for name in ("market_tab", "trade_tab", "chart_tab", "ai_tab"):
            tab = getattr(app, name)
            orig = tab.update
            tab.update = (lambda n, f: (lambda *a, **k: (calls.append(n), f(*a, **k))[1]))(name, orig)

        class RP:
            current_tab = None
        app.root_panel, app.tabs = RP(), {"market": object(), "trade": object(), "chart": object(), "ai": object(), "bots": object()}
        RP.current_tab = app.tabs["market"]
        app.refresh(0.0)
        self.assertEqual(calls, ["market_tab"])                          # chỉ tab đang xem được vẽ
        calls.clear()
        RP.current_tab = app.tabs["chart"]
        app._catch_up()
        self.assertIn("chart_tab", calls)                                 # chuyển tab -> cập nhật ngay
        self.assertNotIn("market_tab", calls)
        app.lazy_tabs = False
        calls.clear()
        app.refresh(0.0)
        self.assertEqual(set(calls), {"market_tab", "trade_tab", "chart_tab", "ai_tab"})

    def test_unknown_tab_state_means_visible(self):
        import test_ui_smoke as T
        app = T.make_app()
        self.assertTrue(app.tab_visible("chart"))
        app.root_panel, app.tabs = type("R", (), {"current_tab": None})(), {"chart": object()}
        self.assertTrue(app.tab_visible("chart"))

    def test_idle_fps_drops_after_inactivity_and_restores_on_touch(self):
        import test_ui_smoke as T
        from kivy.clock import Clock
        app = T.make_app()
        Clock._max_fps = 60.0
        app._fps_full = None
        app.settings["idle_fps_save"] = True
        app._last_touch = __import__("time").time() - 60
        app._fps_check()
        self.assertEqual(Clock._max_fps, 20.0)
        app._on_motion()
        self.assertEqual(Clock._max_fps, 60.0)
        app._last_touch = __import__("time").time() - 60
        app.settings["idle_fps_save"] = False                             # tắt trong Cài đặt: không hạ
        app._fps_check()
        self.assertEqual(Clock._max_fps, 60.0)


class TestProfilerText(unittest.TestCase):
    def test_lists_callbacks_flags_slow_and_handles_empty(self):
        from pyea.loadprobe import profiler_text
        self.assertIn("chưa có bot", profiler_text([]))
        inst = [{"bot": "ma_cross", "iid": "b0", "symbol": "BTCUSD", "tf": "1m",
                 "metrics": {"errors": 2, "last_error": "ZeroDivisionError: x", "callbacks": {"on_tick": {"n": 100, "avg_ms": 0.4, "max_ms": 3.0},
                                                                                           "on_bar": {"n": 5, "avg_ms": 80.0, "max_ms": 120.0}}}},
                {"bot": "x", "iid": "b1", "metrics": {}}]
        t = profiler_text(inst)
        self.assertIn("ma_cross (BTCUSD 1m)  lỗi: 2", t)
        self.assertIn("on_tick", t)
        self.assertEqual(t.count("CHẬM"), 1)                    # chỉ on_bar (TB 80 ms) bị cảnh báo
        self.assertIn("ZeroDivisionError", t)
        self.assertNotIn("x (", t)                              # bot không có số đo thì bỏ qua
