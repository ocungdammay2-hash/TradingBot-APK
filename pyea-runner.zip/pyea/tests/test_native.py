"""Lệnh chờ NATIVE trên sàn, kết quả lệnh, đồng bộ lịch sử + số dư, đối soát Binance Spot."""
import os
import sys
import time
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX, FakeOandaX                              # noqa: E402
from pyea.backtest import _ReplayFeed                                            # noqa: E402
from pyea.broker import BinanceBroker, BinanceFuturesBroker, BrokerError, Fill, OandaBroker      # noqa: E402
from pyea.engine import Account, TradingSession                                  # noqa: E402
from pyea.sdk import Ret, Tick                                                   # noqa: E402
from pyea.settings import default_settings                                       # noqa: E402


# =========================================================================================== broker + HTTP
class TestBinanceNative(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.spot = BinanceBroker("key123", "sekret", self.fx.base)
        self.fut = BinanceFuturesBroker("key123", "sekret", self.fx.base)

    def _post(self, path_part):
        return [c for c in self.fx.calls if c[0] == "POST" and path_part in c[1]]

    def test_spot_limit_lifecycle(self):
        self.spot.prepare("BTCUSDT")
        nid = self.spot.place_pending("BTCUSDT", "buy", "limit", 0.0105, 95.123)
        sent = self._post("/api/v3/order")[0][2]
        self.assertEqual((sent["type"], sent["timeInForce"], sent["price"], sent["quantity"]), ("LIMIT", "GTC", "95.12", "0.010"))
        self.assertTrue(sent["newClientOrderId"].startswith("pyea"))
        self.assertIn(nid, self.spot.pending_orders())
        self.assertEqual(self.spot.order_result(nid, "BTCUSDT"), {"state": "open"})
        self.fx.fill("spot", nid)
        self.assertNotIn(nid, self.spot.pending_orders())
        r = self.spot.order_result(nid, "BTCUSDT")
        self.assertEqual(r["state"], "filled")
        self.assertAlmostEqual(r["price"], 95.12, 6)
        self.assertAlmostEqual(r["qty"], 0.010 - 0.010 * 0.001, 9)           # phí mua tính bằng coin nhận về -> trừ

    def test_spot_stop_uses_stop_loss_type_with_stop_price(self):
        self.fx.spot["bal"]["BTC"] = 0.05                                   # Spot: lệnh BÁN chờ cần có coin (sàn giả khoá coin như sàn thật)
        self.spot.place_pending("BTCUSDT", "sell", "stop", 0.01, 90.0)
        sent = self._post("/api/v3/order")[0][2]
        self.assertEqual((sent["type"], sent["stopPrice"]), ("STOP_LOSS", "90.00"))
        self.assertNotIn("price", sent)

    def test_futures_stop_goes_through_algo_order_and_fills(self):
        nid = self.fut.place_pending("BTCUSDT", "sell", "stop", 0.05, 90.0)
        self.assertTrue(nid.startswith("algo:"))
        self.assertEqual(self._post("/fapi/v1/order"), [])                      # KHÔNG gửi STOP_MARKET qua /order nữa (sẽ bị -4120)
        sent = self._post("/fapi/v1/algoOrder")[0][2]
        self.assertEqual((sent["algoType"], sent["type"], sent["triggerPrice"], sent["quantity"]), ("CONDITIONAL", "STOP_MARKET", "90.00", "0.050"))
        self.assertNotIn("stopPrice", sent)
        self.assertEqual(self.fut.order_result(nid, "BTCUSDT"), {"state": "open"})
        self.assertIn(nid, self.fut.pending_orders())
        self.fx.fill_algo(nid[5:])
        r = self.fut.order_result(nid, "BTCUSDT")
        self.assertEqual((r["state"], r["price"], r["qty"]), ("filled", 90.0, 0.05))
        self.assertNotIn(nid, self.fut.pending_orders())
        self.assertAlmostEqual(self.fut.positions()["BTCUSDT"]["qty"], -0.05, 9)

    def test_legacy_stop_endpoint_is_rejected_like_the_real_exchange(self):
        """Khoá lại hành vi thật của sàn: STOP_MARKET qua /fapi/v1/order -> -4120 (nên vỏ phải dùng algoOrder)."""
        with self.assertRaises(BrokerError) as cm:
            self.fut._signed("POST", "/fapi/v1/order", {"symbol": "BTCUSDT", "side": "SELL", "type": "STOP_MARKET", "quantity": "0.05", "stopPrice": "90"})
        self.assertIn("-4120", str(cm.exception))

    def test_futures_algo_cancel_modify_and_restart(self):
        nid = self.fut.place_pending("BTCUSDT", "buy", "stop", 0.05, 105.0)
        new = self.fut.modify_pending(nid, "BTCUSDT", price=106.5)
        self.assertNotEqual(new, nid)
        self.assertEqual(self.fx.fut["algo"][nid[5:]]["algoStatus"], "CANCELED")
        a = self.fx.fut["algo"][new[5:]]
        self.assertEqual((a["algoStatus"], a["triggerPrice"], a["quantity"], a["side"]), ("NEW", "106.50", "0.050", "BUY"))
        self.assertEqual(self.fut.modify_pending(new, "BTCUSDT"), new)             # không đổi giá -> không làm gì
        self.assertEqual(self.fut.order_result(nid, "BTCUSDT")["state"], "canceled")
        fresh = BinanceFuturesBroker("key123", "sekret", self.fx.base)            # khởi động lại: broker mới không nhớ gì
        self.assertEqual(fresh.pending_orders(), {})
        self.assertIn(new, fresh.pending_orders([(new, "BTCUSDT")]))
        self.assertTrue(fresh.cancel_pending(new, "BTCUSDT"))
        self.assertEqual(fresh.order_result(new, "BTCUSDT")["state"], "canceled")
        with self.assertRaises(BrokerError):
            fresh.cancel_pending(new, "BTCUSDT")                                  # huỷ lần hai -> lỗi như sàn thật

    def test_futures_algo_rejected_and_finished_without_order(self):
        nid = self.fut.place_pending("BTCUSDT", "sell", "stop", 0.05, 90.0)
        self.fx.fut["algo"][nid[5:]]["algoStatus"] = "REJECTED"
        self.assertEqual(self.fut.order_result(nid, "BTCUSDT")["state"], "rejected")
        nid2 = self.fut.place_pending("BTCUSDT", "sell", "stop", 0.05, 90.0)
        a = self.fx.fut["algo"][nid2[5:]]
        a.update(algoStatus="FINISHED", actualOrderId="", actualPrice="89.5")
        r = self.fut.order_result(nid2, "BTCUSDT")
        self.assertEqual((r["state"], r["price"], r["qty"]), ("filled", 89.5, 0.05))
        nid3 = self.fut.place_pending("BTCUSDT", "sell", "stop", 0.05, 90.0)
        self.fx.fut["algo"][nid3[5:]].update(algoStatus="FINISHED", actualOrderId="", actualPrice="0.00000")
        self.assertEqual(self.fut.order_result(nid3, "BTCUSDT")["state"], "unknown")      # không biết gì -> để engine suy luận từ vị thế

    def test_unsupported_kind(self):
        with self.assertRaises(BrokerError):
            self.spot.place_pending("BTCUSDT", "buy", "stop_limit", 0.01, 90.0, stop_price=91.0)

    def test_cancel_and_unknown(self):
        nid = self.spot.place_pending("BTCUSDT", "buy", "limit", 0.01, 90.0)
        self.assertTrue(self.spot.cancel_pending(nid, "BTCUSDT"))
        self.assertEqual(self.spot.order_result(nid, "BTCUSDT")["state"], "canceled")
        with self.assertRaises(BrokerError) as cm:
            self.spot.cancel_pending(nid, "BTCUSDT")
        self.assertIn("-2011", str(cm.exception))

    def test_expired_with_partial_fill_counts_as_filled(self):
        nid = self.fut.place_pending("BTCUSDT", "buy", "limit", 0.2, 95.0)
        o = self.fx.fut["orders"][nid]
        o["executedQty"], o["px"], o["status"] = "0.100", 95.0, "EXPIRED"
        r = self.fut.order_result(nid, "BTCUSDT")
        self.assertEqual((r["state"], r["qty"], r["price"]), ("filled", 0.1, 95.0))

    def test_modify_is_cancel_plus_new_order_with_new_id(self):
        nid = self.fut.place_pending("BTCUSDT", "buy", "limit", 0.05, 95.0)
        new = self.fut.modify_pending(nid, "BTCUSDT", price=96.5)
        self.assertNotEqual(new, nid)
        self.assertEqual(self.fx.fut["orders"][nid]["status"], "CANCELED")
        o = self.fx.fut["orders"][new]
        self.assertEqual((o["status"], o["price"], o["origQty"], o["side"]), ("NEW", "96.50", "0.050", "BUY"))
        self.assertEqual(self.fut.modify_pending(new, "BTCUSDT"), new)        # không đổi giá -> không làm gì

    def test_pending_orders_works_after_restart_via_known(self):
        nid = self.fut.place_pending("BTCUSDT", "buy", "limit", 0.05, 95.0)
        fresh = BinanceFuturesBroker("key123", "sekret", self.fx.base)        # "khởi động lại": broker mới không nhớ gì
        self.assertEqual(fresh.pending_orders(), {})
        self.assertIn(nid, fresh.pending_orders([(nid, "BTCUSDT")]))
        self.assertEqual(fresh.order_result(nid, "BTCUSDT"), {"state": "open"})

    def test_history_and_balance_spot(self):
        self.spot.prepare("BTCUSDT")
        self.spot.market_order("BTCUSDT", "buy", 0.02)
        h = self.spot.history(0, ["BTCUSDT"])
        self.assertEqual(len(h), 1)
        self.assertEqual((h[0]["symbol"], h[0]["side"], h[0]["qty"], h[0]["fee_asset"]), ("BTCUSDT", "buy", 0.02, "BTC"))
        self.assertAlmostEqual(self.spot.balance(), 5000.0 - 0.02 * 100.0, 6)  # quote USDT sau khi mua 0.02 BTC @ 100

    def test_history_futures_uses_7day_windows(self):
        self.fut.prepare("BTCUSDT")
        self.fut.market_order("BTCUSDT", "buy", 0.02)
        self.fx.calls.clear()
        h = self.fut.history(time.time() - 20 * 86400, ["BTCUSDT"])
        self.assertEqual(len(h), 1)
        wins = [c for c in self.fx.calls if c[1].endswith("/userTrades")]
        self.assertEqual(len(wins), 3)                                         # 20 ngày -> 3 cửa sổ <= 7 ngày
        for c in wins:
            self.assertLessEqual((int(c[2]["endTime"]) - int(c[2]["startTime"])) / 1000.0, 7 * 86400)
        self.assertAlmostEqual(self.fut.balance(), 5000.0, 6)                  # walletBalance, không phải availableBalance

    def test_history_futures_no_gap_between_windows(self):
        """Lệnh khớp nằm sát ranh giới hai cửa sổ 7 ngày không được rơi vào khe hở."""
        self.fut.prepare("BTCUSDT")
        now = time.time()
        for off in (0.0, 0.4, 0.999, 1.0, 1.5):                                # ngay sau/ trước điểm cắt cửa sổ đầu
            self.fx.fut["trades"].append({"id": len(self.fx.fut["trades"]) + 1, "orderId": 1, "price": "100", "qty": "0.1", "symbol": "BTCUSDT",
                                          "side": "BUY", "commission": "0", "commissionAsset": "USDT", "realizedPnl": "0",
                                          "time": int((now - 7 * 86400 + off + 3.0) * 1000)})
        self.fx.fut["trades"].append({"id": 99, "orderId": 2, "price": "100", "qty": "0.1", "symbol": "BTCUSDT", "side": "BUY", "commission": "0",
                                      "commissionAsset": "USDT", "realizedPnl": "0", "time": int((time.time() - 0.2) * 1000)})
        h = self.fut.history(now - 7 * 86400 + 2.0, ["BTCUSDT"])
        self.assertEqual(len(h), 6)

    def test_spot_positions_are_balances_of_watched_symbols_only(self):
        self.fx.spot["bal"]["BTC"] = 0.3
        self.assertEqual(self.spot.positions(), {})                            # chưa set_watch -> không biết quan tâm mã nào
        self.spot.set_watch({"BTCUSDT"})
        self.assertAlmostEqual(self.spot.positions()["BTCUSDT"]["qty"], 0.3, 9)
        self.fx.spot["bal"]["BTC"] = 0.0
        self.assertEqual(self.spot.positions(), {})


class TestOandaNative(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeOandaX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.b = OandaBroker(self.fx.TOKEN, self.fx.ACC, self.fx.base)

    def test_limit_lifecycle_precision_and_fill_via_transaction(self):
        nid = self.b.place_pending("EUR_USD", "buy", "limit", 1000, 1.09)
        sent = [c for c in self.fx.calls if c[0] == "POST" and c[1].endswith("/orders")][0][3]["order"]
        self.assertEqual((sent["type"], sent["units"], sent["price"], sent["timeInForce"]), ("LIMIT", "1000", "1.09000", "GTC"))
        self.assertEqual(sent["clientExtensions"]["tag"], "pyea")
        self.assertIn(nid, self.b.pending_orders())
        self.assertEqual(self.b.order_result(nid), {"state": "open"})
        self.fx.fill(nid, 1.0899)
        self.assertNotIn(nid, self.b.pending_orders())
        r = self.b.order_result(nid)
        self.assertEqual((r["state"], r["price"], r["qty"]), ("filled", 1.0899, 1000.0))

    def test_sell_stop_has_negative_units_and_gtd(self):
        self.b.place_pending("EUR_USD", "sell", "stop", 500, 1.05, expiry=1_800_000_000)
        sent = [c for c in self.fx.calls if c[0] == "POST" and c[1].endswith("/orders")][0][3]["order"]
        self.assertEqual((sent["type"], sent["units"], sent["timeInForce"]), ("STOP", "-500", "GTD"))
        self.assertTrue(sent["gtdTime"].endswith("Z"))

    def test_cancel_and_cancel_reasons(self):
        nid = self.b.place_pending("EUR_USD", "buy", "limit", 100, 1.0)
        self.assertTrue(self.b.cancel_pending(nid))
        self.assertEqual(self.b.order_result(nid)["state"], "canceled")
        n2 = self.b.place_pending("EUR_USD", "buy", "limit", 100, 1.0)
        self.fx.cancel_external(n2, "TIME_IN_FORCE_EXPIRED")
        self.assertEqual(self.b.order_result(n2)["state"], "expired")
        with self.assertRaises(BrokerError):
            self.b.cancel_pending(nid)

    def test_modify_replaces_with_new_id_and_keeps_fields(self):
        nid = self.b.place_pending("EUR_USD", "buy", "limit", 1000, 1.09)
        new = self.b.modify_pending(nid, price=1.0950)
        self.assertNotEqual(new, nid)
        self.assertEqual(self.fx.orders[nid]["state"], "CANCELLED")
        o = self.fx.orders[new]
        self.assertEqual((o["price"], o["units"], o["instrument"], o["state"]), ("1.09500", "1000", "EUR_USD", "PENDING"))

    def test_precision_error_surfaces_clear_message(self):
        # lệnh sai độ chính xác bị sàn từ chối -> BrokerError có lý do
        self.fx.orders.clear()
        b = OandaBroker(self.fx.TOKEN, self.fx.ACC, self.fx.base)
        b._prec_cache = {"EUR_USD": 3}                       # ép sai độ chính xác (giả lập sàn đổi cấu hình)
        with self.assertRaises(BrokerError) as cm:
            b.place_pending("EUR_USD", "buy", "limit", 100, 1.0)
        self.assertIn("PRICE_PRECISION", str(cm.exception))

    def test_history_balance_positions(self):
        self.b.market_order("EUR_USD", "buy", 1000)
        h = self.b.history(0)
        self.assertEqual(len(h), 1)
        self.assertEqual((h[0]["symbol"], h[0]["side"], h[0]["qty"], h[0]["price"]), ("EUR_USD", "buy", 1000.0, 1.1))
        self.assertGreater(h[0]["time"], 1_700_000_000)
        self.assertEqual(self.b.balance(), 10000.0)
        self.assertEqual(self.b.positions()["EUR_USD"]["qty"], 1000.0)


# =========================================================================================== engine
class NativeBroker:
    """Broker giả (không HTTP) để kiểm soát từng tình huống của engine."""
    supports_short, netting = True, False
    native_pending = {"limit", "stop"}

    def __init__(self):
        self.orders, self.n, self.results = {}, 100, {}
        self.cancel_fail = self.place_fail = self.modify_fail = self.modify_new_id = self.list_fail = None
        self.market_calls, self.cancel_calls, self.modify_calls, self.place_calls = [], [], [], []
        self.remote_pos = {}

    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if self.place_fail:
            raise BrokerError(self.place_fail)
        self.n += 1
        nid = str(self.n)
        self.orders[nid] = {"symbol": symbol, "side": side, "kind": kind, "volume": volume, "price": price, "open": True}
        self.place_calls.append((nid, symbol, side, kind, volume, price, expiry))
        return nid

    def cancel_pending(self, nid, symbol=None):
        self.cancel_calls.append(nid)
        if self.cancel_fail:
            raise BrokerError(self.cancel_fail)
        self.orders[nid]["open"] = False
        return True

    def modify_pending(self, nid, symbol=None, price=None, sl=None, tp=None):
        self.modify_calls.append((nid, price, sl, tp))
        if self.modify_fail:
            raise BrokerError(self.modify_fail)
        if self.modify_new_id:
            self.orders[self.modify_new_id] = dict(self.orders.pop(nid), price=price or self.orders[nid]["price"])
            return self.modify_new_id
        self.orders[nid]["price"] = price or self.orders[nid]["price"]
        return True

    def pending_orders(self, known=None):
        if self.list_fail:
            raise BrokerError(self.list_fail)
        return {k: v for k, v in self.orders.items() if v["open"]}

    def order_result(self, nid, symbol=None):
        return self.results.get(nid)

    def positions(self):
        return self.remote_pos

    def market_order(self, symbol, side, qty, reduce_only=False):
        self.market_calls.append((symbol, side, qty, reduce_only))
        return Fill(100.0, qty)

    # ---- điều khiển từ test ----
    def exchange_fill(self, nid, price, qty=None, with_result=True):
        o = self.orders[nid]
        o["open"] = False
        q = qty if qty is not None else o["volume"]
        if with_result:
            self.results[nid] = {"state": "filled", "price": price, "qty": q}
        cur = self.remote_pos.get(o["symbol"], {"qty": 0.0, "price": 0.0})["qty"]
        self.remote_pos[o["symbol"]] = {"qty": cur + (q if o["side"] == "buy" else -q), "price": price}

    def exchange_cancel(self, nid, state="canceled", with_result=True):
        self.orders[nid]["open"] = False
        if with_result:
            self.results[nid] = {"state": state}


def make(**over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0,
              native_sync_s=0.5)
    st.update(over)
    alarms = []
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), alarm_cb=lambda t, x: alarms.append(t))
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = ["BTCUSDT"]
    s.alarms = alarms
    s.broker = NativeBroker()
    return s


def tk(s, px=100.0, t=1000.0, sym="BTCUSDT"):
    s.process_tick(Tick(sym, t, px, px))


class TestEngineNative(unittest.TestCase):
    def test_native_order_is_sent_to_exchange_and_not_tracked_locally(self):
        s = make()
        tk(s, 100.0)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        self.assertTrue(r.ok, r.message)
        o = s.account.pending[r.order.id]
        self.assertTrue(o.native_id)
        self.assertEqual(s.broker.place_calls[0][1:6], ("BTCUSDT", "buy", "limit", 0.5, 95.0))
        tk(s, 90.0, 1001.0)                                           # giá xuyên qua mức đặt: vỏ KHÔNG tự khớp
        self.assertIn(o.id, s.account.pending)
        self.assertEqual(s.account.positions, {})
        self.assertEqual(s.broker.market_calls, [])
        ev = [e for e in s.events if e.kind == "pending"][0]
        self.assertIn("trên sàn", str(ev.details.get("nơi giữ lệnh")))

    def test_exchange_fill_becomes_position_same_id_without_market_order(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0, sl=90.0, tp=110.0, owner="manual")
        oid, nid = r.order.id, s.account.pending[r.order.id].native_id
        s.broker.exchange_fill(nid, 95.2, 0.4995)
        s._sync_native_pending(force=True)
        self.assertEqual(s.account.pending, {})
        p = s.account.positions[oid]                                   # vị thế GIỮ id của lệnh chờ
        self.assertEqual((p.side, p.open_price, p.volume, p.sl, p.tp), ("buy", 95.2, 0.4995, 90.0, 110.0))
        self.assertEqual(s.broker.market_calls, [])                    # KHÔNG gửi lại lệnh thị trường
        self.assertTrue(any(e.kind == "open" and e.pos_id == oid for e in s.events))

    def test_app_side_sl_tp_works_after_native_fill(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0, sl=90.0)
        s.broker.exchange_fill(s.account.pending[r.order.id].native_id, 95.0)
        s._sync_native_pending(force=True)
        tk(s, 89.0, 1002.0)                                            # chạm SL do vỏ giữ
        self.assertEqual(s.account.positions, {})
        self.assertEqual(s.broker.market_calls[-1][3], True)           # đóng bằng lệnh reduce_only

    def test_sync_is_rate_limited_unless_forced(self):
        s = make()
        tk(s)
        s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        calls = []
        orig = s.broker.pending_orders
        s.broker.pending_orders = lambda known=None: (calls.append(1), orig(known))[1]
        s._sync_native_pending()
        s._sync_native_pending()
        s._sync_native_pending()
        self.assertEqual(len(calls), 1)
        s._sync_native_pending(force=True)
        self.assertEqual(len(calls), 2)

    def test_cancel_native(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        c = s.cancel_order(r.order.id)
        self.assertTrue(c.ok)
        self.assertEqual(s.broker.cancel_calls, [nid])
        self.assertEqual(s.account.pending, {})

    def test_cancel_rejected_by_exchange_keeps_order(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        s.broker.cancel_fail = "network down"
        c = s.cancel_order(r.order.id)
        self.assertFalse(c.ok)
        self.assertEqual(c.retcode, Ret.REJECTED)
        self.assertIn(r.order.id, s.account.pending)                   # KHÔNG xoá lệnh còn sống trên sàn

    def test_cancel_failing_because_order_just_filled_adopts_the_fill(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        s.broker.exchange_fill(nid, 95.0)
        s.broker.cancel_fail = "Unknown order"                         # sàn: không huỷ được vì đã khớp
        c = s.cancel_order(r.order.id)
        self.assertFalse(c.ok)
        self.assertEqual(c.retcode, Ret.NOT_FOUND)
        self.assertIn(r.order.id, s.account.positions)                 # fill được ghi sổ, không mất

    def test_modify_native_updates_price_and_new_exchange_id(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        old = s.account.pending[r.order.id].native_id
        s.broker.modify_new_id = "777"
        m = s.modify_order(r.order.id, price=96.0)
        self.assertTrue(m.ok, m.message)
        o = s.account.pending[r.order.id]
        self.assertEqual((o.price, o.native_id), (96.0, "777"))
        self.assertEqual(s.broker.modify_calls, [(old, 96.0, None, None)])

    def test_modify_rejected_leaves_local_order_unchanged(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        s.broker.modify_fail = "rate limited"
        m = s.modify_order(r.order.id, price=96.0)
        self.assertFalse(m.ok)
        self.assertEqual(s.account.pending[r.order.id].price, 95.0)

    def test_expiration_cancels_on_exchange(self):
        s = make()
        tk(s, 100.0, 1000.0)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0, expiration=1010.0)
        nid = s.account.pending[r.order.id].native_id
        self.assertEqual(s.broker.place_calls[0][6], 1010.0)           # truyền hạn xuống sàn (sàn nào hỗ trợ sẽ tự huỷ)
        tk(s, 100.0, 1020.0)
        self.assertEqual(s.account.pending, {})
        self.assertEqual(s.broker.cancel_calls, [nid])                 # và vỏ cũng chủ động huỷ để chắc chắn

    def test_exchange_side_cancel_removes_local_order(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        s.broker.exchange_cancel(s.account.pending[r.order.id].native_id, "expired")
        s._sync_native_pending(force=True)
        self.assertEqual(s.account.pending, {})
        self.assertEqual(s.broker.cancel_calls, [])                    # đã biến mất khỏi sàn -> không gọi huỷ lần nữa
        ev = [e for e in s.events if e.kind == "cancel"][-1]
        self.assertIn("không còn trên sàn", ev.reason)

    def test_unknown_result_infers_fill_from_position_diff(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        s.broker.exchange_fill(nid, 95.2, with_result=False)           # sàn không cho biết kết quả lệnh
        s._sync_native_pending(force=True)
        p = s.account.positions[r.order.id]
        self.assertEqual((p.volume, p.open_price), (0.5, 95.2))

    def test_unknown_result_infers_cancel_when_no_position_appeared(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        s.broker.exchange_cancel(s.account.pending[r.order.id].native_id, with_result=False)
        s._sync_native_pending(force=True)
        self.assertEqual((s.account.pending, s.account.positions), ({}, {}))

    def test_open_state_from_exchange_keeps_order(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        s.broker.orders[nid]["open"] = False                           # danh sách lệnh chờ chưa phản ánh...
        s.broker.results[nid] = {"state": "open"}                      # ...nhưng sàn nói lệnh vẫn sống
        s._sync_native_pending(force=True)
        self.assertIn(r.order.id, s.account.pending)

    def test_listing_error_keeps_orders_and_warns_once_a_minute(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        s.broker.list_fail = "502"
        for _ in range(3):
            s._sync_native_pending(force=True)
        self.assertIn(r.order.id, s.account.pending)
        warns = [l for l in s.logs if "Không đồng bộ được lệnh chờ" in l[3]]
        self.assertEqual(len(warns), 1)

    def test_place_failure_rejected_and_nothing_stored(self):
        s = make()
        tk(s)
        s.broker.place_fail = "insufficient balance"
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        self.assertFalse(r.ok)
        self.assertEqual(r.retcode, Ret.REJECTED)
        self.assertEqual(s.account.pending, {})

    def test_modes(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "stop_limit", 0.5, 101.0, stop_price=102.0)      # sàn không có native stop_limit
        self.assertTrue(r.ok)
        self.assertEqual(s.account.pending[r.order.id].native_id, "")                           # auto -> vỏ tự theo dõi
        s2 = make(pending_mode="native")
        tk(s2)
        r2 = s2.place_pending("BTCUSDT", "buy", "stop_limit", 0.5, 101.0, stop_price=102.0)
        self.assertFalse(r2.ok)
        self.assertEqual(r2.retcode, Ret.NOT_SUPPORTED)
        s3 = make(pending_mode="emulated")
        tk(s3)
        r3 = s3.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        self.assertTrue(r3.ok)
        self.assertEqual((s3.account.pending[r3.order.id].native_id, s3.broker.place_calls), ("", []))
        tk(s3, 94.0, 1001.0)                                                                    # emulated: vỏ tự khớp như cũ
        self.assertEqual(len(s3.account.positions), 1)
        self.assertEqual(s3.broker.market_calls[0][:2], ("BTCUSDT", "buy"))

    def test_paper_mode_without_broker_is_unchanged(self):
        s = make()
        s.broker = None
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        self.assertEqual(s.account.pending[r.order.id].native_id, "")
        tk(s, 94.0, 1001.0)
        self.assertEqual(len(s.account.positions), 1)

    def test_native_id_survives_save_and_restore(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        d = s.account.to_dict()
        a2 = Account(100000.0, 0.0, 1.0)
        a2.restore(d)
        self.assertEqual(a2.pending[r.order.id].native_id, nid)

    def test_restored_native_order_resolves_after_restart(self):
        s = make()
        tk(s)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0)
        nid = s.account.pending[r.order.id].native_id
        s2 = make()
        s2.account.restore(s.account.to_dict())
        s2.broker = s.broker                                             # cùng sàn
        s.broker.exchange_fill(nid, 95.0)
        tk(s2)
        s2._sync_native_pending(force=True)
        self.assertIn(r.order.id, s2.account.positions)

    def test_cancel_all_and_kill_switch_cancel_natively(self):
        s = make()
        tk(s)
        for px in (95.0, 94.0):
            s.place_pending("BTCUSDT", "buy", "limit", 0.1, px)
        self.assertEqual(s.cancel_all_orders(), 2)
        self.assertEqual(len(s.broker.cancel_calls), 2)


# =========================================================================================== engine + HTTP thật
class TestEngineWithBinanceFutures(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()

    def test_full_cycle_place_fill_reconcile(self):
        s = make()
        s.broker = BinanceFuturesBroker("key123", "sekret", self.fx.base)
        s.broker.prepare("BTCUSDT")
        tk(s, 100.0)
        r = s.place_pending("BTCUSDT", "buy", "limit", 0.05, 95.0)
        self.assertTrue(r.ok, r.message)
        nid = s.account.pending[r.order.id].native_id
        self.assertIn(nid, self.fx.fut["orders"])
        s._sync_native_pending(force=True)
        self.assertIn(r.order.id, s.account.pending)                    # còn sống trên sàn
        self.fx.fill("fut", nid, 95.0)
        s._sync_native_pending(force=True)
        p = s.account.positions[r.order.id]
        self.assertEqual((p.volume, p.open_price), (0.05, 95.0))
        self.assertEqual(s.reconcile_now(), [])                         # sàn có 0.05 = sổ app 0.05 -> khớp
        c = s.cancel_order(s.place_pending("BTCUSDT", "buy", "limit", 0.05, 90.0).order.id)
        self.assertTrue(c.ok)
        self.assertEqual(self.fx.fut["orders"][str(int(nid) + 1)]["status"], "CANCELED")


class TestSpotReconcile(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()

    def _session(self, **over):
        s = make(exchange="binance_spot", **over)
        s.broker = BinanceBroker("key123", "sekret", self.fx.base)
        s.broker.prepare("BTCUSDT")
        return s

    def test_external_coins_are_not_reported(self):
        self.fx.spot["bal"]["BTC"] = 1.5                                  # coin có sẵn trong ví, app chưa mở gì
        s = self._session()
        tk(s)
        self.assertEqual(s.reconcile_now(), [])
        self.assertIs(s.recon["ok"], True)
        r = s.send_order("BTCUSDT", "buy", 0.02)                           # app mua thêm
        self.assertTrue(r.ok, r.message)
        self.assertEqual(s.reconcile_now(), [])                            # ví 1.52 >= sổ app 0.02 -> ổn

    def test_wallet_shortfall_is_reported_with_spot_wording(self):
        s = self._session()
        tk(s)
        s.send_order("BTCUSDT", "buy", 0.02)
        self.fx.spot["bal"]["BTC"] = 0.005                                 # ví chỉ còn 0.005 < sổ app 0.02 (bán ở nơi khác)
        issues = s.reconcile_now()
        self.assertEqual([i["kind"] for i in issues], ["mismatch"])
        self.assertIn("ÍT hơn", issues[0]["text"])
        self.assertEqual(len(s.alarms), 1)
        self.fx.spot["bal"]["BTC"] = 0.0
        self.assertEqual([i["kind"] for i in s.reconcile_now()], ["ghost"])
        self.assertIn("còn coin này", s.reconcile_now()[0]["text"])

    def test_adopt_cuts_book_to_wallet_without_importing_external_coins(self):
        s = self._session(reconcile_policy="adopt")
        tk(s)
        def adopt_now():                                                   # adopt chỉ sửa khi thấy cùng chênh lệch hai lần liên tiếp
            first = s.reconcile_now()
            for k in list(s._recon_pending):
                s._recon_pending[k] -= 60.0
            return s.reconcile_now() if first else first
        s.send_order("BTCUSDT", "buy", 0.04)
        self.fx.spot["bal"]["BTC"] = 0.01
        adopt_now()
        self.assertAlmostEqual(sum(p.volume for p in s.account.positions.values()), 0.01, 9)
        self.fx.spot["bal"]["BTC"] = 3.0                                   # ví nhiều hơn nhiều: KHÔNG nhập vào sổ
        adopt_now()
        self.assertAlmostEqual(sum(p.volume for p in s.account.positions.values()), 0.01, 9)
        self.fx.spot["bal"]["BTC"] = 0.0
        adopt_now()
        self.assertEqual(s.account.positions, {})

    def test_futures_reconcile_unchanged_still_strict(self):
        s = make()
        s.broker = BinanceFuturesBroker("key123", "sekret", self.fx.base)
        tk(s)
        self.fx.fut["pos"], self.fx.fut["entry"] = 0.3, 100.0
        self.assertEqual([i["kind"] for i in s.reconcile_now()], ["orphan"])   # Futures vẫn báo orphan như cũ


if __name__ == "__main__":
    unittest.main()
