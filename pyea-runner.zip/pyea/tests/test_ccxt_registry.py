"""Adapter ccxt (module ccxt GIẢ) + đăng ký các sàn mới qua settings/make_feed/make_broker/diagnostics."""
import os
import sys
import tempfile
import time
import types
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import ccxt_adapter, ratelimit                                           # noqa: E402
from pyea.broker import BrokerError, make_broker                                   # noqa: E402
from pyea.ccxt_adapter import CcxtBroker, CcxtFeed, exchange_for                   # noqa: E402
from pyea.feeds import FeedError, make_feed                                        # noqa: E402
from pyea.settings import EXCHANGE_WATCH, GLOBAL_INPUTS, clean_settings, default_settings   # noqa: E402


class FakeCcxtEx:
    """Giả lập một sàn ccxt (giao diện unified)."""
    id = "fakex"
    timeframes = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "1h"}

    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.has = {"createStopMarketOrder": True, "editOrder": False}
        self.markets = {"BTC/USDT": {"symbol": "BTC/USDT", "base": "BTC", "quote": "USDT", "spot": True, "active": True},
                        "BTC/USDT:USDT": {"symbol": "BTC/USDT:USDT", "base": "BTC", "quote": "USDT", "spot": False, "active": True}}
        self.calls, self.orders, self.n = [], {}, 0
        self.bal = {"USDT": 5000.0, "BTC": 0.0}
        self.pos = {}
        self.sandbox = False
        self.fail = None
        self.trades = []

    def set_sandbox_mode(self, v):
        self.sandbox = v

    def load_markets(self):
        self.calls.append("load_markets")
        return self.markets

    def fetch_time(self):
        return int(time.time() * 1000)

    def fetch_ticker(self, s):
        if self.fail:
            raise RuntimeError(self.fail)
        return {"bid": 100.0, "ask": 100.2, "last": 100.1, "timestamp": int(time.time() * 1000)}

    def fetch_ohlcv(self, s, tf, since=None, limit=None):
        step = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600}[tf]
        t0 = int((since or (time.time() - 100 * step) * 1000) / 1000 // step) * step
        return [[(t0 + i * step) * 1000, 100 + i, 101 + i, 99 + i, 100.5 + i, 10] for i in range(limit or 10)]

    def amount_to_precision(self, s, a):
        return "%.3f" % (int(a * 1000 + 1e-9) / 1000.0)

    def price_to_precision(self, s, p):
        return "%.2f" % p

    def fetch_balance(self):
        return {"total": dict(self.bal), "USDT": {"total": self.bal["USDT"]}}

    def set_leverage(self, lev, sym):
        self.calls.append(("set_leverage", lev, sym))

    def create_order(self, sym, typ, side, amt, price=None, params=None):
        self.calls.append(("create_order", sym, typ, side, amt, price, params))
        self.n += 1
        oid = str(self.n)
        o = {"id": oid, "symbol": sym, "type": typ, "side": side, "amount": amt, "price": price, "status": "open", "filled": 0, "remaining": amt}
        if typ == "market" and not (params or {}).get("stopPrice"):
            o.update(status="closed", filled=amt, average=100.2 if side == "buy" else 100.0)
            q = amt if side == "buy" else -amt
            if "USDT" in sym.split(":")[-1] and ":" in sym:
                self.pos[sym] = self.pos.get(sym, 0) + q
            else:
                self.bal["BTC"] += q
        self.orders[oid] = o
        return dict(o)

    def create_stop_market_order(self, sym, side, amt, trigger):
        self.calls.append(("create_stop_market_order", sym, side, amt, trigger))
        self.n += 1
        oid = str(self.n)
        self.orders[oid] = {"id": oid, "symbol": sym, "type": "stop", "side": side, "amount": amt, "price": trigger, "status": "open", "filled": 0, "remaining": amt}
        return dict(self.orders[oid])

    def cancel_order(self, oid, sym=None):
        if self.orders.get(oid, {}).get("status") != "open":
            raise RuntimeError("order not found")
        self.orders[oid]["status"] = "canceled"
        return {}

    def fetch_order(self, oid, sym=None):
        return dict(self.orders[oid])

    def fetch_open_orders(self, sym=None):
        return [dict(o) for o in self.orders.values() if o["status"] == "open" and o["symbol"] == sym]

    def fetch_positions(self, *a):
        return [{"symbol": s, "contracts": abs(q), "side": "long" if q > 0 else "short", "entryPrice": 100.2} for s, q in self.pos.items() if q]

    def fetch_my_trades(self, sym, since=None):
        return list(self.trades)

    def fill(self, oid, px):
        o = self.orders[oid]
        o.update(status="closed", filled=o["amount"], average=px)


def install_fake():
    mod = types.ModuleType("ccxt")
    mod.fakex = FakeCcxtEx
    mod.exchanges = ["fakex"]
    sys.modules["ccxt"] = mod
    ccxt_adapter._EX.clear()
    return mod


class TestCcxt(unittest.TestCase):
    def setUp(self):
        ratelimit.reset_all()
        install_fake()
        self.settings = {"exchange": "ccxt", "ccxt_id": "fakex", "ccxt_api_key": "k", "ccxt_secret": "s", "ccxt_password": "", "ccxt_options": ""}
        self.ex = exchange_for(self.settings)
        self.feed, self.b = CcxtFeed(self.ex), CcxtBroker(self.ex)

    def tearDown(self):
        sys.modules.pop("ccxt", None)
        ccxt_adapter._EX.clear()

    def test_config_passed_and_shared(self):
        self.assertEqual(self.ex.cfg["apiKey"], "k")
        self.assertTrue(self.ex.cfg["enableRateLimit"])
        self.assertIs(exchange_for(self.settings), self.ex)

    def test_sandbox_and_options(self):
        st = dict(self.settings, ccxt_options='{"sandbox": true, "options": {"defaultType": "swap"}}')
        x = exchange_for(st)
        self.assertTrue(x.sandbox)
        self.assertEqual(x.cfg["options"], {"defaultType": "swap"})
        self.assertNotIn("sandbox", x.cfg)
        with self.assertRaises(BrokerError):
            exchange_for(dict(self.settings, ccxt_options="{bad"))

    def test_missing_library_has_actionable_message(self):
        sys.modules.pop("ccxt", None)
        sys.modules["ccxt"] = None                                          # import ccxt -> ImportError
        ccxt_adapter._EX.clear()
        with self.assertRaises(BrokerError) as cm:
            exchange_for(self.settings)
        self.assertIn("buildozer.spec", str(cm.exception))
        self.assertIn("pip install ccxt", str(cm.exception))

    def test_unknown_exchange_and_missing_id(self):
        with self.assertRaises(BrokerError) as cm:
            exchange_for(dict(self.settings, ccxt_id="nope"))
        self.assertIn("nope", str(cm.exception))
        with self.assertRaises(BrokerError):
            exchange_for(dict(self.settings, ccxt_id=""))

    def test_feed_symbols_tick_history(self):
        self.assertEqual(self.feed.symbols(), ["BTC/USDT", "BTC/USDT:USDT"])
        t = self.feed.tick("BTC/USDT")
        self.assertEqual((t.bid, t.ask), (100.0, 100.2))
        cs = self.feed.history("BTC/USDT", "5m", 6)
        self.assertEqual(len(cs), 6)
        self.assertEqual(cs[1].time - cs[0].time, 300)
        past = self.feed.history("BTC/USDT", "5m", 4, end=time.time() - 7200)
        self.assertEqual(len(past), 4)
        self.assertLess(past[-1].time, time.time() - 7000)

    def test_feed_resamples_unsupported_timeframe_and_errors_are_feederrors(self):
        cs = self.feed.history("BTC/USDT", "30m", 3)                        # sàn không có 30m -> ghép từ 15m
        self.assertEqual(len(cs), 3)
        self.assertEqual(cs[1].time - cs[0].time, 1800)
        self.ex.fail = "rate limit exceeded"
        with self.assertRaises(FeedError) as cm:
            self.feed.tick("BTC/USDT")
        self.assertIn("rate limit", str(cm.exception))

    def test_spot_market_order_and_flags(self):
        bal = self.b.prepare("BTC/USDT")
        self.assertEqual(bal, 5000.0)
        self.assertEqual((self.b.supports_short, self.b.spot_like), (False, True))
        f = self.b.market_order("BTC/USDT", "buy", 0.0157)
        self.assertEqual((f.price, f.qty), (100.2, 0.015))                     # làm tròn theo bước sàn
        self.assertEqual(self.ex.calls[-1][:5], ("create_order", "BTC/USDT", "market", "buy", 0.015))
        self.b.set_watch({"BTC/USDT"})
        self.assertEqual(self.b.positions()["BTC/USDT"]["qty"], 0.015)

    def test_derivative_positions_and_reduce_only(self):
        self.b.prepare("BTC/USDT:USDT", leverage=5)
        self.assertEqual((self.b.supports_short, self.b.spot_like), (True, False))
        self.assertIn(("set_leverage", 5, "BTC/USDT:USDT"), self.ex.calls)
        self.b.market_order("BTC/USDT:USDT", "sell", 0.2)
        self.assertEqual(self.b.positions(), {"BTC/USDT:USDT": {"qty": -0.2, "price": 100.2}})
        self.b.market_order("BTC/USDT:USDT", "buy", 0.2, reduce_only=True)
        self.assertEqual(self.ex.calls[-1][6], {"reduceOnly": True})
        self.assertEqual(self.b.positions(), {})

    def test_zero_amount_after_rounding_rejected(self):
        with self.assertRaises(BrokerError):
            self.b.market_order("BTC/USDT", "buy", 0.0004)

    def test_unknown_symbol(self):
        with self.assertRaises(BrokerError):
            self.b.market_order("NOPE/USDT", "buy", 1)

    def test_native_limit_stop_cancel_modify_result(self):
        self.assertEqual(self.b.native_pending, {"limit", "stop"})
        nid = self.b.place_pending("BTC/USDT", "buy", "limit", 0.0123, 95.123)
        self.assertEqual(self.ex.calls[-1][:6], ("create_order", "BTC/USDT", "limit", "buy", 0.012, 95.12))
        self.assertIn(nid, self.b.pending_orders())
        self.assertEqual(self.b.order_result(nid, "BTC/USDT"), {"state": "open"})
        new = self.b.modify_pending(nid, "BTC/USDT", price=96.0)              # không có editOrder -> huỷ + đặt lại, mã đổi
        self.assertNotEqual(new, nid)
        self.assertEqual(self.ex.orders[nid]["status"], "canceled")
        self.ex.fill(new, 96.0)
        r = self.b.order_result(new, "BTC/USDT")
        self.assertEqual((r["state"], r["price"], r["qty"]), ("filled", 96.0, 0.012))
        sid = self.b.place_pending("BTC/USDT", "sell", "stop", 0.01, 90.0)
        self.assertEqual(self.ex.calls[-1], ("create_stop_market_order", "BTC/USDT", "sell", 0.01, 90.0))
        self.assertTrue(self.b.cancel_pending(sid, "BTC/USDT"))
        self.assertEqual(self.b.order_result(sid, "BTC/USDT")["state"], "canceled")

    def test_stop_unavailable_when_exchange_lacks_it(self):
        self.ex.has = {}
        b = CcxtBroker(self.ex)
        self.assertEqual(b.native_pending, {"limit"})
        with self.assertRaises(BrokerError):
            b.place_pending("BTC/USDT", "sell", "stop", 0.01, 90.0)

    def test_cancel_failure_is_brokererror(self):
        nid = self.b.place_pending("BTC/USDT", "buy", "limit", 0.01, 90.0)
        self.b.cancel_pending(nid, "BTC/USDT")
        with self.assertRaises(BrokerError) as cm:
            self.b.cancel_pending(nid, "BTC/USDT")
        self.assertIn("RuntimeError", str(cm.exception))

    def test_history_and_balance(self):
        self.ex.trades = [{"id": "t1", "timestamp": 1_700_000_000_000, "side": "buy", "amount": 0.1, "price": 100, "order": "9",
                           "fee": {"cost": 0.01, "currency": "USDT"}}]
        h = self.b.history(0, ["BTC/USDT"])
        self.assertEqual((h[0]["id"], h[0]["qty"], h[0]["fee"], h[0]["fee_asset"], h[0]["time"]), ("t1", 0.1, 0.01, "USDT", 1_700_000_000.0))
        self.b.prepare("BTC/USDT")
        self.assertEqual(self.b.balance(), 5000.0)


class TestRegistry(unittest.TestCase):
    def setUp(self):
        ratelimit.reset_all()
        install_fake()

    def tearDown(self):
        sys.modules.pop("ccxt", None)
        ccxt_adapter._EX.clear()

    def test_every_exchange_choice_has_a_watchlist_and_secret_fields_are_masked(self):
        for ch in GLOBAL_INPUTS["exchange"].choices:
            self.assertIn(ch, EXCHANGE_WATCH, ch)
        for k in ("exness_api_key", "exness_private_key", "metaapi_token", "mt5gw_token", "bridge_token", "ccxt_api_key", "ccxt_secret", "ccxt_password"):
            self.assertTrue(GLOBAL_INPUTS[k].secret, k)
        st = clean_settings(dict(default_settings(), exchange="exness", pending_mode="native", sync_interval="120", balance_drift_pct="2.5"))
        self.assertEqual((st["exchange"], st["pending_mode"], st["sync_interval"], st["balance_drift_pct"]), ("exness", "native", 120.0, 2.5))
        self.assertEqual(clean_settings(dict(default_settings(), exchange="nonsense"))["exchange"], "simulated")

    def test_make_feed_and_broker_pick_the_right_adapter(self):
        from pyea.bridges import MtBroker, MtFeed
        from pyea.exness import ExnBroker, ExnFeed
        st = default_settings()
        # ccxt
        c = dict(st, exchange="ccxt", ccxt_id="fakex")
        self.assertIsInstance(make_feed("ccxt", c), CcxtFeed)
        self.assertIsInstance(make_broker(c), CcxtBroker)
        # cầu nối
        g = dict(st, exchange="mt5gw", mt5gw_url="127.0.0.1:1")
        self.assertIsInstance(make_feed("mt5gw", g), MtFeed)
        self.assertIsInstance(make_broker(g), MtBroker)
        m = dict(st, exchange="metaapi", metaapi_token="t", metaapi_account="a")
        self.assertEqual(make_feed("metaapi", m).b.name, "metaapi")
        b = dict(st, exchange="bridge", bridge_profile='{"base":"http://x","ops":{}}', bridge_token="t")
        self.assertEqual(make_broker(b).b.name, "profile")
        # exness (cần khoá thật dạng hợp lệ)
        key = "-----BEGIN PRIVATE KEY-----\nMC4CAQAwBQYDK2VwBCIEIAABAgMEBQYHCAkKCwwNDg8QERITFBUWFxgZGhscHR4f\n-----END PRIVATE KEY-----"
        e = dict(st, exchange="exness", exness_api_key="exnsk_x", exness_private_key=key, exness_account="1")
        self.assertIsInstance(make_feed("exness", e), ExnFeed)
        self.assertIsInstance(make_broker(e), ExnBroker)

    def test_feed_errors_are_feederror_with_clear_message(self):
        st = default_settings()
        for kind, extra in (("exness", {}), ("mt5gw", {"mt5gw_url": ""}), ("metaapi", {}), ("ccxt", {"ccxt_id": ""})):
            with self.assertRaises(FeedError, msg=kind) as cm:
                make_feed(kind, dict(st, exchange=kind, **extra))
            self.assertTrue(str(cm.exception), kind)

    def test_broker_errors_are_brokererror(self):
        st = default_settings()
        for ex in ("exness", "mt5gw", "metaapi", "ccxt"):
            with self.assertRaises(BrokerError, msg=ex):
                make_broker(dict(st, exchange=ex))

    def test_diagnostics_reports_each_new_exchange_without_raising(self):
        from pyea import diagnostics
        d = tempfile.mkdtemp()
        for ex, extra in (("ccxt", {"ccxt_id": "fakex"}), ("mt5gw", {"mt5gw_url": "127.0.0.1:1"}), ("exness", {}), ("metaapi", {})):
            res = diagnostics.run_checks(d, dict(default_settings(), exchange=ex, **extra), network=True)
            names = " | ".join(r["name"] for r in res)
            self.assertIn("Sàn: Dựng feed", names, (ex, names))                      # mọi sàn đều ra báo cáo (LỖI nếu thiếu khoá), không ném ngoại lệ
            if ex != "ccxt":                                                          # ccxt 'fakex' là sàn giả chạy được; các sàn còn lại thiếu khoá/URL -> LỖI có mô tả
                self.assertTrue(any(r["status"] == "LỖI" and r["detail"] for r in res if r["name"].startswith("Sàn:")), (ex, names))


if __name__ == "__main__":
    unittest.main()
