"""1.9.40: khởi động nhanh - form Cài đặt dựng lười, bot chỉ nạp dần, không quét/đọc file bot hai lần."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(__file__))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import loader, ui  # noqa: E402


def fresh_app():
    app = ui.PyEAApp()
    app.user_data_dir = tempfile.mkdtemp()
    app.build()
    return app


class TestStartupPerf(unittest.TestCase):
    def setUp(self):
        kivy_stub.SCHEDULED.clear()

    def test_settings_form_lazy_but_transparent(self):
        app = fresh_app()
        st = app.settings_tab
        self.assertFalse(st.built)                          # chưa dựng ~780 widget lúc khởi động
        form = st.gform                                     # truy cập từ bất kỳ nơi nào vẫn có form đầy đủ
        self.assertTrue(st.built)
        self.assertIn("tick_interval", form.ctrl)
        self.assertIs(st.gform, form)                       # không dựng lại lần hai

    def test_only_selected_bot_inspected_at_startup(self):
        calls = []
        orig = ui.inspect_bot
        ui.inspect_bot = lambda *a, **k: (calls.append(a[0]), orig(*a, **k))[1]
        try:
            app = fresh_app()
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0], app.selected)
            n = len(app.store.list_bots())
            self.assertGreater(n, 3)
            for _ in range(n + 2):                          # các lượt Clock nạp dần
                fs = [f for f in kivy_stub.SCHEDULED if getattr(f, "__name__", "") == "_fill_infos"]
                kivy_stub.SCHEDULED.clear()
                for f in fs:
                    f()
            self.assertEqual(sorted(set(calls)), sorted(app.store.list_bots()))
            self.assertEqual(len(calls), n)                 # mỗi bot đúng một lần
            self.assertTrue(all(app.get_info(p).ok for p in app.store.list_bots()))
        finally:
            ui.inspect_bot = orig

    def test_inspect_bot_reads_and_checks_once(self):
        n = {"c": 0}
        orig = loader.check_bot_source
        loader.check_bot_source = lambda *a, **k: (n.__setitem__("c", n["c"] + 1), orig(*a, **k))[1]
        try:
            app = fresh_app()
            n["c"] = 0
            info = loader.inspect_bot(app.store.list_bots()[0])
            self.assertTrue(info.ok)
            self.assertEqual(n["c"], 1)
        finally:
            loader.check_bot_source = orig


if __name__ == "__main__":
    unittest.main()
