"""Báo thức giám sát dịch vụ (AlarmManager «công tắc người chết»): logic (pyea/watchdog.py), cầu nối Android (android_native.schedule_watchdog bằng jnius GIẢ)
và tích hợp ServiceHost. KHÔNG kiểm chứng được trên thiết bị thật ở đây: phần Android chỉ kiểm chuỗi lời gọi theo tài liệu
(p4a Service.getDefaultIntent, PendingIntent.getForegroundService/getService, AlarmManager.setExactAndAllowWhileIdle/setAndAllowWhileIdle)."""
import os
import sys
import tempfile
import types
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import android_native as native                    # noqa: E402
from pyea.ipc import ServiceClient, ServiceHost              # noqa: E402
from pyea.settings import default_settings, GLOBAL_INPUTS    # noqa: E402
from pyea.watchdog import Watchdog                           # noqa: E402
from pyea.accounts import ACCOUNT_DENY                       # noqa: E402


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


class TestWatchdogLogic(unittest.TestCase):
    def setUp(self):
        self.clock, self.log = Clock(), []
        self.ok = True
        self.wd = Watchdog(lambda d: self.log.append(("arm", d)) or self.ok, lambda: self.log.append(("cancel",)) or True,
                           interval_s=300.0, clock=self.clock, retry_s=60.0)

    def test_arms_at_once_and_pushes_the_alarm_forward_before_it_can_fire(self):
        self.wd.tick(True)
        self.assertEqual(self.log, [("arm", 300.0)])
        self.clock.t += 100                                    # < 40% chu kỳ: chưa dời
        self.wd.tick(True)
        self.assertEqual(len(self.log), 1)
        self.clock.t += 30                                     # qua 40% (120s): dời về 300s sau
        self.wd.tick(True)
        self.assertEqual(self.log, [("arm", 300.0), ("arm", 300.0)])
        self.assertLess(120.0, 300.0 - 0.0)                    # luôn dời trước khi báo thức kịp nổ (40% < 100%)

    def test_cancels_when_no_longer_wanted_and_only_once(self):
        self.wd.tick(True)
        self.wd.tick(False)
        self.wd.tick(False)
        self.assertEqual(self.log, [("arm", 300.0), ("cancel",)])
        self.assertFalse(self.wd.armed)

    def test_a_fresh_process_clears_a_stale_alarm_left_by_the_previous_one_once(self):
        self.wd.tick(False)                                    # tiến trình mới, chưa đặt gì: báo thức của tiến trình trước có thể còn treo
        self.wd.tick(False)
        self.assertEqual(self.log, [("cancel",)])

    def test_failed_arm_is_retried_later_not_every_loop(self):
        self.ok = False
        self.wd.tick(True)
        self.wd.tick(True)
        self.assertEqual(len(self.log), 1)
        self.assertFalse(self.wd.armed)
        self.assertTrue(self.wd.error)
        self.clock.t += 61
        self.ok = True
        self.wd.tick(True)
        self.assertTrue(self.wd.armed)
        self.assertEqual(self.wd.error, "")

    def test_exceptions_never_escape(self):
        def boom(*a):
            raise RuntimeError("không có AlarmManager")
        wd = Watchdog(boom, boom, clock=self.clock)
        wd.tick(True)
        self.assertIn("AlarmManager", wd.error)
        wd.tick(False)
        wd.stop()

    def test_interval_has_a_floor(self):
        self.wd.set_interval(1)
        self.assertEqual(self.wd.interval, 30.0)


class FakeJnius:
    """jnius giả ghi lại chuỗi lời gọi Android."""

    def __init__(self, sdk, can_exact=True, fail=None):
        self.calls, self.sdk, self.fail = [], sdk, fail
        rec = self.calls
        fake = self

        class AM:
            def canScheduleExactAlarms(s):
                rec.append(("canScheduleExactAlarms",))
                return can_exact

            def setExactAndAllowWhileIdle(s, typ, when, pi):
                rec.append(("exact", typ, when, pi))

            def setAndAllowWhileIdle(s, typ, when, pi):
                rec.append(("inexact", typ, when, pi))

            def cancel(s, pi):
                rec.append(("cancel", pi))

        class Ctx:
            def getPackageName(s):
                return "org.test.pyea"

            def getSystemService(s, name):
                rec.append(("service", name))
                return AM()

        self.ctx = Ctx()

        class Svc:
            @staticmethod
            def getDefaultIntent(ctx, icon, title, text, arg):
                rec.append(("intent", icon, arg))
                return "INTENT"

        class PI:
            FLAG_UPDATE_CURRENT, FLAG_IMMUTABLE = 0x08000000, 0x04000000

            @staticmethod
            def getForegroundService(ctx, req, intent, flags):
                rec.append(("pi_fgs", req, intent, flags))
                return "PI_FGS"

            @staticmethod
            def getService(ctx, req, intent, flags):
                rec.append(("pi_svc", req, intent, flags))
                return "PI_SVC"

        self.classes = {
            "org.kivy.android.PythonService": types.SimpleNamespace(mService=self.ctx),
            "android.os.Build$VERSION": types.SimpleNamespace(SDK_INT=sdk),
            "android.content.Context": types.SimpleNamespace(ALARM_SERVICE="alarm"),
            "android.app.AlarmManager": types.SimpleNamespace(RTC_WAKEUP=0),
            "android.app.PendingIntent": PI,
            "java.lang.System": types.SimpleNamespace(currentTimeMillis=lambda: 5_000_000),
            "org.test.pyea.ServiceBotservice": Svc,
        }

    def autoclass(self, name):
        if self.fail:
            raise RuntimeError(self.fail)
        return self.classes[name]


class TestAndroidBridge(unittest.TestCase):
    def setUp(self):
        self._mod = sys.modules.get("jnius")
        self._was = native.IS_ANDROID
        native.IS_ANDROID = True

    def tearDown(self):
        native.IS_ANDROID = self._was
        if self._mod is None:
            sys.modules.pop("jnius", None)
        else:
            sys.modules["jnius"] = self._mod

    def use(self, **kw):
        fj = FakeJnius(**kw)
        sys.modules["jnius"] = types.SimpleNamespace(autoclass=fj.autoclass)
        return fj

    def kinds(self, fj):
        return [c[0] for c in fj.calls]

    def test_android_9_uses_foreground_service_pending_intent_and_exact_alarm(self):
        fj = self.use(sdk=28)
        self.assertTrue(native.schedule_watchdog(300))
        self.assertIn(("pi_fgs", native.WD_REQUEST, "INTENT", 0x08000000 | 0x04000000), fj.calls)
        self.assertIn(("exact", 0, 5_000_000 + 300_000, "PI_FGS"), fj.calls)
        self.assertNotIn("canScheduleExactAlarms", self.kinds(fj))        # trước Android 12 không cần hỏi quyền báo thức chính xác

    def test_before_android_8_uses_plain_get_service(self):
        fj = self.use(sdk=24)
        self.assertTrue(native.schedule_watchdog(60))
        self.assertIn("pi_svc", self.kinds(fj))
        self.assertNotIn("pi_fgs", self.kinds(fj))

    def test_android_12_without_exact_alarm_permission_falls_back_to_inexact(self):
        fj = self.use(sdk=33, can_exact=False)
        self.assertTrue(native.schedule_watchdog(300))
        self.assertIn("inexact", self.kinds(fj))
        self.assertNotIn("exact", self.kinds(fj))

    def test_android_12_with_permission_uses_exact(self):
        fj = self.use(sdk=33, can_exact=True)
        self.assertTrue(native.schedule_watchdog(300))
        self.assertIn("exact", self.kinds(fj))

    def test_cancel_uses_the_same_pending_intent_so_it_cancels_the_scheduled_alarm(self):
        fj = self.use(sdk=28)
        self.assertTrue(native.cancel_watchdog())
        self.assertIn(("cancel", "PI_FGS"), fj.calls)
        self.assertIn(("pi_fgs", native.WD_REQUEST, "INTENT", 0x08000000 | 0x04000000), fj.calls)   # cùng requestCode + Intent

    def test_failures_return_false_and_never_raise(self):
        self.use(sdk=28, fail="jnius lỗi")
        self.assertFalse(native.schedule_watchdog(300))
        self.assertFalse(native.cancel_watchdog())

    def test_outside_android_is_a_noop(self):
        native.IS_ANDROID = False
        self.assertFalse(native.schedule_watchdog(300))
        self.assertFalse(native.cancel_watchdog())


class FakeWd:
    def __init__(self, boom=False):
        self.calls, self.boom, self.interval = [], boom, None

    def set_interval(self, s):
        self.interval = s

    def tick(self, want):
        self.calls.append(want)
        if self.boom:
            raise RuntimeError("giám sát hỏng")

    def stop(self):
        self.calls.append("stop")


class TestServiceHostIntegration(unittest.TestCase):
    def _desired(self, d, running=True, **settings):
        st = default_settings()
        st.update(settings)
        ServiceClient(d).write_desired({"running": running, "config": {"settings": st, "instances": []}})

    def host(self, d, wd=None):
        return ServiceHost(d, sleep=0.02, exit_grace=0.1, idle_exit=0.3, watchdog=wd)

    def test_wanted_while_the_session_is_desired_even_if_the_service_just_restarted(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d)
            self.assertEqual(self.host(d)._watchdog_want(), (True, 300.0))

    def test_not_wanted_when_nothing_should_run(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d, running=False)
            self.assertFalse(self.host(d)._watchdog_want()[0])

    def test_setting_off_or_auto_resume_off_disables_it(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d, watchdog_alarm=False)
            self.assertFalse(self.host(d)._watchdog_want()[0])
            self._desired(d, auto_resume=False)
            self.assertFalse(self.host(d)._watchdog_want()[0])                 # không tự khôi phục thì dựng lại dịch vụ cũng vô ích

    def test_interval_follows_the_setting(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d, watchdog_minutes=10.0)
            self.assertEqual(self.host(d)._watchdog_want(), (True, 600.0))

    def test_idle_host_exits_and_cancels_the_alarm(self):
        with tempfile.TemporaryDirectory() as d:
            wd = FakeWd()
            self.host(d, wd).run()
            self.assertEqual(wd.calls[-1], "stop")
            self.assertNotIn(True, wd.calls)

    def test_a_broken_watchdog_cannot_take_the_service_down(self):
        with tempfile.TemporaryDirectory() as d:
            wd = FakeWd(boom=True)
            self._desired(d, running=False)
            self.host(d, wd).run()                                             # không ném, vẫn thoát nhàn rỗi
            self.assertTrue(wd.calls)

    def test_settings_are_app_level_not_per_account(self):
        self.assertIn("watchdog_alarm", GLOBAL_INPUTS)
        self.assertIn("watchdog_alarm", ACCOUNT_DENY)
        self.assertIn("watchdog_minutes", ACCOUNT_DENY)


if __name__ == "__main__":
    unittest.main()
