"""Lịch kinh tế: phân tích JSON/CSV (econcal.py), suy tiền tệ từ mã, bộ đệm/nạp lại, và phần vỏ (calwatch.py): báo trước tin, chặn lệnh MỚI của bot/AI
quanh tin (lệnh đóng/lệnh tay/backtest không bị chặn; lịch hỏng thì không chặn)."""
import http.server
import json
import os
import sys
import tempfile
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub                                             # noqa: E402
kivy_stub.install()

from pyea import econcal                                     # noqa: E402
from pyea.econcal import EconCalendar, fetch_text, parse, symbol_currencies   # noqa: E402
from pyea.engine import BotContext, TradingSession           # noqa: E402
from pyea.sdk import API_VERSION, Ret, Tick                  # noqa: E402
from pyea.settings import GLOBAL_INPUTS, clean_settings, default_settings   # noqa: E402
from test_botproc import HEAD, write                         # noqa: E402
from test_recon_cache import make as make_paper              # noqa: E402

FEED = json.dumps([
    {"title": "Non-Farm Employment Change", "country": "USD", "date": "2026-11-06T13:30:00-05:00", "impact": "High", "forecast": "180K", "previous": "254K"},
    {"title": "Bank Holiday", "country": "JPY", "date": "2026-11-03T00:00:00-05:00", "impact": "Holiday", "forecast": "", "previous": ""},
    {"title": "CPI m/m", "country": "EUR", "date": "2026-11-04T05:00:00-05:00", "impact": "Medium", "forecast": "0.2%", "previous": "0.3%"},
    {"title": "Retail Sales", "country": "GBP", "date": "2026-11-05T02:00:00-05:00", "impact": "Low", "forecast": "", "previous": ""},
])
NOW = 1_800_000_000.0


def ev(offset_min, cur="USD", title="NFP", impact=3, now=None):
    now = time.time() if now is None else now
    return {"title": title, "country": cur, "date": now + offset_min * 60.0, "impact": ["Holiday", "Low", "Medium", "High"][impact]}


# ================================================================================================ phân tích
class TestParse(unittest.TestCase):
    def test_real_feed_shape(self):
        out = parse(FEED)
        self.assertEqual([e.title for e in out], ["Bank Holiday", "CPI m/m", "Retail Sales", "Non-Farm Employment Change"])    # xếp theo giờ
        nfp = out[-1]
        self.assertEqual((nfp.currency, nfp.impact, nfp.forecast, nfp.previous), ("USD", 3, "180K", "254K"))
        self.assertEqual(nfp.ts, 1793989800.0)                                               # 13:30 giờ New York (UTC-5) = 18:30 UTC
        self.assertEqual([e.impact for e in out], [0, 2, 1, 3])

    def test_wrapped_object_csv_and_epoch(self):
        self.assertEqual(len(parse(json.dumps({"events": json.loads(FEED)}))), 4)
        self.assertEqual(len(parse(json.dumps({"data": json.loads(FEED)}))), 4)
        csv_text = "time,event,currency,importance\n2026-11-06 18:30:00,NFP,USD,high\n1793989800,CPI,EUR,2\n1793989800000,Rate,GBP,★★★\n"
        out = parse(csv_text)
        self.assertEqual([(e.title, e.currency, e.impact) for e in out], [("CPI", "EUR", 2), ("Rate", "GBP", 3), ("NFP", "USD", 3)])      # cùng giờ -> xếp theo tiền tệ
        self.assertEqual({e.ts for e in out}, {1793989800.0})                                # chuỗi không múi giờ = UTC; mili-giây được nhận ra

    def test_bom_junk_rows_and_failures(self):
        out = parse("﻿" + json.dumps([{"title": "ok", "country": "usd", "date": "2026-11-06T00:00:00Z", "impact": "low"}, {"title": "no date"}, {"date": "x"}, 5, None]))
        self.assertEqual([(e.title, e.currency, e.impact) for e in out], [("ok", "USD", 1)])
        for bad in ("", "   ", "[]", "[{}]", json.dumps({"x": 1}), "a,b\n1,2\n"):
            with self.assertRaises(ValueError, msg=repr(bad)):
                parse(bad)
        with self.assertRaises(ValueError):
            parse("[not json")

    def test_impact_words_and_unknown_default_low(self):
        self.assertEqual([econcal._impact(x) for x in ("High", "MEDIUM", "moderate", "low", "Holiday", "", "weird", 3, 9, -1)], [3, 2, 2, 1, 0, 1, 1, 3, 3, 0])

    def test_long_titles_are_cut_and_currency_is_normalised(self):
        e = parse(json.dumps([{"title": "x" * 500, "country": " usdt-long-name ", "date": "2026-11-06T00:00:00Z"}]))[0]
        self.assertEqual(len(e.title), 160)
        self.assertLessEqual(len(e.currency), 8)


class TestSymbolCurrencies(unittest.TestCase):
    def test_common_symbols(self):
        for sym, want in (("EURUSD", {"EUR", "USD"}), ("EUR_USD", {"EUR", "USD"}), ("GBPJPY", {"GBP", "JPY"}), ("USDJPY", {"USD", "JPY"}),
                          ("XAUUSD", {"USD"}), ("XAU_USD", {"USD"}), ("XAUEUR", {"EUR"}), ("BTCUSD", {"USD"}), ("BTCUSDT", {"USD"}), ("ETHUSDC", {"USD"}),
                          ("US500", {"USD"}), ("GER40", {"EUR"}), ("UK100", {"GBP"}), ("JP225", {"JPY"}), ("btcusdt", {"USD"})):
            self.assertEqual(symbol_currencies(sym), want, sym)

    def test_unknown_symbols_give_nothing_so_nothing_is_blocked(self):
        for sym in ("AAPL", "", None, "SOLBNB", "DOGE", "X"):
            self.assertEqual(symbol_currencies(sym), set(), sym)

    def test_override_wins(self):
        self.assertEqual(symbol_currencies("BTCUSDT", "eur, jpy;gbp"), {"EUR", "JPY", "GBP"})
        self.assertEqual(symbol_currencies("AAPL", "USD"), {"USD"})


# ================================================================================================ nạp nguồn
class _Srv(http.server.BaseHTTPRequestHandler):
    body = FEED.encode()
    status = 200

    def do_GET(self):
        self.send_response(self.status)
        self.send_header("Content-Length", str(len(self.body)))
        self.end_headers()
        self.wfile.write(self.body)

    def log_message(self, *a):
        pass


class TestFetch(unittest.TestCase):
    def test_file_paths_and_file_url(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "cal.json")
        open(p, "w", encoding="utf-8").write(FEED)
        self.assertEqual(len(parse(fetch_text(p))), 4)
        self.assertEqual(len(parse(fetch_text("file://" + p))), 4)

    def test_http_source(self):
        srv = http.server.HTTPServer(("127.0.0.1", 0), _Srv)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            self.assertEqual(len(parse(fetch_text("http://127.0.0.1:%d/cal.json" % srv.server_port))), 4)
            _Srv.status = 500
            with self.assertRaises(Exception):
                fetch_text("http://127.0.0.1:%d/cal.json" % srv.server_port)
        finally:
            _Srv.status = 200
            srv.shutdown()
            srv.server_close()

    def test_errors_and_size_limit(self):
        with self.assertRaises(ValueError):
            fetch_text("")
        with self.assertRaises(OSError):
            fetch_text("/không/có/file.json")
        d = tempfile.mkdtemp()
        p = os.path.join(d, "big.json")
        with open(p, "wb") as f:
            f.write(b"x" * (econcal.MAX_BYTES + 10))
        with self.assertRaises(ValueError):
            fetch_text(p)


# ================================================================================================ lịch
class Clock:
    def __init__(self, t=NOW):
        self.t = t

    def __call__(self):
        return self.t


class TestEconCalendar(unittest.TestCase):
    def setUp(self):
        self.clock = Clock()
        self.src = json.dumps([ev(30, "USD", "NFP", 3, NOW), ev(-10, "EUR", "CPI", 2, NOW), ev(120, "JPY", "BOJ", 3, NOW), ev(60, "ALL", "G20", 3, NOW), ev(45, "USD", "Minor", 1, NOW)])
        self.calls = 0

        def fetch(source):
            self.calls += 1
            if isinstance(self.src, Exception):
                raise self.src
            return self.src
        self.cal = EconCalendar("mem", fetch=fetch, clock=self.clock)

    def test_refresh_loads_and_failure_keeps_the_old_calendar(self):
        self.assertTrue(self.cal.refresh()[0])
        self.assertEqual(len(self.cal.events), 5)
        self.src = OSError("mất mạng")
        self.clock.t += 7 * 3600
        ok, err = self.cal.refresh()
        self.assertFalse(ok)
        self.assertIn("mất mạng", err)
        self.assertEqual(len(self.cal.events), 5)                                            # giữ lịch cũ
        self.src = "không phải lịch"
        self.clock.t += 400
        self.assertFalse(self.cal.refresh()[0])
        self.assertEqual(len(self.cal.events), 5)

    def test_stale_logic_ttl_and_retry_spacing(self):
        self.assertTrue(self.cal.stale())
        self.cal.refresh()
        self.assertFalse(self.cal.stale())
        self.clock.t += 6 * 3600 + 1
        self.assertTrue(self.cal.stale())
        self.src = OSError("x")
        self.cal.refresh()
        self.assertFalse(self.cal.stale())                                                   # vừa thử lỗi: chưa thử lại ngay
        self.clock.t += 301
        self.assertTrue(self.cal.stale())
        n = self.calls
        self.cal.refresh()
        self.cal.refresh()
        self.assertEqual(self.calls, n + 1)                                                  # trong lúc chờ không gọi dồn

    def test_force_refresh_ignores_ttl_and_busy_guard(self):
        self.cal.refresh()
        n = self.calls
        self.cal.refresh()
        self.assertEqual(self.calls, n)
        self.cal.refresh(force=True)
        self.assertEqual(self.calls, n + 1)
        self.cal._busy = True
        self.assertFalse(self.cal.refresh(force=True)[0])
        self.assertEqual(self.calls, n + 1)

    def test_cache_survives_restart_and_is_ignored_for_another_source(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "cache.json")
        c1 = EconCalendar("mem", cache_path=p, fetch=lambda s: self.src, clock=self.clock)
        c1.refresh()
        c2 = EconCalendar("mem", cache_path=p, fetch=lambda s: (_ for _ in ()).throw(OSError("không mạng")), clock=self.clock)
        self.assertEqual(len(c2.events), 5)                                                  # mở app lúc chưa có mạng vẫn có lịch
        self.assertEqual(c2.loaded_at, c1.loaded_at)
        self.assertEqual(len(EconCalendar("khác", cache_path=p, clock=self.clock).events), 0)
        open(p, "w").write("{hỏng")
        self.assertEqual(len(EconCalendar("mem", cache_path=p, clock=self.clock).events), 0)

    def test_upcoming_filters(self):
        self.cal.refresh()
        up = self.cal.upcoming(NOW, 3600, 2, {"USD"})
        self.assertEqual([e.title for e in up], ["NFP", "G20"])                              # USD + ALL; bỏ CPI (đã qua), Minor (thấp), BOJ (xa)
        self.assertEqual([e.title for e in self.cal.upcoming(NOW, 3600, 1, {"USD"})], ["NFP", "Minor", "G20"])
        self.assertEqual([e.title for e in self.cal.upcoming(NOW, 3600, 2, {"EUR"}, past_s=900)], ["CPI", "G20"])
        self.assertEqual(len(self.cal.upcoming(NOW, 86400, 0, None)), 4)                    # currencies=None: mọi tiền tệ (CPI đã qua)

    def test_blocking_window_is_inclusive_and_currency_aware(self):
        only = EconCalendar("mem", fetch=lambda s: json.dumps([ev(30, "USD", "NFP", 3, NOW), ev(-10, "EUR", "CPI", 2, NOW)]), clock=self.clock)
        only.refresh()
        b = lambda sym, now, **k: only.blocking(sym, k.get("before", 900), k.get("after", 900), k.get("impact", 3), k.get("ov", ""), now)       # noqa: E731
        self.assertIsNone(b("EURUSD", NOW + 30 * 60 - 901))                                  # trước cửa sổ 1 giây (NFP ở NOW+30')
        self.assertEqual(b("EURUSD", NOW + 30 * 60 - 900).title, "NFP")                      # đúng biên đầu
        self.assertEqual(b("EURUSD", NOW + 30 * 60 + 900).title, "NFP")                      # đúng biên cuối
        self.assertIsNone(b("EURUSD", NOW + 30 * 60 + 901))
        self.assertIsNone(b("USDJPY", NOW + 30 * 60 - 900, ov="EUR"))                        # ghi đè tiền tệ: không phải USD nữa
        self.assertIsNone(b("AAPL", NOW + 30 * 60))                                          # mã lạ: không bao giờ chặn
        self.assertIsNone(b("EURUSD", NOW - 10 * 60, impact=3))                              # CPI mức vừa < 3
        self.assertEqual(b("EURUSD", NOW - 10 * 60, impact=2).title, "CPI")
        self.assertIsNone(b("GBPCHF", NOW + 30 * 60 - 900))                                  # không liên quan USD
        self.assertEqual(b("EURUSD", NOW + 30 * 60, before=0, after=0).title, "NFP")          # cửa sổ rộng 0: chỉ đúng khoảnh khắc ra tin
        self.assertIsNone(b("EURUSD", NOW + 30 * 60 + 1, before=0, after=0))

    def test_global_events_affect_every_symbol_with_a_known_currency_but_not_unknown_ones(self):
        self.cal.refresh()
        self.assertEqual(self.cal.blocking("EURUSD", 900, 900, 3, "", NOW + 60 * 60).title, "G20")
        self.assertIsNone(self.cal.blocking("AAPL", 900, 900, 3, "", NOW + 60 * 60))


# ================================================================================================ phần vỏ
def session(events=None, **over):
    base = dict(calendar_enabled=True, calendar_source="mem", news_block=True, news_block_min_impact="high", news_block_before_min=15.0,
                news_block_after_min=15.0, calendar_alert_min=15.0, calendar_min_impact="high")
    base.update(over)
    s = make_paper(**base)
    s.sync = False
    s.watch = ["EURUSD", "BTCUSDT"]
    s.alarm_log = []
    orig = s.alarm
    s.alarm = lambda t, x, critical=True: (s.alarm_log.append((t, x, critical)), orig(t, x, critical=critical))[1]
    if events is not None:
        cal = EconCalendar("mem", fetch=lambda src: json.dumps(events))
        cal.refresh()
        s.cal, s._cal_src = cal, "mem"
    for sym in ("EURUSD", "BTCUSDT", "AAPL"):
        s.process_tick(Tick(sym, time.time(), 100.0, 100.0))
    s.status = "running"
    return s


class TestBlocking(unittest.TestCase):
    def test_bot_orders_are_blocked_inside_the_window_with_a_clear_message(self):
        s = session([ev(5)])
        r = s.send_order("EURUSD", "buy", 1.0, owner="botA")
        self.assertFalse(r.ok)
        self.assertEqual(r.retcode, Ret.NEWS_BLOCK)
        self.assertIn("NFP", r.message)
        self.assertIn("USD", r.message)
        self.assertEqual(len(s.account.positions), 0)

    def test_pending_order_placement_is_blocked_for_bots_but_not_for_the_user(self):
        s = session([ev(5)])
        r = s.place_pending("EURUSD", "buy", "limit", 1.0, 99.0, owner="botA")
        self.assertEqual(r.retcode, Ret.NEWS_BLOCK)
        self.assertEqual(len(s.account.pending), 0)
        self.assertEqual(s.place_pending("EURUSD", "buy", "limit", 1.0, 99.0, owner="manual").retcode, Ret.PLACED)

    def test_after_the_window_and_before_it_orders_go_through(self):
        for off in (-40, 60):
            s = session([ev(off)])
            self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok, off)

    def test_manual_orders_are_never_blocked(self):
        s = session([ev(5)])
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="manual").ok)
        self.assertTrue(s.place_order("EURUSD", "buy", 1.0).ok)

    def test_closing_is_never_blocked_even_in_the_middle_of_news(self):
        s = session([])
        p = s.send_order("EURUSD", "buy", 1.0, owner="botA").position
        s.cal = EconCalendar("mem", fetch=lambda src: json.dumps([ev(0)]))
        s.cal.refresh()
        self.assertEqual(s.send_order("EURUSD", "buy", 1.0, owner="botA").retcode, Ret.NEWS_BLOCK)
        self.assertTrue(s.close_position(p.id, "bot", "đóng").ok)
        self.assertEqual(len(s.account.positions), 0)

    def test_the_gate_itself_exempts_closing_and_manual_orders(self):
        s = session([ev(0)])
        self.assertEqual(s._gate("EURUSD", "buy", owner="botA")[0], Ret.NEWS_BLOCK)
        self.assertIsNone(s._gate("EURUSD", "sell", closing=True, owner="botA"))
        self.assertIsNone(s._gate("EURUSD", "buy", owner="manual"))

    def test_close_all_and_kill_switch_paths_are_unaffected(self):
        s = session([])
        s.send_order("EURUSD", "buy", 1.0, owner="botA")
        s.send_order("BTCUSDT", "buy", 1.0, owner="botA")
        s.cal = EconCalendar("mem", fetch=lambda src: json.dumps([ev(0, "USD")]))
        s.cal.refresh()
        s.close_all("kill", "test")
        self.assertEqual(len(s.account.positions), 0)

    def test_only_symbols_with_the_event_currency_are_affected(self):
        s = session([ev(5, "JPY")])
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        self.assertTrue(s.send_order("BTCUSDT", "buy", 1.0, owner="botA").ok)
        s2 = session([ev(5, "USD")])
        self.assertEqual(s2.send_order("BTCUSDT", "buy", 1.0, owner="botA").retcode, Ret.NEWS_BLOCK)         # crypto theo USD
        self.assertTrue(s2.send_order("AAPL", "buy", 1.0, owner="botA").ok)                                   # mã lạ: không suy ra được -> không chặn

    def test_currency_override_changes_what_is_affected(self):
        s = session([ev(5, "EUR")], calendar_currencies="USD")
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)                                  # đã ép chỉ theo USD, tin EUR bị bỏ qua

    def test_impact_threshold_for_blocking(self):
        s = session([ev(5, "USD", "Medium thing", 2)])
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        s2 = session([ev(5, "USD", "Medium thing", 2)], news_block_min_impact="medium")
        self.assertEqual(s2.send_order("EURUSD", "buy", 1.0, owner="botA").retcode, Ret.NEWS_BLOCK)

    def test_switches_off_means_nothing_blocks(self):
        for over in ({"news_block": False}, {"calendar_enabled": False}, {"calendar_source": ""}):
            s = session([ev(5)], **over)
            self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok, over)

    def test_backtest_sessions_never_block(self):
        s = session([ev(5)])
        s.sync = True
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        self.assertEqual(s.calendar_state()["enabled"], False)

    def test_broken_or_empty_calendar_never_blocks(self):
        s = session([])
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        s.cal.events = None                                                                  # trạng thái hỏng bất ngờ
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        s2 = session([ev(5)])
        s2.cal.blocking = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("lịch hỏng giữa chừng"))
        self.assertTrue(s2.send_order("EURUSD", "buy", 1.0, owner="botA").ok)               # lỗi trong lịch KHÔNG được biến thành chặn lệnh hay làm sập đặt lệnh

    def test_window_widths_follow_settings(self):
        s = session([ev(30)], news_block_before_min=5.0)
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)                  # còn 30 phút > 5
        s2 = session([ev(30)], news_block_before_min=45.0)
        self.assertEqual(s2.send_order("EURUSD", "buy", 1.0, owner="botA").retcode, Ret.NEWS_BLOCK)
        s3 = session([ev(-20)], news_block_after_min=10.0)
        self.assertTrue(s3.send_order("EURUSD", "buy", 1.0, owner="botA").ok)
        s4 = session([ev(-20)], news_block_after_min=30.0)
        self.assertEqual(s4.send_order("EURUSD", "buy", 1.0, owner="botA").retcode, Ret.NEWS_BLOCK)


class TestAlerts(unittest.TestCase):
    def _poll(self, s):
        s._cal_t = 0.0
        s._check_calendar()

    def test_one_non_critical_alarm_per_event_for_relevant_symbols(self):
        s = session([ev(10, "USD", "Non-Farm Payrolls")])
        self._poll(s)
        self._poll(s)
        al = [a for a in s.alarm_log if a[0].startswith("Tin sắp ra")]
        self.assertEqual(len(al), 1)                                                         # không báo lặp
        self.assertFalse(al[0][2])                                                           # thông tin, không phải sự cố
        self.assertIn("Non-Farm Payrolls", al[0][0])
        self.assertIn("CAO", al[0][1])
        self.assertIn("EURUSD", al[0][1])
        self.assertIn("chặn lệnh mới", al[0][1])
        self.assertRegex(al[0][1], r"còn \d+ phút")

    def test_no_alarm_for_far_low_irrelevant_or_past_events_or_when_disabled(self):
        for evs, over in (([ev(40)], {}), ([ev(10, "USD", "x", 1)], {}), ([ev(10, "CHF")], {}), ([ev(-5)], {}), ([ev(10)], {"calendar_alert_min": 0.0}),
                          ([ev(10)], {"calendar_enabled": False})):
            s = session(evs, **over)
            self._poll(s)
            self.assertEqual([a for a in s.alarm_log if a[0].startswith("Tin sắp ra")], [], (evs, over))

    def test_alert_text_does_not_promise_blocking_when_it_is_off(self):
        s = session([ev(10)], news_block=False)
        self._poll(s)
        al = [a for a in s.alarm_log if a[0].startswith("Tin sắp ra")]
        self.assertEqual(len(al), 1)
        self.assertNotIn("chặn lệnh mới", al[0][1])

    def test_open_positions_make_their_currencies_relevant(self):
        s = session([ev(10, "USD")])
        s.watch = []
        self._poll(s)
        self.assertEqual([a for a in s.alarm_log if a[0].startswith("Tin sắp ra")], [])      # không theo dõi mã nào liên quan
        s.send_order("EURUSD", "buy", 1.0, owner="manual")
        self._poll(s)
        self.assertEqual(len([a for a in s.alarm_log if a[0].startswith("Tin sắp ra")]), 1)

    def test_throttled_to_once_per_20_seconds(self):
        s = session([ev(10)])
        s._cal_t = time.time()
        s._check_calendar()
        self.assertEqual(s.alarm_log, [])


class TestRefreshThread(unittest.TestCase):
    def test_loads_in_the_background_and_a_dead_source_changes_nothing(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "cal.json")
        open(p, "w", encoding="utf-8").write(json.dumps([ev(10)]))
        s = session(None, calendar_source=p)
        s.data_dir = d
        self.assertEqual(s.calendar_state()["events"], 0)
        s._cal_t = 0.0
        s._check_calendar()
        s._cal_thread.join(10)
        self.assertEqual(s.calendar_state()["events"], 1)
        self.assertTrue(os.path.exists(os.path.join(d, "calendar_cache.json")))
        self.assertTrue(any("đã nạp 1 sự kiện" in x[3] for x in s.get_logs(0)))

    def test_unreachable_source_logs_once_and_never_blocks(self):
        s = session(None, calendar_source="/không/có.json")
        s._cal_t = 0.0
        s._check_calendar()
        s._cal_thread.join(10)
        st = s.calendar_state()
        self.assertEqual((st["events"], bool(st["error"])), (0, True))
        self.assertTrue(any("KHÔNG chặn lệnh vì lịch" in x[3] for x in s.get_logs(0)))
        self.assertTrue(s.send_order("EURUSD", "buy", 1.0, owner="botA").ok)

    def test_changing_the_source_rebuilds_the_calendar(self):
        s = session([ev(10)])
        c1 = s._cal_get()
        self.assertIs(s._cal_get(), c1)
        s.settings["calendar_source"] = "khác"
        self.assertIsNot(s._cal_get(), c1)

    def test_calendar_errors_never_reach_the_poll_loop(self):
        s = session([ev(10)])
        s._check_calendar_inner = lambda: (_ for _ in ()).throw(RuntimeError("hỏng"))
        s._check_calendar()
        s.poll_once()

    def test_the_poll_loop_really_runs_the_calendar_check(self):
        s = session([ev(10)])
        calls = []
        s._check_calendar = lambda: calls.append(1)
        s.poll_once()
        self.assertEqual(calls, [1])


class TestStateAndApi(unittest.TestCase):
    def test_snapshot_reports_next_events_and_the_blocking_one(self):
        s = session([ev(5, "USD", "NFP"), ev(300, "USD", "Far")])
        st = s.snapshot()["calendar"]
        self.assertTrue(st["enabled"])
        self.assertEqual(st["blocking"]["title"], "NFP")
        self.assertEqual(st["blocking"]["symbol"] in ("EURUSD", "BTCUSDT"), True)
        self.assertEqual([e["title"] for e in st["next"]], ["NFP", "Far"])                    # 24 giờ tới
        s2 = session([ev(300)], calendar_enabled=False)
        self.assertEqual(s2.snapshot()["calendar"]["enabled"], False)
        s3 = session([ev(300)], calendar_source="")
        self.assertEqual(s3.calendar_state()["enabled"], False)                              # bật nhưng chưa có nguồn = chưa hoạt động

    def test_bot_api_calendar_is_per_symbol_and_filters_by_impact(self):
        s = session([ev(30, "USD", "NFP", 3), ev(20, "EUR", "CPI", 2), ev(20, "JPY", "BOJ", 3), ev(10, "USD", "Minor", 1)])
        d = tempfile.mkdtemp()
        inst = s.attach(write(d, "b.py", HEAD + "class B(BaseBot):\n    def on_tick(self, t):\n        pass\n"), "EURUSD", "1m", {}, iid="c1")
        api = BotContext(inst)
        got = api.calendar(2, "medium")
        self.assertEqual([e["title"] for e in got], ["CPI", "NFP"])                           # EURUSD = EUR+USD; bỏ JPY và tin mức thấp
        self.assertEqual([e["title"] for e in api.calendar(2, "high")], ["NFP"])
        self.assertEqual([e["title"] for e in api.calendar(0.2, 0)], ["Minor"])               # 0.2 giờ = 12 phút; mức 0 = mọi tin
        self.assertEqual({"ts", "currency", "title", "impact", "forecast", "previous", "actual"}, set(got[0]))
        s.settings["calendar_enabled"] = False
        self.assertEqual(api.calendar(2), [])

    def test_settings_defaults_and_clamping(self):
        d = default_settings()
        self.assertEqual((d["calendar_enabled"], d["news_block"], d["calendar_source"]), (False, False, ""))
        for k in ("calendar_enabled", "calendar_source", "calendar_refresh_h", "calendar_min_impact", "calendar_alert_min", "calendar_currencies",
                  "news_block", "news_block_min_impact", "news_block_before_min", "news_block_after_min"):
            self.assertIn(k, GLOBAL_INPUTS)
            self.assertEqual(GLOBAL_INPUTS[k].group, "Lịch kinh tế")
        c = clean_settings({"news_block_before_min": 99999, "calendar_min_impact": "bogus"})
        self.assertLessEqual(c["news_block_before_min"], 240.0)
        self.assertEqual(c["calendar_min_impact"], "high")

    def test_api_contract_is_versioned_and_documented(self):
        from pyea import ai
        from pyea.changelog import API_CHANGES
        self.assertEqual(API_VERSION, "1.5")
        self.assertEqual(API_CHANGES[0][0], "1.5")
        self.assertIn("1.4", [v for v, _ in API_CHANGES])
        self.assertEqual(Ret.NEWS_BLOCK, "NEWS_BLOCK")
        src = open(ai.__file__, encoding="utf-8").read()
        self.assertIn("NEWS_BLOCK", src)
        self.assertIn("calendar(hours=24", src)


if __name__ == "__main__":
    unittest.main()
