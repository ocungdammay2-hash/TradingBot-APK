"""Cầu nối MT4/MT5: MetaApi, Gateway (backend MetaTrader5 python), EA relay (MT4/MT5), Profile REST bất kỳ."""
import json
import os
import sys
import threading
import time
import unittest
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))
sys.path.insert(0, HERE)

import mt_gateway                                                                  # noqa: E402
from fake_mt import FakeEA, FakeMetaApi, FakeMt5, MtCore                           # noqa: E402
from pyea import ratelimit                                                         # noqa: E402
from pyea.backtest import _ReplayFeed                                              # noqa: E402
from pyea.bridges import (BridgeError, GatewayBackend, MetaApiBackend, MtBroker, MtFeed, ProfileBackend, make_backend, _path_get)   # noqa: E402
from pyea.engine import Account, TradingSession                                    # noqa: E402
from pyea.feeds import FeedError                                                   # noqa: E402
from pyea.sdk import Ret, Tick                                                     # noqa: E402
from pyea.settings import default_settings                                         # noqa: E402


def wait(cond, t=5.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


class BrokerContract:
    """Bộ kiểm tra HỢP ĐỒNG dùng chung cho mọi backend (MetaApi / Gateway-mt5 / Gateway-ea / Profile)."""
    core = None
    broker = None
    feed = None
    sym = "EURUSD"

    def settle(self):
        """Chờ trạng thái lan tới backend (EA relay nhất quán dần). Mặc định: không cần."""

    def test_prepare_and_balance(self):
        self.assertEqual(self.broker.prepare(self.sym), 10000.0)
        self.assertEqual(self.broker.balance(), 10000.0)
        self.assertEqual(self.broker.netting, False)                       # tài khoản hedging

    def test_market_buy_price_and_volume_rounding(self):
        f = self.broker.market_order(self.sym, "buy", 0.037)
        self.assertAlmostEqual(f.price, 1.1002, 5)
        self.assertAlmostEqual(f.qty, 0.03, 6)                              # làm tròn xuống theo volume_step
        self.assertEqual(self.core.log[-1], ("open", self.sym, "buy", 0.03))

    def test_volume_below_min_rejected_before_sending(self):
        n = len(self.core.log)
        with self.assertRaises(BridgeError) as cm:
            self.broker.market_order(self.sym, "buy", 0.001)
        self.assertIn("tối thiểu", str(cm.exception))
        self.assertEqual(len(self.core.log), n)

    def test_broker_reject_surfaces_reason(self):
        self.core.reject_next = ("10019", "No money")
        with self.assertRaises(BridgeError) as cm:
            self.broker.market_order(self.sym, "buy", 0.05)
        self.assertIn("No money", str(cm.exception))

    def test_close_partial_full_and_fifo(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        time.sleep(0.01)
        self.broker.market_order(self.sym, "buy", 0.03)
        self.core.set_price(self.sym, 1.1100, 1.1102)
        self.settle()
        f = self.broker.market_order(self.sym, "sell", 0.04, reduce_only=True)       # đóng 0.04: hết vị thế cũ (0.02) + 0.02 của vị thế sau
        self.assertAlmostEqual(f.qty, 0.04, 6)
        self.assertAlmostEqual(f.price, 1.1100, 4)
        left = sorted(p["volume"] for p in self.core.positions.values())
        self.assertEqual(len(left), 1)
        self.assertAlmostEqual(left[0], 0.01, 6)
        f2 = self.broker.close_market(self.sym, "buy", 0.01)
        self.assertAlmostEqual(f2.qty, 0.01, 6)
        self.assertEqual(self.core.positions, {})
        self.assertGreater(self.core.balance, 10000.0)

    def test_close_without_position(self):
        with self.assertRaises(BridgeError):
            self.broker.close_market(self.sym, "buy", 0.01)

    def test_hedged_positions_not_netted(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        self.broker.market_order(self.sym, "sell", 0.02)
        self.assertEqual(len(self.core.positions), 2)
        self.assertEqual(self.broker.positions(), {})                       # ròng = 0
        self.broker.close_market(self.sym, "buy", 0.02)
        self.assertEqual([p["side"] for p in self.core.positions.values()], ["sell"])
        self.assertAlmostEqual(self.broker.positions()[self.sym]["qty"], -0.02, 6)

    def test_positions_net_with_average_price(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        self.core.set_price(self.sym, 1.2000, 1.2002)
        self.settle()
        self.broker.market_order(self.sym, "buy", 0.02)
        self.settle()
        pos = self.broker.positions()[self.sym]
        self.assertAlmostEqual(pos["qty"], 0.04, 6)
        self.assertAlmostEqual(pos["price"], (1.1002 + 1.2002) / 2, 5)

    def test_native_pending_lifecycle_limit(self):
        nid = self.broker.place_pending(self.sym, "buy", "limit", 0.05, 1.0900)
        self.assertIn(nid, self.broker.pending_orders())
        self.assertEqual(self.broker.order_result(nid, self.sym), {"state": "open"})
        self.broker.modify_pending(nid, self.sym, price=1.0950)
        self.assertEqual(self.core.orders[nid]["price"], 1.095)
        self.core.set_price(self.sym, 1.0940, 1.0942)                         # khớp
        self.settle()
        self.assertNotIn(nid, self.broker.pending_orders())
        r = self.broker.order_result(nid, self.sym)
        self.assertEqual(r["state"], "filled")
        self.assertAlmostEqual(r["price"], 1.095, 6)
        self.assertAlmostEqual(r["qty"], 0.05, 6)

    def test_native_pending_cancel(self):
        nid = self.broker.place_pending(self.sym, "sell", "stop", 0.02, 1.0500)
        self.assertTrue(self.broker.cancel_pending(nid, self.sym))
        self.assertEqual(self.core.orders, {})
        self.assertIsNone(self.broker.order_result(nid, self.sym))              # đã biến mất, không có dấu vết khớp -> engine suy luận

    def test_stop_limit_maps_trigger_and_limit_prices(self):
        nid = self.broker.place_pending(self.sym, "buy", "stop_limit", 0.02, 1.1050, stop_price=1.1100)
        o = self.core.orders[nid]
        self.assertEqual((o["kind"], o["price"], o["stop_price"]), ("stop_limit", 1.105, 1.11))      # limit = 1.1050, kích hoạt = 1.1100

    def test_pending_unsupported_kind(self):
        with self.assertRaises(BridgeError):
            self.broker.place_pending(self.sym, "buy", "trailing", 0.02, 1.1)

    def test_history_filters_non_trades_and_symbols(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        h = self.broker.history(0)
        self.assertEqual([(r["symbol"], r["side"], r["qty"]) for r in h], [(self.sym, "buy", 0.02)])
        self.assertGreater(h[0]["time"], time.time() - 60)
        self.assertEqual(self.broker.history(0, ["XAUUSD"]), [])

    def test_feed_tick_candles_symbols(self):
        self.assertIn(self.sym, self.feed.symbols())
        t = self.feed.tick(self.sym)
        self.assertAlmostEqual(t.bid, 1.1000, 5)
        self.assertTrue(t.tradeable)
        self.assertLess(abs(t.time - time.time()), 30)                         # giờ UTC đúng dù broker lệch múi giờ
        cs = self.feed.history(self.sym, "5m", 6)
        self.assertEqual(len(cs), 6)
        for a, b in zip(cs, cs[1:]):
            self.assertEqual(b.time - a.time, 300)
        self.assertLess(abs(cs[-1].time - time.time()), 600)
        past = self.feed.history(self.sym, "5m", 4, end=time.time() - 7200)
        self.assertEqual(len(past), 4)
        self.assertLess(past[-1].time, time.time() - 6000)


# =========================================================================================== MetaApi
class TestMetaApi(BrokerContract, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        cls.api = FakeMetaApi(cls.core)

    @classmethod
    def tearDownClass(cls):
        cls.api.close()

    def setUp(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.api.requests.clear()
        self.api.deals_as_dict = True
        self.backend = MetaApiBackend(self.api.TOKEN, self.api.ACC, client_url=self.api.base, data_url=self.api.base)
        self.broker = MtBroker(self.backend)
        self.feed = MtFeed(self.backend)

    def test_bad_token_and_unknown_account_messages(self):
        with self.assertRaises(BridgeError) as cm:
            MetaApiBackend("bad", self.api.ACC, client_url=self.api.base).account()
        self.assertEqual(cm.exception.status, 401)
        self.assertIn("token", str(cm.exception))
        with self.assertRaises(BridgeError) as cm2:
            MetaApiBackend(self.api.TOKEN, "nope", client_url=self.api.base).account()
        self.assertIn("Deploy", str(cm2.exception))
        with self.assertRaises(BridgeError):
            MetaApiBackend("", "x")
        with self.assertRaises(BridgeError):
            MetaApiBackend("t", "")

    def test_trade_http_200_with_mt_reject_is_an_error_with_code(self):
        self.core.reject_next = ("10019", "No money")
        with self.assertRaises(BridgeError) as cm:
            self.backend.market("EURUSD", "buy", 0.05)
        self.assertEqual(cm.exception.code, "TRADE_RETCODE_REJECT")

    def test_market_request_body_matches_docs_and_price_comes_from_position(self):
        f = self.broker.market_order(self.sym, "sell", 0.05)
        body = [r for r in self.api.requests if r[1].endswith("/trade")][0][3]
        self.assertEqual({k: body[k] for k in ("actionType", "symbol", "volume")}, {"actionType": "ORDER_TYPE_SELL", "symbol": "EURUSD", "volume": 0.05})
        self.assertAlmostEqual(f.price, 1.1000, 5)                              # trade API không trả giá -> lấy từ vị thế

    def test_action_types_for_pending_and_partial_close(self):
        self.broker.place_pending(self.sym, "buy", "stop_limit", 0.02, 1.1050, stop_price=1.1100)
        self.broker.market_order(self.sym, "buy", 0.05)
        self.broker.close_market(self.sym, "buy", 0.02)
        acts = [r[3] for r in self.api.requests if r[1].endswith("/trade")]
        self.assertEqual([a["actionType"] for a in acts], ["ORDER_TYPE_BUY_STOP_LIMIT", "ORDER_TYPE_BUY", "POSITION_PARTIAL"])
        self.assertEqual((acts[0]["openPrice"], acts[0]["stopLimitPrice"]), (1.11, 1.105))
        self.assertEqual(acts[2]["volume"], 0.02)

    def test_expiry_sent_as_specified_time(self):
        self.broker.place_pending(self.sym, "buy", "limit", 0.02, 1.09, expiry=1_800_000_000)
        b = [r[3] for r in self.api.requests if r[1].endswith("/trade")][0]
        self.assertEqual(b["expiration"]["type"], "ORDER_TIME_SPECIFIED")
        self.assertTrue(b["expiration"]["time"].endswith("Z"))

    def test_history_accepts_list_and_dict_shapes_and_drops_balance_deals(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        for as_dict in (True, False):
            self.api.deals_as_dict = as_dict
            self.assertEqual(len(self.broker.history(0)), 1)

    def test_candles_use_market_data_timeframe_names(self):
        self.feed.history(self.sym, "1mo", 2) if False else None
        self.feed.history(self.sym, "4h", 3)
        r = [x for x in self.api.requests if "/candles" in x[1]][0]
        self.assertIn("/timeframes/4h/candles", r[1])
        self.assertEqual(r[2]["limit"], "3")
        with self.assertRaises(FeedError):
            self.feed.history(self.sym, "7m", 3)

    def test_order_result_via_deals_when_position_gone(self):
        nid = self.broker.place_pending(self.sym, "buy", "limit", 0.05, 1.0900)
        self.core.set_price(self.sym, 1.0890, 1.0892)
        self.core.positions.clear()                                             # đã đóng ngay sau khi khớp
        r = self.broker.order_result(nid, self.sym)
        self.assertEqual((r["state"], round(r["price"], 4), r["qty"]), ("filled", 1.09, 0.05))

    def test_netting_account_flag(self):
        self.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_NETTING"
        self.broker.prepare(self.sym)
        self.assertTrue(self.broker.netting)
        self.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING"

    def test_rate_limiter_shared_and_metaapi_preset(self):
        self.assertIs(self.backend.lim, ratelimit.limiter_for("metaapi", self.api.base))


# =========================================================================================== Gateway + MetaTrader5 (python)
class GatewayFixture:
    @classmethod
    def start_gateway(cls, backend, token="gw-secret"):
        cls.srv = mt_gateway.serve(backend, "127.0.0.1", 0, token)
        cls.url = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        cls.token = token
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def stop_gateway(cls):
        cls.srv.shutdown()
        cls.srv.server_close()


class TestGatewayMt5(GatewayFixture, BrokerContract, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        cls.mt5 = FakeMt5(cls.core, offset=7200)                              # broker UTC+2
        cls.be = mt_gateway.Mt5Backend(mt5=cls.mt5, login="123", password="pw", server="Exness-MT5Real")
        cls.start_gateway(cls.be)

    @classmethod
    def tearDownClass(cls):
        cls.stop_gateway()

    def setUp(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.mt5.requests.clear()
        self.backend = GatewayBackend(self.url, self.token)
        self.broker = MtBroker(self.backend)
        self.feed = MtFeed(self.backend)

    def test_initialize_called_with_credentials(self):
        self.assertEqual(self.mt5.init_args, {"login": 123, "password": "pw", "server": "Exness-MT5Real"})

    def test_initialize_failure_message(self):
        with self.assertRaises(mt_gateway.GwError) as cm:
            mt_gateway.Mt5Backend(mt5=FakeMt5(MtCore(), init_ok=False))
        self.assertIn("initialize", str(cm.exception))

    def test_token_required(self):
        with self.assertRaises(BridgeError) as cm:
            GatewayBackend(self.url, "wrong").account()
        self.assertEqual(cm.exception.status, 401)
        self.assertIn("token", str(cm.exception))

    def test_server_offset_autodetected_and_times_are_utc(self):
        self.feed.tick(self.sym)
        self.assertEqual(self.be.offset, 7200.0)

    def test_filling_mode_follows_symbol_flags(self):
        for fm, want in ((2, FakeMt5.ORDER_FILLING_IOC), (1, FakeMt5.ORDER_FILLING_FOK), (0, FakeMt5.ORDER_FILLING_RETURN)):
            self.mt5.filling_mode = fm
            self.mt5.requests.clear()
            self.broker.market_order(self.sym, "buy", 0.01)
            self.assertEqual(self.mt5.requests[-1]["type_filling"], want)
        self.mt5.filling_mode = 2

    def test_stop_limit_request_uses_price_as_trigger_and_stoplimit_as_limit(self):
        self.broker.place_pending(self.sym, "sell", "stop_limit", 0.02, 1.0950, stop_price=1.0900)
        r = self.mt5.requests[-1]
        self.assertEqual((r["type"], r["price"], r["stoplimit"]), (FakeMt5.ORDER_TYPE_SELL_STOP_LIMIT, 1.09, 1.095))

    def test_expiry_converted_to_broker_time(self):
        self.feed.tick(self.sym)
        exp = time.time() + 3600
        self.broker.place_pending(self.sym, "buy", "limit", 0.02, 1.09, expiry=exp)
        r = self.mt5.requests[-1]
        self.assertEqual(r["type_time"], FakeMt5.ORDER_TIME_SPECIFIED)
        self.assertEqual(r["expiration"], int(exp + 7200))

    def test_bad_requests(self):
        for path, code in (("/v1/nope", 404),):
            with self.assertRaises(BridgeError) as cm:
                self.backend._req("GET", path)
            self.assertEqual(cm.exception.status, code)
        with self.assertRaises(BridgeError) as cm:
            self.backend._req("GET", "/v1/tick")                               # thiếu symbol
        self.assertEqual(cm.exception.status, 400)
        with self.assertRaises(BridgeError) as cm:
            self.backend.tick("NOPE")
        self.assertIn("NOPE", str(cm.exception))

    def test_hedging_flag_from_margin_mode(self):
        self.core.hedging = False
        try:
            self.broker.prepare(self.sym)
            self.assertTrue(self.broker.netting)
        finally:
            self.core.hedging = True


# =========================================================================================== Gateway + EA relay
class TestGatewayEa(GatewayFixture, BrokerContract, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        cls.be = mt_gateway.EaRelayBackend(cmd_timeout=5.0)
        cls.start_gateway(cls.be, "gw-secret")
        cls.ea = FakeEA(cls.core, cls.url, "gw-secret").start()
        assert wait(lambda: cls.be.state["account"] is not None)

    @classmethod
    def tearDownClass(cls):
        cls.ea.close()
        cls.stop_gateway()

    def setUp(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.backend = GatewayBackend(self.url, self.token)
        self.broker = MtBroker(self.backend)
        self.feed = MtFeed(self.backend)
        self.broker.OP_WAIT = 3.0
        self.be.state["deals"].clear()                                         # relay giữ deals đã nhận: dọn giữa các test
        time.sleep(0.15)                                                       # để EA đẩy trạng thái mới lên

    def _sync(self):
        n = self.ea.polls
        wait(lambda: self.ea.polls >= n + 2)

    def settle(self):
        self._sync()

    def test_relay_state_is_eventually_consistent_for_reads(self):
        self.core.set_price(self.sym, 1.3000, 1.3002)
        self.feed.tick(self.sym)
        self._sync()
        self.assertAlmostEqual(self.feed.tick(self.sym).bid, 1.3, 5)

    def test_poll_requires_token(self):
        import urllib.request, urllib.error
        req = urllib.request.Request(self.url + "/ea/poll", data=b"HELLO|MT5|1|1\n", method="POST", headers={"X-PyEA-Token": "bad"})
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req, timeout=3)
        self.assertEqual(cm.exception.code, 401)

    def test_malformed_lines_do_not_break_poll(self):
        import urllib.request
        req = urllib.request.Request(self.url + "/ea/poll", data=b"TICK|EURUSD|x\nPOS|1|2\nGARBAGE\nACCT|1|2|3|4|5|USD|1\n", method="POST",
                                     headers={"X-PyEA-Token": "gw-secret"})
        with urllib.request.urlopen(req, timeout=3) as r:
            self.assertTrue(r.read().decode().startswith("OK|"))

    def test_mt4_platform_reported(self):
        self.assertEqual(self.backend._req("GET", "/v1/ping")["platform"], "MT5")

    def test_commands_reach_ea_in_documented_wire_format(self):
        self.broker.market_order(self.sym, "buy", 0.02)
        self.broker.place_pending(self.sym, "buy", "stop_limit", 0.02, 1.1050, stop_price=1.1100)
        acts = [c[0] for c in self.ea.cmd_log[-3:]]
        self.assertIn("market", acts)
        pend = [c for c in self.ea.cmd_log if c[0] == "pending"][-1]
        self.assertEqual(pend[1:7], ["EURUSD", "buy", "stop_limit", "0.02", "1.105", "1.11"])


class TestGatewayEaMt4(GatewayFixture, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        cls.be = mt_gateway.EaRelayBackend(cmd_timeout=5.0)
        cls.start_gateway(cls.be, "t")
        cls.ea = FakeEA(cls.core, cls.url, "t", platform="MT4").start()
        assert wait(lambda: cls.be.state["account"] is not None)

    @classmethod
    def tearDownClass(cls):
        cls.ea.close()
        cls.stop_gateway()

    def test_mt4_drops_stop_limit_but_keeps_limit_and_stop(self):
        b = MtBroker(GatewayBackend(self.url, "t"))
        self.assertEqual(b.native_pending, {"limit", "stop", "stop_limit"})
        b.prepare("EURUSD")
        self.assertEqual(b.native_pending, {"limit", "stop"})
        with self.assertRaises(BridgeError) as cm:
            b.place_pending("EURUSD", "buy", "stop_limit", 0.02, 1.1, stop_price=1.11)
        self.assertIn("stop_limit", str(cm.exception))
        self.assertTrue(b.place_pending("EURUSD", "buy", "limit", 0.02, 1.09))

    def test_engine_falls_back_to_emulation_for_stop_limit_on_mt4(self):
        b = MtBroker(GatewayBackend(self.url, "t"))
        s = make_session(b)
        s.account.balance = b.prepare("EURUSD")
        s.process_tick(Tick("EURUSD", 1000.0, 1.1000, 1.1002))
        r = s.place_pending("EURUSD", "buy", "stop_limit", 0.02, 1.1045, stop_price=1.1050)
        self.assertTrue(r.ok, r.message)
        self.assertEqual(s.account.pending[r.order.id].native_id, "")        # pending_mode=auto -> vỏ tự theo dõi, không gửi lên MT4


class TestEaOffline(GatewayFixture, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.be = mt_gateway.EaRelayBackend(cmd_timeout=0.6)
        cls.be.STALE = 0.5
        cls.start_gateway(cls.be, "t")

    @classmethod
    def tearDownClass(cls):
        cls.stop_gateway()

    def test_no_ea_connected_has_actionable_message(self):
        with self.assertRaises(BridgeError) as cm:
            GatewayBackend(self.url, "t").account()
        self.assertIn("EA PyEA_Bridge chưa kết nối", str(cm.exception))
        self.assertIn("WebRequest", str(cm.exception))

    def test_ea_that_ignores_commands_times_out(self):
        core = MtCore()
        ea = FakeEA(core, self.url, "t").start()
        try:
            self.assertTrue(wait(lambda: self.be.state["account"] is not None))
            ea._exec = lambda cid, action, a: "NOPE|%s" % cid                     # EA treo: không trả kết quả
            with self.assertRaises(BridgeError) as cm:
                GatewayBackend(self.url, "t").market("EURUSD", "buy", 0.01)
            self.assertIn("không phản hồi", str(cm.exception))
            self.assertEqual(self.be.queue, [])                                    # lệnh quá hạn bị gỡ khỏi hàng đợi
        finally:
            ea.close()

    def test_ea_going_stale_is_detected(self):
        core = MtCore()
        ea = FakeEA(core, self.url, "t").start()
        self.assertTrue(wait(lambda: self.be.state["account"] is not None))
        ea.close()
        time.sleep(0.8)
        with self.assertRaises(BridgeError):
            GatewayBackend(self.url, "t").positions()


# =========================================================================================== Profile (REST bất kỳ)
class _Vendor(BaseHTTPRequestHandler):
    """Một dịch vụ REST 'lạ' có hình dạng JSON khác hẳn - để chứng minh ProfileBackend ánh xạ được bằng cấu hình."""
    core = None
    seen = []

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _h(self, m):
        import urllib.parse
        u = urllib.parse.urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n)) if n else {}
        c = _Vendor.core
        _Vendor.seen.append((m, u.path, dict(urllib.parse.parse_qsl(u.query)), body, self.headers.get("X-Key")))
        if self.headers.get("X-Key") != "k-1":
            return self._send({"err": "auth"}, 403)
        p = u.path
        if p == "/api/acct":
            return self._send({"data": {"bal": c.balance, "eq": c.balance, "lev": 50, "ccy": "USD", "hedge": True}})
        if p == "/api/symbols":
            return self._send({"result": sorted(c.prices)})
        if p.startswith("/api/price/"):
            b, a = c.prices[p.rsplit("/", 1)[1]]
            return self._send({"data": {"b": b, "a": a, "t": int(time.time() * 1000)}})
        if p == "/api/open":
            try:
                oid, pid, px = c.open(body["sym"], body["dir"].lower(), body["lots"])
            except ValueError as e:
                return self._send({"err": str(e)}, 400)
            return self._send({"ticket": oid, "pos": pid, "fill": px})
        if p == "/api/positions":
            return self._send({"items": [{"ticket": x["id"], "sym": x["symbol"], "dir": x["side"].upper(), "lots": x["volume"], "open": x["price"], "t": x["time"]}
                                         for x in c.positions.values()]})
        if p.startswith("/api/close/"):
            oid, px, v = c.close(p.rsplit("/", 1)[1], body.get("lots") or None)
            return self._send({"ticket": oid, "fill": px})
        return self._send({"err": "unknown"}, 404)

    def do_GET(self):
        self._h("GET")

    def do_POST(self):
        self._h("POST")


PROFILE = {"name": "vendorx", "base": None, "headers": {"X-Key": "{token}"}, "side": {"buy": "BUY", "sell": "SELL"},
           "ops": {"account": {"path": "/api/acct", "map": {"balance": "data.bal", "equity": "data.eq", "leverage": "data.lev", "currency": "data.ccy", "hedging": "data.hedge"}},
                   "symbols": {"path": "/api/symbols", "list": "result"},
                   "tick": {"path": "/api/price/{symbol}", "map": {"bid": "data.b", "ask": "data.a", "time": "data.t"}},
                   "positions": {"path": "/api/positions", "list": "items", "map": {"id": "ticket", "symbol": "sym", "side": "dir", "volume": "lots", "price": "open", "time": "t"}},
                   "market": {"method": "POST", "path": "/api/open", "body": {"sym": "{symbol}", "dir": "{side}", "lots": "{volume}"},
                              "map": {"order_id": "ticket", "position_id": "pos", "price": "fill"}},
                   "close": {"method": "POST", "path": "/api/close/{position_id}", "body": {"lots": "{volume}"}, "map": {"order_id": "ticket", "price": "fill"}}}}


class TestProfile(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        _Vendor.core = cls.core
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), _Vendor)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.profile = dict(PROFILE, base=cls.base)

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def setUp(self):
        ratelimit.reset_all()
        self.core.positions.clear(); self.core.deals.clear(); self.core.balance = 10000.0; self.core.log.clear()
        _Vendor.seen.clear()
        self.be = ProfileBackend(self.profile, token="k-1")
        self.broker = MtBroker(self.be)
        self.feed = MtFeed(self.be)

    def test_account_symbols_tick_via_mapping(self):
        self.assertEqual(self.broker.prepare("EURUSD"), 10000.0)
        self.assertEqual(self.feed.symbols(), ["EURUSD", "XAUUSD"])
        t = self.feed.tick("EURUSD")
        self.assertAlmostEqual(t.ask, 1.1002, 5)
        self.assertLess(abs(t.time - time.time()), 30)                            # epoch ms -> giây

    def test_templates_headers_side_mapping_and_number_types(self):
        f = self.broker.market_order("EURUSD", "buy", 0.05)
        m, path, q, body, key = [s for s in _Vendor.seen if s[1] == "/api/open"][0]
        self.assertEqual((m, key), ("POST", "k-1"))
        self.assertEqual(body, {"sym": "EURUSD", "dir": "BUY", "lots": 0.05})          # 'BUY' theo bảng side; lots giữ kiểu SỐ
        self.assertAlmostEqual(f.price, 1.1002, 5)

    def test_close_by_position_path_template(self):
        self.broker.market_order("EURUSD", "buy", 0.05)
        f = self.broker.close_market("EURUSD", "buy", 0.05)
        self.assertEqual(self.core.positions, {})
        self.assertTrue(any(s[1].startswith("/api/close/") for s in _Vendor.seen))
        self.assertAlmostEqual(f.price, 1.1000, 5)

    def test_unsupported_operation_is_clear(self):
        with self.assertRaises(BridgeError) as cm:
            self.be.orders()
        self.assertIn("không hỗ trợ thao tác 'orders'", str(cm.exception))
        self.assertEqual(self.broker.native_pending, set())
        with self.assertRaises(BridgeError):
            self.broker.place_pending("EURUSD", "buy", "limit", 0.01, 1.0)

    def test_auth_failure_and_bad_profile(self):
        with self.assertRaises(BridgeError) as cm:
            ProfileBackend(self.profile, token="bad").account()
        self.assertEqual(cm.exception.status, 403)
        with self.assertRaises(BridgeError):
            ProfileBackend("không phải json")
        with self.assertRaises(BridgeError):
            ProfileBackend({"name": "x"})
        self.assertIsNotNone(ProfileBackend(json.dumps(self.profile)))                # nhận cả chuỗi JSON

    def test_path_get(self):
        d = {"a": {"b": [{"c": 5}, {"c": 6}]}}
        self.assertEqual((_path_get(d, "a.b.1.c"), _path_get(d, "a.b.-1.c"), _path_get(d, "a.x.y"), _path_get(d, "a.b.9.c")), (6, 6, None, None))


# =========================================================================================== engine + cầu nối
def make_session(broker, **over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0,
              native_sync_s=0.5)
    st.update(over)
    alarms = []
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), alarm_cb=lambda t, x: alarms.append(t))
    s.events = deque(maxlen=5000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = ["EURUSD"]
    s.alarms, s.broker = alarms, broker
    return s


class TestEngineOverBridge(GatewayFixture, unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = MtCore()
        cls.be = mt_gateway.Mt5Backend(mt5=FakeMt5(cls.core))
        cls.start_gateway(cls.be)

    @classmethod
    def tearDownClass(cls):
        cls.stop_gateway()

    def setUp(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.balance = 10000.0; c.reject_next = None; c.log.clear()
        c.prices["EURUSD"] = [1.1000, 1.1002]

    def test_native_stop_limit_through_whole_stack(self):
        broker = MtBroker(GatewayBackend(self.url, self.token))
        s = make_session(broker)
        s.account.balance = broker.prepare("EURUSD")
        s.process_tick(Tick("EURUSD", 1000.0, 1.1000, 1.1002))
        r = s.place_pending("EURUSD", "buy", "stop_limit", 0.05, 1.1045, stop_price=1.1050)
        self.assertTrue(r.ok, r.message)
        o = s.account.pending[r.order.id]
        self.assertTrue(o.native_id)
        self.core.set_price("EURUSD", 1.1055, 1.1057)                              # ask >= 1.1050: kích hoạt -> thành lệnh limit @1.1045
        s._sync_native_pending(force=True)
        self.assertIn(r.order.id, s.account.pending)                               # chưa khớp (ask 1.1057 > 1.1045)
        self.core.set_price("EURUSD", 1.1040, 1.1042)                              # ask <= 1.1045: khớp
        s._sync_native_pending(force=True)
        p = s.account.positions[r.order.id]
        self.assertEqual((p.side, p.volume), ("buy", 0.05))
        self.assertAlmostEqual(p.open_price, 1.1045, 4)
        self.assertEqual(s.reconcile_now(), [])                                    # sổ app = vị thế trên terminal

    def test_cancel_native_and_reconcile_orphan_detection(self):
        broker = MtBroker(GatewayBackend(self.url, self.token))
        s = make_session(broker)
        s.process_tick(Tick("EURUSD", 1000.0, 1.1000, 1.1002))
        r = s.place_pending("EURUSD", "sell", "limit", 0.02, 1.1200)
        self.assertEqual(len(self.core.orders), 1)
        self.assertTrue(s.cancel_order(r.order.id).ok)
        self.assertEqual(self.core.orders, {})
        self.core.open("EURUSD", "buy", 0.03)                                       # bạn bấm tay trên terminal
        iss = s.reconcile_now()
        self.assertEqual([i["kind"] for i in iss], ["orphan"])


class TestMakeBackend(unittest.TestCase):
    def test_settings_to_backend(self):
        b = make_backend({"exchange": "metaapi", "metaapi_token": "t", "metaapi_account": "a", "metaapi_region": "london"})
        self.assertIn("london", b.url)
        self.assertIn("mt-market-data-client-api-v1.london", b.data_url)
        g = make_backend({"exchange": "mt5gw", "mt5gw_url": "10.0.0.5:8765", "mt5gw_token": "x"})
        self.assertEqual(g.url, "http://10.0.0.5:8765")
        with self.assertRaises(BridgeError):
            make_backend({"exchange": "mt5gw", "mt5gw_url": ""})
        with self.assertRaises(BridgeError):
            make_backend({"exchange": "binance"})


class TestTfNames(unittest.TestCase):
    def test_gateway_timeframes(self):
        self.assertEqual([mt_gateway.tf_name(x) for x in ("1m", "15m", "1h", "4h", "1d", "1w", "1mo")], ["M1", "M15", "H1", "H4", "D1", "W1", "MN1"])
        self.assertEqual([mt_gateway.tf_minutes(x) for x in ("1m", "1h", "1d", "1w")], [1, 60, 1440, 10080])
        with self.assertRaises(mt_gateway.GwError):
            mt_gateway.tf_name("abc")


if __name__ == "__main__":
    unittest.main()
