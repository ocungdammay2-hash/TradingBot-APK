"""Backtest chi tiết chi phí (spread/phí/trượt giá/swap/funding), danh mục nhiều mã, walk-forward."""
import os
import sys
import tempfile
import threading
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea.backtest import CostModel, cost_breakdown, optimize, run_backtest, run_portfolio, walk_forward     # noqa: E402
from pyea.engine import Account                                                                              # noqa: E402
from pyea.feeds import SimFeed, fetch_history                                                                # noqa: E402
from pyea.sdk import Candle, Position                                                                        # noqa: E402
from pyea.settings import default_settings                                                                   # noqa: E402
from pyea.storage import Store                                                                               # noqa: E402

TMP = tempfile.mkdtemp()
STORE = Store(TMP)
STORE.seed_examples()
BOTS = STORE.bots_dir
MA = os.path.join(BOTS, "ma_cross.py")

HOLD = '''# -*- coding: utf-8 -*-
from pyea import BaseBot, Input


class Hold(BaseBot):
    inputs = {"lot": Input(1.0, "lot"), "side": Input("buy", "side")}

    def on_init(self):
        self.opened = False

    def on_bar(self, candle):
        if self.opened:
            return
        self.opened = True
        if self.p.side == "buy":
            self.api.buy(self.p.lot, reason="mua giữ")
        else:
            self.api.sell(self.p.lot, reason="bán giữ")
'''
HOLD_PATH = os.path.join(TMP, "hold.py")
open(HOLD_PATH, "w", encoding="utf-8").write(HOLD)


def S(**over):
    s = default_settings()
    s.update(initial_balance=10000.0, leverage=10.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0, close_on_stop=True)
    s.update(over)
    return s


def flat(n=200, price=100.0, step=300, t0=1_700_000_000):
    return [Candle(t0 + i * step, price, price, price, price, 1.0) for i in range(n)]


class TestAccountCosts(unittest.TestCase):
    def test_default_fee_identical_to_percent_of_notional(self):
        a = Account(1000.0, 0.1, 1.0)
        self.assertAlmostEqual(a.fee_for(2.0, 50.0), 2.0 * 50.0 * 0.001, 12)
        p = a.open("X", "buy", 2.0, 50.0, 0, 0, "", 0.0)
        self.assertAlmostEqual(p.fee, 0.1, 12)
        tr = a.close(p.id, 60.0, 1.0, "x")
        self.assertAlmostEqual(tr.profit, 20.0 - 0.1 - 0.12, 12)

    def test_per_unit_and_minimum_fee(self):
        a = Account(1000.0, 0.0, 1.0)
        a.fee_per_unit, a.fee_min = 1.5, 5.0
        self.assertEqual(a.fee_for(2.0, 100.0), 5.0)                  # 3.0 < tối thiểu 5.0
        self.assertEqual(a.fee_for(10.0, 100.0), 15.0)
        a.fee_rate = 0.001
        self.assertAlmostEqual(a.fee_for(10.0, 100.0), 15.0 + 1.0, 12)

    def test_swap_accrual_reduces_floating_and_closed_profit_and_splits_on_partial_close(self):
        a = Account(1000.0, 0.0, 1.0)
        p = a.open("X", "buy", 4.0, 100.0, 0, 0, "", 0.0)
        a.accrue_swap(p, 2.0)
        self.assertAlmostEqual(p.profit, -2.0, 12)
        from pyea.sdk import Tick
        a.mark(Tick("X", 1.0, 101.0, 101.0))
        self.assertAlmostEqual(p.profit, 4.0 - 2.0, 12)               # lãi gộp 4 trừ swap 2
        tr = a.reduce(p.id, 1.0, 101.0, 2.0, "part")                   # đóng 1/4: nhận 1/4 swap
        self.assertAlmostEqual(tr.swap, 0.5, 12)
        self.assertAlmostEqual(tr.profit, 1.0 - 0.5, 12)
        self.assertAlmostEqual(p.swap, 1.5, 12)
        tr2 = a.close(p.id, 101.0, 3.0, "rest")
        self.assertAlmostEqual(tr2.swap, 1.5, 12)
        self.assertAlmostEqual(a.balance, 1000.0 + 4.0 - 2.0, 12)
        self.assertAlmostEqual(a.swap_total, 2.0, 12)
        self.assertAlmostEqual(tr.fee + tr2.fee, 0.0, 12)

    def test_position_and_trade_have_new_fields_with_safe_defaults(self):
        self.assertEqual(Position(1, "X", "buy", 1.0, 1.0, 0.0).swap, 0.0)
        from pyea.engine import _mk
        from pyea.sdk import Trade
        t = _mk(Trade, {"id": 1, "symbol": "X", "side": "buy", "volume": 1, "open_price": 1, "close_price": 2, "open_time": 0, "close_time": 1,
                        "profit": 1, "reason": "r"})                   # sổ lưu từ phiên bản cũ (không có swap/fee) vẫn nạp được
        self.assertEqual((t.swap, t.fee), (0.0, 0.0))


class TestCostModel(unittest.TestCase):
    def test_half_spread_points_vs_percent_and_slippage(self):
        self.assertAlmostEqual(CostModel(spread_pct=0.2).half_spread(100.0), 0.1, 12)
        self.assertAlmostEqual(CostModel(spread_pct=0.2, spread_points=0.5).half_spread(100.0), 0.25, 12)       # points ưu tiên
        self.assertAlmostEqual(CostModel(spread_pct=0.2, slippage_pct=0.05).half_spread(100.0), 0.1 + 0.05, 12)

    def test_from_settings_and_per_symbol_override(self):
        cm = CostModel.from_settings(S(spread_pct=0.05, commission_pct=0.1, bt_commission_per_lot=3.5, bt_slippage_pct=0.02, bt_funding_8h_pct=0.01))
        self.assertEqual((cm.spread_pct, cm.commission_pct, cm.commission_per_lot, cm.slippage_pct, cm.funding_8h_pct), (0.05, 0.1, 3.5, 0.02, 0.01))
        cm.per_symbol = {"XAUUSD": {"spread_points": 0.25, "bogus": 1}}
        self.assertEqual(cm.for_symbol("XAUUSD").spread_points, 0.25)
        self.assertEqual(cm.for_symbol("EURUSD").spread_points, 0.0)
        self.assertEqual(CostModel.from_settings(S(), spread_pct=0.3).spread_pct, 0.3)

    def test_swap_amount_signs(self):
        cm = CostModel(swap_long_pct_day=0.1, swap_short_pct_day=-0.05, funding_8h_pct=0.02)
        long_ = Position(1, "X", "buy", 2.0, 100.0, 0.0)
        short = Position(2, "X", "sell", 2.0, 100.0, 0.0)
        day = 86400.0
        self.assertAlmostEqual(cm.swap_amount(long_, 100.0, day), 200 * 0.1 / 100 + 200 * 0.02 / 100 * 3, 12)      # swap + 3 kỳ funding
        self.assertAlmostEqual(cm.swap_amount(short, 100.0, day), 200 * -0.05 / 100 - 200 * 0.02 / 100 * 3, 12)    # bán: swap âm = nhận; funding đảo dấu


class TestBacktestCostsAnalytic(unittest.TestCase):
    def run_hold(self, side="buy", lot=1.0, n=200, **over):
        s = S(**over)
        return run_backtest(HOLD_PATH, {"lot": lot, "side": side}, s, "TEST", "5m", flat(n), 20, "ohlc")

    def test_no_costs_flat_market_zero_pnl(self):
        r = self.run_hold()
        self.assertTrue(r.ok, r.error)
        self.assertEqual(len(r.trades), 1)
        self.assertAlmostEqual(r.trades[0].profit, 0.0, 9)
        self.assertAlmostEqual(r.report["Tổng chi phí"], 0.0, 9)

    def test_spread_and_slippage_exact(self):
        r = self.run_hold(spread_pct=0.2, bt_slippage_pct=0.05)
        t = r.trades[0]
        self.assertAlmostEqual(t.open_price, 100.15, 9)                    # mua tại ask = 100 + 0.1 + 0.05
        self.assertAlmostEqual(t.close_price, 99.85, 9)                    # đóng tại bid
        self.assertAlmostEqual(t.profit, -0.30, 9)
        rp = r.report
        self.assertAlmostEqual(rp["Spread đã trả (ước)"], 0.20, 9)
        self.assertAlmostEqual(rp["Trượt giá (ước)"], 0.10, 9)
        self.assertAlmostEqual(rp["Tổng chi phí"], 0.30, 9)
        self.assertAlmostEqual(rp["Lãi gộp (trước chi phí)"], 0.0, 9)

    def test_fixed_points_spread_beats_percent(self):
        r = self.run_hold(spread_pct=5.0, bt_spread_points=0.4)
        self.assertAlmostEqual(r.trades[0].profit, -0.4, 9)

    def test_commission_per_lot_percent_and_minimum(self):
        r = self.run_hold(lot=2.0, bt_commission_per_lot=1.5)
        self.assertAlmostEqual(r.trades[0].fee, 6.0, 9)                    # 2 lot × 1.5 × 2 chiều
        self.assertAlmostEqual(r.trades[0].profit, -6.0, 9)
        self.assertAlmostEqual(r.report["Phí giao dịch"], 6.0, 9)
        r2 = self.run_hold(lot=2.0, bt_commission_per_lot=1.5, bt_commission_min=5.0)
        self.assertAlmostEqual(r2.trades[0].fee, 10.0, 9)                  # mỗi chiều tối thiểu 5
        r3 = self.run_hold(lot=2.0, commission_pct=0.1)
        self.assertAlmostEqual(r3.trades[0].fee, 2 * 2.0 * 100.0 * 0.001, 9)   # hành vi cũ: % notional hai chiều

    def test_swap_proportional_to_rate_and_time(self):
        a = self.run_hold(bt_swap_long_pct_day=0.1)
        b = self.run_hold(bt_swap_long_pct_day=0.2)
        t = a.trades[0]
        self.assertGreater(t.swap, 0)
        self.assertAlmostEqual(b.trades[0].swap / t.swap, 2.0, 9)
        n0 = (t.close_time - t.open_time) / 300.0
        per_bar = 1.0 * 100.0 * 0.1 / 100.0 * 300.0 / 86400.0
        self.assertTrue(any(abs(t.swap - per_bar * n) < 1e-9 for n in (round(n0) - 1, round(n0), round(n0) + 1)), (t.swap, n0, per_bar))
        self.assertAlmostEqual(t.profit, -t.swap, 9)                       # thị trường đứng yên: lỗ = swap
        longer = self.run_hold(n=400, bt_swap_long_pct_day=0.1)
        self.assertGreater(longer.trades[0].swap, t.swap * 1.9)            # giữ lâu gấp đôi => swap gấp đôi

    def test_funding_sign_buy_pays_sell_receives(self):
        buy = self.run_hold("buy", bt_funding_8h_pct=0.05)
        sell = self.run_hold("sell", bt_funding_8h_pct=0.05)
        self.assertGreater(buy.trades[0].swap, 0)
        self.assertLess(sell.trades[0].swap, 0)
        self.assertAlmostEqual(sell.trades[0].profit, -sell.trades[0].swap, 9)
        self.assertGreater(sell.trades[0].profit, 0)                       # bán nhận funding => lãi
        self.assertAlmostEqual(buy.trades[0].swap, -sell.trades[0].swap, 9)

    def test_equity_curve_reflects_swap_while_position_open(self):
        r = self.run_hold(bt_swap_long_pct_day=1.0)
        eq = [c[2] for c in r.curve]
        self.assertLess(eq[-2], eq[len(eq) // 3] - 1e-9)                   # equity giảm dần khi giữ lệnh

    def test_default_costs_unchanged_vs_explicit_default_model(self):
        c = fetch_history(SimFeed(seed=7), "EURUSD", "15m", 1500)
        s = S(spread_pct=0.01, commission_pct=0.02)
        a = run_backtest(MA, {"lot": 1000.0}, s, "EURUSD", "15m", c, 100, "ohlc")
        b = run_backtest(MA, {"lot": 1000.0}, s, "EURUSD", "15m", c, 100, "ohlc", costs=CostModel.from_settings(s))
        self.assertEqual([round(t.profit, 9) for t in a.trades], [round(t.profit, 9) for t in b.trades])
        self.assertTrue(a.trades)

    def test_more_costs_never_improve_result(self):
        c = fetch_history(SimFeed(seed=9), "EURUSD", "15m", 1500)
        base = run_backtest(MA, {"lot": 1000.0}, S(), "EURUSD", "15m", c, 100, "ohlc")
        costly = run_backtest(MA, {"lot": 1000.0}, S(bt_commission_per_lot=0.002, bt_slippage_pct=0.01, bt_swap_long_pct_day=0.05,
                                                     bt_swap_short_pct_day=0.05), "EURUSD", "15m", c, 100, "ohlc")
        self.assertLess(costly.report["Lợi nhuận ròng"], base.report["Lợi nhuận ròng"])
        self.assertGreater(costly.report["Tổng chi phí"], base.report["Tổng chi phí"])
        self.assertAlmostEqual(costly.report["Lãi gộp (trước chi phí)"] - costly.report["Tổng chi phí"], costly.report["Lợi nhuận ròng"], 6)

    def test_per_symbol_costs_override(self):
        cm = CostModel(spread_pct=0.0, per_symbol={"TEST": {"spread_points": 0.6}})
        r = run_backtest(HOLD_PATH, {"lot": 1.0}, S(), "TEST", "5m", flat(200), 20, "ohlc", costs=cm)
        self.assertAlmostEqual(r.trades[0].profit, -0.6, 9)


class TestPortfolio(unittest.TestCase):
    def entries(self):
        return [{"bot_path": MA, "params": {"lot": 500.0}, "symbol": "EURUSD", "tf": "15m", "candles": fetch_history(SimFeed(seed=3), "EURUSD", "15m", 1500)},
                {"bot_path": MA, "params": {"fast": 6, "slow": 20, "lot": 0.02}, "symbol": "BTCUSD", "tf": "5m",
                 "candles": fetch_history(SimFeed(seed=4), "BTCUSD", "5m", 3000)}]

    def test_two_bots_one_account_breakdown_matches_total(self):
        r = run_portfolio(self.entries(), S(), 100, "ohlc")
        self.assertTrue(r.ok, r.error)
        self.assertEqual(set(r.by_bot), {"bt1", "bt2"})
        self.assertTrue(all(v["trades"] > 3 for v in r.by_bot.values()))
        self.assertEqual(sum(v["trades"] for v in r.by_bot.values()), len(r.trades))
        self.assertAlmostEqual(sum(v["net"] for v in r.by_bot.values()), sum(t.profit for t in r.trades), 6)
        self.assertAlmostEqual(r.report["Số dư cuối"], 10000.0 + sum(t.profit for t in r.trades), 6)
        self.assertEqual(r.report["Số bot"], 2)
        self.assertEqual({t.symbol for t in r.trades}, {"EURUSD", "BTCUSD"})
        times = [c[0] for c in r.curve]
        self.assertEqual(times, sorted(times))                              # tick của hai mã được trộn đúng thứ tự thời gian

    def test_deterministic_and_single_entry_equals_run_backtest(self):
        e = self.entries()
        a = run_portfolio(e, S(), 100, "ohlc")
        b = run_portfolio(e, S(), 100, "ohlc")
        self.assertEqual([round(t.profit, 9) for t in a.trades], [round(t.profit, 9) for t in b.trades])
        one = run_portfolio(e[:1], S(), 100, "ohlc")
        solo = run_backtest(MA, e[0]["params"], S(), "EURUSD", "15m", e[0]["candles"], 100, "ohlc")
        self.assertEqual([round(t.profit, 6) for t in one.trades], [round(t.profit, 6) for t in solo.trades])

    def test_shared_margin_blocks_second_bot(self):
        e = self.entries()
        r = run_portfolio(e, S(initial_balance=3000.0, leverage=1.0), 100, "ohlc")        # vốn nhỏ, bot lớn chiếm ký quỹ
        self.assertTrue(r.ok, r.error)
        free = run_portfolio(e, S(initial_balance=3000.0, leverage=100.0), 100, "ohlc")
        self.assertLessEqual(len(r.trades), len(free.trades))

    def test_costs_per_symbol_in_portfolio(self):
        e = [{"bot_path": HOLD_PATH, "params": {"lot": 1.0}, "symbol": "AAA", "tf": "5m", "candles": flat(150)},
             {"bot_path": HOLD_PATH, "params": {"lot": 1.0}, "symbol": "BBB", "tf": "5m", "candles": flat(150, 50.0)}]
        cm = CostModel(spread_pct=0.0, per_symbol={"AAA": {"spread_points": 0.2}, "BBB": {"spread_points": 0.1}})
        r = run_portfolio(e, S(), 20, "ohlc", costs=cm)
        by = {t.symbol: t.profit for t in r.trades}
        self.assertAlmostEqual(by["AAA"], -0.2, 9)
        self.assertAlmostEqual(by["BBB"], -0.1, 9)
        self.assertAlmostEqual(r.report["Spread đã trả (ước)"], 0.3, 9)

    def test_errors_and_stop(self):
        self.assertFalse(run_portfolio([], S()).ok)
        bad = [{"bot_path": MA, "params": {}, "symbol": "X", "tf": "5m", "candles": flat(3)}]
        r = run_portfolio(bad, S())
        self.assertFalse(r.ok)
        self.assertIn("Không đủ dữ liệu", r.error)
        ev = threading.Event()
        ev.set()
        r2 = run_portfolio(self.entries(), S(), 100, "ohlc", stop_event=ev)
        self.assertIn("dừng", r2.error)


class TestWalkForward(unittest.TestCase):
    def setUp(self):
        self.c = fetch_history(SimFeed(seed=21), "EURUSD", "5m", 1800)
        self.grid = {"fast": [5, 8], "slow": [20, 30]}

    def wf(self, **kw):
        a = dict(base_params={"lot": 1000.0}, grid=self.grid, settings=S(), is_bars=600, oos_bars=200, warmup=100, anchored=False)
        a.update(kw)
        return walk_forward(MA, a["base_params"], a["grid"], a["settings"], "EURUSD", "5m", self.c, a["warmup"], a["is_bars"], a["oos_bars"],
                            anchored=a["anchored"])

    def test_window_count_ranges_and_no_overlap(self):
        r = self.wf()
        self.assertTrue(r["ok"], r["error"])
        m = len(self.c) - 100
        self.assertEqual(len(r["windows"]), (m - 600 - 200) // 200 + 1)
        for w in r["windows"]:
            self.assertLess(w["is_from"], w["is_to"])
            self.assertLess(w["is_to"], w["oos_from"])                     # OOS đứng SAU IS
            self.assertLess(w["oos_from"], w["oos_to"])
        for a, b in zip(r["windows"], r["windows"][1:]):
            self.assertLess(a["oos_to"], b["oos_from"])                    # các đoạn OOS không chồng nhau
            self.assertEqual(round(b["oos_from"] - a["oos_from"]), 200 * 300)     # trượt đúng oos_bars nến
        self.assertEqual(r["windows"][0]["oos_from"] - r["windows"][0]["is_from"], 600 * 300)

    def test_params_chosen_from_grid_and_oos_is_unseen_data(self):
        r = self.wf()
        for w in r["windows"]:
            self.assertIn(w["params"]["fast"], (5, 8))
            self.assertIn(w["params"]["slow"], (20, 30))
            self.assertEqual(w["params"]["lot"], 1000.0)
        # tham số IS tốt nhất phải ĐÚNG là cái tối ưu hoá chọn trên đoạn IS (kiểm lại bằng optimize độc lập)
        w = r["windows"][0]
        cs = [c for c in self.c]
        w0 = 100
        isc = cs[w0 + 0 - 100: w0 + 600]
        best = optimize(MA, {"lot": 1000.0}, self.grid, S(), "EURUSD", "5m", isc, 100, "open", 1, "Lợi nhuận ròng", 60)
        self.assertEqual(w["params"], best[0]["params"])

    def test_stitched_report_equals_sum_of_oos_windows(self):
        r = self.wf()
        self.assertAlmostEqual(sum(t.profit for t in r["trades"]), sum(w["oos_net"] for w in r["windows"]), 6)
        self.assertEqual(r["report"]["Tổng số lệnh"], len(r["trades"]))
        self.assertAlmostEqual(r["report"]["Số dư cuối"], 10000.0 + sum(w["oos_net"] for w in r["windows"]), 6)
        times = [c[0] for c in r["curve"]]
        self.assertEqual(times, sorted(times))
        pct = r["positive_windows_pct"]
        self.assertEqual(pct, len([w for w in r["windows"] if w["oos_net"] > 0]) / len(r["windows"]) * 100.0)

    def test_anchored_grows_in_sample(self):
        r = self.wf(anchored=True)
        self.assertTrue(r["ok"], r["error"])
        self.assertEqual(len({w["is_from"] for w in r["windows"]}), 1)     # IS luôn bắt đầu từ đầu
        spans = [w["is_to"] - w["is_from"] for w in r["windows"]]
        self.assertEqual(spans, sorted(spans))
        self.assertGreater(spans[-1], spans[0])

    def test_deterministic(self):
        a, b = self.wf(), self.wf()
        self.assertEqual([w["params"] for w in a["windows"]], [w["params"] for w in b["windows"]])
        self.assertEqual([round(t.profit, 8) for t in a["trades"]], [round(t.profit, 8) for t in b["trades"]])

    def test_wfe_defined_when_in_sample_positive(self):
        r = self.wf()
        if r["wfe"] is not None:
            self.assertIsInstance(r["wfe"], float)
        r2 = self.wf(grid=None, base_params={"lot": 1000.0})               # không lưới: chạy 1 bộ tham số cố định cho từng cửa sổ
        self.assertTrue(r2["ok"], r2["error"])
        self.assertEqual(len(r2["windows"]), len(r["windows"]))

    def test_validation_and_stop(self):
        short = walk_forward(MA, {"lot": 1.0}, self.grid, S(), "EURUSD", "5m", self.c[:300], 100, 600, 200)
        self.assertFalse(short["ok"])
        self.assertIn("Không đủ dữ liệu", short["error"])
        tiny = walk_forward(MA, {"lot": 1.0}, self.grid, S(), "EURUSD", "5m", self.c, 100, 5, 2)
        self.assertFalse(tiny["ok"])
        ev = threading.Event()
        ev.set()
        st = walk_forward(MA, {"lot": 1000.0}, self.grid, S(), "EURUSD", "5m", self.c, 100, 600, 200, stop_event=ev)
        self.assertIn("dừng", st["error"])
        self.assertEqual(st["windows"], [])

    def test_costs_flow_into_walk_forward(self):
        free = self.wf(grid=None)
        costly = walk_forward(MA, {"lot": 1000.0}, None, S(spread_pct=0.05, bt_commission_per_lot=0.01), "EURUSD", "5m", self.c, 100, 600, 200)
        self.assertLessEqual(sum(w["oos_net"] for w in costly["windows"]), sum(w["oos_net"] for w in free["windows"]))


if __name__ == "__main__":
    unittest.main()
