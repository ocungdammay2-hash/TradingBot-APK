import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import netwatch as N


class T(unittest.TestCase):
    def test_probe(self):
        def bad(a, t): raise OSError("x")
        class S:
            def close(self): pass
        self.assertFalse(N.probe(connect=bad))
        self.assertTrue(N.probe(connect=lambda a, t: S()))

    def test_state_changes_need_two_failures(self):
        t = [0.0]
        res = [True]
        w = N.NetWatch(fn=lambda: res[0], interval=1, fails=2, clock=lambda: t[0])
        self.assertEqual(w.check(wait=True), (True, False))
        res[0] = False
        t[0] = 2
        self.assertEqual(w.check(wait=True), (True, False))          # lần lỗi đầu: chưa báo
        t[0] = 4
        self.assertEqual(w.check(wait=True), (False, True))          # lần lỗi thứ 2 -> mất mạng
        res[0] = True
        t[0] = 8
        self.assertEqual(w.check(wait=True), (True, True))


if __name__ == "__main__":
    unittest.main()


class TestUIBanner(unittest.TestCase):
    def _F(self, on, ch):
        import time
        class F:
            since = time.time()
            def check(self): return (on, ch)
        return F()

    def test_banner_only_when_connected_and_mutable(self):
        import test_ui_smoke as T
        app = T.make_app()
        app._net = self._F(False, True)
        app.settings["net_alert"] = "connected"
        app._net_step()
        self.assertEqual(app.net_banner.height, 0)             # chưa kết nối/không chạy bot -> không báo
        app.settings["net_alert"] = "always"
        app._net_step()
        self.assertGreater(app.net_banner.height, 0)
        self.assertIn("MẤT MẠNG", app.net_lbl.text)
        app._net_banner_touch(app.net_banner, type("T", (), {"pos": (app.net_banner.x + 1, app.net_banner.y + 1)})())
        app._net_step()
        self.assertEqual(app.net_banner.height, 0)             # chạm = tắt tới khi có mạng lại
        app.settings["net_alert"] = "off"
        app._net_mute = False
        app._net_step()
        self.assertEqual(app.net_banner.height, 0)
        app._net = self._F(True, True)
        app._net_step()
        self.assertEqual(app.net_banner.height, 0)
