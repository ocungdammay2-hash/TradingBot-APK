"""cTrader Open API (nối thẳng từ điện thoại): chạy với máy chủ GIẢ theo đúng tài liệu - KHÔNG phải sàn thật."""
import json
import os
import sys
import tempfile
import threading
import time
import unittest
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import kivy_stub                                                             # noqa: E402
kivy_stub.install()
from fake_ctrader import FakeCTrader                                         # noqa: E402
from pyea import bridges, ctrader                                            # noqa: E402
from pyea.bridges import BridgeError, MtBroker, MtFeed                       # noqa: E402


def settings(fake, tmp, **kw):
    s = {"exchange": "ctrader", "ctrader_client_id": "cid", "ctrader_client_secret": "sec", "ctrader_access_token": "AT1", "ctrader_refresh_token": "RT1",
         "ctrader_env": "demo", "ctrader_ws_url": fake.url, "ctrader_tokens_path": os.path.join(tmp, "tok.json")}
    s.update(kw)
    return s


class Base(unittest.TestCase):
    def setUp(self):
        bridges._BACKENDS.clear()
        self.tmp = tempfile.mkdtemp()
        self.fake = FakeCTrader()
        self.st = settings(self.fake, self.tmp)
        self.b = ctrader.make_backend(self.st)

    def tearDown(self):
        self.b.close()
        self.fake.close()


class TestConnect(Base):
    def test_auth_picks_demo_account_and_lists_symbols(self):
        self.assertEqual(self.b.symbols(), ["EURUSD", "XAUUSD"])
        self.assertEqual(self.b.c.account_id, 222)                                   # env demo -> tài khoản demo, không phải live
        pts = [p for p, _ in self.fake.log]
        self.assertEqual(pts[:4], [2100, 2149, 2102, 2114])                          # đúng trình tự tài liệu

    def test_live_env_picks_live_account(self):
        b = ctrader.make_backend(dict(self.st, ctrader_env="live", ctrader_tokens_path=os.path.join(self.tmp, "t2.json")))
        try:
            b.symbols()
            self.assertEqual(b.c.account_id, 111)
        finally:
            b.close()

    def test_wrong_app_secret_gives_clear_error(self):
        b = ctrader.make_backend(dict(self.st, ctrader_client_secret="bad", ctrader_tokens_path=os.path.join(self.tmp, "t3.json")))
        with self.assertRaises(BridgeError) as cm:
            b.symbols()
        self.assertIn("Client", str(cm.exception))

    def test_missing_credentials(self):
        b = ctrader.make_backend(dict(self.st, ctrader_client_id="", ctrader_tokens_path=os.path.join(self.tmp, "t4.json")))
        with self.assertRaises(BridgeError):
            b.symbols()

    def test_expired_token_refreshes_and_persists(self):
        self.fake.expire_token_once = True
        self.assertEqual(self.b.symbols(), ["EURUSD", "XAUUSD"])
        self.assertEqual(self.fake.access, "AT1n")
        d = json.load(open(self.st["ctrader_tokens_path"], encoding="utf-8"))
        self.assertEqual((d["access"], d["refresh"], d["origin"]), ("AT1n", "RT1n", "RT1"))
        # tiến trình/khởi động sau: Cài đặt vẫn giữ token cũ -> dùng token mới trong file
        t = ctrader.Tokens("AT1", "RT1", "cid", self.st["ctrader_tokens_path"])
        self.assertEqual((t.access, t.refresh), ("AT1n", "RT1n"))
        # người dùng dán token MỚI vào Cài đặt -> Cài đặt thắng
        t2 = ctrader.Tokens("ATX", "RTX", "cid", self.st["ctrader_tokens_path"])
        self.assertEqual((t2.access, t2.refresh), ("ATX", "RTX"))
        # khác client id -> bỏ file
        t3 = ctrader.Tokens("AT1", "RT1", "other", self.st["ctrader_tokens_path"])
        self.assertEqual(t3.access, "AT1")


class TestMarketData(Base):
    def test_spec_in_lots(self):
        sp = self.b.spec("EURUSD")
        self.assertAlmostEqual(sp["volume_min"], 0.01)
        self.assertAlmostEqual(sp["volume_step"], 0.01)
        self.assertAlmostEqual(self.b.spec("XAUUSD")["volume_min"], 0.01)

    def test_tick_from_spot_events_scaled(self):
        bid, ask, ts = self.b.tick("EURUSD")
        self.assertAlmostEqual(bid, 1.1)
        self.assertAlmostEqual(ask, 1.1001)
        self.fake.set_price(1, 1.2345)
        for _ in range(60):
            if abs(self.b.tick("EURUSD")[0] - 1.2345) < 1e-9:
                break
            time.sleep(0.05)
        self.assertAlmostEqual(self.b.tick("EURUSD")[0], 1.2345)
        self.assertTrue(abs(ts - time.time()) < 60)

    def test_candles_decode_and_order(self):
        cs = self.b.candles("EURUSD", "1h", 50)
        self.assertEqual(len(cs), 50)
        self.assertTrue(all(a.time < b.time for a, b in zip(cs, cs[1:])))
        c = cs[-1]
        self.assertTrue(c.low <= c.open <= c.high and c.low <= c.close <= c.high)
        self.assertAlmostEqual(c.high - c.low, 80 / 1e5, places=9)
        self.assertEqual(cs[1].time - cs[0].time, 3600)

    def test_candles_before_end_and_paging_with_window_limit(self):
        self.fake.max_bar_window_ms = 5 * 3600 * 1000                          # máy chủ chỉ cho cửa sổ 5 giờ: mã phải tự thu hẹp rồi gom đủ
        end = (int(time.time()) // 3600) * 3600
        cs = self.b.candles("EURUSD", "1h", 40, end=end)
        self.assertEqual(len(cs), 40)
        self.assertTrue(all(c.time < end for c in cs))
        self.assertEqual(len({c.time for c in cs}), 40)

    def test_unsupported_timeframe(self):
        with self.assertRaises(BridgeError):
            self.b.candles("EURUSD", "7m", 10)

    def test_unknown_symbol(self):
        with self.assertRaises(BridgeError):
            self.b.tick("NOPE")


class TestTrading(Base):
    def test_market_buy_position_and_account(self):
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.assertTrue(r["position_id"] and r["order_id"])
        self.assertAlmostEqual(r["price"], 1.1001)                                 # mua ở ask
        self.assertAlmostEqual(r["volume"], 0.10)
        ps = self.b.positions()
        self.assertEqual(len(ps), 1)
        p = ps[0]
        self.assertEqual((p["symbol"], p["side"], p["comment"]), ("EURUSD", "buy", "pyea"))
        self.assertAlmostEqual(p["volume"], 0.10)
        self.assertEqual(p["id"], r["position_id"])
        self.assertIn("profit", p)
        a = self.b.account()
        self.assertEqual((a["currency"], a["hedging"], a["leverage"]), ("USD", True, 100.0))
        self.assertAlmostEqual(a["balance"], 10000.0)
        self.assertAlmostEqual(a["margin"], 10.0)
        self.assertAlmostEqual(a["free_margin"], a["equity"] - 10.0)

    def test_volume_lots_snap_to_step_and_bad_volume(self):
        r = self.b.market("EURUSD", "sell", 0.057, "pyea")
        self.assertAlmostEqual(r["volume"], 0.05)
        with self.assertRaises(BridgeError):
            self.b.market("EURUSD", "buy", 0.001, "pyea")

    def test_close_partial_then_full_with_profit(self):
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.fake.set_price(1, 1.1100)
        c1 = self.b.close_position(r["position_id"], 0.04)
        self.assertAlmostEqual(c1["volume"], 0.04)
        self.assertAlmostEqual(c1["price"], 1.1100)
        self.assertAlmostEqual(self.b.positions()[0]["volume"], 0.06)
        self.b.close_position(r["position_id"])
        self.assertEqual(self.b.positions(), [])
        self.assertGreater(self.fake.balance, 10000.0)

    def test_close_missing_position(self):
        with self.assertRaises(BridgeError):
            self.b.close_position("999999")

    def test_modify_position_sltp(self):
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.b.modify_position(r["position_id"], 1.0950, 1.1200)
        p = self.b.positions()[0]
        self.assertAlmostEqual(p["sl"], 1.0950)
        self.assertAlmostEqual(p["tp"], 1.1200)

    def test_pending_place_modify_cancel(self):
        oid = self.b.place_pending("EURUSD", "buy", "limit", 0.10, 1.0900, None, None, "pyea")
        o = self.b.orders()
        self.assertEqual([(x["id"], x["kind"], x["side"]) for x in o], [(oid, "limit", "buy")])
        self.assertAlmostEqual(o[0]["price"], 1.09)
        self.assertAlmostEqual(o[0]["volume"], 0.10)
        self.b.modify_pending(oid, 1.0850, 1.0800, 1.1000)
        o = self.b.orders()[0]
        self.assertAlmostEqual(o["price"], 1.085)
        self.assertAlmostEqual(o["sl"], 1.08)
        self.b.cancel_pending(oid)
        self.assertEqual(self.b.orders(), [])
        oid2 = self.b.place_pending("EURUSD", "sell", "stop", 0.10, 1.0800, None, time.time() + 3600, "pyea")
        self.assertEqual(self.b.orders()[0]["kind"], "stop")
        self.b.cancel_pending(oid2)
        with self.assertRaises(BridgeError):
            self.b.place_pending("EURUSD", "buy", "stop_limit", 0.1, 1.0, 1.1, None, "pyea")

    def test_rejection_is_clear_and_not_retried(self):
        self.fake.fail_next = "NOT_ENOUGH_MONEY"
        n0 = len([1 for p, _ in self.fake.log if p == 2106])
        with self.assertRaises(BridgeError) as cm:
            self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.assertIn("ký quỹ", str(cm.exception))
        self.assertEqual(len([1 for p, _ in self.fake.log if p == 2106]) - n0, 1)    # lệnh giao dịch KHÔNG tự gửi lại

    def test_works_when_server_does_not_echo_client_msg_id(self):
        self.fake.drop_cmid = True
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.assertTrue(r["position_id"])
        self.b.close_position(r["position_id"])
        self.assertEqual(self.b.positions(), [])

    def test_deals_history(self):
        r = self.b.market("EURUSD", "buy", 0.10, "pyea")
        self.fake.set_price(1, 1.1050)
        self.b.close_position(r["position_id"])
        ds = self.b.deals(time.time() - 3600)
        self.assertEqual(len(ds), 2)
        entry, out = ds[0], ds[1]
        self.assertEqual((entry["entry"], out["entry"]), ("IN", "OUT"))
        self.assertAlmostEqual(out["qty"], 0.10)
        self.assertGreater(out["pnl"], 0)
        self.assertEqual(len(self.b.deals_by_position(r["position_id"])), 2)
        self.assertEqual(len(self.b.history(time.time() - 3600)), 2)


class TestThroughShell(Base):
    """Qua vỏ chung MtBroker/MtFeed và nhà máy settings -> broker/feed (đúng đường app dùng)."""

    def test_factories_and_shell(self):
        from pyea.broker import _make_broker
        from pyea.feeds import make_feed
        feed = make_feed("ctrader", self.st)
        self.assertIsInstance(feed, MtFeed)
        t = feed.tick("EURUSD")
        self.assertAlmostEqual(t.bid, 1.1)
        self.assertEqual(len(feed.history("EURUSD", "1h", 30)), 30)
        br = _make_broker(self.st)
        self.assertIsInstance(br, MtBroker)
        self.assertEqual(br.prepare("EURUSD"), 10000.0)
        fill = br.market_order("EURUSD", "buy", 0.10)
        self.assertAlmostEqual(fill.qty if hasattr(fill, "qty") else fill.quantity, 0.10)
        self.assertTrue(br.prot_supported())
        pos = br.position_levels("EURUSD")
        self.assertEqual(len(pos), 1)
        self.assertTrue(pos[0]["owned"])                                           # comment 'pyea' -> vị thế của app
        br.set_position_levels(pos[0]["ref"], 1.09, 1.12)
        self.assertAlmostEqual(br.position_levels("EURUSD")[0]["sl"], 1.09)
        br.close_market("EURUSD", "buy", 0.10, ref=pos[0]["ref"])
        self.assertEqual(br.position_levels("EURUSD"), [])
        self.assertEqual(feed.symbols(), ["EURUSD", "XAUUSD"])


class TestOAuth(unittest.TestCase):
    def test_auth_url(self):
        u = ctrader.auth_url("CID", "http://localhost:53682/callback")
        self.assertTrue(u.startswith("https://id.ctrader.com/my/settings/openapi/grantingaccess/?"))
        for part in ("client_id=CID", "scope=trading", "redirect_uri=http%3A%2F%2Flocalhost%3A53682%2Fcallback", "product=web"):
            self.assertIn(part, u)

    def test_exchange_code(self):
        seen = []
        r = ctrader.exchange_code("CID", "SEC", "CODE1", "http://localhost:1/cb",
                                  fetch=lambda url: (seen.append(url), {"accessToken": "A", "refreshToken": "R", "expiresIn": 2628000})[1])
        self.assertEqual((r["access"], r["refresh"]), ("A", "R"))
        self.assertTrue(seen[0].startswith("https://openapi.ctrader.com/apps/token?"))
        for part in ("grant_type=authorization_code", "code=CODE1", "client_id=CID", "client_secret=SEC"):
            self.assertIn(part, seen[0])
        with self.assertRaises(BridgeError):
            ctrader.exchange_code("CID", "SEC", "X", "u", fetch=lambda url: {"errorCode": "ACCESS_DENIED", "description": "no"})

    def test_local_redirect_listener_gets_code_without_any_server(self):
        port = 53999
        opened = []

        def browser(url):                                            # giả lập trình duyệt: sau khi cho phép thì chuyển hướng về localhost
            opened.append(url)
            threading.Thread(target=lambda: (time.sleep(0.2), urllib.request.urlopen("http://127.0.0.1:%d/callback?code=ABC123" % port).read()), daemon=True).start()
        r = ctrader.oauth_login("CID", "SEC", browser, port=port, timeout=10,
                                fetch=lambda url: {"accessToken": "AT", "refreshToken": "RT", "expiresIn": 1})
        self.assertEqual((r["access"], r["refresh"]), ("AT", "RT"))
        self.assertIn("redirect_uri=http%3A%2F%2Flocalhost%3A53999%2Fcallback", opened[0])

    def test_listener_reports_denial_and_timeout(self):
        port = 53998
        with self.assertRaises(BridgeError) as cm:
            ctrader.wait_for_code(port, 10, started=lambda: threading.Thread(
                target=lambda: (time.sleep(0.2), urllib.request.urlopen("http://127.0.0.1:%d/callback?error=access_denied" % port).read()), daemon=True).start())
        self.assertIn("access_denied", str(cm.exception))
        with self.assertRaises(BridgeError):
            ctrader.wait_for_code(53997, 0.6)


if __name__ == "__main__":
    unittest.main()


class TestCtraderUI(unittest.TestCase):
    def setUp(self):
        from pyea import ui_ctrader
        self.m = ui_ctrader
        self.calls = []
        self._orig = ui_ctrader.popup
        ui_ctrader.popup = lambda title, msg, buttons=None, **k: self.calls.append((title, msg, buttons))

    def tearDown(self):
        self.m.popup = self._orig

    def test_login_needs_app_credentials(self):
        import test_ui_smoke as T
        app = T.make_app()
        self.assertFalse(self.m.ctrader_login(app))
        self.assertIn("Redirect URI", self.calls[-1][1])

    def test_login_flow_saves_tokens(self):
        import test_ui_smoke as T
        app = T.make_app()
        form = app.settings_tab.gform
        form.set_values(dict(form.read()[0], ctrader_client_id="CID", ctrader_client_secret="SEC"))
        orig = ctrader.exchange_code
        ctrader.exchange_code = lambda *a, **k: {"access": "AT9", "refresh": "RT9", "expires_in": 1}
        try:
            port = 53996
            self.assertTrue(self.m.ctrader_login(app, opener=lambda url: threading.Thread(
                target=lambda: (time.sleep(0.2), urllib.request.urlopen("http://127.0.0.1:%d/callback?code=Z" % port).read()), daemon=True).start(), port=port))
            title, msg, buttons = self.calls[-1]
            self.assertEqual(title, "Đăng nhập cTrader")
            self.assertIn("http://localhost:%d/callback" % port, msg)
            buttons[0][2](None)                                       # «Mở trình duyệt»
            for _ in range(100):
                if app.settings.get("ctrader_access_token") == "AT9":
                    break
                time.sleep(0.1)
        finally:
            ctrader.exchange_code = orig
        self.assertEqual((app.settings["ctrader_access_token"], app.settings["ctrader_refresh_token"]), ("AT9", "RT9"))

    def test_choose_account_sets_env_and_account(self):
        import test_ui_smoke as T
        fake = FakeCTrader()
        tmp = tempfile.mkdtemp()
        try:
            app = T.make_app()
            form = app.settings_tab.gform
            form.set_values(dict(form.read()[0], **settings(fake, tmp)))
            self.m.ctrader_accounts(app)
            for _ in range(100):
                if self.calls:
                    break
                time.sleep(0.1)
            title, msg, buttons = self.calls[-1]
            self.assertEqual(title, "Tài khoản cTrader của token")
            self.assertIn("DEMO", msg)
            self.assertIn("LIVE", msg)
            demo = [b for b in buttons if "DEMO" in b[0]][0]
            demo[2](None)
            self.assertEqual((app.settings["ctrader_account"], app.settings["ctrader_env"]), ("222", "demo"))
        finally:
            fake.close()
