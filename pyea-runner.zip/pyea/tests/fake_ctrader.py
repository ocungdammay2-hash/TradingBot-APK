"""Máy chủ cTrader Open API GIẢ (JSON qua WebSocket) theo đúng tài liệu/.proto - chỉ để test, KHÔNG phải sàn thật."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from pyea.wsclient import accept_key, encode_frame, parse_frame

ERR = 2142


class FakeCTrader:
    def __init__(self, client_id="cid", secret="sec", access="AT1", refresh="RT1"):
        self.client_id, self.secret, self.access, self.refresh = client_id, secret, access, refresh
        self.lock = threading.RLock()
        self.balance = 10000.0
        self.accounts = [{"ctidTraderAccountId": 111, "isLive": True, "traderLogin": 900111}, {"ctidTraderAccountId": 222, "isLive": False, "traderLogin": 900222}]
        self.sym = {1: {"name": "EURUSD", "lot": 10_000_000, "min": 100_000, "step": 100_000, "max": 10_000_000_000, "bid": 1.10000, "ask": 1.10010},
                    2: {"name": "XAUUSD", "lot": 10_000, "min": 100, "step": 100, "max": 1_000_000, "bid": 2000.0, "ask": 2000.5}}
        self.positions, self.orders, self.deals = {}, {}, []
        self.next_id = 1000
        self.expire_token_once = False          # lần AccountAuth kế tiếp báo token hết hạn
        self.max_bar_window_ms = None           # ép lỗi INCORRECT_BOUNDARIES khi khoảng from..to lớn hơn mức này
        self.log = []                           # (payloadType, payload)
        self.conns = []
        self.drop_cmid = False                  # không lặp lại clientMsgId trong ExecutionEvent
        self.fail_next = None                   # errorCode cho lệnh giao dịch kế tiếp
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.port = self.srv.server_address[1]
        self.url = "ws://127.0.0.1:%d" % self.port
        self._stop = threading.Event()
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self._stop.set()
        self.srv.shutdown()
        self.srv.server_close()

    # ---- giá ----
    def set_price(self, sid, bid, ask=None):
        with self.lock:
            s = self.sym[sid]
            s["bid"], s["ask"] = bid, ask or bid + (s["ask"] - s["bid"])
            for c in self.conns:
                if sid in c["subs"]:
                    c["q"].append((2131, None, {"ctidTraderAccountId": c["acc"], "symbolId": sid, "bid": int(round(s["bid"] * 100000)),
                                               "ask": int(round(s["ask"] * 100000)), "timestamp": int(time.time() * 1000)}))

    def _px(self, sid, side):
        s = self.sym[sid]
        return s["ask"] if side == 1 else s["bid"]

    # ---- bản ghi ----
    def _pos_json(self, p):
        return {"positionId": p["id"], "tradeData": {"symbolId": p["sid"], "volume": p["vol"], "tradeSide": p["side"], "openTimestamp": int(p["t"] * 1000),
                                                    "label": p.get("label", ""), "comment": p.get("comment", "")},
                "positionStatus": 1, "swap": 0, "price": p["price"], "stopLoss": p.get("sl", 0.0), "takeProfit": p.get("tp", 0.0),
                "commission": -50, "usedMargin": 1000, "moneyDigits": 2}

    def _ord_json(self, o):
        d = {"orderId": o["id"], "tradeData": {"symbolId": o["sid"], "volume": o["vol"], "tradeSide": o["side"], "label": o.get("label", "")},
             "orderType": o["type"], "orderStatus": 1, "clientOrderId": o.get("coid", "")}
        if o["type"] == 2:
            d["limitPrice"] = o["price"]
        else:
            d["stopPrice"] = o["price"]
        if o.get("sl"):
            d["stopLoss"] = o["sl"]
        if o.get("tp"):
            d["takeProfit"] = o["tp"]
        return d

    def _nid(self):
        self.next_id += 1
        return self.next_id

    def _pnl(self):
        out = []
        for p in self.positions.values():
            cur = self.sym[p["sid"]]["bid"] if p["side"] == 1 else self.sym[p["sid"]]["ask"]
            diff = (cur - p["price"]) * (1 if p["side"] == 1 else -1)
            g = int(round(diff * p["vol"] / 100.0 * 100))            # tiền * 100 (moneyDigits=2)
            out.append({"positionId": p["id"], "grossUnrealizedPnL": g, "netUnrealizedPnL": g - 50})
        return out

    # ---- xử lý ----
    def handle(self, conn, pt, pl, cmid):
        self.log.append((pt, pl))
        send = lambda t, body: conn["q"].append((t, cmid, body))                       # noqa: E731
        acc = pl.get("ctidTraderAccountId")
        if pt == 51:
            return
        if pt == 2100:
            if pl.get("clientId") != self.client_id or pl.get("clientSecret") != self.secret:
                return send(ERR, {"errorCode": "CH_CLIENT_AUTH_FAILURE", "description": "bad app"})
            conn["app"] = True
            return send(2101, {})
        if not conn.get("app"):
            return send(ERR, {"errorCode": "CH_CLIENT_NOT_AUTHENTICATED"})
        if pt == 2149:
            if pl.get("accessToken") != self.access:
                return send(ERR, {"errorCode": "CH_ACCESS_TOKEN_INVALID"})
            return send(2150, {"accessToken": self.access, "permissionScope": 1, "ctidTraderAccount": self.accounts})
        if pt == 2173:
            if pl.get("refreshToken") != self.refresh:
                return send(ERR, {"errorCode": "CH_ACCESS_TOKEN_INVALID", "description": "bad refresh"})
            self.access, self.refresh = self.access + "n", self.refresh + "n"
            self.expire_token_once = False
            return send(2174, {"accessToken": self.access, "tokenType": "bearer", "expiresIn": 2628000, "refreshToken": self.refresh})
        if pt == 2102:
            if self.expire_token_once or pl.get("accessToken") != self.access:
                return send(ERR, {"errorCode": "CH_ACCESS_TOKEN_INVALID", "description": "expired"})
            conn["acc"] = acc
            conn["auth"] = True
            return send(2103, {"ctidTraderAccountId": acc})
        if not conn.get("auth"):
            return send(ERR, {"errorCode": "ACCOUNT_NOT_AUTHORIZED", "ctidTraderAccountId": acc})
        with self.lock:
            return self._trading(conn, pt, pl, cmid, send, acc)

    def _trading(self, conn, pt, pl, cmid, send, acc):
        if pt == 2114:
            return send(2115, {"ctidTraderAccountId": acc, "symbol": [{"symbolId": k, "symbolName": v["name"], "enabled": True} for k, v in self.sym.items()]})
        if pt == 2116:
            return send(2117, {"ctidTraderAccountId": acc, "symbol": [
                {"symbolId": i, "digits": 5, "pipPosition": 4, "lotSize": self.sym[i]["lot"], "minVolume": self.sym[i]["min"], "stepVolume": self.sym[i]["step"],
                 "maxVolume": self.sym[i]["max"]} for i in pl.get("symbolId", []) if i in self.sym]})
        if pt == 2112:
            return send(2113, {"ctidTraderAccountId": acc, "asset": [{"assetId": 15, "name": "USD", "digits": 2}]})
        if pt == 2121:
            return send(2122, {"ctidTraderAccountId": acc, "trader": {"ctidTraderAccountId": acc, "balance": int(self.balance * 100), "moneyDigits": 2,
                                                                      "depositAssetId": 15, "leverageInCents": 10000, "accountType": 0, "traderLogin": 900222}})
        if pt == 2124:
            return send(2125, {"ctidTraderAccountId": acc, "position": [self._pos_json(p) for p in self.positions.values()],
                               "order": [self._ord_json(o) for o in self.orders.values()]})
        if pt == 2127:
            ids = pl.get("symbolId", [])
            conn["subs"].update(ids)
            send(2128, {"ctidTraderAccountId": acc, "subscribedSymbolId": ids})
            for i in ids:
                self.set_price(i, self.sym[i]["bid"], self.sym[i]["ask"])
            return
        if pt == 2190:
            return send(2191, {"ctidTraderAccountId": acc})
        if pt == 2187:
            return send(2188, {"ctidTraderAccountId": acc, "positionUnrealizedPnL": self._pnl(), "moneyDigits": 2})
        if pt == 2137:
            return self._bars(send, pl, acc)
        if pt == 2133:
            return send(2134, {"ctidTraderAccountId": acc, "deal": [d for d in self.deals if pl.get("fromTimestamp", 0) <= d["executionTimestamp"] <= pl.get("toTimestamp", 10 ** 15)], "hasMore": False})
        if pt == 2179:
            return send(2180, {"ctidTraderAccountId": acc, "deal": [d for d in self.deals if d["positionId"] == pl["positionId"]], "hasMore": False})
        if pt in (2106, 2111, 2110, 2109, 2108):
            return self._order(conn, pt, pl, cmid, acc)
        send(ERR, {"errorCode": "UNKNOWN_REQUEST", "description": "pt=%s" % pt})

    def _bars(self, send, pl, acc):
        frm, to, period, sid, count = pl.get("fromTimestamp", 0), pl["toTimestamp"], pl["period"], pl["symbolId"], pl.get("count", 100000)
        if self.max_bar_window_ms and to - frm > self.max_bar_window_ms:
            return send(ERR, {"errorCode": "INCORRECT_BOUNDARIES", "description": "range too large"})
        step = {1: 60, 5: 300, 9: 3600, 12: 86400}[period]
        t = (int(to / 1000) // step) * step
        bars = []
        while t * 1000 >= frm and len(bars) < count and t > 0:
            base = 1.1 + (t // step % 50) / 1000.0
            low = int(round(base * 100000))
            bars.append({"volume": 100, "period": period, "low": low, "deltaOpen": 20, "deltaClose": 50, "deltaHigh": 80, "utcTimestampInMinutes": t // 60})
            t -= step
        bars.reverse()
        send(2138, {"ctidTraderAccountId": acc, "period": period, "symbolId": sid, "trendbar": bars, "hasMore": False})

    def _exec(self, conn, cmid, kind, pos=None, order=None, deal=None, err=None):
        body = {"ctidTraderAccountId": conn["acc"], "executionType": kind}
        if pos is not None:
            body["position"] = self._pos_json(pos)
        if order is not None:
            body["order"] = order
        if deal is not None:
            body["deal"] = deal
        if err:
            body["errorCode"] = err
        conn["q"].append((2126, None if self.drop_cmid else cmid, body))

    def _deal(self, p, vol, price, closing, profit=0):
        d = {"dealId": self._nid(), "orderId": self._nid(), "positionId": p["id"], "volume": vol, "filledVolume": vol, "symbolId": p["sid"],
             "createTimestamp": int(time.time() * 1000), "executionTimestamp": int(time.time() * 1000), "executionPrice": price,
             "tradeSide": p["side"] if not closing else 3 - p["side"], "dealStatus": 2, "commission": -25, "moneyDigits": 2}
        if closing:
            d["closePositionDetail"] = {"entryPrice": p["price"], "grossProfit": profit, "swap": 0, "commission": -25, "balance": int(self.balance * 100), "moneyDigits": 2}
        self.deals.append(d)
        return d

    def _order(self, conn, pt, pl, cmid, acc):
        if self.fail_next:
            code, self.fail_next = self.fail_next, None
            conn["q"].append((2132, cmid, {"errorCode": code, "ctidTraderAccountId": acc, "description": "fake"}))
            return
        if pt == 2106:
            sid, side, vol, ot = pl["symbolId"], pl["tradeSide"], pl["volume"], pl["orderType"]
            s = self.sym[sid]
            if vol < s["min"] or vol % s["step"]:
                conn["q"].append((2132, cmid, {"errorCode": "TRADING_BAD_VOLUME", "ctidTraderAccountId": acc}))
                return
            if ot == 1:
                price = self._px(sid, side)
                p = {"id": self._nid(), "sid": sid, "side": side, "vol": vol, "price": price, "t": time.time(), "label": pl.get("label", ""), "comment": pl.get("comment", "")}
                self.positions[p["id"]] = p
                o = {"orderId": self._nid(), "tradeData": {"symbolId": sid, "volume": vol, "tradeSide": side}, "orderType": 1, "orderStatus": 2,
                     "executionPrice": price, "positionId": p["id"], "clientOrderId": pl.get("clientOrderId", "")}
                self._exec(conn, cmid, 2, pos=p, order=dict(o, orderStatus=1))      # ACCEPTED rồi FILLED (như sàn thật)
                self._exec(conn, cmid, 3, pos=p, order=o, deal=self._deal(p, vol, price, False))
            else:
                o = {"id": self._nid(), "sid": sid, "side": side, "vol": vol, "type": ot, "price": pl.get("limitPrice") or pl.get("stopPrice"), "coid": pl.get("clientOrderId", ""),
                     "label": pl.get("label", "")}
                self.orders[o["id"]] = o
                self._exec(conn, cmid, 2, order=self._ord_json(o))
            return
        if pt == 2111:
            p = self.positions.get(pl["positionId"])
            if not p:
                conn["q"].append((2132, cmid, {"errorCode": "POSITION_NOT_FOUND", "ctidTraderAccountId": acc}))
                return
            vol = pl["volume"]
            price = self._px(p["sid"], 3 - p["side"])
            diff = (price - p["price"]) * (1 if p["side"] == 1 else -1)
            profit = int(round(diff * vol / 100.0 * 100))
            self.balance += profit / 100.0
            d = self._deal(p, vol, price, True, profit)
            p["vol"] -= vol
            if p["vol"] <= 0:
                self.positions.pop(p["id"], None)
            self._exec(conn, cmid, 3, pos=p, order={"orderId": d["orderId"], "tradeData": {"symbolId": p["sid"], "volume": vol, "tradeSide": 3 - p["side"]},
                                                  "orderType": 1, "orderStatus": 2, "executionPrice": price, "positionId": p["id"], "closingOrder": True}, deal=d)
            return
        if pt == 2110:
            p = self.positions.get(pl["positionId"])
            if not p:
                conn["q"].append((2132, cmid, {"errorCode": "POSITION_NOT_FOUND", "ctidTraderAccountId": acc}))
                return
            p["sl"], p["tp"] = pl.get("stopLoss", 0.0), pl.get("takeProfit", 0.0)
            self._exec(conn, cmid, 4, pos=p)
            return
        o = self.orders.get(pl["orderId"])
        if not o:
            conn["q"].append((2132, cmid, {"errorCode": "ORDER_NOT_FOUND", "ctidTraderAccountId": acc}))
            return
        if pt == 2108:
            self.orders.pop(o["id"], None)
            self._exec(conn, cmid, 5, order=dict(self._ord_json(o), orderStatus=5))
            return
        if "limitPrice" in pl or "stopPrice" in pl:
            o["price"] = pl.get("limitPrice") or pl.get("stopPrice")
        if "stopLoss" in pl:
            o["sl"] = pl["stopLoss"]
        if "takeProfit" in pl:
            o["tp"] = pl["takeProfit"]
        self._exec(conn, cmid, 4, order=self._ord_json(o))

    # ---- WebSocket ----
    def _handler(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def do_GET(self):
                key = self.headers.get("Sec-WebSocket-Key")
                self.send_response(101)
                self.send_header("Upgrade", "websocket")
                self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", accept_key(key))
                self.end_headers()
                self.wfile.flush()
                conn = {"q": [], "subs": set()}
                with fake.lock:
                    fake.conns.append(conn)
                sock = self.connection
                sock.settimeout(0.05)
                buf = bytearray()
                try:
                    while not fake._stop.is_set():
                        try:
                            d = sock.recv(65536)
                            if not d:
                                break
                            buf += d
                        except OSError as e:
                            if "timed out" not in str(e):
                                break
                        while True:
                            fr = parse_frame(buf)
                            if not fr:
                                break
                            fin, op, payload, used = fr
                            del buf[:used]
                            if op == 0x8:
                                return
                            if op == 0x1:
                                m = json.loads(payload)
                                fake.handle(conn, int(m["payloadType"]), m.get("payload") or {}, m.get("clientMsgId"))
                        with fake.lock:
                            q, conn["q"] = conn["q"], []
                        for pt, cmid, body in q:
                            msg = {"payloadType": pt, "payload": body}
                            if cmid:
                                msg["clientMsgId"] = cmid
                            sock.sendall(encode_frame(0x1, json.dumps(msg), mask=False))
                except OSError:
                    pass
                finally:
                    with fake.lock:
                        if conn in fake.conns:
                            fake.conns.remove(conn)
                    self.close_connection = True
        return H
