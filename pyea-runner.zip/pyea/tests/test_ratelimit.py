"""Giới hạn tốc độ API theo sàn (đồng hồ giả => tất định, không phải chờ thật)."""
import http.server
import json
import os
import sys
import threading
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import ratelimit
from pyea.feeds import FeedError, HttpError, http_json
from pyea.ratelimit import RateLimiter, RateLimitError, limiter_for


class FakeClock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t

    def sleep(self, s):
        self.t += s


def mk(rules, **kw):
    c = FakeClock()
    return RateLimiter("t", rules, clock=c, sleep=c.sleep, **kw), c


class TestLimiter(unittest.TestCase):
    def test_under_limit_no_wait(self):
        lim, c = mk([(5, 1.0)])
        for _ in range(5):
            self.assertEqual(lim.acquire(), 0.0)

    def test_blocks_until_window_slides(self):
        lim, c = mk([(3, 1.0)])
        for _ in range(3):
            lim.acquire()
        waited = lim.acquire()                    # lần thứ 4 phải chờ ~1 giây
        self.assertGreaterEqual(waited, 0.99)
        self.assertLessEqual(waited, 1.3)

    def test_cost_weighted(self):
        lim, c = mk([(10, 60.0)])
        lim.acquire(cost=6)
        lim.acquire(cost=4)                        # vừa đủ 10
        with self.assertRaises(RateLimitError):    # cửa sổ 60s > max_wait 30s
            lim.acquire(cost=1)

    def test_max_wait_raises_without_sleeping_forever(self):
        lim, c = mk([(1, 100.0)], max_wait=2.0)
        lim.acquire()
        t0 = c.t
        with self.assertRaises(RateLimitError) as cm:
            lim.acquire()
        self.assertGreater(cm.exception.wait, 90)
        self.assertLess(c.t - t0, 1.0)             # không ngủ trước khi biết chắc sẽ vượt

    def test_multiple_rules_all_apply(self):
        lim, c = mk([(100, 60.0), (2, 1.0)])      # trần phút rộng, trần giây chặt
        lim.acquire()
        lim.acquire()
        self.assertGreaterEqual(lim.acquire(), 0.9)

    def test_oversized_cost_does_not_deadlock(self):
        lim, c = mk([(5, 1.0)])
        self.assertEqual(lim.acquire(cost=50), 0.0)  # nặng hơn cả hạn mức: coi như dùng hết 1 cửa sổ

    def test_penalize_blocks(self):
        lim, c = mk([(100, 1.0)], max_wait=60.0)
        lim.penalize(5.0, "429")
        self.assertGreaterEqual(lim.acquire(), 4.9)

    def test_on_http_429_retry_after(self):
        lim, c = mk([(100, 1.0)], max_wait=60.0)
        lim.on_http(429, {"Retry-After": "7"})
        self.assertGreaterEqual(lim.acquire(), 6.9)
        self.assertEqual(lim.stats()["penalties"], 1)

    def test_on_http_418_default_long_ban(self):
        lim, c = mk([(100, 1.0)], max_wait=10.0)
        lim.on_http(418, {})
        with self.assertRaises(RateLimitError):    # 418 (cấm IP) mặc định 120s -> không chờ trong luồng giá
            lim.acquire()

    def test_binance_used_weight_header_slows_down(self):
        lim, c = mk([(1000, 60.0)], max_wait=60.0)
        lim.on_http(200, {"X-MBX-USED-WEIGHT-1M": "990"})   # sàn báo đã dùng 990/1000
        self.assertGreater(lim.acquire(cost=5), 0.0)

    def test_set_rules_overrides_preset(self):
        lim, c = mk([(1, 100.0)], max_wait=1.0)
        lim.acquire()
        lim.set_rules([(50, 1.0)])
        self.assertEqual(lim.acquire(), 0.0)

    def test_stats(self):
        lim, c = mk([(2, 1.0)])
        lim.acquire()
        lim.acquire()
        lim.acquire()
        st = lim.stats()
        self.assertEqual(st["calls"], 3)
        self.assertEqual(st["waits"], 1)

    def test_thread_safe_total_never_exceeds(self):
        lim = RateLimiter("mt", [(20, 0.5)], max_wait=5.0)
        stamps, lk = [], threading.Lock()

        def run():
            for _ in range(10):
                lim.acquire()
                with lk:
                    import time as _t
                    stamps.append(_t.monotonic())
        ts = [threading.Thread(target=run) for _ in range(4)]       # 40 request, 20/0.5s => cần ≥ 0.5s
        t0 = __import__("time").monotonic()
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(len(stamps), 40)
        self.assertGreaterEqual(max(stamps) - t0, 0.45)


class TestRegistry(unittest.TestCase):
    def setUp(self):
        ratelimit.reset_all()

    def test_shared_per_kind_and_base(self):
        a = limiter_for("binance_spot", "https://api.binance.com")
        b = limiter_for("binance_spot", "https://api.binance.com/")
        c = limiter_for("binance_spot", "https://testnet.binance.vision")
        self.assertIs(a, b)
        self.assertIsNot(a, c)

    def test_loopback_is_unlimited_unless_explicit(self):
        a = limiter_for("binance_spot", "http://127.0.0.1:9999")
        self.assertEqual(a.rules[0][0], 1e9)
        b = limiter_for("oanda", "http://127.0.0.1:9998", rules=[(1, 10.0)])
        self.assertEqual(b.rules, [(1.0, 10.0)])

    def test_presets_are_conservative(self):
        self.assertLess(ratelimit.PRESETS["binance_spot"][0][0], 1200)
        self.assertLess(ratelimit.PRESETS["binance_futures"][0][0], 2400)


class _H(http.server.BaseHTTPRequestHandler):
    hits = 0

    def log_message(self, *a):
        pass

    def do_GET(self):
        type(self).hits += 1
        if self.path.startswith("/limited"):
            self.send_response(429)
            self.send_header("Retry-After", "42")
            self.end_headers()
            self.wfile.write(b'{"msg":"too many"}')
        elif self.path.startswith("/weight"):
            self.send_response(200)
            self.send_header("X-MBX-USED-WEIGHT-1M", "999")
            self.end_headers()
            self.wfile.write(b'{"ok":1}')
        else:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"ok": True}).encode())


class TestHttpIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H)
        cls.base = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def test_429_raises_httperror_with_retry_after_and_penalizes(self):
        lim = RateLimiter("x", [(100, 1.0)], max_wait=5.0)
        with self.assertRaises(HttpError) as cm:
            http_json(self.base + "/limited", limiter=lim)
        self.assertEqual(cm.exception.status, 429)
        self.assertEqual(cm.exception.retry_after, 42.0)
        self.assertIsInstance(cm.exception, FeedError)       # mã cũ bắt FeedError vẫn chạy
        before = _H.hits
        with self.assertRaises(FeedError) as cm2:            # lần sau KHÔNG gửi nữa (đang bị phạt 42s > max_wait 5s)
            http_json(self.base + "/ok", limiter=lim)
        self.assertEqual(_H.hits, before)
        self.assertIn("giới hạn tốc độ", str(cm2.exception))

    def test_used_weight_header_observed(self):
        lim = RateLimiter("x", [(1000, 60.0)], max_wait=1.0)
        self.assertEqual(http_json(self.base + "/weight", limiter=lim), {"ok": 1})
        with self.assertRaises(FeedError):
            http_json(self.base + "/ok", limiter=lim, cost=5)

    def test_no_limiter_behaves_as_before(self):
        self.assertEqual(http_json(self.base + "/ok"), {"ok": True})

    def test_raw_body_sent_verbatim(self):
        # raw_body được gửi nguyên văn (chữ ký Exness phải khớp từng byte)
        got = {}

        class P(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                got["body"] = self.rfile.read(int(self.headers["Content-Length"]))
                self.send_response(202)
                self.end_headers()
                self.wfile.write(b'{"status":"accepted"}')
        srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), P)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            raw = '{"a":  1, "b":"x"}'
            r = http_json("http://127.0.0.1:%d/p" % srv.server_address[1], method="POST", raw_body=raw)
            self.assertEqual(r, {"status": "accepted"})
            self.assertEqual(got["body"], raw.encode())
        finally:
            srv.shutdown()
            srv.server_close()


if __name__ == "__main__":
    unittest.main()
