"""Công cụ vẽ trên biểu đồ: mô hình đối tượng, lưu theo mã, quy đổi thời gian<->chỉ số nến, chọn bằng cách chạm, Fibonacci."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import drawings as D                               # noqa: E402


class TestModel(unittest.TestCase):
    def test_new_object_needs_right_number_of_valid_points(self):
        self.assertIsNone(D.new_object("trend", [(1, 2)]))
        self.assertIsNone(D.new_object("trend", [(1, 2), (1, 2)]))                 # hai điểm trùng nhau
        self.assertIsNone(D.new_object("hline", [(1, float("nan"))]))
        self.assertIsNone(D.new_object("khong-co", [(1, 2)]))
        o = D.new_object("hline", [(5, 100.5)], color=7)
        self.assertEqual((o["kind"], o["pts"], o["color"]), ("hline", [[5.0, 100.5]], 7 % len(D.COLORS)))
        self.assertEqual(len(D.new_object("text", [(1, 2)], "x" * 500)["text"]), D.MAX_TEXT)

    def test_save_load_roundtrip_per_symbol_and_drops_garbage(self):
        prefs = {}
        a = D.new_object("trend", [(10, 1), (20, 2)])
        b = D.new_object("fib", [(10, 1), (20, 3)])
        D.put(prefs, "BTCUSD", [a, b])
        D.put(prefs, "ETHUSD", [D.new_object("hline", [(5, 9)])])
        prefs["drawings"]["BTCUSD"].append({"kind": "trend", "pts": "hỏng"})
        prefs["drawings"]["BTCUSD"].append("rác")
        got = D.get(prefs, "BTCUSD")
        self.assertEqual([o["kind"] for o in got], ["trend", "fib"])
        self.assertEqual(len(D.get(prefs, "ETHUSD")), 1)
        self.assertEqual(D.get(prefs, "KHAC"), [])
        D.put(prefs, "ETHUSD", [])
        self.assertNotIn("ETHUSD", prefs["drawings"])

    def test_limit_per_symbol_keeps_newest(self):
        objs = []
        for i in range(D.MAX_PER_SYMBOL + 5):
            objs = D.add(objs, D.new_object("hline", [(i, 1.0 + i)]))
        self.assertEqual(len(objs), D.MAX_PER_SYMBOL)
        self.assertEqual(objs[-1]["pts"][0][1], 1.0 + D.MAX_PER_SYMBOL + 4)

    def test_remove(self):
        a, b = D.new_object("hline", [(1, 1)]), D.new_object("hline", [(2, 2)])
        self.assertEqual(D.remove([a, b], a["id"]), [b])

    def test_fib_levels(self):
        lv = dict(D.fib_prices(100.0, 200.0))
        self.assertAlmostEqual(lv[0.0], 100.0)
        self.assertAlmostEqual(lv[0.618], 161.8)
        self.assertAlmostEqual(lv[1.0], 200.0)
        down = dict(D.fib_prices(200.0, 100.0))
        self.assertAlmostEqual(down[0.5], 150.0)


class TestTime(unittest.TestCase):
    times = [1000.0, 1060.0, 1120.0, 1180.0]

    def test_roundtrip_inside_and_extrapolated(self):
        for t in (1000.0, 1030.0, 1119.0, 1180.0, 900.0, 1300.0):
            g = D.frac_index(self.times, t, 60.0)
            self.assertAlmostEqual(D.time_at(self.times, g, 60.0), t)
        self.assertAlmostEqual(D.frac_index(self.times, 1090.0, 60.0), 1.5)
        self.assertAlmostEqual(D.frac_index(self.times, 1240.0, 60.0), 4.0)         # sau nến cuối: ngoại suy theo bước nến

    def test_irregular_candles_weekend_gap(self):
        t = [0.0, 60.0, 60.0 + 3 * 86400, 120.0 + 3 * 86400]
        self.assertAlmostEqual(D.frac_index(t, 30.0), 0.5)
        self.assertAlmostEqual(D.time_at(t, 1.5), 60.0 + 1.5 * 86400)


class TestHit(unittest.TestCase):
    def xy(self, t, p):
        return (t, p)                                        # đồng nhất: thời gian = x, giá = y

    def test_nearest_picks_closest_within_radius(self):
        line = D.new_object("hline", [(0, 100)])
        tr = D.new_object("trend", [(0, 0), (100, 100)])
        rc = D.new_object("rect", [(200, 200), (300, 300)])
        txt = D.new_object("text", [(500, 500)], "hi")
        objs = [line, tr, rc, txt]
        self.assertEqual(D.nearest(objs, 50, 103, self.xy, 600, 10)["id"], line["id"])
        self.assertEqual(D.nearest(objs, 50, 55, self.xy, 600, 10)["id"], tr["id"])      # cách đường xu hướng ~3.5px, xa đường ngang 45px
        self.assertEqual(D.nearest(objs, 250, 250, self.xy, 600, 10)["id"], rc["id"])     # bên trong chữ nhật
        self.assertEqual(D.nearest(objs, 503, 503, self.xy, 600, 10)["id"], txt["id"])
        self.assertIsNone(D.nearest(objs, 400, 50, self.xy, 600, 10))

    def test_fib_is_hit_near_any_level(self):
        fb = D.new_object("fib", [(0, 100), (100, 200)])
        self.assertIs(D.nearest([fb], 50, 161.8, self.xy, 600, 5), fb)
        self.assertIsNone(D.nearest([fb], 50, 400, self.xy, 600, 5))


class TestClip(unittest.TestCase):
    def test_clip_segment(self):
        self.assertEqual(D.clip_segment(1, 1, 5, 5, 0, 0, 10, 10), (1, 1, 5, 5))                    # nằm trong: giữ nguyên
        self.assertIsNone(D.clip_segment(-5, 20, -1, 30, 0, 0, 10, 10))                              # nằm ngoài hẳn
        x0, y0, x1, y1 = D.clip_segment(-10, 5, 20, 5, 0, 0, 10, 10)                                 # cắt hai đầu
        self.assertEqual((x0, y0, x1, y1), (0.0, 5.0, 10.0, 5.0))
        self.assertIsNone(D.clip_segment(-5, 11, 15, 11, 0, 0, 10, 10))                              # song song, nằm ngoài
        c = D.clip_segment(-5, -5, 5, 5, 0, 0, 10, 10)
        self.assertEqual((round(c[0], 6), round(c[1], 6), c[2], c[3]), (0.0, 0.0, 5, 5))


class TestList(unittest.TestCase):
    def test_list_text(self):
        self.assertIn("Chưa có", D.list_text([]))
        txt = D.list_text([D.new_object("hline", [(1, 1.5)]), D.new_object("fib", [(1, 1), (2, 3)]), D.new_object("text", [(1, 2)], "Hỗ trợ")])
        self.assertIn("1. Đường ngang @ 1.5", txt)
        self.assertIn("2. Fibonacci", txt)
        self.assertIn("«Hỗ trợ»", txt)


if __name__ == "__main__":
    unittest.main()
