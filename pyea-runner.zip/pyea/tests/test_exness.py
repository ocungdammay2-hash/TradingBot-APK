"""Adapter Exness vs máy chủ giả: chữ ký Ed25519 (xác minh độc lập), host discovery, WS, ACK bất đồng bộ, lệnh chờ native."""
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    HAVE_CRYPTO = True
except Exception:                                    # noqa: BLE001
    HAVE_CRYPTO = False

from pyea import exness, ratelimit
from pyea.broker import BrokerError
from pyea.exness import ExnBroker, ExnClient, ExnError, ExnFeed
from pyea.feeds import FeedError


@unittest.skipUnless(HAVE_CRYPTO, "cần cryptography để xác minh chữ ký độc lập")
class ExnBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fake_exness import FakeExness
        cls.key = Ed25519PrivateKey.generate()
        cls.pem = cls.key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        pub = cls.key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        cls.fake = FakeExness(pub)

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        ratelimit.reset_all()
        f = self.fake
        with f.lock:
            f.positions.clear()
            f.orders.clear()
            f.ops.clear()
            f.requests.clear()
            f.balance = 10000.0
            f.confirm_after_polls = 0
            f.op_shape = "flat"
            f.tf_enum = "mt"
            f.ap_shape = "bare"
            f.reject_next = None
            f.limits_shape, f.candles_max, f.time_fmt, f.candle_gap = "documented", 300, "both", None
            f.close_volume_in, f.account_status, f.trade_mode = "body", "active", "full"
            f.family_host = {"history": "ap", "configuration": "disc", "market-data": "disc"}
            f.history_range_days, f.history_age_days = 30, 90
            f.hist_orders.clear()
            f.deals.clear()
            f.ws_log.clear()
            f.prices["EURUSD"] = [1.1000, 1.1002]
        self.settings = {"exness_api_key": "exnsk_test", "exness_private_key": self.pem, "exness_account": "123456", "exness_host": f.base}
        exness._CLIENTS.clear()
        self.client = exness.client_for(self.settings)
        self.broker = ExnBroker(self.client)
        self.feed = ExnFeed(self.client)

    def tearDown(self):
        s = getattr(self.client, "stream", None)
        if s:
            s.close()

    def reqs(self, method=None, path_part=None):
        return [r for r in self.fake.requests if (method is None or r["method"] == method) and (path_part is None or path_part in r["path"])]


class TestAuthAndDiscovery(ExnBase):
    def test_signed_get_accepted(self):
        d = self.client.account()
        self.assertEqual(d["currency"], "USD")

    def test_wrong_key_gets_401_with_helpful_message(self):
        other = Ed25519PrivateKey.generate().private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                                           serialization.NoEncryption()).decode()
        c = ExnClient("exnsk_test", other, "123456", self.fake.base)
        with self.assertRaises(ExnError) as cm:
            c.account()
        self.assertEqual(cm.exception.status, 401)
        self.assertEqual(cm.exception.code, 1001)
        self.assertIn("khoá riêng", str(cm.exception))

    def test_wrong_api_key_rejected(self):
        c = ExnClient("exnsk_other", self.pem, "123456", self.fake.base)
        with self.assertRaises(ExnError) as cm:
            c.account()
        self.assertEqual(cm.exception.status, 401)

    def test_bad_private_key_message(self):
        with self.assertRaises(ExnError) as cm:
            ExnClient("k", "not-a-key!!", "1", self.fake.base)
        self.assertIn("Khoá riêng Exness không hợp lệ", str(cm.exception))
        with self.assertRaises(ExnError):
            ExnClient("", self.pem, "1")
        with self.assertRaises(ExnError):
            ExnClient("k", self.pem, "")

    def test_access_point_bare_host_inherits_scheme_and_is_cached(self):
        base = self.client.access_base()
        self.assertEqual(base, "http://localhost:%d" % self.fake.port)
        self.client.access_base()
        self.assertEqual(len(self.reqs("GET", "access-point")), 1)

    def test_access_point_nested_shape(self):
        self.fake.ap_shape = "nested"
        self.assertEqual(self.client.access_base(), "http://localhost:%d" % self.fake.port)

    def test_extract_host_variants(self):
        f = ExnClient._extract_host
        self.assertEqual(f("ap-1.trading.exness.com"), "ap-1.trading.exness.com")
        self.assertEqual(f({"accessPoint": "h.example"}), "h.example")
        self.assertEqual(f({"result": {"host": "x.y"}}), "x.y")
        self.assertIsNone(f({"nothing": 1}))

    def test_default_hosts(self):
        c = ExnClient("k", self.pem, "1", "alt")
        self.assertEqual(c.disc, "https://api.exness-api.com")
        self.assertEqual(ExnClient("k", self.pem, "1").disc, "https://api.exness.com")
        self.assertEqual(ExnClient("k", self.pem, "1", "my.host.example").disc, "https://my.host.example")

    def test_idempotency_unique_and_nonempty_for_mutations(self):
        self.broker.prepare("EURUSD")
        self.broker.market_order("EURUSD", "buy", 0.01)
        self.broker.market_order("EURUSD", "buy", 0.01)
        ids = [r["idem"] for r in self.reqs("POST", "/positions")]
        self.assertEqual(len(ids), 2)
        self.assertTrue(all(ids))
        self.assertNotEqual(ids[0], ids[1])
        self.assertTrue(all((r["idem"] or "") == "" for r in self.reqs("GET")))


class TestLimitsAndMeta(ExnBase):
    def test_limits_applied_to_limiters_from_documented_structure(self):
        applied = self.client.apply_limits()
        self.assertEqual(applied["trade"], [(4.0, 1.0)])                       # POST 5/s (< toàn tài khoản 50/s) x0.8
        self.assertEqual(applied["read"], [(6.4, 1.0)])                        # GET chặt nhất 8/s x0.8
        self.assertEqual(self.client.trade_lim.rules, [(4.0, 1.0)])
        self.assertEqual(applied["consts"], {"max_candles_per_request": 300, "history_range_days": 30, "history_age_days": 90})
        self.assertEqual(self.client.max_candles(), 300)
        self.assertEqual(self.feed.max_chunk, 300)

    def test_legacy_limits_shape_still_parsed_heuristically(self):
        self.fake.limits_shape = "legacy"
        applied = self.client.apply_limits()
        self.assertEqual(applied["trade"], [(4.0, 1.0)])
        self.assertEqual(self.client.max_candles(), 500)                       # không có hằng số -> mặc định

    def test_global_rate_alone_limits_both(self):
        r = exness.rules_from_limits({"limits": {"rest": {"global_account_rate": {"limit": 10, "window_seconds": 2}, "methods": []}}})
        self.assertEqual(r, {"read": [(8.0, 2.0)], "trade": [(8.0, 2.0)]})

    def test_unparseable_limits_keep_defaults(self):
        before = list(self.client.read_lim.rules)
        self.assertIsNone(self.client.apply_limits({"something": "else"}))
        self.assertEqual(self.client.read_lim.rules, before)
        self.fake.limits_shape = "none"
        self.assertIsNone(self.client.apply_limits())

    def test_instruments(self):
        self.assertEqual(self.client.instruments(), ["EURUSD", "XAUUSD"])
        self.assertEqual(self.feed.symbols(), ["EURUSD", "XAUUSD"])


class TestFeed(ExnBase):
    def test_tick_over_websocket(self):
        t = self.feed.tick("EURUSD")
        self.assertAlmostEqual(t.bid, 1.1000, 5)
        self.assertAlmostEqual(t.ask, 1.1002, 5)
        self.assertTrue(t.tradeable)
        self.fake.set_price("EURUSD", 1.2000, 1.2002)
        end = time.time() + 3
        while time.time() < end and abs(self.feed.tick("EURUSD").bid - 1.2) > 1e-9:
            time.sleep(0.05)
        self.assertAlmostEqual(self.feed.tick("EURUSD").bid, 1.2, 5)
        sub = [m for m in self.fake.ws_log if m.get("subscribe", {}).get("event") == "ticks"]
        # (máy chủ giả có thể xử lý muộn tin đăng ký của test trước -> tìm đúng tin của test này)
        self.assertTrue(any(m["subscribe"]["instruments"] == ["EURUSD"] for m in sub), sub)

    def test_ws_handshake_used_signed_headers_and_subprotocol(self):
        self.feed.tick("EURUSD")
        self.assertIn("EURUSD", self.client.stream.ticks)       # fake từ chối nếu sai chữ ký/subprotocol

    def test_rest_fallback_when_no_ws_tick(self):
        self.feed.stream.wait_tick = lambda s, t: None
        t = self.feed.tick("GBPJPY")                            # không có trong bảng giá -> WS im lặng
        self.assertGreater(t.bid, 1.0)
        self.assertEqual(t.bid, t.ask)

    def test_history_basic_and_style_autodetect_remembered(self):
        self.fake.tf_enum = "lower"
        cs = self.feed.history("EURUSD", "1m", 5)
        self.assertEqual(len(cs), 5)
        self.assertEqual(self.client.tf_style, "lower")
        n = len(self.reqs("GET", "candles"))
        self.assertEqual(n, 3)                                   # M1 (400) -> 1m (400) -> m1 (ok)
        self.feed.history("EURUSD", "1m", 5)
        self.assertEqual(len(self.reqs("GET", "candles")), n + 1)   # lần sau đi thẳng, không dò lại

    def test_history_paging_with_end(self):
        cs = self.feed.history("EURUSD", "5m", 4, end=time.time() - 3600)
        self.assertEqual(len(cs), 4)
        self.assertLess(cs[-1].time, time.time() - 3000)
        self.assertEqual(self.client.time_style, "iso")
        for a, b in zip(cs, cs[1:]):
            self.assertEqual(b.time - a.time, 300)

    def test_history_resampled_for_non_native_timeframe(self):
        cs = self.feed.history("EURUSD", "2h", 3)
        self.assertEqual(len(cs), 3)
        self.assertEqual(cs[1].time - cs[0].time, 7200)

    def test_candle_parsing_variants(self):
        d = {"data": [{"timestamp": 1700000000000, "bid": {"o": 1, "h": 2, "l": 0.5, "c": 1.5}, "volume": 3}]}
        c = exness.parse_candles(d)[0]
        self.assertEqual((c.time, c.open, c.high, c.low, c.close), (1700000000.0, 1.0, 2.0, 0.5, 1.5))
        self.assertEqual(exness.parse_candles([{"time": "2026-10-01T10:00:00.123456789Z", "open": "1", "high": "2", "low": "1", "close": "2"}])[0].time,
                         1790848800.123456)
        self.assertEqual(exness.parse_candles({"candles": [{"time": 1, "open": "x"}]}), [])


class TestBroker(ExnBase):
    def test_prepare_returns_balance_and_sets_limits(self):
        self.assertEqual(self.broker.prepare("EURUSD"), 10000.0)
        self.assertEqual(self.client.trade_lim.rules, [(4.0, 1.0)])

    def test_market_buy_fill_from_ws_event(self):
        self.broker.prepare("EURUSD")
        f = self.broker.market_order("EURUSD", "buy", 0.05)
        self.assertAlmostEqual(f.price, 1.1002, 5)
        self.assertAlmostEqual(f.qty, 0.05, 6)
        body = self.reqs("POST", "/positions")[0]["body"]
        self.assertEqual(__import__("json").loads(body), {"instrument": "EURUSD", "side": "buy", "volume": "0.05"})
        self.assertEqual(len(self.fake.positions), 1)

    def test_market_order_polls_operation_when_event_slow(self):
        self.fake.confirm_after_polls = 2
        self.broker.stream.connected["events"] = False
        f = self.broker.market_order("EURUSD", "sell", 0.01)
        self.assertAlmostEqual(f.price, 1.1000, 5)
        self.assertGreaterEqual(len(self.reqs("GET", "/operations/")), 3)

    def test_fill_shapes_nested_and_noprice(self):
        for shape in ("nested", "noprice"):
            self.fake.op_shape = shape
            f = self.broker.market_order("EURUSD", "buy", 0.02)
            self.assertAlmostEqual(f.price, 1.1002, 5, shape)
            self.assertAlmostEqual(f.qty, 0.02, 6, shape)

    def test_rejected_operation_raises_with_reason(self):
        self.fake.reject_next = "NOT_ENOUGH_MONEY"
        with self.assertRaises(ExnError) as cm:
            self.broker.market_order("EURUSD", "buy", 0.01)
        self.assertIn("rejected", str(cm.exception))
        self.assertIn("NOT_ENOUGH_MONEY", str(cm.exception))

    def test_volume_validated_before_sending(self):
        before = len(self.reqs("POST"))
        with self.assertRaises(BrokerError) as cm:
            self.broker.market_order("EURUSD", "buy", 0.001)
        self.assertIn("tối thiểu", str(cm.exception))
        self.assertEqual(len(self.reqs("POST")), before)
        with self.assertRaises(BrokerError):
            self.broker.market_order("EURUSD", "buy", 500)

    def test_volume_rounded_down_to_step(self):
        self.broker.market_order("EURUSD", "buy", 0.037)
        self.assertEqual(__import__("json").loads(self.reqs("POST", "/positions")[0]["body"])["volume"], "0.03")

    def test_close_full_and_partial_by_position(self):
        self.broker.market_order("EURUSD", "buy", 0.10)
        self.fake.set_price("EURUSD", 1.1100, 1.1102)
        f = self.broker.market_order("EURUSD", "sell", 0.04, reduce_only=True)       # đóng một phần vị thế mua
        self.assertAlmostEqual(f.price, 1.1100, 5)
        self.assertAlmostEqual(f.qty, 0.04, 6)
        self.assertAlmostEqual(list(self.fake.positions.values())[0]["volume"], 0.06, 6)
        dele = self.reqs("DELETE", "/positions/")[0]
        self.assertEqual(__import__("json").loads(dele["body"]), {"volume": "0.04"})        # volume đi trong body (có body_hash trong chữ ký)
        self.assertEqual(dele["query"], {})
        f2 = self.broker.close_market("EURUSD", "buy", 0.06)
        self.assertAlmostEqual(f2.qty, 0.06, 6)
        self.assertEqual(self.fake.positions, {})
        self.assertGreater(self.fake.balance, 10000.0)

    def test_close_spanning_multiple_positions_fifo(self):
        for _ in range(3):
            self.broker.market_order("EURUSD", "buy", 0.02)
            time.sleep(0.01)
        f = self.broker.close_market("EURUSD", "buy", 0.05)
        self.assertAlmostEqual(f.qty, 0.05, 6)
        self.assertAlmostEqual(sum(p["volume"] for p in self.fake.positions.values()), 0.01, 6)

    def test_close_without_position_errors(self):
        with self.assertRaises(ExnError):
            self.broker.close_market("EURUSD", "buy", 0.01)

    def test_hedged_opposite_positions_not_netted_on_close(self):
        self.broker.market_order("EURUSD", "buy", 0.02)
        self.broker.market_order("EURUSD", "sell", 0.02)           # tài khoản hedging: hai vị thế riêng
        self.assertEqual(len(self.fake.positions), 2)
        self.broker.close_market("EURUSD", "buy", 0.02)
        self.assertEqual([p["side"] for p in self.fake.positions.values()], ["sell"])

    def test_positions_net_per_symbol(self):
        self.broker.market_order("EURUSD", "buy", 0.05)
        self.broker.market_order("EURUSD", "sell", 0.02)
        self.broker.market_order("XAUUSD", "sell", 0.01)
        pos = self.broker.positions()
        self.assertAlmostEqual(pos["EURUSD"]["qty"], 0.03, 6)
        self.assertAlmostEqual(pos["EURUSD"]["price"], 1.1002, 5)
        self.assertAlmostEqual(pos["XAUUSD"]["qty"], -0.01, 6)

    def test_balance_prefers_fresh_ws_account_state(self):
        self.broker.prepare("EURUSD")
        end = time.time() + 3
        while time.time() < end and not self.client.stream.state:
            time.sleep(0.05)
        self.fake.balance = 12345.0                              # REST sẽ trả số mới nhưng WS còn tươi -> dùng WS
        self.assertEqual(self.broker.balance(), 10000.0)


class TestNativePending(ExnBase):
    def test_place_modify_cancel(self):
        nid = self.broker.place_pending("EURUSD", "buy", "limit", 0.03, 1.0900, sl=1.0800, tp=1.1200)
        self.assertIn(nid, self.fake.orders)
        o = self.fake.orders[nid]
        self.assertEqual((o["type"], o["price"], o["sl"], o["tp"]), ("limit", 1.09, 1.08, 1.12))
        self.assertIn(nid, self.broker.pending_orders())
        self.broker.modify_pending(nid, price=1.0950, sl=0)
        self.assertEqual(self.fake.orders[nid]["price"], 1.095)
        self.assertIsNone(self.fake.orders[nid]["sl"])
        self.broker.cancel_pending(nid)
        self.assertEqual(self.fake.orders, {})
        self.assertEqual(self.broker.pending_orders(), {})

    def test_modify_uses_patch_only(self):
        nid = self.broker.place_pending("EURUSD", "sell", "stop", 0.01, 1.0500)
        self.broker.modify_pending(nid, price=1.0400)
        self.assertEqual(self.fake.orders[nid]["price"], 1.04)
        self.assertEqual([r["method"] for r in self.reqs(path_part="/orders/")], ["PATCH"])

    def test_native_fill_becomes_position_and_order_disappears(self):
        nid = self.broker.place_pending("EURUSD", "buy", "limit", 0.02, 1.0950)
        self.fake.set_price("EURUSD", 1.0940, 1.0942)
        self.assertNotIn(nid, self.broker.pending_orders())
        pos = self.broker.positions()
        self.assertAlmostEqual(pos["EURUSD"]["qty"], 0.02, 6)

    def test_unsupported_kind_rejected_locally(self):
        with self.assertRaises(ExnError):
            self.broker.place_pending("EURUSD", "buy", "stop_limit", 0.01, 1.0, stop_price=1.1)

    def test_cancel_unknown_order_raises(self):
        with self.assertRaises(ExnError) as cm:
            self.broker.cancel_pending("O999")
        self.assertEqual(cm.exception.status, 404)


class TestCandlesPerDocs(ExnBase):
    """Tài liệu: from BẮT BUỘC; from+to (from gồm, to không gồm); số nến <= max_candles_per_request; tăng dần."""

    def setUp(self):
        super().setUp()
        self.client.apply_limits()

    def candle_reqs(self):
        return self.reqs("GET", "/candles")

    def test_always_sends_from_and_to_never_bare_count(self):
        self.feed.history("EURUSD", "1m", 5)
        for r in self.candle_reqs():
            self.assertIn("from", r["query"])
            self.assertIn("to", r["query"])
            self.assertNotIn("count", r["query"])

    def test_more_than_max_per_request_is_paged_in_windows(self):
        cs = self.client.candles("EURUSD", "1m", 700)
        self.assertEqual(len(cs), 700)
        self.assertEqual(len({c.time for c in cs}), 700)
        self.assertEqual([c.time for c in cs], sorted(c.time for c in cs))
        self.assertGreaterEqual(len(self.candle_reqs()), 3)               # 700 nến / 300 mỗi lần
        for r in self.candle_reqs():                                       # không yêu cầu nào vượt giới hạn của sàn
            self.assertLessEqual(len(r["query"]["from"]), 40)

    def test_weekend_gap_is_bridged_by_widening_windows(self):
        now = time.time()
        self.fake.candle_gap = (now - 3 * 86400, now + 10)                  # 3 ngày gần đây không có nến
        cs = self.client.candles("EURUSD", "5m", 20)
        self.assertEqual(len(cs), 20)
        self.assertLess(cs[-1].time, now - 3 * 86400 + 1)                   # nến cuối cùng nằm TRƯỚC khoảng nghỉ

    def test_end_is_exclusive_and_results_end_before_it(self):
        end = (int(time.time()) // 300) * 300 - 3000
        cs = self.client.candles("EURUSD", "5m", 6, end=end)
        self.assertEqual(len(cs), 6)
        self.assertEqual(cs[-1].time, end - 300)

    def test_ms_only_server_is_probed_and_remembered(self):
        self.fake.time_fmt = "ms"
        self.assertEqual(len(self.client.candles("EURUSD", "1m", 4)), 4)
        self.assertEqual(self.client.time_style, "ms")
        n = len(self.candle_reqs())
        self.client.candles("EURUSD", "1m", 4)
        self.assertEqual(len(self.candle_reqs()), n + 1)

    def test_timeframe_error_does_not_burn_time_style_probes(self):
        self.fake.tf_enum = "lower"
        self.client.candles("EURUSD", "1m", 3)
        self.assertEqual(len(self.candle_reqs()), 3)                        # M1 -> 1m -> m1 (mỗi kiểu tên chỉ 1 yêu cầu)

    def test_native_timeframes_include_m3_and_m10(self):
        for tf in ("3m", "10m"):
            cs = self.feed.history("EURUSD", tf, 4)
            self.assertEqual(len(cs), 4, tf)
            self.assertEqual(cs[1].time - cs[0].time, 180 if tf == "3m" else 600)

    def test_unsupported_higher_tf_falls_back_to_resampling_once(self):
        cs = self.feed.history("EURUSD", "4h", 3)                          # máy chủ giả không có H4 -> ghép từ 1h
        self.assertEqual(len(cs), 3)
        self.assertEqual(cs[1].time - cs[0].time, 14400)
        self.assertIn("4h", self.feed._tf_bad)
        before = len(self.candle_reqs())
        self.feed.history("EURUSD", "4h", 3)
        self.assertTrue(all(r["query"]["timeframe"] == ["H1"] for r in self.candle_reqs()[before:]))      # lần sau không thử H4 nữa

    def test_rest_tick_fallback_uses_hourly_candle_when_market_closed(self):
        now = time.time()
        self.fake.candle_gap = (now - 5 * 86400, now + 10)
        self.feed.stream.wait_tick = lambda s, t: None
        t = self.feed.tick("GBPJPY")
        self.assertFalse(t.tradeable)
        self.assertLessEqual(len(self.candle_reqs()), 4)                    # không đập 10 cửa sổ 1m mỗi 5 giây


class TestFamilyRouting(ExnBase):
    def test_non_trading_families_find_their_host_and_remember(self):
        self.assertEqual(self.client.account()["currency"], "USD")
        self.assertEqual(self.client.fam_base["configuration"], "disc")
        self.broker.history(0)
        self.assertEqual(self.client.fam_base["history"], "ap")

    def test_opposite_host_assignment_is_discovered_without_config(self):
        self.fake.family_host = {"history": "disc", "configuration": "ap", "market-data": "ap"}
        self.assertEqual(self.client.account()["currency"], "USD")
        self.assertEqual(len(self.client.candles("EURUSD", "1m", 3)), 3)
        self.broker.history(0)
        self.assertEqual(self.client.fam_base, {"configuration": "ap", "market-data": "ap", "history": "disc"})
        n = len(self.reqs("GET", "/account"))
        self.client.account()
        self.assertEqual(len(self.reqs("GET", "/account")), n + 1)           # đã nhớ: không dò lại

    def test_auth_error_is_not_mistaken_for_wrong_host(self):
        other = Ed25519PrivateKey.generate().private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                                           serialization.NoEncryption()).decode()
        c = ExnClient("exnsk_test", other, "123456", self.fake.base)
        with self.assertRaises(ExnError) as cm:
            c.account()
        self.assertEqual(cm.exception.status, 401)
        self.assertEqual(len(self.reqs("GET", "/account")), 1)                # 401 không thử host khác


class TestHistoryPerDocs(ExnBase):
    def _trade(self):
        self.broker.market_order("EURUSD", "buy", 0.02)
        self.fake.set_price("EURUSD", 1.1050, 1.1052)
        self.broker.close_market("EURUSD", "buy", 0.02)

    def test_history_signature_matches_what_the_shell_calls(self):
        self.assertEqual(self.broker.history(0.0, ["EURUSD"]), [])            # sync.py gọi history(since, symbols) - từng là TypeError

    def test_deals_open_and_close_normalized_oldest_first(self):
        self._trade()
        self.fake.deals.append({"deal_id": "B1", "type": "balance", "instrument": "", "volume": 0, "price": 0, "profit": 100.0,
                                "event_time": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()})
        h = self.broker.history(time.time() - 3600)
        self.assertEqual([x["side"] for x in h], ["buy", "sell"])             # deal 'balance' (nạp tiền) KHÔNG phải lần khớp
        self.assertAlmostEqual(h[1]["qty"], 0.02, 6)
        self.assertGreater(h[1]["pnl"], 0)
        self.assertLess(h[0]["time"], h[1]["time"] + 1)
        self.assertEqual(h[0]["fee_asset"], "")
        req = self.reqs("GET", "/v1/history/")[0]
        self.assertEqual(req["path"], "/v1/history/accounts/123456/deals")
        self.assertEqual(req["query"]["limit"], ["200"])
        self.assertIn("from", req["query"])
        self.assertNotIn("to", req["query"])                                  # cửa sổ cuối không cần to

    def test_more_than_one_page_follows_cursor_without_duplicates(self):
        now = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        for i in range(450):
            self.fake.deals.append({"deal_id": "X%d" % i, "type": "close", "instrument": "EURUSD", "side": "sell", "volume": 0.01, "price": 1.1,
                                    "profit": 1.0, "commission": 0.0, "event_time": (now - __import__("datetime").timedelta(seconds=1000 - i)).isoformat()})
        h = self.broker.history(time.time() - 7200)
        self.assertEqual(len(h), 450)
        self.assertEqual(len({x["id"] for x in h}), 450)
        pages = self.reqs("GET", "/v1/history/")
        self.assertEqual(len(pages), 3)
        self.assertEqual(set(pages[1]["query"]), {"cursor", "limit"})         # tài liệu: cursor không đi chung bộ lọc khác ngoài limit

    def test_long_lookback_is_split_by_range_days_and_clamped_to_age(self):
        self.client.apply_limits()
        old = __import__("datetime").datetime.now(__import__("datetime").timezone.utc) - __import__("datetime").timedelta(days=45)
        self.fake.deals.append({"deal_id": "OLD", "type": "close", "instrument": "EURUSD", "side": "sell", "volume": 0.01, "price": 1.1,
                                "profit": 2.0, "commission": 0.0, "event_time": old.isoformat()})
        h = self.broker.history(time.time() - 200 * 86400)                    # xin xa hơn tuổi tối đa 90 ngày -> bị kẹp, không 400
        self.assertEqual([x["id"] for x in h], ["OLD"])
        qs = self.reqs("GET", "/v1/history/")
        self.assertGreaterEqual(len(qs), 3)                                    # 90 ngày / cửa sổ 30 ngày
        for q in qs:
            self.assertLessEqual(len(q["query"].get("from", ["x"])[0]), 40)

    def test_ms_time_format_discovered_for_history(self):
        self.fake.time_fmt = "ms"
        self._trade()
        self.assertEqual(len(self.broker.history(time.time() - 3600)), 2)
        self.assertEqual(self.client.hist_time_style, "ms")

    def test_missing_history_host_gives_clear_error(self):
        self.fake.family_host["history"] = "nowhere"
        with self.assertRaises(ExnError) as cm:
            self.broker.history(0)
        self.assertIn("/v1/history", str(cm.exception))


class TestErrorsPerDocs(ExnBase):
    def test_numeric_final_codes_map_to_names_hints_and_retryability(self):
        cases = [((6000, "x"), "EXECUTION_REQUOTE", True), (("6001", "x"), "EXECUTION_REJECTED", True),
                 ((4001, "x"), "MARKET_TRADE_DISABLED", False), ((5000, "x"), "TRADING_RULE_INVALID_VOLUME", False),
                 (("TRADING_RULE_INSUFFICIENT_MARGIN", ""), "TRADING_RULE_INSUFFICIENT_MARGIN", False),
                 ((0, "MARKET_SESSION_CLOSED"), "MARKET_SESSION_CLOSED", True)]
        for rej, name, retry in cases:
            self.fake.reject_next = rej
            with self.assertRaises(ExnError) as cm:
                self.broker.market_order("EURUSD", "buy", 0.01)
            e = cm.exception
            self.assertEqual((e.name, e.retryable), (name, retry), (rej, str(e)))
            self.assertIn("rejected", str(e))

    def test_unknown_error_keeps_raw_text(self):
        self.fake.reject_next = (9999, "SOMETHING_NEW")
        with self.assertRaises(ExnError) as cm:
            self.broker.market_order("EURUSD", "buy", 0.01)
        self.assertIn("SOMETHING_NEW", str(cm.exception))
        self.assertFalse(cm.exception.retryable)

    def test_http_level_error_has_name_and_retry_flag(self):
        self.fake.close()
        c = ExnClient("exnsk_test", self.pem, "123456", "http://127.0.0.1:1", timeout=1)
        with self.assertRaises(ExnError):
            c.account()
        self.__class__.fake = type(self.fake)(self.key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))

    def test_close_only_account_flags_and_sticky_block(self):
        fl = self.broker.account_flags()
        self.assertEqual((fl["currency"], fl["can_trade"]), ("USD", True))
        self.fake.account_status = "close_only"
        self.assertFalse(self.broker.account_flags()["can_trade"])
        self.fake.account_status = "active"
        self.assertTrue(self.broker.account_flags()["can_trade"])
        with self.assertRaises(ExnError) as cm:                              # sàn từ chối vì close-only -> nhớ để vỏ chặn lệnh mới
            self.fake.reject_next = ("ACCOUNT_CLOSE_ONLY", "")
            self.broker.market_order("EURUSD", "buy", 0.01)
        self.assertEqual(cm.exception.name, "ACCOUNT_CLOSE_ONLY")
        fl = self.broker.account_flags()
        self.assertFalse(fl["can_trade"])
        self.assertEqual(fl["blocked_by"], "ACCOUNT_CLOSE_ONLY")

    def test_trading_disabled_mode_blocks(self):
        self.fake.trade_mode = "trading_disabled"
        self.assertFalse(self.broker.account_flags()["can_trade"])


class TestPendingPerDocs(ExnBase):
    def test_prices_rounded_to_point_digits(self):
        nid = self.broker.place_pending("EURUSD", "buy", "limit", 0.01, 1.0900123456, sl=1.0800987654, tp=1.1200555555)
        body = __import__("json").loads(self.reqs("POST", "/orders")[0]["body"])
        self.assertEqual((body["price"], body["stop_loss_price"], body["take_profit_price"]), ("1.09001", "1.0801", "1.12006"))
        self.broker.modify_pending(nid, "EURUSD", price=1.0950999999)
        self.assertEqual(self.fake.orders[nid]["price"], 1.0951)

    def test_modify_without_symbol_looks_it_up(self):
        nid = self.broker.place_pending("EURUSD", "buy", "limit", 0.01, 1.09)
        self.broker.modify_pending(nid, price=1.0912345678)
        self.assertEqual(self.fake.orders[nid]["price"], 1.09123)

    def test_modify_removes_sl_tp_with_null_and_keeps_omitted(self):
        nid = self.broker.place_pending("EURUSD", "buy", "limit", 0.01, 1.09, sl=1.08, tp=1.12)
        self.broker.modify_pending(nid, "EURUSD", sl=0)
        body = __import__("json").loads(self.reqs("PATCH", "/orders/")[0]["body"])
        self.assertEqual(body, {"stop_loss_price": None})                     # tài liệu: null gỡ SL, khoá vắng mặt = giữ nguyên
        self.assertIsNone(self.fake.orders[nid]["sl"])
        self.assertEqual(self.fake.orders[nid]["tp"], 1.12)

    def test_pending_orders_expose_the_keys_the_shell_expects(self):
        nid = self.broker.place_pending("EURUSD", "sell", "stop", 0.03, 1.05)
        o = self.broker.pending_orders()[nid]
        from pyea import contract
        self.assertEqual(contract.check_pending({nid: o}), [])
        self.assertAlmostEqual(o["qty"], 0.03, 6)

    def test_close_only_rejects_new_pending_with_clear_reason(self):
        self.fake.account_status = "close_only"
        with self.assertRaises(ExnError) as cm:
            self.broker.place_pending("EURUSD", "buy", "limit", 0.01, 1.09)
        self.assertEqual(cm.exception.name, "ACCOUNT_CLOSE_ONLY")
        self.assertIn("close-only", str(cm.exception))


class TestPartialCloseSafety(ExnBase):
    """Tài liệu không nói volume của DELETE đi trong body hay query. Nếu đoán sai, sàn đóng HẾT thay vì một phần -> phải phát hiện."""

    def test_body_style_default_closes_only_part(self):
        self.broker.market_order("EURUSD", "buy", 0.10)
        self.broker.close_market("EURUSD", "buy", 0.04)
        self.assertAlmostEqual(list(self.fake.positions.values())[0]["volume"], 0.06, 6)
        self.assertEqual(self.client.close_style, "body")

    def test_server_reading_query_only_is_detected_and_style_flips(self):
        self.fake.close_volume_in = "query"
        self.broker.market_order("EURUSD", "buy", 0.10)
        with self.assertRaises(ExnError) as cm:
            self.broker.close_market("EURUSD", "buy", 0.04)                     # gửi body -> máy chủ bỏ qua -> đóng hết
        self.assertIn("HẾT", str(cm.exception))
        self.assertEqual(self.fake.positions, {})                               # (thiệt hại đã xảy ra: lỗi báo rõ để đối soát bắt lệch)
        self.assertEqual(self.client.close_style, "query")
        self.broker.market_order("EURUSD", "buy", 0.10)
        f = self.broker.close_market("EURUSD", "buy", 0.04)                     # lần sau gửi query -> đúng
        self.assertAlmostEqual(f.qty, 0.04, 6)
        self.assertAlmostEqual(list(self.fake.positions.values())[0]["volume"], 0.06, 6)
        self.assertEqual(self.client.close_style, "query")

    def test_full_close_never_sends_volume(self):
        self.broker.market_order("EURUSD", "buy", 0.05)
        self.broker.close_market("EURUSD", "buy", 0.05)
        r = self.reqs("DELETE", "/positions/")[0]
        self.assertEqual((r["body"], r["query"]), ("", {}))


if __name__ == "__main__":
    unittest.main()
