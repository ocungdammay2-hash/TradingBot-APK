"""SL/TP NATIVE - bộ test CHUNG cho MỌI sàn (Binance Futures, Binance Spot, OANDA, MT/MetaApi).

Vỏ (protect.py) chỉ nói «mỗi vị thế muốn SL/TP nào» qua broker.sync_protection(symbol, intents); cách sàn giữ mức (bậc thang reduceOnly, lệnh OCO, SL/TP gắn
trên ticket) nằm ở broker. Vì vậy MỘT bộ kịch bản kiểm hợp đồng đó chạy y hệt trên cả bốn sàn giả: mỗi sàn chỉ cần một lớp `Harness` mỏng (dựng phiên, đẩy giá phía
sàn, bắt sàn khớp lệnh bảo vệ, tạo vật thể «lạ», đếm lời gọi ghi). THÊM SÀN MỚI = thêm một Harness vào danh sách HARNESSES, không viết lại kịch bản.
Test riêng của từng sàn (định dạng lệnh, luật giá, bụi...) nằm ở test_protect.py / test_protect_spot.py / test_protect_oanda.py / test_protect_mt.py.
"""
import os
import sys
import tempfile
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX, FakeOandaX          # noqa: E402
from fake_mt import FakeMetaApi, MtCore                      # noqa: E402
from pyea import contract, ratelimit                         # noqa: E402
from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.bridges import MetaApiBackend, MtBroker            # noqa: E402
from pyea.broker import BinanceBroker, BinanceFuturesBroker, OandaBroker   # noqa: E402
from pyea.engine import Account, TradingSession              # noqa: E402
from pyea.protection import STYLES, levels_of                # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402


def near(a, b, rel=1e-6):
    return abs(a - b) <= max(abs(b) * rel, 1e-9)


# =============================================================================================== adapter mỏng cho từng sàn
class Harness:
    """Mô tả một sàn giả cho bộ kịch bản chung. Giá/khối lượng do từng sàn chọn (số tròn hợp lệ với luật của sàn)."""
    NAME = "?"
    EXCHANGE = "?"
    SYM = "?"
    P0 = 0.0                                   # giá phía vỏ lúc bắt đầu
    VOL_A, VOL_B = 0.0, 0.0                    # khối lượng hai vị thế
    LV_A = (0.0, 0.0)                          # (SL, TP) vị thế mua A
    LV_B = (0.0, 0.0)                          # (SL, TP) vị thế mua B (mức khác A)
    SL_NEW = 0.0                               # SL mới khi sửa A
    SHORT = None                               # (SL, TP) của vị thế BÁN, None = sàn không bán khống
    INITIAL = 100000.0
    STYLE = ""

    def __init__(self):
        self.start()

    # --- sàn
    def start(self): raise NotImplementedError
    def close(self): raise NotImplementedError
    def reset(self): raise NotImplementedError
    def make_broker(self): raise NotImplementedError
    def exchange_price(self, px): raise NotImplementedError
    def fire(self, leg, level, side="buy"): raise NotImplementedError          # sàn khớp lệnh bảo vệ `leg` đang đặt ở mức `level`
    def foreign(self): raise NotImplementedError                               # tạo vật thể KHÔNG của vỏ; trả hàm kiểm «vẫn nguyên vẹn»
    def cancel_external(self): raise NotImplementedError                       # ai đó gỡ bảo vệ trực tiếp trên sàn
    def writes(self): raise NotImplementedError                                # số lời gọi GHI lên sàn từ đầu
    def exchange_net(self): raise NotImplementedError                          # vị thế ròng trên sàn (đơn vị của vỏ)

    # --- phiên
    def session(self, state_dir, **over):
        st = default_settings()
        st.update(mode="paper", exchange=self.EXCHANGE, initial_balance=self.INITIAL, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
                  max_loss_pct=0.0, native_sltp=True, native_sync_s=1.0, reconcile_interval=0)
        st.update(over)
        s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=os.path.join(state_dir, "state.json") if state_dir else None)
        s.events = deque(maxlen=10000)
        s.account = Account(st["initial_balance"], 0.0, 1.0)
        s.status = "running"
        s.ready.set()
        s.watch = [self.SYM]
        s.broker = self.make_broker()
        s.broker.prepare(self.SYM)
        s.sync = False                                         # phiên «live» (không luồng nền): test tự gọi _check_protection
        return s

    def tick(self, s, price, t=1000.0):
        s.process_tick(Tick(self.SYM, t, price, price))


class FuturesH(Harness):
    NAME, EXCHANGE, SYM, P0, STYLE = "binance_futures", "binance_futures", "BTCUSDT", 100.0, "ladder"
    VOL_A, VOL_B = 0.03, 0.02
    LV_A, LV_B, SL_NEW, SHORT = (95.0, 110.0), (90.0, 120.0), 96.0, (105.0, 90.0)

    def start(self): self.fx = FakeBinanceX()
    def close(self): self.fx.close()

    def reset(self):
        self.fx.reset()
        self.fx.price = 100.0

    def make_broker(self):
        return BinanceFuturesBroker("key123", "sekret", self.fx.base)

    def exchange_price(self, px): self.fx.price = px

    def fire(self, leg, level, side="buy"):
        want = "STOP_MARKET" if leg == "sl" else "TAKE_PROFIT_MARKET"
        for aid, a in self.fx.fut["algo"].items():
            if a["algoStatus"] == "NEW" and a["orderType"] == want and near(float(a["triggerPrice"]), level):
                return self.fx.fill_algo(aid, level)
        raise AssertionError("không có lệnh %s @%s trên sàn: %s" % (leg, level, list(self.fx.fut["algo"].values())))

    def foreign(self):
        self.fx.fut["algo"]["777"] = {"algoId": 777, "clientAlgoId": "my-own-order", "algoType": "CONDITIONAL", "orderType": "STOP_MARKET",
                                      "symbol": self.SYM, "side": "SELL", "quantity": "0.100", "algoStatus": "NEW", "triggerPrice": "70.00",
                                      "reduceOnly": "true", "actualOrderId": "", "actualPrice": "0"}
        return lambda: self.fx.fut["algo"]["777"]["algoStatus"] == "NEW" and self.fx.fut["algo"]["777"]["triggerPrice"] == "70.00"

    def cancel_external(self):
        for a in self.fx.fut["algo"].values():
            if a["algoStatus"] == "NEW" and str(a["clientAlgoId"]).startswith("pyeaP"):
                a["algoStatus"] = "CANCELED"

    def writes(self): return len([c for c in self.fx.calls if c[0] in ("POST", "DELETE", "PUT")])
    def exchange_net(self): return self.fx.fut["pos"]


class SpotH(Harness):
    NAME, EXCHANGE, SYM, P0, STYLE = "binance_spot", "binance_spot", "BTCUSDT", 100.0, "pair"
    VOL_A, VOL_B = 0.03, 0.02
    LV_A, LV_B, SL_NEW, SHORT = (95.0, 110.0), (90.0, 120.0), 96.0, None

    def start(self): self.fx = FakeBinanceX()
    def close(self): self.fx.close()

    def reset(self):
        self.fx.reset()
        self.fx.price = 100.0
        self.fx.fee_rate = 0.0

    def make_broker(self):
        return BinanceBroker("key123", "sekret", self.fx.base)

    def exchange_price(self, px): self.fx.price = px

    def fire(self, leg, level, side="buy"):
        for lid, lst in self.fx.spot["lists"].items():
            if lst["status"] != "EXECUTING":
                continue
            o = self.fx.spot["orders"][str(lst["legs"][leg])]
            if near(float(o.get("stopPrice") if leg == "sl" else o.get("price")), level):
                return self.fx.fill_oco(lid, leg, level)
        raise AssertionError("không có cặp OCO có chân %s @%s" % (leg, level))

    def foreign(self):
        self.fx.spot["bal"]["BTC"] = 1.0
        self.fx.spot["orders"]["999"] = {"orderId": 999, "symbol": self.SYM, "side": "SELL", "type": "LIMIT", "origQty": "0.2", "status": "NEW",
                                         "price": "200.00", "clientId": "my-own-order", "orderListId": -1}
        return lambda: self.fx.spot["orders"]["999"]["status"] == "NEW"

    def cancel_external(self):
        for lid, lst in list(self.fx.spot["lists"].items()):
            if lst["status"] == "EXECUTING":
                self.fx.external_cancel_oco(lid)

    def writes(self): return len([c for c in self.fx.calls if c[0] in ("POST", "DELETE", "PUT")])
    def exchange_net(self): return self.fx.spot["bal"]["BTC"]


class OandaH(Harness):
    NAME, EXCHANGE, SYM, P0, STYLE = "oanda", "oanda", "EUR_USD", 1.1000, "ladder"
    VOL_A, VOL_B = 600, 400
    LV_A, LV_B, SL_NEW, SHORT = (1.0900, 1.1200), (1.0800, 1.1300), 1.0950, (1.1100, 1.0800)
    INITIAL = 1_000_000.0

    def start(self): self.fx = FakeOandaX()
    def close(self): self.fx.close()
    def reset(self): self.fx.reset()

    def make_broker(self):
        return OandaBroker(self.fx.TOKEN, self.fx.ACC, self.fx.base)

    def exchange_price(self, px): self.fx.price = px

    def _pending(self):
        return [(k, o) for k, o in self.fx.orders.items() if o["state"] == "PENDING"]

    def fire(self, leg, level, side="buy"):
        want = "STOP" if leg == "sl" else "LIMIT"
        for k, o in self._pending():
            if o["type"] == want and near(float(o["price"]), level) and str((o.get("clientExtensions") or {}).get("id", "")).startswith("pyeaP"):
                return self.fx.fill(k, level)
        raise AssertionError("không có lệnh %s @%s trên sàn" % (leg, level))

    def foreign(self):
        self.fx.orders["999"] = {"type": "LIMIT", "instrument": self.SYM, "units": "-50", "price": "1.20000", "positionFill": "REDUCE_ONLY",
                                 "timeInForce": "GTC", "triggerCondition": "DEFAULT", "state": "PENDING", "clientExtensions": {"id": "my-own"}}
        return lambda: self.fx.orders["999"]["state"] == "PENDING"

    def cancel_external(self):
        for k, o in self._pending():
            if str((o.get("clientExtensions") or {}).get("id", "")).startswith("pyeaP"):
                self.fx.cancel_external(k)

    def writes(self): return len([c for c in self.fx.calls if c[0] in ("POST", "DELETE", "PUT")])
    def exchange_net(self): return self.fx.pos


class MtH(Harness):
    NAME, EXCHANGE, SYM, P0, STYLE = "metaapi", "metaapi", "EURUSD", 1.1000, "position"
    VOL_A, VOL_B = 0.06, 0.04
    LV_A, LV_B, SL_NEW, SHORT = (1.0900, 1.1200), (1.0800, 1.1300), 1.0950, (1.1100, 1.0800)
    INITIAL = 1_000_000.0

    def start(self):
        self.core = MtCore()
        self.api = FakeMetaApi(self.core)

    def close(self): self.api.close()

    def reset(self):
        ratelimit.reset_all()
        c = self.core
        c.positions.clear(); c.orders.clear(); c.deals.clear(); c.sltp_calls.clear(); c.log.clear()
        c.balance, c.reject_next = 10000.0, None
        c.prices["EURUSD"] = [1.1000, 1.1002]
        self.api.requests.clear()

    def make_broker(self):
        return MtBroker(MetaApiBackend(self.api.TOKEN, self.api.ACC, client_url=self.api.base, data_url=self.api.base))

    def exchange_price(self, px): self.core.set_price(self.SYM, px, round(px + 0.0002, 5))

    def fire(self, leg, level, side="buy"):
        # Máy chủ MT tự canh SL/TP của từng vị thế: đẩy giá tới mức là vị thế chạm mức tự đóng (đúng như sàn thật)
        if side == "buy":
            self.core.set_price(self.SYM, level, round(level + 0.0002, 5))
        else:
            self.core.set_price(self.SYM, round(level - 0.0002, 5), level)

    def foreign(self):
        pid, _, _ = self.core.open(self.SYM, "buy", 0.05, "")                  # vị thế đặt tay trên MT (comment rỗng)
        self.core.positions[pid]["sl"] = 1.0000
        return lambda: (pid in self.core.positions and self.core.positions[pid]["sl"] == 1.0000 and self.core.positions[pid]["tp"] == 0.0
                        and pid not in [c[0] for c in self.core.sltp_calls])

    def cancel_external(self):
        for pid, p in list(self.core.positions.items()):
            if str(p.get("comment", "")).startswith("pyea"):
                p["sl"], p["tp"] = 0.0, 0.0                                    # ai đó xoá SL/TP tay trên MT

    def writes(self): return len([r for r in self.api.requests if r[0] == "POST"])

    def exchange_net(self):
        return sum((p["volume"] if p["side"] == "buy" else -p["volume"]) for p in self.core.positions.values()
                   if p["symbol"] == self.SYM and str(p.get("comment", "")).startswith("pyea"))


try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    HAVE_CRYPTO = True
except ImportError:                                            # pragma: no cover
    HAVE_CRYPTO = False


class ExnH(Harness):
    """Exness (PROT_STYLE=position, SLTP là một LỆNH riêng gắn với vị thế; sửa bằng PATCH, gỡ bằng DELETE)."""
    NAME, EXCHANGE, SYM, P0, STYLE = "exness", "exness", "EURUSD", 1.1000, "position"
    VOL_A, VOL_B = 0.06, 0.04
    LV_A, LV_B, SL_NEW, SHORT = (1.0900, 1.1200), (1.0800, 1.1300), 1.0950, (1.1100, 1.0800)
    INITIAL = 1_000_000.0

    def start(self):
        from fake_exness import FakeExness
        from pyea import exness
        self.exness = exness
        key = Ed25519PrivateKey.generate()
        self.pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        pub = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.fake = FakeExness(pub)
        self.foreign_ids = set()

    def close(self):
        self.fake.close()

    def reset(self):
        ratelimit.reset_all()
        f = self.fake
        with f.lock:
            f.positions.clear(); f.orders.clear(); f.ops.clear(); f.requests.clear(); f.deals.clear()
            f.balance, f.reject_next = 10000.0, None
            f.prices["EURUSD"] = [1.1000, 1.1002]
            f.sltp_key, f.sltp_needs_instrument, f.sltp_model, f.sltp_created = "position_id", False, "orders", []
            f.account_status, f.trade_mode, f.confirm_after_polls = "active", "full", 0
        self.foreign_ids = set()
        self.exness._CLIENTS.clear()

    def make_broker(self):
        st = {"exness_api_key": "exnsk_test", "exness_private_key": self.pem, "exness_account": "123456", "exness_host": self.fake.base}
        return self.exness.ExnBroker(self.exness.client_for(st))

    def exchange_price(self, px): self.fake.set_price(self.SYM, px, round(px + 0.0002, 5))

    def fire(self, leg, level, side="buy"):
        if side == "buy":
            self.fake.set_price(self.SYM, level, round(level + 0.0002, 5))
        else:
            self.fake.set_price(self.SYM, round(level - 0.0002, 5), level)

    def foreign(self):
        f = self.fake
        with f.lock:
            pid = f._open(self.SYM, "buy", 0.05, 1.1002)                     # vị thế bạn mở tay trên app Exness + SLTP của chính bạn
            self.foreign_ids.add(pid)
            f.orders["F1"] = {"type": "sltp", "instrument": self.SYM, "side": "buy", "volume": 0.05, "price": 0.0, "sl": 1.0, "tp": None, "position_id": pid}
        return lambda: pid in f.positions and f.orders.get("F1", {}).get("sl") == 1.0 and f.orders["F1"].get("tp") is None

    def cancel_external(self):
        f = self.fake
        with f.lock:
            for k, o in list(f.orders.items()):
                if o.get("type") == "sltp" and k != "F1":
                    del f.orders[k]                                          # ai đó gỡ SL/TP tay trên app Exness

    def writes(self): return len([r for r in self.fake.requests if r["method"] in ("POST", "DELETE", "PATCH")])

    def exchange_net(self):
        return sum((p["volume"] if p["side"] == "buy" else -p["volume"]) for pid, p in self.fake.positions.items()
                   if p["instrument"] == self.SYM and pid not in self.foreign_ids)


HARNESSES = [FuturesH, SpotH, OandaH, MtH] + ([ExnH] if HAVE_CRYPTO else [])


# =============================================================================================== bộ kịch bản chung
class Conformance:
    H = None                                                   # lớp Harness; lớp con test gán

    @classmethod
    def setUpClass(cls):
        cls.h = cls.H()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        h = self.h
        h.reset()
        self.tmp = tempfile.mkdtemp()
        self.s = h.session(self.tmp)
        h.tick(self.s, h.P0)

    # ---- tiện ích
    def open(self, vol, sl, tp, side="buy"):
        r = self.s.send_order(self.h.SYM, side, vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position

    def poll(self, s=None):
        s = s or self.s
        s._prot_next = 0.0
        s._check_protection()

    def live_levels(self):
        out = set()
        for o in self.s.broker.protection_orders(self.h.SYM):
            out.update(round(x, 6) for x in levels_of(o) if x)
        return out

    def assert_levels(self, *levels):
        self.assertEqual(self.live_levels(), {round(x, 6) for x in levels if x})

    def covered(self, p, *legs):
        for leg in legs:
            self.assertTrue(self.s.prot_covered(p.id, leg), "%s của #%d chưa được sàn canh" % (leg, p.id))

    # ---- kịch bản
    def test_style_is_declared(self):
        b = self.s.broker
        self.assertIn(b.PROT_STYLE, STYLES)
        self.assertEqual(b.PROT_STYLE, self.h.STYLE)
        self.assertEqual(contract.check_broker_attrs(b), [])
        self.assertEqual(contract.check_class(type(b), contract.BROKER_CALLS), [])

    def test_levels_are_placed_covered_and_contract_valid(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                   # vừa mở: chưa có bảo vệ -> vỏ tự canh
        self.poll()
        self.covered(p, "sl", "tp")
        self.assert_levels(*h.LV_A)
        self.assertEqual(contract.check_protection_orders(self.s.broker.protection_orders(h.SYM)), [])
        intents = self.s._prot_desired(h.SYM)
        res = self.s.broker.sync_protection(h.SYM, intents)
        self.assertEqual(contract.check_protection_result(res, intents), [])
        self.assertEqual(res["covered"], {p.id: ["sl", "tp"]})
        self.assertEqual(res["errors"], [])

    def test_resync_is_idempotent(self):
        h = self.h
        self.open(h.VOL_A, *h.LV_A)
        self.poll()
        n = h.writes()
        self.poll()
        self.poll()
        self.assertEqual(h.writes(), n, "đồng bộ lại đã ghi thêm lên sàn")

    def test_shell_leaves_a_covered_level_to_the_exchange(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        n, net = h.writes(), h.exchange_net()
        h.tick(self.s, h.LV_A[0] - abs(h.LV_A[0]) * 0.005, 1001.0)          # giá xuyên SL nhưng sàn canh -> vỏ KHÔNG đóng
        self.assertIn(p.id, self.s.account.positions)
        self.assertEqual((h.writes(), h.exchange_net()), (n, net))

    def test_modify_moves_the_level_without_leaving_a_stale_one(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        self.assertTrue(self.s.modify_position(p.id, sl=h.SL_NEW))
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                   # đang đổi: vỏ canh tạm thời mức mới
        self.poll()
        self.covered(p, "sl", "tp")
        self.assert_levels(h.SL_NEW, h.LV_A[1])
        n = h.writes()
        self.s.modify_position(p.id, sl=h.SL_NEW)                           # không đổi mức -> không đụng tới sàn
        self.poll()
        self.assertEqual(h.writes(), n)

    def test_shell_close_removes_protection_and_flattens_the_exchange(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        r = self.s.close_position(p.id, "bot", "x")
        self.assertTrue(r, r.message)
        self.poll()
        self.assertEqual(self.s.broker.protection_orders(h.SYM), [])
        self.assertAlmostEqual(h.exchange_net(), 0.0, 6)
        self.assertEqual(self.s.account.positions, {})
        self.assertEqual(self.s.reconcile_now(), [])

    def test_closing_one_position_keeps_the_other_protected(self):
        h = self.h
        a, b = self.open(h.VOL_A, *h.LV_A), self.open(h.VOL_B, *h.LV_B)
        self.poll()
        self.covered(a, "sl", "tp")
        self.covered(b, "sl", "tp")
        self.assert_levels(*h.LV_A, *h.LV_B)
        self.assertTrue(self.s.close_position(a.id, "bot", "x"))
        self.poll()
        self.assert_levels(*h.LV_B)
        self.covered(b, "sl", "tp")
        self.assertAlmostEqual(h.exchange_net(), h.VOL_B, 6)

    def _fill_case(self, leg, near_first=True):
        """Hai vị thế: N có mức GẦN giá (sẽ khớp) và F có mức XA giá. `near_first` = N mở trước (id nhỏ hơn) hay sau F. Sàn khớp lệnh bảo vệ của N: chỉ ĐÚNG N được ghi sổ,
        F vẫn mở và vẫn được bảo vệ. (N mở SAU F bắt lỗi kiểu «ghi sổ nhầm vị thế có id nhỏ nhất».)"""
        h = self.h
        specs = [("N", h.VOL_A, h.LV_A), ("F", h.VOL_B, h.LV_B)]
        pos = {}
        for name, vol, lv in (specs if near_first else specs[::-1]):
            pos[name] = self.open(vol, *lv)
        self.poll()
        hit, left = pos["N"], pos["F"]
        lv = h.LV_A[0 if leg == "sl" else 1]
        h.fire(leg, lv)
        self.poll()
        self.assertNotIn(hit.id, self.s.account.positions)
        self.assertIn(left.id, self.s.account.positions)
        tr = self.s.account.trades[-1]
        self.assertTrue(near(tr.close_price, lv), "giá ghi sổ %r != mức %r" % (tr.close_price, lv))
        self.assertAlmostEqual(tr.volume, h.VOL_A, 8)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, leg)
        self.assertIn("NATIVE", ev.reason)
        self.assertAlmostEqual(h.exchange_net(), h.VOL_B, 6)               # vỏ KHÔNG đóng thêm (đóng đúp sẽ làm lệch vị thế ròng)
        self.assert_levels(*h.LV_B)                                         # chỉ còn mức của vị thế kia
        self.covered(left, "sl", "tp")
        self.assertEqual(self.s.reconcile_now(), [])

    def test_sl_fill_is_booked_and_the_other_position_stays_protected(self):
        self._fill_case("sl")

    def test_tp_fill_is_booked_and_the_other_position_stays_protected(self):
        self._fill_case("tp")

    def test_fill_of_the_later_position_does_not_book_the_earlier_one(self):
        self._fill_case("sl", near_first=False)

    def test_tp_fill_of_the_later_position_does_not_book_the_earlier_one(self):
        self._fill_case("tp", near_first=False)

    def test_modify_is_resynced_on_the_very_next_cycle_not_after_the_interval(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        self.s._prot_next = 1e18                                            # đang «chờ» tới kỳ đồng bộ sau; modify phải buộc chạy ngay
        self.assertTrue(self.s.modify_position(p.id, sl=h.SL_NEW))
        self.s._check_protection()                                          # KHÔNG đặt lại _prot_next: vòng kế tiếp phải đồng bộ
        self.assertTrue(self.s.prot_covered(p.id, "sl"), "mức mới không được đồng bộ ở vòng kế tiếp")
        self.assert_levels(h.SL_NEW, h.LV_A[1])

    def test_foreign_objects_are_never_touched(self):
        h = self.h
        intact = h.foreign()
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        self.poll()
        self.assertTrue(intact(), "vật thể không phải của vỏ đã bị đụng tới")
        self.covered(p, "sl", "tp")

    def test_externally_removed_protection_is_placed_again(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        h.cancel_external()
        self.assertEqual(self.s.broker.protection_orders(h.SYM), [])
        self.poll()
        self.poll()
        self.assert_levels(*h.LV_A)
        self.covered(p, "sl", "tp")

    def test_restart_does_not_duplicate_live_protection(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        state = self.s.account.to_dict()
        s2 = h.session(self.tmp)
        s2.account.restore(state)
        h.tick(s2, h.P0, 2000.0)
        n = h.writes()
        self.poll(s2)
        self.assertEqual(h.writes(), n)                                     # nhận ra mức đang sống, không đặt lại
        self.assertTrue(s2.prot_covered(p.id, "sl") and s2.prot_covered(p.id, "tp"))

    def test_fill_while_app_was_off_is_booked_after_restart(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        state = self.s.account.to_dict()
        h.fire("sl", h.LV_A[0])                                             # app tắt, sàn khớp lệnh bảo vệ
        s2 = h.session(self.tmp)                                            # app mở lại: cùng thư mục state (protect.json + vị thế)
        s2.account.restore(state)
        h.tick(s2, h.LV_A[0], 2000.0)
        self.assertIn(p.id, s2.account.positions)
        self.poll(s2)
        self.assertNotIn(p.id, s2.account.positions)
        self.assertTrue(near(s2.account.trades[-1].close_price, h.LV_A[0]))
        self.assertAlmostEqual(h.exchange_net(), 0.0, 6)
        self.assertEqual(s2.reconcile_now(), [])

    def test_hold_blocks_shell_exits_right_after_restart_then_expires(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        state = self.s.account.to_dict()
        s2 = h.session(self.tmp)
        s2.account.restore(state)
        self.assertTrue(s2.prot_hold(h.SYM))
        h.tick(s2, h.LV_A[0] - abs(h.LV_A[0]) * 0.005, 2000.0)             # xuyên SL nhưng đang «giữ» (chưa xác minh): vỏ không tự đóng
        self.assertIn(p.id, s2.account.positions)
        s2._prot_hold_until = 0.0
        self.assertFalse(s2.prot_hold(h.SYM))
        h.tick(s2, h.LV_A[0] - abs(h.LV_A[0]) * 0.005, 2001.0)
        self.assertNotIn(p.id, s2.account.positions)

    def test_default_is_off_and_places_nothing(self):
        h = self.h
        s = h.session(tempfile.mkdtemp(), native_sltp=False)
        h.tick(s, h.P0)
        r = s.send_order(h.SYM, "buy", h.VOL_A, h.LV_A[0], h.LV_A[1])
        self.assertTrue(r, r.message)
        self.poll(s)
        self.assertEqual(s.broker.protection_orders(h.SYM), [])
        self.assertFalse(s.prot_covered(r.position.id, "sl"))

    def test_turning_the_setting_off_removes_protection_and_returns_control(self):
        h = self.h
        p = self.open(h.VOL_A, *h.LV_A)
        self.poll()
        self.covered(p, "sl", "tp")
        self.s.settings["native_sltp"] = False
        self.poll()
        self.assertEqual(self.s.broker.protection_orders(h.SYM), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl") or self.s.prot_covered(p.id, "tp"))
        h.tick(self.s, h.LV_A[0] - abs(h.LV_A[0]) * 0.005, 1001.0)          # vỏ canh lại và tự đóng khi giá xuyên SL
        self.assertNotIn(p.id, self.s.account.positions)

    def test_short_positions_close_on_the_other_side(self):
        h = self.h
        if h.SHORT is None:
            self.skipTest("%s không bán khống" % h.NAME)
        p = self.open(h.VOL_A, *h.SHORT, side="sell")
        self.poll()
        self.covered(p, "sl", "tp")
        self.assert_levels(*h.SHORT)
        h.fire("tp", h.SHORT[1], side="sell")
        self.poll()
        self.assertNotIn(p.id, self.s.account.positions)
        self.assertTrue(near(self.s.account.trades[-1].close_price, h.SHORT[1]))
        self.assertAlmostEqual(h.exchange_net(), 0.0, 6)


def _make(h_cls):
    return type("TestConformance_%s" % h_cls.NAME, (Conformance, unittest.TestCase), {"H": h_cls})


for _h in HARNESSES:
    _cls = _make(_h)
    globals()[_cls.__name__] = _cls
del _h, _cls


if __name__ == "__main__":
    unittest.main()
