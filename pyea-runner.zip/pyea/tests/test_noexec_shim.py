"""Lớp đệm LD_PRELOAD cho Box64 (tools/mt5_phone/shim/pyea_noexec.c): khi nhân trả EACCES/EPERM cho mprotect/mmap có PROT_EXEC thì thử lại không PROT_EXEC.

Chứng minh được (trong sandbox): mã nguồn thật, biên dịch cho máy chạy test, trên một mount noexec THẬT (nếu mount được): mprotect lỗi EACCES / mmap lỗi EPERM
đúng như dòng «noexec filesystem?» của Wine; có lớp đệm thì thành công và ghi log; lỗi khác (ENOMEM) không bị che; máy bình thường không bị đổi hành vi.
Bản aarch64 đóng trong APK: kiểm cấu trúc ELF + khớp mã nguồn (BUILD_INFO.txt); đã nạp thử bằng qemu-user một lần (không nằm trong bộ test).
KHÔNG chứng minh: lớp đệm cứu được Wine+Box64 trên điện thoại thật (nguyên nhân lỗi trên máy chưa được xác định chắc chắn)."""
import hashlib
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, ROOT)

from pyea import mt5ea    # noqa: E402

SHIM_DIR = os.path.join(ROOT, "tools", "mt5_phone", "shim")
SRC = os.path.join(SHIM_DIR, "pyea_noexec.c")
ASSET = os.path.join(ROOT, "pyea", "assets", mt5ea.SHIM_ASSET)

HOST_C = r"""
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
int main(int argc, char **argv) {
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) { perror("open"); return 2; }
    void *m = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 0);
    if (m == MAP_FAILED) { perror("mmap R"); return 3; }
    int r = mprotect(m, 4096, PROT_READ | PROT_EXEC);
    printf("mprotect_RX=%d errno=%d\n", r, r ? errno : 0);
    void *x = mmap(NULL, 4096, PROT_READ | PROT_EXEC, MAP_PRIVATE, fd, 0);
    printf("mmap_RX=%s errno=%d\n", x == MAP_FAILED ? "FAIL" : "ok", x == MAP_FAILED ? errno : 0);
    int r3 = mprotect((void *)0x10000, 4096, PROT_READ | PROT_EXEC);
    printf("unmapped=%d errno=%d\n", r3, r3 ? errno : 0);
    return 0;
}
"""


def cc():
    for n in ("clang", "gcc", "cc"):
        if shutil.which(n):
            return shutil.which(n)
    return None


def kv(text):
    return dict(re.findall(r"^(\w+)=(-?\d+|ok|FAIL)", text, re.M)) | {k + "_errno": v for k, v in re.findall(r"^(\w+)=\S+ errno=(\d+)", text, re.M)}


class TestShimBehaviour(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="pyea_shim_")
        c = cc()
        if not c or sys.platform != "linux":
            cls.so = None
            return
        cls.so = os.path.join(cls.tmp, "shim.so")
        r = subprocess.run([c, "-O2", "-fPIC", "-shared", "-nostdlib", "-ffreestanding", "-fno-builtin", "-Wl,-z,now", "-o", cls.so, SRC], capture_output=True, text=True)
        if r.returncode:
            cls.so = None
            return
        host_c = os.path.join(cls.tmp, "host.c")
        open(host_c, "w").write(HOST_C)
        cls.host = os.path.join(cls.tmp, "host")
        r = subprocess.run([c, "-O1", "-o", cls.host, host_c], capture_output=True, text=True)
        if r.returncode:
            cls.so = None

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def setUp(self):
        if not self.so:
            self.skipTest("không có trình biên dịch C trong môi trường test")

    def run_host(self, path, preload=True, log=None):
        env = dict(os.environ)
        env.pop("LD_PRELOAD", None)
        if preload:
            env["LD_PRELOAD"] = self.so
        if log:
            env["PYEA_SHIM_LOG"] = log
        r = subprocess.run([self.host, path], env=env, capture_output=True, text=True, timeout=30)
        self.assertEqual(r.returncode, 0, r.stderr)
        return kv(r.stdout)

    def mount_noexec(self):
        d = os.path.join(self.tmp, "nx")
        os.makedirs(d, exist_ok=True)
        r = subprocess.run(["mount", "-t", "tmpfs", "-o", "noexec,size=4m", "tmpfs", d], capture_output=True, text=True)
        if r.returncode:
            self.skipTest("không mount được tmpfs noexec (cần quyền root): %s" % r.stderr.strip())
        self.addCleanup(lambda: subprocess.run(["umount", d], capture_output=True))
        f = os.path.join(d, "f.bin")
        with open(f, "wb") as fh:
            fh.write(os.urandom(8192))
        return f

    def test_noexec_mount_fails_without_shim_exactly_like_wine_reports(self):
        f = self.mount_noexec()
        v = self.run_host(f, preload=False)
        self.assertEqual(v["mprotect_RX"], "-1")
        self.assertEqual(v["mprotect_RX_errno"], "13", "EACCES: đúng lỗi làm Wine in «failed to set ... protection ..., noexec filesystem?»")
        self.assertEqual(v["mmap_RX"], "FAIL")
        self.assertEqual(v["mmap_RX_errno"], "1")

    def test_shim_rescues_noexec_mount_and_logs_errno(self):
        f = self.mount_noexec()
        log = os.path.join(self.tmp, "rescue.log")
        v = self.run_host(f, preload=True, log=log)
        self.assertEqual(v["mprotect_RX"], "0")
        self.assertEqual(v["mmap_RX"], "ok")
        text = open(log).read()
        self.assertIn("tai pid=", text)
        self.assertRegex(text, r"mprotect addr=0x[0-9a-f]+ len=0x1000 prot=0x5 errno=13 -> thu-lai-khong-exec:ok")
        self.assertRegex(text, r"mmap addr=0x0 len=0x1000 prot=0x5 flags=0x2 fd=\d+ errno=1 -> thu-lai-khong-exec:ok")

    def test_other_errors_are_not_masked(self):
        f = os.path.join(self.tmp, "normal.bin")
        open(f, "wb").write(os.urandom(8192))
        log = os.path.join(self.tmp, "other.log")
        v = self.run_host(f, preload=True, log=log)
        self.assertEqual(v["unmapped"], "-1")
        self.assertEqual(v["unmapped_errno"], "12", "ENOMEM phải giữ nguyên, không được báo thành công")
        self.assertIn("errno=12 -> khong-thu-lai", open(log).read())

    def test_normal_filesystem_behaves_identically_with_and_without_shim(self):
        f = os.path.join(self.tmp, "normal2.bin")
        open(f, "wb").write(os.urandom(8192))
        a = self.run_host(f, preload=False)
        log = os.path.join(self.tmp, "same.log")
        b = self.run_host(f, preload=True, log=log)
        self.assertEqual(a, b)
        self.assertNotIn("thu-lai-khong-exec", open(log).read(), "máy bình thường: không có lần thử lại nào")

    def test_works_without_log_variable(self):
        f = os.path.join(self.tmp, "normal3.bin")
        open(f, "wb").write(os.urandom(8192))
        v = self.run_host(f, preload=True)
        self.assertEqual(v["mprotect_RX"], "0")


def parse_elf(data):
    """Phân tích tối thiểu ELF64 little-endian: (e_type, e_machine, danh sách (p_type, p_flags), số DT_NEEDED, có BIND_NOW)."""
    assert data[:4] == b"\x7fELF" and data[4] == 2 and data[5] == 1
    e_type, e_machine = struct.unpack_from("<HH", data, 16)
    e_phoff, = struct.unpack_from("<Q", data, 32)
    e_phentsize, e_phnum = struct.unpack_from("<HH", data, 54)
    phs, dyn = [], None
    for i in range(e_phnum):
        p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = struct.unpack_from("<IIQQQQQQ", data, e_phoff + i * e_phentsize)
        phs.append((p_type, p_flags))
        if p_type == 2:
            dyn = (p_offset, p_filesz)
    needed = now = 0
    if dyn:
        for off in range(dyn[0], dyn[0] + dyn[1], 16):
            tag, val = struct.unpack_from("<qQ", data, off)
            if tag == 0:
                break
            if tag == 1:
                needed += 1
            if tag == 24 or (tag == 30 and val & 8) or (tag == 0x6ffffffb and val & 1):
                now = 1
    return e_type, e_machine, phs, needed, now


class TestShippedBinary(unittest.TestCase):
    def setUp(self):
        self.data = open(ASSET, "rb").read()

    def test_is_aarch64_shared_object_without_exec_stack_and_without_libc_dependency(self):
        e_type, e_machine, phs, needed, now = parse_elf(self.data)
        self.assertEqual(e_type, 3, "ET_DYN (thư viện dùng chung)")
        self.assertEqual(e_machine, 0xB7, "EM_AARCH64")
        stack = [f for t, f in phs if t == 0x6474e551]
        self.assertEqual(len(stack), 1, "phải có PT_GNU_STACK, nếu không glibc có thể đòi stack thực thi và bị SELinux chặn")
        self.assertEqual(stack[0] & 1, 0, "stack không được có quyền thực thi")
        self.assertEqual(needed, 0, "không kéo thêm thư viện nào (đã có sẵn trong tiến trình Box64)")
        self.assertEqual(now, 1, "nạp ràng buộc ngay (BIND_NOW) để khỏi giải biểu tượng lười bên trong bộ xử lý tín hiệu của Box64")

    def test_exports_and_env_variable_name(self):
        for sym in (b"mprotect\0", b"mmap\0", b"mmap64\0", b"PYEA_SHIM_LOG\0", b"__errno_location\0", b"syscall\0"):
            self.assertIn(sym, self.data, sym)

    def test_asset_is_in_sync_with_source(self):
        info = dict(l.split("=", 1) for l in open(os.path.join(SHIM_DIR, "BUILD_INFO.txt"), encoding="utf-8").read().splitlines() if "=" in l)
        self.assertEqual(info["nguon_sha256"], hashlib.sha256(open(SRC, "rb").read()).hexdigest(),
                         "sửa pyea_noexec.c thì phải chạy lại: sh tools/mt5_phone/shim/build_shim.sh (dựng lại .so và BUILD_INFO.txt)")
        self.assertEqual(info["asset_sha256"], hashlib.sha256(self.data).hexdigest(), "file .so đóng trong APK không khớp BUILD_INFO.txt")

    def test_asset_has_extension_the_apk_accepts_and_is_loaded_by_helper(self):
        spec = open(os.path.join(ROOT, "buildozer.spec"), encoding="utf-8").read()
        exts = re.search(r"^source\.include_exts\s*=\s*(.*)$", spec, re.M).group(1).split(",")
        self.assertIn(mt5ea.SHIM_ASSET.rsplit(".", 1)[1], [e.strip() for e in exts])
        self.assertEqual(mt5ea.shim_bytes(), self.data)

    def test_source_has_no_hardcoded_device_values(self):
        src = open(SRC, encoding="utf-8").read()
        for bad in ("S52", "Cat S", "Helio", "MediaTek", "0x7ffff", "Android 10", "4.9"):
            self.assertNotIn(bad, src, bad)


class TestExecProbe(unittest.TestCase):
    """Đoạn python3 trong install_mt5_termux.sh (hàm exec_probe) đo THẬT mmap/mprotect có PROT_EXEC. Trích đoạn đó ra chạy bằng python thật của máy test."""

    @classmethod
    def setUpClass(cls):
        text = open(os.path.join(ROOT, "tools", "mt5_phone", "install_mt5_termux.sh"), encoding="utf-8").read()
        m = re.search(r"<<'PY'[^\n]*\n(.*?)\nPY\n", text, re.S)
        assert m, "không thấy khối python của exec_probe"
        cls.tmp = tempfile.mkdtemp(prefix="pyea_probe_")
        cls.code = os.path.join(cls.tmp, "probe.py")
        open(cls.code, "w", encoding="utf-8").write(m.group(1) + "\n")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def probe(self, real, tmp):
        r = subprocess.run([sys.executable, "-I", self.code, real, tmp], capture_output=True, text=True, timeout=30)
        self.assertEqual(r.returncode, 0, r.stderr)
        return r.stdout.strip()

    def test_normal_filesystem_all_ok_and_one_line(self):
        real = os.path.join(self.tmp, "real.bin")
        open(real, "wb").write(os.urandom(8192))
        out = self.probe(real, os.path.join(self.tmp, "scratch.bin"))
        self.assertEqual(len(out.splitlines()), 1)
        self.assertIn("[file Wine] map_RX:ok R->RX:ok RW->RX:ok đã-ghi->RX:ok", out)
        self.assertIn("[file tạm] map_RX:ok R->RX:ok RW->RX:ok đã-ghi->RX:ok", out)
        self.assertIn("[bộ nhớ ẩn danh] RW->RX:ok RWX:ok", out)
        self.assertIn("[mount noexec]", out)
        self.assertIn("[selinux]", out)

    def test_noexec_mount_shows_which_calls_are_refused(self):
        d = os.path.join(self.tmp, "nx")
        os.makedirs(d)
        r = subprocess.run(["mount", "-t", "tmpfs", "-o", "noexec,size=4m", "tmpfs", d], capture_output=True, text=True)
        if r.returncode:
            self.skipTest("không mount được tmpfs noexec: %s" % r.stderr.strip())
        self.addCleanup(lambda: subprocess.run(["umount", d], capture_output=True))
        real = os.path.join(d, "real.bin")
        open(real, "wb").write(os.urandom(8192))
        out = self.probe(real, os.path.join(d, "scratch.bin"))
        self.assertIn("[file Wine] map_RX:EPERM R->RX:EACCES RW->RX:EACCES đã-ghi->RX:EACCES", out)
        self.assertIn("[file tạm] map_RX:EPERM", out)
        self.assertIn("[bộ nhớ ẩn danh] RW->RX:ok RWX:ok", out, "bộ nhớ ẩn danh vẫn cho phép: đúng phân biệt «chỉ vùng ánh xạ từ file bị chặn»")
        self.assertIn(d, out.split("[mount noexec]")[1], "liệt kê điểm mount noexec")

    def test_missing_files_are_reported_not_crashing(self):
        out = self.probe(os.path.join(self.tmp, "khong-co.bin"), "")
        self.assertIn("[file Wine] không-mở-được(ENOENT)", out)
        self.assertIn("[bộ nhớ ẩn danh]", out)


if __name__ == "__main__":
    unittest.main()
