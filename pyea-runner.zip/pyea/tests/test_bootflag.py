"""Tự chạy lại sau khi khởi động máy: cờ boot_resume.flag (logic), cài đặt, hook chèn <receiver> vào manifest và nội dung BootReceiver.java.
KHÔNG kiểm chứng được trên máy thật (khởi động lại máy, Android 15, ROM tuỳ biến)."""
import importlib.util
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, ROOT)

from pyea import bootflag                                    # noqa: E402
from pyea.accounts import ACCOUNT_DENY                       # noqa: E402
from pyea.ipc import ServiceClient, ServiceHost              # noqa: E402
from pyea.settings import GLOBAL_INPUTS, default_settings    # noqa: E402

spec = importlib.util.spec_from_file_location("p4a_hook", os.path.join(ROOT, "tools", "p4a_hook.py"))
hook = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hook)

TMPL = '<manifest>\n  <application android:label="x">\n    <service android:name="a"/>\n  </application>\n</manifest>\n'


class TestFlag(unittest.TestCase):
    def test_sync_creates_and_removes(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(bootflag.sync(d, True))
            self.assertTrue(os.path.exists(bootflag.path(d)))
            self.assertFalse(bootflag.sync(d, False))
            self.assertFalse(os.path.exists(bootflag.path(d)))
            self.assertFalse(bootflag.sync(d, False))                  # xoá lần nữa không lỗi

    def test_mirror_in_device_protected_dir_follows_main_flag(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as m:
            bootflag.sync(d, True, m)
            self.assertTrue(os.path.exists(bootflag.path(m)))
            bootflag.sync(d, False, m)
            self.assertFalse(os.path.exists(bootflag.path(m)))
            self.assertFalse(os.path.exists(bootflag.path(d)))

    def test_flag_content_follows_alert_setting_and_rewrites(self):
        with tempfile.TemporaryDirectory() as d:
            bootflag.sync(d, True, None, True)
            self.assertEqual(open(bootflag.path(d)).read(), "A")
            bootflag.sync(d, True, None, False)                          # đổi cài đặt khi cờ đã có -> ghi lại
            self.assertEqual(open(bootflag.path(d)).read(), "Q")

    def test_setting_boot_alert_global(self):
        self.assertIn("boot_alert", GLOBAL_INPUTS)
        self.assertIn("boot_alert", ACCOUNT_DENY)
        self.assertTrue(default_settings()["boot_alert"])

    def test_host_mirrors_flag(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as m:
            st = default_settings()
            ServiceClient(d).write_desired({"running": True, "config": {"settings": st, "instances": []}})
            h = ServiceHost(d, sleep=0.02, exit_grace=0.1, idle_exit=0.3, boot_mirror=m)
            h._watchdog_tick()
            self.assertTrue(os.path.exists(bootflag.path(m)))

    def test_unwritable_dir_does_not_raise(self):
        self.assertFalse(bootflag.sync("/nonexistent/zzz", True))


class TestHost(unittest.TestCase):
    def _desired(self, d, running=True, **kw):
        st = default_settings()
        st.update(kw)
        ServiceClient(d).write_desired({"running": running, "config": {"settings": st, "instances": []}})

    def host(self, d):
        return ServiceHost(d, sleep=0.02, exit_grace=0.1, idle_exit=0.3)

    def test_want_follows_desired_and_settings(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d)
            self.assertEqual(self.host(d)._boot_want(), (True, True))
            self._desired(d, running=False)
            self.assertFalse(self.host(d)._boot_want()[0])             # người dùng đã ngắt -> không tự bật lại
            self._desired(d, start_on_boot=False)
            self.assertFalse(self.host(d)._boot_want()[0])
            self._desired(d, auto_resume=False)
            self.assertFalse(self.host(d)._boot_want()[0])
            self._desired(d, boot_alert=False)
            self.assertEqual(self.host(d)._boot_want(), (True, False))

    def test_tick_writes_and_clears_flag(self):
        with tempfile.TemporaryDirectory() as d:
            self._desired(d)
            h = self.host(d)
            h._watchdog_tick()
            self.assertTrue(os.path.exists(bootflag.path(d)))
            self._desired(d, running=False)
            h._boot_next = 0.0
            h._watchdog_tick()
            self.assertFalse(os.path.exists(bootflag.path(d)))

    def test_setting_is_global_default_on(self):
        self.assertIn("start_on_boot", GLOBAL_INPUTS)
        self.assertIn("start_on_boot", ACCOUNT_DENY)
        self.assertTrue(default_settings()["start_on_boot"])


class TestHookAndJava(unittest.TestCase):
    def test_patch_inserts_once_inside_application(self):
        new, ch = hook.patch_manifest_text(TMPL)
        self.assertTrue(ch)
        self.assertLess(new.index("BootReceiver"), new.index("</application>"))
        self.assertIn("BOOT_COMPLETED", new)
        again, ch2 = hook.patch_manifest_text(new)
        self.assertFalse(ch2)
        self.assertEqual(again.count("BootReceiver"), 1)

    def test_patch_without_application_raises(self):
        with self.assertRaises(ValueError):
            hook.patch_manifest_text("<manifest/>")

    def test_hook_patches_template_in_dist(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "templates"))
            f = os.path.join(d, "templates", "AndroidManifest.tmpl.xml")
            open(f, "w").write(TMPL)
            tc = type("T", (), {"_dist": type("D", (), {"dist_dir": d})(), "ctx": None})()
            hook.before_apk_build(tc)
            self.assertIn("BootReceiver", open(f).read())

    def test_hook_fails_loudly_when_no_template(self):
        with tempfile.TemporaryDirectory() as d:
            tc = type("T", (), {"_dist": type("D", (), {"dist_dir": d})(), "ctx": None})()
            cwd = os.getcwd()
            os.chdir(d)
            try:
                with self.assertRaises(RuntimeError):
                    hook.before_apk_build(tc)
            finally:
                os.chdir(cwd)

    def test_java_and_spec_consistent(self):
        j = open(os.path.join(ROOT, "android_src", "org", "pyea", "pyearunner", "BootReceiver.java"), encoding="utf-8").read()
        self.assertIn("package org.pyea.pyearunner;", j)
        self.assertIn(bootflag.FLAG, j)
        self.assertIn("ACTION_BOOT_COMPLETED", j)
        self.assertIn("LOCKED_BOOT_COMPLETED", j)
        self.assertIn("USAGE_ALARM", j)
        self.assertIn("FLAG_INSISTENT", j)
        self.assertIn("CATEGORY_ALARM", j)
        self.assertIn("'Q'", j)
        self.assertIn("createDeviceProtectedStorageContext", j)
        self.assertIn("directBootAware", hook.RECEIVER)
        self.assertIn("LOCKED_BOOT_COMPLETED", hook.RECEIVER)
        s = open(os.path.join(ROOT, "buildozer.spec"), encoding="utf-8").read()
        self.assertIn("RECEIVE_BOOT_COMPLETED", s)
        self.assertIn("android.add_src = android_src", s)
        self.assertIn("p4a.hook = tools/p4a_hook.py", s)
        self.assertIn("package.domain = org.pyea", s)
        self.assertIn("package.name = pyearunner", s)


if __name__ == "__main__":
    unittest.main()
