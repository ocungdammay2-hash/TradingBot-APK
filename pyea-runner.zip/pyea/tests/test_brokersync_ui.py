"""Giao diện số liệu do SÀN báo (Kivy GIẢ - kiểm tra logic, không kiểm tra hiển thị thật):
khung «Giao dịch» như MT5 (Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ) đổi nhãn «SÀN»/«sổ app» và không bịa số khi sàn không báo,
dòng vị thế dùng lãi/lỗ + swap + hoa hồng + giá hiện tại của sàn, dải an toàn có lãi/lỗ thả nổi, và mục «Lịch sử từ sàn» (tải ở luồng nền, nói rõ khi chưa hỗ trợ)."""
import os
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub
kivy_stub.install()
import test_ui_smoke as T                                           # noqa: E402
from pyea import brokerhist as bh                                   # noqa: E402
from pyea.ui_widgets import fm, fp                                  # noqa: E402

ACCT = {"balance": 10000.0, "equity": 10098.0, "margin": 1100.2, "free_margin": 8997.8, "profit": 98.0, "margin_level": 917.8, "currency": "USC", "age": 3.0}


class TestBrokerSyncUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()
        del kivy_stub.SCHEDULED[:]

    def drive(self, app, cond, timeout=20.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.1)
        return False

    def connected(self):
        app = T.make_app()
        app.start_session()
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and "BTCUSD" in app.last_snap["watch"]))
        return app

    def run_scheduled(self):
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for f in fns:
            f(0)

    # ---------------------------------------------------------------------------------------------- khung Giao dịch
    def test_boxes_show_exchange_numbers_labelled_SAN_and_floating_profit(self):
        app = self.connected()
        snap = dict(app.last_snap, broker_account=dict(ACCT), broker_positions=None)
        app.trade_tab.update(snap)
        s = app.trade_tab.s
        self.assertEqual(s["balance"].t.text, "Số dư (SÀN, USC)")
        self.assertEqual(s["balance"].v.text, fp(10000.0))
        self.assertEqual(s["equity"].v.text, fp(10098.0))
        self.assertEqual(s["floating"].v.text, fm(98.0))
        self.assertEqual(s["margin"].v.text, fp(1100.2))
        self.assertEqual(s["free"].v.text, fp(8997.8))
        self.assertEqual(s["level"].v.text, "918%")
        self.assertIn("Ký quỹ còn dư", s["free"].t.text)
        self.assertIn("(SÀN", s["level"].t.text)
        self.assertIn("sổ app", s["pnl"].t.text)                         # tổng lãi/lỗ vẫn là sổ của app và NÓI RÕ như vậy
        self.assertIn("sổ app", s["winrate"].t.text)

    def test_boxes_fall_back_to_app_ledger_with_honest_label(self):
        app = self.connected()
        app.trade_tab.update(dict(app.last_snap, broker_account=None, broker_positions=None))
        s = app.trade_tab.s
        for k in ("balance", "equity", "floating", "margin", "free", "level"):
            self.assertIn("(sổ app)", s[k].t.text, k)
            self.assertNotIn("SÀN", s[k].t.text, k)
        self.assertEqual(s["balance"].v.text, fp(app.last_snap["balance"]))

    def test_missing_exchange_fields_show_dash_never_zero(self):
        app = self.connected()
        part = {"balance": 500.0, "equity": 500.0, "margin": 0.0, "free_margin": None, "profit": None, "margin_level": None, "currency": "", "age": 1.0}
        app.trade_tab.update(dict(app.last_snap, broker_account=part, broker_positions=None))
        s = app.trade_tab.s
        self.assertEqual(s["floating"].v.text, "-")
        self.assertEqual(s["free"].v.text, "-")
        self.assertEqual(s["level"].v.text, "-")
        self.assertEqual(s["balance"].t.text, "Số dư (SÀN)")             # không có tiền tệ thì không in dấu phẩy thừa
        self.assertEqual(s["balance"].v.text, fp(500.0))

    def test_low_margin_level_is_flagged_red_and_loss_is_red(self):
        from pyea.ui_widgets import DOWN, UP
        app = self.connected()
        bad = dict(ACCT, profit=-95376.37, margin_level=60.0, equity=4623.0)
        app.trade_tab.update(dict(app.last_snap, broker_account=bad, broker_positions=None))
        s = app.trade_tab.s
        self.assertEqual(s["floating"].v.color, DOWN)
        self.assertEqual(s["floating"].v.text, fm(-95376.37))
        self.assertEqual(s["level"].v.color, DOWN)                       # dưới 100%: gần margin call
        app.trade_tab.update(dict(app.last_snap, broker_account=ACCT, broker_positions=None))
        self.assertEqual(s["floating"].v.color, UP)

    def test_safety_bar_line_carries_currency_and_floating_profit(self):
        app = self.connected()
        bar = app.trade_tab.bar
        bar.update(dict(app.last_snap, broker_account=dict(ACCT), broker_positions=None))
        t = bar.l_bacct.text
        self.assertIn("SÀN (USC)", t)
        self.assertIn("Thả nổi", t)
        self.assertIn(fm(98.0), t)
        self.assertIn("Mức ký quỹ 918%", t)
        bar.update(dict(app.last_snap, broker_account=dict(ACCT, profit=None), broker_positions=None))
        self.assertNotIn("Thả nổi", bar.l_bacct.text)                    # sàn không báo thì không in số bịa

    # ---------------------------------------------------------------------------------------------- dòng vị thế
    def open_position(self, app):
        status, res = app.ctl.place_order("BTCUSD", "buy", 0.01)
        self.assertEqual(status, "ok")
        self.assertTrue(self.drive(app, lambda: app.last_snap["positions"] and len(app.trade_tab._rows) == len(app.last_snap["positions"])))
        return app.last_snap["positions"][0]

    def test_position_row_uses_exchange_profit_swap_commission_and_price(self):
        app = self.connected()
        pos = self.open_position(app)
        snap = dict(app.last_snap)
        pos.ref = "T-77"
        snap["broker_positions"] = {"T-77": {"profit": 123.45, "swap": -2.5, "commission": -0.7, "price": 1234.5}}
        app.trade_tab.update(snap)
        l1, l2, pl = app.trade_tab._rows[pos.id]
        self.assertEqual(pl.text, fm(123.45))                            # lãi/lỗ do SÀN tính, không phải Δgiá × lot của sổ app
        self.assertIn("swap", l2.text)
        self.assertIn(fm(-2.5), l2.text)
        self.assertIn("hoa hồng", l2.text)
        self.assertIn("sàn", l2.text)
        self.assertIn(" → %s" % fp(1234.5), l1.text)                     # «giá mở → giá hiện tại» như MT5

    def test_position_row_without_exchange_numbers_keeps_the_app_number_and_a_current_price(self):
        app = self.connected()
        pos = self.open_position(app)
        snap = dict(app.last_snap, broker_positions=None)
        pos.ref = "T-78"
        app.trade_tab.update(snap)
        l1, l2, pl = app.trade_tab._rows[pos.id]
        self.assertEqual(pl.text, fm(pos.profit))
        self.assertNotIn("sàn", l2.text)
        self.assertNotIn("swap", l2.text)
        self.assertIn(" → ", l1.text)                                    # có giá hiện tại từ tick đang theo dõi
        snap["broker_positions"] = {"T-79": {"profit": 5.0}}             # sàn báo vị thế khác, không phải ticket này -> không lẫn số
        app.trade_tab.update(snap)
        self.assertEqual(app.trade_tab._rows[pos.id][2].text, fm(pos.profit))

    def test_partial_exchange_fields_do_not_print_zero_swap_or_commission(self):
        app = self.connected()
        pos = self.open_position(app)
        pos.ref = "T-80"
        app.trade_tab.update(dict(app.last_snap, broker_positions={"T-80": {"profit": 7.0}}))
        l1, l2, pl = app.trade_tab._rows[pos.id]
        self.assertEqual(pl.text, fm(7.0))
        self.assertNotIn("swap", l2.text)
        self.assertNotIn("hoa hồng", l2.text)

    # ---------------------------------------------------------------------------------------------- Lịch sử từ sàn
    def fake_result(self):
        now = time.time()
        ds = [{"id": "b1", "time": now - 900, "kind": "balance", "profit": 1_250_000.0},
              {"id": "1", "time": now - 800, "kind": "trade", "symbol": "XAUUSD", "side": "buy", "qty": 0.5, "price": 2000.0, "entry": "IN", "position_id": "9"},
              {"id": "2", "time": now - 100, "kind": "trade", "symbol": "XAUUSD", "side": "sell", "qty": 0.5, "price": 2010.0, "entry": "OUT", "position_id": "9",
               "profit": 500.0, "commission": -3.5, "swap": -12.25}]
        return {"deals": ds, "summary": bh.summarize(ds), "positions": bh.positions_from_deals(ds)}

    def open_history(self, app):
        app.open_history_dialog()
        return kivy_stub.OPEN_POPUPS[-1]

    def test_history_notes_are_shown_and_warnings_are_amber(self):
        app = self.connected()
        res = dict(self.fake_result(), notes=["Hồ sơ lịch sử «X» (có sẵn trong app).", "CHÚ Ý: Không đọc được nguồn «income»: 401"])
        orig = bh.fetch_for_settings
        bh.fetch_for_settings = lambda st, since, until=None: res
        try:
            dlg = self.open_history(app)
            T.press(dlg.content, "7 ngày")
            self.wait_scheduled()
            self.run_scheduled()
        finally:
            bh.fetch_for_settings = orig
        blob = T.texts(dlg.content)
        self.assertIn("GHI CHÚ VỀ SỐ LIỆU", blob)
        self.assertIn("Hồ sơ lịch sử «X»", blob)
        warn = T.find(dlg.content, lambda x: "Không đọc được nguồn" in getattr(x, "text", ""))
        info = T.find(dlg.content, lambda x: "Hồ sơ lịch sử «X»" in getattr(x, "text", ""))
        self.assertTrue(warn and info)
        self.assertNotEqual(tuple(warn[0].color), tuple(info[0].color))

    def wait_scheduled(self, n=1, timeout=10.0):
        end = time.time() + timeout
        while time.time() < end and len(kivy_stub.SCHEDULED) < n:
            time.sleep(0.02)
        self.assertGreaterEqual(len(kivy_stub.SCHEDULED), n)

    def test_history_section_loads_in_background_and_shows_mt5_style_totals(self):
        app = self.connected()
        calls = []
        orig = bh.fetch_for_settings
        bh.fetch_for_settings = lambda st, since, until=None: (calls.append((since, until)), self.fake_result())[1]
        try:
            dlg = self.open_history(app)
            self.assertIn("LỊCH SỬ TỪ SÀN", T.texts(dlg.content))
            for _, label in ((0, "Hôm nay"), (0, "7 ngày"), (0, "30 ngày"), (0, "90 ngày")):
                self.assertTrue(T.find(dlg.content, lambda x, l=label: getattr(x, "text", None) == l), label)
            T.press(dlg.content, "7 ngày")
            self.assertIn("Đang tải", T.texts(dlg.content))                  # chưa trả về: báo đang tải, không treo giao diện
            self.wait_scheduled()
            self.run_scheduled()
        finally:
            bh.fetch_for_settings = orig
        blob = T.texts(dlg.content)
        self.assertIn("Lợi nhuận: 500.00", blob)
        self.assertIn("Tiền nạp: 1 250 000.00", blob)                       # nhóm nghìn bằng dấu cách như MT5
        self.assertIn("Phí qua đêm: -12.25", blob)
        self.assertIn("Phí trung gian: -3.50", blob)
        self.assertIn("Số dư: 1 250 484.25", blob)                          # 1250000 + 500 - 12.25 - 3.5
        self.assertIn("XAUUSD", blob)
        self.assertIn("1 vị thế đã đóng", blob)
        (since, until), = calls
        self.assertAlmostEqual(until - time.time(), 3600.0, delta=30.0)
        self.assertAlmostEqual(time.time() - since, 7 * 86400.0, delta=30.0)

    def test_today_period_starts_at_local_midnight(self):
        app = self.connected()
        calls = []
        orig = bh.fetch_for_settings
        bh.fetch_for_settings = lambda st, since, until=None: (calls.append(since), self.fake_result())[1]
        try:
            dlg = self.open_history(app)
            T.press(dlg.content, "Hôm nay")
            self.wait_scheduled()
        finally:
            bh.fetch_for_settings = orig
        lt = time.localtime(calls[0])
        self.assertEqual((lt.tm_hour, lt.tm_min, lt.tm_sec), (0, 0, 0))
        self.assertLessEqual(time.time() - calls[0], 86400.0 + 1)

    def test_unsupported_broker_and_paper_mode_say_so_instead_of_crashing(self):
        app = self.connected()                                               # mặc định là chế độ paper
        dlg = self.open_history(app)
        T.press(dlg.content, "30 ngày")
        self.wait_scheduled()
        self.run_scheduled()
        self.assertIn("giả lập", T.texts(dlg.content))
        # sàn live nhưng không có lịch sử đồng bộ
        orig = bh.fetch_for_settings

        def unsupported(st, since, until=None):
            raise NotImplementedError("Sàn/cầu nối này chưa có lịch sử đồng bộ từ sàn")
        bh.fetch_for_settings = unsupported
        try:
            T.press(dlg.content, "30 ngày")
            self.wait_scheduled()
            self.run_scheduled()
        finally:
            bh.fetch_for_settings = orig
        self.assertIn("chưa có lịch sử đồng bộ", T.texts(dlg.content))

    def test_network_error_is_reported_in_the_dialog(self):
        app = self.connected()
        orig = bh.fetch_for_settings

        def boom(st, since, until=None):
            raise RuntimeError("mất mạng")
        bh.fetch_for_settings = boom
        try:
            dlg = self.open_history(app)
            T.press(dlg.content, "90 ngày")
            self.wait_scheduled()
            self.run_scheduled()
        finally:
            bh.fetch_for_settings = orig
        self.assertIn("Không tải được lịch sử từ sàn: mất mạng", T.texts(dlg.content))

    def test_a_slow_old_answer_never_overwrites_a_newer_choice(self):
        import threading
        app = self.connected()
        gate = threading.Event()
        orig = bh.fetch_for_settings

        def fn(st, since, until=None):
            if time.time() - since > 29 * 86400:                           # kỳ 30 ngày: trả chậm
                gate.wait(5.0)
                res = self.fake_result()
                res["positions"] = [dict(res["positions"][0], symbol="OLDSYM")]
                return res
            return self.fake_result()
        bh.fetch_for_settings = fn
        try:
            dlg = self.open_history(app)
            T.press(dlg.content, "30 ngày")
            T.press(dlg.content, "7 ngày")
            self.wait_scheduled(1)
            self.run_scheduled()
            gate.set()
            self.wait_scheduled(1)
            self.run_scheduled()                                             # kết quả 30 ngày về muộn: bị bỏ
        finally:
            gate.set()
            bh.fetch_for_settings = orig
        blob = T.texts(dlg.content)
        self.assertIn("XAUUSD", blob)
        self.assertNotIn("OLDSYM", blob)


if __name__ == "__main__":
    unittest.main()


class TestHistoryFilters(TestBrokerSyncUI):
    """Bộ lọc kiểu MT5 trong hộp «Lịch sử & báo cáo»: kỳ, mã, chiều, kết quả, sắp xếp, 3 tab, tuỳ chọn khoảng ngày."""

    def load_7d(self, app, res):
        orig = bh.fetch_for_settings
        bh.fetch_for_settings = lambda st, since, until=None: (self._calls.append((since, until)), res)[1]
        self._orig = orig
        dlg = self.open_history(app)
        T.press(dlg.content, "7 ngày")
        self.wait_scheduled()
        self.run_scheduled()
        return dlg

    def setUp(self):
        super().setUp()
        self._calls = []

    def tearDown(self):
        if getattr(self, "_orig", None):
            bh.fetch_for_settings = self._orig
        super().tearDown()

    def two_position_result(self):
        now = time.time()
        ds = [{"id": "1", "time": now - 800, "kind": "trade", "symbol": "XAUUSD", "side": "buy", "qty": 0.5, "price": 2000.0, "entry": "IN", "position_id": "9", "order_id": "a"},
              {"id": "2", "time": now - 700, "kind": "trade", "symbol": "XAUUSD", "side": "sell", "qty": 0.5, "price": 2010.0, "entry": "OUT", "position_id": "9", "order_id": "b", "profit": 500.0},
              {"id": "3", "time": now - 600, "kind": "trade", "symbol": "EURUSD", "side": "sell", "qty": 1.0, "price": 1.1, "entry": "IN", "position_id": "10", "order_id": "c"},
              {"id": "4", "time": now - 500, "kind": "trade", "symbol": "EURUSD", "side": "buy", "qty": 1.0, "price": 1.12, "entry": "OUT", "position_id": "10", "order_id": "d", "profit": -200.0}]
        return {"deals": ds, "summary": bh.summarize(ds), "positions": bh.positions_from_deals(ds)}

    @staticmethod
    def pick(sp, text):
        """Đổi giá trị Spinner và kích bind(text=...) như Kivy thật (Kivy giả không tự gọi)."""
        sp.text = text
        for cb in sp._binds.get("text", []):
            cb(sp, text)

    def spinners(self, dlg):
        return [w for w in T.find(dlg.content, lambda x: hasattr(x, "values") and hasattr(x, "text"))]

    def test_tabs_and_filters_change_the_table(self):
        app = self.connected()
        dlg = self.load_7d(app, self.two_position_result())
        blob = T.texts(dlg.content)
        self.assertIn("Nguồn: sàn · 2 dòng", blob)
        for label in ("Vị thế", "Lệnh", "Giao dịch", "Tuỳ chọn", "180 ngày"):
            self.assertTrue(T.find(dlg.content, lambda x, l=label: getattr(x, "text", None) == l), label)
        T.press(dlg.content, "Giao dịch")
        self.assertIn("Nguồn: sàn · 4 dòng", T.texts(dlg.content))
        T.press(dlg.content, "Lệnh")
        self.assertIn("Lệnh = các lệnh ĐÃ KHỚP", T.texts(dlg.content))
        T.press(dlg.content, "Vị thế")
        sp = {tuple(s.values)[0]: s for s in self.spinners(dlg)}
        self.pick(sp["Mới nhất trước"], "Lãi nhiều nhất")
        self.pick(sp["Lãi + Lỗ"], "Chỉ lỗ")
        self.assertIn("Nguồn: sàn · 1 dòng · Lãi/lỗ: -200.00", T.texts(dlg.content))
        self.pick(sp["Lãi + Lỗ"], "Lãi + Lỗ")
        self.pick(sp["Tất cả mã"], "XAUUSD")
        self.assertIn("Nguồn: sàn · 1 dòng · Lãi/lỗ: 500.00", T.texts(dlg.content))

    def test_custom_range_validates_and_queries_that_window(self):
        app = self.connected()
        dlg = self.load_7d(app, self.two_position_result())
        self._calls.clear()
        ins = T.inputs_of(dlg.content)
        ins[0].text, ins[1].text = "2026-10-31", "2026-10-01"
        T.press(dlg.content, "Tuỳ chọn")
        self.assertIn("phải trước", T.texts(dlg.content))
        self.assertEqual(self._calls, [])
        ins[0].text, ins[1].text = "2026-10-01", "2026-10-31"
        T.press(dlg.content, "Tuỳ chọn")
        self.wait_scheduled(1)
        (since, until), = self._calls
        self.assertAlmostEqual(until - since, 31 * 86400.0, delta=3700)

    def test_paper_mode_filters_the_local_book(self):
        app = self.connected()
        dlg = self.open_history(app)
        self.assertIn("Nguồn: sổ app", T.texts(dlg.content))
