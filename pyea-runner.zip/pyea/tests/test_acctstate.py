"""Tài khoản do SÀN báo (Tài sản · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ) khác với sổ tự tính của app và phải được đọc/hiển thị riêng.

Kiểm: chuẩn hoá bí danh (không riêng sàn nào), vòng đọc ở luồng poll (chu kỳ, số cũ bị bỏ, lỗi -> giãn nhịp không sập, paper/tắt thì không gọi),
số của sàn ≠ số tự tính (contract size), đi tới snapshot + api.account_info(), và đủ credit/profit/margin_level qua MetaApi, cổng MT5 và EA relay."""
import os
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "gateway"))
sys.path.insert(0, HERE)

import test_protect_contract as tc                                             # noqa: E402
import test_gateway_protect as tg                                              # noqa: E402
from pyea import acctstate                                                     # noqa: E402
from pyea.broker import BrokerError                                            # noqa: E402


class TestNormalize(unittest.TestCase):
    def test_metatrader_style_gets_margin_level_and_profit_derived(self):
        n = acctstate.normalize({"balance": 1000.0, "equity": 1100.0, "margin": 200.0, "free_margin": 900.0, "leverage": 100, "currency": "USD", "hedging": True,
                                 "platform": "MT5"})
        self.assertEqual((n["balance"], n["equity"], n["margin"], n["free_margin"]), (1000.0, 1100.0, 200.0, 900.0))
        self.assertAlmostEqual(n["margin_level"], 550.0)                         # equity / margin × 100 (định nghĩa MT5)
        self.assertAlmostEqual(n["profit"], 100.0)                               # equity - balance - credit
        self.assertEqual(n["currency"], "USD")

    def test_credit_is_excluded_from_floating_profit(self):
        n = acctstate.normalize({"balance": 1000.0, "equity": 1150.0, "margin": 100.0, "credit": 100.0})
        self.assertAlmostEqual(n["profit"], 50.0)
        self.assertAlmostEqual(n["free_margin"], 1050.0)

    def test_aliases_of_other_naming_styles(self):
        n = acctstate.normalize({"balance": 500, "NAV": 480, "marginUsed": 50, "marginAvailable": 430, "unrealizedPL": -20, "accountCurrency": "EUR"})
        self.assertEqual((n["equity"], n["margin"], n["free_margin"], n["profit"], n["currency"]), (480.0, 50.0, 430.0, -20.0, "EUR"))
        n = acctstate.normalize({"balance": 500, "equity": 500, "used_margin": 25, "freeMargin": 475, "marginLevel": 2000})
        self.assertEqual((n["margin"], n["free_margin"], n["margin_level"]), (25.0, 475.0, 2000.0))     # giá trị sàn báo được ưu tiên hơn giá trị tính

    def test_missing_fields_stay_none_and_are_not_invented(self):
        n = acctstate.normalize({"balance": 100.0})
        self.assertEqual((n["equity"], n["margin"], n["free_margin"], n["margin_level"], n["profit"]), (None, None, None, None, None))

    def test_no_margin_means_no_margin_level(self):
        n = acctstate.normalize({"balance": 100.0, "equity": 100.0, "margin": 0.0})
        self.assertIsNone(n["margin_level"])
        self.assertEqual(n["free_margin"], 100.0)

    def test_garbage_is_rejected(self):
        for bad in (None, [], "x", {}, {"currency": "USD"}, {"balance": "n/a", "equity": float("nan")}):
            self.assertIsNone(acctstate.normalize(bad), bad)


class LiveBase:
    H = None

    @classmethod
    def setUpClass(cls):
        cls.h = cls.H()

    @classmethod
    def tearDownClass(cls):
        cls.h.close()

    def setUp(self):
        h = self.h
        h.reset()
        self.s = h.session(tempfile.mkdtemp(), native_sltp=False)
        self.s.settings["mode"] = "live"                                         # vòng đọc chỉ chạy ở live
        self.s.settings["account_state_interval"] = 15.0
        h.tick(self.s, h.P0)

    def test_exchange_numbers_differ_from_app_numbers_and_reach_snapshot_and_bot_api(self):
        h, s = self.h, self.s
        r = s.send_order(h.SYM, "buy", 0.10)
        self.assertTrue(r, r.message)
        h.exchange_price(1.1100)                                                 # +0.0100: sàn tính 0.0100 × 0.10 × 100000 = +100
        h.tick(s, 1.1100, 1001.0)
        s._check_account_state()
        ba = s.broker_account()
        self.assertIsNotNone(ba)
        self.assertAlmostEqual(ba["equity"] - ba["balance"], 100.0, delta=3.0)
        self.assertGreater(ba["margin"], 100.0)                                  # 0.10 lot × 100000 × giá / 100 ≈ 1100
        self.assertAlmostEqual(ba["margin_level"], ba["equity"] / ba["margin"] * 100.0, 3)
        app_floating = s.account.floating()
        self.assertLess(abs(app_floating), 1.0)                                  # sổ app: Δgiá × 0.10 ≈ 0.001 - KHÔNG phải số của sàn
        snap = s.snapshot()
        self.assertAlmostEqual(snap["broker_account"]["equity"], ba["equity"], 6)
        self.assertEqual(snap["equity"], s.account.equity())                     # số tự tính vẫn giữ nguyên, chỉ thêm khối số của sàn
        info = s.account_info()
        self.assertTrue(info.broker_synced)
        self.assertAlmostEqual(info.broker_equity, ba["equity"], 6)
        self.assertAlmostEqual(info.broker_margin, ba["margin"], 6)
        self.assertAlmostEqual(info.broker_free_margin, ba["free_margin"], 6)
        self.assertAlmostEqual(info.broker_margin_level, ba["margin_level"], 6)
        self.assertAlmostEqual(info.broker_profit, ba["profit"], 6)
        self.assertEqual(info.equity, s.account.equity())

    def test_value_is_dropped_when_stale_and_bot_is_told_it_is_unsynced(self):
        s = self.s
        s._check_account_state()
        self.assertTrue(s.account_info().broker_synced)
        s._bacct["t"] -= 1000.0                                                  # số cũ quá 4 chu kỳ: bỏ, không để bot quyết định theo số cũ
        self.assertIsNone(s.broker_account())
        info = s.account_info()
        self.assertEqual((info.broker_synced, info.broker_equity, info.broker_margin_level), (False, 0.0, 0.0))
        self.assertIsNone(s.snapshot()["broker_account"])

    def test_interval_zero_never_calls_the_exchange(self):
        s = self.s
        s.settings["account_state_interval"] = 0.0
        calls = []
        orig = s.broker.account_state
        s.broker.account_state = lambda: (calls.append(1), orig())[1]
        s._check_account_state()
        self.assertEqual(calls, [])
        self.assertIsNone(s.broker_account())

    def test_paper_mode_never_reads_the_exchange(self):
        s = self.s
        s.settings["mode"] = "paper"
        calls = []
        s.broker.account_state = lambda: calls.append(1) or {}
        s._check_account_state()
        self.assertEqual(calls, [])

    def test_respects_the_interval_between_reads(self):
        s = self.s
        calls = []
        orig = s.broker.account_state
        s.broker.account_state = lambda: (calls.append(1), orig())[1]
        s._check_account_state()
        s._check_account_state()
        s._check_account_state()
        self.assertEqual(len(calls), 1)
        s._bacct_next = 0.0
        s._check_account_state()
        self.assertEqual(len(calls), 2)

    def test_exchange_errors_back_off_warn_once_and_never_crash(self):
        s = self.s
        calls = []

        def boom():
            calls.append(1)
            raise BrokerError("sàn không trả lời")
        s.broker.account_state = boom
        for _ in range(5):
            s._check_account_state()                                             # không ném ngoại lệ
            s._bacct_next = s._bacct_next if s._bacct_next > time.time() else 0.0
        self.assertEqual(len(calls), 1)                                          # lần sau còn trong thời gian giãn nhịp
        self.assertGreater(s._bacct_next, time.time() + 25.0)                    # giãn nhịp gấp đôi chu kỳ trở lên
        warns = [x for x in s.get_logs(0) if "tài khoản từ sàn" in x[3]]
        self.assertEqual(len(warns), 1)
        self.assertIsNone(s.broker_account())
        self.assertFalse(s.account_info().broker_synced)

    def test_repeated_failures_warn_only_once_in_five_minutes(self):
        s = self.s

        def boom():
            raise BrokerError("sàn không trả lời")
        s.broker.account_state = boom
        for _ in range(6):
            s._bacct_next = 0.0                                                  # ép gọi lại mỗi vòng để thấy cảnh báo không lặp
            s._check_account_state()
        self.assertEqual(s._bacct_fail, 6)
        self.assertEqual(len([x for x in s.get_logs(0) if "tài khoản từ sàn" in x[3]]), 1)

    def test_recovery_after_error_resets_backoff(self):
        s = self.s
        good = s.broker.account_state

        def boom():
            raise BrokerError("x")
        s.broker.account_state = boom
        s._check_account_state()
        s.broker.account_state = good
        s._bacct_next = 0.0
        s._check_account_state()
        self.assertIsNotNone(s.broker_account())
        self.assertEqual(s._bacct_fail, 0)

    def test_useless_reply_is_treated_as_failure_not_as_zero_equity(self):
        s = self.s
        s.broker.account_state = lambda: {"currency": "USD"}
        s._check_account_state()
        self.assertIsNone(s.broker_account())
        self.assertEqual(s._bacct_fail, 1)

    def test_broker_without_account_state_is_silently_skipped(self):
        s = self.s
        s.broker.account_state = None
        del s.broker.account_state                                               # lớp có hàm: dựng broker giả không có hàm này
        class NoState:
            pass
        s.broker = NoState()
        s._check_account_state()
        self.assertIsNone(s.broker_account())


class TestLive_metaapi(LiveBase, unittest.TestCase):
    H = tc.MtH

    def test_marginlevel_and_credit_from_the_documented_fields(self):
        h, s = self.h, self.s
        s.send_order(h.SYM, "buy", 0.10)
        s._check_account_state()
        raw = s.broker.account_state()
        self.assertIn("margin_level", raw)                                       # MetatraderAccountInformation.marginLevel
        self.assertEqual(raw["credit"], 0.0)


class TestLive_gateway_mt5(LiveBase, unittest.TestCase):
    H = tg.GwMt5H

    def test_gateway_forwards_credit_profit_and_margin_level(self):
        h, s = self.h, self.s
        s.send_order(h.SYM, "buy", 0.10)
        h.exchange_price(1.1050)
        raw = s.broker.account_state()
        for k in ("credit", "profit", "margin_level"):
            self.assertIn(k, raw)
        self.assertGreater(raw["profit"], 40.0)


class TestLive_gateway_ea(LiveBase, unittest.TestCase):
    H = tg.GwEaH

    def test_ea_acct_line_carries_credit_and_old_ea_still_parses(self):
        h = self.h
        h.ea.caps = ""                                                           # EA bản cũ: ACCT 8 trường, không credit
        n = h.ea.polls
        tg.wait(lambda: h.ea.polls >= n + 3)
        self.assertNotIn("credit", h.be.state["account"])
        h.ea.caps = "sltp,posdeals,comment"
        n = h.ea.polls
        tg.wait(lambda: h.ea.polls >= n + 3)
        self.assertEqual(h.be.state["account"]["credit"], 0.0)
        self.assertIsNotNone(acctstate.normalize(self.s.broker.account_state()))


if __name__ == "__main__":
    unittest.main()
