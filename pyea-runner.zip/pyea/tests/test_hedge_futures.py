"""Binance Futures ở HEDGE MODE (dualSidePosition=true): theo tài liệu Binance, mọi lệnh phải kèm positionSide LONG/SHORT và KHÔNG được gửi reduceOnly
(New Order, New Algo Order). Sàn giả áp đúng luật này (-4061, -1106). One-way mode giữ nguyên hành vi cũ."""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeBinanceX                      # noqa: E402
import test_protect as tp                                    # noqa: E402

SYM = tp.SYM


def orders(fx):
    return [c[2] for c in fx.calls if c[0] == "POST" and c[1] == "/fapi/v1/order"]


class HedgeBase(unittest.TestCase):
    dual = True

    @classmethod
    def setUpClass(cls):
        cls.fx = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.fx.dual = self.dual
        self.s = tp.make(self.fx)
        tp.tk(self.s, 100.0)


class TestHedge(HedgeBase):
    def test_prepare_detects_hedge_instead_of_refusing(self):
        self.assertTrue(self.s.broker._hedge)

    def test_long_open_and_close_use_long_leg_without_reduce_only(self):
        r = self.s.send_order(SYM, "buy", 0.05)
        self.assertTrue(r, r.message)
        self.assertEqual(self.fx.fut["pos"], 0.05)
        c = self.s.close_position(r.position.id)
        self.assertTrue(c, c.message)
        self.assertEqual(self.fx.fut["pos"], 0.0)
        o = orders(self.fx)
        self.assertEqual([(x["side"], x["positionSide"]) for x in o], [("BUY", "LONG"), ("SELL", "LONG")])
        self.assertTrue(all("reduceOnly" not in x for x in o))

    def test_short_open_and_close_use_short_leg(self):
        r = self.s.send_order(SYM, "sell", 0.04)
        self.assertTrue(r, r.message)
        self.assertEqual(self.fx.fut["pos"], -0.04)
        self.assertTrue(self.s.close_position(r.position.id))
        o = orders(self.fx)
        self.assertEqual([(x["side"], x["positionSide"]) for x in o], [("SELL", "SHORT"), ("BUY", "SHORT")])
        self.assertEqual(self.fx.fut["pos"], 0.0)

    def test_positions_net_across_legs_and_short_is_negative(self):
        self.s.send_order(SYM, "sell", 0.04)
        pos = self.s.broker.positions()
        self.assertAlmostEqual(pos[SYM]["qty"], -0.04)
        self.fx.fut["pos"] = 0.0
        self.assertEqual(self.s.broker.positions(), {})

    def test_native_protection_has_position_side_and_no_reduce_only(self):
        p = self.s.send_order(SYM, "buy", 0.05, 95.0, 110.0).position
        tp.poll(self.s)
        live = tp.algos(self.fx)
        self.assertEqual({(a["orderType"], a["side"], a["positionSide"], a["reduceOnly"]) for a in live},
                         {("STOP_MARKET", "SELL", "LONG", "false"), ("TAKE_PROFIT_MARKET", "SELL", "LONG", "false")})
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        n = len(tp.posts(self.fx, "/algoOrder"))
        tp.poll(self.s)
        self.assertEqual(len(tp.posts(self.fx, "/algoOrder")), n)             # vẫn idempotent

    def test_short_protection_uses_short_leg(self):
        self.s.send_order(SYM, "sell", 0.04, 105.0, 90.0)
        tp.poll(self.s)
        self.assertEqual({(a["side"], a["positionSide"]) for a in tp.algos(self.fx)}, {("BUY", "SHORT")})

    def test_pending_orders_carry_position_side(self):
        nid = self.s.broker.place_pending(SYM, "buy", "limit", 0.01, 90.0)
        self.assertEqual(self.fx.fut["orders"][nid]["side"], "BUY")
        aid = self.s.broker.place_pending(SYM, "sell", "stop", 0.01, 80.0)
        self.assertEqual(self.fx.fut["algo"][aid[5:]]["positionSide"], "SHORT")


class TestOneWayUnchanged(HedgeBase):
    dual = False

    def test_one_way_still_uses_reduce_only_and_no_position_side(self):
        self.assertFalse(self.s.broker._hedge)
        r = self.s.send_order(SYM, "buy", 0.05, 95.0)
        self.s.close_position(r.position.id)
        o = orders(self.fx)
        self.assertTrue(all("positionSide" not in x for x in o))
        self.assertEqual(o[1].get("reduceOnly"), "true")
        tp.poll(self.s)


if __name__ == "__main__":
    unittest.main()
