"""Cache lịch sử + lấp khoảng trống, và đối soát vị thế giữa sổ app với sàn."""
import json, os, sys, tempfile, time, unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea.backtest import _ReplayFeed                                     # noqa: E402
from pyea.broker import BinanceFuturesBroker, BrokerError, Fill, OandaBroker      # noqa: E402
from pyea.datacache import HistoryCache, find_gaps, load_history, merge_candles   # noqa: E402
from pyea.engine import Account, TradingSession                           # noqa: E402
from pyea.feeds import tf_bucket                                          # noqa: E402
from pyea.sdk import Candle, Tick                                         # noqa: E402
from pyea.settings import default_settings                                # noqa: E402


def candles_ending(now, tf_s, n, skip=()):
    """n nến đóng + 1 nến đang hình thành, căn theo tf_s, bỏ các chỉ số trong skip (tạo lỗ)."""
    cur = int(now // tf_s) * tf_s
    out = []
    for i in range(n, -1, -1):
        if i in skip:
            continue
        t = cur - i * tf_s
        out.append(Candle(t, 100 + i * 0.1, 101 + i * 0.1, 99 + i * 0.1, 100.5 + i * 0.1, 5.0))
    return out


class FakeFeed:
    def __init__(self, tf_s=300, now=None, skip=()):
        self.tf_s, self.now, self.skip, self.calls = tf_s, now or time.time(), skip, []

    def history(self, symbol, tf, n, end=None):
        self.calls.append(n)
        return candles_ending(self.now, self.tf_s, n, self.skip)[-n:]

    def tick(self, symbol):
        return Tick(symbol, self.now, 100.0, 100.1)


class TestHistoryCache(unittest.TestCase):
    def test_merge_and_gaps(self):
        a = [Candle(0, 1, 1, 1, 1), Candle(300, 1, 1, 1, 1)]
        b = [Candle(300, 9, 9, 9, 9), Candle(600, 2, 2, 2, 2)]
        m = merge_candles(a, b)
        self.assertEqual([c.time for c in m], [0, 300, 600])
        self.assertEqual(m[1].close, 9)                                     # bản mới thắng
        cs = [Candle(t, 1, 1, 1, 1) for t in (0, 300, 900, 1200)]
        self.assertEqual(find_gaps(cs, "5m"), [(300, 900, 1)])
        wk = [Candle(0, 1, 1, 1, 1), Candle(3 * 86400, 1, 1, 1, 1)]          # nghỉ 3 ngày
        self.assertEqual(find_gaps(wk, "1h", "oanda"), [])                  # forex được nghỉ cuối tuần
        self.assertEqual(len(find_gaps(wk, "1h", "binance")), 1)            # crypto 24/7 thì là lỗ
        self.assertEqual(find_gaps([Candle(0, 1, 1, 1, 1), Candle(7 * 86400, 1, 1, 1, 1)], "1h", "oanda")[0][2], 167)

    def test_cache_roundtrip_corrupt_and_clear(self):
        with tempfile.TemporaryDirectory() as d:
            c = HistoryCache(d)
            cs = candles_ending(1_700_000_000, 300, 5)
            self.assertTrue(c.save("binance", "BTC/USDT", "5m", cs))
            self.assertEqual(c.load("binance", "BTC/USDT", "5m"), cs)
            self.assertEqual(c.load("binance", "BTC/USDT", "1h"), [])
            with open(c.path("binance", "BTC/USDT", "5m"), "w") as f:
                f.write("{hỏng")
            self.assertEqual(c.load("binance", "BTC/USDT", "5m"), [])        # cache hỏng không làm sập
            c.save("a", "b", "5m", cs)
            self.assertGreaterEqual(c.clear(), 1)

    def test_load_history_fetches_only_the_missing_tail(self):
        with tempfile.TemporaryDirectory() as d:
            cache = HistoryCache(d)
            now = 1_700_000_100.0
            f1 = FakeFeed(300, now)
            hist, info = load_history(f1, cache, "binance", "BTCUSDT", "5m", 200, now)
            self.assertEqual(f1.calls, [200])
            self.assertEqual((info["cache_hit"], info["gaps"]), (False, 0))
            saved = cache.load("binance", "BTCUSDT", "5m")
            self.assertTrue(saved and saved[-1].time < tf_bucket("5m", now))       # không lưu nến đang hình thành
            # 7 nến sau: chỉ tải phần thiếu
            now2 = now + 7 * 300
            f2 = FakeFeed(300, now2)
            hist2, info2 = load_history(f2, cache, "binance", "BTCUSDT", "5m", 200, now2)
            self.assertTrue(info2["cache_hit"])
            self.assertEqual(len(f2.calls), 1)
            self.assertLess(f2.calls[0], 20)                                        # ít hơn nhiều so với 200
            self.assertEqual(info2["gaps"], 0)
            self.assertEqual(len(hist2), 200)
            self.assertEqual(hist2[-1].time, tf_bucket("5m", now2))

    def test_gap_in_cache_triggers_full_refetch_and_is_healed(self):
        with tempfile.TemporaryDirectory() as d:
            cache = HistoryCache(d)
            now = 1_700_000_100.0
            good = [c for c in candles_ending(now, 300, 200) if c.time < tf_bucket("5m", now)]
            holed = good[:100] + good[110:]                                         # thủng 10 nến trong cache
            cache.save("binance", "BTCUSDT", "5m", holed)
            f = FakeFeed(300, now + 300)
            hist, info = load_history(f, cache, "binance", "BTCUSDT", "5m", 200, now + 300)
            self.assertTrue(info["refetched"])
            self.assertEqual(len(f.calls), 2)                                       # tải phần thiếu + tải lại đủ
            self.assertEqual(info["gaps"], 0)                                       # đã lấp
            self.assertEqual(len({c.time for c in hist}), len(hist))

    def test_gaps_that_the_source_itself_has_are_reported(self):
        with tempfile.TemporaryDirectory() as d:
            now = 1_700_000_100.0
            f = FakeFeed(300, now, skip=(50, 49, 48))
            hist, info = load_history(f, HistoryCache(d), "binance", "X", "5m", 100, now)
            self.assertEqual(info["gaps"], 1)
            self.assertEqual(info["gap_candles"], 3)

    def test_corrupt_cache_falls_back_to_full_download(self):
        with tempfile.TemporaryDirectory() as d:
            cache = HistoryCache(d)
            with open(cache.path("binance", "X", "5m"), "w") as fh:
                fh.write("rác")
            f = FakeFeed(300, 1_700_000_100.0)
            hist, info = load_history(f, cache, "binance", "X", "5m", 50, 1_700_000_100.0)
            self.assertEqual((f.calls, info["cache_hit"], len(hist)), ([50], False, 50))

    def test_session_get_builder_uses_cache_on_restart(self):
        with tempfile.TemporaryDirectory() as d:
            st = default_settings()
            st.update(exchange="binance", mode="paper", history_bars=150, tick_interval=1.0, max_loss_pct=0.0)
            sf = os.path.join(d, "state.json")
            feed = FakeFeed(300)
            s1 = TradingSession(st, state_file=sf, feed=feed)
            b = s1.get_builder("BTCUSDT", "5m")
            self.assertEqual(feed.calls, [150])
            self.assertTrue(os.path.isdir(os.path.join(d, "cache")))
            self.assertTrue(any("Lịch sử BTCUSDT 5m" in l[3] for l in s1.logs))
            feed2 = FakeFeed(300)
            s2 = TradingSession(st, state_file=sf, feed=feed2)                      # "khởi động lại"
            b2 = s2.get_builder("BTCUSDT", "5m")
            self.assertEqual(len(feed2.calls), 1)
            self.assertLessEqual(feed2.calls[0], 5)                                 # chỉ tải vài nến mới
            self.assertEqual(len(b2.closed), len(b.closed))


def make(**over):
    st = default_settings()
    st.update(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0)
    st.update(over)
    alarms = []
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), alarm_cb=lambda t, x: alarms.append(t))
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = ["BTCUSDT"]                      # mã app đang theo dõi (phạm vi đối soát mặc định = các mã app dùng)
    s.alarms = alarms
    return s


class FakeBroker:
    supports_short, netting = True, True

    def __init__(self, remote=None, fail=False):
        self.remote, self.fail, self.calls = remote if remote is not None else {}, fail, 0

    def positions(self):
        self.calls += 1
        if self.fail:
            raise BrokerError("mạng lỗi")
        return self.remote

    def market_order(self, sym, side, qty, reduce_only=False):
        return Fill(100.0, qty)


def tk(s, sym="BTCUSDT", px=100.0, t=1000.0):
    s.process_tick(Tick(sym, t, px, px))


def adopt_now(s):
    """adopt chỉ sửa sổ khi cùng chênh lệch được thấy ở HAI lần đối soát cách nhau >= CONFIRM_S: lần 1 chờ, lùi giờ chờ, lần 2 sửa."""
    first = s.reconcile_now()
    for k in list(s._recon_pending):
        s._recon_pending[k] -= 60.0
    return s.reconcile_now() if first else first


class TestReconcile(unittest.TestCase):
    def test_orphan_ghost_mismatch_alert_only(self):
        s = make(reconcile_policy="alert")
        tk(s)
        s.broker = FakeBroker({"BTCUSDT": {"qty": 0.5, "price": 99.0}})
        issues = s.reconcile_now()
        self.assertEqual([(i["kind"], i["remote"], i["local"]) for i in issues], [("orphan", 0.5, 0.0)])
        self.assertIs(s.recon["ok"], False)
        self.assertEqual(len(s.account.positions), 0)                            # alert: KHÔNG tự sửa sổ
        self.assertEqual(len(s.alarms), 1)
        s.reconcile_now()
        self.assertEqual(len(s.alarms), 1)                                       # cùng lệch -> không báo động lặp
        s.broker.remote = {"BTCUSDT": {"qty": 0.5, "price": 99.0}}
        s.send_order("BTCUSDT", "buy", 0.5)
        self.assertEqual(s.reconcile_now(), [])                                  # khớp
        self.assertIs(s.recon["ok"], True)
        s.broker.remote = {}                                                     # sàn không còn
        self.assertEqual([i["kind"] for i in s.reconcile_now()], ["ghost"])
        s.broker.remote = {"BTCUSDT": {"qty": 0.8, "price": 99.0}}
        self.assertEqual([i["kind"] for i in s.reconcile_now()], ["mismatch"])
        s.broker.remote = {"BTCUSDT": {"qty": -0.5, "price": 99.0}}              # ngược chiều
        self.assertEqual([i["kind"] for i in s.reconcile_now()], ["mismatch"])

    def test_tolerance_uses_volume_step(self):
        s = make(volume_step=0.01)
        tk(s)
        s.send_order("BTCUSDT", "buy", 0.50)
        s.broker = FakeBroker({"BTCUSDT": {"qty": 0.504, "price": 100.0}})       # lệch nhỏ hơn nửa step
        self.assertEqual(s.reconcile_now(), [])
        s.broker.remote = {"BTCUSDT": {"qty": 0.52, "price": 100.0}}
        self.assertEqual(len(s.reconcile_now()), 1)

    def test_adopt_policy_makes_book_follow_exchange(self):
        s = make(reconcile_policy="adopt")
        tk(s)
        s.broker = FakeBroker({"BTCUSDT": {"qty": -0.7, "price": 101.5}})
        s.reconcile_now()
        self.assertEqual(len(s.account.positions), 0)                            # lần thấy đầu tiên: CHỜ xác nhận, chưa sửa sổ
        adopt_now(s)                                                             # orphan -> nhận vị thế bán 0.7
        pos = list(s.account.positions.values())
        self.assertEqual((len(pos), pos[0].side, pos[0].volume, pos[0].open_price, pos[0].owner), (1, "sell", 0.7, 101.5, "manual"))
        self.assertTrue(any(e.kind == "open" and "đối soát" in e.reason.lower() for e in s.events))
        s.broker.remote = {}                                                     # ghost -> đóng sổ
        adopt_now(s)
        self.assertEqual(len(s.account.positions), 0)
        self.assertEqual(s.account.trades[-1].reason, "Đối soát")
        s.broker.remote = {"BTCUSDT": {"qty": 1.0, "price": 100.0}}              # mismatch -> thay bằng sự thật của sàn
        s.send_order("BTCUSDT", "buy", 0.4)
        adopt_now(s)
        self.assertEqual(sorted((p.side, round(p.volume, 9), p.owner) for p in s.account.positions.values()), [("buy", 0.4, "manual"), ("buy", 0.6, "manual")])
        self.assertEqual(s.reconcile_now(), [])                                  # hội tụ: vị thế 0.4 của app GIỮ NGUYÊN, chỉ nhập thêm phần 0.6 sàn có

    def test_scope_app_vs_all(self):
        s = make()
        tk(s)
        s.broker = FakeBroker({"ETHUSDT": {"qty": 2.0, "price": 10.0}})          # mã app không dùng (bạn tự vào trên app sàn)
        self.assertEqual(s.reconcile_now(), [])
        s.settings["reconcile_scope"] = "all"
        self.assertEqual([i["symbol"] for i in s.reconcile_now()], ["ETHUSDT"])

    def test_unsupported_error_off_and_interval(self):
        s = make()
        tk(s)
        s.broker = FakeBroker(None)
        s.broker.positions = lambda: None                                        # spot: không hỗ trợ
        self.assertEqual(s.reconcile_now(), [])
        self.assertFalse(s.recon["supported"])
        b = FakeBroker(fail=True)
        s.broker = b
        self.assertEqual(s.reconcile_now(), [])
        self.assertIsNone(s.recon["ok"])
        self.assertIn("mạng lỗi", s.recon["issues"][0])
        b2 = FakeBroker({})
        s.broker = b2
        s.settings["reconcile_interval"] = 60.0
        s._check_reconcile()
        s._check_reconcile()
        self.assertEqual(b2.calls, 1)                                            # chưa tới hạn lần sau
        s.settings["reconcile_policy"] = "off"
        s._recon_next = 0
        s._check_reconcile()
        self.assertEqual(b2.calls, 1)
        s.settings["reconcile_policy"] = "alert"
        s.settings["reconcile_interval"] = 0
        s._check_reconcile()
        self.assertEqual(b2.calls, 1)

    def test_order_failure_schedules_early_reconcile_and_snapshot_exposes_it(self):
        s = make()
        tk(s)

        class Failing(FakeBroker):
            def market_order(self, *a, **k):
                raise BrokerError("timeout")
        s.broker = Failing({})
        s._recon_next = time.time() + 3600
        r = s.send_order("BTCUSDT", "buy", 0.1)
        self.assertEqual(r.retcode, "REJECTED")
        self.assertLess(s._recon_next - time.time(), 5)                          # sẽ đối chiếu với sàn ngay sau đó
        snap = s.snapshot()
        self.assertIn("reconcile", snap)
        self.assertEqual(set(["last", "ok", "issues", "supported", "policy"]) - set(snap["reconcile"]), set())


class TestBrokerPositions(unittest.TestCase):
    def test_futures_positions_parse_and_fallback(self):
        b = BinanceFuturesBroker("k", "s", "http://x")
        calls = []

        def signed(m, path, p):
            calls.append(path)
            if path.endswith("v2/positionRisk"):
                raise BrokerError("404")
            return [{"symbol": "BTCUSDT", "positionAmt": "-0.250", "entryPrice": "60000.5"},
                    {"symbol": "ETHUSDT", "positionAmt": "0.000", "entryPrice": "0"},
                    {"symbol": "XRPUSDT", "positionAmt": "100", "entryPrice": "0.5"}, {"symbol": "BAD"}]
        b._signed = signed
        r = b.positions()
        self.assertEqual(calls, ["/fapi/v2/positionRisk", "/fapi/v3/positionRisk"])
        self.assertEqual(r, {"BTCUSDT": {"qty": -0.25, "price": 60000.5}, "XRPUSDT": {"qty": 100.0, "price": 0.5}})
        b._signed = lambda m, p, q: (_ for _ in ()).throw(BrokerError("hỏng"))
        with self.assertRaises(BrokerError):
            b.positions()

    def test_oanda_positions_net_units(self):
        b = OandaBroker("t", "101-1", "http://x")
        b._call = lambda m, path, body=None: {"positions": [
            {"instrument": "EUR_USD", "long": {"units": "1500", "averagePrice": "1.0850"}, "short": {"units": "0"}},
            {"instrument": "USD_JPY", "long": {"units": "0"}, "short": {"units": "-2000", "averagePrice": "150.2"}},
            {"instrument": "GBP_USD", "long": {"units": "0"}, "short": {"units": "0"}}, {"junk": 1}]}
        self.assertEqual(b.positions(), {"EUR_USD": {"qty": 1500.0, "price": 1.085}, "USD_JPY": {"qty": -2000.0, "price": 150.2}})


if __name__ == "__main__":
    unittest.main()
