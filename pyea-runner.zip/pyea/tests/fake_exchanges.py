"""Sàn GIẢ có trạng thái (Binance Spot + Futures, OANDA) cho test lệnh chờ native, lịch sử, số dư, đối soát."""
import hashlib
import hmac
import json
import re
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def synth_candles(step, n, end, price):
    """n nến (tăng dần) có giờ MỞ < end (epoch giây); giá quanh `price` - đủ để kiểm tra hình dạng/phân trang/tính nhất quán với tick."""
    last = int((end - 1e-6) // step) * step
    out = []
    for i in range(n):
        t = last - (n - 1 - i) * step
        base = price + ((t // step) % 5) * price * 0.0001
        out.append((t, base, base + price * 0.0005, base - price * 0.0005, base + price * 0.0001))
    return out


COND_TYPES = ("STOP_MARKET", "TAKE_PROFIT_MARKET", "STOP", "TAKE_PROFIT", "TRAILING_STOP_MARKET")     # Futures: bắt buộc qua /fapi/v1/algoOrder


class _Srv:
    def start(self, handler_factory):
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), handler_factory)
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


class FakeBinanceX(_Srv):
    KEY, SECRET = "key123", b"sekret"

    def __init__(self):
        self.lock = threading.RLock()
        self.price = 100.0
        self.reset()
        self.start(self._factory())

    def reset(self):
        with self.lock:
            self.spot = {"orders": {}, "trades": [], "bal": {"USDT": 5000.0, "BTC": 0.0}, "n": 1000, "lists": {}, "ln": 700}
            self.fut = {"orders": {}, "trades": [], "pos": 0.0, "entry": 0.0, "n": 5000, "wallet": 5000.0, "algo": {}, "an": 9000, "income": []}
            self.calls = []
            self.fee_rate = 0.001
            self.can_trade = True
            self.margin_type = "cross"
            self.income_fail = False

    # ---- điều khiển từ test ----
    def fill(self, kind, oid, price=None):
        """Khớp lệnh chờ `oid` tại `price` (mặc định = giá lệnh)."""
        with self.lock:
            st = self.spot if kind == "spot" else self.fut
            o = st["orders"][str(oid)]
            px = float(price if price is not None else (o.get("price") or o.get("stopPrice")))
            self._execute(kind, o, px)
            o["status"] = "FILLED"

    def fill_algo(self, aid, price=None):
        """Mô phỏng lệnh điều kiện (Algo Order) bị kích hoạt và khớp: sinh một lệnh MARKET thật, algoStatus -> FINISHED."""
        with self.lock:
            a = self.fut["algo"][str(aid)]
            px = float(price if price is not None else a["triggerPrice"])
            self.fut["n"] += 1
            o = {"orderId": self.fut["n"], "symbol": a["symbol"], "side": a["side"], "type": "MARKET", "origQty": a["quantity"], "status": "NEW"}
            self._execute("fut", o, px)
            o["status"] = "FILLED"
            self.fut["orders"][str(o["orderId"])] = o
            a.update(algoStatus="FINISHED", actualOrderId=str(o["orderId"]), actualPrice="%.2f" % px)

    def external_trade(self, kind, side, qty, price):
        """Lệnh thị trường do NGƯỜI DÙNG tự bấm trên app của sàn (hoặc thanh lý): khớp thật, có trong lịch sử, nhưng app không biết."""
        with self.lock:
            st = self.spot if kind == "spot" else self.fut
            st["n"] += 1
            o = {"orderId": st["n"], "symbol": "BTCUSDT", "side": side.upper(), "type": "MARKET", "origQty": "%.8g" % qty, "status": "NEW"}
            self._execute(kind, o, float(price))
            o["status"] = "FILLED"
            st["orders"][str(o["orderId"])] = o
            return o["orderId"]

    def add_fut_trade(self, symbol, side, qty, price, t, pnl=0.0, fee=0.0, asset="USDT", position_side="BOTH"):
        """Thêm MỘT lần khớp Futures vào lịch sử (t = epoch giây): dùng cho test lịch sử, không đổi vị thế/số dư."""
        with self.lock:
            st = self.fut
            st["n"] += 1
            st["trades"].append({"id": st["n"], "orderId": st["n"] + 100000, "price": "%.2f" % price, "qty": "%.6g" % qty, "time": int(t * 1000), "symbol": symbol,
                                 "side": side.upper(), "commission": "%.6f" % fee, "commissionAsset": asset, "realizedPnl": "%.6f" % pnl, "positionSide": position_side})

    def add_income(self, income_type, amount, t, symbol="", asset="USDT"):
        with self.lock:
            self.fut["an"] += 1
            self.fut["income"].append({"symbol": symbol, "incomeType": income_type, "income": "%.8f" % amount, "asset": asset, "time": int(t * 1000),
                                       "tranId": self.fut["an"], "tradeId": ""})

    def locked_base(self):
        """Coin cơ sở bị KHOÁ bởi lệnh BÁN đang chờ (Spot): lệnh đơn khoá origQty; MỘT cặp OCO khoá origQty đúng MỘT lần."""
        with self.lock:
            st = self.spot
            tot = sum(float(o["origQty"]) for o in st["orders"].values()
                      if o["status"] == "NEW" and o["side"] == "SELL" and o.get("orderListId", -1) < 0)
            for lst in st["lists"].values():
                if lst["status"] == "EXECUTING":
                    tot += lst["qty"]
            return tot

    def fill_oco(self, list_id, leg, price=None):
        """Chân `leg` ("sl" = STOP_LOSS, "tp" = LIMIT_MAKER) của cặp OCO khớp tại `price` (mặc định: giá của chân); chân kia -> EXPIRED, cặp -> ALL_DONE."""
        with self.lock:
            lst = self.spot["lists"][int(list_id)]
            o = self.spot["orders"][str(lst["legs"][leg])]
            px = float(price if price is not None else (o.get("stopPrice") if leg == "sl" else o.get("price")))
            lst["status"] = "ALL_DONE"                                  # trước _execute: số dư kiểm tra sau khi cặp đã đóng
            self._execute("spot", o, px)
            o["status"] = "FILLED"
            for k, oid in lst["legs"].items():
                if k != leg:
                    self.spot["orders"][str(oid)]["status"] = "EXPIRED"

    def external_cancel_oco(self, list_id):
        with self.lock:
            lst = self.spot["lists"][int(list_id)]
            lst["status"] = "ALL_DONE"
            for oid in lst["legs"].values():
                self.spot["orders"][str(oid)]["status"] = "CANCELED"

    def expire(self, kind, oid):
        with self.lock:
            st = self.spot if kind == "spot" else self.fut
            st["orders"][str(oid)]["status"] = "EXPIRED"

    def external_cancel(self, kind, oid):
        with self.lock:
            st = self.spot if kind == "spot" else self.fut
            st["orders"][str(oid)]["status"] = "CANCELED"

    def _execute(self, kind, o, px):
        q = float(o["origQty"])
        o["executedQty"] = o["origQty"]
        o["px"] = px
        side = o["side"]
        st = self.spot if kind == "spot" else self.fut
        tr = {"id": len(st["trades"]) + 1, "orderId": o["orderId"], "price": "%.2f" % px, "qty": o["origQty"], "time": int(time.time() * 1000),
              "symbol": o["symbol"]}
        if kind == "spot":
            fee = q * self.fee_rate if side == "BUY" else 0.0
            tr.update(isBuyer=side == "BUY", commission="%.8f" % fee, commissionAsset="BTC" if side == "BUY" else "USDT")
            st["bal"]["BTC"] += q - fee if side == "BUY" else -q
            st["bal"]["USDT"] += -q * px if side == "BUY" else q * px
        else:
            tr.update(side=side, commission="%.6f" % (q * px * 0.0004), commissionAsset="USDT", realizedPnl="0")
            signed = q if side == "BUY" else -q
            st["entry"] = px if st["pos"] == 0 else st["entry"]
            st["pos"] += signed
        st["trades"].append(tr)

    # ---- HTTP ----
    def _factory(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _h(self, method):
                u = urllib.parse.urlparse(self.path)
                qs = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                p = u.path
                kind = "fut" if p.startswith("/fapi") else "spot"
                st = fake.fut if kind == "fut" else fake.spot
                with fake.lock:
                    fake.calls.append((method, p, dict(qs)))
                if p.endswith("/time"):
                    return self._send({"serverTime": int(time.time() * 1000)})
                if p.endswith("/ticker/price"):
                    return self._send([{"symbol": "BTCUSDT", "price": "%.2f" % fake.price}, {"symbol": "ETHUSDT", "price": "50.00"}])
                if p.endswith("/ticker/bookTicker"):
                    return self._send({"symbol": qs.get("symbol"), "bidPrice": "%.2f" % (fake.price - 0.01), "askPrice": "%.2f" % (fake.price + 0.01)})
                if p.endswith("/klines"):
                    step = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "2h": 7200, "4h": 14400, "1d": 86400}[qs["interval"]]
                    end = (int(qs["endTime"]) + 1) / 1000.0 if "endTime" in qs else time.time() + 1
                    return self._send([[int(t * 1000), "%.2f" % o, "%.2f" % h, "%.2f" % l, "%.2f" % c, "1.0", int(t * 1000) + step * 1000 - 1]
                                       for t, o, h, l, c in synth_candles(step, min(int(qs.get("limit", 500)), 1000), end, fake.price)])
                if p.endswith("/exchangeInfo"):
                    filt = [{"filterType": "LOT_SIZE", "stepSize": "0.001", "minQty": "0.001"},
                            {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001", "minQty": "0.001"},
                            {"filterType": "PRICE_FILTER", "tickSize": "0.01"}]
                    return self._send({"symbols": [{"symbol": "BTCUSDT", "baseAsset": "BTC", "quoteAsset": "USDT", "filters": filt}]})
                # có chữ ký
                raw = u.query
                if "signature=" not in raw:
                    return self._send({"code": -1022, "msg": "no signature"}, 400)
                base, sig = raw.rsplit("&signature=", 1)
                good = hmac.new(fake.SECRET, base.encode(), hashlib.sha256).hexdigest()
                if good != sig or self.headers.get("X-MBX-APIKEY") != fake.KEY:
                    return self._send({"code": -1022, "msg": "bad signature"}, 400)
                with fake.lock:
                    return self._signed(method, p, qs, kind, st)

            def _signed(self, method, p, qs, kind, st):
                if p in ("/fapi/v2/account", "/fapi/v3/account"):
                    return self._send({"canTrade": fake.can_trade, "totalWalletBalance": "%.2f" % st["wallet"]})
                if p == "/api/v3/account":
                    lk = fake.locked_base()
                    return self._send({"canTrade": fake.can_trade, "balances": [
                        {"asset": a, "free": "%.8f" % (v - (lk if a == "BTC" else 0.0)), "locked": "%.8f" % (lk if a == "BTC" else 0.0)} for a, v in st["bal"].items()]})
                if p in ("/fapi/v2/balance", "/fapi/v3/balance"):
                    return self._send([{"asset": "USDT", "balance": "%.2f" % st["wallet"], "availableBalance": "%.2f" % (st["wallet"] - 10)}])
                if p in ("/fapi/v2/positionRisk", "/fapi/v3/positionRisk"):
                    return self._send([{"symbol": "BTCUSDT", "positionAmt": "%.3f" % st["pos"], "entryPrice": "%.2f" % st["entry"], "marginType": fake.margin_type}])
                if p == "/fapi/v1/positionSide/dual":
                    return self._send({"dualSidePosition": False})
                if p == "/fapi/v1/leverage":
                    return self._send({"leverage": int(qs["leverage"])})
                if p == "/fapi/v1/algoOrder" and method == "POST":
                    if qs.get("algoType") != "CONDITIONAL" or "triggerPrice" not in qs or qs.get("type") not in COND_TYPES:
                        return self._send({"code": -1102, "msg": "Mandatory parameter missing or malformed (algoOrder)"}, 400)
                    trig, last = float(qs["triggerPrice"]), fake.price
                    # sàn thật: lệnh dừng mà giá kích hoạt đã nằm sai phía so với giá hiện tại -> -2021 (sẽ kích hoạt ngay)
                    if (qs["type"] == "STOP_MARKET" and ((qs["side"] == "SELL" and trig >= last) or (qs["side"] == "BUY" and trig <= last))) or \
                       (qs["type"] == "TAKE_PROFIT_MARKET" and ((qs["side"] == "SELL" and trig <= last) or (qs["side"] == "BUY" and trig >= last))):
                        return self._send({"code": -2021, "msg": "Order would immediately trigger."}, 400)
                    if qs.get("reduceOnly") == "true" and (st["pos"] == 0 or (st["pos"] > 0) != (qs["side"] == "SELL")):
                        return self._send({"code": -2022, "msg": "ReduceOnly Order is rejected."}, 400)
                    st["an"] += 1
                    a = {"algoId": st["an"], "reduceOnly": qs.get("reduceOnly", "false"), "clientAlgoId": qs.get("clientAlgoId", ""), "algoType": "CONDITIONAL", "orderType": qs["type"],
                         "symbol": qs["symbol"], "side": qs["side"], "positionSide": "BOTH", "quantity": qs["quantity"], "algoStatus": "NEW",
                         "triggerPrice": qs["triggerPrice"], "price": qs.get("price", "0"), "actualOrderId": "", "actualPrice": "0.00000"}
                    st["algo"][str(a["algoId"])] = a
                    return self._send(a)
                if p == "/fapi/v1/algoOrder" and method == "DELETE":
                    a = st["algo"].get(qs.get("algoId"))
                    if not a or a["algoStatus"] != "NEW":
                        return self._send({"code": -2011, "msg": "Unknown order sent."}, 400)
                    a["algoStatus"] = "CANCELED"
                    return self._send({"algoId": a["algoId"], "algoStatus": "CANCELED"})
                if p == "/fapi/v1/algoOrder" and method == "GET":
                    a = st["algo"].get(qs.get("algoId"))
                    if not a:
                        return self._send({"code": -2013, "msg": "Order does not exist."}, 400)
                    return self._send(a)
                if p == "/fapi/v1/openAlgoOrders":
                    return self._send([a for a in st["algo"].values() if a["algoStatus"] == "NEW" and a["symbol"] == qs.get("symbol")])
                if p == "/api/v3/orderList/oco" and method == "POST":
                    return self._new_oco(qs, st)
                if p == "/api/v3/orderList" and method == "DELETE":
                    lst = st["lists"].get(int(qs["orderListId"])) if "orderListId" in qs else None
                    if not lst or lst["status"] != "EXECUTING" or lst["symbol"] != qs.get("symbol"):
                        return self._send({"code": -2011, "msg": "Unknown order sent."}, 400)
                    lst["status"] = "ALL_DONE"
                    for oid in lst["legs"].values():
                        st["orders"][str(oid)]["status"] = "CANCELED"
                    return self._send(self._list_view(lst, "ALL_DONE"))
                if p == "/api/v3/orderList" and method == "GET":
                    lst = st["lists"].get(int(qs["orderListId"])) if "orderListId" in qs else None
                    if not lst:
                        return self._send({"code": -2018, "msg": "Order list does not exist."}, 400)
                    return self._send(self._list_view(lst, "EXECUTING" if lst["status"] == "EXECUTING" else "ALL_DONE"))
                if p.endswith("/order") and method == "POST" and kind == "fut" and qs.get("type") in COND_TYPES:
                    return self._send({"code": -4120, "msg": "Order type not supported for this endpoint. Please use the Algo Order API endpoints instead."}, 400)
                if p.endswith("/order") and method == "POST":
                    return self._new_order(qs, kind, st)
                if p.endswith("/order") and method == "DELETE":
                    o = st["orders"].get(qs.get("orderId"))
                    if not o or o["status"] != "NEW":
                        return self._send({"code": -2011, "msg": "Unknown order sent."}, 400)
                    o["status"] = "CANCELED"
                    return self._send({"orderId": o["orderId"], "status": "CANCELED"})
                if p.endswith("/order") and method == "GET":
                    o = st["orders"].get(qs.get("orderId"))
                    if not o:
                        return self._send({"code": -2013, "msg": "Order does not exist."}, 400)
                    return self._send(self._view(o, kind))
                if p.endswith("/openOrders"):
                    return self._send([self._view(o, kind) for o in st["orders"].values() if o["status"] == "NEW" and o["symbol"] == qs.get("symbol")])
                if p == "/fapi/v1/income":
                    if fake.income_fail:
                        return self._send({"code": -2015, "msg": "Invalid API-key, IP, or permissions for action."}, 401)
                    if "startTime" in qs and "endTime" in qs and int(qs["endTime"]) - int(qs["startTime"]) > 7 * 86400 * 1000:
                        return self._send({"code": -1127, "msg": "Time interval must be within 0-7 days"}, 400)
                    rows = sorted(st["income"], key=lambda r: r["time"])
                    if "startTime" in qs:
                        rows = [r for r in rows if r["time"] >= int(qs["startTime"])]
                    if "endTime" in qs:
                        rows = [r for r in rows if r["time"] <= int(qs["endTime"])]
                    return self._send(rows[:int(qs.get("limit", 100))])
                if p.endswith("/userTrades") and "startTime" in qs and "endTime" in qs and int(qs["endTime"]) - int(qs["startTime"]) > 7 * 86400 * 1000:
                    return self._send({"code": -1127, "msg": "Time interval must be within 0-7 days"}, 400)
                if p.endswith("/myTrades") or p.endswith("/userTrades"):
                    rows = [t for t in st["trades"] if t["symbol"] == qs.get("symbol")]
                    if "orderId" in qs:
                        rows = [t for t in rows if str(t["orderId"]) == qs["orderId"]]
                    if "startTime" in qs:
                        rows = [t for t in rows if t["time"] >= int(qs["startTime"])]
                    if "endTime" in qs:
                        rows = [t for t in rows if t["time"] <= int(qs["endTime"])]
                    if "limit" in qs:
                        rows = sorted(rows, key=lambda t: t["time"])[:int(qs["limit"])]
                    return self._send(rows)
                return self._send({"code": -2015, "msg": "unknown " + p}, 404)

            def _view(self, o, kind):
                ex = float(o.get("executedQty", 0) or 0)
                d = {"orderId": o["orderId"], "symbol": o["symbol"], "side": o["side"], "type": o["type"], "origQty": o["origQty"],
                     "executedQty": o.get("executedQty", "0"), "status": o["status"], "price": o.get("price", "0"), "stopPrice": o.get("stopPrice", "0"),
                     "clientOrderId": o.get("clientId", ""), "orderListId": o.get("orderListId", -1)}
                if ex > 0:
                    if kind == "spot":
                        d["cummulativeQuoteQty"] = "%.4f" % (ex * o["px"])
                    else:
                        d["avgPrice"] = "%.2f" % o["px"]
                        d["cumQuote"] = "%.4f" % (ex * o["px"])
                return d

            def _free_base(self):
                return fake.spot["bal"]["BTC"] - fake.locked_base()

            def _list_view(self, lst, status):
                return {"orderListId": lst["id"], "contingencyType": "OCO", "listStatusType": "EXEC_STARTED" if status == "EXECUTING" else "ALL_DONE",
                        "listOrderStatus": status, "listClientOrderId": lst["cid"], "transactionTime": int(time.time() * 1000), "symbol": lst["symbol"],
                        "orders": [{"symbol": lst["symbol"], "orderId": oid, "clientOrderId": st_o["clientId"]}
                                   for oid in lst["legs"].values() for st_o in [fake.spot["orders"][str(oid)]]]}

            def _new_oco(self, qs, st):
                """POST /api/v3/orderList/oco theo tài liệu: bắt buộc symbol, side, quantity, aboveType, belowType; BÁN: trên = LIMIT_MAKER/TAKE_PROFIT*,
                dưới = STOP_LOSS/STOP_LOSS_LIMIT; giá trên > giá gần nhất > giá dừng dưới. Khoá coin MỘT lần cho cả cặp. (Mã lỗi: ước lượng.)"""
                need = ("symbol", "side", "quantity", "aboveType", "belowType")
                if any(k not in qs for k in need):
                    return self._send({"code": -1102, "msg": "Mandatory parameter missing or malformed (OCO)"}, 400)
                at, bt = qs["aboveType"], qs["belowType"]
                if qs["side"] != "SELL" or at not in ("LIMIT_MAKER", "TAKE_PROFIT", "TAKE_PROFIT_LIMIT") or bt not in ("STOP_LOSS", "STOP_LOSS_LIMIT"):
                    return self._send({"code": -1106, "msg": "Invalid OCO leg types for side"}, 400)
                if "abovePrice" not in qs or "belowStopPrice" not in qs:
                    return self._send({"code": -1102, "msg": "abovePrice / belowStopPrice required"}, 400)
                tp, sl, last = float(qs["abovePrice"]), float(qs["belowStopPrice"]), fake.price
                if not (tp > last > sl):
                    return self._send({"code": -2010, "msg": "OCO price rule violated: abovePrice > last price > belowStopPrice"}, 400)
                q = float(qs["quantity"])
                if q > self._free_base() + 1e-12:
                    return self._send({"code": -2010, "msg": "Account has insufficient balance for requested action."}, 400)
                st["ln"] += 1
                lid = st["ln"]
                legs = {}
                for k, typ, extra, cid in (("tp", at, {"price": qs["abovePrice"]}, qs.get("aboveClientOrderId", "")),
                                           ("sl", bt, {"stopPrice": qs["belowStopPrice"]}, qs.get("belowClientOrderId", ""))):
                    st["n"] += 1
                    o = {"orderId": st["n"], "symbol": qs["symbol"], "side": "SELL", "type": typ, "origQty": qs["quantity"], "status": "NEW",
                         "clientId": cid, "orderListId": lid}
                    o.update(extra)
                    st["orders"][str(o["orderId"])] = o
                    legs[k] = o["orderId"]
                lst = {"id": lid, "symbol": qs["symbol"], "cid": qs.get("listClientOrderId", ""), "status": "EXECUTING", "qty": q, "legs": legs}
                st["lists"][lid] = lst
                return self._send(self._list_view(lst, "EXECUTING"))

            def _new_order(self, qs, kind, st):
                if kind == "spot" and qs.get("side") == "SELL" and float(qs.get("quantity", 0)) > self._free_base() + 1e-12:
                    return self._send({"code": -2010, "msg": "Account has insufficient balance for requested action."}, 400)
                st["n"] += 1
                o = {"orderId": st["n"], "symbol": qs["symbol"], "side": qs["side"], "type": qs["type"], "origQty": qs["quantity"], "status": "NEW",
                     "clientId": qs.get("newClientOrderId", "")}
                if "price" in qs:
                    o["price"] = qs["price"]
                if "stopPrice" in qs:
                    o["stopPrice"] = qs["stopPrice"]
                if qs["type"] == "MARKET":
                    fake._execute(kind, o, fake.price)
                    o["status"] = "FILLED"
                    st["orders"][str(o["orderId"])] = o
                    q = float(o["origQty"])
                    if kind == "fut":
                        return self._send({"orderId": o["orderId"], "status": "FILLED", "executedQty": o["origQty"], "avgPrice": "%.2f" % fake.price, "cumQuote": "%.4f" % (q * fake.price)})
                    fills = [{"price": "%.2f" % fake.price, "qty": o["origQty"], "commission": "%.8f" % (q * fake.fee_rate if o["side"] == "BUY" else 0),
                              "commissionAsset": "BTC" if o["side"] == "BUY" else "USDT"}]
                    return self._send({"orderId": o["orderId"], "executedQty": o["origQty"], "cummulativeQuoteQty": "%.4f" % (q * fake.price), "fills": fills})
                st["orders"][str(o["orderId"])] = o
                return self._send({"orderId": o["orderId"], "status": "NEW"})

            def do_GET(self):
                self._h("GET")

            def do_POST(self):
                self._h("POST")

            def do_DELETE(self):
                self._h("DELETE")
        return H


def _oanda_time(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        import calendar
        m = re.match(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)", str(x or ""))
        return float(calendar.timegm(tuple(int(g) for g in m.groups()))) if m else 0.0


class FakeOandaX(_Srv):
    TOKEN, ACC = "tok", "101-001-1-001"

    def __init__(self):
        self.lock = threading.RLock()
        self.reset()
        self.start(self._factory())

    def reset(self):
        with self.lock:
            self.orders, self.tx, self.pos, self.n = {}, {}, 0.0, 100
            self.calls = []
            self.balance = 10000.0
            self.price = 1.1000
            self.reject_pending = False          # True: từ chối MỌI lệnh chờ LIMIT/STOP (lệnh thị trường vẫn khớp bình thường)
            self.page_size = 0                   # >0: ép kích thước trang của /transactions (test phân trang)

    def fill(self, oid, price=None):
        """Khớp lệnh chờ `oid`. Lệnh `positionFill=REDUCE_ONLY` chỉ được GIẢM vị thế hiện có (tài liệu v20: OrderPositionFill): khối lượng bị
        cắt còn bằng vị thế; nếu không có vị thế để giảm thì lệnh bị HUỶ (lý do mô phỏng - tài liệu không nêu chi tiết)."""
        with self.lock:
            o = self.orders[str(oid)]
            px = float(price if price is not None else o["price"])
            u = float(o["units"])
            if o.get("positionFill") == "REDUCE_ONLY":
                if self.pos == 0 or self.pos * u > 0:
                    self._cancel_tx(o, str(oid), "POSITION_CLOSEOUT_NOTHING_TO_REDUCE")
                    return
                u = max(-abs(self.pos), u) if u < 0 else min(abs(self.pos), u)
            self.n += 1
            tid = str(self.n)
            self.tx[tid] = {"id": tid, "type": "ORDER_FILL", "instrument": o["instrument"], "units": str(int(u)), "price": "%.5f" % px,
                            "time": "2026-10-20T10:00:00.000000000Z", "pl": "0.0", "commission": "0.0", "financing": "0.0", "orderID": str(oid)}
            o["state"], o["fillingTransactionID"] = "FILLED", tid
            self.pos += u

    def add_tx(self, **tx):
        """Thêm một giao dịch lịch sử (type, time = epoch giây hoặc chuỗi, ...); trả id. Dùng cho test lịch sử (tradeOpened/tradesClosed, DAILY_FINANCING...)."""
        with self.lock:
            self.n += 1
            tid = str(self.n)
            t = dict(tx, id=tid)
            if isinstance(t.get("time"), (int, float)):
                t["time"] = "%.9f" % t["time"]
            self.tx[tid] = t
            return tid

    def _cancel_tx(self, o, oid, reason):
        """Huỷ lệnh + ghi giao dịch OrderCancelTransaction (Order chỉ giữ `cancellingTransactionID`; LÝ DO nằm trong giao dịch - đúng tài liệu v20)."""
        self.n += 1
        tid = str(self.n)
        self.tx[tid] = {"id": tid, "type": "ORDER_CANCEL", "orderID": oid, "reason": reason, "time": "2026-10-20T10:00:00.000000000Z"}
        o["state"], o["cancellingTransactionID"] = "CANCELLED", tid
        return tid

    def cancel_external(self, oid, reason="CLIENT_REQUEST"):
        with self.lock:
            self._cancel_tx(self.orders[str(oid)], str(oid), reason)

    def _factory(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _h(self, method):
                u = urllib.parse.urlparse(self.path)
                qs = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n)) if n else {}
                if self.headers.get("Authorization") != "Bearer " + fake.TOKEN:
                    return self._send({"errorMessage": "unauthorized"}, 401)
                a = "/v3/accounts/%s" % fake.ACC
                p = u.path
                with fake.lock:
                    fake.calls.append((method, p, qs, body))
                    if p == a + "/summary":
                        return self._send({"account": {"balance": "%.2f" % fake.balance, "currency": getattr(fake, "currency", "USD")}})
                    if p == a + "/instruments":
                        return self._send({"instruments": [{"name": qs.get("instruments") or "EUR_USD", "displayPrecision": 5}]})
                    if p == a + "/pricing":
                        return self._send({"prices": [{"instrument": qs.get("instruments"), "status": "tradeable", "time": time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime()),
                                                       "bids": [{"price": "%.5f" % (fake.price - 0.0001)}], "asks": [{"price": "%.5f" % (fake.price + 0.0001)}]}]})
                    mc = re.match(r"^/v3/instruments/(\w+)/candles$", p)
                    if mc:
                        gran = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H2": 7200, "H4": 14400, "D": 86400}[qs["granularity"]]
                        end = float(qs["to"]) if "to" in qs else time.time() + 1
                        return self._send({"candles": [{"time": time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime(t)), "volume": 10, "complete": True,
                                                       "mid": {"o": "%.5f" % o, "h": "%.5f" % h, "l": "%.5f" % l, "c": "%.5f" % c}}
                                                      for t, o, h, l, c in synth_candles(gran, min(int(qs.get("count", 500)), 5000), end, fake.price)]})
                    if p == a + "/openPositions":
                        return self._send({"positions": [{"instrument": "EUR_USD", "long": {"units": str(fake.pos if fake.pos > 0 else 0), "averagePrice": "1.1"},
                                                          "short": {"units": str(fake.pos if fake.pos < 0 else 0), "averagePrice": "1.1"}}] if fake.pos else []})
                    if p == a + "/orders" and method == "POST":
                        return self._create(body["order"])
                    if p == a + "/pendingOrders":
                        return self._send({"orders": [dict(o, id=k) for k, o in fake.orders.items() if o["state"] == "PENDING"]})
                    m = re.match(r"^%s/orders/(\d+)(/cancel)?$" % re.escape(a), p)
                    if m:
                        oid, cancel = m.group(1), m.group(2)
                        o = fake.orders.get(oid)
                        if not o:
                            return self._send({"errorMessage": "ORDER_DOESNT_EXIST"}, 404)
                        if method == "GET":
                            return self._send({"order": dict(o, id=oid)})
                        if method == "PUT" and cancel:
                            if o["state"] != "PENDING":
                                return self._send({"errorMessage": "ORDER_NOT_CANCELABLE"}, 404)
                            tid = fake._cancel_tx(o, oid, "CLIENT_REQUEST")
                            return self._send({"orderCancelTransaction": {"id": tid, "orderID": oid}})
                        if method == "PUT":
                            fake._cancel_tx(o, oid, "CLIENT_REQUEST")
                            return self._create(body["order"])
                    m = re.match(r"^%s/transactions/(\d+)$" % re.escape(a), p)
                    if m:
                        t = fake.tx.get(m.group(1))
                        return self._send({"transaction": t}) if t else self._send({"errorMessage": "nf"}, 404)
                    if p == a + "/transactions":
                        types = set(qs["type"].split(",")) if qs.get("type") else None
                        rows = sorted((r for r in fake.tx.values() if types is None or r["type"] in types), key=lambda r: int(r["id"]))
                        if "to" in qs:                                   # kỳ [from, to] chỉ áp dụng khi hỏi đủ hai đầu (kiểu hỏi của bộ máy lịch sử chung)
                            lo, hi = _oanda_time(qs.get("from", "0")), _oanda_time(qs["to"])
                            rows = [r for r in rows if lo <= _oanda_time(r.get("time")) <= hi]
                        ps = fake.page_size or int(qs.get("pageSize", 100))
                        pages = ["%s%s/transactions/idrange?from=%s&to=%s%s" % (fake.base, a, rows[i]["id"], rows[min(i + ps, len(rows)) - 1]["id"],
                                                                                ("&type=" + qs["type"]) if types else "") for i in range(0, len(rows), ps)]
                        if not rows and "to" not in qs:
                            pages = ["%s%s/transactions/idrange?from=1&to=99999" % (fake.base, a)]
                        return self._send({"pages": pages, "count": len(rows), "lastTransactionID": str(fake.n)})
                    if p == a + "/transactions/idrange":
                        lo, hi = int(qs.get("from", 0)), int(qs.get("to", 10 ** 12))
                        types = set(qs["type"].split(",")) if qs.get("type") else None
                        return self._send({"transactions": [r for r in sorted(fake.tx.values(), key=lambda r: int(r["id"]))
                                                            if lo <= int(r["id"]) <= hi and (types is None or r["type"] in types)]})
                return self._send({"errorMessage": "unknown " + p}, 404)

            def _create(self, o):
                fake.n += 1
                oid = str(fake.n)
                if o["type"] == "MARKET":
                    fake.orders[oid] = dict(o, state="PENDING")
                    fake.fill_market = None
                    fake.n += 1
                    tid = str(fake.n)
                    fake.tx[tid] = {"id": tid, "type": "ORDER_FILL", "instrument": o["instrument"], "units": o["units"], "price": "%.5f" % fake.price,
                                    "time": "2026-10-20T10:00:00.000000000Z", "pl": "0.0", "commission": "0.0", "financing": "0.0", "orderID": oid}
                    fake.orders[oid].update(state="FILLED", fillingTransactionID=tid)
                    fake.pos += float(o["units"])
                    return self._send({"orderFillTransaction": {"id": tid, "price": "%.5f" % fake.price, "units": o["units"]}})
                if o["type"] in ("LIMIT", "STOP"):
                    if fake.reject_pending:
                        return self._send({"orderRejectTransaction": {"rejectReason": "STOP_LOSS_ON_FILL_LOSS"}}, 400)
                    if "price" not in o or len(o["price"].split(".")[-1]) != 5:
                        return self._send({"orderRejectTransaction": {"rejectReason": "PRICE_PRECISION_EXCEEDED"}}, 400)
                    fake.orders[oid] = dict(o, state="PENDING")
                    return self._send({"orderCreateTransaction": {"id": oid}})
                return self._send({"errorMessage": "bad type"}, 400)

            def do_GET(self):
                self._h("GET")

            def do_POST(self):
                self._h("POST")

            def do_PUT(self):
                self._h("PUT")
        return H


class FakeZetaX(_Srv):
    """Sàn THỨ BA, cố ý khác mọi sàn có sẵn: tên trường lạ, giờ ms / ISO có múi giờ, cờ chiều «B»/«S», phí báo SỐ DƯƠNG, nạp/rút cùng một số dương + cờ hướng,
    phân trang bằng con trỏ (fills) và bằng số trang (cash), khoá API ở header X-ZX-KEY. Không có dòng mã nào của app biết tới nó - chỉ có hồ sơ JSON."""
    KEY = "zk-1"

    def __init__(self):
        self.lock = threading.RLock()
        self.fills, self.cash, self.calls = [], [], []
        self.start(self._factory())

    def add_fill(self, fid, inst, dir_, sz, px, t, fee=0.0, realized=0.0, pos="", leg="open"):
        with self.lock:
            self.fills.append({"fid": fid, "inst": inst, "dir": dir_, "sz": str(sz), "px": str(px), "ts_ms": int(t * 1000), "fee": str(fee),
                               "realized": str(realized), "pos": pos, "leg": leg})

    def add_cash(self, cid, t, typ, amt, direction="in"):
        import time as _t
        with self.lock:
            off = "+07:00"
            iso = _t.strftime("%Y-%m-%dT%H:%M:%S", _t.gmtime(t + 7 * 3600)) + off
            self.cash.append({"cid": cid, "when": iso, "type": typ, "amt": str(amt), "dir": direction})

    def _factory(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200):
                b = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                u = urllib.parse.urlparse(self.path)
                qs = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                if self.headers.get("X-ZX-KEY") != fake.KEY:
                    return self._send({"ok": False, "err": "bad key"}, 401)
                with fake.lock:
                    fake.calls.append((u.path, dict(qs)))
                    if u.path == "/zx/v2/fills":
                        rows = sorted(fake.fills, key=lambda r: r["ts_ms"])
                        rows = [r for r in rows if int(qs.get("from_ms", 0)) <= r["ts_ms"] <= int(qs.get("to_ms", 10 ** 15))]
                        start, size = int(qs.get("cursor", "0") or 0), int(qs.get("size", 50))
                        nxt = start + size
                        return self._send({"ok": True, "data": {"rows": rows[start:nxt], "next": str(nxt) if nxt < len(rows) else None}})
                    if u.path == "/zx/v2/cash":
                        per, page = int(qs.get("per", 50)), int(qs.get("page", 1))
                        return self._send({"result": {"items": fake.cash[(page - 1) * per: page * per], "total": len(fake.cash)}})
                return self._send({"ok": False, "err": "unknown " + u.path}, 404)
        return H
