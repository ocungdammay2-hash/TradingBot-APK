"""Khung thời gian kiểu MT5 (21 khung, ghép nến cho sàn thiếu khung), cử chỉ cảm ứng của biểu đồ (kéo/chụm/chạm 2 lần/đà),
chỉ báo MT5 (công thức + vẽ + quản lý trên giao diện). UI chạy bằng Kivy giả => KHÔNG kiểm tra hiển thị/cảm ứng thật."""
import math, os, random, sys, tempfile, time, types, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub
kivy_stub.install()

from pyea import chart_indicators as chind                         # noqa: E402
from pyea import feeds                                              # noqa: E402
from pyea import indicators as ta                                   # noqa: E402
from pyea.backtest import run_backtest                              # noqa: E402
from pyea.engine import CandleBuilder, TradingSession               # noqa: E402
from pyea.feeds import (TIMEFRAMES, BinanceFeed, OandaFeed, SimFeed, pick_base, resample, tf_bucket,   # noqa: E402
                        tf_next, tf_prev, tf_span)
from pyea.ipc import _chart_from_json, snapshot_from_json, snapshot_to_json    # noqa: E402
from pyea.sdk import Candle                                         # noqa: E402
from pyea.settings import default_settings                          # noqa: E402
from pyea.storage import Store                                      # noqa: E402
import pyea.ui_widgets as W                                         # noqa: E402


def utc(y, mo, d, h=0, mi=0, s=0):
    import calendar
    return calendar.timegm((y, mo, d, h, mi, s))


def walk_candles(n, step=300, seed=7, vol=True):
    rnd = random.Random(seed)
    p, out = 100.0, []
    for i in range(n):
        o = p
        p *= math.exp(rnd.gauss(0, 0.01))
        out.append(Candle(1_700_000_000 - (1_700_000_000 % step) + i * step, o, max(o, p) * (1 + abs(rnd.gauss(0, .002))),
                          min(o, p) * (1 - abs(rnd.gauss(0, .002))), p, rnd.uniform(10, 100) if vol else 0.0))
    return out


# ============================================================================ khung thời gian
class TestTimeframes(unittest.TestCase):
    def test_full_mt5_set(self):
        want = ["1m", "2m", "3m", "4m", "5m", "6m", "10m", "12m", "15m", "20m", "30m", "1h", "2h", "3h", "4h", "6h", "8h",
                "12h", "1d", "1w", "1mo"]
        self.assertEqual(list(TIMEFRAMES), want)
        self.assertEqual(sorted(TIMEFRAMES.values()), list(TIMEFRAMES.values()))      # đã xếp tăng dần

    def test_bucket_week_month(self):
        t = utc(2026, 10, 18, 13, 30)                                      # Chủ nhật
        self.assertEqual(tf_bucket("1w", t), utc(2026, 10, 12))            # Thứ Hai 00:00 UTC
        self.assertEqual(tf_bucket("1mo", t), utc(2026, 10, 1))
        self.assertEqual(tf_bucket("1d", t), utc(2026, 10, 18))
        self.assertEqual(tf_bucket("4h", t), utc(2026, 10, 18, 12))
        self.assertEqual(tf_bucket("20m", utc(2026, 10, 18, 13, 30)), utc(2026, 10, 18, 13, 20))
        self.assertEqual(tf_next("1mo", utc(2026, 12, 1)), utc(2027, 1, 1))
        self.assertEqual(tf_prev("1mo", utc(2026, 1, 1), 2), utc(2025, 11, 1))
        self.assertEqual(tf_span("1mo", utc(2028, 2, 1)) / 86400, 29)       # năm nhuận
        self.assertEqual(tf_span("1mo", utc(2026, 2, 1)) / 86400, 28)
        self.assertEqual(tf_span("1w", utc(2026, 10, 12)) / 86400, 7)

    def test_resample_ohlcv(self):
        cs = [Candle(utc(2026, 1, 5, 0, i), 10 + i, 20 + i, 5 + i, 11 + i, 1.0) for i in range(12)]
        out = resample(cs, "4m")
        self.assertEqual([c.time for c in out], [utc(2026, 1, 5, 0, 0), utc(2026, 1, 5, 0, 4), utc(2026, 1, 5, 0, 8)])
        c = out[1]
        self.assertEqual((c.open, c.high, c.low, c.close, c.volume), (14, 27, 9, 18, 4.0))

    def test_pick_base(self):
        from pyea.feeds import _BINANCE_INT, _OANDA_GRAN
        self.assertEqual(pick_base("3h", _BINANCE_INT), "1h")
        self.assertEqual(pick_base("12m", _BINANCE_INT), "3m")
        self.assertEqual(pick_base("20m", _BINANCE_INT), "5m")
        self.assertEqual(pick_base("2m", _BINANCE_INT), "1m")
        self.assertEqual(pick_base("6m", _OANDA_GRAN), "2m")
        self.assertEqual(pick_base("12m", _OANDA_GRAN), "4m")
        self.assertEqual(pick_base("20m", _OANDA_GRAN), "10m")
        self.assertEqual(pick_base("3m", _OANDA_GRAN), "1m")
        for tf in TIMEFRAMES:                                               # mọi khung đều lấy được từ Binance và OANDA
            self.assertTrue(tf in _BINANCE_INT or pick_base(tf, _BINANCE_INT), tf)
            self.assertTrue(tf in _OANDA_GRAN or pick_base(tf, _OANDA_GRAN), tf)

    def test_sim_history_all_timeframes(self):
        f = SimFeed(start_price=1000.0, speed=1.0)
        for tf in TIMEFRAMES:
            h = f.history("BTCUSD", tf, 30)
            self.assertEqual(len(h), 30, tf)
            self.assertEqual([c.time for c in h], sorted(c.time for c in h), tf)
            self.assertEqual(len({c.time for c in h}), 30, tf)
            for c in h:
                self.assertEqual(tf_bucket(tf, c.time), c.time, "%s lệch căn nến" % tf)
                self.assertGreaterEqual(c.high, max(c.open, c.close) - 1e-9)
                self.assertLessEqual(c.low, min(c.open, c.close) + 1e-9)
            self.assertLess(h[-1].time, tf_bucket(tf, f.sim_time), tf)      # nến cuối đã đóng
        mo = f.history("BTCUSD", "1mo", 24)
        self.assertTrue(all(time.gmtime(c.time).tm_mday == 1 for c in mo))
        wk = f.history("BTCUSD", "1w", 10)
        self.assertTrue(all(time.gmtime(c.time).tm_wday == 0 for c in wk))   # Thứ Hai

    def test_builder_week_and_month_boundaries(self):
        b = CandleBuilder(TIMEFRAMES["1mo"], tf="1mo")
        self.assertIsNone(b.update(utc(2026, 1, 31, 23, 59, 59), 10.0))
        b.update(utc(2026, 1, 31, 23, 59, 59), 12.0)
        done = b.update(utc(2026, 2, 1, 0, 0, 1), 11.0)
        self.assertIsNotNone(done)
        self.assertEqual(done.time, utc(2026, 1, 1))
        self.assertEqual((done.open, done.high, done.close), (10.0, 12.0, 12.0))
        self.assertEqual(b.current.time, utc(2026, 2, 1))
        w = CandleBuilder(TIMEFRAMES["1w"], tf="1w")
        w.update(utc(2026, 10, 18, 23, 0), 1.0)                              # Chủ nhật
        done = w.update(utc(2026, 10, 19, 0, 0, 5), 2.0)                     # Thứ Hai
        self.assertEqual(done.time, utc(2026, 10, 12))
        self.assertEqual(w.current.time, utc(2026, 10, 19))

    def test_session_chart_on_new_timeframes(self):
        s = default_settings()
        s.update(tick_interval=0.2, sim_speed=300.0, history_bars=120, max_loss_pct=0.0)
        sess = TradingSession(s, log_file=None)
        sess.start()
        try:
            for tf in ("3m", "1w", "1mo"):
                sess.set_chart("BTCUSD", tf)
                end = time.time() + 15
                c = None
                while time.time() < end and not c:
                    c = sess.chart("BTCUSD", tf, 400)
                    time.sleep(0.1)
                self.assertTrue(c and len(c["candles"]) > 20, tf)
                for k in c["candles"]:
                    self.assertEqual(tf_bucket(tf, k.time), k.time, tf)
        finally:
            sess.stop()

    def test_backtest_monthly_and_weekly(self):
        store = Store(tempfile.mkdtemp())
        store.seed_examples()
        bot = os.path.join(store.bots_dir, "ma_cross.py")
        f = SimFeed(start_price=1000.0, speed=1.0)
        for tf in ("1w", "1mo", "7m" if False else "12m"):
            cs = f.history("BTCUSD", tf, 400)
            st = default_settings()
            st.update(initial_balance=100000.0, max_loss_pct=0.0)
            res = run_backtest(bot, {}, st, "BTCUSD", tf, cs, 100, "ohlc")
            self.assertTrue(res.ok, (tf, res.error))
            self.assertGreater(len(res.candles), 50, tf)

    def test_ipc_candles_compact_and_legacy(self):
        cs = walk_candles(5)
        snap = {"ready": True, "positions": [], "trades": []}
        chart = {"symbol": "X", "timeframe": "5m", "candles": cs, "plots": {"a": [(cs[0].time, 1.5)]}, "events": [], "positions": []}
        d = snapshot_to_json(snap, chart)
        self.assertIsInstance(d["chart"]["candles"][0], list)
        import json
        back = snapshot_from_json(json.loads(json.dumps(d)))
        self.assertEqual(back["chart"]["candles"], cs)
        legacy = _chart_from_json({"candles": [{"time": 1, "open": 2, "high": 3, "low": 1, "close": 2.5, "volume": 0}]})
        self.assertEqual(legacy["candles"][0].high, 3)

    def test_feed_resampling_with_fake_http(self):
        """Binance/OANDA không có sẵn 12m/3h/20m -> ghép từ khung nhỏ; khung có sẵn gửi đúng interval."""
        calls = []
        real = feeds.http_json
        base_t = utc(2026, 10, 18, 12, 0)

        def fake(url, params=None, headers=None, method="GET", timeout=10, body=None, **kw):
            params = dict(params or {})
            calls.append((url.split("/")[-1], params))
            if url.endswith("/klines"):
                iv = params["interval"]
                step = {"1m": 60, "3m": 180, "5m": 300, "1h": 3600, "1M": 2592000}[iv]
                end_ms = params.get("endTime", base_t * 1000)
                last = int((end_ms / 1000.0) // step) * step - (step if "endTime" not in params else 0)
                n = params["limit"]
                return [[(last - (n - 1 - i) * step) * 1000, "1", "2", "0.5", "1.5", "10"] for i in range(n)]
            if url.endswith("/candles"):
                gran = params["granularity"]
                step = {"M1": 60, "M2": 120, "M4": 240, "M10": 600, "H1": 3600}[gran]
                last = int(base_t // step) * step
                n = params["count"]
                out = []
                for i in range(n):
                    t = last - (n - 1 - i) * step
                    out.append({"complete": True, "volume": 5, "time": time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime(t)),
                                "mid": {"o": "1", "h": "2", "l": "0.5", "c": "1.5"}})
                return {"candles": out}
            return {}
        feeds.http_json = fake
        try:
            b = BinanceFeed("http://x")
            h = b.history("BTCUSDT", "12m", 10)
            self.assertEqual(len(h), 10)
            self.assertTrue(all(c.time % 720 == 0 for c in h))
            self.assertTrue(all(c.volume == 40.0 for c in h[:-1]))            # 4 nến 3m x 10
            self.assertEqual({p["interval"] for u, p in calls if u == "klines"}, {"3m"})
            calls.clear()
            h3 = b.history("BTCUSDT", "3h", 5)
            self.assertEqual(len(h3), 5)
            self.assertTrue(all(c.time % 10800 == 0 for c in h3))
            self.assertEqual({p["interval"] for u, p in calls}, {"1h"})
            calls.clear()
            b.history("BTCUSDT", "1mo", 3)
            self.assertEqual(calls[0][1]["interval"], "1M")                       # tháng của Binance viết hoa
            calls.clear()
            o = OandaFeed("http://x", "tok", "101-1")
            h20 = o.history("EUR_USD", "20m", 6)
            self.assertEqual(len(h20), 6)
            self.assertTrue(all(c.time % 1200 == 0 for c in h20))
            self.assertEqual({p["granularity"] for u, p in calls}, {"M10"})
            calls.clear()
            o.history("EUR_USD", "1h", 5)
            p = calls[0][1]
            self.assertEqual((p["granularity"], p["alignmentTimezone"], p["dailyAlignment"], p["weeklyAlignment"]),
                             ("H1", "UTC", 0, "Monday"))
        finally:
            feeds.http_json = real


# ============================================================================ chỉ báo
class TestIndicatorMath(unittest.TestCase):
    def test_moving_averages(self):
        v = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        self.assertEqual(ta.sma_series(v, 3), [None, None, 2.0, 3.0, 4.0, 5.0])
        self.assertEqual(ta.lwma_series(v, 3)[2], (1 * 1 + 2 * 2 + 3 * 3) / 6.0)
        sm = ta.smma_series(v, 3)
        self.assertEqual(sm[2], 2.0)
        self.assertAlmostEqual(sm[3], (2.0 * 2 + 4.0) / 3.0)
        self.assertEqual(ta.ma_series(v, 3, "ema")[2], 2.0)
        self.assertEqual(ta.sma_series([None, None, 1, 2, 3, 4], 3), [None] * 4 + [2.0, 3.0])      # chịu None ở đầu
        e = ta.ema_series([1, 2, 3, 4, 5.0], 3)
        self.assertAlmostEqual(e[3], 4 * 0.5 + 2.0 * 0.5)

    def test_rsi_wilder_reference(self):
        v = [44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28,
             46.00, 46.03, 46.41, 46.22, 45.64]
        r = [x for x in ta.rsi_series(v, 14) if x is not None]
        self.assertAlmostEqual(r[0], 70.46, 1)
        self.assertAlmostEqual(r[-1], 57.92, 1)

    def test_macd_mt5_signal_is_sma(self):
        cs = walk_candles(120)
        v = [c.close for c in cs]
        line, sig, hist = ta.macd_series(v, 12, 26, 9, "sma")
        self.assertEqual(ta._first(line), 25)
        self.assertEqual(ta._first(sig), 25 + 8)
        i = 60
        self.assertAlmostEqual(sig[i], sum(line[i - 8:i + 1]) / 9.0)
        self.assertAlmostEqual(hist[i], line[i] - sig[i])
        _, sig_e, _ = ta.macd_series(v, 12, 26, 9, "ema")
        self.assertNotAlmostEqual(sig_e[i], sig[i])

    def test_stochastic_matches_bruteforce(self):
        cs = walk_candles(80)
        k, d, sl = 5, 3, 3
        main, sig = ta.stoch_series(cs, k, d, sl)
        for i in (20, 45, 79):
            num = den = 0.0
            for j in range(i - sl + 1, i + 1):
                ll = min(c.low for c in cs[j - k + 1:j + 1])
                hh = max(c.high for c in cs[j - k + 1:j + 1])
                num += cs[j].close - ll
                den += hh - ll
            self.assertAlmostEqual(main[i], num / den * 100.0)
            self.assertAlmostEqual(sig[i], sum(main[i - d + 1:i + 1]) / d)
            self.assertTrue(0 <= main[i] <= 100)

    def test_adx_ranges_and_trend(self):
        up = [Candle(i * 60, 100 + i, 101 + i, 99.5 + i, 100.8 + i, 1) for i in range(80)]
        for sm in ("ema", "wilder"):
            adx, pdi, ndi = ta.adx_series(up, 14, sm)
            self.assertGreater(adx[-1], 80, sm)                     # xu hướng tăng đều => ADX rất cao
            self.assertGreater(pdi[-1], 30)
            self.assertAlmostEqual(ndi[-1], 0.0, 6)
        cs = walk_candles(200)
        adx, pdi, ndi = ta.adx_series(cs)
        for a, p, n in zip(adx, pdi, ndi):
            if a is not None:
                self.assertTrue(0 <= a <= 100 and p >= 0 and n >= 0)

    def test_atr_sma_vs_wilder(self):
        cs = walk_candles(60)
        tr = ta.true_range(cs)
        a = ta.atr_series(cs, 14)
        self.assertEqual(ta._first(a), 14)
        self.assertAlmostEqual(a[14], sum(tr[1:15]) / 14.0)
        w = ta.atr_series(cs, 14, "wilder")
        self.assertAlmostEqual(w[14], a[14])
        self.assertNotAlmostEqual(w[40], a[40])

    def test_sar_follows_trend_and_flips(self):
        up = [Candle(i, 100 + i, 101 + i, 99 + i, 100.5 + i, 1) for i in range(30)]
        down = [Candle(30 + i, 130 - i, 131 - i, 129 - i, 129.5 - i, 1) for i in range(30)]
        s = ta.sar_series(up + down)
        self.assertTrue(all(s[i] < up[i].low for i in range(5, 30)))               # SAR dưới nến khi tăng
        self.assertTrue(all(s[i] > (up + down)[i].high for i in range(50, 60)))     # đảo xuống: SAR trên nến

    def test_ichimoku_fractals_donchian(self):
        cs = walk_candles(100)
        t, k, a, b, ch = ta.ichimoku_series(cs, 9, 26, 52)
        i = 70
        self.assertAlmostEqual(t[i], (max(c.high for c in cs[i - 8:i + 1]) + min(c.low for c in cs[i - 8:i + 1])) / 2)
        self.assertAlmostEqual(a[i], (t[i] + k[i]) / 2)
        self.assertEqual(ch[i], cs[i].close)
        hs = [1, 2, 5, 2, 1, 2, 3, 1, 0.5, 2]
        fc = [Candle(i, h, h, h - 0.2, h, 1) for i, h in enumerate(hs)]
        up, dn = ta.fractals_series(fc)
        self.assertEqual(up[2], 5)
        self.assertIsNone(up[1])
        hh, mid, ll = ta.donchian_series(cs, 20)
        self.assertEqual(hh[50], max(c.high for c in cs[31:51]))

    def test_volume_indicators(self):
        cs = [Candle(i, 10, 11, 9, 10 + 0.1 * i, 100) for i in range(40)]            # đóng cửa tăng dần
        self.assertEqual(ta.obv_series(cs)[-1], 100 * 40)
        self.assertEqual(ta.mfi_series(cs, 14)[-1], 100.0)
        self.assertGreater(ta.ad_series(cs)[-1], 0)
        for fn in (ta.cci_series, ta.wpr_series, ta.demarker_series, ta.ao_series, ta.ac_series):
            self.assertTrue(any(x is not None for x in fn(walk_candles(100))))
        self.assertTrue(all(-100 <= x <= 0 for x in ta.wpr_series(walk_candles(100)) if x is not None))

    def test_all_registered_indicators_compute(self):
        cs = walk_candles(300)
        self.assertEqual(len(chind.INDICATORS), 33)
        for i, key in enumerate(chind.INDICATORS):
            cfg = chind.new_cfg(key, i)
            r = chind.compute(cfg, cs)
            self.assertEqual(r["note"], "", key)
            self.assertTrue(r["lines"], key)
            for ln in r["lines"]:
                self.assertEqual(len(ln["v"]), 300, key)
                self.assertTrue(any(v is not None for v in ln["v"]), (key, ln["name"]))
            self.assertIn(r["pane"], ("main", "sub"))
            self.assertTrue(chind.describe(cfg))
        # nguồn không có khối lượng -> ghi chú, không lỗi
        nov = walk_candles(100, vol=False)
        self.assertIn("khối lượng", chind.compute(chind.new_cfg("obv"), nov)["note"])
        # tham số hỏng trong prefs -> về mặc định
        c = chind.clean_cfgs([{"key": "ma", "params": {"period": "abc", "method": "ema"}}, {"key": "khong-co"}, "x"])
        self.assertEqual(len(c), 1)
        self.assertEqual((c[0]["params"]["period"], c[0]["params"]["method"]), (20, "ema"))

    def test_sub_axis_range(self):
        cs = walk_candles(200)
        self.assertEqual(chind.sub_axis_range(chind.compute(chind.new_cfg("rsi"), cs), 100, 200), (0, 100))
        lo, hi = chind.sub_axis_range(chind.compute(chind.new_cfg("macd"), cs), 100, 200)
        self.assertLess(lo, 0)
        self.assertGreater(hi, 0)
        lo, hi = chind.sub_axis_range(chind.compute(chind.new_cfg("volumes"), cs), 100, 200)
        self.assertEqual(lo, 0)

    def test_shift_and_future_projection(self):
        cs = walk_candles(120)
        r = chind.compute(chind.new_cfg("ichimoku"), cs)
        senkou_a = r["lines"][2]
        self.assertEqual(senkou_a["shift"], 26)
        self.assertEqual(r["lines"][4]["shift"], -26)
        r = chind.compute(chind.new_cfg("alligator"), cs)
        self.assertEqual([ln["shift"] for ln in r["lines"]], [8, 5, 3])


# ============================================================================ biểu đồ + cử chỉ
class FT:
    """Chạm giả."""
    n = 0

    def __init__(self, x, y, button=None):
        FT.n += 1
        self.uid, self.x, self.y, self.button = FT.n, x, y, button
        self.pos, self.grab_current, self.ud = (x, y), None, {}

    def grab(self, w): self.grab_current = w
    def ungrab(self, w): pass

    def to(self, x, y):
        self.x, self.y, self.pos = x, y, (x, y)
        return self


def make_chart(n=400, bars=60):
    ch = W.CandleChart(size_hint_y=None, height=300)
    ch.x, ch.y, ch.width, ch.height = 0, 0, 360, 300
    ch.update(walk_candles(n), {}, [], [])
    ch.bars = bars
    ch.redraw()
    return ch


def down(ch, x, y):
    t = FT(x, y)
    ch.on_touch_down(t)
    return t


def move(ch, t, x, y):
    t.to(x, y)
    t.grab_current = ch
    return ch.on_touch_move(t)


def up(ch, t):
    t.grab_current = ch
    return ch.on_touch_up(t)


class TestChartGestures(unittest.TestCase):
    def test_pan_drag_horizontal(self):
        ch = make_chart()
        bw = ch._bw
        t = down(ch, 100, 150)
        move(ch, t, 100 + bw * 10, 150)
        up(ch, t)
        self.assertAlmostEqual(ch.offset, 10, delta=1)
        t = down(ch, 200, 150)                                    # kéo ngược lại về mới nhất
        move(ch, t, 200 - bw * 30, 150)
        up(ch, t)
        self.assertEqual(ch.offset, 0)                            # không vượt qua nến mới nhất

    def test_pan_clamped_at_oldest(self):
        ch = make_chart(n=100, bars=60)
        t = down(ch, 10, 150)
        move(ch, t, 10 + 5000, 150)
        up(ch, t)
        self.assertEqual(ch.offset, 100 - 60)

    def test_vertical_drag_scrolls_page_not_chart(self):
        ch = make_chart()
        sv = types.SimpleNamespace(children=[types.SimpleNamespace(height=1000)], height=400, scroll_y=1.0)
        ch.scroll_parent = sv
        t = down(ch, 100, 150)
        move(ch, t, 102, 150 + 120)
        up(ch, t)
        self.assertEqual(ch.offset, 0)
        self.assertAlmostEqual(sv.scroll_y, 1.0 - 120 / 600.0, places=3)

    def test_pinch_zoom(self):
        ch = make_chart(bars=60)
        a, b = down(ch, 150, 150), down(ch, 210, 150)             # cách nhau 60
        move(ch, b, 270, 150)                                     # giãn gấp đôi -> phóng to (ít nến hơn)
        self.assertAlmostEqual(ch.bars, 30, delta=1)
        move(ch, b, 150 + 15, 150)                                # chụm lại còn 1/4 -> thu nhỏ
        self.assertGreater(ch.bars, 100)
        up(ch, b); up(ch, a)
        self.assertEqual(ch._touches, {})
        # nhấc 1 ngón rồi tiếp tục: không bị coi là "chạm" (không bật crosshair)
        self.assertIsNone(ch.cross)

    def test_pinch_keeps_candle_under_fingers(self):
        ch = make_chart(bars=60)
        ch.set_offset(50)
        ch.redraw()
        a, b = down(ch, 100, 150), down(ch, 200, 150)
        mid = 150.0
        g0 = ch._anchor_g(mid)
        for xb in (230, 260, 300):
            move(ch, b, xb, 150)
            ch.redraw()
            bw = ch._pw / (ch.bars + ch._pad(ch.bars))
            now = ch._start + (mid + (xb - 200) / 2.0 - ch._x0) / bw - 0.5            # tâm 2 ngón dịch sang phải
            self.assertAlmostEqual(ch._anchor_g(mid + (xb - 200) / 2.0), now, delta=1.0)
        # tâm đứng yên (2 ngón giãn đối xứng) => cùng 1 nến ở dưới tâm
        ch2 = make_chart(bars=60)
        ch2.set_offset(50)
        ch2.redraw()
        a, b = down(ch2, 120, 150), down(ch2, 180, 150)
        g_before = ch2._anchor_g(150)
        move(ch2, a, 90, 150)
        move(ch2, b, 210, 150)
        self.assertLess(ch2.bars, 60)
        self.assertAlmostEqual(ch2._anchor_g(150), g_before, delta=1.0)

    def test_finger_left_after_pinch_does_not_jump(self):
        ch = make_chart(bars=60)
        a, b = down(ch, 100, 150), down(ch, 160, 150)
        move(ch, b, 220, 150)
        up(ch, b)
        off = ch.offset
        move(ch, a, 105, 150)                                      # < 8px: chưa kéo
        self.assertEqual(ch.offset, off)

    def test_forward_projected_indicators_get_room(self):
        ch = make_chart(n=300, bars=60)
        base = ch._pad(60)
        ch.set_indicators([chind.new_cfg("ichimoku", 0)])
        self.assertGreater(ch._pad(60), base)                      # chừa chỗ cho mây dịch +26 nến
        self.assertLessEqual(ch._pad(60), 30)
        ch.redraw()

    def test_axis_drag_zoom(self):
        ch = make_chart(bars=60)
        t = down(ch, 100, 3)                                      # dải trục giờ
        move(ch, t, 100 + 110, 3)
        up(ch, t)
        self.assertAlmostEqual(ch.bars, 60 * math.exp(-0.5), delta=2)

    def test_tap_crosshair_and_double_tap_reset(self):
        ch = make_chart(bars=60)
        t = down(ch, 120, 150); up(ch, t)
        self.assertIsNotNone(ch.cross)
        ch.redraw()                                               # vẽ crosshair không lỗi
        ch._last_tap = (0.0, 0.0, 0.0)
        t = down(ch, 120, 150); up(ch, t)                         # chạm lại đúng nến -> tắt
        self.assertIsNone(ch.cross)
        ch.bars, ch._off_f, ch.offset = 25, 30.0, 30
        ch._last_tap = (0.0, 0.0, 0.0)
        t = down(ch, 50, 50); up(ch, t)
        t = down(ch, 51, 51); up(ch, t)                           # chạm 2 lần
        self.assertEqual((ch.bars, ch.offset), (W.CandleChart.DEFAULT_BARS, 0))
        self.assertIsNone(ch.cross)

    def test_fling_inertia(self):
        ch = make_chart(bars=60)
        t = down(ch, 50, 150)
        move(ch, t, 90, 150)
        move(ch, t, 160, 150)
        move(ch, t, 250, 150)
        up(ch, t)
        self.assertIsNotNone(ch._fling_ev)
        off0 = ch.offset
        steps = 0
        while ch._fling_ev is not None and steps < 600:
            ch._fling_step(1 / 60.0)
            steps += 1
        self.assertGreater(ch.offset, off0)                       # trôi thêm sau khi nhả
        self.assertLess(steps, 600)                               # rồi dừng hẳn

    def test_mouse_wheel_and_latest_pill(self):
        ch = make_chart(bars=60)
        ch.on_touch_down(FT(200, 150, button="scrollup"))
        self.assertLess(ch.bars, 60)
        ch.set_offset(40)
        ch.redraw()
        self.assertIn("latest", ch._zones)
        zx, zy, zw, zh = ch._zones["latest"]
        ch._tap(zx + zw / 2, zy + zh / 2)
        self.assertEqual(ch.offset, 0)

    def test_view_stays_on_same_time_when_new_candle_arrives(self):
        cs = walk_candles(300)
        ch = W.CandleChart(size_hint_y=None, height=300)
        ch.x, ch.y, ch.width, ch.height = 0, 0, 360, 300
        ch.update(cs[-250:], {}, [], [])
        ch.bars = 60
        ch.set_offset(20)
        t_edge = ch.candles[-1 - ch.offset].time
        ch.update(cs[-249:] + [Candle(cs[-1].time + 300, 1, 2, 0.5, 1.5, 1)], {}, [], [])     # trượt 1 nến, cửa sổ vẫn 250
        self.assertEqual(ch.candles[-1 - ch.offset].time, t_edge)
        self.assertEqual(ch.offset, 21)

    def test_clip_runs(self):
        runs = W.clip_runs([(0, 0.0), (1, 10.0), (2, 0.0)], 2.0, 8.0)
        self.assertEqual(len(runs), 2)
        self.assertAlmostEqual(runs[0][0], 0.2)
        self.assertAlmostEqual(runs[0][2], 0.8)
        self.assertEqual(W.clip_runs([(0, 20.0), (1, 30.0)], 0.0, 10.0), [])
        self.assertEqual(len(W.clip_runs([(0, 1.0), (1, 2.0), (2, 3.0)], 0.0, 10.0)), 1)

    def test_draw_with_every_indicator(self):
        ch = make_chart(n=500, bars=80)
        ch.set_indicators([chind.new_cfg(k, i) for i, k in enumerate(chind.INDICATORS)])
        subs = sum(1 for c in ch.indicators if chind.INDICATORS[c["key"]].pane == "sub")
        self.assertEqual(ch.wanted_height(300), 300 + subs * (W.CandleChart.SUB_H + W.CandleChart.GAP))
        ch.height = ch.wanted_height(300)
        ch.redraw()                                               # vẽ cả 33 chỉ báo + crosshair không lỗi
        ch.cross = (ch.candles[-5].time, ch.candles[-5].close)
        ch.set_offset(100)
        ch.redraw()
        ch.cross = None
        ch.bars = 400
        ch.redraw()
        ch.indicators[0]["visible"] = False
        ch.redraw()


# ============================================================================ giao diện
class TestChartUI(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def app(self):
        import test_ui_smoke as T
        self.T = T
        return T.make_app()

    def test_tf_picker_lists_all_timeframes(self):
        app = self.app()
        tab = app.chart_tab
        tab.tf.open_grid()
        blob = self.T.texts(kivy_stub.OPEN_POPUPS[-1].content).split("\n")
        for tf in TIMEFRAMES:
            self.assertIn(tf, blob)
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "3h")
        self.assertEqual(tab.tf.text, "3h")
        tab.sym.text = "BTCUSD"
        tab._changed()
        self.assertEqual(app.chart_tf, "3h")
        self.assertFalse(kivy_stub.OPEN_POPUPS)                    # chọn xong tự đóng

    def test_no_button_bar_gestures_replace_it(self):
        app = self.app()
        blob = self.T.texts(app.chart_tab)
        for old in ("◀", "▶", "Mới nhất", "−"):
            self.assertNotIn("\n%s\n" % old, "\n" + blob + "\n")
        self.assertIn("chụm 2 ngón", blob)
        sv = [w for w in self.T.walk(app.chart_tab) if isinstance(w, W.GestureScrollView)]
        self.assertTrue(sv and app.chart_tab.panel.chart in sv[0].gesture_widgets)
        self.assertIs(app.chart_tab.panel.chart.scroll_parent, sv[0])

    def test_indicator_manager_add_edit_hide_delete_persist(self):
        app = self.app()
        panel = app.chart_tab.panel
        h0 = panel.height
        self.T.press(panel, "+ Chỉ báo")
        mgr = kivy_stub.OPEN_POPUPS[-1]
        blob = self.T.texts(mgr.content)
        for name in ("RSI", "MACD", "Bollinger Bands", "Ichimoku Kinko Hyo", "Parabolic SAR", "Alligator", "Volumes"):
            self.assertIn(name, blob)
        # thêm RSI (có tham số) -> hộp sửa -> Thêm
        self.T.press(mgr.content, "RSI")
        edit = kivy_stub.OPEN_POPUPS[-1]
        ins = self.T.inputs_of(edit.content)
        ins[0].text = "21"
        self.T.press(edit.content, "Thêm")
        self.assertEqual([(c["key"], c["params"]["period"]) for c in panel.chart.indicators], [("rsi", 21)])
        self.assertGreater(panel.height, h0)                       # cửa sổ phụ làm biểu đồ cao thêm
        # thêm Volumes (chỉ có ô Màu) -> thêm luôn, không hỏi
        self.T.press(kivy_stub.OPEN_POPUPS[0].content, "Volumes")
        self.assertEqual([c["key"] for c in panel.chart.indicators], ["rsi", "volumes"])
        # thêm MA trên biểu đồ giá: chiều cao không đổi thêm
        h_two = panel.height
        self.T.press(kivy_stub.OPEN_POPUPS[0].content, "Moving Average (MA)")
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Thêm")
        self.assertEqual(panel.height, h_two)
        self.assertIn("ƒ RSI(21)", self.T.texts(panel.chip_box))
        # lưu vào prefs và nạp lại ở lần mở sau
        saved = app.store.load_prefs()["chart"]["indicators"]
        self.assertEqual([c["key"] for c in saved], ["rsi", "volumes", "ma"])
        import pyea.ui as ui
        again = ui.ChartPanel(app, "chart", 300)
        self.assertEqual([(c["key"], c["params"]) for c in again.chart.indicators],
                         [(c["key"], c["params"]) for c in panel.chart.indicators])
        # ẩn bằng chip: cửa sổ phụ biến mất
        chips = [w for w in self.T.walk(panel.chip_box) if str(getattr(w, "text", "")).startswith("ƒ RSI")]
        for cb in chips[0]._binds["state"]:
            cb(chips[0], "normal")
        self.assertFalse(panel.chart.indicators[0]["visible"])
        self.assertLess(panel.height, h_two)
        # xoá
        self.T.press(kivy_stub.OPEN_POPUPS[0].content, "Xoá")
        self.assertEqual(len(panel.chart.indicators), 2)

    def test_bad_indicator_value_is_rejected(self):
        app = self.app()
        panel = app.chart_tab.panel
        panel.open_manager()
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "RSI")
        edit = kivy_stub.OPEN_POPUPS[-1]
        self.T.inputs_of(edit.content)[0].text = "abc"
        n = len(kivy_stub.OPEN_POPUPS)
        self.T.press(edit.content, "Thêm")
        self.assertEqual(panel.chart.indicators, [])
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n + 1)         # popup báo lỗi, hộp sửa vẫn mở

    def test_backtest_form_uses_grid_picker_for_timeframe(self):
        app = self.app()
        c = app.bt_tab.form.ctrl["timeframe"]
        self.assertIsInstance(c, W.PickButton)
        c.text = "12m"
        vals, errs = app.bt_tab.form.read()
        self.assertFalse(errs)
        self.assertEqual(vals["timeframe"], "12m")


class TestPopupReadable(unittest.TestCase):
    """Lỗi thật đã gặp: Popup(background="") vẽ hộp TRẮNG, chữ sáng của app thành 'mờ mờ' không đọc được."""

    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_no_popup_overrides_background(self):
        import ast
        for f in ("ui.py", "ui_widgets.py"):
            with open(os.path.join(HERE, "..", "pyea", f), encoding="utf-8") as fh:
                tree = ast.parse(fh.read())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "Popup":
                    self.assertNotIn("background", {k.arg for k in node.keywords}, "%s dòng %d" % (f, node.lineno))

    def test_three_buttons_are_stacked_not_overflowing(self):
        W.popup("Thoát ứng dụng", "Phiên đang chạy nền.", [("Huỷ", W.PANEL2, None), ("Thoát, bot chạy tiếp", W.BLUE, None),
                                                          ("Ngắt phiên & thoát", W.RED, None)], size=(0.95, 0.5))
        row = kivy_stub.OPEN_POPUPS[-1].content.children[0]
        self.assertEqual(row.orientation, "vertical")
        self.assertEqual(len(row.children), 3)
        W.popup("Hỏi", "ok?", [("Huỷ", W.PANEL2, None), ("Đồng ý", W.RED, None)])
        self.assertEqual(kivy_stub.OPEN_POPUPS[-1].content.children[0].orientation, "horizontal")   # 2 nút ngắn: vẫn 1 hàng

    def test_button_text_wraps_inside_button(self):
        b = W.mkbtn("Kiểm tra hệ thống", W.BLUE)
        for cb in b._binds["width"]:
            cb(b, 200)
        self.assertEqual(b.text_size, (200 - W.dp(8), None))
        self.assertEqual(b.halign, "center")


if __name__ == "__main__":
    unittest.main()

class TestDraftOrderOnChart(unittest.TestCase):
    """Đặt lệnh ngay trên biểu đồ như MT5 mobile: đường vào/SL/TP kéo được, loại lệnh tự suy ra."""
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def chart_with_draft(self, side="buy"):
        ch = make_chart()
        px = ch.candles[-1].close
        ch.draft = {"side": side, "price": px, "sl": 0.0, "tp": 0.0, "bid": px - 0.01, "ask": px}
        ch.redraw()
        return ch

    def test_drag_entry_line_changes_price_without_panning(self):
        ch = self.chart_with_draft()
        y = ch._pm.y(ch.draft["price"])
        off0, p0 = ch.offset, ch.draft["price"]
        seen = []
        ch.on_draft = lambda: seen.append(ch.draft["price"])
        t = down(ch, 100, y)
        move(ch, t, 100, y + 40)
        up(ch, t)
        self.assertNotEqual(ch.draft["price"], p0)
        self.assertEqual(ch.offset, off0)                       # kéo đường không làm lướt biểu đồ
        self.assertTrue(seen)
        self.assertAlmostEqual(ch.draft["price"], ch._pm.price(y + 40), places=6)

    def test_drag_sl_and_tp_independently(self):
        ch = self.chart_with_draft()
        px = ch.draft["price"]
        span = ch._pm.span()
        ch.set_draft_price("sl", px - span * 0.1)
        ch.set_draft_price("tp", px + span * 0.1)
        ch.redraw()
        sl0, tp0, e0 = ch.draft["sl"], ch.draft["tp"], ch.draft["price"]
        t = down(ch, 120, ch._pm.y(sl0))
        move(ch, t, 120, ch._pm.y(sl0) - 30)
        up(ch, t)
        self.assertNotEqual(ch.draft["sl"], sl0)
        self.assertEqual((ch.draft["tp"], ch.draft["price"]), (tp0, e0))

    def test_tap_empty_moves_entry_and_no_draft_means_old_behaviour(self):
        ch = self.chart_with_draft()
        y = ch._pm.y(ch.draft["price"]) + 90
        t = down(ch, 150, y)
        up(ch, t)
        self.assertAlmostEqual(ch.draft["price"], ch._pm.price(y), places=6)
        ch.draft = None
        ch.redraw()
        t = down(ch, 150, y)
        up(ch, t)
        self.assertIsNone(ch.draft)                              # không có lệnh nháp: chạm vẫn chỉ là crosshair

    def test_labelled_lines_draw_without_error(self):
        ch = make_chart()
        px = ch.candles[-1].close
        ch.update(ch.candles, {}, [], [(px, (1, 1, 1, 1)), (px * 0.999, (1, 0, 0, 1), "SL #3")])
        ch.redraw()

    def app(self):
        import test_ui_smoke as T
        self.T = T
        app = T.make_app()
        app.is_connected = lambda: True
        return app

    def test_panel_chips_kind_and_validation(self):
        app = self.app()
        panel = app.chart_tab.panel
        self.assertFalse(panel.start_draft("BTCUSD"))            # chưa có giá: không bật
        panel.set_prices(99.9, 100.0)
        panel.chart.x, panel.chart.y, panel.chart.width, panel.chart.height = 0, 0, 360, 300
        self.assertTrue(panel.start_draft("BTCUSD"))
        blob = self.T.texts(panel.draft_bar)
        for w in ("✕", "BUY", "SL", "TP", "→"):
            self.assertIn(w, blob)
        d = panel.chart.draft
        d["price"] = 98.0
        panel._draft_refresh()
        self.assertIn("BUY LIMIT", self.T.texts(panel.draft_bar))
        d["price"] = 102.0
        panel._draft_refresh()
        self.assertIn("BUY STOP", self.T.texts(panel.draft_bar))
        panel.toggle_side()
        self.assertEqual(d["side"], "sell")
        d["price"] = 101.0
        panel._draft_refresh()
        self.assertIn("SELL LIMIT", self.T.texts(panel.draft_bar))
        panel.chart.redraw()
        panel.toggle_level("sl")
        panel.toggle_level("tp")
        self.assertGreater(d["sl"], d["price"])                  # bán: SL trên giá vào
        self.assertLess(d["tp"], d["price"])
        panel.toggle_level("sl")
        self.assertEqual(d["sl"], 0.0)
        sent = []
        app.chart_order_send = lambda *a, **k: sent.append(a)
        d["sl"] = 99.0                                           # sai phía: bán mà SL dưới giá vào
        panel.send_draft()
        self.assertEqual(sent, [])
        d["sl"], d["tp"] = 103.0, 95.0
        panel.send_draft()
        self.assertEqual(sent[0][:6], ("BTCUSD", "sell", "limit", 101.0, 103.0, 95.0))
        panel.cancel_draft()
        self.assertFalse(panel.has_draft())

    def test_send_places_market_and_pending_via_controller(self):
        app = self.app()
        calls = []

        class Res:
            id, symbol, volume, open_price = 7, "BTCUSD", 0.01, 100.0

        class PRes:
            class order:
                id = 8
            price = 98.0

        class Ctl:
            def place_order(self, *a):
                calls.append(("order",) + a)
                return "ok", Res()

            def place_pending(self, *a):
                calls.append(("pending",) + a)
                return "ok", PRes()
        app.ctl = Ctl()
        app.settings["mode"], app.settings["testnet"] = "paper", False
        app.settings["confirm_trades"] = False
        done = []
        app.chart_order_send("BTCUSD", "buy", None, 100.0, 99.0, 102.0, on_done=lambda: done.append(1))
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.T.press(pop.content, "Gửi lệnh")
        self.assertEqual(calls[0][:2], ("order", "BTCUSD"))
        self.assertEqual(calls[0][-3:-1], (99.0, 102.0))
        self.assertEqual(done, [1])
        app.chart_order_send("BTCUSD", "buy", "limit", 98.0, 0.0, 0.0)
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Gửi lệnh")
        self.assertEqual(calls[1][:4], ("pending", "BTCUSD", "buy", "limit"))
        self.assertEqual(calls[1][5], 98.0)

    def test_live_account_asks_for_real_order_confirmation(self):
        app = self.app()
        app.settings["mode"], app.settings["testnet"] = "live", False
        app.ctl = object()
        app.chart_order_send("BTCUSD", "buy", None, 100.0, 0.0, 0.0)
        self.T.press(kivy_stub.OPEN_POPUPS[-1].content, "Gửi lệnh")
        self.assertIn("LỆNH THẬT", "".join(str(getattr(p, "title", "")) for p in kivy_stub.OPEN_POPUPS))

    def test_plus_button_requires_connection(self):
        app = self.app()
        app.is_connected = lambda: False
        msgs = []
        app.toast = msgs.append
        kivy_stub.OPEN_POPUPS.clear()
        app.chart_tab.toggle_draft()                           # 1.9.17: hộp thoại giải thích + nút «Kết nối» thay cho toast dễ bỏ sót
        self.assertEqual(msgs, [])
        self.assertIn("Chưa kết nối", kivy_stub.OPEN_POPUPS[-1].title)
        self.assertFalse(app.chart_tab.panel.has_draft())


class TestLanguage(unittest.TestCase):
    def tearDown(self):
        from pyea import i18n
        i18n.set_lang("vi")
        kivy_stub.OPEN_POPUPS.clear()

    def test_catalog_is_complete_and_choices_roundtrip(self):
        from pyea import i18n
        self.assertEqual(len(i18n.LANGS), 10)
        for k, row in i18n.CAT.items():
            self.assertEqual(len(row), len(i18n.LANGS) - 1, k)
            self.assertTrue(all(row), k)
        for c, _n in i18n.LANGS:
            self.assertEqual(i18n.code_of(i18n.label_of(c)), c)
        self.assertEqual(i18n.code_of("English (en)"), "en")
        self.assertEqual(i18n.code_of("rác"), "vi")
        self.assertEqual(i18n.code_of(None), "vi")

    def test_tr_translates_known_and_keeps_unknown(self):
        from pyea import i18n
        self.assertEqual(i18n.tr("Cài đặt"), "Cài đặt")               # mặc định tiếng Việt
        i18n.set_lang("English (en)")
        self.assertEqual(i18n.tr("Cài đặt"), "Settings")
        self.assertEqual(i18n.tr("chuỗi lạ chưa có trong bảng"), "chuỗi lạ chưa có trong bảng")
        self.assertEqual(i18n.tr(5), 5)
        i18n.set_lang("ru")
        self.assertEqual(i18n.tr("Huỷ"), "Отмена")

    def test_settings_has_language_choice_and_ui_follows(self):
        from pyea import i18n
        from pyea.settings import GLOBAL_INPUTS
        inp = GLOBAL_INPUTS["language"]
        self.assertIn("English (en)", inp.choices)
        self.assertEqual(inp.default, "Tiếng Việt (vi)")
        import test_ui_smoke as T
        i18n.set_lang("en")
        app = T.make_app()
        blob = T.texts(app.root) if hasattr(app, "root") else ""
        self.assertNotIn("Thị trường\n", blob + "\n") if blob else None
        app.settings["language"] = "Français (fr)"
        toasts = []
        app.toast = toasts.append
        app._commit_settings(True)
        self.assertEqual(i18n.lang(), "fr")
        self.assertTrue(toasts and "Redémarrez" in toasts[0] and "Khởi động lại" in toasts[0])
        self.assertEqual(app.store.load_settings()["language"], "Français (fr)")


class TestDrawingTools(unittest.TestCase):
    """Công cụ vẽ trên CandleChart: chạm 1-2 điểm tạo đối tượng neo (thời gian, giá), vẽ không lỗi, chạm trúng thì gọi callback, không đụng lệnh nháp."""
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def test_trend_needs_two_taps_and_anchors_to_time_and_price(self):
        ch = make_chart()
        ch.redraw()
        made = []
        ch.on_object = lambda kind, pts: made.append((kind, pts))
        ch.set_tool("trend")
        y1, y2 = ch._pm.y(ch.candles[-1].close), ch._pm.y(ch.candles[-1].close) + 50
        up(ch, down(ch, 120, y1))
        self.assertEqual(made, [])                               # mới một điểm
        up(ch, down(ch, 220, y2))
        self.assertEqual(len(made), 1)
        kind, pts = made[0]
        self.assertEqual((kind, len(pts)), ("trend", 2))
        self.assertAlmostEqual(pts[0][1], ch._pm.price(y1), places=6)
        self.assertLess(pts[0][0], pts[1][0])                    # điểm chạm bên phải có thời gian muộn hơn
        self.assertIsNone(ch.tool)                               # xong một hình thì thả công cụ

    def test_objects_draw_and_tap_selects_nearest(self):
        from pyea import drawings
        ch = make_chart()
        ch.redraw()
        c0, c1 = ch.candles[-30], ch.candles[-5]
        px = ch.candles[-1].close
        ch.objects = [drawings.new_object("hline", [(c0.time, px)]), drawings.new_object("trend", [(c0.time, px * 0.99), (c1.time, px * 1.01)]),
                      drawings.new_object("rect", [(c0.time, px * 0.98), (c1.time, px * 0.99)]), drawings.new_object("fib", [(c0.time, px * 0.97), (c1.time, px * 1.02)]),
                      drawings.new_object("text", [(c1.time, px)], "Hỗ trợ")]
        ch.redraw()                                              # vẽ đủ 5 loại không lỗi
        got = []
        ch.on_object_tap = got.append
        y = ch._pm.y(px)
        up(ch, down(ch, ch._x0 + ch._pw * 0.5, y + 2))
        self.assertEqual(len(got), 1)
        self.assertEqual(ch.selected, got[0]["id"])

    def test_no_tool_no_objects_keeps_old_tap_behaviour(self):
        ch = make_chart()
        ch.redraw()
        called = []
        ch.on_object, ch.on_object_tap = (lambda *a: called.append(a)), (lambda *a: called.append(a))
        up(ch, down(ch, 150, 100))
        self.assertEqual(called, [])


class TestCrosshairMode(unittest.TestCase):
    def _toggle(self, ch):
        z = ch._zones["cross"]
        t = down(ch, z[0] + z[2] / 2, z[1] + z[3] / 2)
        up(ch, t)

    def test_toggle_button_and_toast(self):
        ch = make_chart()
        msgs = []
        ch.on_toast = msgs.append
        self.assertFalse(ch.crosshair_mode)
        self._toggle(ch)
        self.assertTrue(ch.crosshair_mode)
        self.assertIn("BẬT", msgs[-1])
        ch.cross = (ch.candles[-1].time, 1.0)
        self._toggle(ch)
        self.assertFalse(ch.crosshair_mode)
        self.assertIsNone(ch.cross)                              # tắt chế độ -> xoá tiêu điểm
        self.assertIn("TẮT", msgs[-1])

    def test_drag_moves_crosshair_without_panning(self):
        ch = make_chart()
        self._toggle(ch)
        off0 = ch.offset
        t = down(ch, 100, 150)
        self.assertIsNotNone(ch.cross)
        c0 = ch.cross
        move(ch, t, 100 + ch._bw * 8, 120)
        up(ch, t)
        self.assertEqual(ch.offset, off0)                        # không lướt
        self.assertNotEqual(ch.cross, c0)                        # tiêu điểm đã dời
        ch.redraw()                                              # vẽ nhãn thời gian không lỗi

    def test_off_mode_still_pans(self):
        ch = make_chart()
        t = down(ch, 100, 150)
        move(ch, t, 100 + ch._bw * 10, 150)
        up(ch, t)
        self.assertGreater(ch.offset, 5)

    def test_pinch_still_zooms_in_crosshair_mode(self):
        ch = make_chart()
        self._toggle(ch)
        b0 = ch.bars
        a, b = down(ch, 150, 150), down(ch, 210, 150)
        move(ch, a, 100, 150)
        move(ch, b, 260, 150)
        up(ch, a)
        up(ch, b)
        self.assertNotEqual(ch.bars, b0)
