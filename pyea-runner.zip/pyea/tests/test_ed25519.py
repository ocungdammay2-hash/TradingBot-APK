"""Ed25519 thuần Python: vector RFC 8032 + đối chiếu thư viện chuẩn + đọc khoá."""
import base64
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import ed25519 as ed

# RFC 8032 mục 7.1 (TEST 1, 2, 3)
VECTORS = [
    ("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
     "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a", "",
     "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"),
    ("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
     "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c", "72",
     "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da085ac1e43e15996e458f3613d0f11d8c387b2eaeb4302aeeb00d291612bb0c00"),
    ("c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
     "fc51cd8e6218a0a38da47d4c8bbd5e39a19be1c7c0c4b6b2d1d5ab0b6c3b5c5e", "af82",
     None),                                                # TEST 3: chỉ kiểm tra khoá công khai ở nhánh cryptography
]


class TestVectors(unittest.TestCase):
    def test_rfc8032_pure_python(self):
        for sk, pk, msg, sig in VECTORS[:2]:
            seed = bytes.fromhex(sk)
            self.assertEqual(ed._py_public_key(seed).hex(), pk)
            self.assertEqual(ed._py_sign(seed, bytes.fromhex(msg)).hex(), sig)

    def test_public_api_matches_vectors(self):
        for sk, pk, msg, sig in VECTORS[:2]:
            seed = bytes.fromhex(sk)
            self.assertEqual(ed.public_key(seed).hex(), pk)
            self.assertEqual(ed.sign(seed, bytes.fromhex(msg)).hex(), sig)

    def test_empty_body_hash_constant_from_exness_docs(self):
        import hashlib
        self.assertEqual(ed.b64u(hashlib.sha256(b"").digest()), "47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU")


class TestCrossCheck(unittest.TestCase):
    def test_random_keys_and_messages_match_cryptography(self):
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        except Exception:
            self.skipTest("không có cryptography")
        for i in range(12):
            seed = os.urandom(32)
            msg = os.urandom(i * 17)
            k = Ed25519PrivateKey.from_private_bytes(seed)
            self.assertEqual(ed._py_sign(seed, msg), k.sign(msg))
            from cryptography.hazmat.primitives import serialization
            raw = k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            self.assertEqual(ed._py_public_key(seed), raw)
            k.public_key().verify(ed._py_sign(seed, msg), msg)     # người xác minh độc lập chấp nhận


class TestKeyLoading(unittest.TestCase):
    seed = bytes(range(32))

    def _pem(self):
        der = ed._PKCS8_PREFIX + self.seed
        b = base64.b64encode(der).decode()
        return "-----BEGIN PRIVATE KEY-----\n%s\n%s\n-----END PRIVATE KEY-----\n" % (b[:40], b[40:])

    def test_pem_pkcs8(self):
        self.assertEqual(ed.load_private_seed(self._pem()), self.seed)

    def test_pem_with_extra_whitespace_and_crlf(self):
        self.assertEqual(ed.load_private_seed("  \r\n" + self._pem().replace("\n", "\r\n") + "  "), self.seed)

    def test_hex_base64_base64url(self):
        self.assertEqual(ed.load_private_seed(self.seed.hex()), self.seed)
        self.assertEqual(ed.load_private_seed(base64.b64encode(self.seed).decode()), self.seed)
        self.assertEqual(ed.load_private_seed(ed.b64u(self.seed)), self.seed)
        self.assertEqual(ed.load_private_seed(base64.b64encode(ed._PKCS8_PREFIX + self.seed).decode()), self.seed)

    def test_rejects_bad_input_with_clear_vietnamese_message(self):
        for bad, frag in (("", "chưa nhập"), (None, "chưa nhập"), ("!!!không-phải-base64!!!", "không đọc được"), ("abc", "2 byte"),
                          ("-----BEGIN PRIVATE KEY-----\nAAAA\n-----END PRIVATE KEY-----", "PKCS#8"),
                          ("-----BEGIN ENCRYPTED PRIVATE KEY-----\nAAAA\n-----END ENCRYPTED PRIVATE KEY-----", "mật khẩu"),
                          (base64.b64encode(b"x" * 10).decode(), "10 byte")):
            with self.assertRaises(ValueError) as cm:
                ed.load_private_seed(bad)
            self.assertIn(frag, str(cm.exception))

    def test_real_openssl_style_pem_roundtrip(self):
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        except Exception:
            self.skipTest("không có cryptography")
        k = Ed25519PrivateKey.generate()
        pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        seed = ed.load_private_seed(pem)
        self.assertEqual(ed._py_sign(seed, b"hello"), k.sign(b"hello"))


if __name__ == "__main__":
    unittest.main()


class TestVerify(unittest.TestCase):
    def test_rfc_vectors_verify_both_paths(self):
        for sk, pk, msg, sig in VECTORS[:2]:
            m, p, g = bytes.fromhex(msg), bytes.fromhex(pk), bytes.fromhex(sig)
            self.assertTrue(ed._py_verify(p, m, g))
            self.assertTrue(ed.verify(p, m, g))
            self.assertFalse(ed._py_verify(p, m + b"x", g))
            bad = bytearray(g)
            bad[40] ^= 1
            self.assertFalse(ed._py_verify(p, m, bytes(bad)))
            self.assertFalse(ed.verify(p, m, bytes(bad)))

    def test_rejects_malformed_inputs(self):
        self.assertFalse(ed._py_verify(b"\x00" * 31, b"", b"\x00" * 64))
        self.assertFalse(ed._py_verify(b"\x01" * 32, b"", b"\x00" * 63))
