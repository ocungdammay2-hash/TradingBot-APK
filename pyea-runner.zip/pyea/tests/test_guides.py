import unittest

from pyea import guides, settings


class TestGuides(unittest.TestCase):
    def test_every_mt5ws_field_has_guide(self):
        keys = {k for k, _ in settings.SETTINGS_INPUTS} if hasattr(settings, "SETTINGS_INPUTS") else set()
        for k in ("mt5ws_login", "mt5ws_password", "mt5ws_uri", "mt5ws_url", "mt5ws_otp", "exchange"):
            g = guides.guide_for(k)
            self.assertTrue(g and g[0] and len(g[1]) > 80, k)
        self.assertIsNone(guides.guide_for("nope"))

    def test_guide_keys_exist_in_settings(self):
        src = open(settings.__file__, encoding="utf-8").read()
        for k in guides.GUIDES:
            self.assertIn('("%s"' % k, src, k)

    def test_overview_mentions_alternatives_and_demo(self):
        t = guides.MT5_OVERVIEW
        for w in ("DEMO", "web terminal", "metaapi", "exness", "investor"):
            self.assertIn(w, t)


if __name__ == "__main__":
    unittest.main()
