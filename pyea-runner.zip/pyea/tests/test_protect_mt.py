"""SL/TP NATIVE cho MetaTrader (MetaApi) - phần RIÊNG của MT: vị thế ảo mang ticket, đóng theo ticket (không FIFO), SL/TP đặt thẳng lên ticket
(POSITION_MODIFY), chỉ đụng vị thế có comment 'pyea', đóng ngoài app, netting.
Các kịch bản chung (đặt/idempotent/sửa/khớp SL-TP/khởi động lại...) đã chạy cho MT trong test_protect_contract.py.
Tài liệu đã đối chiếu: MQL5 TRADE_ACTION_SLTP (SL/TP là thuộc tính của vị thế), ENUM_DEAL_ENTRY (OUT = đóng); MetaApi: positions có comment/stopLoss/takeProfit,
trade POSITION_MODIFY cần positionId, GET history-deals/position/:id. Chưa có tài liệu nói rõ «0 = bỏ mức» và trường lý do của deal -> sàn giả theo quy ước MT5."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from test_protect_contract import MtH, near                  # noqa: E402
from pyea.bridges import BridgeError                          # noqa: E402

h = None


def setUpModule():
    global h
    h = MtH()


def tearDownModule():
    h.close()


class Base(unittest.TestCase):
    def setUp(self):
        h.reset()
        h.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING"
        self.tmp = tempfile.mkdtemp()
        self.s = h.session(self.tmp)
        h.tick(self.s, h.P0)
        self.core = h.core

    def open(self, vol=0.06, sl=1.0900, tp=1.1200, side="buy"):
        r = self.s.send_order(h.SYM, side, vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position

    def poll(self, s=None):
        s = s or self.s
        s._prot_next = 0.0
        s._check_protection()

    def modifies(self):
        return list(self.core.sltp_calls)


class TestTickets(Base):
    def test_virtual_positions_carry_the_exchange_ticket_and_keep_it_after_restart(self):
        a, b = self.open(), self.open()
        self.assertTrue(a.ref and b.ref and a.ref != b.ref)
        self.assertEqual({a.ref, b.ref}, set(self.core.positions))
        s2 = h.session(self.tmp)
        s2.account.restore(self.s.account.to_dict())
        self.assertEqual({p.ref for p in s2.account.positions.values()}, {a.ref, b.ref})

    def test_every_order_is_tagged_pyea_so_the_app_can_recognise_its_positions(self):
        a = self.open()
        self.assertTrue(self.core.positions[a.ref]["comment"].startswith("pyea"))

    def test_close_goes_to_the_stored_ticket_not_the_oldest_position(self):
        a, b = self.open(), self.open()                          # a mở trước (cũ nhất): FIFO sẽ đóng a
        self.assertTrue(self.s.close_position(b.id, "bot", "x"))
        self.assertEqual(set(self.core.positions), {a.ref})

    def test_close_of_a_ticket_that_is_gone_never_closes_another_position(self):
        a, b = self.open(), self.open()
        self.core.close(a.ref)                                   # a bị đóng tay trên MT
        r = self.s.close_position(a.id, "bot", "x")
        self.assertFalse(r)
        self.assertEqual(set(self.core.positions), {b.ref})      # FIFO cũ sẽ đóng nhầm b ở đây
        self.assertIn(b.id, self.s.account.positions)

    def test_positions_without_a_ticket_are_closed_the_old_way_and_never_get_native_levels(self):
        p = self.open()
        self.s.account.positions[p.id].ref = ""                  # vị thế cũ (lưu trước khi có ticket)
        self.poll()
        self.assertEqual(self.modifies(), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        h.tick(self.s, 1.0890, 1001.0)                           # vỏ tự canh SL như trước
        self.assertNotIn(p.id, self.s.account.positions)
        self.assertEqual(self.core.positions, {})


class TestOwnership(Base):
    def test_a_manual_position_with_levels_is_never_modified_or_cleared(self):
        pid, _, _ = self.core.open(h.SYM, "buy", 0.05, "")
        self.core.positions[pid]["sl"], self.core.positions[pid]["tp"] = 1.0500, 1.2500
        mine = self.open()
        self.poll()
        self.poll()
        self.assertEqual((self.core.positions[pid]["sl"], self.core.positions[pid]["tp"]), (1.0500, 1.2500))
        self.assertEqual([c[0] for c in self.modifies()], [mine.ref])

    def test_an_intent_that_points_at_a_foreign_ticket_is_refused(self):
        pid, _, _ = self.core.open(h.SYM, "buy", 0.05, "")
        res = self.s.broker.sync_protection(h.SYM, [{"pid": 9, "ref": pid, "side": "sell", "qty": 0.05, "sl": 1.0900, "tp": 1.1200}])
        self.assertEqual(res["covered"], {})
        self.assertTrue(any("không phải do app mở" in e for e in res["errors"]))
        self.assertEqual(self.modifies(), [])

    def test_an_intent_for_a_vanished_ticket_is_reported_not_guessed(self):
        res = self.s.broker.sync_protection(h.SYM, [{"pid": 9, "ref": "424242", "side": "sell", "qty": 0.05, "sl": 1.0900, "tp": 1.1200}])
        self.assertEqual(res["covered"], {})
        self.assertTrue(any("không còn trên sàn" in e for e in res["errors"]))

    def test_the_exchange_refusing_the_levels_leaves_the_watch_to_the_shell(self):
        p = self.open()
        self.core.reject_next = ("10016", "Invalid stops")
        self.poll()
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        h.tick(self.s, 1.0890, 1001.0)                           # sàn từ chối -> vỏ vẫn tự canh và đóng
        self.assertNotIn(p.id, self.s.account.positions)


class TestPositionLevels(Base):
    def test_levels_are_set_on_the_ticket_with_one_modify_call(self):
        p = self.open()
        self.poll()
        self.assertEqual(self.modifies(), [(p.ref, 1.0900, 1.1200)])
        self.assertEqual((self.core.positions[p.ref]["sl"], self.core.positions[p.ref]["tp"]), (1.0900, 1.1200))
        self.poll()
        self.assertEqual(len(self.modifies()), 1)

    def test_only_sl_leaves_tp_to_the_shell_and_clears_nothing_else(self):
        p = self.open(sl=1.0900, tp=0.0)
        self.poll()
        self.assertEqual(self.modifies(), [(p.ref, 1.0900, 0.0)])
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        self.assertFalse(self.s.prot_covered(p.id, "tp"))

    def test_changing_a_level_ends_with_the_new_levels_on_the_ticket(self):
        p = self.open()
        self.poll()
        self.assertTrue(self.s.modify_position(p.id, sl=1.0950, tp=1.1250))
        self.poll()
        self.assertEqual(self.modifies()[-1], (p.ref, 1.0950, 1.1250))
        self.assertTrue(self.s.prot_covered(p.id, "sl") and self.s.prot_covered(p.id, "tp"))

    def test_levels_rounded_by_the_exchange_do_not_cause_endless_modify(self):
        p = self.open(sl=1.09000, tp=1.12000)
        self.poll()
        self.core.positions[p.ref]["sl"] = 1.09000 + 1e-9        # sàn làm tròn lệch rất nhỏ
        n = len(self.modifies())
        self.poll()
        self.assertEqual(len(self.modifies()), n)

    def test_partial_close_keeps_the_levels_and_the_final_fill_uses_only_the_last_deal(self):
        p = self.open(vol=0.06)
        self.poll()
        h.exchange_price(1.1050)                                 # giá khác để deal đóng một phần có giá riêng
        self.assertTrue(self.s.close_position(p.id, "bot", "một phần", volume=0.02))
        self.assertEqual(self.core.positions[p.ref]["volume"], 0.04)
        self.poll()
        self.poll()
        self.assertTrue(self.s.prot_covered(p.id, "sl"))
        self.assertEqual((self.core.positions[p.ref]["sl"], self.core.positions[p.ref]["tp"]), (1.0900, 1.1200))
        h.fire("sl", 1.0900)                                     # SL chạm: deal đóng cuối 0.04 @ 1.0900, deal trước 0.02 @ 1.1050
        self.poll()
        self.assertNotIn(p.id, self.s.account.positions)
        tr = self.s.account.trades[-1]
        self.assertTrue(near(tr.close_price, 1.0900), tr.close_price)       # không bị giá của lần đóng một phần kéo lệch
        self.assertAlmostEqual(tr.volume, 0.04, 8)


class TestExternalClose(Base):
    def test_closed_by_hand_on_mt_is_booked_as_manual_at_the_deal_price(self):
        p = self.open()
        self.poll()
        h.exchange_price(1.1050)
        self.core.close(p.ref)                                   # người dùng đóng tay trên MT ở giữa hai mức
        n = h.writes()
        self.poll()
        self.assertNotIn(p.id, self.s.account.positions)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, "manual")
        self.assertIn("NGOÀI app", ev.reason)
        self.assertTrue(near(self.s.account.trades[-1].close_price, 1.1050))
        self.assertEqual(h.writes(), n)                          # vỏ không gửi lệnh nào
        self.assertEqual(self.s.reconcile_now(), [])

    def test_a_gap_through_the_stop_is_booked_as_stop_loss_at_the_real_fill_price(self):
        p = self.open()
        self.poll()
        pos = self.core.positions.pop(p.ref)                     # giá nhảy qua SL: khớp ở 1.0850 (xấu hơn mức đặt 1.0900)
        self.core._deal("S1", h.SYM, "sell", pos["volume"], 1.0850, -50.0, pos_id=p.ref, entry="OUT")
        self.poll()
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, "sl")
        self.assertTrue(near(self.s.account.trades[-1].close_price, 1.0850))

    def test_history_not_synced_yet_is_asked_again_next_round(self):
        p = self.open()
        self.poll()
        pos = self.core.positions.pop(p.ref)                     # vị thế mất nhưng lịch sử CHƯA có deal đóng
        self.poll()
        self.assertIn(p.id, self.s.account.positions)            # chưa kết luận gì
        self.core._deal("S2", h.SYM, "sell", pos["volume"], 1.0900, -10.0, pos_id=p.ref, entry="OUT")
        self.poll()
        self.assertNotIn(p.id, self.s.account.positions)


class TestSupport(Base):
    def netting_session(self):
        h.api.margin_mode = "ACCOUNT_MARGIN_MODE_RETAIL_NETTING"
        h.core.hedging = False
        s = h.session(tempfile.mkdtemp())
        h.tick(s, h.P0)
        self.assertTrue(s.broker.netting)
        self.assertTrue(s.broker.prot_supported())
        return s

    def test_netting_a_virtual_position_that_is_the_whole_ticket_gets_native_levels(self):
        try:
            s = self.netting_session()
            r = s.send_order(h.SYM, "buy", 0.06, 1.0900, 1.1200)
            self.assertTrue(r, r.message)
            self.poll(s)
            self.assertEqual(self.modifies(), [(r.position.ref, 1.09, 1.12)])
            self.assertTrue(s.prot_covered(r.position.id, "sl"))
        finally:
            h.core.hedging = True

    def test_netting_merged_ticket_is_never_given_one_virtual_positions_levels(self):
        """Hai vị thế ảo cùng nằm trong MỘT ticket gộp: SL/TP trên sàn là của cả ticket -> KHÔNG gắn mức của vị thế nào (app tự canh), mức cũ bị gỡ."""
        try:
            s = self.netting_session()
            a = s.send_order(h.SYM, "buy", 0.06, 1.0900, 1.1200).position
            self.poll(s)
            self.assertEqual(self.modifies(), [(a.ref, 1.09, 1.12)])
            b = s.send_order(h.SYM, "buy", 0.06, 1.0500, 1.1500).position
            self.assertEqual(a.ref, b.ref)                       # sàn cộng vào cùng ticket
            self.poll(s)
            self.assertEqual(self.modifies()[-1], (a.ref, 0.0, 0.0))          # mức của A (chỉ phủ nửa ticket) bị gỡ
            self.assertFalse(s.prot_covered(a.id, "sl"))
            self.assertFalse(s.prot_covered(b.id, "sl"))
            self.assertEqual(self.core.positions[a.ref]["sl"], 0.0)
            self.assertTrue(any("lớn hơn vị thế ảo" in m for _, _, lv, m in s.logs))
        finally:
            h.core.hedging = True

    def test_backend_without_position_modify_is_not_supported(self):
        s = h.session(tempfile.mkdtemp())
        s.broker.b.can_modify_position = False                   # vd cổng/EA không có POSITION_MODIFY
        h.tick(s, h.P0)
        self.assertFalse(s.broker.prot_supported())
        p = s.send_order(h.SYM, "buy", 0.06, 1.0900, 1.1200).position
        self.poll(s)
        self.assertFalse(s.prot_covered(p.id, "sl"))
        self.assertEqual(self.modifies(), [])


if __name__ == "__main__":
    unittest.main()
