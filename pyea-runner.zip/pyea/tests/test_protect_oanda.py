"""SL/TP NATIVE cho OANDA: lệnh STOP (SL) / LIMIT (TP) với positionFill=REDUCE_ONLY, bậc thang theo mã (protect.py + OandaBroker.sync_protection).
Dùng sàn OANDA GIẢ (tests/fake_exchanges.FakeOandaX). Phần tài liệu v20 đã đối chiếu: OrderPositionFill, LimitOrderRequest/StopOrderRequest,
Order.cancellingTransactionID (lý do huỷ nằm trong OrderCancelTransaction)."""
import os
import sys
import tempfile
import unittest
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_exchanges import FakeOandaX                        # noqa: E402
from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.broker import BrokerError, OandaBroker             # noqa: E402
from pyea.engine import Account, TradingSession              # noqa: E402
from pyea.feeds import _oanda_tradeable                      # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402

SYM = "EUR_USD"


def make(fx, state_dir=None, **over):
    st = default_settings()
    st.update(mode="paper", exchange="oanda", initial_balance=1_000_000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0, native_sltp=True, native_sync_s=1.0, reconcile_interval=0)
    st.update(over)
    sf = os.path.join(state_dir, "state.json") if state_dir else None
    s = TradingSession(st, sync=True, feed=_ReplayFeed(), state_file=sf)
    s.events = deque(maxlen=10000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    s.watch = [SYM]
    s.broker = OandaBroker(fx.TOKEN, fx.ACC, fx.base)
    s.broker.prepare(SYM)
    s.sync = False                                           # phiên «live»: test tự gọi _check_protection
    return s


def tk(s, price, t=1000.0):
    s.process_tick(Tick(SYM, t, price, price))


def poll(s):
    s._prot_next = 0.0
    s._check_protection()


def pend(fx):
    return [dict(o, id=k) for k, o in fx.orders.items() if o["state"] == "PENDING"]


def posts(fx, suffix="/orders"):
    return [c for c in fx.calls if c[0] == "POST" and c[1].endswith(suffix)]


def view(fx):
    return {(o["type"], o["units"], o["price"], o["positionFill"]) for o in pend(fx)}


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fx = FakeOandaX()

    @classmethod
    def tearDownClass(cls):
        cls.fx.close()

    def setUp(self):
        self.fx.reset()
        self.tmp = tempfile.mkdtemp()
        self.s = make(self.fx, self.tmp)
        tk(self.s, 1.1000)

    def open(self, vol, sl=0.0, tp=0.0, side="buy"):
        r = self.s.send_order(SYM, side, vol, sl, tp)
        self.assertTrue(r, r.message)
        return r.position


class TestLadder(Base):
    def test_levels_become_reduce_only_stop_and_limit_orders(self):
        p = self.open(1000, 1.0900, 1.1200)
        self.assertFalse(self.s.prot_covered(p.id, "sl"))                      # vừa mở: chưa bảo vệ -> vỏ tự canh
        poll(self.s)
        self.assertEqual(view(self.fx), {("STOP", "-1000", "1.09000", "REDUCE_ONLY"), ("LIMIT", "-1000", "1.12000", "REDUCE_ONLY")})
        for o in pend(self.fx):
            self.assertEqual((o["timeInForce"], o["triggerCondition"]), ("GTC", "DEFAULT"))
            self.assertTrue(o["clientExtensions"]["id"].startswith("pyeaP"))
        self.assertTrue(self.s.prot_covered(p.id, "sl") and self.s.prot_covered(p.id, "tp"))
        n = len(posts(self.fx))
        poll(self.s)
        poll(self.s)
        self.assertEqual(len(posts(self.fx)), n)                                # idempotent

    def test_same_level_positions_are_aggregated(self):
        a, b = self.open(600, 1.0900), self.open(400, 1.0900, 1.1300)
        poll(self.s)
        stops = [o for o in pend(self.fx) if o["type"] == "STOP"]
        self.assertEqual([(o["units"], o["price"]) for o in stops], [("-1000", "1.09000")])
        self.assertTrue(all(self.s.prot_covered(p.id, "sl") for p in (a, b)))
        self.assertFalse(self.s.prot_covered(a.id, "tp"))

    def test_short_position_uses_buy_orders(self):
        self.open(500, 1.1100, 1.0800, side="sell")
        poll(self.s)
        self.assertEqual(view(self.fx), {("STOP", "500", "1.11000", "REDUCE_ONLY"), ("LIMIT", "500", "1.08000", "REDUCE_ONLY")})

    def test_foreign_orders_are_never_touched(self):
        mine = self.s.broker.place_pending(SYM, "buy", "limit", 100, 1.0500)       # lệnh chờ của app (clientExtensions.id 'pyea...')
        self.fx.orders["999"] = {"type": "LIMIT", "instrument": SYM, "units": "-50", "price": "1.20000", "positionFill": "REDUCE_ONLY",
                                 "timeInForce": "GTC", "triggerCondition": "DEFAULT", "state": "PENDING", "clientExtensions": {"id": "my-own"}}
        p = self.open(1000, 1.0900)
        poll(self.s)
        poll(self.s)
        self.assertEqual(self.fx.orders["999"]["state"], "PENDING")
        self.assertEqual(self.fx.orders[mine]["state"], "PENDING")
        self.assertEqual(len(pend(self.fx)), 3)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))

    def test_units_are_floored_to_whole_units(self):
        self.fx.pos = 1000.0
        r = self.s.broker.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 1.09, "qty": 1000.9}])
        self.assertEqual(view(self.fx), {("STOP", "-1000", "1.09000", "REDUCE_ONLY")})
        self.assertEqual(r["covered"], [0])
        self.assertEqual(self.s.broker.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 1.09, "qty": 0.6}])["live"], [])


class TestOwnership(Base):
    def test_covered_level_is_not_closed_by_the_shell(self):
        p = self.open(1000, 1.0900, 1.1200)
        poll(self.s)
        n = len(posts(self.fx))
        tk(self.s, 1.0890, 1001.0)                                              # giá xuyên SL nhưng sàn canh -> vỏ không đóng
        self.assertIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx)), n)

    def test_rejected_protection_leaves_the_shell_watching(self):
        p = self.open(1000, 1.0900)
        self.fx.reject_pending = True                                           # sàn từ chối STOP/LIMIT (lệnh thị trường vẫn khớp)
        poll(self.s)
        self.assertEqual(pend(self.fx), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        self.assertTrue(any("vẫn tự canh" in m and "STOP_LOSS_ON_FILL_LOSS" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        tk(self.s, 1.0890, 1001.0)
        self.assertNotIn(p.id, self.s.account.positions)                        # vỏ đóng bằng lệnh thị trường REDUCE_ONLY (không bị bộ lọc chặn)
        self.assertEqual(self.fx.pos, 0.0)

    def test_bot_close_cancels_protection_before_market_close(self):
        p = self.open(1000, 1.0900, 1.1200)
        poll(self.s)
        self.fx.calls.clear()
        self.assertTrue(self.s.close_position(p.id, "bot", "đóng tay"))
        seq = [(c[0], c[1].split("/")[-1] if c[0] == "PUT" else c[3].get("order", {}).get("type")) for c in self.fx.calls if c[0] in ("PUT", "POST")]
        cancels = [i for i, c in enumerate(seq) if c[0] == "PUT" and c[1] == "cancel"]
        market = [i for i, c in enumerate(seq) if c[0] == "POST" and c[1] == "MARKET"]
        self.assertEqual(len(cancels), 2, seq)
        self.assertTrue(market and max(cancels) < min(market), seq)
        self.assertEqual(pend(self.fx), [])
        self.assertEqual(self.fx.pos, 0.0)

    def test_modify_sl_replaces_the_order(self):
        p = self.open(1000, 1.0900)
        poll(self.s)
        self.assertTrue(self.s.modify_position(p.id, sl=1.0910))
        self.assertFalse(self.s.prot_covered(p.id, "sl"))
        poll(self.s)
        self.assertEqual(view(self.fx), {("STOP", "-1000", "1.09100", "REDUCE_ONLY")})
        self.assertTrue(self.s.prot_covered(p.id, "sl"))


class TestFills(Base):
    def test_sl_fill_is_booked_without_sending_any_order(self):
        p = self.open(1000, 1.0900, 1.1200)
        poll(self.s)
        sl_id = [o["id"] for o in pend(self.fx) if o["type"] == "STOP"][0]
        n = len(posts(self.fx))
        self.fx.fill(sl_id, 1.0895)                                             # sàn khớp lệnh bảo vệ -> vị thế sàn về 0
        poll(self.s)
        self.assertNotIn(p.id, self.s.account.positions)
        self.assertEqual(len(posts(self.fx)), n)                                # vỏ KHÔNG gửi thêm lệnh nào
        tr = self.s.account.trades[-1]
        self.assertAlmostEqual(tr.profit, (1.0895 - 1.1000) * 1000, 6)
        ev = [e for e in self.s.events if e.kind == "close"][-1]
        self.assertEqual(ev.source, "sl")
        self.assertIn("NATIVE", ev.reason)
        self.assertIn("STOP REDUCE_ONLY", ev.reason)                            # nhãn lấy từ broker (PROT_LABEL)
        self.assertEqual(pend(self.fx), [])                                     # lệnh TP còn lại bị huỷ ngay vòng đó
        self.assertEqual(self.s.reconcile_now(), [])

    def test_tp_fill_keeps_other_position_protected(self):
        a, b = self.open(300, 1.0800, 1.1100), self.open(200, 1.0800, 1.1300)
        poll(self.s)
        tp = [o["id"] for o in pend(self.fx) if o["type"] == "LIMIT" and o["price"] == "1.11000"][0]
        self.fx.fill(tp, 1.1100)
        poll(self.s)
        self.assertNotIn(a.id, self.s.account.positions)
        self.assertIn(b.id, self.s.account.positions)
        self.assertAlmostEqual(self.s.account.trades[-1].profit, 0.0100 * 300, 6)
        self.assertEqual(view(self.fx), {("STOP", "-200", "1.08000", "REDUCE_ONLY"), ("LIMIT", "-200", "1.13000", "REDUCE_ONLY")})
        self.assertTrue(self.s.prot_covered(b.id, "sl") and self.s.prot_covered(b.id, "tp"))
        self.assertEqual(self.s.reconcile_now(), [])

    def test_fill_while_app_was_off_is_booked_after_restart(self):
        p = self.open(1000, 1.0900)
        poll(self.s)
        state = self.s.account.to_dict()
        self.fx.fill(pend(self.fx)[0]["id"], 1.0890)                           # app tắt, sàn khớp lệnh bảo vệ
        s2 = make(self.fx, self.tmp)
        s2.account.restore(state)
        tk(s2, 1.0890, 2000.0)
        poll(s2)
        self.assertNotIn(p.id, s2.account.positions)
        self.assertEqual(s2.account.trades[-1].close_price, 1.0890)
        self.assertEqual(s2.reconcile_now(), [])

    def test_restart_with_live_orders_does_not_duplicate(self):
        p = self.open(1000, 1.0900, 1.1200)
        poll(self.s)
        state = self.s.account.to_dict()
        s2 = make(self.fx, self.tmp)
        s2.account.restore(state)
        tk(s2, 1.1000, 2000.0)
        n = len(posts(self.fx))
        poll(s2)
        self.assertEqual(len(posts(self.fx)), n)
        self.assertTrue(s2.prot_covered(p.id, "sl") and s2.prot_covered(p.id, "tp"))

    def test_order_canceled_externally_is_replaced(self):
        p = self.open(1000, 1.0900)
        poll(self.s)
        self.fx.cancel_external(pend(self.fx)[0]["id"], "CLIENT_REQUEST")       # ai đó huỷ tay trên web/app sàn
        poll(self.s)
        self.assertTrue(any("bị sàn huỷ" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        self.assertEqual(len(pend(self.fx)), 1)
        self.assertTrue(self.s.prot_covered(p.id, "sl"))

    def test_expired_reason_is_read_from_the_cancel_transaction(self):
        self.open(1000, 1.0900)
        poll(self.s)
        self.fx.cancel_external(pend(self.fx)[0]["id"], "TIME_IN_FORCE_EXPIRED")
        poll(self.s)
        self.assertTrue(any("hết hạn" in m for _, _, lv, m in self.s.logs if lv == "WARN"))


class TestSwitchesAndBroker(Base):
    def test_turning_off_removes_orders(self):
        p = self.open(1000, 1.0900)
        poll(self.s)
        self.assertEqual(len(pend(self.fx)), 1)
        self.s.settings["native_sltp"] = False
        poll(self.s)
        self.assertEqual(pend(self.fx), [])
        self.assertFalse(self.s.prot_covered(p.id, "sl"))

    def test_sync_protection_errors_are_reported_per_order(self):
        b = self.s.broker
        self.fx.pos = 1000.0
        d = [{"kind": "sl", "side": "sell", "trigger": 1.09, "qty": 1000}, {"kind": "tp", "side": "sell", "trigger": 1.12, "qty": 1000}]
        r = b.sync_steps(SYM, d)
        self.assertEqual((len(r["live"]), r["covered"], r["errors"]), (2, [0, 1], []))
        r2 = b.sync_steps(SYM, d[:1])
        self.assertEqual((len(r2["live"]), r2["covered"]), (1, [0]))
        self.fx.reject_pending = True
        r3 = b.sync_steps(SYM, [{"kind": "sl", "side": "sell", "trigger": 1.05, "qty": 1000}])
        self.assertEqual(r3["covered"], [])
        self.assertIn("STOP_LOSS_ON_FILL_LOSS", r3["errors"][0])
        self.assertEqual(pend(self.fx), [])                                     # lệnh cũ (không còn trong desired) đã bị huỷ

    def test_oanda_tradeable_prefers_status_over_legacy_flag(self):
        self.assertTrue(_oanda_tradeable({"status": "tradeable"}))
        self.assertFalse(_oanda_tradeable({"status": "non-tradeable", "tradeable": True}))
        self.assertFalse(_oanda_tradeable({"status": "invalid"}))
        self.assertTrue(_oanda_tradeable({"tradeable": True}))
        self.assertFalse(_oanda_tradeable({"tradeable": False}))
        self.assertTrue(_oanda_tradeable({}))                                    # thiếu cả hai: không chặn nhầm

    def test_brokererror_is_raised_not_leaked_as_http_error(self):
        b = OandaBroker("wrong", self.fx.ACC, self.fx.base)
        with self.assertRaises(BrokerError):
            b.protection_orders(SYM)


if __name__ == "__main__":
    unittest.main()
