"""API CẤP PHÁT tài khoản MetaApi GIẢ (provisioning), đúng theo tài liệu chính thức đã đọc (xem pyea/mt5quick.py).
Chưa so với dịch vụ thật. Dùng cho tests/test_mt5quick.py."""
import json
import re
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeProvisioning:
    TOKEN = "tok-" + "x" * 30
    GOOD = {"login": "50194988", "password": "Secret#1", "server": "ICMarketsSC-Demo"}

    def __init__(self, region="vint-hill", detect_polls=0, connect_after=1, id_override=None, region_in_account=True):
        self.region, self.detect_polls, self.connect_after = region, detect_polls, connect_after
        self.accounts = {}
        self.requests = []
        self.tx_seen = []
        self.pending = {}                    # tx -> số lần đã trả 202
        self.polls = {}
        self.id_override = id_override
        self.region_in_account = region_in_account
        self.create_state = "UNDEPLOYED"
        self.servers = {"ICMarketsSC-Demo", "Exness-MT5Real8"}
        self.fail_code = None                # ép lỗi cụ thể khi tạo: "E_SERVER_TIMEZONE"...
        self.never_connect = False
        self.lock = threading.Lock()
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, obj, code=200, headers=None):
                b = json.dumps(obj).encode() if obj is not None else b""
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                for k, v in (headers or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(b)

            def _h(self, m):
                u = urllib.parse.urlparse(self.path)
                q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n)) if n else {}
                with fake.lock:
                    fake.requests.append((m, u.path, q, body))
                    if self.headers.get("auth-token") != fake.TOKEN:
                        return self._send({"id": 1, "error": "UnauthorizedError", "message": "Authorization failed"}, 401)
                    code, obj, hd = fake.route(m, u.path, q, body, self.headers.get("transaction-id"))
                self._send(obj, code, hd)

            def do_GET(self):
                self._h("GET")

            def do_POST(self):
                self._h("POST")
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.base = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()

    # ------------------------------------------------------------------ định tuyến
    def route(self, m, p, q, b, tx):
        if p == "/users/current/accounts" and m == "GET":
            qq = q.get("query", "")
            return 200, [self._pub(i, a) for i, a in self.accounts.items() if qq in (i, a["name"], a["server"], a["login"])], {}
        if p == "/users/current/accounts" and m == "POST":
            return self._create(b, tx)
        mm = re.match(r"^/users/current/accounts/([^/]+)(/deploy)?$", p)
        if mm:
            i = mm.group(1)
            if i not in self.accounts:
                return 404, {"id": 5, "error": "NotFoundError", "message": "Trading account not found"}, {}
            a = self.accounts[i]
            if mm.group(2) and m == "POST":
                a["state"] = "DEPLOYED"
                return 204, None, {}
            if not mm.group(2) and m == "GET":
                self.polls[i] = self.polls.get(i, 0) + 1
                if a["state"] == "DEPLOYED" and not self.never_connect and self.polls[i] >= self.connect_after:
                    a["connectionStatus"] = "CONNECTED"
                return 200, self._pub(i, a), {}
        return 404, {"message": "no route %s %s" % (m, p)}, {}

    def _pub(self, i, a):
        d = {"_id": i, "login": a["login"], "name": a["name"], "server": a["server"], "magic": a["magic"], "state": a["state"],
             "connectionStatus": a["connectionStatus"], "type": "cloud-g2", "platform": a["platform"]}
        if self.region_in_account:
            d["region"] = self.region
        return d

    def _create(self, b, tx):
        if not tx or not re.fullmatch(r"[0-9a-f]{32}", tx):
            return 400, {"id": 3, "error": "ValidationError", "message": "transaction-id must be 32 chars"}, {}
        self.tx_seen.append(tx)
        for k in ("name", "server", "magic"):
            if k not in b:
                return 400, {"id": 3, "error": "ValidationError", "message": "%s is required" % k}, {}
        if self.fail_code == "E_SERVER_TIMEZONE":
            return 400, {"id": 3, "error": "ValidationError", "message": "Broker settings could not be retrieved", "details": "E_SERVER_TIMEZONE"}, {}
        if b["server"] not in self.servers:
            return 400, {"id": 3, "error": "ValidationError", "message": "Server file not found",
                         "details": {"code": "E_SRV_NOT_FOUND", "serversByBrokers": {"IC Markets": ["ICMarketsSC-Demo", "ICMarketsSC-Live"]}}}, {}
        n = self.pending.get(tx, 0)
        if n < self.detect_polls:
            self.pending[tx] = n + 1
            return 202, {"message": "Automatic broker settings detection is in progress, please retry in 60 seconds."}, {"Retry-After": "1"}
        if b.get("login") != self.GOOD["login"] or b.get("password") != self.GOOD["password"]:
            return 400, {"id": 3, "error": "ValidationError", "message": "We failed to authenticate to your broker using credentials provided.",
                         "details": "E_AUTH"}, {}
        i = self.id_override or "acc-%d" % (len(self.accounts) + 1)
        self.accounts[i] = {"login": b["login"], "name": b["name"], "server": b["server"], "magic": b["magic"], "platform": b.get("platform", ""),
                            "state": self.create_state, "connectionStatus": "DISCONNECTED"}
        return 201, {"id": i, "state": self.create_state}, {}
