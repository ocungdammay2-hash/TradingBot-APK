"""Luật biểu thức (rules), ánh xạ mã webhook, tối ưu di truyền/Monte Carlo nối UI."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pyea import rules, webhook                                 # noqa: E402
from pyea.sdk import Candle                                     # noqa: E402


def cs(closes):
    return [Candle(i, c, c + 1, c - 1, c, 10) for i, c in enumerate(closes)]


class TestRules(unittest.TestCase):
    def test_cross_and_none(self):
        up = cs([10] * 30 + [8, 8, 8, 8, 16])
        self.assertTrue(rules.compile_rule("cross_above(sma(close,2), sma(close,5))").truth(up))
        self.assertFalse(rules.compile_rule("cross_below(sma(close,2), sma(close,5))").truth(up))
        self.assertFalse(rules.compile_rule("sma(close,50) > 0").truth(up))        # thiếu dữ liệu = sai
        self.assertIsNone(rules.compile_rule("sma(close,50)").evaluate(up))

    def test_arith_prev_logic(self):
        c = cs([1, 2, 3, 4, 5, 6])
        self.assertEqual(rules.compile_rule("close - prev(close, 2)").evaluate(c), 2)
        self.assertTrue(rules.compile_rule("close > 5 and not (close < 1) or false").truth(c))
        self.assertTrue(rules.compile_rule("highest(high, 3) == 7").truth(c))
        self.assertIsNone(rules.compile_rule("close / 0").evaluate(c))

    def test_bands_macd_atr(self):
        c = cs([100 + (i % 7) for i in range(80)])
        self.assertTrue(rules.compile_rule("bb_upper(close,20,2) > bb_lower(close,20,2)").truth(c))
        self.assertIsNotNone(rules.compile_rule("macd(close,12,26,9) - macd_signal(close,12,26,9)").evaluate(c))
        self.assertGreater(rules.compile_rule("atr(14)").evaluate(c), 0)

    def test_rejects_unsafe(self):
        for bad in ("__import__('os').system('x')", "close.__class__", "open('f')", "sma(close, 3, key=1)", "[1,2]", "'abc'",
                    "lambda: 1", "foo(1)", "x + 1", "", "1 +", "sma(5, 3)", "a" * 500):
            ok, why = rules.check(bad)
            if bad == "sma(5, 3)":                                  # hợp lệ cú pháp nhưng lỗi lúc chạy: nguồn phải là chuỗi giá
                with self.assertRaises(rules.RuleError):
                    rules.compile_rule(bad).evaluate(cs([1] * 10))
                continue
            self.assertFalse(ok, bad)
            self.assertTrue(why)

    def test_example_bot_loads_and_runs(self):
        import shutil
        import tempfile
        from pyea.loader import inspect_bot
        src = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "pyea", "examples", "rule_bot.py.txt")
        d = tempfile.mkdtemp()
        try:
            path = os.path.join(d, "rule_bot.py")
            shutil.copy(src, path)
            info = inspect_bot(path)
            self.assertTrue(info.ok, getattr(info, "error", ""))
            self.assertIn("entry_long", info.inputs)
        finally:
            shutil.rmtree(d, ignore_errors=True)


class TestWebhookMapping(unittest.TestCase):
    def test_normalize(self):
        n = webhook.normalize_symbol
        self.assertEqual(n("BINANCE:BTCUSDT.P"), "BTCUSDT")
        self.assertEqual(n("OANDA:EURUSD", suffix=".m"), "EURUSD.m")
        self.assertEqual(n("OANDA:EURUSD.m", suffix=".m"), "EURUSD.M")        # không thêm đôi hậu tố
        self.assertEqual(n("XAUUSD", {"xauusd": "GOLD"}), "GOLD")
        self.assertEqual(n("BINANCE:BTCUSDT", {"BINANCE:BTCUSDT": "BTCUSD"}), "BTCUSD")
        self.assertEqual(n("BTCUSDT1!"), "BTCUSDT")
        self.assertEqual(n("HOSE:VNM"), "VNM")

    def _core(self, **kw):
        got = []
        core = webhook.WebhookCore(lambda o: got.append(o) or {"ok": True}, "s" * 16, **kw)
        return core, got

    def test_alias_qty_and_map(self):
        core, got = self._core(symbol_map={"BINANCE:BTCUSDT": "BTCUSD"}, allowed_symbols=["BTCUSD"])
        body = json.dumps({"secret": "s" * 16, "action": "LONG", "symbol": "BINANCE:BTCUSDT", "qty": 0.5}).encode()
        st, r = core.handle(body)
        self.assertEqual(st, 200, r)
        self.assertEqual(got[0]["action"], "buy")
        self.assertEqual(got[0]["symbol"], "BTCUSD")
        self.assertEqual(got[0]["volume"], 0.5)
        st, r = core.handle(json.dumps({"secret": "s" * 16, "action": "flat", "symbol": "BINANCE:BTCUSDT"}).encode())
        self.assertEqual((st, got[1]["action"]), (200, "close"))

    def test_symbol_denied_after_mapping(self):
        core, _ = self._core(allowed_symbols=["EURUSD"])
        st, r = core.handle(json.dumps({"secret": "s" * 16, "action": "buy", "symbol": "OANDA:GBPUSD", "volume": 1}).encode())
        self.assertEqual(st, 403)

    def test_session_executor(self):
        calls = []

        class R:
            retcode, message = "OK", ""

            def __bool__(self):
                return True

        class S:
            def open_position(self, *a, **k):
                calls.append(("open", a))
                return R()

            def close_all(self, source, reason, symbol=None, owner=None):
                calls.append(("close_all", symbol))
                return 2
        ex = webhook.session_executor(S())
        self.assertTrue(ex({"action": "buy", "symbol": "BTCUSD", "volume": 0.1, "sl": 1, "tp": 2, "comment": "tv"})["ok"])
        self.assertEqual(ex({"action": "close", "symbol": "BTCUSD"})["closed"], 2)
        self.assertEqual(calls[1], ("close_all", "BTCUSD"))
        self.assertEqual(calls[0][1][0:3], ("BTCUSD", "buy", 0.1))


class TestUiWiring(unittest.TestCase):
    def test_montecarlo_text_on_fake_trades(self):
        import types
        from pyea import mcarlo
        tr = [types.SimpleNamespace(profit=p, close_time=1700000000 + i * 86400 * 20, open_time=1700000000, sl=0, tp=0, volume=1, open_price=100)
              for i, p in enumerate([5, -3, 4, -2, 6, -1, 3])]
        ex = mcarlo.extra_stats(tr, 1000.0)
        self.assertIsInstance(ex["Theo tháng"], list)
        self.assertTrue(mcarlo.monte_carlo(tr, 1000.0, 200, "bootstrap", seed=1)["ok"])

    def test_ui_source_has_hooks(self):
        src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "pyea", "ui.py"), encoding="utf-8").read()
        for needle in ("genetic.optimize_genetic", "def montecarlo_dialog", "GEN_METHOD", "mcarlo.monte_carlo_text"):
            self.assertIn(needle, src)


if __name__ == "__main__":
    unittest.main()
