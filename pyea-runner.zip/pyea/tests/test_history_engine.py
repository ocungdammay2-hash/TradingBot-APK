"""Bộ máy lịch sử CHUNG (pyea/histengine.py + hồ sơ dữ liệu pyea/histprofiles.py): «sàn mới chỉ cần một hồ sơ JSON, không viết mã».

(1) engine thuần: thời gian/đường dẫn/đặc tả trường/điều kiện/mẫu tham số, kiểm hồ sơ (kể cả chốt CHỈ ĐỌC), phân trang các kiểu, theo mã, nguồn tuỳ chọn,
    dựng vị thế cho sàn netting; (2) OANDA / Binance Futures / ccxt chạy hồ sơ có sẵn qua sàn GIẢ có phân trang; (3) sàn thứ ba ZetaX CHỈ cấu hình bằng JSON
    (dán ở Cài đặt, hoặc nhúng trong cầu nối); (4) ưu tiên hồ sơ người dùng > nhúng > có sẵn; (5) giao diện hiện «Ghi chú về số liệu»."""
import json
import os
import sys
import time
import types
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import brokerhist as bh, ccxt_adapter, histengine as H, histprofiles as P       # noqa: E402
from pyea.broker import BrokerError, make_broker                                           # noqa: E402
from fake_exchanges import FakeBinanceX, FakeOandaX, FakeZetaX                             # noqa: E402

DAY = 86400.0


def strip(deals, *keys):
    return [{k: d[k] for k in keys} for d in deals]


def simple_profile(**over):
    p = {"name": "t", "sources": [{"id": "s", "path": "/x", "records": "", "emit": [
        {"kind": "trade", "entry": "IN", "map": {"id": "id", "time": "t", "symbol": "sym", "side": "side", "qty": "q", "price": "p"}}]}]}
    p["sources"][0].update(over)
    return p


def row(i, t, side="buy", sym="AAA", q=1.0, p=10.0, **kw):
    return dict({"id": i, "t": t, "sym": sym, "side": side, "q": q, "p": p}, **kw)


# ------------------------------------------------------------------------------------------------------------------ 1. engine thuần
class TestEnginePieces(unittest.TestCase):
    def test_parse_time_units_iso_and_offsets(self):
        self.assertEqual(H.parse_time(1700000000), 1700000000.0)
        self.assertEqual(H.parse_time("1700000000123"), 1700000000.123)               # auto: mili-giây
        self.assertEqual(H.parse_time(1700000000.5, "s"), 1700000000.5)
        self.assertEqual(H.parse_time(1700000000123, "ms"), 1700000000.123)
        self.assertEqual(H.parse_time("2023-11-14T22:13:20Z"), 1700000000.0)
        self.assertEqual(H.parse_time("2023-11-14T22:13:20.000000000Z"), 1700000000.0)
        self.assertEqual(H.parse_time("2023-11-15T05:13:20+07:00"), 1700000000.0)     # múi giờ được trừ đúng chiều
        self.assertEqual(H.parse_time("2023-11-14T17:13:20-0500"), 1700000000.0)
        self.assertEqual(H.parse_time("1700000000.000000000"), 1700000000.0)          # kiểu UNIX của OANDA
        for bad in (None, "", "abc", True, [], {}):
            self.assertEqual(H.parse_time(bad), 0.0)

    def test_render_keeps_type_for_whole_templates_and_formats_time(self):
        v = {"since": 1700000000.0, "symbol": "BTC", "account": "A1", "quote": "USDT"}
        self.assertEqual(H.render("{since:ms}", v), 1700000000000)
        self.assertEqual(H.render("{since:s}", v), 1700000000)
        self.assertEqual(H.render("{since:iso}", v), "2023-11-14T22:13:20Z")
        self.assertEqual(H.render("{since:iso9}", v), "2023-11-14T22:13:20.000000000Z")
        self.assertEqual(H.render("/a/{account}/x?s={symbol}", v), "/a/A1/x?s=BTC")
        self.assertEqual(H.render({"k": ["{quote}", 5]}, v), {"k": ["USDT", 5]})
        self.assertEqual(H.render("{nope}", v), "")

    def test_field_specs(self):
        rec = {"a": "-5.5", "s": "SELL", "n": None, "dir": "out", "p": {"x": "7"}, "units": "-100", "f": {"cost": "0.2", "cur": "USDT"}}
        par = {"fee": "0.4"}
        v = lambda spec, **k: H._value(spec, rec, par, {"quote": "USDT"}, **k)       # noqa: E731
        self.assertEqual(v("a"), "-5.5")
        self.assertEqual(v("p.x"), "7")
        self.assertEqual(v("^fee"), "0.4")
        self.assertEqual(v(["zzz", "n", "a"]), "-5.5")                                # thay thế: bỏ qua thiếu/None
        self.assertEqual(v({"path": "a", "abs": True}), 5.5)
        self.assertEqual(v({"path": "a", "neg": True}), 5.5)
        self.assertEqual(v({"path": "a", "scale": 2}), -11.0)
        self.assertEqual(v({"path": "a", "abs": True, "neg_if": {"field": "dir", "eq": "out"}}), -5.5)
        self.assertEqual(v({"path": "a", "abs": True, "neg_if": {"field": "dir", "eq": "in"}}), 5.5)
        self.assertEqual(v({"path": "units", "sign": ["buy", "sell"]}), "sell")
        self.assertEqual(v({"path": "s", "lower": True}), "sell")
        self.assertEqual(v({"path": "s", "map": {"buy": "B", "sell": "S"}}), "S")
        self.assertEqual(v({"path": "s", "map": {"buy": "B"}, "default": "?"}), "?")
        self.assertEqual(v({"path": "zzz", "default": "d"}), "d")
        self.assertEqual(v({"const": "K"}), "K")
        self.assertEqual(H._value({"path": "s", "prefix": "<", "suffix": ":{i}>"}, rec, par, {}, 3), "<SELL:3>")
        self.assertEqual(v({"path": "f.cost", "only_if": {"field": "f.cur", "eq": "{quote}"}}), "0.2")
        self.assertIsNone(v({"path": "f.cost", "only_if": {"field": "f.cur", "eq": "BNB"}}))
        once = set()
        self.assertEqual(H._value({"path": "^fee", "once": True}, rec, par, {}, 0, once, "commission"), "0.4")
        self.assertIsNone(H._value({"path": "^fee", "once": True}, rec, par, {}, 1, once, "commission"))   # chỉ gắn vào deal ĐẦU của bản ghi

    def test_conditions(self):
        rec = {"t": "ORDER_FILL", "n": "0", "amt": "3", "x": None, "s": "Hello World", "b": True}
        c = lambda cond: H._cond(cond, rec, None, {"quote": "USDT"})                   # noqa: E731
        self.assertTrue(c({"field": "t", "eq": "order_fill"}))                        # không phân biệt hoa thường
        self.assertTrue(c({"field": "t", "in": ["X", "ORDER_FILL"]}))
        self.assertTrue(c({"field": "t", "nin": ["X"]}))
        self.assertFalse(c({"field": "n", "ne": 0}))
        self.assertTrue(c({"field": "amt", "ne": 0}))
        self.assertFalse(c({"field": "missing", "ne": 0}))                            # thiếu = 0 (quy ước ghi trong docstring)
        self.assertTrue(c({"field": "amt", "gt": 2}))
        self.assertFalse(c({"field": "amt", "lt": 2}))
        self.assertFalse(c({"field": "missing", "gt": 1}))
        self.assertTrue(c({"field": "s", "regex": "^Hello"}))
        self.assertTrue(c({"field": "s", "contains": "world"}))
        self.assertTrue(c({"field": "x", "exists": False}))
        self.assertTrue(c({"field": "t", "exists": True}))
        self.assertTrue(c({"field": "b", "eq": True}))
        self.assertTrue(c([{"field": "t", "eq": "ORDER_FILL"}, {"field": "amt", "gt": 1}]))
        self.assertFalse(c([{"field": "t", "eq": "ORDER_FILL"}, {"field": "amt", "gt": 9}]))
        self.assertTrue(c({"any": [{"field": "t", "eq": "no"}, {"field": "amt", "gt": 1}]}))
        self.assertTrue(c({"not": {"field": "t", "eq": "no"}}))
        self.assertTrue(c({"field": ["zz", "t"], "eq": "ORDER_FILL"}))                # danh sách đường dẫn thay thế
        self.assertTrue(c({"field": "t", "eq": "{quote}"}) is False)


class TestValidation(unittest.TestCase):
    def test_builtin_profiles_are_valid_json_data(self):
        for name, prof in P.BUILTIN.items():
            self.assertEqual(H.validate_profile(prof), [], name)
            self.assertEqual(json.loads(json.dumps(prof)), prof, name)                # chỉ là DỮ LIỆU (JSON thuần), không có mã

    def test_typos_and_missing_parts_are_reported_in_plain_words(self):
        bad = simple_profile()
        bad["sources"][0]["emit"][0]["map"]["simbol"] = "sym"
        bad["sources"][0]["emit"][0]["map"].pop("time")
        e = " | ".join(H.validate_profile(bad))
        self.assertIn("simbol", e)
        self.assertIn("thiếu «time»", e)
        self.assertIn("«sources»", " ".join(H.validate_profile({"name": "x"})))
        self.assertIn("khoá lạ", " ".join(H.validate_profile({"sourcez": 1, "sources": simple_profile()["sources"]})))
        self.assertIn("kiểu phân trang", " ".join(H.validate_profile(simple_profile(paging={"type": "magic"}))))
        self.assertIn("cursor cần «next»", " ".join(H.validate_profile(simple_profile(paging={"type": "cursor"}))))
        self.assertIn("«time»", " ".join(H.validate_profile(simple_profile(paging={"type": "window", "start": "s", "limit": 5}))))
        self.assertIn("kind", " ".join(H.validate_profile(_with_emit(kind="loan"))))
        self.assertIn("entry", " ".join(H.validate_profile(_with_emit(entry="SIDEWAYS"))))
        dup = simple_profile()
        dup["sources"].append(dict(dup["sources"][0]))
        self.assertIn("trùng", " ".join(H.validate_profile(dup)))

    def test_history_profile_is_read_only(self):
        """Hồ sơ do người dùng dán không được thành đường đặt/sửa/huỷ lệnh: POST bị chặn, đường dẫn tuyệt đối bị chặn."""
        e = " ".join(H.validate_profile(simple_profile(method="POST", path="/order")))
        self.assertIn("POST bị chặn", e)
        self.assertEqual(H.validate_profile(simple_profile(method="POST", path="/q", query_post=True)), [])
        self.assertIn("bắt đầu bằng", " ".join(H.validate_profile(simple_profile(path="orders"))))
        self.assertIn("địa chỉ đầy đủ", " ".join(H.validate_profile(simple_profile(path="/x?u=http://evil/"))))
        self.assertIn("bắt đầu bằng", " ".join(H.validate_profile(simple_profile(path="https://evil.example/x"))))
        with self.assertRaises(H.HistoryError):
            H.fetch_deals(simple_profile(method="POST", path="/order"), lambda *a: {}, 0)

    def test_parse_profiles_keeps_valid_drops_invalid_and_never_raises(self):
        good = simple_profile()
        ok, errs = H.parse_profiles(json.dumps({"a": good, "b": {"sources": []}}))
        self.assertEqual(list(ok), ["a"])
        self.assertTrue(any(e.startswith("«b»") for e in errs))
        self.assertEqual(H.parse_profiles("")[0], {})
        self.assertIn("JSON không hợp lệ", H.parse_profiles("{oops")[1][0])
        self.assertIn("đối tượng", H.parse_profiles("[1]")[1][0])


def _with_emit(**kw):
    p = simple_profile()
    p["sources"][0]["emit"][0].update(kw)
    return p


class TestPagingKinds(unittest.TestCase):
    def run_src(self, pages, **src):
        """`pages(method, path, params, body)` -> JSON. Trả (kết quả, danh sách lời gọi)."""
        calls = []

        def call(m, path, params, body):
            calls.append((m, path, dict(params or {}), body))
            return pages(m, path, params or {}, body)
        r = H.fetch_deals(simple_profile(**src), call, 1000.0, 2000.0)
        return r, calls

    def test_none_extracts_records_from_nested_path_and_filters_by_period(self):
        r, calls = self.run_src(lambda *a: {"data": {"rows": [row("1", 1500), row("2", 5000), row("3", 10)]}}, records="data.rows")
        self.assertEqual([d["id"] for d in r["deals"]], ["1"])                       # ngoài kỳ [since, until] bị loại
        self.assertEqual(len(calls), 1)

    def test_window_splits_long_period_and_respects_exchange_max_days(self):
        seen = []

        def pages(m, path, p, body):
            seen.append((p["s"], p["e"]))
            return []
        calls = []
        H.fetch_deals(simple_profile(paging={"type": "window", "days": 7, "start": "s", "end": "e", "unit": "ms"}),
                      lambda m, pa, p, b: (calls.append(p), pages(m, pa, p, b))[1], 0.0 + 1000 * DAY, 1000 * DAY + 20 * DAY)
        self.assertEqual(len(calls), 3)                                              # 20 ngày / cửa sổ 7 ngày
        for p in calls:
            self.assertLessEqual((p["e"] - p["s"]) / 1000.0, 7 * DAY)
        for a, b in zip(calls, calls[1:]):
            self.assertLess(b["s"] - a["e"], 5)                                      # nối liền (chỉ cách 1 mili-giây), không để hở giữa hai cửa sổ

    def test_window_full_page_continues_from_last_time_and_dedupes(self):
        data = [row(str(i), 1100 + i) for i in range(5)]                             # 5 dòng, trang tối đa 2
        calls = []

        def call(m, path, p, body):
            calls.append(dict(p))
            lo = p["s"]
            return [r for r in data if r["t"] >= lo][:p["lim"]]
        r = H.fetch_deals(simple_profile(paging={"type": "window", "start": "s", "unit": "s", "limit": 2, "limit_param": "lim", "time": "t", "days": 7}),
                          call, 1000.0, 2000.0)
        self.assertEqual([d["id"] for d in r["deals"]], ["0", "1", "2", "3", "4"])   # đủ, không trùng dù mốc lật trang lặp dòng cuối
        self.assertGreaterEqual(len(calls), 3)

    def test_cursor_follows_next_until_exhausted(self):
        data = [row(str(i), 1100 + i) for i in range(5)]

        def pages(m, path, p, body):
            c = int(p.get("cur", 0))
            return {"rows": data[c:c + 2], "next": str(c + 2) if c + 2 < len(data) else None}
        r, calls = self.run_src(pages, paging={"type": "cursor", "param": "cur", "next": "next"}, records="rows")
        self.assertEqual(len(r["deals"]), 5)
        self.assertEqual([c[2].get("cur") for c in calls], [None, "2", "4"])

    def test_page_number_stops_on_short_page(self):
        data = [row(str(i), 1100 + i) for i in range(5)]
        r, calls = self.run_src(lambda m, p_, p, b: data[(p["page"] - 1) * 2: p["page"] * 2],
                                paging={"type": "page", "param": "page", "limit": 2, "limit_param": "per"})
        self.assertEqual(len(r["deals"]), 5)
        self.assertEqual([c[2]["page"] for c in calls], [1, 2, 3])
        self.assertTrue(all(c[2]["per"] == 2 for c in calls))

    def test_from_id_advances_by_last_id(self):
        data = [dict(row(str(i), 1100 + i), id=i) for i in range(1, 6)]

        def pages(m, path, p, body):
            f = int(p.get("fromId", 0))
            return [r for r in data if r["id"] >= f][:2]
        r, calls = self.run_src(pages, paging={"type": "from_id", "param": "fromId", "id": "id", "limit": 2, "plus_one": True})
        self.assertEqual(sorted(d["id"] for d in r["deals"]), ["1", "2", "3", "4", "5"])

    def test_page_urls_fetches_every_listed_page_with_relative_paths(self):
        def pages(m, path, p, body):
            if path == "/x":
                return {"pages": ["https://host.example/v3/p?from=1&to=2", "https://host.example/v3/p?from=3&to=4"]}
            return {"records": [row(path[-1], 1100 + int(path[-1]))]}
        r, calls = self.run_src(pages, paging={"type": "page_urls", "urls": "pages"}, records="records")
        self.assertEqual([c[1] for c in calls], ["/x", "/v3/p?from=1&to=2", "/v3/p?from=3&to=4"])
        self.assertEqual(len(r["deals"]), 2)

    def test_runaway_exchange_is_capped_and_told(self):
        n = [0]

        def pages(m, p_, p, b):
            n[0] += 1
            return {"rows": [row(str(n[0]), 1100 + n[0] % 500)], "next": "again"}
        r, calls = self.run_src(pages, paging={"type": "cursor", "param": "c", "next": "next"}, records="rows")
        self.assertEqual(len(calls), 100)                                            # max_pages mặc định
        self.assertTrue(any("giới hạn an toàn" in n for n in r["notes"]))

    def test_global_call_budget(self):
        prof = simple_profile(paging={"type": "page", "param": "page", "limit": 1})
        prof["max_calls"] = 3
        calls = []
        r = H.fetch_deals(prof, lambda m, p_, p, b: (calls.append(1), [row(str(len(calls)), 1100)])[1], 1000.0, 2000.0)
        self.assertEqual(len(calls), 3)
        self.assertTrue(any("giới hạn an toàn" in n for n in r["notes"]))


class TestSymbolsAndSources(unittest.TestCase):
    def test_per_symbol_unions_discovered_and_watch_and_dedupes(self):
        prof = {"name": "t", "sources": [
            {"id": "led", "path": "/led", "records": "", "discover_symbols": "sym", "emit": [{"when": {"field": "kind", "eq": "cash"}, "kind": "balance", "map": {"id": "id", "time": "t", "profit": "amt"}}]},
            {"id": "f", "path": "/f", "params": {"sym": "{symbol}"}, "per_symbol": {"from": ["discovered", "watch"]}, "records": "", "emit": simple_profile()["sources"][0]["emit"]}]}
        asked = []

        def call(m, path, p, body):
            if path == "/led":
                return [{"id": "c1", "t": 1500, "kind": "cash", "amt": 5, "sym": "BBB"}, {"id": "x", "t": 1500, "kind": "fee", "sym": "AAA"}, {"id": "y", "t": 1500, "kind": "fee", "sym": "BBB"}]
            asked.append(p["sym"])
            return [row("%s1" % p["sym"], 1500, sym=p["sym"])]
        r = H.fetch_deals(prof, call, 1000.0, 2000.0, {"symbols": ["CCC", "AAA"]})
        self.assertEqual(asked, ["BBB", "AAA", "CCC"])                               # khám phá trước, rồi danh sách theo dõi; AAA không trùng
        self.assertEqual(len([d for d in r["deals"] if d["kind"] == "trade"]), 3)

    def test_per_symbol_without_any_symbol_makes_no_calls_and_says_so(self):
        prof = simple_profile(per_symbol={"from": ["watch"]})
        calls = []
        r = H.fetch_deals(prof, lambda *a: calls.append(a), 1000.0, 2000.0, {})
        self.assertEqual((r["deals"], calls), ([], []))
        self.assertTrue(any(n.startswith(H.WARN) and "theo từng mã" in n for n in r["notes"]))

    def test_symbol_cap_is_announced(self):
        prof = simple_profile(per_symbol={"from": ["watch"], "max": 2})
        asked = []
        r = H.fetch_deals(prof, lambda m, p_, p, b: (asked.append(1), [])[1], 1000.0, 2000.0, {"symbols": ["A", "B", "C", "D"]})
        self.assertEqual(len(asked), 2)
        self.assertTrue(any("chỉ đọc 2 mã" in n for n in r["notes"]))

    def test_required_failure_raises_but_optional_only_adds_a_note(self):
        def boom(*a):
            raise BrokerError("HTTP 401 permissions")
        with self.assertRaises(BrokerError):
            H.fetch_deals(simple_profile(), boom, 1000.0, 2000.0)
        r = H.fetch_deals(simple_profile(required=False, note_fail="kiểm tra quyền"), boom, 1000.0, 2000.0)
        self.assertEqual(r["deals"], [])
        n = [x for x in r["notes"] if "Không đọc được nguồn" in x][0]
        self.assertTrue(n.startswith(H.WARN))
        self.assertIn("401", n)
        self.assertIn("kiểm tra quyền", n)

    def test_optional_failure_does_not_stop_the_other_sources(self):
        prof = {"name": "t", "sources": [dict(simple_profile()["sources"][0], id="a", required=False), dict(simple_profile()["sources"][0], id="b", path="/b")]}

        def call(m, path, p, body):
            if path == "/x":
                raise BrokerError("down")
            return [row("ok", 1500)]
        r = H.fetch_deals(prof, call, 1000.0, 2000.0)
        self.assertEqual([d["id"] for d in r["deals"]], ["ok"])
        self.assertEqual(r["sources"]["b"]["deals"], 1)

    def test_needs_capability_skips_with_note_but_unknown_capabilities_still_try(self):
        prof = simple_profile(needs="fetchLedger")
        calls = []
        r = H.fetch_deals(prof, lambda *a: calls.append(a) or [], 1000.0, 2000.0, {"capabilities": {"fetchMyTrades"}})
        self.assertEqual(calls, [])
        self.assertTrue(any("fetchLedger" in n for n in r["notes"]))
        H.fetch_deals(prof, lambda *a: calls.append(a) or [], 1000.0, 2000.0, {})
        self.assertEqual(len(calls), 1)
        H.fetch_deals(prof, lambda *a: calls.append(a) or [], 1000.0, 2000.0, {"capabilities": {"fetchLedger": True}})
        self.assertEqual(len(calls), 2)

    def test_default_period_when_since_is_zero(self):
        got = []
        H.fetch_deals(simple_profile(paging={"type": "window", "days": 7, "start": "s", "end": "e", "unit": "s"}), lambda m, p_, p, b: (got.append(p), [])[1], 0)
        self.assertAlmostEqual(time.time() - got[0]["s"], 7 * DAY, delta=60)


class TestEmitting(unittest.TestCase):
    def test_each_expands_children_and_once_attaches_parent_cost_to_first_only(self):
        prof = {"name": "t", "sources": [{"id": "s", "path": "/x", "records": "", "emit": [
            {"each": "legs", "kind": "trade", "entry": "OUT", "map": {"id": {"path": "^id", "suffix": ":{i}"}, "time": "^t", "symbol": "^sym", "side": "^side",
                                                                     "qty": "q", "price": "p", "position_id": "pos", "profit": "pnl",
                                                                     "commission": {"path": "^fee", "neg": True, "once": True}}}]}]}
        rec = {"id": "F", "t": 1500, "sym": "AAA", "side": "sell", "fee": "0.6", "legs": [{"q": 1, "p": 5, "pos": "P1", "pnl": 2}, {"q": 2, "p": 5, "pos": "P2", "pnl": 3}]}
        r = H.fetch_deals(prof, lambda *a: [rec], 1000.0, 2000.0)
        self.assertEqual(strip(r["deals"], "id", "position_id", "profit", "commission"),
                         [{"id": "F:0", "position_id": "P1", "profit": 2.0, "commission": -0.6}, {"id": "F:1", "position_id": "P2", "profit": 3.0, "commission": 0.0}])

    def test_fallback_runs_only_when_nothing_else_matched(self):
        em = simple_profile()["sources"][0]["emit"][0]
        prof = simple_profile(emit=[dict(em, each="legs", entry="IN"), dict(em, fallback=True, entry="")])
        r = H.fetch_deals(prof, lambda *a: [dict(row("a", 1500), legs=[{"id": "a", "t": 1500, "sym": "AAA", "side": "buy", "q": 1, "p": 1}]), row("b", 1600)], 1000.0, 2000.0)
        self.assertEqual({d["id"]: d["entry"] for d in r["deals"]}, {"a": "IN", "b": ""})

    def test_kind_classification_by_map_and_unknown_falls_back_to_classify(self):
        prof = simple_profile(emit=[{"kind": {"path": "type", "map": {"dep": "balance", "wd": "balance", "bonus": "credit"}, "default": "other"},
                                     "map": {"id": "id", "time": "t", "profit": "amt"}}])
        r = H.fetch_deals(prof, lambda *a: [{"id": "1", "t": 1500, "type": "dep", "amt": 5}, {"id": "2", "t": 1500, "type": "bonus", "amt": 1}, {"id": "3", "t": 1500, "type": "zzz", "amt": 2}],
                          1000.0, 2000.0)
        self.assertEqual({d["id"]: d["kind"] for d in r["deals"]}, {"1": "balance", "2": "credit", "3": "other"})

    def test_bad_rows_are_dropped_with_a_count_not_invented(self):
        rows = [row("ok", 1500), dict(row("nt", 1500), t=None), dict(row("ns", 1500), side="zzz"), dict(row("nq", 1500), q=0)]
        r = H.fetch_deals(simple_profile(), lambda *a: rows, 1000.0, 2000.0)
        self.assertEqual([d["id"] for d in r["deals"]], ["ok"])
        blob = " ".join(r["notes"])
        self.assertIn("không đọc được thời gian", blob)
        self.assertIn("thiếu mã/chiều/khối lượng", blob)

    def test_duplicate_ids_from_overlapping_windows_are_not_double_counted(self):
        r = H.fetch_deals(simple_profile(), lambda *a: [row("1", 1500), row("1", 1500, p=11.0)], 1000.0, 2000.0)
        self.assertEqual(len(r["deals"]), 1)

    def test_output_obeys_the_deal_contract_and_is_sorted(self):
        r = H.fetch_deals(simple_profile(), lambda *a: [row("2", 1600), row("1", 1500)], 1000.0, 2000.0)
        self.assertEqual([d["id"] for d in r["deals"]], ["1", "2"])
        from pyea import contract
        self.assertEqual(contract.check_history_deals(r["deals"]), [])


class TestNetting(unittest.TestCase):
    def d(self, i, t, side, q, entry="", pnl=0.0, fee=0.0, group="", sym="X"):
        return {"id": str(i), "time": t, "kind": "trade", "symbol": sym, "side": side, "qty": q, "price": 100.0, "entry": entry, "position_id": "",
                "profit": pnl, "commission": fee, "swap": 0.0, "fee": 0.0, "order_id": "", "comment": "", "group": group}

    def test_open_add_reduce_close_then_reopen_makes_two_positions(self):
        out = H.apply_netting([self.d(1, 1, "buy", 1), self.d(2, 2, "buy", 1), self.d(3, 3, "sell", 1, pnl=5), self.d(4, 4, "sell", 1, pnl=6),
                               self.d(5, 5, "sell", 2)], {"key": ["symbol"]})
        self.assertEqual([(d["entry"], d["position_id"]) for d in out], [("IN", "X#1"), ("IN", "X#1"), ("OUT", "X#1"), ("OUT", "X#1"), ("IN", "X#2")])
        rows = bh.positions_from_deals([dict(d, kind="trade") for d in out])
        by = {r["position_id"]: r for r in rows}
        self.assertEqual(list(by), ["X#1"])                                         # X#2 còn mở -> không phải lịch sử
        self.assertEqual((by["X#1"]["side"], by["X#1"]["volume"], by["X#1"]["profit"]), ("buy", 2.0, 11.0))

    def test_flip_is_split_into_close_part_and_open_part_with_pro_rata_fee(self):
        out = H.apply_netting([self.d(1, 1, "buy", 1), self.d(2, 2, "sell", 3, pnl=7.0, fee=-0.3), self.d(3, 3, "buy", 2, pnl=4.0)], {"key": ["symbol"]})
        self.assertEqual([(d["id"], d["entry"], d["qty"], d["position_id"]) for d in out],
                         [("1", "IN", 1, "X#1"), ("2a", "OUT", 1.0, "X#1"), ("2b", "IN", 2.0, "X#2"), ("3", "OUT", 2, "X#2")])
        self.assertAlmostEqual(out[1]["commission"] + out[2]["commission"], -0.3)
        self.assertEqual((out[1]["profit"], out[2]["profit"]), (7.0, 0.0))            # lãi/lỗ thuộc phần ĐÓNG

    def test_closing_hint_with_unknown_open_position_belongs_to_before_the_period(self):
        out = H.apply_netting([self.d(1, 1, "sell", 1, entry="OUT", pnl=3.0), self.d(2, 2, "sell", 1, entry="OUT", pnl=2.0), self.d(3, 3, "buy", 1, entry="IN")], {"key": ["symbol"]})
        self.assertEqual([(d["entry"], d["position_id"]) for d in out], [("OUT", "X#0"), ("OUT", "X#0"), ("IN", "X#1")])
        row0 = bh.positions_from_deals(out)[0]
        self.assertEqual((row0["side"], row0["open_time"], row0["open_price"], row0["profit"]), ("buy", None, 0.0, 5.0))    # chiều ngược deal đóng, giá mở không bịa

    def test_symbols_and_hedge_legs_are_independent(self):
        out = H.apply_netting([self.d(1, 1, "buy", 1, sym="A", group="LONG"), self.d(2, 2, "sell", 1, sym="A", group="SHORT"), self.d(3, 3, "sell", 1, sym="B", group="LONG"),
                               self.d(4, 4, "sell", 1, sym="A", group="LONG", pnl=1)], {"key": ["symbol", "group"]})
        self.assertEqual({d["id"]: (d["position_id"], d["entry"]) for d in out},
                         {"1": ("A|LONG#1", "IN"), "2": ("A|SHORT#1", "IN"), "3": ("B|LONG#1", "IN"), "4": ("A|LONG#1", "OUT")})

    def test_exchange_supplied_position_ids_are_left_alone(self):
        dd = dict(self.d(1, 1, "buy", 1), position_id="P9", entry="IN")
        self.assertEqual(H.apply_netting([dd], {"key": ["symbol"]}), [dd])

    def test_non_trade_deals_pass_through(self):
        b = {"id": "b", "time": 1, "kind": "balance", "profit": 5.0}
        self.assertEqual(H.apply_netting([b], {}), [b])


# ------------------------------------------------------------------------------------------------------------------ 2. OANDA qua sàn giả
class TestOandaHistory(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fake = FakeOandaX()

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        self.fake.reset()
        self.t0 = time.time() - 3 * DAY

    def settings(self, **kw):
        return dict({"mode": "live", "exchange": "oanda", "oanda_token": self.fake.TOKEN, "oanda_account": self.fake.ACC, "base_url": self.fake.base}, **kw)

    def seed(self):
        f, t = self.fake, self.t0
        f.add_tx(type="TRANSFER_FUNDS", time=t, amount="1000.00", fundingReason="CLIENT_FUNDING")
        f.add_tx(type="ORDER_FILL", time=t + 10, instrument="EUR_USD", units="2000", price="1.1000", orderID="1", commission="0.80", pl="0.0000", financing="0.0000",
                 tradeOpened={"tradeID": "T1", "units": "2000", "price": "1.1000"})
        f.add_tx(type="ORDER_FILL", time=t + 20, instrument="EUR_USD", units="1000", price="1.1010", orderID="2", commission="0.40", pl="0.0", financing="0.0",
                 tradeOpened={"tradeID": "T2", "units": "1000", "price": "1.1010"})
        f.add_tx(type="ORDER_CANCEL", time=t + 25, orderID="3")                                    # loại không liên quan: bị lọc
        f.add_tx(type="DAILY_FINANCING", time=t + DAY, financing="-0.25", accountBalance="1000")
        f.add_tx(type="ORDER_FILL", time=t + 2 * DAY, instrument="EUR_USD", units="-3000", price="1.1100", orderID="4", commission="1.20", pl="23.0", financing="-0.10",
                 tradesClosed=[{"tradeID": "T1", "units": "-2000", "price": "1.1100", "realizedPL": "20.0", "financing": "-0.06"},
                               {"tradeID": "T2", "units": "-1000", "price": "1.1100", "realizedPL": "3.0", "financing": "-0.04"}])
        f.add_tx(type="TRANSFER_FUNDS", time=t + 2 * DAY + 5, amount="-200.00", fundingReason="CLIENT_WITHDRAWAL")

    def test_trades_are_split_per_trade_id_and_numbers_follow_mt5_definitions(self):
        self.seed()
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        sm = res["summary"]
        self.assertAlmostEqual(sm["deposit"], 800.0)                                              # 1000 nạp - 200 rút
        self.assertAlmostEqual(sm["profit"], 23.0)
        self.assertAlmostEqual(sm["swap"], -0.25 - 0.06 - 0.04)                                  # daily financing + financing lúc đóng
        self.assertAlmostEqual(sm["commission"], -(0.80 + 0.40 + 1.20))                          # hoa hồng là SỐ ÂM (trừ số dư), mỗi lần khớp đúng MỘT lần
        self.assertAlmostEqual(sm["balance"], 800 + 23 - 0.35 - 2.4)
        pos = {r["position_id"]: r for r in res["positions"]}
        self.assertEqual(set(pos), {"T1", "T2"})
        self.assertEqual((pos["T1"]["side"], pos["T1"]["volume"], pos["T1"]["open_price"], pos["T1"]["close_price"], pos["T1"]["profit"]), ("buy", 2000.0, 1.1, 1.11, 20.0))
        self.assertAlmostEqual(pos["T2"]["open_price"], 1.101)
        self.assertEqual(sm["deposits"], 2)

    def test_multiple_pages_are_all_read_and_only_wanted_types_are_requested(self):
        self.seed()
        self.fake.page_size = 2
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        self.assertAlmostEqual(res["summary"]["profit"], 23.0)
        self.assertEqual(res["summary"]["trades"], 4)                                             # 2 vào + 2 ra
        reqs = [c for c in self.fake.calls if c[1].endswith("/transactions")]
        self.assertTrue(reqs)
        q = reqs[-1][2]
        self.assertIn("ORDER_FILL", q["type"])
        self.assertIn("from", q)
        self.assertIn("to", q)
        self.assertGreaterEqual(len([c for c in self.fake.calls if c[1].endswith("/idrange")]), 3)    # 6 giao dịch / 2 mỗi trang

    def test_period_is_respected(self):
        self.seed()
        res = bh.fetch_for_settings(self.settings(), self.t0 + 1.5 * DAY, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 2)                                             # chỉ lần đóng
        self.assertAlmostEqual(res["summary"]["deposit"], -200.0)
        pos = res["positions"]
        self.assertEqual(len(pos), 2)
        self.assertTrue(all(r["open_time"] is None for r in pos))                                 # deal mở nằm TRƯỚC kỳ: giờ mở không biết, không bịa

    def test_plain_fill_without_trade_breakdown_falls_back_to_one_deal(self):
        self.fake.add_tx(type="ORDER_FILL", time=self.t0, instrument="USD_JPY", units="-500", price="150.0", orderID="9", commission="0.1", pl="-2.0", financing="0.0")
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        d = [x for x in res["deals"] if x["kind"] == "trade"]
        self.assertEqual(len(d), 1)
        self.assertEqual((d[0]["side"], d[0]["qty"], d[0]["profit"], d[0]["entry"], d[0]["commission"]), ("sell", 500.0, -2.0, "", -0.1))

    def test_dividend_goes_to_other_not_profit(self):
        self.fake.add_tx(type="DIVIDEND_ADJUSTMENT", time=self.t0, instrument="SPX500_USD", dividendAdjustment="4.5")
        sm = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)["summary"]
        self.assertEqual((sm["profit"], sm["other"]), (0.0, 4.5))

    def test_notes_name_the_profile_and_its_assumptions(self):
        self.seed()
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        self.assertIn("OANDA v20", res["notes"][0])
        self.assertIn("có sẵn trong app", res["notes"][0])
        self.assertTrue(any("tradeID" in n for n in res["notes"]))
        self.assertFalse(any(bh.is_warning(n) for n in res["notes"]))                            # đọc đủ: không có cảnh báo

    def test_history_call_cannot_mutate(self):
        b = make_broker(self.settings())
        with self.assertRaises(BrokerError):
            b.history_call("POST", "/v3/accounts/%s/orders" % self.fake.ACC, None, {"order": {}})
        with self.assertRaises(BrokerError):
            b.history_call("PUT", "/v3/accounts/%s/orders/1/cancel" % self.fake.ACC)

    def test_old_history_for_reconcile_is_unchanged(self):
        self.seed()
        b = make_broker(self.settings())
        rows = b.history(0.0)
        self.assertTrue(rows and all(r["id"] for r in rows))


# ------------------------------------------------------------------------------------------------------------------ 3. Binance Futures qua sàn giả
class TestBinanceFuturesHistory(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fake = FakeBinanceX()

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        self.fake.reset()
        self.t0 = time.time() - 20 * DAY

    def settings(self, **kw):
        return dict({"mode": "live", "exchange": "binance_futures", "api_key": self.fake.KEY, "api_secret": self.fake.SECRET.decode(), "base_url": self.fake.base,
                     "watchlist": ""}, **kw)

    def seed(self):
        f, t = self.fake, self.t0
        f.add_income("TRANSFER", 2000.0, t)
        # vị thế 1: mua 0.5 rồi mua thêm 0.5 rồi bán hết (9 ngày sau - khác cửa sổ 7 ngày)
        f.add_fut_trade("BTCUSDT", "BUY", 0.5, 100.0, t + 100, pnl=0.0, fee=0.02)
        f.add_fut_trade("BTCUSDT", "BUY", 0.5, 102.0, t + 200, pnl=0.0, fee=0.02)
        f.add_fut_trade("BTCUSDT", "SELL", 1.0, 110.0, t + 9 * DAY, pnl=9.0, fee=0.044)
        f.add_income("REALIZED_PNL", 9.0, t + 9 * DAY, "BTCUSDT")
        f.add_income("COMMISSION", -0.084, t + 9 * DAY, "BTCUSDT")
        f.add_income("FUNDING_FEE", -0.3, t + 3 * DAY, "BTCUSDT")
        f.add_income("FUNDING_FEE", 0.1, t + 5 * DAY, "BTCUSDT")
        f.add_income("COMMISSION_REBATE", 0.01, t + 9 * DAY, "BTCUSDT")
        f.add_income("WELCOME_BONUS", 5.0, t + 10 * DAY)
        f.add_income("SOMETHING_NEW", -1.0, t + 11 * DAY, "BTCUSDT")
        # vị thế 2 (ETH): bán khống rồi mua lại, lỗ
        f.add_fut_trade("ETHUSDT", "SELL", 2.0, 50.0, t + 12 * DAY, fee=0.04)
        f.add_fut_trade("ETHUSDT", "BUY", 2.0, 52.0, t + 13 * DAY, pnl=-4.0, fee=0.04)
        f.add_income("REALIZED_PNL", -4.0, t + 13 * DAY, "ETHUSDT")

    def test_discovers_symbols_from_income_and_builds_positions_without_ids(self):
        self.seed()
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        sm = res["summary"]
        self.assertAlmostEqual(sm["profit"], 5.0)                                                 # 9 - 4
        self.assertAlmostEqual(sm["deposit"], 2000.0)
        self.assertAlmostEqual(sm["swap"], -0.2)                                                  # funding = «phí qua đêm»
        self.assertAlmostEqual(sm["commission"], -(0.02 + 0.02 + 0.044 + 0.04 + 0.04) + 0.01)    # phí khớp (âm) + hoàn phí
        self.assertAlmostEqual(sm["other"], 5.0 - 1.0)                                            # bonus + loại thu chi lạ: KHÔNG rơi mất
        pos = {r["symbol"]: r for r in res["positions"]}
        self.assertEqual(set(pos), {"BTCUSDT", "ETHUSDT"})
        self.assertEqual((pos["BTCUSDT"]["side"], pos["BTCUSDT"]["volume"], pos["BTCUSDT"]["profit"]), ("buy", 1.0, 9.0))
        self.assertAlmostEqual(pos["BTCUSDT"]["open_price"], 101.0)                               # bình quân gia quyền 2 lần mua
        self.assertEqual((pos["ETHUSDT"]["side"], pos["ETHUSDT"]["profit"]), ("sell", -4.0))
        self.assertAlmostEqual(pos["ETHUSDT"]["open_price"], 50.0)
        self.assertAlmostEqual(pos["ETHUSDT"]["close_price"], 52.0)

    def test_long_period_is_cut_into_7_day_windows_the_exchange_accepts(self):
        self.seed()
        res = bh.fetch_for_settings(self.settings(), self.t0 - 60, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 5)
        hist = [c for c in self.fake.calls if c[1] in ("/fapi/v1/income", "/fapi/v1/userTrades")]
        for _, _, q in hist:
            if "startTime" in q and "endTime" in q:
                self.assertLessEqual(int(q["endTime"]) - int(q["startTime"]), 7 * 86400 * 1000)
        self.assertGreaterEqual(len([c for c in hist if c[1] == "/fapi/v1/income"]), 3)

    def test_full_page_is_continued(self):
        for i in range(7):                                                                       # 7 lần khớp nhỏ trong 1 phút, trang tối đa 1000 -> ép trang nhỏ bằng hồ sơ
            self.fake.add_fut_trade("BTCUSDT", "BUY" if i % 2 == 0 else "SELL", 1.0, 100.0 + i, self.t0 + 10 + i, pnl=0.0 if i % 2 == 0 else 1.0, fee=0.01)
        self.fake.add_income("REALIZED_PNL", 3.0, self.t0 + 12, "BTCUSDT")
        prof = json.loads(json.dumps(P.BINANCE_FUTURES))
        for s in prof["sources"]:
            s["paging"]["limit"] = 3
        st = self.settings(history_profiles=json.dumps({"binance_futures": prof}))
        res = bh.fetch_for_settings(st, self.t0 - 60, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 7)                                            # không sót, không đếm đôi
        self.assertTrue(res["notes"][0].endswith("(do bạn dán ở Cài đặt)."))

    def test_income_denied_falls_back_to_watchlist_and_warns(self):
        self.seed()
        self.fake.income_fail = True
        st = self.settings(watchlist="BTCUSDT")
        res = bh.fetch_for_settings(st, self.t0 - 60, time.time() + 3600)
        warn = [n for n in res["notes"] if bh.is_warning(n)]
        self.assertTrue(any("income" in n and "Enable Reading" in n for n in warn))
        self.assertEqual({d["symbol"] for d in res["deals"] if d["kind"] == "trade"}, {"BTCUSDT"})   # ETH không được biết -> không bịa
        self.assertEqual(res["summary"]["deposit"], 0.0)

    def test_nothing_known_makes_no_trade_requests_and_says_why(self):
        self.fake.income_fail = True
        res = bh.fetch_for_settings(self.settings(), self.t0, time.time() + 3600)
        self.assertEqual(res["deals"], [])
        self.assertFalse([c for c in self.fake.calls if c[1] == "/fapi/v1/userTrades"])
        self.assertTrue(any("theo từng mã" in n for n in res["notes"]))

    def test_commission_in_other_asset_is_not_added_and_closing_hint_marks_pre_window_position(self):
        f, t = self.fake, self.t0
        f.add_income("REALIZED_PNL", 6.0, t + 100, "BTCUSDT")
        f.add_fut_trade("BTCUSDT", "SELL", 1.0, 120.0, t + 100, pnl=6.0, fee=0.003, asset="BNB")   # đóng vị thế mở TRƯỚC kỳ, phí bằng BNB
        res = bh.fetch_for_settings(self.settings(), t - 60, time.time() + 3600)
        self.assertEqual(res["summary"]["commission"], 0.0)
        pos = res["positions"]
        self.assertEqual((len(pos), pos[0]["side"], pos[0]["open_time"], pos[0]["open_price"]), (1, "buy", None, 0.0))

    def test_history_call_is_get_only(self):
        b = make_broker(self.settings())
        with self.assertRaises(BrokerError):
            b.history_call("POST", "/fapi/v1/order", {"symbol": "BTCUSDT"})
        with self.assertRaises(BrokerError):
            b.history_call("DELETE", "/fapi/v1/order", {})
        self.assertFalse([c for c in self.fake.calls if c[0] in ("POST", "DELETE")])

    def test_spot_now_has_account_history_and_it_is_read_only(self):          # 1.9.14: hồ sơ BINANCE_SPOT (trước đây: chưa có)
        res = bh.fetch_for_settings(dict(self.settings(), exchange="binance_spot", watchlist="BTCUSDT"), time.time() - DAY)
        self.assertEqual(res["deals"], [])
        self.assertFalse([c for c in self.fake.calls if c[0] in ("POST", "DELETE")])


# ------------------------------------------------------------------------------------------------------------------ 4. ccxt qua module ccxt GIẢ
class FakeCcxt2:
    id = "fakex"
    timeframes = {"1m": "1m"}

    def __init__(self, cfg=None):
        self.cfg = cfg or {}
        self.has = {"fetchMyTrades": True, "fetchFundingHistory": True, "fetchDeposits": True, "fetchWithdrawals": True, "fetchLedger": False}
        self.markets = {"BTC/USDT:USDT": {"symbol": "BTC/USDT:USDT", "base": "BTC", "quote": "USDT", "spot": False, "active": True}}
        self.calls, self.trades, self.funding, self.deposits, self.withdrawals = [], {}, {}, [], []

    def set_sandbox_mode(self, v):
        pass

    def load_markets(self):
        return self.markets

    def fetch_my_trades(self, symbol=None, since=None, limit=None, params=None):
        self.calls.append(("fetch_my_trades", symbol, since, limit))
        return [t for t in self.trades.get(symbol, []) if since is None or t["timestamp"] >= since]

    def fetch_funding_history(self, symbol=None, since=None, limit=None, params=None):
        self.calls.append(("fetch_funding_history", symbol, since, limit))
        return list(self.funding.get(symbol, []))

    def fetch_deposits(self, code=None, since=None, limit=None, params=None):
        self.calls.append(("fetch_deposits", code, since, limit))
        return list(self.deposits)

    def fetch_withdrawals(self, code=None, since=None, limit=None, params=None):
        self.calls.append(("fetch_withdrawals", code, since, limit))
        return list(self.withdrawals)

    def create_order(self, *a, **k):
        raise AssertionError("lịch sử KHÔNG được đặt lệnh")


def install_fake():
    mod = types.ModuleType("ccxt")
    mod.fakex = FakeCcxt2
    mod.exchanges = ["fakex"]
    sys.modules["ccxt"] = mod
    ccxt_adapter._EX.clear()
    return mod


class TestCcxtHistory(unittest.TestCase):
    def setUp(self):
        install_fake()
        self.st = {"mode": "live", "exchange": "ccxt", "ccxt_id": "fakex", "ccxt_api_key": "k", "ccxt_secret": "s", "watchlist": "BTC/USDT:USDT"}
        self.ex = ccxt_adapter.exchange_for(self.st)
        self.t0 = time.time() - 2 * DAY

    def tearDown(self):
        sys.modules.pop("ccxt", None)
        ccxt_adapter._EX.clear()

    def trade(self, i, side, q, px, t, pnl=None, fee=0.01, cur="USDT"):
        info = {} if pnl is None else {"realizedPnl": str(pnl)}
        return {"id": str(i), "timestamp": int(t * 1000), "symbol": "BTC/USDT:USDT", "side": side, "amount": q, "price": px, "order": "o%d" % i,
                "fee": {"cost": fee, "currency": cur}, "info": info}

    def test_trades_funding_and_cash_are_normalised_and_only_read_functions_are_called(self):
        t = self.t0
        self.ex.trades["BTC/USDT:USDT"] = [self.trade(1, "buy", 1.0, 100.0, t + 10, pnl=0, fee=0.04), self.trade(2, "sell", 1.0, 105.0, t + 99, pnl=5.0, fee=0.04)]
        self.ex.funding["BTC/USDT:USDT"] = [{"id": "f1", "timestamp": int((t + 50) * 1000), "symbol": "BTC/USDT:USDT", "amount": -0.12}]
        self.ex.deposits = [{"id": "d1", "timestamp": int((t + 5) * 1000), "currency": "USDT", "amount": 500.0, "status": "ok"},
                            {"id": "d2", "timestamp": int((t + 6) * 1000), "currency": "USDT", "amount": 50.0, "status": "pending"},       # chưa xong: không tính
                            {"id": "d3", "timestamp": int((t + 7) * 1000), "currency": "BTC", "amount": 1.0, "status": "ok"}]              # khác đồng quote: không cộng
        self.ex.withdrawals = [{"id": "w1", "timestamp": int((t + 60) * 1000), "currency": "USDT", "amount": 100.0, "status": "ok", "fee": {"cost": 1.0}}]
        res = bh.fetch_for_settings(self.st, t - 60, time.time() + 3600)
        sm = res["summary"]
        self.assertAlmostEqual(sm["deposit"], 400.0)
        self.assertAlmostEqual(sm["profit"], 5.0)
        self.assertAlmostEqual(sm["swap"], -0.12)
        self.assertAlmostEqual(sm["commission"], -0.08 - 1.0)
        self.assertEqual({c[0] for c in self.ex.calls}, {"fetch_my_trades", "fetch_funding_history", "fetch_deposits", "fetch_withdrawals"})
        self.assertEqual(sm["positions"], 1)                                                       # có realizedPnl nên biết lần khớp nào là ĐÓNG
        self.assertTrue(any("realizedPnl" in n for n in res["notes"]))

    def test_without_realized_pnl_nothing_is_invented(self):
        t = self.t0
        self.ex.trades["BTC/USDT:USDT"] = [self.trade(1, "buy", 1.0, 100.0, t + 10), self.trade(2, "sell", 1.0, 105.0, t + 99)]
        res = bh.fetch_for_settings(self.st, t - 60, time.time() + 3600)
        self.assertEqual((res["summary"]["profit"], res["summary"]["positions"]), (0.0, 0))
        self.assertEqual(res["summary"]["trades"], 2)

    def test_unsupported_sources_are_skipped_with_a_note(self):
        self.ex.has = {"fetchMyTrades": True}
        res = bh.fetch_for_settings(self.st, self.t0, time.time() + 3600)
        n = " ".join(res["notes"])
        self.assertIn("fetchDeposits", n)
        self.assertIn("fetchFundingHistory", n)
        self.assertEqual([c[0] for c in self.ex.calls], ["fetch_my_trades"])

    def test_failing_cash_source_does_not_hide_the_trades(self):
        t = self.t0
        self.ex.trades["BTC/USDT:USDT"] = [self.trade(1, "sell", 1.0, 105.0, t + 99, pnl=5.0)]

        def boom(*a, **k):
            raise RuntimeError("ExchangeError: 403")
        self.ex.fetch_deposits = boom
        res = bh.fetch_for_settings(self.st, t - 60, time.time() + 3600)
        self.assertEqual(res["summary"]["trades"], 1)
        self.assertTrue(any("deposits" in n and bh.is_warning(n) for n in res["notes"]))

    def test_only_allow_listed_read_methods_can_be_called(self):
        b = make_broker(self.st)
        for bad in ("create_order", "cancel_order", "withdraw", "transfer"):
            with self.assertRaises(BrokerError):
                b.history_call("CCXT", bad, {"symbol": "X"})
        evil = {"ccxt": dict(P.CCXT, sources=[dict(P.CCXT["sources"][0], path="create_order", id="evil")])}
        with self.assertRaises(BrokerError):
            bh.fetch_for_settings(dict(self.st, history_profiles=json.dumps(evil)), self.t0, time.time() + 3600)


# ------------------------------------------------------------------------------------------------------------------ 5. SÀN THỨ BA chỉ bằng JSON
ZETAX_PROFILE = {
    "name": "ZetaX",
    "notes": ["ZetaX báo phí là số dương và nạp/rút cùng một số dương kèm hướng; hồ sơ đổi dấu cho đúng."],
    "sources": [
        {"id": "fills", "path": "/zx/v2/fills", "params": {"from_ms": "{since:ms}", "to_ms": "{until:ms}", "size": 2},
         "paging": {"type": "cursor", "param": "cursor", "next": "data.next"}, "records": "data.rows",
         "emit": [{"kind": "trade", "entry": {"path": "leg", "map": {"open": "IN", "close": "OUT"}},
                   "map": {"id": "fid", "time": "ts_ms", "symbol": "inst", "side": {"path": "dir", "map": {"B": "buy", "S": "sell"}}, "qty": "sz", "price": "px",
                           "profit": "realized", "commission": {"path": "fee", "neg": True}, "position_id": "pos"}}]},
        {"id": "cash", "path": "/zx/v2/cash", "params": {"per": 2}, "paging": {"type": "page", "param": "page", "limit": 2}, "records": "result.items",
         "emit": [
             {"when": {"field": "type", "in": ["DEPOSIT", "WITHDRAW"]}, "kind": "balance",
              "map": {"id": "cid", "time": "when", "profit": {"path": "amt", "neg_if": {"field": "dir", "eq": "out"}}}},
             {"when": {"field": "type", "eq": "FUNDING"}, "kind": "other",
              "map": {"id": "cid", "time": "when", "swap": {"path": "amt", "neg_if": {"field": "dir", "eq": "out"}}}},
             {"when": {"field": "type", "eq": "BONUS"}, "kind": "credit", "map": {"id": "cid", "time": "when", "profit": "amt"}}]},
    ],
}


class TestThirdExchangeJsonOnly(unittest.TestCase):
    """ZetaX không có MỘT dòng mã nào trong app: không adapter, không nhánh, không tên trường. Chỉ cấu hình + hồ sơ JSON."""

    @classmethod
    def setUpClass(cls):
        cls.fake = FakeZetaX()

    @classmethod
    def tearDownClass(cls):
        cls.fake.close()

    def setUp(self):
        self.fake.fills.clear()
        self.fake.cash.clear()
        self.fake.calls.clear()
        self.t0 = time.time() - DAY
        f, t = self.fake, self.t0
        f.add_cash("c1", t, "DEPOSIT", 1000, "in")
        f.add_cash("c2", t + 1, "FUNDING", 0.5, "out")
        f.add_cash("c3", t + 2, "WITHDRAW", 100, "out")
        f.add_cash("c4", t + 3, "BONUS", 10, "in")
        f.add_cash("c5", t + 4, "FUNDING", 0.2, "in")
        f.add_fill("f1", "ZETA-PERP", "B", 3, 10.0, t + 10, fee=0.3, pos="P1", leg="open")
        f.add_fill("f2", "ZETA-PERP", "S", 1, 12.0, t + 20, fee=0.1, realized=2.0, pos="P1", leg="close")
        f.add_fill("f3", "ZETA-PERP", "S", 2, 13.0, t + 30, fee=0.2, realized=6.0, pos="P1", leg="close")
        f.add_fill("f4", "ZETA-PERP", "S", 1, 14.0, t + 40, fee=0.1, pos="P2", leg="open")

    def bridge_settings(self, **kw):
        prof = {"name": "zetax", "base": self.fake.base, "headers": {"X-ZX-KEY": "{token}"}, "ops": {"account": {"path": "/zx/v2/me", "map": {"balance": "bal"}}}}
        prof.update(kw.pop("embed", {}))
        return dict({"mode": "live", "exchange": "bridge", "bridge_profile": json.dumps(prof), "bridge_token": self.fake.KEY, "watchlist": ""}, **kw)

    def check(self, res):
        sm = res["summary"]
        self.assertAlmostEqual(sm["deposit"], 900.0)                                              # 1000 - 100
        self.assertAlmostEqual(sm["profit"], 8.0)
        self.assertAlmostEqual(sm["swap"], -0.5 + 0.2)
        self.assertAlmostEqual(sm["commission"], -(0.3 + 0.1 + 0.2 + 0.1))                        # phí dương của sàn -> số âm
        self.assertAlmostEqual(sm["other"], 10.0)                                                 # bonus (credit)
        self.assertEqual((sm["trades"], sm["positions"]), (4, 1))                                 # P1 đã đóng; P2 còn mở nên không phải lịch sử
        p = res["positions"][0]
        self.assertEqual((p["position_id"], p["side"], p["volume"], p["profit"]), ("P1", "buy", 3.0, 8.0))
        self.assertAlmostEqual(p["close_price"], (12.0 * 1 + 13.0 * 2) / 3)

    def test_profile_pasted_in_settings_makes_the_new_exchange_work(self):
        st = self.bridge_settings(history_profiles=json.dumps({"bridge": ZETAX_PROFILE}))
        res = bh.fetch_for_settings(st, self.t0 - 60, time.time() + 3600)
        self.check(res)
        self.assertIn("ZetaX", res["notes"][0])
        self.assertIn("do bạn dán ở Cài đặt", res["notes"][0])
        fills = [c for c in self.fake.calls if c[0] == "/zx/v2/fills"]
        self.assertEqual(len(fills), 2)                                                           # 4 fill, trang 2 -> đúng 2 lần (con trỏ), lần 2 hết
        self.assertEqual(len([c for c in self.fake.calls if c[0] == "/zx/v2/cash"]), 3)           # 5 dòng, trang 2 -> 3 lần (trang cuối ngắn)

    def test_profile_embedded_in_the_bridge_json_works_too(self):
        res = bh.fetch_for_settings(self.bridge_settings(embed={"history_profile": ZETAX_PROFILE}), self.t0 - 60, time.time() + 3600)
        self.check(res)
        self.assertIn("nhúng trong cấu hình cầu nối", res["notes"][0])

    def test_pasted_profile_beats_embedded_and_a_broken_paste_falls_back_with_a_warning(self):
        broken = {"bridge": {"sources": [{"id": "x"}]}}
        res = bh.fetch_for_settings(self.bridge_settings(embed={"history_profile": ZETAX_PROFILE}, history_profiles=json.dumps(broken)), self.t0 - 60, time.time() + 3600)
        self.check(res)                                                                           # hồ sơ dán lỗi -> dùng hồ sơ nhúng
        self.assertTrue(any(bh.is_warning(n) and "BỎ QUA" in n for n in res["notes"]))
        other = dict(ZETAX_PROFILE, name="ZetaX-user")
        res2 = bh.fetch_for_settings(self.bridge_settings(embed={"history_profile": ZETAX_PROFILE}, history_profiles=json.dumps({"bridge": other})), self.t0 - 60, time.time() + 3600)
        self.assertIn("ZetaX-user", res2["notes"][0])

    def test_wrong_api_key_is_an_error_not_silent_zero(self):
        st = self.bridge_settings(history_profiles=json.dumps({"bridge": ZETAX_PROFILE}), bridge_token="wrong")
        with self.assertRaises(Exception) as cm:
            bh.fetch_for_settings(st, self.t0 - 60, time.time() + 3600)
        self.assertIn("401", str(cm.exception))

    def test_without_any_profile_it_says_how_to_add_one(self):
        with self.assertRaises(Exception) as cm:
            bh.fetch_for_settings(self.bridge_settings(), self.t0, time.time() + 3600)
        self.assertNotIn("401", str(cm.exception))                                               # không gọi sàn khi chưa có hồ sơ

    def test_post_is_blocked_in_a_pasted_profile_and_nothing_reaches_the_exchange(self):
        prof = json.loads(json.dumps(ZETAX_PROFILE))
        prof["sources"][0].update(method="POST", path="/zx/v2/cancel_all")
        self.assertTrue(any("POST bị chặn" in e for e in H.validate_profile(prof)))
        res = bh.fetch_for_settings(self.bridge_settings(embed={"history_profile": ZETAX_PROFILE}, history_profiles=json.dumps({"bridge": prof})), self.t0 - 60, time.time() + 3600)
        self.check(res)                                                                           # hồ sơ POST bị bỏ qua -> dùng hồ sơ nhúng (đọc)
        self.assertFalse([c for c in self.fake.calls if c[0] == "/zx/v2/cancel_all"])


# ------------------------------------------------------------------------------------------------------------------ 6. ưu tiên hồ sơ + hợp đồng
class TestResolveAndContract(unittest.TestCase):
    def test_precedence_user_then_embedded_then_builtin(self):
        mine = simple_profile()
        emb = dict(simple_profile(), name="emb")
        prof, origin, notes = H.resolve(json.dumps({"oanda": mine}), "oanda", None, emb)
        self.assertEqual((prof, origin, notes), (mine, "user", []))
        self.assertEqual(H.resolve("", "oanda", None, emb)[1], "embedded")
        self.assertEqual(H.resolve("", "oanda", None, None)[:2], (P.OANDA, "builtin"))
        self.assertEqual(H.resolve("", "nope", None, None)[:2], (None, ""))
        self.assertEqual(H.resolve("", "whatever", "ccxt", None)[:2], (P.CCXT, "builtin"))
        # hồ sơ người dùng cho sàn KHÁC không ảnh hưởng
        self.assertEqual(H.resolve(json.dumps({"binance_futures": mine}), "oanda", None, None)[1], "builtin")

    def test_every_account_history_passes_the_shared_broker_contract(self):
        from pyea import contract
        fake = FakeOandaX()
        try:
            fake.add_tx(type="ORDER_FILL", time=time.time() - 100, instrument="EUR_USD", units="1000", price="1.1", orderID="1", commission="0.1",
                        tradeOpened={"tradeID": "A", "units": "1000", "price": "1.1"})
            b = make_broker({"mode": "live", "exchange": "oanda", "oanda_token": fake.TOKEN, "oanda_account": fake.ACC, "base_url": fake.base})
            self.assertEqual(contract.check_history_deals(b.account_history(time.time() - DAY, time.time() + 60)), [])
        finally:
            fake.close()

    def test_settings_have_the_paste_box_and_save_validates_it(self):
        from pyea.settings import GLOBAL_INPUTS
        self.assertIn("history_profiles", GLOBAL_INPUTS)
        inp = GLOBAL_INPUTS["history_profiles"]
        self.assertEqual(inp.label, "Hồ sơ lịch sử sàn (JSON)")
        self.assertEqual(inp.default, "")
        self.assertEqual(H.parse_profiles(json.dumps({"x": ZETAX_PROFILE}))[1], [])
        self.assertTrue(H.parse_profiles(json.dumps({"x": {"sources": [{"id": "a"}]}}))[1])


if __name__ == "__main__":
    unittest.main()
