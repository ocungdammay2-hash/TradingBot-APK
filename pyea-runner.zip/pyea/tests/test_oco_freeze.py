"""OCO (one-cancels-other) cho lệnh chờ và freeze level (không sửa/huỷ lệnh chờ, SL/TP khi giá trong vùng đóng băng)."""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea.engine import Account                                                   # noqa: E402
from pyea.sdk import Ret                                                          # noqa: E402
from test_native import make as make_native, tk as tk_native                      # noqa: E402
from test_shell_gaps import make, tk, log_levels                                  # noqa: E402


def updates(sess):
    out = []
    orig = sess._emit

    def cap(u):
        out.append(u)
        return orig(u)
    sess._emit = cap
    return out


class TestOco(unittest.TestCase):
    def two_buy_limits(self, **over):
        s = make(**over)
        tk(s, "BTCUSD", 100.0, 100.0)
        a = s.place_pending("BTCUSD", "buy", "limit", 1, 99.0, owner="bot1")
        b = s.place_pending("BTCUSD", "buy", "limit", 1, 98.0, owner="bot1")
        self.assertTrue(a.ok and b.ok)
        return s, a.order.id, b.order.id

    def test_unlinked_orders_both_fill_control(self):
        s, a, b = self.two_buy_limits()
        tk(s, "BTCUSD", 97.0, 97.0, 1001.0)
        self.assertEqual(len(s.account.positions), 2)

    def test_one_fill_cancels_the_other_even_if_both_hit_in_the_same_tick(self):
        s, a, b = self.two_buy_limits()
        ups = updates(s)
        r = s.link_oco([a, b], owner="bot1")
        self.assertTrue(r.ok, r.message)
        self.assertEqual(r.message, "oco-%d" % min(a, b))
        tk(s, "BTCUSD", 97.0, 97.0, 1001.0)                           # chạm CẢ HAI mức trong một tick
        self.assertEqual(len(s.account.positions), 1)
        self.assertEqual(s.account.pending, {})
        filled = [u for u in ups if u.kind == "order_filled"]
        cancelled = [u for u in ups if u.kind == "order_cancelled"]
        self.assertEqual((len(filled), len(cancelled)), (1, 1))
        self.assertEqual(cancelled[0].source, "oco")
        self.assertIn("OCO", cancelled[0].reason)
        self.assertEqual(filled[0].id, min(a, b))                      # lệnh có id nhỏ hơn được xử lý trước
        self.assertTrue(any(e.kind == "cancel" and "OCO" in e.reason for e in s.events))

    def test_stop_pair_breakout_classic(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        up = s.place_pending("BTCUSD", "buy", "stop", 1, 102.0, owner="b")
        dn = s.place_pending("BTCUSD", "sell", "stop", 1, 98.0, owner="b")
        s.link_oco([up.order.id, dn.order.id], owner="b")
        tk(s, "BTCUSD", 103.0, 103.0, 1001.0)
        self.assertEqual([p.side for p in s.account.positions.values()], ["buy"])
        tk(s, "BTCUSD", 90.0, 90.0, 1002.0)                           # giá xuống tiếp: lệnh sell stop ĐÃ bị huỷ -> không mở lệnh bán
        self.assertEqual([p.side for p in s.account.positions.values()], ["buy"])

    def test_only_same_group_and_same_owner_are_touched(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        o = [s.place_pending("BTCUSD", "buy", "limit", 1, 99.0 - i, owner="bot1").order.id for i in range(4)]
        s.link_oco(o[:2], owner="bot1")
        s.link_oco(o[2:], owner="bot1")
        tk(s, "BTCUSD", 96.0, 96.0, 1001.0)
        self.assertEqual(len(s.account.positions), 2)                  # mỗi nhóm một lệnh khớp
        self.assertEqual(s.account.pending, {})

    def test_manual_cancel_of_one_leaves_the_other_alone(self):
        s, a, b = self.two_buy_limits()
        s.link_oco([a, b], owner="bot1")
        self.assertTrue(s.cancel_order(a, "bot").ok)
        self.assertIn(b, s.account.pending)
        tk(s, "BTCUSD", 97.0, 97.0, 1001.0)
        self.assertEqual(len(s.account.positions), 1)

    def test_link_validation(self):
        s, a, b = self.two_buy_limits()
        self.assertFalse(s.link_oco([a]).ok)
        self.assertFalse(s.link_oco([a, a]).ok)
        self.assertFalse(s.link_oco([a, 9999]).ok)
        self.assertFalse(s.link_oco([a, b], owner="other").ok)         # không nối lệnh của bot khác
        self.assertFalse(s.link_oco(["x", "y"]).ok)
        self.assertEqual(s.account.pending[a].oco, "")

    def test_group_survives_state_roundtrip(self):
        s, a, b = self.two_buy_limits()
        s.link_oco([a, b], owner="bot1")
        d = s.account.to_dict()
        acc = Account(1000.0, 0.0, 1.0)
        acc.restore(d)
        self.assertEqual({o.oco for o in acc.pending.values()}, {"oco-%d" % min(a, b)})

    def test_bot_api_oco_accepts_results_orders_and_ids(self):
        from pyea.engine import BotContext
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)

        class R:                                                     # runner tối thiểu
            iid, session = "bot1", s
        api = BotContext(R())
        a = s.place_pending("BTCUSD", "buy", "limit", 1, 99.0, owner="bot1")
        b = s.place_pending("BTCUSD", "buy", "limit", 1, 98.0, owner="bot1")
        r = api.oco(a, b.order)
        self.assertTrue(r.ok, r.message)
        c = s.place_pending("BTCUSD", "buy", "limit", 1, 97.0, owner="someone_else")
        self.assertFalse(api.oco(a, c.order.id).ok)                   # lệnh của bot khác bị từ chối

    def test_native_orders_cancel_sibling_on_exchange_when_one_fills(self):
        s = make_native()
        tk_native(s)
        a = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0, owner="bot1")
        b = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 94.0, owner="bot1")
        na, nb = s.account.pending[a.order.id].native_id, s.account.pending[b.order.id].native_id
        self.assertTrue(s.link_oco([a.order.id, b.order.id], owner="bot1").ok)
        s.broker.exchange_fill(na, 95.0)
        s._sync_native_pending(force=True)
        self.assertEqual(len(s.account.positions), 1)
        self.assertEqual(s.broker.cancel_calls, [nb])                  # anh em bị HUỶ TRÊN SÀN
        self.assertEqual(s.account.pending, {})

    def test_native_sibling_that_also_filled_is_reported_not_hidden(self):
        s = make_native()
        tk_native(s)
        a = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 95.0, owner="bot1")
        b = s.place_pending("BTCUSDT", "buy", "limit", 0.5, 94.0, owner="bot1")
        na, nb = s.account.pending[a.order.id].native_id, s.account.pending[b.order.id].native_id
        s.link_oco([a.order.id, b.order.id], owner="bot1")
        s.broker.exchange_fill(na, 95.0)
        s.broker.exchange_fill(nb, 94.0)                                # cả hai khớp trước khi vỏ kịp đồng bộ (độ trễ native_sync_s)
        s.broker.cancel_fail = "order already filled"
        s._sync_native_pending(force=True)
        s._sync_native_pending(force=True)
        self.assertEqual(len(s.account.positions), 2)                  # thực tế sàn đã khớp cả hai: sổ app phản ánh đúng thực tế
        self.assertEqual(s.account.pending, {})


class TestFreezeLevel(unittest.TestCase):
    def sess(self, **over):
        s = make(freeze_level_pct=1.0, **over)                          # 1% giá
        tk(s, "BTCUSD", 100.0, 100.0)
        return s

    def test_modify_and_cancel_pending_inside_freeze_zone_are_refused(self):
        s = self.sess()
        r = s.place_pending("BTCUSD", "buy", "limit", 1, 99.5, owner="bot1")     # cách ask 0.5 < freeze 1.0
        self.assertTrue(r.ok)
        oid = r.order.id
        m = s.modify_order(oid, price=99.4)
        self.assertEqual((m.ok, m.retcode), (False, Ret.FROZEN))
        self.assertIn("freeze", m.message)
        c = s.cancel_order(oid, "bot")
        self.assertEqual((c.ok, c.retcode), (False, Ret.FROZEN))
        self.assertIn(oid, s.account.pending)
        self.assertEqual(s.account.pending[oid].price, 99.5)
        self.assertTrue(any("freeze" in msg for lv, msg in log_levels(s) if lv == "WARN"))

    def test_outside_zone_is_allowed_and_zone_follows_the_price(self):
        s = self.sess()
        oid = s.place_pending("BTCUSD", "buy", "limit", 1, 97.0, owner="bot1").order.id
        self.assertTrue(s.modify_order(oid, price=96.5).ok)             # cách 3.5 >= 1.0
        tk(s, "BTCUSD", 97.4, 97.4, 1001.0)                            # giá tiến sát (0.9 < 0.974): vào vùng freeze
        self.assertEqual(s.modify_order(oid, price=96.4).retcode, Ret.FROZEN)
        tk(s, "BTCUSD", 100.0, 100.0, 1002.0)                          # giá xa lại
        self.assertTrue(s.cancel_order(oid, "bot").ok)

    def test_system_cancels_are_never_blocked(self):
        s = self.sess()
        oid = s.place_pending("BTCUSD", "buy", "limit", 1, 99.6, owner="bot1").order.id
        self.assertTrue(s.cancel_order(oid, "kill", "Kill switch").ok)  # kill switch / hết hạn / sàn / OCO / stop-out: không bị chặn
        oid = s.place_pending("BTCUSD", "buy", "limit", 1, 99.6, owner="bot1").order.id
        self.assertTrue(s.cancel_order(oid, "expired").ok)

    def test_kill_switch_cancels_frozen_orders(self):
        s = self.sess()
        s.place_pending("BTCUSD", "buy", "limit", 1, 99.6, owner="bot1")
        s.kill_switch("test")
        self.assertEqual(s.account.pending, {})

    def test_position_sltp_inside_zone_cannot_be_modified(self):
        s = self.sess()
        r = s.send_order("BTCUSD", "buy", 1, sl=99.3, tp=110.0, owner="bot1")
        self.assertTrue(r.ok, r.message)
        pid = r.position.id
        m = s.modify_position(pid, sl=99.0)
        self.assertEqual((m.ok, m.retcode), (False, Ret.FROZEN))
        self.assertIn("SL", m.message)
        tk(s, "BTCUSD", 105.0, 105.0, 1001.0)                          # giá lên, SL 99.3 đã xa >1%
        self.assertTrue(s.modify_position(pid, sl=101.0).ok)

    def test_closing_a_position_is_not_blocked_by_freeze(self):
        s = self.sess()
        r = s.send_order("BTCUSD", "buy", 1, sl=99.3, owner="bot1")
        self.assertTrue(s.close_position(r.position.id, "bot").ok)

    def test_default_off_changes_nothing_and_symbol_override_works(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        oid = s.place_pending("BTCUSD", "buy", "limit", 1, 99.9, owner="bot1").order.id
        self.assertTrue(s.modify_order(oid, price=99.8).ok)             # freeze_level_pct mặc định 0 = tắt
        s2 = make(symbol_overrides='{"BTCUSD": {"freeze_level_pct": 2.0}}')
        tk(s2, "BTCUSD", 100.0, 100.0)
        oid2 = s2.place_pending("BTCUSD", "buy", "limit", 1, 99.0, owner="bot1").order.id
        self.assertEqual(s2.modify_order(oid2, price=98.9).retcode, Ret.FROZEN)

    def test_symbol_info_exposes_freeze_level_in_price_units(self):
        s = self.sess()
        info = s.symbol_info("BTCUSD")
        self.assertAlmostEqual(info.freeze_level, 1.0, 9)               # 1% của 100


if __name__ == "__main__":
    unittest.main()
