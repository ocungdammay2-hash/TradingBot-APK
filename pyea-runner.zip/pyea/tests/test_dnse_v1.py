"""DNSE V1: MQTT-WSS (máy chủ giả), parser giá, backend lệnh/vị thế (API giả)."""
import json, os, struct, sys, threading, time, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea import mqttws
from pyea.bridges import BridgeError
from pyea.dnse import DnseBackend, DnseStream, DnseV1, is_derivative, parse_quote
from pyea.feeds import HttpError
from pyea.wsclient import accept_key, encode_frame, parse_frame


class FakeBroker:
    """Máy chủ WebSocket + MQTT 5 giả: CONNACK, nhận SUBSCRIBE, đẩy PUBLISH tick/TP."""
    def __init__(self, rc=0):
        outer = self
        self.rc, self.connect, self.subs = rc, None, []

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *a): pass
            def do_GET(self):
                self.send_response(101); self.send_header("Upgrade", "websocket"); self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", accept_key(self.headers["Sec-WebSocket-Key"])); self.send_header("Sec-WebSocket-Protocol", "mqtt")
                self.end_headers(); self.wfile.flush()
                buf = bytearray(); sock = self.connection; sock.settimeout(5)
                try:
                    while True:
                        fr = parse_frame(buf)
                        if fr is None:
                            buf += sock.recv(4096); continue
                        fin, op, payload, used = fr; del buf[:used]
                        if op == 8: return
                        if op != 2: continue
                        typ = payload[0] >> 4
                        if typ == 1:
                            outer.connect = payload
                            sock.sendall(encode_frame(2, bytes([0x20, 3, 0, outer.rc, 0]), mask=False))
                            if outer.rc: return
                        elif typ == 8:
                            outer.subs.append(payload)
                            sock.sendall(encode_frame(2, bytes([0x90, 4]) + payload[1:3] + b"\x00\x00", mask=False))
                            for topic, body in (("plaintext/quotes/stock/TP/HPG", {"symbol": "HPG", "Bid": [{"Price": 25.4, "Qtty": 1}, {"Price": 25.3, "Qtty": 2}], "ask": [{"price": 25.5, "qtty": 3}]}),
                                                ("plaintext/quotes/stock/tick/HPG", {"symbol": "HPG", "matchPrice": 25.45, "matchQtty": 100})):
                                tb = topic.encode(); pl = json.dumps(body).encode()
                                inner = struct.pack(">H", len(tb)) + tb + b"\x00" + pl
                                sock.sendall(encode_frame(2, mqttws.packet(0x30, inner), mask=False))
                except (OSError, ValueError):
                    return
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = "ws://127.0.0.1:%d/wss" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()


class TestMqtt(unittest.TestCase):
    def test_varint_roundtrip(self):
        for n in (0, 127, 128, 16383, 16384, 2097151, 268435455):
            self.assertEqual(mqttws.dec_varint(mqttws.enc_varint(n))[0], n)

    def test_connect_packet(self):
        p = mqttws.build_connect("cid", "inv", "tok", 60)
        self.assertEqual(p[0], 0x10); self.assertIn(b"MQTT\x05\xc2", p); self.assertTrue(p.endswith(b"\x00\x03inv\x00\x03tok"))

    def test_connect_subscribe_receive(self):
        b = FakeBroker()
        try:
            c = mqttws.MqttWs(b.url, "cid", "INV1", "JWT")
            c.connect()
            c.subscribe(["plaintext/quotes/stock/TP/HPG"])
            got = []
            end = time.time() + 5
            while len(got) < 2 and time.time() < end:
                got += c.poll(0.3)
            self.assertEqual([g[0] for g in got], ["plaintext/quotes/stock/TP/HPG", "plaintext/quotes/stock/tick/HPG"])
            self.assertIn(b"INV1", b.connect); self.assertIn(b"JWT", b.connect)
            c.close()
        finally:
            b.close()

    def test_rejected_connack(self):
        b = FakeBroker(rc=135)
        try:
            with self.assertRaises(mqttws.MqttError):
                mqttws.MqttWs(b.url, "c", "u", "p", timeout=3).connect()
        finally:
            b.close()


class TestParse(unittest.TestCase):
    def test_tp_best_prices_case_insensitive(self):
        q = parse_quote("plaintext/quotes/stock/TP/HPG", json.dumps({"symbol": "hpg", "Bid": [{"Price": 25.3}, {"price": 25.4}], "ASK": [{"PRICE": 25.6}, {"price": 25.5}]}).encode())
        self.assertEqual(q, ("tp", "HPG", 25.4, 25.5))

    def test_tick_and_garbage(self):
        self.assertEqual(parse_quote("plaintext/quotes/stock/tick/FPT", b'{"MatchPrice": 100.5, "MatchQtty": 7}'), ("tick", "FPT", 100.5, 7.0))
        self.assertIsNone(parse_quote("plaintext/quotes/stock/tick/FPT", b"not json"))
        self.assertIsNone(parse_quote("plaintext/quotes/stock/SI/FPT", b'{"symbol":"FPT"}'))

    def test_derivative_detect(self):
        self.assertTrue(is_derivative("VN30F2612")); self.assertTrue(is_derivative("vn30f1m")); self.assertFalse(is_derivative("HPG"))


class TestStream(unittest.TestCase):
    def test_stream_end_to_end(self):
        b = FakeBroker()
        s = DnseStream(b.url, lambda: ("INV1", "JWT"))
        try:
            s.watch("HPG")
            end = time.time() + 6
            while time.time() < end and not (s.get("HPG") and s.get("HPG")[0] == 25.4):
                time.sleep(0.05)
            t = s.get("HPG")
            self.assertEqual((t[0], t[1], t[2]), (25.4, 25.5, 25.45))
            self.assertEqual(len(b.subs), 1)
        finally:
            s.close(); b.close()

    def test_bad_creds_surface_error_not_fake_price(self):
        b = FakeBroker(rc=135)
        s = DnseStream(b.url, lambda: ("INV1", "JWT"))
        try:
            s.watch("HPG")
            end = time.time() + 6
            while time.time() < end and not s.error:
                time.sleep(0.05)
            self.assertIn("MQTT", s.error); self.assertEqual(s.get("HPG"), [])
        finally:
            s.close(); b.close()


class FakeHttp:
    def __init__(self):
        self.calls = []
        self.orders_rows = [{"id": 7, "symbol": "HPG", "side": "NB", "orderStatus": "new", "quantity": 300, "leaveQuantity": 300, "price": 25.0},
                            {"id": 8, "symbol": "HPG", "side": "NB", "orderStatus": "filled", "quantity": 100, "price": 25.0}]
        self.fail_order = None

    def __call__(self, url, params=None, headers=None, method="GET", timeout=10, body=None, **kw):
        path = url.split("dnse.com.vn", 1)[-1] if "dnse.com.vn" in url else url
        self.calls.append((method, path, params, dict(headers or {}), body))
        if path == "/auth-service/login": return {"token": "JWT%d" % len(self.calls)}
        if path == "/order-service/accounts": return {"accounts": [{"id": "0001", "investorId": "INV", "derivativeAccount": False}]}
        if path.startswith("/order-service/account-balances"): return {"totalCash": 1000.0, "availableCash": 800.0, "netAssetValue": 1500.0, "marginDebt": 50.0}
        if path == "/deal-service/deals":
            return {"deals": [{"id": 5, "symbol": "hpg", "status": "OPEN", "side": "NB", "accumulateQuantity": 500, "closedQuantity": 200, "averageCostPrice": 24.0, "createdDate": "2026-11-01T02:00:00Z"},
                              {"id": 6, "symbol": "FPT", "status": "CLOSED", "accumulateQuantity": 100, "closedQuantity": 100}]}
        if path == "/order-service/trading-token": return {"tradingToken": "TT-" + ("smart" if "smart-otp" in (headers or {}) else "mail")}
        if path == "/order-service/v2/orders" and method == "POST":
            if self.fail_order: raise HttpError(400, self.fail_order)
            return {"id": 99, "averagePrice": 25.1}
        if path == "/order-service/v2/orders" and method == "GET": return {"orders": self.orders_rows}
        if path.startswith("/order-service/v2/orders/") and method == "DELETE": return {"id": 7}
        if "chart-api" in url: return {"t": [100, 160, 220], "o": [1, 2, 3], "h": [2, 3, 4], "l": [0.5, 1, 2], "c": [1.5, 2.5, 3.5], "v": [10, 20, 30]}
        raise AssertionError("gọi không mong đợi: %s %s" % (method, path))


class FakeStream:
    error = ""
    def __init__(self): self.t = {}; self.watched = []
    def watch(self, s): self.watched.append(s)
    def get(self, s): return self.t.get(s.upper(), [])
    def close(self): pass


def mk(**kw):
    h = FakeHttp()
    api = DnseV1("u", "p", http=h)
    st = FakeStream()
    return DnseBackend(api, loan_package=2403, stream=st, http=h, **kw), h, st


class TestBackend(unittest.TestCase):
    def test_login_cached_and_header(self):
        b, h, _ = mk()
        b.account(); b.positions()
        self.assertEqual(sum(1 for c in h.calls if c[1] == "/auth-service/login"), 1)
        self.assertTrue(all(c[3].get("Authorization", "").startswith("Bearer JWT") for c in h.calls if c[1] != "/auth-service/login"))

    def test_account_positions_orders(self):
        b, h, _ = mk()
        a = b.account()
        self.assertEqual((a["balance"], a["equity"], a["free_margin"], a["currency"]), (1000.0, 1500.0, 800.0, "VND"))
        p = b.positions()
        self.assertEqual(len(p), 1); self.assertEqual((p[0]["symbol"], p[0]["side"], p[0]["volume"], p[0]["price"]), ("HPG", "buy", 300.0, 24.0))
        o = b.orders()
        self.assertEqual([(x["id"], x["volume"], x["kind"]) for x in o], [("7", 300.0, "limit")])

    def test_tick_from_stream_or_error(self):
        b, h, st = mk(price_scale=1000.0)
        with self.assertRaises(BridgeError): b.tick("HPG")
        st.t["HPG"] = [25.4, 25.5, 25.45, 1234.0]
        self.assertEqual(b.tick("HPG"), (25400.0, 25500.0, 1234.0))
        self.assertIn("HPG", st.watched)

    def test_market_order_needs_trading_token(self):
        b, h, _ = mk()
        with self.assertRaises(BridgeError) as cm: b.market("HPG", "buy", 100)
        self.assertIn("trading token", str(cm.exception))
        self.assertFalse(any(c[1] == "/order-service/v2/orders" and c[0] == "POST" for c in h.calls))

    def test_otp_exchanged_once_and_order_body(self):
        b, h, _ = mk(otp="123456", otp_smart=True)
        r = b.market("HPG", "buy", 100)
        self.assertEqual(r["order_id"], "99"); self.assertEqual(r["price"], 25.1)
        post = [c for c in h.calls if c[0] == "POST" and c[1] == "/order-service/v2/orders"][0]
        self.assertEqual(post[3]["Trading-Token"], "TT-smart")
        self.assertEqual(post[4], {"symbol": "HPG", "side": "NB", "orderType": "MP", "quantity": 100, "accountNo": "0001", "loanPackageId": 2403})
        tk = [c for c in h.calls if c[1] == "/order-service/trading-token"]
        self.assertEqual(tk[0][3]["smart-otp"], "123456")
        b.market("HPG", "sell", 100)
        self.assertEqual(len([c for c in h.calls if c[1] == "/order-service/trading-token"]), 1)      # OTP dùng 1 lần, token tái dùng

    def test_email_otp_header(self):
        b, h, _ = mk(otp="999", otp_smart=False)
        b.market("HPG", "buy", 100)
        self.assertEqual([c for c in h.calls if c[1] == "/order-service/trading-token"][0][3]["otp"], "999")

    def test_limit_order_price_scaled_and_stop_rejected(self):
        b, h, _ = mk(trading_token="TT", price_scale=1000.0)
        b.place_pending("HPG", "buy", "limit", 200, 25000.0, 0, 0)
        post = [c for c in h.calls if c[0] == "POST" and c[1] == "/order-service/v2/orders"][0]
        self.assertEqual((post[4]["orderType"], post[4]["price"]), ("LO", 25.0))
        with self.assertRaises(BridgeError): b.place_pending("HPG", "buy", "stop", 200, 25000.0, 0, 0)

    def test_order_rejection_and_no_retry(self):
        b, h, _ = mk(trading_token="TT")
        h.fail_order = "quá sức mua"
        with self.assertRaises(BridgeError) as cm: b.market("HPG", "buy", 100)
        self.assertIn("quá sức mua", str(cm.exception))
        self.assertEqual(len([c for c in h.calls if c[0] == "POST" and c[1] == "/order-service/v2/orders"]), 1)

    def test_close_position_sells_open_volume(self):
        b, h, _ = mk(trading_token="TT")
        b.close_position("5")
        post = [c for c in h.calls if c[0] == "POST" and c[1] == "/order-service/v2/orders"][0]
        self.assertEqual((post[4]["side"], post[4]["quantity"]), ("NS", 300))
        with self.assertRaises(BridgeError): b.close_position("404")

    def test_cancel(self):
        b, h, _ = mk(trading_token="TT")
        b.cancel_pending("7")
        d = [c for c in h.calls if c[0] == "DELETE"][0]
        self.assertEqual((d[1], d[2], d[3]["Trading-Token"]), ("/order-service/v2/orders/7", {"accountNo": "0001"}, "TT"))

    def test_candles_scale_and_unsupported_tf(self):
        b, h, _ = mk(price_scale=2.0)
        c = b.candles("HPG", "5m", 2)
        self.assertEqual([x.close for x in c], [5.0, 7.0]); self.assertEqual(c[-1].volume, 30.0)
        with self.assertRaises(BridgeError): b.candles("HPG", "4h", 2)

    def test_spec(self):
        b, _, _ = mk()
        self.assertEqual(b.spec("HPG")["volume_step"], 100.0); self.assertEqual(b.spec("VN30F2612")["volume_min"], 1.0)

    def test_missing_creds(self):
        with self.assertRaises(BridgeError): DnseV1("", "")


if __name__ == "__main__":
    unittest.main()


class TestUiDnse(unittest.TestCase):
    def test_token_flow_fills_form(self):
        import kivy_stub
        kivy_stub.install()
        from pyea import ui_dnse

        class Form:
            def __init__(self): self.v = {"dnse_otp": "123456", "dnse_otp_kind": "email", "dnse_username": "u", "dnse_password": "p"}
            def read(self): return dict(self.v), []
            def set_values(self, d): self.v = dict(d)

        class App:
            def __init__(self):
                self.settings_tab = type("T", (), {"gform": Form()})()
                self.toasts = []; self.saved = 0
            def toast(self, m): self.toasts.append(m)
            def save_forms(self, *a): self.saved += 1

        class Api:
            def trading_token(self, otp, smart): self.args = (otp, smart); return "TOK"
        api = Api()
        app = App()
        orig = threading.Thread
        threading.Thread = lambda target=None, daemon=None, **k: type("T", (), {"start": lambda s: target()})()
        try:
            self.assertTrue(ui_dnse.dnse_get_token(app, api_factory=lambda v: api))
        finally:
            threading.Thread = orig
        self.assertEqual(api.args, ("123456", False))
        v = app.settings_tab.gform.v
        self.assertEqual((v["dnse_trading_token"], v["dnse_otp"]), ("TOK", ""))
        self.assertEqual(app.saved, 1)
