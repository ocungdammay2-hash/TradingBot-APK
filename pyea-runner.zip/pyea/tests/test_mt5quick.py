"""Kết nối MT5 một bước (pyea/mt5quick.py) với API cấp phát MetaApi GIẢ (tests/fake_prov.py, theo đúng tài liệu). Chưa so với dịch vụ thật."""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from fake_mt import FakeMetaApi, MtCore                                            # noqa: E402
from fake_prov import FakeProvisioning                                             # noqa: E402
from pyea import mt5quick                                                          # noqa: E402
from pyea.bridges import MetaApiBackend, make_backend                              # noqa: E402
from pyea.settings import default_settings                                         # noqa: E402

G = FakeProvisioning.GOOD
TOK = FakeProvisioning.TOKEN


class Clock:
    """Đồng hồ giả: sleep() chỉ cộng giờ, không ngủ thật."""

    def __init__(self):
        self.t, self.sleeps = 0.0, []

    def now(self):
        return self.t

    def sleep(self, s):
        self.sleeps.append(s)
        self.t += s


class QuickBase(unittest.TestCase):
    def setUp(self):
        self.fp = FakeProvisioning()
        self.addCleanup(self.fp.close)
        self.clk = Clock()
        self.msgs = []

    def go(self, **kw):
        a = dict(login=G["login"], password=G["password"], server=G["server"], token=TOK, progress=self.msgs.append, prov_url=self.fp.base,
                 sleep=self.clk.sleep, now=self.clk.now, verify=False, timeout=60.0)
        a.update(kw)
        return mt5quick.connect(**a)


class TestProblems(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(mt5quick.problems("50194988", "x", "ICMarketsSC-Demo", "t" * 30), [])

    def test_each_field(self):
        self.assertEqual(len(mt5quick.problems("abc", "x", "S-Demo", "t" * 30)), 1)
        self.assertEqual(len(mt5quick.problems("123456", "", "S-Demo", "t" * 30)), 1)
        self.assertEqual(len(mt5quick.problems("123456", "x", "", "t" * 30)), 1)
        self.assertEqual(len(mt5quick.problems("123456", "x", "1.2.3.4:443", "t" * 30)), 1)      # địa chỉ chứ không phải tên server
        self.assertEqual(len(mt5quick.problems("123456", "x", "S-Demo", "short")), 1)
        self.assertEqual(len(mt5quick.problems("123456", "x", "S-Demo", "t" * 30, platform="mt6")), 1)
        self.assertEqual(len(mt5quick.problems("", "", "", "")), 4)

    def test_invalid_input_makes_no_network_call(self):
        with self.assertRaises(mt5quick.QuickError) as c:
            mt5quick.connect("x", "", "", "", prov_url="http://127.0.0.1:1")
        self.assertEqual(c.exception.code, "nhập liệu")


class TestConnect(QuickBase):
    def test_happy_path_with_detection_retry(self):
        self.fp.detect_polls = 2                                        # hai lần 202 rồi mới 201
        self.fp.connect_after = 3
        r = self.go()
        self.assertTrue(r["connected"])
        self.assertFalse(r["reused"])
        self.assertEqual((r["account_id"], r["region"], r["state"], r["connection"]), ("acc-1", "vint-hill", "DEPLOYED", "CONNECTED"))
        reqs = [(m, p) for m, p, _, _ in self.fp.requests]
        self.assertEqual(reqs[0], ("GET", "/users/current/accounts"))
        creates = [x for x in self.fp.requests if x[0] == "POST" and x[1] == "/users/current/accounts"]
        self.assertEqual(len(creates), 3)                               # 202, 202, 201
        self.assertEqual(len(set(self.fp.tx_seen)), 1)                  # CÙNG transaction-id khi gửi lại (tài liệu yêu cầu)
        self.assertIn(("POST", "/users/current/accounts/acc-1/deploy"), reqs)
        body = creates[0][3]
        self.assertEqual((body["login"], body["server"], body["platform"], body["magic"]), (G["login"], G["server"], "mt5", 0))
        self.assertEqual(self.clk.sleeps[:2], [2.0, 2.0])               # Retry-After 1s bị nâng lên tối thiểu 2s
        self.assertTrue(any("dò cấu hình" in m for m in self.msgs))

    def test_reuse_existing_account_no_duplicate(self):
        r1 = self.go()
        n_creates = len([1 for m, p, _, _ in self.fp.requests if m == "POST" and p == "/users/current/accounts"])
        r2 = self.go(password="khac")                                   # đã có -> không tạo lại (mật khẩu không bị dùng)
        self.assertTrue(r2["reused"])
        self.assertEqual(r2["account_id"], r1["account_id"])
        self.assertEqual(n_creates, len([1 for m, p, _, _ in self.fp.requests if m == "POST" and p == "/users/current/accounts"]))
        self.assertEqual(len(self.fp.accounts), 1)

    def test_already_deployed_skips_deploy(self):
        self.fp.create_state = "DEPLOYED"
        self.go()
        self.assertFalse([1 for m, p, _, _ in self.fp.requests if p.endswith("/deploy")])

    def test_not_connected_returns_partial_without_raising(self):
        self.fp.never_connect = True
        r = self.go(timeout=20.0)
        self.assertFalse(r["connected"])
        self.assertEqual(r["account_id"], "acc-1")                      # vẫn có id để giao diện lưu cài đặt
        self.assertIn("chưa nối", r["note"])
        self.assertIn("CHƯA NỐI", mt5quick.summary(r))
        self.assertGreaterEqual(self.clk.t, 20.0)

    def test_region_missing_falls_back_with_note(self):
        self.fp.region_in_account = False
        r = self.go()
        self.assertEqual(r["region"], mt5quick.DEFAULT_REGION)
        self.assertIn("region", r["note"])

    def test_mt4_platform_sent(self):
        self.go(platform="mt4")
        create = [x for x in self.fp.requests if x[0] == "POST" and x[1] == "/users/current/accounts"][0]
        self.assertEqual(create[3]["platform"], "mt4")

    def test_password_never_in_progress_or_summary_or_settings(self):
        r = self.go()
        s = mt5quick.apply_settings(default_settings(), r, TOK)
        blob = " ".join(self.msgs) + mt5quick.summary(r) + repr(s) + repr(r)
        self.assertNotIn(G["password"], blob)


class TestErrors(QuickBase):
    def test_wrong_password(self):
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go(password="sai")
        self.assertEqual(c.exception.code, "E_AUTH")
        self.assertIn("sai login, mật khẩu hoặc server", str(c.exception))
        self.assertEqual(len(self.fp.accounts), 0)                      # không để lại tài khoản rác

    def test_unknown_server_lists_suggestions(self):
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go(server="ICMarketSC-Demo")                           # gõ sai
        self.assertEqual(c.exception.code, "E_SRV_NOT_FOUND")
        self.assertIn("ICMarketsSC-Demo", str(c.exception))

    def test_server_timezone(self):
        self.fp.fail_code = "E_SERVER_TIMEZONE"
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go()
        self.assertEqual(c.exception.code, "E_SERVER_TIMEZONE")

    def test_bad_token(self):
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go(token="t" * 40)
        self.assertEqual(c.exception.code, "token")
        self.assertIn("Token MetaApi", str(c.exception))

    def test_network_down(self):
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go(prov_url="http://127.0.0.1:1")
        self.assertEqual(c.exception.code, "mạng")

    def test_still_detecting_after_many_retries(self):
        self.fp.detect_polls = 99
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go()
        self.assertEqual(c.exception.code, "đang xử lý")
        self.assertEqual(len(set(self.fp.tx_seen)), 1)

    def test_existing_draft_rejected(self):
        self.fp.accounts["acc-9"] = {"login": G["login"], "name": "n", "server": G["server"], "magic": 0, "platform": "mt5", "state": "DRAFT",
                                     "connectionStatus": "DISCONNECTED"}
        with self.assertRaises(mt5quick.QuickError) as c:
            self.go()
        self.assertEqual(c.exception.code, "DRAFT")

    def test_explain_http_codes(self):
        from pyea.feeds import HttpError
        cases = {403: "quyền", 400: "tham số", 429: "giới hạn", 503: "máy chủ", 404: "không thấy", 418: "http"}
        for st, code in cases.items():
            self.assertEqual(mt5quick.explain_http(HttpError(st, '{"message":"m"}')).code, code, st)
        self.assertEqual(mt5quick.explain_http(HttpError(400, "không phải json")).code, "tham số")


class TestVerifyAndSettings(QuickBase):
    def test_verify_reads_account_via_metaapi_backend(self):
        core = MtCore()
        fm = FakeMetaApi(core)
        self.addCleanup(fm.close)
        fm.TOKEN = TOK                                                  # cùng token với API cấp phát giả; ACC mặc định "acc-1" = id đầu tiên
        r = self.go(verify=True, client_url=fm.base)
        self.assertTrue(r["connected"])
        self.assertAlmostEqual(r["info"]["balance"], 10000.0)
        self.assertIn("Số dư", mt5quick.summary(r))

    def test_verify_failure_is_not_fatal(self):
        r = self.go(verify=True, client_url="http://127.0.0.1:1")
        self.assertTrue(r["connected"])
        self.assertIsNone(r["info"])
        self.assertIn("chưa đọc được số dư", r["note"])

    def test_apply_settings_makes_working_backend(self):
        r = self.go()
        s = mt5quick.apply_settings(default_settings(), r, "  " + TOK + " ")
        self.assertEqual((s["exchange"], s["metaapi_token"], s["metaapi_account"], s["metaapi_region"]), ("metaapi", TOK, "acc-1", "vint-hill"))
        b = make_backend(s)
        self.assertIsInstance(b, MetaApiBackend)
        self.assertIn("vint-hill", b.url)
        self.assertEqual(default_settings()["exchange"], "simulated")   # không sửa bản gốc


class TestUiWiring(unittest.TestCase):
    """Không cần Kivy: kiểm nguồn (bản chạy thật nằm ở tools/ui_smoke/smoke_quick.py)."""

    @classmethod
    def setUpClass(cls):
        root = os.path.join(HERE, "..", "pyea")
        cls.ui = open(os.path.join(root, "ui.py"), encoding="utf-8").read()
        cls.dlg = open(os.path.join(root, "ui_mt5quick.py"), encoding="utf-8").read()

    def test_button_and_handler(self):
        # «Kết nối MT5 nhanh» là MT5 THẬT trong giả lập (ui_mt5emu); MetaApi chỉ là nút tuỳ chọn khác, KHÔNG mang tên đó
        self.assertIn("def mt_quick(self)", self.ui)
        self.assertIn("ui_mt5emu.mt5emu_dialog(self.app)", self.ui.split("def mt_quick(self)")[1].split("def ")[0])
        self.assertIn("def mt_cloud(self)", self.ui)
        self.assertIn("ui_mt5quick.mt5quick_dialog(self.app)", self.ui.split("def mt_cloud(self)")[1].split("def ")[0])
        self.assertNotIn("Kết nối MT5 nhanh", self.dlg.replace("không phải «Kết nối MT5 nhanh»", ""))

    def test_dialog_flow(self):
        for s in ("mt5quick.problems(", "mt5quick.connect(", "mt5quick.apply_settings(", "form.update_values(", "app.save_forms(", 'pw.text = ""',
                  "threading.Thread("):
            self.assertIn(s, self.dlg, s)
        self.assertIn("password=True", self.dlg)               # ô mật khẩu + token bị che
        # mật khẩu không được đưa vào apply_settings/cài đặt
        self.assertNotIn("pw.text)", self.dlg.split("apply_settings(")[1].split("\n")[0])

    def test_docs_exist(self):
        self.assertTrue(os.path.isfile(os.path.join(HERE, "..", "docs", "METAAPI_CLOUD.md")))


if __name__ == "__main__":
    unittest.main()
