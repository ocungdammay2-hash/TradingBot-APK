"""Nạp lại MÃ bot khi đang chạy: giữ vị thế, lỗi -> giữ/quay lại bản cũ, phát hiện «mã đã đổi»."""
import os
import sys
import tempfile
import unittest
from collections import deque

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea.backtest import _ReplayFeed                        # noqa: E402
from pyea.controller import LocalController                  # noqa: E402
from pyea.engine import Account, TradingSession              # noqa: E402
from pyea.sdk import Tick                                    # noqa: E402
from pyea.settings import default_settings                   # noqa: E402


def make():
    st = default_settings()
    st.update(mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0)
    s = TradingSession(st, sync=True, feed=_ReplayFeed())
    s.events = deque(maxlen=100000)
    s.account = Account(st["initial_balance"], 0.0, 1.0)
    s.status = "running"
    s.ready.set()
    return s


def bot_src(version, marker_file, init_body="", deinit_body=""):
    return ('from pyea import BaseBot, Input\n'
            'class B(BaseBot):\n'
            '    name = "Hot"\n'
            '    version = "%s"\n'
            '    inputs = {"lot": Input(1.0, "Lot")}\n'
            '    def on_init(self):\n'
            '        open(%r, "a").write("init %s\\n")\n'
            '%s'
            '    def on_deinit(self, reason):\n'
            '        open(%r, "a").write("deinit %s %%s\\n" %% reason)\n'
            '%s'
            '    def on_tick(self, t):\n'
            '        if not self.api.positions():\n'
            '            self.api.buy(self.p.lot)\n'
            % (version, marker_file, version, init_body, marker_file, version, deinit_body))


class TestHotReload(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.marker = os.path.join(self.d, "marker.txt")
        self.path = os.path.join(self.d, "hot.py")
        self._write(bot_src("1", self.marker))
        self.s = make()
        self.inst = self.s.attach(self.path, "BTCUSD", "1m", {"lot": 2.0}, iid="hot1")
        self.s.process_tick(Tick("BTCUSD", 1000.0, 100.0, 100.0))
        self.inst.start()
        self.s.process_tick(Tick("BTCUSD", 1001.0, 100.0, 100.0))

    def _write(self, src, bump=True):
        old = os.path.getmtime(self.path) if os.path.exists(self.path) else 0.0
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(src)
        if bump:                                              # mtime phân giải thô trên một số FS -> ép mới hơn
            os.utime(self.path, (old + 5, old + 5) if old else None)

    def marks(self):
        return open(self.marker).read().split("\n")[:-1]

    def test_reload_swaps_code_and_keeps_positions(self):
        self.assertEqual(len(self.s.account.positions), 1)
        pid = list(self.s.account.positions)[0]
        self.assertFalse(self.inst.code_stale())
        self._write(bot_src("2", self.marker))
        self.assertTrue(self.inst.code_stale())
        self.assertTrue(self.inst.summary()["code_stale"])
        self.assertTrue(self.inst.reload_code())
        self.assertEqual(self.inst.bot.version, "2")
        self.assertEqual(self.marks(), ["init 1", "deinit 1 reload", "init 2"])
        self.assertEqual(list(self.s.account.positions), [pid])                   # vị thế KHÔNG bị đụng tới
        self.assertEqual(self.inst.bot_params["lot"], 2.0)                         # tham số người dùng giữ nguyên
        self.assertFalse(self.inst.code_stale())
        self.s.process_tick(Tick("BTCUSD", 1002.0, 101.0, 101.0))                  # bản mới nhận tick bình thường
        self.assertEqual(len(self.s.account.positions), 1)                         # đã có vị thế nên không mua thêm

    def test_syntax_error_keeps_old_bot_running(self):
        self._write("def broken(:\n")
        self.assertFalse(self.inst.reload_code())
        self.assertEqual(self.inst.bot.version, "1")
        self.assertEqual(self.marks(), ["init 1"])                                 # bản cũ không bị on_deinit
        self.assertEqual(self.inst.status, "running")
        self.assertTrue(any("THẤT BẠI" in m for _, _, lv, m in self.s.logs if lv == "ERROR"))
        self.assertTrue(self.inst.code_stale())                                    # vẫn báo mã đã đổi (chưa nạp được)

    def test_new_on_init_exception_rolls_back_to_old(self):
        self._write(bot_src("3", self.marker, init_body='        raise RuntimeError("hỏng")\n'))
        self.assertFalse(self.inst.reload_code())
        self.assertEqual(self.inst.bot.version, "1")
        self.assertEqual(self.marks(), ["init 1", "deinit 1 reload", "init 3", "init 1"])   # cũ bị deinit, mới lỗi, cũ init lại
        self.assertEqual(self.inst.status, "running")
        self.assertEqual(len(self.s.account.positions), 1)
        self.s.process_tick(Tick("BTCUSD", 1002.0, 101.0, 101.0))                 # bản cũ vẫn chạy tick được
        self.assertEqual(self.inst.status, "running")

    def test_new_on_init_false_rolls_back(self):
        self._write(bot_src("4", self.marker, init_body="        return False\n"))
        self.assertFalse(self.inst.reload_code())
        self.assertEqual(self.inst.bot.version, "1")
        self.assertTrue(any("on_init trả về False" in m for _, _, lv, m in self.s.logs if lv == "ERROR"))

    def test_old_on_deinit_error_does_not_block_reload(self):
        self._write(bot_src("1", self.marker, deinit_body='        raise ValueError("xấu")\n'))
        self.assertTrue(self.inst.reload_code())                                   # nạp lại bản có on_deinit lỗi (bản "cũ" lúc này vẫn là v1 gốc)
        self._write(bot_src("5", self.marker))
        self.assertTrue(self.inst.reload_code())                                   # bản cũ (on_deinit lỗi) -> vẫn nạp được bản mới
        self.assertEqual(self.inst.bot.version, "5")
        self.assertTrue(any("on_deinit('reload')" in m for _, _, lv, m in self.s.logs if lv == "ERROR"))

    def test_not_running_or_remote_is_refused(self):
        self.inst.stop()
        self.inst.status = "stopped"
        self.assertFalse(self.inst.reload_code())                                  # chưa/không chạy: lần chạy sau tự nạp mới
        self.inst.status = "running"
        self.inst.bot.proc = object()                                              # giả lập bot cô lập tiến trình
        self.assertFalse(self.inst.reload_code())
        self.assertTrue(any("TIẾN TRÌNH RIÊNG" in m for _, _, lv, m in self.s.logs if lv == "WARN"))
        del self.inst.bot.proc

    def test_controller_reload(self):
        ctl = LocalController(self.s)
        self._write(bot_src("6", self.marker))
        self.assertTrue(ctl.reload_bot("hot1"))
        self.assertEqual(self.inst.bot.version, "6")
        self.assertFalse(ctl.reload_bot("khong-co"))


if __name__ == "__main__":
    unittest.main()
