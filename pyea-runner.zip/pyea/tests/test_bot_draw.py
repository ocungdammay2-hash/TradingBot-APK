"""Bot vẽ đối tượng lên biểu đồ (api.draw_*)."""
import os, sys, tempfile, time, unittest
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from pyea.engine import TradingSession
from pyea.settings import default_settings

BODY = ("from pyea import BaseBot\nclass D(BaseBot):\n    def on_bar(self, c):\n"
        "        self.api.draw_hline('lv', c.close, 'mức')\n"
        "        self.api.draw_trend('tr', c.time - 600, c.low, c.time, c.high)\n"
        "        self.api.draw_text('tx', c.time, c.high, 'hi')\n"
        "        self.api.draw_rect('bad', c.time, c.low, c.time, c.low)\n")   # 2 điểm trùng -> bị từ chối


class TestBotDraw(unittest.TestCase):
    def test_draw_in_chart_and_replace(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "d.py"); open(p, "w", encoding="utf-8").write(BODY)
            s = default_settings(); s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, initial_balance=100000.0)
            sess = TradingSession(s, log_file=None)
            inst = sess.attach(p, "BTCUSD", "1m"); sess.start(); inst.start()
            end = time.time() + 15
            ch = None
            while time.time() < end:
                ch = sess.chart("BTCUSD", "1m")
                if ch and len(ch["bot_objects"]) >= 3:
                    break
                time.sleep(0.1)
            try:
                kinds = sorted(o["kind"] for o in ch["bot_objects"])
                self.assertEqual(kinds, ["hline", "text", "trend"])            # rect trùng điểm bị bỏ; cùng tên không nhân đôi
                self.assertTrue(all(o["id"].startswith("b:") for o in ch["bot_objects"]))
                self.assertIsNone(sess.chart("ETHUSD", "1m"))
                self.assertTrue(inst.draw_objs)
            finally:
                sess.stop()

    def test_delete_and_cap(self):
        from pyea.engine import BotRunner
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "d.py"); open(p, "w", encoding="utf-8").write(BODY)
            sess = TradingSession(default_settings(), log_file=None)
            r = sess.attach(p, "BTCUSD", "1m")
            sess.settings["max_bot_objects"] = 60
            for i in range(80):
                self.assertTrue(r._draw("n%d" % i, "hline", [(0, 100 + i)], "", 0))
            self.assertEqual(len(r.draw_objs), r.MAX_BOT_OBJECTS)
            self.assertTrue(r._draw_delete("n79"))
            self.assertFalse(r._draw_delete("n79"))
            r._draw_delete(None)
            self.assertEqual(len(r.draw_objs), 0)


if __name__ == "__main__":
    unittest.main()
