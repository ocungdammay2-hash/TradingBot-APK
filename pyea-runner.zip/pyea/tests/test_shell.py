"""Tính năng của VỎ: kết quả lệnh có mã lỗi, luật khối lượng/SL/TP/ký quỹ, lệnh chờ, đóng một phần, on_trade/on_timer,
đa khung giờ trong bot, Kill switch, circuit breaker, chống treo, cảnh báo giá, margin call/stop-out, sao lưu/chẩn đoán, an toàn khi nạp bot."""
import json, os, sys, tempfile, threading, time, unittest, zipfile
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from pyea import loader                                             # noqa: E402
from pyea.backtest import _ReplayFeed                               # noqa: E402
from pyea.broker import BinanceBroker, Fill                         # noqa: E402
from pyea.engine import Account, BotRunner, TradingSession          # noqa: E402
from pyea.sdk import API_VERSION, OrderResult, Ret, Tick, Trade     # noqa: E402
from pyea.settings import default_settings                          # noqa: E402
from pyea.shell import (AlertBook, SymbolSpec, connection_health, resolve_spec, statement_csv, trade_stats,   # noqa: E402
                        validate_stops, validate_volume)
from pyea.storage import Store                                      # noqa: E402


def wait(fn, timeout=10.0, step=0.05):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if fn():
                return True
        except Exception:
            pass
        time.sleep(step)
    return False


def make(alarms=None, **over):
    """Phiên đồng bộ (như backtest): tự đẩy tick bằng tay, không luồng nền - kiểm thử tất định."""
    st = default_settings()
    st.update(mode="paper", exchange="simulated", initial_balance=10000.0, leverage=1.0, commission_pct=0.0, spread_pct=0.0,
              max_loss_pct=0.0)
    st.update(over)
    sess = TradingSession(st, sync=True, feed=_ReplayFeed(), alarm_cb=(lambda t, x: alarms.append((t, x))) if alarms is not None else None)
    sess.events = deque(maxlen=100000)
    sess.account = Account(st["initial_balance"], st["commission_pct"], st["leverage"])
    sess.status = "running"
    sess.ready.set()
    return sess


def tk(sess, sym, bid, ask=None, t=1000.0):
    tick = Tick(sym, t, bid, bid if ask is None else ask)
    sess.process_tick(tick)
    return tick


def write_bot(d, name, body):
    p = os.path.join(d, name)
    with open(p, "w", encoding="utf-8") as f:
        f.write(body)
    return p


class TestOrderRules(unittest.TestCase):
    def test_volume_rules(self):
        sp = SymbolSpec("X", volume_min=0.01, volume_max=5.0, volume_step=0.01)
        self.assertEqual(validate_volume(sp, 0.019), (0.01, None))
        self.assertIsNotNone(validate_volume(sp, 0.004)[1])
        self.assertIsNotNone(validate_volume(sp, 6)[1])
        for bad in (0, -1, float("nan"), "abc", None):
            self.assertIsNotNone(validate_volume(sp, bad)[1], bad)
        s = make(min_volume=0.01, volume_step=0.01, max_volume=2.0)
        tk(s, "BTCUSD", 100.0, 100.0)
        r = s.send_order("BTCUSD", "buy", 0.005)
        self.assertFalse(r)
        self.assertEqual(r.retcode, Ret.INVALID_VOLUME)
        r = s.send_order("BTCUSD", "buy", 0.0234)                       # làm tròn xuống 0.02
        self.assertTrue(r)
        self.assertAlmostEqual(r.volume, 0.02)
        self.assertAlmostEqual(r.requested_volume, 0.0234)
        self.assertEqual(s.send_order("BTCUSD", "buy", 3).retcode, Ret.INVALID_VOLUME)

    def test_stops_sides_and_stop_level(self):
        s = make(stop_level_pct=1.0)
        t = tk(s, "BTCUSD", 100.0, 100.0)
        self.assertEqual(s.send_order("BTCUSD", "buy", 1, sl=101).retcode, Ret.INVALID_STOPS)        # SL trên giá khi mua
        self.assertEqual(s.send_order("BTCUSD", "sell", 1, tp=101).retcode, Ret.INVALID_STOPS)       # TP trên giá khi bán
        self.assertEqual(s.send_order("BTCUSD", "buy", 1, sl=99.5).retcode, Ret.INVALID_STOPS)       # sát hơn 1%
        r = s.send_order("BTCUSD", "buy", 1, sl=95, tp=110)
        self.assertTrue(r)
        self.assertEqual(r.retcode, Ret.OK)
        self.assertIsNone(validate_stops(SymbolSpec("X"), "buy", 100, 0, 0))
        r2 = s.modify_position(r.id, sl=99.9)                                                        # sửa cũng bị kiểm tra
        self.assertFalse(r2)
        self.assertEqual(r2.retcode, Ret.INVALID_STOPS)
        self.assertTrue(s.modify_position(r.id, sl=96))

    def test_margin_and_reserved_for_pending(self):
        s = make(initial_balance=1000.0, leverage=1.0)
        tk(s, "BTCUSD", 100.0, 100.0)
        r = s.send_order("BTCUSD", "buy", 5.0)                                  # dùng 500
        self.assertTrue(r)
        p = s.place_pending("BTCUSD", "buy", "limit", 4.0, 90.0)                # giữ 360
        self.assertTrue(p)
        self.assertEqual(p.retcode, Ret.PLACED)
        info = s.account_info()
        self.assertAlmostEqual(info.margin, 500.0)
        self.assertAlmostEqual(info.reserved, 360.0)
        self.assertAlmostEqual(info.free_margin, 140.0)
        r = s.send_order("BTCUSD", "buy", 2.0)                                  # cần 200 > 140
        self.assertEqual(r.retcode, Ret.INSUFFICIENT_MARGIN)
        self.assertEqual(s.place_pending("BTCUSD", "buy", "limit", 2.0, 80.0).retcode, Ret.INSUFFICIENT_MARGIN)
        self.assertTrue(s.cancel_order(p.order.id))
        self.assertAlmostEqual(s.account_info().reserved, 0.0)
        self.assertTrue(s.send_order("BTCUSD", "buy", 2.0))                     # sau khi huỷ lại đủ

    def test_read_only_halt_and_symbol_modes(self):
        s = make(read_only=True)
        tk(s, "BTCUSD", 100.0, 100.0)
        self.assertEqual(s.send_order("BTCUSD", "buy", 1).retcode, Ret.TRADE_DISABLED)
        self.assertEqual(s.place_pending("BTCUSD", "buy", "limit", 1, 90).retcode, Ret.TRADE_DISABLED)
        self.assertFalse(s.account_info().trade_allowed)
        s.settings["read_only"] = False
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))
        s.settings["read_only"] = True
        self.assertTrue(s.close_position(s.account.positions and list(s.account.positions)[0], "manual", "x"))   # vẫn đóng được
        s.settings["read_only"] = False
        ov = json.dumps({"BTCUSD": {"trade_mode": "long_only"}, "ETHUSD": {"trade_mode": "close_only"}, "XAUUSD": {"trade_mode": "disabled"}})
        s.settings["symbol_overrides"] = ov
        for sym in ("ETHUSD", "XAUUSD"):
            tk(s, sym, 10.0, 10.0)
        self.assertEqual(s.send_order("BTCUSD", "sell", 1).retcode, Ret.SYMBOL_MODE)
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))
        self.assertEqual(s.send_order("ETHUSD", "buy", 1).retcode, Ret.SYMBOL_MODE)
        self.assertEqual(s.send_order("XAUUSD", "buy", 1).retcode, Ret.SYMBOL_MODE)
        self.assertEqual(s.symbol_info("BTCUSD").trade_mode, "long_only")

    def test_stale_quotes_and_closed_market(self):
        s = make(stale_after=30.0)
        t = tk(s, "BTCUSD", 100.0, 100.0)
        s.sync = False                                                           # bật kiểm tra độ tươi (chỉ chạy khi không backtest)
        s._tick_wall["BTCUSD"] = time.time() - 120
        r = s.send_order("BTCUSD", "buy", 1)
        self.assertEqual(r.retcode, Ret.NO_QUOTES)
        self.assertIn("cũ", r.message)
        s._tick_wall["BTCUSD"] = time.time()
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))
        s.ticks["ETHUSD"] = Tick("ETHUSD", 1000.0, 10.0, 10.0, tradeable=False)
        s._tick_wall["ETHUSD"] = time.time()
        self.assertEqual(s.send_order("ETHUSD", "buy", 1).retcode, Ret.MARKET_CLOSED)
        self.assertFalse(s.symbol_info("ETHUSD").market_open)

    def test_request_id_is_idempotent(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        a = s.send_order("BTCUSD", "buy", 1, request_id="abc")
        b = s.send_order("BTCUSD", "buy", 1, request_id="abc")                   # bot retry cùng request_id
        self.assertTrue(a and b)
        self.assertEqual(a.id, b.id)
        self.assertEqual(len(s.account.positions), 1)
        self.assertIn("request_id", b.message)
        s.send_order("BTCUSD", "buy", 1, request_id="khác")
        self.assertEqual(len(s.account.positions), 2)

    def test_broker_restrictions_netting_and_spot_short(self):
        class B:
            supports_short, netting = False, True

            def market_order(self, sym, side, qty, reduce_only=False):
                return Fill(100.0, qty)
        s = make()
        s.broker = B()
        tk(s, "BTCUSD", 100.0, 100.0)
        self.assertEqual(s.send_order("BTCUSD", "sell", 1).retcode, Ret.NOT_SUPPORTED)
        B.supports_short = True
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))
        r = s.send_order("BTCUSD", "sell", 1)
        self.assertEqual(r.retcode, Ret.HEDGE_NOT_ALLOWED)
        self.assertTrue(s.account_info().netting)

    def test_order_result_is_backward_compatible(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0)
        r = s.send_order("BTCUSD", "buy", 2, sl=90, comment="x")
        self.assertIsInstance(r, OrderResult)
        self.assertEqual((r.symbol, r.side, r.volume, r.sl, r.open_price), ("BTCUSD", "buy", 2, 90, 100.0))   # đọc như Position
        self.assertEqual(r.ticket, r.position.id)
        self.assertFalse(OrderResult())
        with self.assertRaises(AttributeError):
            OrderResult().id


class TestPendingOrders(unittest.TestCase):
    def test_placement_validation(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.5)
        bad = [("buy", "limit", 101.0), ("sell", "limit", 99.0), ("buy", "stop", 100.0), ("sell", "stop", 101.0)]
        for side, kind, price in bad:
            self.assertEqual(s.place_pending("BTCUSD", side, kind, 1, price).retcode, Ret.INVALID_PRICE, (side, kind))
        self.assertEqual(s.place_pending("BTCUSD", "buy", "stop_limit", 1, 105, stop_price=0).retcode, Ret.INVALID_PRICE)
        self.assertEqual(s.place_pending("BTCUSD", "buy", "stop_limit", 1, 106, stop_price=105).retcode, Ret.INVALID_PRICE)  # limit > trigger
        self.assertEqual(s.place_pending("BTCUSD", "buy", "limit", 1, 99, expiration=500.0).retcode, Ret.INVALID_EXPIRATION)
        self.assertEqual(s.place_pending("BTCUSD", "buy", "limit", 1, 99, sl=100).retcode, Ret.INVALID_STOPS)
        self.assertEqual(s.place_pending("BTCUSD", "buy", "tuỳ", 1, 99).retcode, Ret.INVALID_PRICE)
        self.assertEqual(len(s.account.pending), 0)
        ok = s.place_pending("BTCUSD", "buy", "limit", 1, 99, sl=95, tp=110)
        self.assertTrue(ok)
        self.assertEqual(ok.order.kind, "limit")

    def test_limit_and_stop_fill_keep_order_id(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        a = s.place_pending("BTCUSD", "buy", "limit", 1, 98.0, sl=90, tp=120)
        b = s.place_pending("BTCUSD", "sell", "stop", 2, 95.0)
        c = s.place_pending("BTCUSD", "sell", "limit", 1, 104.0)
        d = s.place_pending("BTCUSD", "buy", "stop", 1, 106.0)
        ids = [x.order.id for x in (a, b, c, d)]
        self.assertEqual(len(set(ids)), 4)
        tk(s, "BTCUSD", 97.9, 98.0, t=1010)                                      # chạm buy limit 98
        self.assertIn(ids[0], s.account.positions)
        pos = s.account.positions[ids[0]]
        self.assertEqual((pos.side, pos.open_price, pos.sl, pos.tp), ("buy", 98.0, 90, 120))
        self.assertNotIn(ids[0], s.account.pending)
        tk(s, "BTCUSD", 94.9, 95.0, t=1020)                                      # chạm sell stop 95
        self.assertEqual(s.account.positions[ids[1]].side, "sell")
        tk(s, "BTCUSD", 104.0, 104.1, t=1030)                                    # chạm sell limit 104
        self.assertEqual(s.account.positions[ids[2]].open_price, 104.0)
        tk(s, "BTCUSD", 106.0, 106.2, t=1040)                                    # chạm buy stop 106 (khớp ở ask 106.2)
        self.assertEqual(s.account.positions[ids[3]].open_price, 106.2)
        self.assertEqual(len(s.account.pending), 0)
        kinds = [e.kind for e in s.events]
        self.assertEqual(kinds.count("pending"), 4)
        self.assertEqual(kinds.count("open"), 4)
        op = next(e for e in s.events if e.kind == "open" and e.pos_id == ids[0])
        self.assertIn("lệnh chờ", op.details)

    def test_stop_limit_arms_then_fills(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        r = s.place_pending("BTCUSD", "buy", "stop_limit", 1, 104.0, stop_price=105.0)
        self.assertTrue(r)
        tk(s, "BTCUSD", 103.0, 103.0, t=1010)
        self.assertEqual(len(s.account.positions), 0)
        tk(s, "BTCUSD", 105.2, 105.3, t=1020)                                    # chạm trigger 105 nhưng giá > limit 104 -> chỉ kích hoạt
        self.assertTrue(s.account.pending[r.order.id].armed)
        self.assertEqual(len(s.account.positions), 0)
        tk(s, "BTCUSD", 103.9, 104.0, t=1030)                                    # về tới limit 104 -> khớp
        self.assertEqual(s.account.positions[r.order.id].open_price, 104.0)

    def test_expiration_cancel_modify(self):
        s = make()
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        a = s.place_pending("BTCUSD", "buy", "limit", 1, 90.0, expiration=1100.0)
        b = s.place_pending("BTCUSD", "buy", "limit", 1, 91.0)
        m = s.modify_order(b.order.id, price=92.0, sl=80.0)
        self.assertTrue(m)
        self.assertEqual(s.account.pending[b.order.id].price, 92.0)
        self.assertFalse(s.modify_order(b.order.id, price=105.0))               # sai phía
        self.assertEqual(s.modify_order(999, price=1).retcode, Ret.NOT_FOUND)
        tk(s, "BTCUSD", 100.0, 100.0, t=1200)                                    # quá hạn lệnh a
        self.assertNotIn(a.order.id, s.account.pending)
        ev = [e for e in s.events if e.kind == "cancel" and e.pos_id == a.order.id]
        self.assertTrue(ev and "hết hạn" in ev[0].reason.lower())
        self.assertTrue(s.cancel_order(b.order.id))
        self.assertEqual(s.cancel_order(b.order.id).retcode, Ret.NOT_FOUND)

    def test_pending_fill_rejected_when_no_margin_at_fill_time(self):
        s = make(initial_balance=1000.0)
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        a = s.place_pending("BTCUSD", "buy", "limit", 10.0, 90.0)                # giữ 900
        s.account.balance = 100.0                                                # vốn tụt mạnh
        tk(s, "BTCUSD", 89.0, 89.0, t=1010)
        self.assertEqual(len(s.account.positions), 0)
        self.assertNotIn(a.order.id, s.account.pending)
        self.assertTrue(any(e.kind == "cancel" and "không khớp" in e.reason for e in s.events))

    def test_pending_survives_save_and_restore(self):
        with tempfile.TemporaryDirectory() as d:
            sf = os.path.join(d, "st.json")
            s = make()
            s.state_file = sf
            tk(s, "BTCUSD", 100.0, 100.0)
            r = s.place_pending("BTCUSD", "sell", "limit", 1.5, 110.0, sl=120, comment="c", expiration=5000.0)
            s._save_state()
            s2 = make()
            s2.state_file = sf
            s2._load_state()
            o = s2.account.pending[r.order.id]
            self.assertEqual((o.side, o.kind, o.volume, o.price, o.sl, o.expiration, o.comment), ("sell", "limit", 1.5, 110.0, 120, 5000.0, "c"))
            n = s2.account.add_pending(type(o)(id=0, symbol="X", side="buy", kind="limit", volume=1, price=1))
            self.assertGreater(n.id, r.order.id)                                  # bộ đếm id không bị trùng sau khôi phục


class TestPartialClose(unittest.TestCase):
    def test_reduce_position(self):
        s = make(commission_pct=0.1)
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        r = s.send_order("BTCUSD", "buy", 4.0)
        fee0 = s.account.positions[r.id].fee
        tk(s, "BTCUSD", 110.0, 110.0, t=1010)
        res = s.close_position(r.id, "manual", "chốt 1 nửa", volume=1.0)
        self.assertTrue(res)
        self.assertAlmostEqual(res.volume, 1.0)
        pos = s.account.positions[r.id]
        self.assertAlmostEqual(pos.volume, 3.0)
        self.assertAlmostEqual(pos.fee, fee0 * 0.75)
        tr = s.account.trades[-1]
        self.assertAlmostEqual(tr.volume, 1.0)
        self.assertAlmostEqual(tr.profit, 10.0 - fee0 / 4 - 1.0 * 110.0 * 0.001, places=6)
        self.assertEqual(s.events[-1].kind, "close")
        self.assertIn("đóng một phần", s.events[-1].details)
        res2 = s.close_position(r.id, "manual", "hết", volume=99)              # volume lớn hơn -> đóng hết
        self.assertTrue(res2)
        self.assertNotIn(r.id, s.account.positions)
        self.assertEqual(len(s.account.trades), 2)
        self.assertEqual(s.close_position(r.id, "manual", "x").retcode, Ret.NOT_FOUND)


BOT_API = '''
from pyea import BaseBot, Input
class B(BaseBot):
    name = "api-test"
    inputs = {"timer": Input(0.0, "timer")}
    def on_init(self):
        self.updates = []
        self.timers = 0
        self.res = {}
        self.step = 0
        if self.p.timer: self.api.set_timer(self.p.timer)
    def on_trade(self, u):
        self.updates.append((u.kind, u.id, u.source, u.retcode))
    def on_timer(self):
        self.timers += 1
    def on_tick(self, t):
        self.step += 1
        a = self.api
        if self.step == 1:
            self.res["limit"] = a.buy_limit(1.0, t.ask * 0.99, sl=t.ask * 0.9, comment="L")
            self.res["bad"] = a.buy_limit(1.0, t.ask * 1.05)
            self.res["mkt"] = a.sell(1.0, sl=t.bid * 1.1, tp=t.bid * 0.8, comment="S")
            self.res["info"] = (a.account_info(), a.symbol_info(), a.time_info(), a.version)
            self.res["orders"] = a.orders()
        if self.step == 3:
            self.res["cancel_other"] = a.cancel_order(99999)
            self.res["partial"] = a.close(a.positions()[0], reason="một phần", volume=0.4)
        if self.step == 4:
            self.res["cancel"] = a.cancel_order(a.orders()[0]) if a.orders() else None
'''


class TestBotAPI(unittest.TestCase):
    def _run(self, ticks, params=None, **over):
        d = tempfile.mkdtemp()
        p = write_bot(d, "api.py", BOT_API)
        s = make(**over)
        inst = s.attach(p, "BTCUSD", "1m", params or {}, iid="b1")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        for t, px in ticks:
            tk(s, "BTCUSD", px, px, t=t)
        return s, inst

    def test_orders_on_trade_info_partial_cancel(self):
        s, inst = self._run([(1010, 100.0), (1020, 100.0), (1030, 99.9), (1040, 98.5), (1050, 97.0)])
        r = inst.bot.res
        self.assertTrue(r["limit"] and r["limit"].retcode == Ret.PLACED)
        self.assertFalse(r["bad"])
        self.assertEqual(r["bad"].retcode, Ret.INVALID_PRICE)
        self.assertTrue(r["mkt"])
        acc, sym, tinfo, ver = r["info"]
        self.assertEqual(ver, API_VERSION)
        self.assertAlmostEqual(acc.balance, 10000.0)
        self.assertEqual((sym.symbol, sym.bid), ("BTCUSD", 100.0))
        self.assertIn("server", tinfo)
        self.assertEqual(len(r["orders"]), 1)
        self.assertEqual(r["cancel_other"].retcode, Ret.NOT_FOUND)
        self.assertTrue(r["partial"])
        self.assertAlmostEqual(r["partial"].volume, 0.4)
        kinds = [u[0] for u in inst.bot.updates]
        self.assertIn("order_placed", kinds)
        self.assertIn("order_rejected", kinds)                      # buy_limit sai giá
        self.assertIn("position_opened", kinds)
        self.assertIn("position_reduced", kinds)
        self.assertIn("order_filled", kinds)                        # tick 98.5 chạm limit 99
        self.assertEqual([u for u in inst.bot.updates if u[0] == "order_rejected"][0][3], Ret.INVALID_PRICE)
        pos = [p for p in s.account.positions.values() if p.owner == "b1"]
        self.assertEqual(len(pos), 2)                                # sell 0.6 còn lại + buy limit đã khớp
        s.close_all("stop", "kết thúc")
        self.assertIn("position_closed", [u[0] for u in inst.bot.updates])
        self.assertEqual(inst.summary()["metrics"]["callbacks"]["on_trade"]["n"] > 0, True)

    def test_on_trade_sl_tp_source(self):
        d = tempfile.mkdtemp()
        p = write_bot(d, "t.py", "from pyea import BaseBot\nclass B(BaseBot):\n    def on_init(self):\n        self.u = []\n"
                      "    def on_tick(self, t):\n        if not self.api.positions(): self.api.buy(1, sl=t.bid*0.9, tp=t.bid*1.1)\n"
                      "    def on_trade(self, u):\n        self.u.append((u.kind, u.source, round(u.profit, 4)))\n")
        s = make()
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="b2")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        tk(s, "BTCUSD", 100.0, 100.0, t=1010)
        tk(s, "BTCUSD", 89.0, 89.0, t=1020)                         # chạm SL
        self.assertIn(("position_closed", "sl", -11.0), inst.bot.u)

    def test_timer_uses_market_time_in_backtest_mode(self):
        s, inst = self._run([(1000 + 20 * i, 100.0) for i in range(1, 13)], params={"timer": 60})
        self.assertEqual(inst.bot.timers, 4)                        # đặt lúc t=1000, tick mỗi 20s: nổ ở 1060, 1120, 1180, 1240

    def test_multi_timeframe_candles_from_resample(self):
        d = tempfile.mkdtemp()
        p = write_bot(d, "mtf.py", "from pyea import BaseBot\nclass B(BaseBot):\n    def on_init(self):\n        self.out = None\n"
                      "    def on_tick(self, t):\n        self.out = (self.api.candles(5, timeframe='15m'), self.api.candles(5, True, timeframe='15m'))\n")
        s = make()
        inst = s.attach(p, "BTCUSD", "5m", {}, iid="m1")
        from pyea.engine import CandleBuilder
        from pyea.sdk import Candle
        b = CandleBuilder(300, tf="5m")
        base = 1_700_000_100 - (1_700_000_100 % 900)
        hist = [Candle(base + 300 * i, 100 + i, 101 + i, 99 + i, 100.5 + i, 1) for i in range(12)]
        b.seed(hist, base + 300 * 12)
        s.builders[("BTCUSD", "5m")] = b
        tk(s, "BTCUSD", 112.0, 112.0, t=base + 300 * 12 + 5)
        inst.start()
        tk(s, "BTCUSD", 113.0, 113.0, t=base + 300 * 12 + 10)
        closed, with_cur = inst.bot.out
        self.assertTrue(closed)
        self.assertTrue(all(c.time % 900 == 0 for c in closed))
        self.assertEqual(len(with_cur), len(closed) + 1)            # có thêm nến 15m đang hình thành
        c0 = closed[0]
        self.assertEqual(c0.open, hist[0].open)                     # gộp đúng: open = nến 5m đầu
        self.assertEqual(c0.close, hist[2].close)
        self.assertEqual(c0.high, max(h.high for h in hist[:3]))
        with self.assertRaises(ValueError):
            inst.bot.api.candles(5, timeframe="1m")                 # nhỏ hơn khung của bot: không có dữ liệu


class TestSafetyNets(unittest.TestCase):
    def test_kill_switch_stops_bots_cancels_closes_and_blocks(self):
        alarms = []
        d = tempfile.mkdtemp()
        p = write_bot(d, "h.py", "from pyea import BaseBot\nclass B(BaseBot):\n    def on_tick(self, t):\n        if not self.api.positions(): self.api.buy(1)\n")
        s = make(alarms=alarms)
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="k1")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        tk(s, "BTCUSD", 100.0, 100.0, t=1010)
        s.send_order("BTCUSD", "buy", 1)
        s.place_pending("BTCUSD", "buy", "limit", 1, 90)
        self.assertEqual((len(s.account.positions), len(s.account.pending)), (2, 1))
        n_pos, n_ord = s.kill_switch("test")
        self.assertEqual((n_pos, n_ord), (2, 1))
        self.assertEqual((len(s.account.positions), len(s.account.pending)), (0, 0))
        self.assertTrue(s.halted)
        self.assertTrue(inst._stop.is_set())
        self.assertEqual(s.send_order("BTCUSD", "buy", 1).retcode, Ret.TRADE_DISABLED)
        self.assertTrue(any("KILL SWITCH" in a[0] for a in alarms))
        self.assertTrue(s.account_info().halted)
        s.resume_trading()
        self.assertTrue(s.send_order("BTCUSD", "buy", 1))

    def test_kill_switch_persisted_across_restart(self):
        with tempfile.TemporaryDirectory() as d:
            sf = os.path.join(d, "st.json")
            s = make()
            s.state_file = sf
            tk(s, "BTCUSD", 100.0, 100.0)
            s.kill_switch("x")
            s2 = make()
            s2.state_file = sf
            s2._load_state()
            self.assertTrue(s2.halted)

    def test_margin_call_once_and_stop_out_closes_worst(self):
        alarms = []
        s = make(alarms=alarms, initial_balance=1000.0, leverage=10.0, margin_call_level=150.0, stop_out_level=50.0)
        tk(s, "A", 100.0, 100.0, t=1000)
        tk(s, "B", 100.0, 100.0, t=1000)
        a = s.send_order("A", "buy", 50.0)              # margin 500
        b = s.send_order("B", "buy", 50.0)              # margin 1000 (tổng, equity 1000)
        self.assertTrue(a and b)
        self.assertAlmostEqual(s.account.margin_level(), 100.0 * 1000 / 1000)
        s._check_margin()
        s._check_margin()
        self.assertEqual(sum(1 for t, _ in alarms if t == "Margin call"), 1)      # chỉ báo 1 lần cho mỗi đợt
        tk(s, "A", 97.0, 97.0, t=1010)                  # A lỗ -150 => equity 850, mức 85%
        tk(s, "B", 99.0, 99.0, t=1010)                  # B lỗ -50
        s._check_margin()
        self.assertTrue(s.account.margin_level() is None or s.account.margin_level() > 50)
        tk(s, "A", 90.0, 90.0, t=1020)                  # A lỗ -500 => equity 450 trên margin 1000 = 45% <= 50
        s._check_margin()
        self.assertNotIn(a.id, s.account.positions)      # đóng vị thế lỗ nặng nhất (A)
        self.assertIn(b.id, s.account.positions)
        self.assertEqual(s.account.trades[-1].reason, "Stop-out")

    def test_circuit_breaker_tolerance(self):
        d = tempfile.mkdtemp()
        p = write_bot(d, "bad.py", "from pyea import BaseBot\nclass B(BaseBot):\n    def on_tick(self, t):\n        raise RuntimeError('boom')\n")
        # tolerance = 0 -> tắt ngay ở lần đầu
        s = make()
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="c0")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        with self.assertRaises(Exception):
            tk(s, "BTCUSD", 100.0, 100.0, t=1010)
        # tolerance = 2 -> lỗi 1,2 chỉ ghi log; lỗi thứ 3 mới tắt
        s = make(bot_error_tolerance=2)
        inst = s.attach(p, "BTCUSD", "1m", {}, iid="c2")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        inst.start()
        tk(s, "BTCUSD", 100.0, 100.0, t=1010)
        tk(s, "BTCUSD", 100.0, 100.0, t=1020)
        self.assertEqual(inst.cbstats.errors, 2)
        self.assertTrue(any("vẫn chạy" in l[3] for l in s.logs))
        with self.assertRaises(Exception) as cm:
            tk(s, "BTCUSD", 100.0, 100.0, t=1030)
        self.assertIn("circuit breaker", str(cm.exception))
        self.assertEqual(inst.summary()["metrics"]["errors"], 3)

    def test_hung_bot_detected_threaded(self):
        d = tempfile.mkdtemp()
        p = write_bot(d, "slow.py", "import time\nfrom pyea import BaseBot\nclass B(BaseBot):\n    def on_tick(self, t):\n        time.sleep(4)\n")
        st = default_settings()
        st.update(tick_interval=0.2, history_bars=60, bot_callback_timeout=0.6, max_loss_pct=0.0)
        r = BotRunner(p, st, {})
        r.start()
        try:
            self.assertTrue(wait(lambda: r.status == "error", 8), r.status)
            self.assertTrue(r.hung)
            self.assertIn("treo", r.message)
            self.assertTrue(r.summary()["hung"])
        finally:
            r.stop()


class TestAlerts(unittest.TestCase):
    def test_book_logic_and_persistence(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x.json")
            ab = AlertBook(path)
            for bad in (lambda: ab.add("X", "above", 0), lambda: ab.add("X", "pct", 1.0, ref=0), lambda: ab.add("X", "gì-đó", 1.0)):
                with self.assertRaises(ValueError):
                    bad()
            self.assertEqual(ab.symbols(), [])
        with tempfile.TemporaryDirectory() as d:
            ab = AlertBook(os.path.join(d, "a.json"))
            a = ab.add("BTCUSD", "above", 105.0)
            b = ab.add("BTCUSD", "below", 95.0, repeat=True)
            c = ab.add("BTCUSD", "pct", 2.0, ref=100.0, repeat=True)
            T = lambda px: Tick("BTCUSD", 1.0, px, px)                      # noqa: E731
            ids = sorted(x[0].id for x in ab.check(T(105.5)))
            self.assertEqual(ids, sorted([a.id, c.id]))
            self.assertEqual(ab.check(T(106.0)), [])                         # không báo lại khi đang ở trên ngưỡng
            self.assertFalse(ab.items[a.id].active)                          # loại 1 lần: tắt sau khi nổ
            self.assertAlmostEqual(ab.items[c.id].ref, 105.5)                # pct lặp: gốc mới
            self.assertEqual(sorted(x[0].id for x in ab.check(T(94.0))), sorted([b.id, c.id]))      # 'below' và pct (từ gốc mới 105.5)
            self.assertEqual(ab.check(T(93.0)), [])
            ab.check(T(96.0))                                                # quay lại trên ngưỡng -> nạp lại
            self.assertEqual([x[0].id for x in ab.check(T(94.5))], [b.id])   # nổ lần 2 (repeat)
            ab2 = AlertBook(ab.path)
            self.assertEqual(len(ab2.items), 3)
            self.assertEqual(ab2.items[b.id].count, 2)
            self.assertEqual(ab2.add("X", "above", 1.0).id, max(ab.items) + 1)
            ab2.clear_fired()
            self.assertNotIn(a.id, ab2.items)
            self.assertTrue(ab2.remove(b.id))

    def test_session_fires_alarm_and_note_event(self):
        alarms = []
        s = make(alarms=alarms)
        s.alerts = AlertBook(None)
        s.alert_add("BTCUSD", "above", 105.0, "phá đỉnh")
        tk(s, "BTCUSD", 100.0, 100.0, t=1000)
        self.assertEqual(alarms, [])
        tk(s, "BTCUSD", 106.0, 106.0, t=1010)
        self.assertEqual(len(alarms), 1)
        self.assertIn("phá đỉnh", alarms[0][1])
        self.assertTrue(any(e.kind == "note" and e.owner == "alert" for e in s.events))
        self.assertEqual(s.alerts.list()[0].fired_price, 106.0)
        s.alert_add("BTCUSD", "pct", 1.0)                                   # cần giá gốc từ tick hiện có
        self.assertEqual(s.alerts.list()[-1].ref, 106.0)
        with self.assertRaises(ValueError):
            s.alert_add("KHONGCO", "pct", 1.0)


class TestStatsHealthExports(unittest.TestCase):
    def _trades(self):
        mk = lambda i, pr, ct: Trade(id=i, symbol="X", side="buy", volume=1, open_price=1, close_price=1, open_time=ct - 5, close_time=ct,   # noqa: E731
                                     profit=pr, reason="Bot", owner="b")
        return [mk(1, 10, 1), mk(2, -4, 2), mk(3, -6, 3), mk(4, 8, 4)]

    def test_trade_stats(self):
        st = trade_stats(self._trades(), 1000.0)
        self.assertEqual((st["trades"], st["wins"], st["losses"]), (4, 2, 2))
        self.assertAlmostEqual(st["win_rate"], 50.0)
        self.assertAlmostEqual(st["profit"], 8.0)
        self.assertAlmostEqual(st["profit_factor"], 18 / 10)
        self.assertAlmostEqual(st["max_drawdown"], 10.0)                    # 10 -> 0 (đỉnh 10, đáy 0)
        self.assertAlmostEqual(st["max_drawdown_pct"], 1.0)
        self.assertEqual(trade_stats([])["trades"], 0)

    def test_connection_health_states(self):
        now = 1000.0
        self.assertEqual(connection_health([], {}, {}, 30, now)["state"], "idle")
        self.assertEqual(connection_health(["A", "B"], {}, {"A": 995, "B": 990}, 30, now)["state"], "connected")
        h = connection_health(["A", "B"], {}, {"A": 995, "B": 900}, 30, now)
        self.assertEqual((h["state"], h["stale"]), ("degraded", ["B"]))
        self.assertEqual(connection_health(["A", "B"], {"A": 5, "B": 5}, {"A": 999, "B": 999}, 30, now)["state"], "disconnected")
        self.assertEqual(connection_health(["A"], {}, {}, 30, now)["state"], "disconnected")      # chưa có tick nào
        self.assertEqual(connection_health(["A"], {}, {}, 0, now)["state"], "connected")           # tắt kiểm tra cũ

    def test_session_health_and_snapshot_fields(self):
        s = make()
        s.sync = False
        tk(s, "BTCUSD", 100.0, 100.0)
        s.watch = ["BTCUSD"]
        snap = s.snapshot()
        for k in ("health", "pending", "alerts", "margin_level", "free_margin", "halted", "read_only", "reserved"):
            self.assertIn(k, snap)
        self.assertEqual(snap["health"]["state"], "connected")
        s._tick_wall["BTCUSD"] = time.time() - 500
        self.assertEqual(s.health()["state"], "disconnected")

    def test_statement_csv_and_store_exports(self):
        csv_text = statement_csv(self._trades(), {"Số dư": 1008})
        self.assertIn("lãi/lỗ", csv_text)
        self.assertEqual(len(csv_text.strip().splitlines()), 1 + 1 + 1 + 4)        # tóm tắt + dòng trống + header + 4 lệnh
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            path = st.save_statement(self._trades(), {"a": 1})
            self.assertTrue(os.path.isfile(path))

    def test_backup_restore_masks_secrets_and_rejects_traversal(self):
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            a = Store(d1)
            a.install_bot_text("my.py", "from pyea import BaseBot\nclass B(BaseBot): pass\n")
            a.save_params("my.py", {"lot": 0.5})
            a.save_preset("my.py", "p1", {"lot": 1})
            a.save_settings(dict(default_settings(), api_key="KEY123", api_secret="SECRET456", oanda_token="TOK789", watchlist="AAA"))
            a.save_agents([{"name": "gpt", "api_key": "sk-abc", "model": "m"}])
            a.save_prefs({"chart": {"bars": 80}})
            z = a.export_backup()
            blob = b"".join(zipfile.ZipFile(z).read(n) for n in zipfile.ZipFile(z).namelist())
            for secret in (b"KEY123", b"SECRET456", b"TOK789", b"sk-abc"):
                self.assertNotIn(secret, blob)
            z2 = a.export_backup(include_secrets=True)
            self.assertIn(b"SECRET456", zipfile.ZipFile(z2).read("settings.json"))
            # khôi phục vào thư mục khác, giữ khoá hiện có nếu bản sao lưu bị xoá khoá
            b = Store(d2)
            b.save_settings(dict(default_settings(), api_key="OLDKEY"))
            n, warns = b.import_backup(z)
            self.assertGreaterEqual(n, 5)
            self.assertEqual(warns, [])
            self.assertEqual(b.load_settings()["watchlist"], "AAA")
            self.assertEqual(b.load_settings()["api_key"], "OLDKEY")
            self.assertEqual(b.load_params("my.py"), {"lot": 0.5})
            self.assertEqual(b.load_presets("my.py"), {"p1": {"lot": 1}})
            self.assertTrue(os.path.isfile(os.path.join(d2, "bots", "my.py")))
            # zip độc hại
            evil = os.path.join(d1, "evil.zip")
            with zipfile.ZipFile(evil, "w") as ez:
                ez.writestr("../../etc/pwn.txt", "x")
                ez.writestr("bots/../../escape.py", "x")
                ez.writestr("/abs.txt", "x")
                ez.writestr("random.bin", "x")
                ez.writestr("bots/ok.py", "x = 1")
            n, warns = b.import_backup(evil)
            self.assertEqual(n, 1)
            self.assertEqual(len(warns), 4)
            self.assertFalse(os.path.exists(os.path.join(d2, "..", "escape.py")))

    def test_diagnostics_bundle_has_no_secrets(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.save_settings(dict(default_settings(), api_secret="TOPSECRET"))
            with open(os.path.join(d, "crash.log"), "w") as f:
                f.write("Traceback...\nboom\n")
            with open(os.path.join(st.logs_dir, "run.log"), "w") as f:
                f.write("dòng log\n")
            z = zipfile.ZipFile(st.export_diagnostics("extra info"))
            names = z.namelist()
            self.assertIn("crash.log", names)
            self.assertIn("logs/run.log", names)
            self.assertIn("system.txt", names)
            self.assertNotIn(b"TOPSECRET", b"".join(z.read(n) for n in names))


class TestBotSafetyAndManifest(unittest.TestCase):
    def test_dangerous_code_blocked_unless_dev_mode(self):
        cases = {"import subprocess\n": "subprocess", "import os\nos.system('ls')\n": "os.system", "x = eval('1+1')\n": "eval",
                 "from ctypes import cdll\n": "ctypes", "exec('pass')\n": "exec", "m = __import__('os')\n": "__import__"}
        for code, key in cases.items():
            errs, warns, _ = loader.check_bot_source("from pyea import BaseBot\n" + code + "class B(BaseBot): pass\n")
            self.assertTrue(errs and key in errs[0], key)
            errs, warns, _ = loader.check_bot_source("from pyea import BaseBot\n" + code + "class B(BaseBot): pass\n", dev_mode=True)
            self.assertEqual(errs, [], key)
            self.assertTrue(any("nhà phát triển" in w for w in warns), key)
        errs, warns, _ = loader.check_bot_source("import requests, socket\nimport os\nprint(os.getcwd())\n")
        self.assertEqual(errs, [])
        self.assertEqual(len(warns), 3)                          # mạng: chỉ cảnh báo, không chặn (2 cảnh báo theo module + 1 nhắc khai báo quyền)
        self.assertTrue(any("@permission: network" in w for w in warns))
        errs, warns, _ = loader.check_bot_source("# @permission: network(api.example.com)\nimport requests, socket\nimport os\nprint(os.getcwd())\n")
        self.assertEqual(errs, [])
        self.assertEqual(len(warns), 2)                          # đã khai báo quyền mạng -> hết cảnh báo nhắc khai báo
        self.assertFalse(any("chưa khai báo" in w for w in warns))
        d = tempfile.mkdtemp()
        p = write_bot(d, "evil.py", "import subprocess\nfrom pyea import BaseBot\nclass B(BaseBot): pass\n")
        info = loader.inspect_bot(p)
        self.assertFalse(info.ok)
        self.assertIn("nguy hiểm", info.error)
        self.assertTrue(loader.inspect_bot(p, dev_mode=True).ok)
        with self.assertRaises(loader.BotLoadError):
            loader.load_bot_class(p)
        loader.DEV_MODE = True
        try:
            self.assertTrue(loader.inspect_bot(p).ok)
        finally:
            loader.DEV_MODE = False

    def test_api_min_manifest(self):
        errs, _, man = loader.check_bot_source("# @api_min: 99.0\n# @permissions: network, files\nfrom pyea import BaseBot\n")
        self.assertTrue(errs and "API" in errs[0])
        self.assertEqual(man["permissions"], ["network", "files"])
        errs, _, _ = loader.check_bot_source("# @api_min: %s\nfrom pyea import BaseBot\n" % API_VERSION)
        self.assertEqual(errs, [])
        d = tempfile.mkdtemp()
        p = write_bot(d, "new.py", "# @api_min: 9.9\nfrom pyea import BaseBot\nclass B(BaseBot): pass\n")
        self.assertIn("API", loader.inspect_bot(p).error)
        p = write_bot(d, "ok.py", "# @api_min: 1.0\nfrom pyea import BaseBot\nclass B(BaseBot): pass\n")
        info = loader.inspect_bot(p)
        self.assertTrue(info.ok)
        self.assertEqual(info.api_min, "1.0")

    def test_all_shipped_example_bots_pass_the_safety_check(self):
        ex = os.path.join(HERE, "..", "pyea", "examples")
        for n in os.listdir(ex):
            if n.endswith(".py.txt"):
                with open(os.path.join(ex, n), encoding="utf-8") as f:
                    errs, _, _ = loader.check_bot_source(f.read())
                self.assertEqual(errs, [], n)


class TestPendingGridExample(unittest.TestCase):
    def test_example_runs_in_backtest_and_places_pending_orders(self):
        from pyea.backtest import run_backtest
        store = Store(tempfile.mkdtemp())
        store.seed_examples()
        path = os.path.join(store.bots_dir, "pending_grid.py")
        info = loader.inspect_bot(path)
        self.assertTrue(info.ok, info.error)
        self.assertEqual(info.api_min, "1.1")
        import math, random                                          # chuỗi nến CỐ ĐỊNH (SimFeed phụ thuộc giờ máy nên test sẽ chập chờn)
        from pyea.sdk import Candle
        rnd, px, cs = random.Random(11), 1000.0, []
        for i in range(700):
            o = px
            px *= math.exp(rnd.gauss(0, 0.004))
            cs.append(Candle(1_700_000_100 - (1_700_000_100 % 300) + i * 300, o, max(o, px) * 1.001, min(o, px) * 0.999, px, 1.0))
        st = default_settings()
        st.update(initial_balance=100000.0, max_loss_pct=0.0, min_volume=0.01, volume_step=0.01)
        res = run_backtest(path, {"gap_pct": 0.1, "tp1_pct": 0.1, "ttl_min": 60}, st, "BTCUSD", "5m", cs, 100, "ohlc")
        self.assertTrue(res.ok, res.error)
        kinds = [e.kind for e in res.events]
        self.assertGreater(kinds.count("pending"), 3)
        self.assertGreater(kinds.count("open"), 0)                     # có lệnh chờ đã khớp thành vị thế
        self.assertTrue(any("một phần" in str(e.details) for e in res.events if e.kind == "close"))     # đóng một nửa
        self.assertTrue(any(e.kind == "cancel" for e in res.events))   # OCO / hết hạn dọn lệnh chờ


class TestBinancePermissions(unittest.TestCase):
    def test_warns_on_withdraw_and_missing_ip_restrict(self):
        b = BinanceBroker("k", "s", "http://x")
        b._signed = lambda m, p, q: {"enableWithdrawals": True, "ipRestrict": False, "enableSpotAndMarginTrading": True}
        w = b.check_permissions()
        self.assertTrue(any("RÚT TIỀN" in x for x in w))
        self.assertTrue(any("IP" in x for x in w))
        b._signed = lambda m, p, q: {"enableWithdrawals": False, "ipRestrict": True, "enableSpotAndMarginTrading": True}
        self.assertEqual(b.check_permissions(), [])
        b._signed = lambda m, p, q: (_ for _ in ()).throw(RuntimeError("testnet không có endpoint"))
        self.assertEqual(b.check_permissions(), [])


class TestBinanceFuturesPermissions(unittest.TestCase):
    def test_production_futures_asks_the_spot_host_and_checks_futures_flag(self):
        from pyea.broker import BinanceFuturesBroker
        b = BinanceFuturesBroker("k", "s", "https://fapi.binance.com")
        seen = {}

        def fake(m, p, q, base=None):
            seen.update(path=p, base=base)
            return {"enableWithdrawals": False, "ipRestrict": True, "enableFutures": False}
        b._signed = fake
        w = b.check_permissions()
        self.assertEqual((seen["path"], seen["base"]), ("/sapi/v1/account/apiRestrictions", "https://api.binance.com"))
        self.assertTrue(any("Futures" in x for x in w), w)

    def test_testnet_futures_host_is_skipped_without_any_request(self):
        from pyea.broker import BinanceFuturesBroker
        b = BinanceFuturesBroker("k", "s", "https://testnet.binancefuture.com")
        b._signed = lambda *a, **k: (_ for _ in ()).throw(AssertionError("không được gọi"))
        self.assertEqual(b.check_permissions(), [])


class TestResolveSpec(unittest.TestCase):
    def test_overrides_and_bad_json(self):
        st = default_settings()
        st.update(min_volume=0.1, volume_step=0.1, symbol_overrides=json.dumps({"XAUUSD": {"volume_min": 0.01, "trade_mode": "close_only", "zzz": 1}}))
        self.assertEqual(resolve_spec(st, "BTCUSD").volume_min, 0.1)
        x = resolve_spec(st, "XAUUSD")
        self.assertEqual((x.volume_min, x.trade_mode), (0.01, "close_only"))
        st["symbol_overrides"] = "{không phải json"
        self.assertEqual(resolve_spec(st, "XAUUSD").volume_min, 0.1)                   # JSON hỏng -> mặc định, không crash
        st["symbol_overrides"] = json.dumps({"XAUUSD": {"trade_mode": "bậy"}})
        self.assertEqual(resolve_spec(st, "XAUUSD").trade_mode, "full")


if __name__ == "__main__":
    unittest.main()
