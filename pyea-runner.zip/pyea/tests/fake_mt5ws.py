"""Máy chủ MT5 Web Terminal GIẢ - nói đúng khung/AES/bố cục byte của pymt5 (qua chính các hàm lược đồ của pyea.mt5ws). Chỉ để test, KHÔNG phải sàn thật.
LƯU Ý: vì dùng chung lược đồ với mã cần test nên test này kiểm tra logic/luồng, KHÔNG chứng minh bố cục byte khớp sàn thật."""
import os
import struct
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from pyea import mt5ws as M
from pyea.wsclient import accept_key, encode_frame, parse_frame

TZ = 7200                      # máy chủ giả chạy giờ UTC+2


def _zeros(sch):
    return [("" if c == "W" else b"" if c == "X" else 0) for c, _ in sch]


def _schema_w256():
    return M._schema("W256")


class FakeMt5Ws:
    def __init__(self, login="12345", password="pw", scale=1e8):
        self.login, self.password, self.scale = login, password, scale
        self.lock = threading.RLock()
        self.balance, self.credit = 10000.0, 0.0
        self.sym = {1: {"name": "EURUSD", "digits": 5, "bid": 1.10000, "ask": 1.10010, "vmin": 0.01, "vmax": 100.0, "vstep": 0.01, "contract": 100000.0},
                    2: {"name": "XAUUSD", "digits": 2, "bid": 2000.0, "ask": 2000.5, "vmin": 0.01, "vmax": 50.0, "vstep": 0.01, "contract": 100.0}}
        self.positions, self.orders, self.deals, self.log = {}, {}, [], []
        self.next = 5000
        self.fail_retcode = None
        self.drop_after_login = False
        self.demo = True
        self.conns = []
        self.logins = 0
        self.fill_flags = 3
        self.strip_comment = False   # sàn "làm mất" comment của lệnh (kiểm thử trường hợp không giữ nhãn)
        self.trade_mode, self.stops_level, self.freeze_level, self.calc_mode = 4, 10, 0, 0   # luật mã do sàn báo (trade_mode 4 = đầy đủ)
        self.time_flags = 0          # cờ hết hạn lệnh chờ mã cho phép (0 = không báo)
        self.book = None             # sổ lệnh giả {sid: (bids, asks)}; None = sàn không đẩy sổ lệnh
        self.hist_orders = []        # lịch sử LỆNH (huỷ/hết hạn/khớp) sàn trả trong lệnh 5
        self.schedule = None         # khối lịch phiên 896 byte (None = trống -> app dùng suy đoán theo giá)
        self.swap_trigger = False    # sàn "hiểu ngược" giá limit/stop của stop-limit (kiểm thử bảo vệ)
        self.mode = None            # kịch bản lỗi cho LẦN giao dịch kế: ("drop", applied) | ("ret", applied, retcode) | ("drop_login_broken", applied)
        self.history_bars = 5000
        self.groups = ["Forex", "Crypto"]
        self.spread_rows = [(1, 0, "EURUSD", 0, 0, 1.5)]
        self.links = [(1, "https://broker.example/support", "Hỗ trợ", 0)]
        self.notified, self.pw_changes, self.demos, self.inited = [], [], [], 0
        self.demo_reply = None        # None = mở được; ('code', n) = sàn từ chối
        self.logged_out = False
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.url = "ws://127.0.0.1:%d/terminal" % self.srv.server_address[1]
        self._stop = threading.Event()
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self._stop.set()
        self.srv.shutdown()
        self.srv.server_close()

    def nid(self):
        self.next += 1
        return self.next

    # ---- giá ----
    def tick_body(self, sid, bid=None, ask=None):
        s = self.sym[sid]
        b = s["bid"] if bid is None else bid
        a = s["ask"] if ask is None else ask
        t = int(time.time()) + TZ
        return M.pack_vals(M.S_TICK, [sid, t, 3, b, a, 0.0, 0, 0, 0])

    def push_account(self, balance=None):
        with self.lock:
            if balance is not None:
                self.balance = balance
            a = _zeros(M.S_ACCOUNT)
            a[0], a[3], a[4], a[5], a[7] = (1 if self.demo else 0), self.balance, self.credit, "USD", 500
            for c in self.conns:
                c["q"].append((14, 0, M.pack_vals(M.S_ACCOUNT, a)))

    def push_details(self, sid, high):
        with self.lock:
            v = [0.0 if c in "dfq" else 0 for c, _ in M.S_DETAILS]
            v[0], v[7] = sid, high
            for c in self.conns:
                c["q"].append((17, 0, M.pack_vals(M.S_DETAILS, v)))

    def push_trade_event(self, cmd=10):
        """Sàn đẩy sự kiện lệnh/vị thế (cmd 10 / 19) tới mọi kết nối."""
        with self.lock:
            for c in self.conns:
                c["q"].append((cmd, 0, b""))

    def book_body(self, sid):
        bids, asks = self.book[sid]
        out = [struct.pack("<I", 1), M.pack_vals(M.S_BOOK_HDR, [sid, 0, 0, len(bids), len(asks), 0])]
        for p, v in list(bids) + list(asks):
            out.append(M.pack_vals(M.S_BOOK_LVL, [p, int(round(v * self.scale))]))
        return b"".join(out)

    def set_price(self, sid, bid, ask=None, partial=False):
        with self.lock:
            s = self.sym[sid]
            s["bid"], s["ask"] = bid, ask if ask is not None else bid + (s["ask"] - s["bid"])
            for c in self.conns:
                if sid in c["subs"]:
                    c["q"].append((8, 0, self.tick_body(sid, bid, 0.0) if partial else self.tick_body(sid)))

    def px(self, sid, buy):
        return self.sym[sid]["ask" if buy else "bid"]

    # ---- bản ghi ----
    def _pos_bytes(self):
        out = [struct.pack("<I", len(self.positions))]
        for p in self.positions.values():
            cur = self.sym[p["sid"]]["bid"] if p["type"] == 0 else self.sym[p["sid"]]["ask"]
            profit = (cur - p["price"]) * (1 if p["type"] == 0 else -1) * self.sym[p["sid"]]["contract"] * p["vol"]
            v = _zeros(M.S_POSITION)
            v[:] = [p["id"], p["id"], int(p["t"]) + TZ, int(p["t"]) + TZ, self.sym[p["sid"]]["name"], p["type"], p["price"], 0.0, p.get("sl", 0.0), p.get("tp", 0.0),
                    int(round(p["vol"] * self.scale)), round(profit, 2), 0.0, 0.0, -3.5, -0.5, 0, 0, p.get("comment", ""), 100000.0, 5, 2, 0, "", 0, 0]
            v[16] = p.get("magic", 0)
            out.append(M.pack_vals(M.S_POSITION, v))
        out.append(struct.pack("<I", len(self.orders)))
        for o in self.orders.values():
            v = _zeros(M.S_ORDER)
            v[0], v[1], v[2], v[6], v[7] = o["id"], str(o["id"]), self.sym[o["sid"]]["name"], o["type"], o["filling"]
            v[8], v[4] = o["ttype"], o["exp"]
            v[10], v[11], v[13], v[14] = o["price"], o.get("trigger", 0.0), o.get("sl", 0.0), o.get("tp", 0.0)
            v[15] = v[16] = int(round(o["vol"] * self.scale))
            v[17], v[20], v[18] = 1, o.get("comment", ""), o.get("magic", 0)
            out.append(M.pack_vals(M.S_ORDER, v))
        return b"".join(out)

    def _deal_bytes(self, frm, to):
        rows = [d for d in self.deals if frm <= d["t"] + TZ <= to]
        out = [struct.pack("<I", len(rows))]
        for d in rows:
            v = _zeros(M.S_DEAL)
            v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7] = d["id"], str(d["id"]), d["order"], int(d["t"]) + TZ, int(d["t"]) + TZ, d["symbol"], d["action"], d["entry"]
            v[8], v[12], v[13], v[16], v[17] = d["price"], int(round(d["vol"] * self.scale)), d["profit"], d.get("comm", -3.5), d.get("swap", 0.0)
            v[19], v[20] = d["pos"], d.get("comment", "")
            v[25] = v[26] = 0
            out.append(M.pack_vals(M.S_DEAL, v))
        horders = [o for o in self.hist_orders if frm <= o["t_done"] + TZ <= to]
        out.append(struct.pack("<I", len(horders)))
        for o in horders:
            v = _zeros(M.S_ORDER)
            v[0], v[1], v[2], v[3], v[5] = o["id"], str(o["id"]), self.sym[o["sid"]]["name"], int(o["t_set"]) + TZ, int(o["t_done"]) + TZ
            v[6], v[10], v[11], v[15], v[16] = o["type"], o["price"], o.get("trigger", 0.0), int(round(o["vol"] * self.scale)), 0
            v[17], v[18], v[19], v[20] = o["state"], o.get("magic", 0), o.get("pos", 0), o.get("comment", "")
            out.append(M.pack_vals(M.S_ORDER, v))
        return b"".join(out)

    def _fullsym(self, name):
        sid = [k for k, s in self.sym.items() if s["name"] == name][0]
        s = self.sym[sid]
        cfg = _zeros(M.S_TRADECFG)
        cfg[3], cfg[4], cfg[5], cfg[7], cfg[8] = self.trade_mode, self.stops_level, self.freeze_level, self.fill_flags, self.time_flags
        cfg[20], cfg[21], cfg[22] = int(s["vmin"] * self.scale), int(s["vmax"] * self.scale), int(s["vstep"] * self.scale)
        v = _zeros(M.S_FULLSYM)
        v[0], v[21], v[22], v[24], v[32], v[33] = name, s["digits"], 10 ** -s["digits"], sid, 10 ** -s["digits"], s["contract"]
        v[13], v[14], v[15], v[35] = name[:3], name[3:6], name[:3], self.calc_mode
        v[47] = self.schedule or bytes(896)
        v[46] = M.pack_vals(M.S_TRADECFG, cfg)
        return struct.pack("<I", 1) + M.pack_vals(M.S_FULLSYM, v)

    def _bars(self, name, code, frm, to):
        mins = {v: k for k, v in M.PERIOD_CODE.items()}[code]
        step = mins * 60
        sid = [k for k, s in self.sym.items() if s["name"] == name][0]
        base = self.sym[sid]["bid"]
        now_s = int(time.time()) + TZ
        last_open = now_s // step * step
        first_ok = last_open - (self.history_bars - 1) * step
        out, t = [], max(frm // step * step, first_ok)
        while t <= min(to, last_open):
            k = (t // step) % 50
            o = base + k * 0.0001
            out.append(M.pack_vals(M.S_RATE, [t, o, o + 0.0005, o - 0.0005, o + 0.0002, 100 + k, 10]))
            t += step
        return b"".join(out)

    def _trade(self, v):
        _aid, action, name, vol, _dg, order, otype, filling, ttype, _tf, _rs, price, trig, sl, tp, dev, comment, pos, _by, exp = v
        self.log.append(dict(action=action, name=name, vol=vol, type=otype, filling=filling, price=price, sl=sl, tp=tp, order=order, pos=pos, ttype=ttype,
                             exp=exp, dev=dev, comment=comment))
        resp = lambda ret, order=0, vol=0, price=0.0, cm="": M.pack_vals(M.S_TRADE_RESP, [ret, 0, order, vol, price, 0.0, 0.0, cm, 0])
        if self.fail_retcode:
            r, self.fail_retcode = self.fail_retcode, None
            return resp(r, cm="rejected")
        sid = [k for k, s in self.sym.items() if s["name"] == name]
        sid = sid[0] if sid else None
        lots = vol / self.scale
        with self.lock:
            if action == M.ACT_DEAL and not pos:
                pr, oid = self.px(sid, otype == 0), self.nid()
                self.positions[oid] = {"id": oid, "sid": sid, "type": otype, "vol": lots, "price": pr, "t": time.time(), "magic": _rs,
                                       "comment": "" if self.strip_comment else comment, "orig": comment}
                self.deals.append({"id": self.nid(), "t": time.time(), "order": oid, "symbol": name, "action": otype, "entry": 0, "price": pr, "vol": lots, "profit": 0.0,
                                   "pos": oid, "comment": comment})
                return resp(10009, oid, vol, pr)
            if action == M.ACT_DEAL and pos:
                p = self.positions.get(pos)
                if not p:
                    return resp(10036)
                pr, oid = self.px(p["sid"], otype == 0), self.nid()
                prof = ((pr - p["price"]) * (1 if p["type"] == 0 else -1)) * self.sym[p["sid"]]["contract"] * lots
                self.deals.append({"id": self.nid(), "t": time.time(), "order": oid, "symbol": name, "action": otype, "entry": 1, "price": pr, "vol": lots,
                                   "profit": round(prof, 2), "pos": pos, "comment": "close"})
                self.balance += round(prof, 2)
                p["vol"] -= lots
                if p["vol"] <= 1e-9:
                    del self.positions[pos]
                return resp(10009, oid, vol, pr)
            if action == M.ACT_CLOSE_BY:
                a, b = self.positions.get(pos), self.positions.get(_by)
                if not a or not b or a["type"] == b["type"]:
                    return resp(10036)
                m = min(a["vol"], b["vol"])
                for q in (a, b):
                    q["vol"] -= m
                    if q["vol"] <= 1e-9:
                        del self.positions[q["id"]]
                self.deals.append({"id": self.nid(), "t": time.time(), "order": self.nid(), "symbol": name, "action": a["type"], "entry": 3, "price": a["price"], "vol": m,
                                   "profit": 0.0, "pos": pos, "comment": "close by"})
                return resp(10009, self.nid(), vol, a["price"])
            if action == M.ACT_SLTP:
                p = self.positions.get(pos)
                if not p:
                    return resp(10036)
                p["sl"], p["tp"] = sl, tp
                return resp(10009)
            if action == M.ACT_PENDING:
                oid = self.nid()
                self.orders[oid] = {"id": oid, "sid": sid, "type": otype, "vol": lots, "price": price, "sl": sl, "tp": tp, "filling": filling, "ttype": ttype,
                                    "exp": exp, "comment": "" if self.strip_comment else comment, "magic": _rs, "orig": comment, "trigger": trig}
                if self.swap_trigger:
                    self.orders[oid].update(price=trig, trigger=price)
                return resp(10008, oid, vol)
            if action == M.ACT_MODIFY:
                o = self.orders.get(order)
                if not o:
                    return resp(10013)
                o.update(price=price, sl=sl, tp=tp, trigger=trig, exp=exp)
                return resp(10009, order)
            if action == M.ACT_REMOVE:
                if order not in self.orders:
                    return resp(10013)
                del self.orders[order]
                return resp(10009, order)
        return resp(10013)

    # ---- xử lý lệnh ----
    def handle(self, conn, cmd, payload):
        if cmd == 0:
            conn["new_key"] = os.urandom(32)
            return 0, struct.pack("<H", 5687) + os.urandom(64) + conn["new_key"], True
        if cmd == 28:
            v = M.parse_at(payload, M.S_LOGIN)
            with self.lock:
                self.logins += 1
            if v[10] != int(self.login) or v[1] != self.password:
                return 7, b"", False
            return 0, bytes(160) + struct.pack("<Q", 777), False
        if cmd == 3:
            a = _zeros(M.S_ACCOUNT)
            a[0], a[1], a[3], a[4], a[5], a[7], a[8], a[10], a[11], a[14] = (1 if self.demo else 0), 0, self.balance, self.credit, "USD", 500, "Test", "Fake-Server", "Fake Co", 2
            return 0, M.pack_vals(M.S_ACCOUNT, a), False
        if cmd == 4:
            return 0, self._pos_bytes(), False
        if cmd == 2:
            self.logged_out = True
            return 0, b"", False
        if cmd == 9:
            return 0, struct.pack("<I", len(self.groups)) + b"".join(M.pack_vals(M.S_GROUP, [g]) for g in self.groups), False
        if cmd == 20:
            return 0, struct.pack("<I", len(self.spread_rows)) + b"".join(M.pack_vals(M.S_SPREAD, list(r)) for r in self.spread_rows), False
        if cmd == 44:
            return 0, struct.pack("<I", len(self.links)) + b"".join(M.pack_vals(M.S_CORP, [t, u, l, f, b""]) for t, u, l, f in self.links), False
        if cmd == 41:
            return 0, M.pack_vals(M.S_TRADER, ["p1", "p2"]), False
        if cmd == 42:
            self.notified.append(M.parse_at(payload, _schema_w256())[0])
            return 0, b"", False
        if cmd == 24:
            v = M.parse_at(payload, M.S_CHPW)
            self.pw_changes.append(v)
            if v[2] != self.password:
                return 0, struct.pack("<i", 3), False
            self.password = v[1]
            return 0, struct.pack("<i", 0), False
        if cmd == 29:
            self.inited += 1
            return 0, b"", False
        if cmd == 30:
            if not self.inited:
                return 5, b"", False
            if self.demo_reply:
                return self.demo_reply[1], b"", False
            v = M.parse_at(payload, M.S_OPEN_REQ)
            self.demos.append(v)
            return 0, M.pack_vals(M.S_OPEN_RES, [0, 9000001, "Pw123456", "Inv123456"]), False
        if cmd == 22:
            n = struct.unpack_from("<I", payload, 0)[0]
            ids = list(struct.unpack_from("<%dI" % n, payload, 4))
            with self.lock:
                conn.setdefault("books", set()).update(ids)
                if self.book:
                    for sid in ids:
                        if sid in self.book:
                            conn["q"].append((23, 0, self.book_body(sid)))
            return 0, b"", False
        if cmd == 5:
            frm, to = struct.unpack("<ii", payload[:8])
            return 0, self._deal_bytes(frm, to), False
        if cmd in (6, 34):
            recs = []
            for sid, s in self.sym.items():
                v = _zeros(M.S_SYMBOL)
                v[0], v[1], v[2], v[3] = s["name"], s["name"] + " desc", s["digits"], sid
                recs.append(M.pack_vals(M.S_SYMBOL, v))
            body = struct.pack("<I", len(recs)) + b"".join(recs)
            return 0, (struct.pack("<I", len(body)) + zlib.compress(body) if cmd == 34 else body), False
        if cmd == 7:
            n = struct.unpack_from("<I", payload, 0)[0]
            ids = list(struct.unpack_from("<%dI" % n, payload, 4))
            conn["subs"] = set(ids)
            return 0, b"".join(self.tick_body(i) for i in ids if i in self.sym), False
        if cmd == 11:
            name, code, frm, to = M.parse_at(payload, M._schema("W64 H i i"))
            return 0, self._bars(name, code, frm, to), False
        if cmd == 18:
            name = M.parse_at(payload, M._schema("W64"))[0]
            return 0, self._fullsym(name), False
        if cmd == 12:
            v = M.parse_at(payload, M.S_TRADE_REQ)
            if isinstance(self.mode, list):
                mode = self.mode.pop(0) if self.mode else None
            else:
                mode, self.mode = self.mode, None
            if mode is None:
                return 0, self._trade(v), False
            if mode[0] == "swallow":                         # áp dụng (hoặc không) rồi IM LẶNG, giữ nguyên kết nối
                if mode[1]:
                    self._trade(v)
                return -2, b"", False
            if mode[0] == "swallow_manual":                  # lệnh của app KHÔNG vào, nhưng người dùng tình cờ mở tay vị thế y hệt
                oid = self.nid()
                sid = [k for k, x in self.sym.items() if x["name"] == v[2]][0]
                self.positions[oid] = {"id": oid, "sid": sid, "type": v[6], "vol": v[3] / self.scale, "price": self.px(sid, v[6] == 0), "t": time.time(), "comment": "manual"}
                return -2, b"", False
            if mode[0] in ("drop", "drop_login_broken"):
                if mode[1]:
                    self._trade(v)
                if mode[0] == "drop_login_broken":
                    self.password = "changed-by-test"
                return -1, b"", False                       # đóng kết nối, không trả lời
            if mode[1]:
                self._trade(v)
            return 0, M.pack_vals(M.S_TRADE_RESP, [mode[2], 0, 0, 0, 0.0, 0.0, 0.0, "srv text", 0]), False
        return 0, b"", False

    def _handler(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def do_GET(self):
                fake.last_origin = self.headers.get("Origin")
                self.send_response(101)
                self.send_header("Upgrade", "websocket")
                self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", accept_key(self.headers.get("Sec-WebSocket-Key")))
                self.end_headers()
                self.wfile.flush()
                conn = {"q": [], "subs": set()}
                with fake.lock:
                    fake.conns.append(conn)
                cipher = M.AesCbc(M.initial_key())
                sock = self.connection
                sock.settimeout(0.05)
                buf = bytearray()

                def send(cmd, code, body):
                    raw = os.urandom(2) + struct.pack("<H", cmd) + bytes([code]) + body
                    enc = cipher.encrypt(raw)
                    sock.sendall(encode_frame(0x2, struct.pack("<II", len(enc), 1) + enc, mask=False))
                try:
                    while not fake._stop.is_set():
                        try:
                            d = sock.recv(65536)
                            if not d:
                                break
                            buf += d
                        except OSError as e:
                            if "timed out" not in str(e):
                                break
                        while True:
                            fr = parse_frame(buf)
                            if not fr:
                                break
                            fin, op, payload, used = fr
                            del buf[:used]
                            if op == 0x8:
                                return
                            if op != 0x2:
                                continue
                            inner = cipher.decrypt(payload[8:])
                            cmd = struct.unpack_from("<H", inner, 2)[0]
                            fake.log.append(("cmd", cmd))
                            code, body, switch = fake.handle(conn, cmd, inner[4:])
                            if code == -1:
                                return
                            if code == -2:
                                continue
                            send(cmd, code, body)
                            if switch:
                                cipher = M.AesCbc(conn["new_key"])
                            if cmd == 28 and code == 0 and fake.drop_after_login:
                                fake.drop_after_login = False
                                return
                        with fake.lock:
                            q, conn["q"] = conn["q"], []
                        for cmd, code, body in q:
                            send(cmd, code, body)
                except OSError:
                    pass
                finally:
                    with fake.lock:
                        if conn in fake.conns:
                            fake.conns.remove(conn)
                    self.close_connection = True
        return H
