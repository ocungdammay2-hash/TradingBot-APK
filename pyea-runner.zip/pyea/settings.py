"""Cài đặt chung của app (khai báo bằng Input để dùng chung bộ sinh form với bot)."""
from collections import OrderedDict

from . import i18n
from .feeds import TIMEFRAMES
from .sdk import Input

GLOBAL_INPUTS = OrderedDict([
    ("language", Input(i18n.label_of("vi"), "Ngôn ngữ / Language", choices=i18n.choices(), group="Ngôn ngữ / Language",
                       help="Chọn ngôn ngữ giao diện. Các nhãn chính (tab, nút, tiêu đề) đã dịch; mô tả dài, tên tham số bot và lời nhắn ghép số liệu vẫn "
                            "là tiếng Việt. Khởi động lại app để áp dụng đầy đủ. Chưa có Trung/Nhật/Hàn/Thái/Hindi/Ả Rập vì app chưa nhúng phông cho các chữ này.")),
    # ---- Thị trường ----
    ("exchange", Input("simulated", "Nguồn thị trường / sàn", choices=["simulated", "public", "binance_spot", "binance_futures", "oanda", "capital", "exness", "metaapi", "mt5gw", "bridge", "ctrader", "mt5ws", "mt5ea", "dnse", "ccxt"],
                       group="Thị trường",
                       help="simulated: giả lập offline (giá NGẪU NHIÊN) · public: GIÁ THẬT không cần tài khoản (crypto từ Binance, vàng/forex/chỉ số từ Yahoo; chỉ paper/xem/backtest) · binance: crypto · oanda: forex/vàng/chỉ số (có demo) · capital: Capital.com CFD (có demo; CHƯA thử với sàn thật) · exness: API Exness (VN/TH, tài khoản "
                            "Exness trading account) · metaapi / mt5gw / bridge: cầu nối MT4/MT5 (Exness MT5, mọi broker MetaTrader) · ctrader: broker cTrader (IC Markets, Pepperstone...) NỐI THẲNG từ điện thoại, không cần máy tính/VPS/trung gian · mt5ws: MỌI broker MT5 NỐI THẲNG từ điện thoại bằng giao thức MT5 Web Terminal (không chính thức, CHƯA thử sàn thật; thử DEMO trước) · dnse: chứng khoán/phái sinh VN (DNSE LightSpeed API V1; CHƯA thử tài khoản thật) · ccxt: ~100 sàn khác")),
    ("mode", Input("paper", "Chế độ", choices=["paper", "live"], group="Thị trường",
                   help="paper = giao dịch giả lập (giá thật nếu chọn sàn thật); live = TIỀN THẬT")),
    ("watchlist", Input("BTCUSD,ETHUSD,EURUSD,XAUUSD,US500,AAPL", "Danh sách theo dõi (Market Watch)", group="Thị trường",
                        help="Mã cách nhau dấu phẩy. Binance: BTCUSDT; OANDA: EUR_USD, XAU_USD; giả lập: BTCUSD, EURUSD...")),
    # ---- Tài khoản giả lập ----
    ("initial_balance", Input(1000.0, "Số dư ban đầu (paper)", min=1.0, group="Tài khoản / rủi ro")),
    ("leverage", Input(1.0, "Đòn bẩy", min=1.0, max=125.0, group="Tài khoản / rủi ro",
                       help="Giới hạn tổng giá trị lệnh theo vốn")),
    ("commission_pct", Input(0.1, "Phí mỗi chiều (%)", min=0.0, max=5.0, group="Tài khoản / rủi ro")),
    ("max_loss_pct", Input(20.0, "Dừng bot nếu lỗ quá (%)", min=0.0, max=100.0, group="Tài khoản / rủi ro",
                           help="0 = tắt. Đóng hết lệnh và dừng khi equity giảm quá mức này")),
    ("close_on_stop", Input(True, "Đóng hết lệnh khi dừng bot", group="Tài khoản / rủi ro")),
    ("daily_loss_pct", Input(0.0, "Giới hạn lỗ TRONG NGÀY (% vốn đầu ngày)", min=0.0, max=100.0, group="Tài khoản / rủi ro",
                             help="0 = tắt. Lỗ trong ngày (gồm lãi/lỗ thả nổi) chạm mức này thì CHẶN lệnh MỚI tới hết ngày, kể cả khi equity hồi lại. Đóng lệnh/SL/TP vẫn chạy. "
                                  "Tính theo sổ của app, không gồm lệnh đặt ngoài app")),
    ("daily_loss_money", Input(0.0, "Giới hạn lỗ TRONG NGÀY (số tiền)", min=0.0, group="Tài khoản / rủi ro",
                               help="0 = tắt. Dùng cùng ô % ở trên thì lấy mức NHỎ hơn")),
    ("daily_loss_action", Input("block", "Khi chạm giới hạn lỗ ngày", choices=["block", "close_block"], group="Tài khoản / rủi ro",
                                help="block = chỉ chặn lệnh mới · close_block = đóng luôn mọi vị thế rồi chặn")),
    ("daily_reset_hour", Input(0.0, "Giờ bắt đầu «ngày» (0-23)", min=0.0, max=23.0, group="Tài khoản / rủi ro",
                               help="Theo múi giờ hiển thị của app (Cài đặt → Giờ hiển thị). 0 = nửa đêm; vd 5 = ngày mới bắt đầu 05:00")),
    # ---- Giao dịch (vỏ): luật & an toàn ----
    ("read_only", Input(False, "Chế độ CHỈ-XEM (không gửi lệnh mới)", group="Giao dịch & an toàn",
                        help="Bot vẫn chạy để xem tín hiệu nhưng vỏ chặn mọi lệnh mới (vẫn cho đóng lệnh/huỷ lệnh chờ)")),
    ("confirm_trades", Input(True, "Hỏi xác nhận khi đặt lệnh tay", group="Giao dịch & an toàn",
                             help="Tắt = 'một chạm' (one-click trading) - chỉ nên tắt khi đã quen")),
    ("default_volume", Input(0.0, "Khối lượng mặc định khi đặt lệnh tay", min=0.0, group="Giao dịch & an toàn",
                             help="0 = tự chọn theo loại tài sản (BTC 0.01, forex 1000, vàng 0.1...)")),
    ("default_sl_pct", Input(0.0, "SL mặc định khi đặt lệnh tay (% cách giá)", min=0.0, max=50.0, group="Giao dịch & an toàn",
                             help="0 = không tự đặt. Ô Stop Loss để trống khi đặt lệnh tay thì vỏ dùng mức này (mua: dưới giá, bán: trên giá)")),
    ("default_tp_pct", Input(0.0, "TP mặc định khi đặt lệnh tay (% cách giá)", min=0.0, max=500.0, group="Giao dịch & an toàn",
                             help="0 = không tự đặt. Ô Take Profit để trống thì dùng mức này")),
    ("min_volume", Input(0.0, "Khối lượng tối thiểu", min=0.0, group="Giao dịch & an toàn", help="0 = không kiểm tra")),
    ("max_volume", Input(0.0, "Khối lượng tối đa mỗi lệnh", min=0.0, group="Giao dịch & an toàn", help="0 = không giới hạn")),
    ("volume_step", Input(0.0, "Bước khối lượng (step)", min=0.0, group="Giao dịch & an toàn",
                          help="Vỏ làm tròn XUỐNG theo bước này; 0 = không ràng buộc")),
    ("stop_level_pct", Input(0.0, "Khoảng cách tối thiểu SL/TP (% giá)", min=0.0, max=50.0, group="Giao dịch & an toàn",
                             help="Như 'stop level' của MT5; 0 = không kiểm tra")),
    ("freeze_level_pct", Input(0.0, "Vùng freeze quanh giá (% giá)", min=0.0, max=50.0, group="Giao dịch & an toàn",
                               help="Như 'freeze level' của MT5: lệnh chờ / SL-TP nằm trong vùng này quanh giá thì KHÔNG sửa hoặc huỷ được (trả mã FROZEN). "
                                    "0 = tắt. Ghi đè theo mã bằng freeze_level_pct trong «Luật riêng theo mã»")),
    ("symbol_overrides", Input("", "Luật riêng theo mã (JSON)", group="Giao dịch & an toàn",
                               help='Vd {"XAUUSD":{"volume_min":0.01,"volume_step":0.01,"trade_mode":"close_only"}} · '
                                    'trade_mode: full|long_only|short_only|close_only|disabled')),
    ("max_slippage_pct", Input(0.0, "Cảnh báo nếu trượt giá quá (%)", min=0.0, max=10.0, group="Giao dịch & an toàn",
                               help="Chỉ áp dụng live: so giá khớp với giá lúc gửi; 0 = tắt")),
    ("stale_after", Input(30.0, "Chặn lệnh nếu giá cũ hơn (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                          help="Mất kết nối giá thì KHÔNG gửi lệnh bằng giá cũ. 0 = tắt")),
    ("margin_call_level", Input(100.0, "Cảnh báo margin call khi mức ký quỹ ≤ (%)", min=0.0, group="Giao dịch & an toàn",
                                help="Mức ký quỹ = equity / ký quỹ đang dùng × 100. 0 = tắt")),
    ("stop_out_level", Input(0.0, "Stop-out: tự đóng lệnh lỗ nặng nhất khi mức ký quỹ ≤ (%)", min=0.0, group="Giao dịch & an toàn",
                             help="0 = tắt. Mỗi lần chỉ đóng 1 vị thế, như MT5")),
    ("bot_error_tolerance", Input(0, "Bot được lỗi bao nhiêu lần/giờ trước khi bị tắt", min=0, max=1000, group="Giao dịch & an toàn",
                                  help="0 = tắt bot ngay ở lỗi đầu tiên. >0 = ghi lỗi và chạy tiếp, vượt ngưỡng mới tắt (circuit breaker)")),
    ("bot_callback_timeout", Input(30.0, "Coi bot là TREO nếu một hàm chạy quá (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                                   help="Python không giết được luồng đang treo; vỏ báo động, đánh dấu lỗi và ngừng đưa tick cho bot. 0 = tắt")),
    ("reconcile_interval", Input(60.0, "Đối soát vị thế với sàn mỗi (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                                 help="Chỉ live (Binance Futures/OANDA). So sổ lệnh của app với vị thế THẬT trên sàn. 0 = tắt")),
    ("reconcile_policy", Input("adopt", "Khi lệch vị thế với sàn", choices=["alert", "adopt", "off"], group="Giao dịch & an toàn",
                               help="adopt (mặc định) = báo động + sổ app tự đổi theo SÀN sau khi xác nhận hai lần: chỉ đóng/nhập PHẦN CHÊNH, giá ra lấy từ lần khớp thật của sàn · "
                                    "alert = chỉ báo động (sổ app giữ nguyên, bạn tự xử lý) · off = tắt")),
    ("link_alarm_s", Input(30.0, "Báo động khi mất kết nối giá/sàn quá (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                           help="Một đợt mất mạng = một báo động nghiêm trọng, nói rõ vị thế nào KHÔNG có ai canh SL/TP lúc đó. 0 = tắt")),
    ("link_repeat_min", Input(10.0, "Nhắc lại khi VẪN mất kết nối mỗi (phút)", min=0.0, max=1440.0, group="Giao dịch & an toàn",
                              help="0 = không nhắc lại. Khi có lại kết nối app báo và đối soát với sàn ngay")),
    ("feed_halt_min", Input(0.0, "Dừng phiên nếu mất giá liên tục quá (phút)", min=0.0, max=1440.0, group="Giao dịch & an toàn",
                            help="0 = KHÔNG BAO GIỜ dừng (mặc định): app tiếp tục thử lại và tự chạy lại khi có mạng. Dừng phiên không đóng được lệnh, "
                                 "chỉ khiến app ngừng canh vị thế kể cả khi mạng đã về")),
    ("reconcile_scope", Input("app", "Phạm vi đối soát", choices=["app", "all"], group="Giao dịch & an toàn",
                              help="app = chỉ các mã app đang dùng · all = mọi vị thế trên tài khoản sàn (cả lệnh bạn tự vào)")),
    ("dev_mode", Input(False, "Chế độ nhà phát triển (cho phép bot dùng subprocess/eval/exec...)", group="Giao dịch & an toàn",
                       help="Mặc định vỏ chặn các mã nguy hiểm trong file bot. Chỉ bật khi TIN file bot")),
    # ---- Lịch kinh tế ----
    ("calendar_enabled", Input(False, "Bật lịch kinh tế", group="Lịch kinh tế",
                               help="Nạp lịch tin từ NGUỒN BẠN CHỌN (bên dưới) và báo trước tin quan trọng. Lịch hỏng/mất mạng thì app KHÔNG chặn gì")),
    ("calendar_source", Input("", "Nguồn lịch (URL hoặc đường dẫn file)", group="Lịch kinh tế",
                              help="ĐỂ TRỐNG hoặc gõ auto = dùng lịch tuần này MIỄN PHÍ có sẵn (nguồn không chính thức, nạp tối đa 1 lần/giờ). Muốn nguồn riêng: dán URL/đường dẫn file. JSON (danh sách hoặc {\"events\": [...]}) hoặc CSV có dòng tiêu đề. Mỗi tin cần: giờ (date, ISO có múi giờ hoặc epoch), tiêu đề (title), "
                                   "tiền tệ (country, vd USD), mức (impact: Holiday/Low/Medium/High), tuỳ chọn forecast/previous. App không gắn cứng nhà cung cấp nào")),
    ("calendar_refresh_h", Input(6.0, "Nạp lại lịch mỗi (giờ)", min=0.1, max=168.0, group="Lịch kinh tế")),
    ("calendar_min_impact", Input("high", "Báo trước tin có mức từ", choices=["low", "medium", "high"], group="Lịch kinh tế")),
    ("calendar_alert_min", Input(15.0, "Báo trước tin (phút)", min=0.0, max=240.0, group="Lịch kinh tế",
                                 help="0 = không báo. Chỉ báo tin có tiền tệ liên quan tới mã đang theo dõi / đang có vị thế")),
    ("calendar_currencies", Input("", "Tiền tệ cần theo dõi (tuỳ chọn)", group="Lịch kinh tế",
                                  help="Vd USD,EUR. Để trống = tự suy từ mã (EURUSD→EUR+USD, XAUUSD/BTCUSDT→USD). Điền vào = ghi đè mọi suy luận")),
    ("news_block", Input(False, "Chặn lệnh MỚI của bot/AI quanh giờ ra tin", group="Lịch kinh tế",
                         help="Chỉ chặn mở vị thế/đặt lệnh chờ MỚI (trả mã NEWS_BLOCK). Đóng lệnh, SL/TP, kill switch luôn chạy; lệnh bạn bấm tay không bị chặn. "
                              "Không áp dụng khi backtest")),
    ("news_block_min_impact", Input("high", "Chặn khi tin có mức từ", choices=["low", "medium", "high"], group="Lịch kinh tế")),
    ("news_block_before_min", Input(15.0, "Chặn TRƯỚC giờ ra tin (phút)", min=0.0, max=240.0, group="Lịch kinh tế")),
    ("news_block_after_min", Input(15.0, "Chặn SAU giờ ra tin (phút)", min=0.0, max=240.0, group="Lịch kinh tế")),
    # ---- Webhook TradingView chạy NGAY TRONG APP (pyea/webhooksrv.py; docs/WEBHOOK.md) ----
    ("webhook_enabled", Input(False, "Bật máy chủ webhook trong app", group="Webhook TradingView (trong app)",
                              help="TẮT mặc định. Điện thoại không có địa chỉ công khai: TradingView chỉ gọi được cổng 80/443 của một địa chỉ công khai, nên cần ĐƯỜNG HẦM (cloudflared/ngrok…) trỏ về cổng bên dưới. Đọc docs/WEBHOOK.md TRƯỚC khi bật. "
                                   "Chỉ chạy khi phiên đang kết nối (không chạy khi backtest)")),
    ("webhook_secret", Input("", "Webhook secret (≥ 16 ký tự)", secret=True, group="Webhook TradingView (trong app)",
                             help="Chuỗi bí mật nằm trong JSON của alert TradingView (TradingView không ký HMAC được). Dài, ngẫu nhiên, KHÔNG dùng lại mật khẩu nơi khác. Đường dẫn qua HTTP thường: ai nghe lén được mạng giữa TradingView và máy bạn đều đọc được nó - dùng đường hầm HTTPS")),
    ("webhook_dry_run", Input(True, "Webhook CHỈ KIỂM TRA, không đặt lệnh (khuyên bật khi mới nối)", group="Webhook TradingView (trong app)",
                              help="Bật = nhận và kiểm tra tín hiệu, ghi nhật ký nhưng KHÔNG đặt lệnh. Thử xong mới tắt")),
    ("webhook_port", Input(8787, "Cổng nghe (1024-65535)", min=1024, max=65535, group="Webhook TradingView (trong app)",
                           help="Cổng TRÊN MÁY NÀY mà đường hầm trỏ vào (Android không cho mở cổng dưới 1024). Địa chỉ công khai trên TradingView vẫn là cổng 80/443 của đường hầm")),
    ("webhook_bind", Input("127.0.0.1", "Địa chỉ nghe", choices=["127.0.0.1", "0.0.0.0"], group="Webhook TradingView (trong app)",
                           help="127.0.0.1 = chỉ chính điện thoại này (đường hầm chạy cùng máy, an toàn nhất) · 0.0.0.0 = cả mạng Wi-Fi/LAN (HTTP thường, ai trong mạng cũng gửi được tới - chỉ dùng khi tin mạng đó)")),
    ("webhook_symbols", Input("", "Chỉ nhận các mã (cách nhau dấu phẩy; trống = mọi mã)", group="Webhook TradingView (trong app)",
                              help="Danh sách cho phép SAU khi đổi mã (xem ánh xạ bên dưới). Nên điền: khi lộ secret kẻ xấu chỉ đặt được những mã này")),
    ("webhook_max_volume", Input(0.0, "Khối lượng TỐI ĐA mỗi lệnh (0 = không giới hạn)", min=0.0, group="Webhook TradingView (trong app)",
                                 help="Tín hiệu vượt mức bị từ chối. BẮT BUỘC > 0 khi chạy LIVE và không ở chế độ chỉ-kiểm-tra: phòng gõ nhầm số lượng trong alert hoặc lộ secret")),
    ("webhook_close_scope", Input("own", "«close»/«close_all» đóng", choices=["own", "all"], group="Webhook TradingView (trong app)",
                                  help="own = chỉ vị thế do webhook mở (an toàn: không đụng lệnh tay/bot) · all = mọi vị thế của mã đó (hoặc tất cả với close_all)")),
    ("webhook_ips", Input("", "IP nguồn cho phép (trống = không lọc; «tradingview» = 4 IP chính thức)", group="Webhook TradingView (trong app)",
                          help="Chỉ có ý nghĩa khi bật «Tin tiêu đề X-Forwarded-For» bên dưới nếu đi qua đường hầm (không thì app chỉ thấy IP của đường hầm). Cách nhau dấu phẩy")),
    ("webhook_trust_proxy", Input(False, "Tin tiêu đề X-Forwarded-For (chỉ bật khi đi qua đường hầm/proxy BẠN kiểm soát)", group="Webhook TradingView (trong app)",
                                  help="Bật khi có đường hầm: IP thật lấy từ mục CUỐI của X-Forwarded-For. Đừng bật khi mở thẳng 0.0.0.0 (ai cũng giả được tiêu đề này)")),
    ("webhook_symbol_map", Input("", "Ánh xạ mã TradingView → mã sàn (vd BINANCE:BTCUSDT=BTCUSD,VN30F1M=VN30F2612)", group="Webhook TradingView (trong app)",
                                 help="App không đoán tên mã của sàn: mã hợp đồng liên tục như VN30F1M phải khai ở đây. Tiền tố sàn «BINANCE:» và hậu tố «.P»/«1!» tự bỏ")),
    ("webhook_symbol_suffix", Input("", "Hậu tố thêm vào mọi mã (vd .m của Exness)", group="Webhook TradingView (trong app)")),
    # ---- Vận hành ----
    ("max_bot_objects", Input(300, "Số đối tượng vẽ tối đa mỗi bot (api.draw_*)", min=10, max=5000, group="Vận hành")),
    ("binance_ws", Input(True, "Giá Binance đẩy qua WebSocket (tự quay về REST nếu mất)", group="Vận hành")),
    ("tick_interval", Input(1.0, "Chu kỳ lấy giá (giây)", min=0.2, max=60.0, group="Vận hành")),
    ("spread_pct", Input(0.01, "Spread giả lập (% giá)", min=0.0, max=5.0, group="Vận hành",
                         help="Dùng trong backtest và nguồn giả; giá thật dùng bid/ask thật")),
    ("history_bars", Input(500, "Số nến lịch sử nạp sẵn", min=50, max=1000, group="Vận hành",
                          help="Càng nhiều càng kéo lùi biểu đồ được xa, nhưng nạp lâu hơn")),
    ("chart_bars", Input(400, "Số nến đưa lên biểu đồ", min=100, max=1000, group="Vận hành",
                         help="Số nến tối đa kéo lùi được trên biểu đồ. Giảm để tiết kiệm pin/bộ nhớ flash khi chạy nền")),
    ("theme", Input("dark", "Giao diện", choices=["dark", "light", "auto"], group="Vận hành",
                    help="dark = nền tối (mặc định) · light = nền sáng · auto = theo chế độ tối của Android. Đổi xong phải MỞ LẠI app mới áp dụng đủ")),
    ("net_alert", Input("connected", "Cảnh báo mất mạng", choices=["connected", "always", "off"], group="Vận hành",
                        help="connected = chỉ khi đang KẾT NỐI/chạy bot (mặc định) · always = luôn · off = tắt. Chạm vào dải đỏ để tắt cảnh báo đến khi có mạng lại.")),
    ("secure_screen", Input("off", "Chặn chụp/quay màn hình", choices=["off", "sensitive", "always"], group="Vận hành",
                            help="off = chụp/quay màn hình bình thường (mặc định) · sensitive = chỉ chặn khi đang ở tab Cài đặt (nơi hiện API key/khoá riêng) · always = mọi màn hình · off = không chặn. "
                                 "Chỉ có tác dụng trên Android (FLAG_SECURE); cũng che ảnh xem trước app ở màn hình đa nhiệm")),
    ("keep_awake", Input(False, "Giữ màn hình sáng khi chạy", group="Vận hành",
                         help="Chỉ cần khi KHÔNG dùng dịch vụ nền (tốn pin)")),
    ("idle_fps_save", Input(True, "Tiết kiệm pin: hạ tốc độ khung hình khi KHÔNG chạm màn hình", group="Vận hành",
                            help="Sau 15 giây không chạm, giao diện chạy 20 khung/giây thay vì 60 (dữ liệu vẫn cập nhật mỗi giây như cũ); chạm lại là về 60 ngay. "
                                 "Cơ chế này chưa đo được trên máy thật (sandbox không có Kivy thật) - tắt nếu thấy giật khi vừa chạm")),
    ("check_updates", Input(False, "Kiểm tra bản cập nhật khi mở app", group="Hỗ trợ & cập nhật",
                            help="Mặc định TẮT. Bật + nhập kho GitHub bên dưới: app hỏi API công khai của GitHub (tối đa 1 lần/ngày) và chỉ BÁO có bản mới, không tự cài.")),
    ("update_repo", Input("", "Kho GitHub chứa bản phát hành (chủ/tên)", group="Hỗ trợ & cập nhật",
                          help="Ví dụ nguoidung/TradingBot-APK. Cần có Releases đính kèm file .apk.")),
    ("crash_report_auto", Input(False, "Tự gửi báo lỗi khi app gặp sự cố", group="Hỗ trợ & cập nhật",
                                help="Mặc định TẮT. Bật + nhập địa chỉ bên dưới: lần mở app sau sự cố, gửi phần mới của crash.log (đã che khoá/bí mật) tới địa chỉ đó. "
                                     "Chỉ gửi tới máy chủ BẠN chỉ định; app không có máy chủ riêng của tác giả.")),
    ("crash_report_url", Input("", "Địa chỉ nhận báo lỗi (https://...)", group="Hỗ trợ & cập nhật",
                               help="Máy chủ của bạn/nhóm hỗ trợ nhận POST JSON {app, version, time, platform, report}.")),
    ("ui_refresh", Input(1.0, "Tần suất cập nhật giao diện (giây)", min=0.5, max=10.0, group="Vận hành",
                         help="Tăng lên để tiết kiệm pin")),
    ("sim_speed", Input(10.0, "Tốc độ giả lập (x)", min=1.0, max=5000.0, group="Giả lập",
                        help="1 giây thật = bao nhiêu giây giả lập")),
    ("sim_start_price", Input(30000.0, "Giá khởi điểm giả lập", min=0.000001, group="Giả lập")),
    # ---- Chạy nền & cảnh báo ----
    ("background_service", Input(True, "Chạy nền bằng dịch vụ (khuyên dùng)", group="Chạy nền & cảnh báo",
                                 help="Bot sống khi tắt màn hình / thoát app, có thông báo trên thanh trạng thái")),
    ("auto_resume", Input(True, "Tự khôi phục phiên sau sự cố", group="Chạy nền & cảnh báo",
                          help="Nếu dịch vụ bị hệ thống giết/crash, tự chạy lại bot với sổ lệnh đã lưu")),
    ("start_on_boot", Input(True, "Tự chạy lại bot sau khi khởi động máy", group="Chạy nền & cảnh báo",
                            help="Nếu bot đang chạy mà máy tắt/khởi động lại, app tự dựng lại dịch vụ và khôi phục phiên ngay khi máy mở khoá lần đầu "
                                 "(cần «Tự khôi phục phiên sau sự cố»). Bạn chủ động bấm Ngắt thì sẽ không tự chạy lại. "
                                 "Phải mở khoá máy một lần; một số ROM (Xiaomi/Oppo/Vivo...) cần cấp quyền «Tự khởi động» cho app. Chưa kiểm chứng trên máy thật")),
    ("boot_alert", Input(True, "Báo động (âm báo thức) khi máy tự khởi động lại", group="Chạy nền & cảnh báo",
                         help="Bật: máy khởi động lại lúc bot đang chạy thì phát âm báo thức + rung, lặp tới khi vuốt bỏ. Tắt: chỉ một thông báo thường. "
                              "Chế độ Không làm phiền có thể vẫn chặn tiếng. Chưa kiểm chứng trên máy thật")),
    ("watchdog_alarm", Input(True, "Báo thức giám sát dịch vụ (AlarmManager)", group="Chạy nền & cảnh báo",
                             help="Khi phiên đang chạy, dịch vụ liên tục dời một báo thức; nếu Android giết dịch vụ thì báo thức nổ và dựng lại dịch vụ rồi khôi phục phiên "
                                  "(cần «Tự khôi phục phiên sau sự cố»). Buộc dừng app trong Cài đặt Android sẽ xoá báo thức. Chưa kiểm chứng trên máy thật")),
    ("watchdog_minutes", Input(5.0, "Chu kỳ báo thức giám sát (phút)", min=1.0, max=30.0, group="Chạy nền & cảnh báo",
                               help="Dịch vụ chết thì tối đa chừng này phút sau mới được dựng lại (Doze có thể làm trễ thêm)")),
    ("power_mode", Input("balanced", "Chế độ năng lượng", choices=["balanced", "saver"],
                         group="Chạy nền & cảnh báo",
                         help="saver: khi app ở nền chỉ lấy giá ≥3 giây/lần để tiết kiệm pin")),
    ("notify_trades", Input(False, "Thông báo mỗi khi mở/đóng lệnh", group="Chạy nền & cảnh báo")),
    ("notify_sound", Input(True, "Thông báo cảnh báo có âm thanh", group="Chạy nền & cảnh báo",
                           help="Tắt = cảnh báo vẫn hiện nhưng im lặng (Android 8+ tạo kênh thông báo riêng cho từng tổ hợp âm/rung)")),
    ("notify_vibrate", Input(True, "Thông báo cảnh báo có rung", group="Chạy nền & cảnh báo")),
    ("dnd_critical_pass", Input(True, "Không làm phiền: VẪN kêu cảnh báo nghiêm trọng", group="Chạy nền & cảnh báo",
                                help="Bật (khuyên dùng): kill switch, margin call, bot/dịch vụ lỗi hoặc treo, lệch vị thế... vẫn có âm/rung dù đang «Không làm phiền». "
                                     "Tắt = im lặng hoàn toàn (cảnh báo vẫn hiện thông báo im lặng) - bạn tự chịu rủi ro bỏ lỡ sự cố")),
    ("dnd_from", Input("", "Khung yên tĩnh hằng ngày: từ (HH:MM)", group="Chạy nền & cảnh báo",
                       help="Vd 22:00 - theo giờ máy. Để trống cả «từ» và «đến» = không dùng. Muốn tạm tắt N giờ: dùng nút ở cuối màn Cài đặt")),
    ("dnd_to", Input("", "Khung yên tĩnh hằng ngày: đến (HH:MM)", group="Chạy nền & cảnh báo", help="Vd 07:00 (qua nửa đêm được)")),
    # ---- Hiển thị ----
    ("time_display", Input("local", "Giờ hiển thị", choices=["local", "utc", "offset"], group="Hiển thị",
                           help="local = giờ máy · utc · offset = UTC + số giờ bên dưới (vd giờ máy chủ broker). Chỉ đổi cách HIỂN THỊ, dữ liệu vẫn UTC")),
    ("lot_display", Input("native", "Hiển thị khối lượng", choices=["native", "units", "both"], group="Hiển thị",
                          help="native = như sàn/MT (lot). units = nhân kích thước hợp đồng (vd 0.1 lot EURUSD = 10000 đv). both = cả hai. Chỉ đổi cách HIỂN THỊ")),
    ("time_offset_hours", Input(0.0, "Lệch giờ so với UTC (giờ)", min=-14.0, max=14.0, group="Hiển thị",
                                help="Dùng khi «Giờ hiển thị» = offset, vd 3 cho broker UTC+3")),
    # ---- AI ----
    ("ai_rounds", Input(2, "Số vòng thảo luận mỗi lần", min=1, max=5, group="AI")),
    ("ai_auto_interval", Input(15, "Chu kỳ AI tự thảo luận (phút)", min=1, max=1440, group="AI",
                               help="Mỗi lần thảo luận tốn API call của từng model")),
    ("ai_decision_mode", Input("decider", "Cách chốt quyết định", choices=["decider", "majority"], group="AI",
                               help="decider: 1 AI chốt; majority: mọi AI bỏ phiếu, cần đa số đồng thuận")),
    ("ai_signal_ttl", Input(30, "Tín hiệu AI hết hạn sau (phút)", min=1, max=1440, group="AI")),
    ("ai_max_tokens", Input(800, "Giới hạn token mỗi câu trả lời", min=100, max=4000, group="AI")),
    ("bot_ai_enabled", Input(False, "Cho bot gọi AI (api.ask_ai)", group="Bot gọi AI",
                             help="Tắt (mặc định): bot không gọi được AI. Bật: bot có thể gửi câu hỏi + dữ liệu bot chọn (vị thế, nến, lịch tin...) tới AI bạn đã cấu hình ở tab AI. "
                                  "Dữ liệu rời khỏi máy và có thể tốn tiền theo gói của nhà cung cấp - hạn mức bên dưới giúp kiểm soát. AI chỉ tham khảo, bot vẫn là bên quyết định")),
    ("bot_ai_agent", Input("", "AI mặc định cho bot", group="Bot gọi AI", help="Tên AI ở tab AI. Để trống = AI đầu tiên đang bật; bot có thể chỉ định AI khác")),
    ("bot_ai_max_per_hour", Input(20, "Hạn mức: số lần gọi AI mỗi giờ", min=0, max=1000, group="Bot gọi AI", help="0 = không giới hạn (không khuyến nghị)")),
    ("bot_ai_max_per_day", Input(200, "Hạn mức: số lần gọi AI mỗi ngày", min=0, max=10000, group="Bot gọi AI", help="0 = không giới hạn (không khuyến nghị)")),
    ("bot_ai_cache_s", Input(300, "Dùng lại câu trả lời trong (giây)", min=0, max=86400, group="Bot gọi AI",
                             help="Cùng một cuộc hỏi (cùng key) trong khoảng này trả lại câu trả lời cũ, không gọi AI lần nữa. Bot có thể đặt riêng")),
    ("bot_ai_timeout", Input(60, "Chờ AI tối đa (giây)", min=10, max=180, group="Bot gọi AI")),
    ("bot_ai_max_tokens", Input(600, "Giới hạn token câu trả lời cho bot", min=50, max=4000, group="Bot gọi AI")),
    ("bot_ai_max_context", Input(12000, "Cỡ ngữ cảnh tối đa (ký tự)", min=1000, max=100000, group="Bot gọi AI",
                                 help="Bot gửi quá cỡ này thì bị từ chối kèm lý do (tránh vô tình gửi cả nghìn nến)")),
    ("bot_ai_allow_web", Input(False, "Cho phép AI tra web", group="Bot gọi AI",
                               help="Chỉ có tác dụng với AI đã điền «Model tra web» hoặc «Tham số thêm khi tra web» ở tab AI. Tra web thường tốn nhiều hơn")),
    ("bot_ai_system", Input("", "Chỉ dẫn chung cho mọi cuộc hỏi của bot", subtype="text", group="Bot gọi AI",
                            help="Tuỳ chọn: văn bản thêm vào lời dặn hệ thống (vd phong cách, ngôn ngữ, giới hạn). Để trống = lời dặn mặc định")),
    ("bot_ai_record", Input(True, "Ghi câu trả lời để backtest phát lại", group="Bot gọi AI",
                            help="Lưu câu trả lời AI (đã che bí mật) vào ai_asks.jsonl để backtest «Phát lại tín hiệu AI đã ghi» dùng lại đúng các câu đó")),
    ("assistant_agent", Input("", "Trợ lý: dùng AI nào (tên)", group="AI",
                              help="Tên AI (đã thêm ở «Quản lý AI») dùng cho Trợ lý hướng dẫn/hỗ trợ sự cố. Để trống = AI bật đầu tiên. Không có AI/mất mạng thì Trợ lý trả lời từ sổ tay có sẵn")),
    ("assistant_share_state", Input(False, "Cho Trợ lý xem trạng thái (số dư, vị thế, nhật ký, sự cố, kết quả kiểm tra)", group="AI",
                                    help="Mặc định TẮT: chỉ gửi cho nhà cung cấp AI câu hỏi, cài đặt không nhạy cảm và tên khoá của sàn. Bật = gửi thêm số liệu/nhật ký gần nhất đã che khoá API và số tài khoản. "
                                         "Trợ lý chỉ ĐỀ XUẤT - bạn bấm Áp dụng mới có hiệu lực; không bao giờ đặt lệnh")),
    # ---- Binance live ----
    ("api_key", Input("", "Binance API key", group="Sàn (chỉ khi live)")),
    ("api_secret", Input("", "Binance API secret", secret=True, group="Sàn (chỉ khi live)")),
    ("testnet", Input(False, "Dùng Testnet / Demo (tiền giả)", group="Sàn (chỉ khi live)",
                      help="Binance Testnet hoặc OANDA practice. Nên thử live ở đây trước")),
    ("base_url", Input("", "Base URL tuỳ chỉnh", group="Sàn (chỉ khi live)",
                       help="Để trống = tự chọn theo sàn/testnet; vd https://data-api.binance.vision")),
    ("oanda_token", Input("", "OANDA API token", secret=True, group="Sàn (chỉ khi live)")),
    ("oanda_account", Input("", "OANDA Account ID", group="Sàn (chỉ khi live)", help="Vd 101-001-1234567-001")),
    ("live_confirm", Input(False, "Tôi hiểu rủi ro giao dịch tiền thật", group="Sàn (chỉ khi live)")),
    ("twelvedata_key", Input("", "Twelve Data API key (dự phòng cho forex/vàng, miễn phí)", secret=True, group="Nguồn giá công khai",
                             help="Tuỳ chọn. Chỉ dùng khi nguồn «public» và Yahoo lỗi. Đăng ký miễn phí ở twelvedata.com (8 yêu cầu/phút, 800/ngày).")),
    # ---- Exness (API chính thức, chỉ tài khoản "Exness trading account" ở VN/TH) ----
    ("exness_api_key", Input("", "Exness API key (exnsk_...)", secret=True, group="Exness API",
                             help="Tạo trong Personal Area > Settings > API. Tạo khoá RIÊNG cho app, quyền tối thiểu, bật giới hạn IP nếu có")),
    ("exness_private_key", Input("", "Exness khoá riêng Ed25519 (PEM / base64 / hex)", secret=True, group="Exness API",
                                 help="Khoá bạn tự sinh (openssl genpkey -algorithm ed25519); khoá CÔNG KHAI mới là cái dán lên Exness. Lưu mã hoá trong máy")),
    ("exness_account", Input("", "Exness số tài khoản", group="Exness API")),
    ("exness_host", Input("main", "Exness host", group="Exness API", help="main = api.exness.com · alt = api.exness-api.com · hoặc URL đầy đủ")),
    ("exness_ws_url", Input("", "Exness WebSocket (tuỳ chọn)", group="Exness API", help="Để trống = tự dò theo host")),
    # ---- Capital.com ----
    ("capital_api_key", Input("", "Capital.com API key", secret=True, group="Capital.com API",
                              help="Capital.com → Settings → API integrations (cần bật xác thực 2 lớp). Tài khoản demo: bật «Testnet/Demo» ở mục Thị trường")),
    ("capital_identifier", Input("", "Capital.com email đăng nhập", group="Capital.com API")),
    ("capital_password", Input("", "Capital.com mật khẩu API key (custom password)", secret=True, group="Capital.com API",
                               help="Mật khẩu bạn đặt khi tạo API key (KHÔNG phải mật khẩu đăng nhập web)")),
    ("capital_account", Input("", "Capital.com account id (tuỳ chọn)", group="Capital.com API", help="Để trống = tài khoản đang chọn mặc định")),
    # ---- Cầu nối MT4/MT5 ----
    ("metaapi_token", Input("", "MetaApi token", secret=True, group="Cầu nối MT4/MT5", help="metaapi.cloud - tài khoản MT phải được Deploy trên MetaApi")),
    ("metaapi_account", Input("", "MetaApi account id", group="Cầu nối MT4/MT5")),
    ("metaapi_region", Input("new-york", "MetaApi region", group="Cầu nối MT4/MT5", help="vd new-york, london, singapore")),
    ("mt5gw_url", Input("", "Địa chỉ cổng MT (PyEA MT Gateway)", group="Cầu nối MT4/MT5", help="vd http://192.168.1.10:8765 hoặc https://vps.example.com:8765 - xem gateway/README.md")),
    ("mt5gw_token", Input("", "Token cổng MT", secret=True, group="Cầu nối MT4/MT5")),
    ("bridge_profile", Input("", "Hồ sơ cầu nối REST khác (JSON)", group="Cầu nối MT4/MT5",
                             help="Cho dịch vụ REST bất kỳ (TickerAll, mt5api...): khai báo đường dẫn + ánh xạ trường. Xem gateway/README.md")),
    ("bridge_token", Input("", "Token cho hồ sơ cầu nối", secret=True, group="Cầu nối MT4/MT5")),
    # ---- cTrader Open API (nối thẳng từ điện thoại) ----
    ("ctrader_client_id", Input("", "cTrader Client ID", group="cTrader API", help="Đăng ký ứng dụng (miễn phí) ở openapi.ctrader.com bằng cTrader ID của bạn; "
                                "thêm redirect URI http://localhost:53682/callback")),
    ("ctrader_client_secret", Input("", "cTrader Client Secret", secret=True, group="cTrader API")),
    ("ctrader_access_token", Input("", "cTrader access token", secret=True, group="cTrader API", help="Bấm «Đăng nhập cTrader» (trên điện thoại) để tự lấy, hoặc dán token lấy từ Playground của openapi.ctrader.com")),
    ("ctrader_refresh_token", Input("", "cTrader refresh token", secret=True, group="cTrader API", help="Tự điền khi đăng nhập; app tự làm mới access token khi hết hạn (~30 ngày)")),
    ("ctrader_env", Input("demo", "cTrader môi trường", choices=["demo", "live"], group="cTrader API", help="LUÔN thử demo trước. demo/live phải khớp loại tài khoản của token")),
    ("ctrader_account", Input("", "cTrader ctidTraderAccountId (tuỳ chọn)", group="cTrader API", help="Để trống = tự chọn tài khoản đầu tiên đúng môi trường")),
    ("ctrader_ws_url", Input("", "cTrader WebSocket (tuỳ chọn)", group="cTrader API", help="Để trống = wss://demo|live.ctraderapi.com:5036")),
    # ---- MT5 Web Terminal (nối thẳng từ điện thoại) ----
    ("mt5ws_login", Input("", "MT5 số tài khoản (login)", group="MT5 trực tiếp", help="Số tài khoản MT5 (chỉ chữ số). LUÔN thử tài khoản DEMO trước")),
    ("mt5ws_password", Input("", "MT5 mật khẩu", secret=True, group="MT5 trực tiếp", help="Mật khẩu giao dịch (KHÔNG phải mật khẩu investor nếu muốn đặt lệnh)")),
    ("mt5ws_uri", Input("", "MT5 địa chỉ WebSocket (uri)", group="MT5 trực tiếp", help="MÁY CHỦ GIAO DỊCH được chọn bằng chính địa chỉ này (đăng nhập chỉ có số tài khoản + mật khẩu, không có ô «tên máy chủ»). "
                        "Tài khoản DEMO MetaQuotes: để trống (= wss://web.metatrader.app/terminal). Tài khoản broker: mở trang web terminal của broker, tìm TÊN MÁY CHỦ trong email "
                        "mở tài khoản (vd «Broker-Demo»), lấy địa chỉ web terminal của máy chủ đó rồi dán vào (https://... cũng được, app tự đổi sang wss:// và thêm /terminal). "
                        "Mỗi máy chủ giao dịch của broker thường có host riêng. Broker không có web terminal thì không dùng được cách này. CHƯA XÁC MINH với sàn thật")),
    ("mt5ws_url", Input("", "MT5 url đăng nhập (tuỳ chọn)", group="MT5 trực tiếp", help="Host trang web terminal gửi kèm khi đăng nhập (KHÔNG phải tên máy chủ giao dịch). Để trống = tự lấy host của địa chỉ WebSocket (web.metatrader.app thì để trống)")),
    ("mt5ws_otp", Input("", "MT5 mã OTP (nếu bật)", secret=True, group="MT5 trực tiếp")),
    ("mt5ws_server_offset_hours", Input("", "MT5 múi giờ máy chủ (giờ, tuỳ chọn)", group="MT5 trực tiếp", help="Giờ máy chủ MT5 - UTC (vd 2 hoặc 3). Để trống = tự dò từ giá đẩy khi thị trường mở; "
                        "nếu thị trường đang đóng cửa thì giờ vị thế/lịch sử có thể lệch cho tới khi dò được - đặt tay để chắc chắn")),
    ("mt5ws_volume_scale", Input("100000000", "MT5 thang khối lượng (tuỳ chọn)", group="MT5 trực tiếp", help="1 lot = bao nhiêu đơn vị thô trong giao thức (mặc định 100000000). Sai thang -> app báo lỗi rõ khi đọc đặc tả mã")),
    ("mt5ws_deviation", Input("20", "MT5 trượt giá tối đa (điểm)", group="MT5 trực tiếp")),
    ("mt5ea_token", Input("", "EA cầu nối: token", secret=True, group="MT5 qua EA cầu nối (tuỳ chọn)", help="Mật khẩu chung giữa app và EA (>= 8 ký tự, không khoảng trắng). Điền CÙNG giá trị vào tham số InpToken của EA PyEABridge. Chỉ cần khi chọn nguồn «mt5ea» (broker không có web terminal; MT5 chạy trong trình giả lập Windows). TUỲ CHỌN - không bao giờ tự bật.")),
    ("mt5ea_port", Input("18765", "EA cầu nối: cổng cục bộ", group="MT5 qua EA cầu nối (tuỳ chọn)", help="Cổng app mở trên 127.0.0.1 (chỉ trong máy) để EA nối vào. Đổi nếu cổng bị chiếm; EA phải dùng cùng cổng (InpPort).")),
    ("mt5ea_login", Input("", "EA cầu nối: số tài khoản MT5", group="MT5 qua EA cầu nối (tuỳ chọn)", help="Chỉ để sinh file cấu hình khởi động MT5 (startup.ini). Mật khẩu: đăng nhập tay một lần trong MT5 để terminal nhớ (chưa xác nhận được chỗ lưu mật khẩu trong file cấu hình).")),
    ("mt5ea_server", Input("", "EA cầu nối: máy chủ MT5", group="MT5 qua EA cầu nối (tuỳ chọn)", help="Tên/địa chỉ máy chủ giao dịch của broker như trong email mở tài khoản, vd Broker-Demo hoặc host:443. Chỉ để sinh startup.ini.")),
    ("mt5ea_symbol", Input("EURUSD", "EA cầu nối: mã của biểu đồ duy nhất", group="MT5 qua EA cầu nối (tuỳ chọn)", help="EA cần gắn vào ĐÚNG MỘT biểu đồ; chọn mã bất kỳ có sẵn ở broker (không ảnh hưởng mã bot giao dịch).")),
    ("mt5ea_deadman_s", Input("20", "EA cầu nối: công tắc người chết (giây)", group="MT5 qua EA cầu nối (tuỳ chọn)", help="EA mất liên lạc với app quá số giây này thì làm theo chính sách bên dưới (5-3600). Đừng đặt quá nhỏ: Android có thể làm app chậm vài giây.")),
    ("mt5ea_policy", Input("hold", "EA cầu nối: chính sách khi mất app", choices=["hold", "breakeven", "close_all"], group="MT5 qua EA cầu nối (tuỳ chọn)", help="hold = giữ nguyên (chỉ dựa SL/TP sẵn trên sàn); breakeven = dời SL về giá vào cho vị thế đang lời; close_all = đóng hết vị thế do app mở. Chỉ áp cho vị thế comment 'pyea', không đụng lệnh đặt tay/EA khác. EA cũng gửi thông báo tới MT5 mobile nếu đã cấu hình.")),
    ("mt5ea_supervised", Input("no", "EA cầu nối: có chạy script giám sát?", choices=["no", "yes"], group="MT5 qua EA cầu nối (tuỳ chọn)", help="Chọn yes nếu bạn chạy tools/mt5_phone/run_mt5_termux.sh (tự khởi động lại MT5). Chỉ để cảnh báo nói ĐÚNG việc tự hồi phục nào đang có.")),
    ("mt5ea_lean", Input("no", "EA cầu nối: chế độ NHẸ (ít CPU/RAM)", choices=["no", "yes"], group="MT5 qua EA cầu nối (tuỳ chọn)", help="yes = EA tắt vẽ biểu đồ, bỏ symbol thừa khỏi Market Watch và quét chậm hơn (200 ms) để MT5 trong giả lập đỡ tốn CPU/RAM. «MT5 nhúng» tự đặt yes; chưa đo mức giảm trên máy thật.")),
    ("mt5ea_deviation", Input("20", "EA cầu nối: trượt giá cho phép (điểm)", group="MT5 qua EA cầu nối (tuỳ chọn)", help="Độ trượt tối đa khi khớp lệnh thị trường.")),
    ("mt5ea_filling", Input("auto", "EA cầu nối: kiểu khớp lệnh", choices=["auto", "fok", "ioc", "return"], group="MT5 qua EA cầu nối (tuỳ chọn)", help="auto = EA chọn theo mã.")),
    ("mt5ws_precheck", Input("on", "MT5 kiểm tra luật mã trước khi gửi", choices=["on", "off"], group="MT5 trực tiếp", help="«on»: app đọc từ sàn chế độ giao dịch (cấm/chỉ đóng/chỉ mua/chỉ bán), stops level và freeze level rồi CHẶN lệnh vi phạm với lời giải thích rõ ràng thay vì chờ sàn từ chối. "
     "Chuyển «off» nếu thấy app chặn nhầm (nghĩa là bảng đặc tả của sàn đọc sai) - khi đó sàn tự quyết định như trước.")),
    ("mt5ws_magic", Input("off", "MT5 gửi thêm magic (nhãn số)", choices=["off", "on"], group="MT5 trực tiếp", help="Mỗi lệnh luôn mang nhãn duy nhất trong comment. «on» gửi thêm "
                          "nhãn số (magic) làm kênh thứ hai - CHƯA XÁC MINH mọi sàn chấp nhận; nếu sàn báo «yêu cầu không hợp lệ» thì để off")),
    ("mt5ws_filling", Input("auto", "MT5 kiểu khớp lệnh", choices=["auto", "fok", "ioc", "return"], group="MT5 trực tiếp", help="auto = theo cờ của mã (IOC > FOK > Return)")),
    # ---- DNSE (chứng khoán/phái sinh Việt Nam) ----
    ("dnse_username", Input("", "DNSE tên đăng nhập", group="DNSE", help="Email, số điện thoại hoặc số lưu ký. API V1 dùng chính tài khoản Entrade X của bạn (CHƯA thử tài khoản thật)")),
    ("dnse_password", Input("", "DNSE mật khẩu", secret=True, group="DNSE")),
    ("dnse_otp_kind", Input("smart", "Loại OTP", choices=["smart", "email"], group="DNSE", help="smart: mã Smart OTP trong app Entrade X · email: mã gửi về email")),
    ("dnse_otp", Input("", "DNSE OTP (dùng 1 lần)", secret=True, group="DNSE", help="Nhập mã ngay trước khi chạy bot để lấy trading token (hiệu lực 8 giờ). Với email OTP: bấm «Gửi Email OTP» trước")),
    ("dnse_trading_token", Input("", "DNSE trading token", secret=True, group="DNSE", help="Tự điền khi đổi OTP; hết hạn sau 8 giờ")),
    ("dnse_loan_package", Input("", "DNSE gói vay (loanPackageId)", group="DNSE", help="Bắt buộc khi đặt lệnh. Lấy ở Entrade X hoặc API danh sách gói vay (cổ phiếu thường để gói không ký quỹ)")),
    ("dnse_account", Input("", "DNSE tiểu khoản (tuỳ chọn)", group="DNSE", help="Để trống = tiểu khoản đầu tiên")),
    ("dnse_price_scale", Input(1.0, "DNSE hệ số giá", min=0.000001, group="DNSE", help="Nhân giá DNSE trả về thành giá app dùng (ví dụ 1000 nếu feed trả nghìn đồng mà lệnh cần đồng). Kiểm bằng lệnh nhỏ trước")),
    ("dnse_tick", Input("hose", "DNSE bước giá lệnh LO", group="DNSE", help="App gióng giá lệnh chờ về bước giá hợp lệ trước khi gửi (mua làm tròn xuống, bán làm tròn lên) vì sàn từ chối giá lẻ. "
     "hose = cổ phiếu HOSE (10 đ dưới 10.000, 50 đ tới 49.950, 100 đ từ 50.000) · hnx = HNX/UPCoM (100 đ) · etf = ETF/chứng quyền HOSE (10 đ) · off = không làm tròn · hoặc một số = bước cố định "
     "(cùng đơn vị giá gửi lên). VN30F luôn 0,1 điểm trừ khi off")),
    ("vn_market_guard", Input("off", "Chặn lệnh ngoài giờ giao dịch (DNSE)", choices=["off", "block"], group="DNSE",
                              help="block = không gửi lệnh MỚI khi sàn đóng cửa (cuối tuần/ngày lễ) và không gửi lệnh THỊ TRƯỜNG ngoài phiên khớp liên tục; lệnh giới hạn ngoài giờ trong ngày giao dịch vẫn gửi. "
                                   "Đóng vị thế không bao giờ bị chặn. off = để sàn tự từ chối (mặc định)")),
    ("vn_holidays_source", Input("auto", "Nguồn lịch nghỉ lễ tự cập nhật (thị trường VN)", group="DNSE",
                                 help="auto = tải docs/vn_holidays.json từ kho GitHub đã nhập ở «Kho GitHub chứa bản phát hành» (kho công khai) · off = chỉ dùng lịch có sẵn · hoặc dán URL https/đường dẫn file JSON. "
                                      "Tải nền mỗi 24 giờ, lỗi mạng thì dùng bản cũ. Định dạng: xem docs/DNSE.md")),
    ("vn_extra_holidays", Input("", "Ngày nghỉ lễ thêm (thị trường VN)", group="DNSE",
                                help="App chỉ có lịch nghỉ lễ 2026; năm khác chỉ biết các lễ cố định (1/1, 30/4, 1/5, 2/9). Dán ngày nghỉ theo thông báo của sở: YYYY-MM-DD hoặc DD/MM/YYYY, cách nhau dấu phẩy/dòng")),
    ("dnse_api_base", Input("", "DNSE API base (tuỳ chọn)", group="DNSE", help="Để trống = https://api.dnse.com.vn")),
    ("dnse_mqtt_url", Input("", "DNSE MQTT WebSocket (tuỳ chọn)", group="DNSE", help="Để trống = wss://datafeed-lts.dnse.com.vn/wss")),
    ("dnse_chart_url", Input("", "DNSE đường dẫn nến lịch sử (tuỳ chọn)", group="DNSE", help="Chưa có trong tài liệu chính thức; mặc định https://services.entrade.com.vn/chart-api/v2/ohlcs")),
    # ---- ccxt ----
    ("ccxt_id", Input("", "ccxt: tên sàn", group="Sàn khác (ccxt)", help="vd bybit, okx, kraken, kucoin, bitget, gate, mexc")),
    ("ccxt_api_key", Input("", "ccxt: API key", secret=True, group="Sàn khác (ccxt)")),
    ("ccxt_secret", Input("", "ccxt: API secret", secret=True, group="Sàn khác (ccxt)")),
    ("ccxt_password", Input("", "ccxt: passphrase (nếu sàn cần)", secret=True, group="Sàn khác (ccxt)")),
    ("ccxt_options", Input("", "ccxt: tuỳ chọn (JSON)", group="Sàn khác (ccxt)",
                           help='vd {"sandbox": true, "options": {"defaultType": "swap"}} - LUÔN thử sandbox trước')),
    # ---- Cô lập bot ----
    ("bot_isolation", Input("thread", "Bot chạy ở đâu", choices=["thread", "process"], group="Giao dịch & an toàn",
                          help="thread: cùng tiến trình app (mặc định) · process: TIẾN TRÌNH RIÊNG (bot treo/crash không kéo sập app, giết được). "
                               "Android: mỗi bot chạy ở một dịch vụ worker riêng (tối đa 4 bot cùng lúc, APK phải dựng từ bản có dịch vụ worker); hết chỗ hoặc APK cũ thì tự rơi về thread")),
    ("bot_net_policy", Input("enforce", "Quyền mạng của bot (khi chạy tiến trình riêng)", choices=["enforce", "off"], group="Giao dịch & an toàn",
                             help="enforce: bot ở tiến trình riêng CHỈ kết nối được tới host đã khai báo `# @permission: network(host)` VÀ bạn đã bấm Cho phép "
                                  "(mặc định không có mạng) · off: không chặn. Không có tác dụng ở chế độ luồng (kể cả khi Android rơi về luồng). Bật Chế độ nhà phát triển cũng tắt rào này")),
    ("bot_hang_kill_s", Input(0.0, "Giết bot nếu một callback chạy quá (giây, 0 = tắt)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                            help="Chỉ có tác dụng khi Bot chạy ở = process")),
    ("bot_mem_mb", Input(0, "Giới hạn bộ nhớ mỗi bot (MB, 0 = không giới hạn)", min=0, max=8192, group="Giao dịch & an toàn", help="Chỉ Linux/macOS (không áp dụng trên Android), khi Bot chạy ở = process")),
    # ---- Backtest: mô hình chi phí ----
    ("bt_spread_points", Input(0.0, "Backtest: spread cố định (đơn vị giá, 0 = dùng % ở trên)", min=0.0, group="Backtest chi phí",
                             help="Ví dụ EURUSD spread 0.00012; XAUUSD 0.25. Ưu tiên hơn spread %")),
    ("bt_commission_per_lot", Input(0.0, "Backtest: phí / lot / chiều", min=0.0, group="Backtest chi phí", help="Kiểu broker MT: vd 3.5 USD mỗi lot mỗi chiều")),
    ("bt_commission_min", Input(0.0, "Backtest: phí tối thiểu mỗi lần khớp", min=0.0, group="Backtest chi phí")),
    ("bt_slippage_pct", Input(0.0, "Backtest: trượt giá bất lợi (% giá, mỗi lần khớp)", min=0.0, max=5.0, group="Backtest chi phí")),
    ("bt_swap_long_pct_day", Input(0.0, "Backtest: swap vị thế MUA (% notional/ngày, dương = trả)", group="Backtest chi phí")),
    ("bt_swap_short_pct_day", Input(0.0, "Backtest: swap vị thế BÁN (% notional/ngày, dương = trả)", group="Backtest chi phí")),
    ("bt_swap_triple_day", Input("off", "Backtest: ngày tính swap x3", choices=["off", "mon", "tue", "wed", "thu", "fri"], group="Backtest chi phí",
                                 help="off = swap tính liên tục theo thời gian. Chọn ngày (forex thường wed; một số chỉ số/vàng fri) = kiểu broker MT: tính rời rạc mỗi ngày T2-T6 ở giờ rollover, ngày đó x3")),
    ("bt_swap_rollover_hour", Input(21.0, "Backtest: giờ rollover (UTC)", min=0.0, max=23.99, group="Backtest chi phí",
                                    help="Chỉ dùng khi chọn ngày swap x3. Giờ máy chủ broker 00:00 = 21:00 hoặc 22:00 UTC tuỳ mùa")),
    ("bt_funding_8h_pct", Input(0.0, "Backtest: funding perp (% notional/8 giờ; dương: mua trả, bán nhận)", group="Backtest chi phí")),
    # ---- Lệnh chờ & đồng bộ với sàn ----
    ("native_sltp", Input(False, "SL/TP NATIVE trên sàn (bảo vệ khi app chết) - THỬ NGHIỆM", group="Giao dịch & an toàn",
                          help="Bật: vỏ đặt lệnh bảo vệ trên sàn cho SL/TP của các vị thế (Binance Futures one-way: lệnh reduce-only, hedge mode: lệnh có positionSide; OANDA: reduce-only; Binance Spot: lệnh OCO vì Spot không có reduce-only; MT/Exness chưa có). Mức nào sàn xác nhận thì sàn canh, vỏ không canh nữa; "
                               "mức không đặt được vẫn do vỏ canh. Thử trên DEMO/testnet và vị thế nhỏ trước. Tắt: vỏ tự gỡ lệnh bảo vệ và canh lại như cũ")),
    ("pending_mode", Input("auto", "Lệnh chờ đặt ở đâu", choices=["auto", "native", "emulated"], group="Giao dịch & an toàn",
                           help="auto: đặt TRÊN SÀN nếu sàn hỗ trợ (sống cả khi app chết), không thì vỏ tự theo dõi · native: bắt buộc trên sàn · emulated: luôn do vỏ theo dõi")),
    ("native_sync_s", Input(2.0, "Hỏi sàn về lệnh chờ native mỗi (giây)", min=0.5, max=60.0, group="Giao dịch & an toàn")),
    ("sync_interval", Input(300.0, "Đồng bộ lịch sử + số dư với sàn mỗi (giây)", min=0.0, max=86400.0, group="Giao dịch & an toàn",
                            help="Chỉ live. 0 = tắt. Lưu các lần khớp THẬT của sàn để đối chiếu phí/funding/trượt giá")),
    ("balance_sync_policy", Input("alert", "Khi số dư sổ app lệch số dư sàn", choices=["alert", "adopt", "off"], group="Giao dịch & an toàn",
                                  help="alert = báo động · adopt = sổ app đổi theo sàn · off = không so")),
    ("balance_drift_pct", Input(1.0, "Ngưỡng lệch số dư (%)", min=0.0, max=100.0, group="Giao dịch & an toàn")),
    ("account_state_interval", Input(15.0, "Đọc tài sản/ký quỹ từ sàn mỗi (giây)", min=0.0, max=600.0, group="Giao dịch & an toàn",
                                     help="Chỉ live, sàn nào báo được (MT qua MetaApi/cổng/profile, Exness). Số Tài sản/Ký quỹ/Ký quỹ còn dư/Mức ký quỹ lấy từ SÀN như khung "
                                          "«Giao dịch» của MT5 thay vì số tự tính của app. 0 = tắt (dùng số tự tính)")),
    ("field_overrides", Input("", "Ánh xạ trường tuỳ chỉnh (JSON)", group="Giao dịch & an toàn",
                              help="Khi một sàn đặt tên trường khác bảng chung (Số dư/Tài sản/Lãi-lỗ vị thế/Lịch sử hiện «-» dù sàn có số): chỉ tên khoá thật ở đây, KHÔNG cần sửa mã. "
                                   "Vd {\"exness\": {\"position\": {\"profit\": \"unrealized_pnl\"}}}. «Kiểm tra hệ thống» liệt kê trường chưa khớp; Trợ lý có thể đề xuất giúp. Xem pyea/fieldmap.py")),
    ("history_profiles", Input("", "Hồ sơ lịch sử sàn (JSON)", group="Giao dịch & an toàn",
                               help="Mục «Lịch sử từ sàn» (Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Vị thế đã đóng) đọc qua MỘT bộ máy chung + hồ sơ dữ liệu cho từng sàn. "
                                    "OANDA, Binance Futures, ccxt đã có hồ sơ sẵn; sàn khác (hoặc sàn đổi tên trường/đường dẫn) thì DÁN hồ sơ vào đây, KHÔNG cần sửa mã: "
                                    "{\"tên_sàn\": {\"sources\": [...]}} - tên_sàn trùng ô «Sàn». Chỉ ĐỌC (không đặt được lệnh). Định dạng: docstring pyea/histengine.py. "
                                    "Hồ sơ sai bị chặn khi bấm Áp dụng; lỗi nhẹ hiện thành «Ghi chú» dưới mục Lịch sử.")),
    ("sync_lookback_days", Input(7, "Lần đầu đồng bộ: lấy lịch sử mấy ngày", min=1, max=90, group="Giao dịch & an toàn")),
])


EXCHANGE_WATCH = {
    "simulated": "BTCUSD,ETHUSD,EURUSD,XAUUSD,US500,AAPL",
    "public": "BTCUSDT,ETHUSDT,XAUUSD,EURUSD,US500",
    "binance_spot": "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT",
    "binance_futures": "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT",
    "oanda": "EUR_USD,GBP_USD,USD_JPY,XAU_USD,SPX500_USD",
    "capital": "EURUSD,GBPUSD,GOLD,BTCUSD,US500",
    "exness": "EURUSD,GBPUSD,USDJPY,XAUUSD,BTCUSD",
    "metaapi": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "mt5gw": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "bridge": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "ctrader": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "mt5ws": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "mt5ea": "EURUSD,GBPUSD,USDJPY,XAUUSD",
    "dnse": "VN30F1M,HPG,FPT,VCB",
    "ccxt": "BTC/USDT,ETH/USDT,SOL/USDT",
}


# ---- Mục «Kết nối sàn / API»: các nhóm ô API gom thành MỘT mục gập; chỉ hiện ô của sàn đang chọn ----
API_GROUPS = ["Sàn (chỉ khi live)", "Nguồn giá công khai", "Capital.com API", "Exness API", "Cầu nối MT4/MT5", "cTrader API", "MT5 trực tiếp", "Sàn khác (ccxt)"]
_API_COMMON = {"live_confirm"}
API_KEYS = {
    "simulated": set(),
    "public": {"twelvedata_key"},
    "binance_spot": {"api_key", "api_secret", "testnet", "base_url"},
    "binance_futures": {"api_key", "api_secret", "testnet", "base_url"},
    "oanda": {"oanda_token", "oanda_account", "testnet", "base_url"},
    "capital": {"capital_api_key", "capital_identifier", "capital_password", "capital_account", "testnet", "base_url"},
    "exness": {"exness_api_key", "exness_private_key", "exness_account", "exness_host", "exness_ws_url"},
    "metaapi": {"metaapi_token", "metaapi_account", "metaapi_region"},
    "mt5gw": {"mt5gw_url", "mt5gw_token"},
    "bridge": {"bridge_profile", "bridge_token"},
    "ctrader": {"ctrader_client_id", "ctrader_client_secret", "ctrader_access_token", "ctrader_refresh_token", "ctrader_env", "ctrader_account", "ctrader_ws_url"},
    "mt5ws": {"mt5ws_login", "mt5ws_password", "mt5ws_uri", "mt5ws_url", "mt5ws_otp", "mt5ws_server_offset_hours", "mt5ws_volume_scale", "mt5ws_deviation", "mt5ws_filling", "mt5ws_magic", "mt5ws_precheck"},
    "mt5ea": {"mt5ea_token", "mt5ea_port", "mt5ea_login", "mt5ea_server", "mt5ea_symbol", "mt5ea_deadman_s", "mt5ea_policy", "mt5ea_supervised", "mt5ea_lean", "mt5ea_deviation", "mt5ea_filling"},
    "dnse": {"dnse_username", "dnse_password", "dnse_otp_kind", "dnse_otp", "dnse_trading_token", "dnse_loan_package", "dnse_account", "dnse_price_scale", "dnse_tick", "dnse_api_base",
             "dnse_mqtt_url", "dnse_chart_url", "vn_market_guard", "vn_extra_holidays", "vn_holidays_source"},
    "ccxt": {"ccxt_id", "ccxt_api_key", "ccxt_secret", "ccxt_password", "ccxt_options"},
}


def api_keys_for(exchange):
    """Tập khoá ô API cần cho sàn `exchange` (None nếu sàn lạ -> hiện hết). Giả lập: không cần API."""
    keys = API_KEYS.get(str(exchange))
    if keys is None:
        return None
    return set(keys) | (_API_COMMON if (keys - {"twelvedata_key"}) else set())


NO_BROKER = ("simulated", "public")       # nguồn chỉ có GIÁ, không có tài khoản: không chạy live


def api_note(exchange):
    if str(exchange) == "public":
        return "Đang chọn «public»: giá thật không cần khoá API (crypto: Binance, vàng/forex/chỉ số: Yahoo). Chỉ paper/xem/backtest, không live. Có nguồn dự phòng tự động (Bybit, OKX, Coinbase, Kraken, Twelve Data nếu có khoá)."
    if str(exchange) == "simulated":
        return "Đang chọn «simulated» (giả lập): không cần khoá API. Đổi «Sàn» ở mục Thị trường để nhập khoá."
    if str(exchange) not in API_KEYS:
        return "Sàn không có trong danh sách chuẩn - đang hiện tất cả ô."
    return "Sàn đang chọn: %s. Chỉ hiện ô của sàn này; bấm «Hiện tất cả sàn» để xem hết." % exchange


def default_settings():
    return {k: v.default for k, v in GLOBAL_INPUTS.items()}


def clean_settings(raw):
    """Ép toàn bộ settings về đúng kiểu; giá trị hỏng -> về mặc định."""
    out = {}
    raw = raw or {}
    for k, inp in GLOBAL_INPUTS.items():
        try:
            out[k] = inp.coerce(raw.get(k, inp.default))
        except ValueError:
            out[k] = inp.default
    return out
