[app]
title = PyEA Runner
package.name = pyearunner
package.domain = org.pyea
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,ttf,txt,md
source.exclude_dirs = tests, docs, gateway, bin, .github, .buildozer, __pycache__
version = 1.9.8

# Chỉ dùng thư viện thuần Python + kivy (ít điểm lỗi khi build). certifi cần cho HTTPS trên Android.
requirements = python3,kivy==2.3.0,certifi,pyjnius,android

orientation = portrait
fullscreen = 0
android.archs = arm64-v8a, armeabi-v7a
android.api = 33
android.minapi = 24
android.ndk = 25b
android.accept_sdk_license = True
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,WAKE_LOCK,FOREGROUND_SERVICE,POST_NOTIFICATIONS,REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
# Không cho sao lưu tự động (API key lưu trong bộ nhớ riêng của app, không để lọt vào backup)
android.allow_backup = False
android.wakelock = True

# DỊCH VỤ NỀN: bot chạy trong tiến trình riêng, sống khi tắt màn hình / thoát app, có thông báo trên thanh trạng thái.
# foreground = hiện thông báo thường trực; sticky = Android tự khởi động lại dịch vụ nếu bị giết/crash.
services = Botservice:service_main.py:foreground:sticky,Botworker0:service_botworker.py,Botworker1:service_botworker.py,Botworker2:service_botworker.py,Botworker3:service_botworker.py

# Ghim bản python-for-android ổn định (tránh bản master đổi NDK/API bất ngờ)
p4a.branch = v2024.01.21

# Giữ nguyên file .py (không byte-compile/xoá) để bot và ví dụ luôn đọc được
android.no-byte-compile-python = True

log_level = 2

[buildozer]
log_level = 2
warn_on_root = 1
