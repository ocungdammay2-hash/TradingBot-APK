[app]
title = PyEA Runner
package.name = pyearunner
package.domain = org.pyea
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,ttf,txt,md
source.exclude_dirs = tests, tools, docs, gateway, bin, .github, .buildozer, __pycache__
version = 1.9.50

# Chỉ dùng thư viện thuần Python + kivy (ít điểm lỗi khi build). certifi cần cho HTTPS trên Android.
# charset_normalizer@URL: ép dùng wheel THUẦN PYTHON 3.4.9; không có dòng này p4a 2026 chọn wheel Android biên dịch của 3.5.x rồi cài lỗi (HANDOFF 5bk).
# pyeapipfix: recipe RỖNG (tools/p4a_recipes) vá lỗi pip bị «lai» khi p4a cài module cho kiến trúc thứ 2 (HANDOFF 5bl). Không vào APK.
requirements = python3,kivy,certifi,pyjnius,android,pyeapipfix,charset_normalizer@https://files.pythonhosted.org/packages/98/2b/f97f1c193fb855c345d678f5077d6926034db0722df74c8f057020e05a25/charset_normalizer-3.4.9-py3-none-any.whl

orientation = portrait
fullscreen = 0
android.archs = arm64-v8a, armeabi-v7a
# API 36: Google Play (từ 31/8/2026) bắt buộc app mới/bản cập nhật nhắm Android 16. Nếu build lỗi, xem README mục 5m (cấu hình lùi).
android.api = 36
android.minapi = 24
android.ndk = 28c
android.accept_sdk_license = True
android.permissions = INTERNET,ACCESS_NETWORK_STATE,ACCESS_WIFI_STATE,WAKE_LOCK,FOREGROUND_SERVICE,FOREGROUND_SERVICE_SPECIAL_USE,POST_NOTIFICATIONS,REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,RECEIVE_BOOT_COMPLETED
# Không cho sao lưu tự động (API key lưu trong bộ nhớ riêng của app, không để lọt vào backup)
android.allow_backup = False
android.wakelock = True

# DỊCH VỤ NỀN: bot chạy trong tiến trình riêng, sống khi tắt màn hình / thoát app, có thông báo trên thanh trạng thái.
# foregroundServiceType=specialUse: dataSync bị Android 15 giới hạn 6 giờ/24 giờ nên không hợp bot 24/7.
# foreground = hiện thông báo thường trực; sticky = Android tự khởi động lại dịch vụ nếu bị giết/crash.
services = Botservice:service_main.py:foreground:sticky:foregroundServiceType=specialUse,Emu:service_emu.py:foreground:sticky:foregroundServiceType=specialUse,Botworker0:service_botworker.py,Botworker1:service_botworker.py,Botworker2:service_botworker.py,Botworker3:service_botworker.py

# Tự chạy lại bot sau khi khởi động máy: BootReceiver.java (add_src) + hook chèn <receiver> vào manifest (buildozer không có tuỳ chọn này).
android.add_src = android_src
p4a.hook = tools/p4a_hook.py

# Ghim bản python-for-android (10/5/2026): có foregroundServiceType (PR #3262), Gradle 8.14.3, NDK 28c. Bản cũ v2024.01.21 KHÔNG có.
p4a.branch = v2026.05.09

# Thư mục recipe cục bộ (recipe vá pip: pyeapipfix)
p4a.local_recipes = tools/p4a_recipes

# Giữ nguyên file .py (không byte-compile/xoá) để bot và ví dụ luôn đọc được
android.no-byte-compile-python = True

log_level = 2

[buildozer]
log_level = 2
warn_on_root = 1
