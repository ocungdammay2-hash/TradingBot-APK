"""Kiểm tệp .zip MT5 NGAY khi người dùng chọn (trước khi chạy cài đặt hàng tiếng đồng hồ).

Vì sao: log thật trên Cat S52 (2026-11-26): app chép đúng tệp, nhưng «unzip» trong Ubuntu báo hàng loạt «bad zipfile offset (local header sig)» rồi
«invalid compressed data to inflate terminal64.exe» => tệp zip hỏng GIỮA tệp (danh mục cuối tệp vẫn đọc được). Gặp ở bước cuối sau ~1h23 cài nền = phí.
Hàm này đọc hết từng mục (Python tự kiểm CRC khi đọc tới cuối mục), nên báo ngay: «mục X hỏng, hãy tải lại tệp».
Chỉ dùng thư viện chuẩn, không đọc cả tệp vào RAM (đọc từng khối 1 MB rồi bỏ)."""
import zipfile
import zlib

NEED = "terminal64.exe"
_CHUNK = 1 << 20
MAX_FILES = 200000
MAX_TOTAL = 8 << 30          # trần tổng dung lượng giải nén (chống «bom zip»): thư mục MT5 thật chỉ vài trăm MB


class ZipCorrupt(ValueError):
    """Zip hỏng (đọc không được danh mục/mục, sai CRC). Khác ValueError thường (rỗng, không có terminal64.exe): chỗ chép thử đường chép khác khi gặp lỗi này."""


def _depth_ok(name, need):
    n = name.replace("\\", "/").strip("/")
    return n.lower().rsplit("/", 1)[-1] == need and n.count("/") <= 2     # script tìm terminal64.exe sâu tối đa 3 cấp


def verify_zip(path, need=NEED, max_report=4):
    """Trả số mục (tệp) trong zip nếu đọc được TOÀN BỘ và có `need` (terminal64.exe); ngược lại ném ValueError với câu tiếng Việt dễ hiểu."""
    redownload = "Thường do tải về dở hoặc bị ngắt giữa chừng: hãy TẢI LẠI tệp (cỡ phải đúng như trên trang tải) rồi chọn lại."
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, EOFError, OSError, ValueError) as e:
        raise ZipCorrupt("Không đọc được danh mục của tệp .zip (%s). %s" % (str(e)[:120], redownload))
    with zf:
        infos = [zi for zi in zf.infolist() if not zi.is_dir()]
        if not infos:
            raise ValueError("Tệp .zip không có tệp nào bên trong.")
        if not any(_depth_ok(zi.filename, need) for zi in infos):
            raise ValueError("Trong tệp .zip không thấy %s: đây không phải thư mục MetaTrader 5 đã cài (hãy nén cả thư mục «MetaTrader 5»)." % need)
        bad = []
        for zi in infos:
            try:
                with zf.open(zi) as f:
                    while f.read(_CHUNK):
                        pass                                    # đọc tới cuối mục: Python tự kiểm chữ ký đầu mục và CRC-32
            except (zipfile.BadZipFile, zlib.error, EOFError, OSError, NotImplementedError, RuntimeError, ValueError) as e:
                bad.append(zi.filename)
        if bad:
            shown = ", ".join(n.rsplit("/", 1)[-1] for n in bad[:max_report])
            more = "" if len(bad) <= max_report else " và %d mục khác" % (len(bad) - max_report)
            raise ZipCorrupt("Tệp .zip bị HỎNG: %d/%d mục đọc không được, ví dụ %s%s. %s" % (len(bad), len(infos), shown, more, redownload))
    return len(infos)


def _safe_rel(name):
    """Tên mục trong zip -> đường dẫn tương đối AN TOÀN, hoặc None nếu phải bỏ (tuyệt đối, «..», ổ đĩa C:, ký tự điều khiển, rỗng)."""
    n = name.replace("\\", "/")
    if not n or n.startswith("/") or any(ord(c) < 32 for c in n):
        return None
    parts = [x for x in n.split("/") if x not in ("", ".")]
    if not parts or any(x == ".." for x in parts) or ":" in parts[0]:
        return None
    return "/".join(parts)


def extract_zip(zip_path, dest, need=NEED, progress=None, hash_min=1 << 20, hash_max_files=12):
    """Giải nén zip MT5 bằng Python (KHÔNG qua unzip/proot): từng mục đọc tới cuối nên CRC-32 được kiểm; mục lạ (đường dẫn thoát ra ngoài, liên kết tượng trưng) bị bỏ.
    dest phải CHƯA có hoặc rỗng. Trả dict {files, bytes, skipped, manifest: [(sha256, đường_dẫn_tương_đối)]} - manifest gồm các tệp lớn nhất để script so lại bên trong Ubuntu.
    Lỗi: ZipCorrupt (zip hỏng), ValueError (không phải thư mục MT5/quá lớn/hết chỗ). Dọn dest khi lỗi."""
    import hashlib
    import os
    import shutil
    import stat
    try:
        zf = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, EOFError, OSError, ValueError) as e:
        raise ZipCorrupt("Không đọc được danh mục của tệp .zip (%s). Thường do tải về dở: hãy TẢI LẠI tệp rồi chọn lại." % str(e)[:120])
    big = []
    files = nbytes = skipped = 0
    started = False                                              # chỉ dọn dest khi CHÍNH hàm này đã bắt đầu ghi vào đó (không xoá dữ liệu có sẵn của người khác)
    try:
        with zf:
            infos = [zi for zi in zf.infolist() if not zi.is_dir()]
            if not infos:
                raise ValueError("Tệp .zip không có tệp nào bên trong.")
            if len(infos) > MAX_FILES:
                raise ValueError("Tệp .zip có quá nhiều mục (%d)." % len(infos))
            total = sum(zi.file_size for zi in infos)
            if total > MAX_TOTAL:
                raise ValueError("Giải nén sẽ tốn %d MB, quá lớn so với thư mục MT5 thật." % (total >> 20))
            if not any(_depth_ok(zi.filename, need) for zi in infos):
                raise ValueError("Trong tệp .zip không thấy %s: đây không phải thư mục MetaTrader 5 đã cài (hãy nén cả thư mục «MetaTrader 5»)." % need)
            parent = os.path.dirname(os.path.abspath(dest)) or "."
            os.makedirs(parent, exist_ok=True)
            free = shutil.disk_usage(parent).free
            if free < total + (200 << 20):
                raise ValueError("Không đủ dung lượng trống để giải nén MT5: cần khoảng %d MB, còn %d MB." % ((total + (200 << 20)) >> 20, free >> 20))
            if os.path.exists(dest):
                if os.listdir(dest):
                    raise ValueError("Thư mục đích đã có dữ liệu: %s" % dest)
            os.makedirs(dest, exist_ok=True)
            started = True
            root = os.path.realpath(dest)
            done = 0
            for zi in infos:
                rel = _safe_rel(zi.filename)
                mode = (zi.external_attr >> 16) & 0o170000
                if rel is None or mode == stat.S_IFLNK or (mode and mode not in (stat.S_IFREG,)):
                    skipped += 1
                    continue
                out = os.path.realpath(os.path.join(root, rel))
                if not (out + os.sep).startswith(root + os.sep) or out == root:
                    skipped += 1
                    continue
                os.makedirs(os.path.dirname(out), exist_ok=True)
                h = hashlib.sha256()
                try:
                    with zf.open(zi) as src, open(out, "wb") as dst:
                        while True:
                            b = src.read(_CHUNK)
                            if not b:
                                break
                            h.update(b)
                            dst.write(b)
                            done += len(b)
                            if progress:
                                progress(done, total)
                except (NotImplementedError, RuntimeError) as e:       # có mật khẩu / kiểu nén lạ: không phải «hỏng», tải lại không giúp gì
                    raise ValueError("Tệp .zip có mật khẩu hoặc dùng kiểu nén không hỗ trợ (%s). Hãy nén lại thường (không mật khẩu)." % str(e)[:60])
                except (zipfile.BadZipFile, zlib.error, EOFError) as e:
                    raise ZipCorrupt("Tệp .zip bị HỎNG ở mục «%s» (%s). Thường do tải về dở hoặc bị ngắt giữa chừng: hãy TẢI LẠI tệp (cỡ phải đúng như trên trang tải) rồi chọn lại." % (rel.rsplit("/", 1)[-1], str(e)[:60]))
                os.chmod(out, 0o644)
                files += 1
                nbytes += zi.file_size
                if zi.file_size >= hash_min:
                    big.append((zi.file_size, h.hexdigest(), rel))
    except Exception:
        if started:
            shutil.rmtree(dest, ignore_errors=True)
        raise
    for dp, dn, _ in os.walk(dest):
        for d in dn:
            try:
                os.chmod(os.path.join(dp, d), 0o755)
            except OSError:
                pass
    try:
        os.chmod(dest, 0o755)
    except OSError:
        pass
    big.sort(reverse=True)
    manifest = [(sha, rel) for _, sha, rel in big[:hash_max_files]]
    return {"files": files, "bytes": nbytes, "skipped": skipped, "manifest": manifest}
