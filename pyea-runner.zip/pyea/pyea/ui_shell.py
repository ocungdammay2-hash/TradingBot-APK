"""Giao diện cho các tính năng của VỎ (dialog + thanh an toàn). Là mixin của PyEAApp; import ui.py muộn (trong hàm) để tránh vòng import."""
import os
import time
from collections import OrderedDict

from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from .ui_widgets import StyledPopup
from kivy.utils import escape_markup

from . import android_native as native
from . import perms as botperms
from . import crashsend, legal, risk, updater
from . import license as lic
from .feeds import TIMEFRAMES
from .prefs import fmt_time, fmt_vol
from .shell import AlertBook, load_trades_csv, trade_stats
from .ui_widgets import (AMBER, BLUE, DOWN, GREEN, MIN_TOUCH, MUTED, PANEL, PANEL2, RED, TEXT, UP, LineChart, Panel, Table,
                         confirm, flabel, fm, fp, hexc, mk_input, mk_spinner, mkbtn, popup, section, vbox, vscroll, wlabel)

HEALTH_TEXT = {"connected": ("●  Kết nối giá OK", UP), "degraded": ("●  Một số mã MẤT/CŨ giá", AMBER),
               "disconnected": ("●  MẤT KẾT NỐI GIÁ - vỏ chặn lệnh bằng giá cũ", DOWN), "idle": ("●  Chưa theo dõi mã nào", MUTED)}


def fmt_ago(ts):
    if not ts:
        return "-"
    d = time.time() - ts
    return fmt_time("%d/%m %H:%M", ts) if d > 86400 else ("%.0f giây trước" % d if d < 90 else "%.0f phút trước" % (d / 60))


def _diag_text(path, extra, per_file=12000):
    """Gói chẩn đoán (.zip, đã xoá khoá) -> MỘT văn bản gửi được qua Chia sẻ: thông tin + phần đuôi của từng tệp (lỗi crash lên đầu)."""
    import zipfile
    parts = [str(extra)]
    try:
        with zipfile.ZipFile(path) as z:
            names = sorted(z.namelist(), key=lambda n: (0 if "crash" in n else 1, n))
            for n in names:
                try:
                    raw = z.read(n).decode("utf-8", "replace")
                except Exception:                                 # noqa: BLE001
                    continue
                parts.append("\n===== %s =====\n%s" % (n, raw[-per_file:]))
    except Exception as e:                                        # noqa: BLE001
        parts.append("\n(không đọc được gói: %s)" % e)
    return "\n".join(parts)


class SafetyBar(Panel):
    """Thanh trạng thái an toàn trên tab Giao dịch: sức khoẻ kết nối giá, mức ký quỹ, Kill switch / Mở lại giao dịch."""

    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, height=dp(186), padding=dp(6), spacing=dp(3), **kw)
        self.app = app
        self.l_health = flabel("", 12, MUTED, bold=True, size_hint_y=None, height=dp(20))
        self.l_margin = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_bacct = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_recon = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_sync = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_flag = flabel("", 12, AMBER, bold=True, size_hint_y=None, height=dp(20))
        row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        self.kill = mkbtn("KILL SWITCH", RED, h=40, size=12, on_release=app.kill_switch_dialog)
        self.resume = mkbtn("Mở lại giao dịch", PANEL2, h=40, size=12, on_release=app.resume_trading_action)
        self.resume.disabled = True
        row.add_widget(self.kill)
        row.add_widget(self.resume)
        for w in (self.l_health, self.l_margin, self.l_bacct, self.l_recon, self.l_sync, self.l_flag, row):
            self.add_widget(w)

    def update(self, snap):
        if not snap or not snap.get("ready"):
            self.l_health.text, self.l_health.color = "●  Chưa kết nối phiên", MUTED
            self.l_margin.text = self.l_bacct.text = self.l_flag.text = self.l_recon.text = self.l_sync.text = ""
            self.resume.disabled = True
            return
        h = snap.get("health") or {"state": "idle"}
        txt, col = HEALTH_TEXT.get(h.get("state"), HEALTH_TEXT["idle"])
        extra = ""
        if h.get("state") in ("degraded", "disconnected"):
            names = sorted(set(h.get("stale", [])) | set(h.get("failing", [])))
            extra = " (%s)" % ", ".join(names[:4])
        elif h.get("state") == "connected":
            extra = " · giá mới nhất %.0f giây trước" % h.get("max_age", 0)
        if h.get("broker_down"):                                  # gọi API sàn (đối soát/lệnh chờ/bảo vệ) lỗi liên tiếp - khác với mất giá
            extra += "  ·  MẤT KẾT NỐI/LỖI API SÀN: %s" % (str(h.get("broker_error") or "")[:50] or "không rõ lỗi")
            col = DOWN
        self.l_health.text, self.l_health.color = txt + extra, col
        lvl = snap.get("margin_level")
        self.l_margin.text = "Mức ký quỹ: %s · Khả dụng: %s · Giữ cho lệnh chờ: %s" % (
            ("%.0f%%" % lvl) if lvl else "-", fp(snap.get("free_margin", 0)), fp(snap.get("reserved", 0)))
        self.l_margin.color = DOWN if (lvl and lvl < 100) else MUTED
        ba = snap.get("broker_account")
        if ba:                                                    # số do SÀN báo (khung «Giao dịch» của MT5); dòng trên là số tự tính của app
            self.l_margin.text = "Sổ app (tự tính) - " + self.l_margin.text
            bl = ba.get("margin_level")
            fl = ba.get("profit")
            self.l_bacct.text = "SÀN%s: Số dư %s · Tài sản %s%s · Ký quỹ %s · Còn dư %s · Mức ký quỹ %s (%.0fs trước)" % (
                (" (%s)" % ba["currency"]) if ba.get("currency") else "", fp(ba.get("balance") or 0), fp(ba.get("equity") or 0),
                (" · Thả nổi %s" % fm(fl)) if fl is not None else "", fp(ba.get("margin") or 0), fp(ba.get("free_margin") or 0),
                ("%.0f%%" % bl) if bl else "-", ba.get("age", 0))
            self.l_bacct.color = DOWN if (bl and bl < 100) else UP
        else:
            self.l_bacct.text = ""
        rc = snap.get("reconcile") or {}
        if not rc.get("supported") and not rc.get("last"):
            self.l_recon.text = ""
        elif rc.get("ok") is False:
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: LỆCH - " + "; ".join(rc.get("issues", [])[:2]), DOWN
        elif rc.get("ok"):
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: khớp (%s)" % fmt_ago(rc.get("last")), UP
        else:
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: chưa lấy được dữ liệu", MUTED
        ex = snap.get("exchange_sync") or {}
        self._acct = snap.get("_account") not in (None, "main") and snap.get("_account_name") or ""
        if self._acct:
            self.l_health.text = "[TÀI KHOẢN: %s]  %s" % (self._acct, self.l_health.text)
        if not ex.get("supported") or not ex.get("last"):
            self.l_sync.text = ""
        elif ex.get("balance_remote") is None:
            self.l_sync.text, self.l_sync.color = "Đồng bộ sàn: %s" % (ex.get("error") or "chưa có số dư"), MUTED
        elif ex.get("ok") is False:
            self.l_sync.text, self.l_sync.color = "Số dư LỆCH: sàn %s · sổ app %s (%+.2f)" % (fp(ex["balance_remote"]), fp(ex["balance_local"]), ex["drift"]), DOWN
        else:
            self.l_sync.text, self.l_sync.color = "Số dư sàn %s khớp sổ app · %d lần khớp đã đồng bộ (%s)" % (
                fp(ex["balance_remote"]), ex.get("total_trades", 0), fmt_ago(ex.get("last"))), UP
        flags = []
        if snap.get("halted"):
            flags.append("KILL SWITCH ĐANG BẬT - giao dịch bị khoá")
        if snap.get("read_only"):
            flags.append("Chế độ CHỈ-XEM")
        cal = snap.get("calendar") or {}
        if cal.get("blocking"):
            bk = cal["blocking"]
            flags.append("CHẶN LỆNH MỚI quanh tin %s %s" % (bk.get("currency", ""), str(bk.get("title", ""))[:28]))
        elif cal.get("enabled") and cal.get("next"):
            e = cal["next"][0]
            mins = (float(e.get("ts", 0)) - time.time()) / 60.0
            if 0 <= mins <= 60:
                flags.append("Tin %s %s sau %.0f phút" % (e.get("currency", ""), str(e.get("title", ""))[:28], mins))
        self.l_flag.text = " · ".join(flags)
        self.l_flag.color = DOWN if snap.get("halted") else AMBER
        self.resume.disabled = not snap.get("halted")
        self.resume.background_color = AMBER if snap.get("halted") else PANEL2


class ShellUIMixin:
    # ------------------------------------------------------------------ an toàn
    def kill_switch_dialog(self, *_):
        if not self.is_connected():
            self.toast("Chưa có phiên nào đang chạy.")
            return
        confirm("KILL SWITCH", "Dừng MỌI bot, huỷ mọi lệnh chờ, ĐÓNG mọi vị thế theo giá thị trường và KHOÁ giao dịch cho tới khi bạn "
                "bấm 'Mở lại giao dịch'.\n\nDùng khi có sự cố hoặc thị trường bất thường.",
                lambda: (self.ctl.kill_switch(), self.toast("Đã gửi lệnh Kill switch - xem kết quả ở tab Nhật ký.")), "KÍCH HOẠT", RED)

    def resume_trading_action(self, *_):
        if not self.is_connected():
            return
        confirm("Mở lại giao dịch", "Mở khoá giao dịch sau Kill switch?\nCác bot đã bị dừng sẽ KHÔNG tự chạy lại - hãy bật lại ở tab Bot.",
                lambda: self.ctl.resume_trading(), "Mở lại", GREEN)

    def reset_paper_dialog(self, *_):
        if self.settings["mode"] == "live":
            self.toast("Chỉ đặt lại được tài khoản GIẢ LẬP (paper). Chế độ live dùng số dư thật của sàn.")
            return

        def do():
            if self.is_connected():
                self.ctl.reset_paper()
            else:
                try:
                    os.remove(self.store.state_path)
                except OSError:
                    pass
            self.toast("Đã đặt lại tài khoản giả lập về số dư ban đầu (%s)." % fp(self.settings["initial_balance"]))
        confirm("Đặt lại tài khoản giả lập", "Xoá mọi vị thế, lệnh chờ và đưa số dư về %s?\nLịch sử trades.csv được giữ." % fp(
            self.settings["initial_balance"]), do, "Đặt lại", RED)

    # ------------------------------------------------------------------ lệnh chờ
    def open_pending_dialog(self, oid):
        from . import ui as U
        o = next((x for x in (self.last_snap or {}).get("pending", []) if x.id == oid), None)
        if o is None:
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        price = U.mk_input("%.10g" % o.price)
        sl = U.mk_input(("%.10g" % o.sl) if o.sl else "", "để trống = bỏ SL")
        tp = U.mk_input(("%.10g" % o.tp) if o.tp else "", "để trống = bỏ TP")
        box.add_widget(wlabel("#%d %s %s %s %s%s" % (o.id, o.symbol, o.side.upper(), fmt_vol(o.volume, o.symbol), o.kind,
                       (" · kích hoạt %s" % fp(o.stop_price)) if o.kind == "stop_limit" else ""), 13, TEXT))
        box.add_widget(U.labeled("Giá đặt" if o.kind != "stop_limit" else "Giá limit", price))
        box.add_widget(U.labeled("Stop Loss", sl))
        box.add_widget(U.labeled("Take Profit", tp))
        msg = wlabel("", 11, MUTED)
        box.add_widget(msg)
        pop = StyledPopup(title="Sửa lệnh chờ", content=box, size_hint=(0.92, 0.62), auto_dismiss=False)

        def ok(*_):
            try:
                p, a, b = U.num(price.text), U.num(sl.text), U.num(tp.text)
            except ValueError as e:
                msg.text, msg.color = str(e), DOWN
                return
            res = self.ctl.modify_order(oid, p, a, b)
            if res is not True and res is not None and not getattr(res, "ok", True):
                msg.text, msg.color = res.message, DOWN
                return
            pop.dismiss()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def cancel_pending(self, oid):
        if self.is_connected():
            confirm("Huỷ lệnh chờ", "Huỷ lệnh chờ #%d?" % oid, lambda: self.ctl.cancel_order(oid), "Huỷ lệnh", RED)

    # ------------------------------------------------------------------ cảnh báo giá
    def _alerts_now(self):
        if self.is_connected():
            ses = getattr(self.ctl, "session", None)
            if ses is not None and ses.alerts is not None:
                return ses.alerts.list()
            return list((self.ctl.snapshot() or {}).get("alerts", []))
        return AlertBook(self.store.alerts_path).list()

    def open_alerts_dialog(self, *_):
        from . import ui as U
        connected = self.is_connected()
        syms = self._symbol_choices() or ["BTCUSD"]
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Cảnh báo giá", content=box, size_hint=(0.96, 0.92), auto_dismiss=False)
        box.add_widget(vscroll(body))
        KINDS = OrderedDict([("Giá ≥ (vượt lên trên)", "above"), ("Giá ≤ (xuống dưới)", "below"), ("Biến động ±% từ giá hiện tại", "pct"),
                             ("RSI cắt LÊN mức (nến đóng)", "rsi_above"), ("RSI cắt XUỐNG mức (nến đóng)", "rsi_below"),
                             ("EMA nhanh cắt LÊN EMA chậm", "ma_up"), ("EMA nhanh cắt XUỐNG EMA chậm", "ma_down")])
        sp_sym = U.mk_spinner(self.chart_sym if self.chart_sym in syms else syms[0], syms)
        sp_kind = U.mk_spinner(list(KINDS)[0], list(KINDS))
        value = U.mk_input("", "giá, % hoặc mức RSI (0-100)")
        sp_tf = U.mk_spinner("15m", list(TIMEFRAMES))
        p1 = U.mk_input("14", "chu kỳ RSI / EMA nhanh")
        p2 = U.mk_input("26", "EMA chậm (chỉ cho EMA cắt)")
        note = U.mk_input("", "ghi chú (tuỳ chọn)")
        sp_rep = U.mk_spinner("Báo 1 lần", ["Báo 1 lần", "Báo lặp lại"])
        msg = wlabel("Cảnh báo chạy cả khi không có bot - app báo bằng thông báo nổi + nhật ký. Cần đang KẾT NỐI để hoạt động." if not connected
                     else "Cảnh báo đang hoạt động trong phiên.", 11, MUTED)

        def rebuild():
            body.clear_widgets()
            items = self._alerts_now()
            body.add_widget(section("CẢNH BÁO (%d)" % len(items)))
            if not items:
                body.add_widget(wlabel("Chưa có cảnh báo nào.", 12, MUTED))
            for a in items:
                row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
                state = "đang chờ" if a.active else "đã báo %s" % fmt_ago(a.fired_at)
                row.add_widget(flabel("%s\n[size=10sp][color=%s]%s%s%s[/color][/size]" % (
                    escape_markup(a.describe()), hexc(UP if a.active else MUTED), state, " · lặp" if a.repeat else "",
                    (" · " + escape_markup(a.note)) if a.note else ""), 12, TEXT, size_hint_x=0.74))
                row.add_widget(mkbtn("Xoá", RED, h=MIN_TOUCH, size=12, size_hint_x=0.26, on_release=lambda *_, i=a.id: remove(i)))
                body.add_widget(row)
            body.add_widget(section("THÊM CẢNH BÁO"))
            for t, w in (("Tài sản", sp_sym), ("Điều kiện", sp_kind), ("Giá trị", value), ("Ghi chú", note), ("Kiểu", sp_rep),
                         ("Khung (chỉ báo)", sp_tf), ("Chu kỳ RSI/EMA nhanh", p1), ("EMA chậm", p2)):
                body.add_widget(U.labeled(t, w))
            body.add_widget(msg)

        def remove(i):
            if connected:
                self.ctl.alert_remove(i)
            else:
                b = AlertBook(self.store.alerts_path)
                b.remove(i)
            Clock.schedule_once(lambda dt: rebuild(), 0.05 if getattr(self.ctl, "session", None) is not None or not connected else 1.2)

        def add(*_):
            kind = KINDS[sp_kind.text]
            try:
                ind_ma = kind in ("ma_up", "ma_down")
                v = U.num(value.text) if not ind_ma else float(int(U.num(p1.text)))          # EMA cắt: không cần ô «Giá trị»
                if v <= 0:
                    raise ValueError("Giá trị phải > 0")
                rep = sp_rep.text == "Báo lặp lại"
                tf, a1, a2 = (sp_tf.text, int(U.num(p1.text)), int(U.num(p2.text))) if kind in ("rsi_above", "rsi_below", "ma_up", "ma_down") else ("", 14, 0)
                if connected:
                    self.ctl.alert_add(sp_sym.text, kind, v, note.text, rep, tf, a1, a2)
                else:
                    if kind == "pct":
                        raise ValueError("Cảnh báo % cần KẾT NỐI để biết giá hiện tại - hãy dùng 'Giá ≥ / ≤' khi chưa kết nối")
                    AlertBook(self.store.alerts_path).add(sp_sym.text, kind, v, 0.0, note.text, rep, tf, a1, a2)
            except ValueError as e:
                msg.text, msg.color = str(e), DOWN
                return
            value.text = note.text = ""
            msg.text, msg.color = "Đã thêm cảnh báo.", UP
            rebuild() if (getattr(self.ctl, "session", None) is not None or not connected) else Clock.schedule_once(lambda dt: rebuild(), 1.2)
        rebuild()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Thêm cảnh báo", GREEN, on_release=add))
        box.add_widget(row)
        pop.open()

    # ------------------------------------------------------------------ lịch sử & báo cáo
    def open_history_dialog(self, *_):
        trades = sorted(load_trades_csv(self.store.trades_csv), key=lambda t: t.close_time)
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(6))
        pop = StyledPopup(title="Lịch sử & báo cáo", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)
        box.add_widget(vscroll(body))
        start = float(self.settings.get("initial_balance") or 0.0)
        self._broker_history_section(body, local_trades=trades)
        if not trades:
            body.add_widget(wlabel("Chưa có lệnh nào đã đóng (file trades.csv còn trống).", 12, MUTED))
            st = trade_stats([], start)
        else:
            st = trade_stats(trades, start)
            pf = st["profit_factor"]
            lines = ["Tổng lệnh: %d · Thắng: %d (%.1f%%) · Thua: %d" % (st["trades"], st["wins"], st["win_rate"], st["losses"]),
                     "Lãi/lỗ ròng: %s · Profit factor: %s" % (fm(st["profit"]), "-" if pf is None else ("∞" if pf == float("inf") else "%.2f" % pf)),
                     "Kỳ vọng/lệnh: %s · Lãi TB: %s · Lỗ TB: %s" % (fm(st["expectancy"]), fm(st["avg_win"]), fm(st["avg_loss"])),
                     "Lãi lớn nhất: %s · Lỗ lớn nhất: %s" % (fm(st["best"]), fm(st["worst"])),
                     "Sụt vốn tối đa: %s (%.2f%% vốn ban đầu)" % (fp(st["max_drawdown"]), st["max_drawdown_pct"])]
            body.add_widget(section("TỔNG QUAN (mọi lệnh đã đóng)"))
            for ln in lines:
                body.add_widget(wlabel(ln, 12, UP if ("ròng" in ln and st["profit"] >= 0) else TEXT))
            cum, curve = 0.0, []
            for t in trades:
                cum += t.profit
                curve.append(cum)
            body.add_widget(section("ĐƯỜNG LÃI/LỖ LUỸ KẾ"))
            ch = LineChart(size_hint_y=None, height=dp(130))
            ch.update(curve, 0.0)
            body.add_widget(ch)
            by = {}
            for t in trades:
                by.setdefault(t.owner or "thủ công", []).append(t)
            body.add_widget(section("THEO TỪNG BOT"))
            tb = Table(["Bot", "Lệnh", "Thắng", "P/L", "PF", "DD"], [1.7, 0.7, 0.9, 1.1, 0.8, 1.0])
            rows = []
            for owner, ts in sorted(by.items(), key=lambda kv: -sum(x.profit for x in kv[1])):
                s2 = trade_stats(ts, start)
                pf2 = s2["profit_factor"]
                rows.append([owner[:16], str(s2["trades"]), "%.0f%%" % s2["win_rate"], (fm(s2["profit"]), UP if s2["profit"] >= 0 else DOWN),
                             "-" if pf2 is None else ("∞" if pf2 == float("inf") else "%.2f" % pf2), fp(s2["max_drawdown"])])
            tb.set_rows(rows)
            body.add_widget(tb)
        summary = OrderedDict([("Tổng lệnh", st["trades"]), ("Thắng %", round(st["win_rate"], 2)), ("Lãi/lỗ ròng", round(st["profit"], 6)),
                               ("Profit factor", st["profit_factor"]), ("Sụt vốn tối đa", round(st["max_drawdown"], 6))])

        def save(*_):
            try:
                path = self.store.save_statement(trades, summary)
            except OSError as e:
                self.toast("Không lưu được sao kê: %s" % e)
                return
            popup("Đã lưu sao kê", "File CSV:\n%s\n\n(Mở bằng trình quản lý file / Excel; trên Android nằm trong thư mục riêng của app)" % path, size=(0.92, 0.5))

        def copy(*_):
            from .shell import statement_csv
            Clipboard.copy(statement_csv(trades, summary))
            self.toast("Đã sao chép sao kê CSV vào clipboard - dán vào ghi chú/Excel/chat.")
        def save_html(*_):
            from . import report
            try:
                path = self.store.save_report_html(report.build_html(trades, start, "Báo cáo giao dịch PyEA (sổ app)"))
            except OSError as e:
                self.toast("Không lưu được báo cáo: %s" % e)
                return
            popup("Đã lưu báo cáo HTML", "File:\n%s\n\nMở bằng trình duyệt (có biểu đồ tăng trưởng, sụt vốn, phân tích theo mã/phiên/giờ); "
                  "in ra PDF từ trình duyệt được." % path, size=(0.92, 0.5))
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        r.add_widget(mkbtn("Sao chép CSV", PANEL2, size=11, on_release=copy))
        r.add_widget(mkbtn("Lưu CSV", GREEN, size=12, on_release=save))
        r.add_widget(mkbtn("Báo cáo HTML", BLUE, size=11, on_release=save_html))
        box.add_widget(r)
        pop.open()

    def _broker_history_section(self, body, local_trades=None):
        """Lịch sử KIỂU MT5: thanh KỲ (Hôm nay/7/30/90/180 ngày/Tuỳ chọn) · thanh LỌC (mã, chiều, kết quả, sắp xếp) · 3 tab Vị thế/Lệnh/Giao dịch · tổng.
        Số liệu từ SÀN (đồng bộ như MT5: Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư) khi sàn có lịch sử; không có (paper/sàn chưa hỗ trợ) thì
        bảng dùng SỔ APP (trades.csv). Gọi sàn ở luồng nền; bộ lọc/sắp xếp chạy tại chỗ trên dữ liệu đã tải (pyea/histview.py)."""
        import threading
        from . import brokerhist, histview
        body.add_widget(section("LỊCH SỬ TỪ SÀN / SỔ APP (như tab Lịch sử của MT5)"))
        status = wlabel("Chọn kỳ để tải từ sàn.", 12, MUTED)
        box = vbox(spacing=dp(4))
        gen = [0]
        st = {"res": None, "tab": "positions", "since": None, "until": None, "symbol": histview.ALL_SYMBOLS, "side": "", "result": "", "sort": "time_desc", "tz": time.localtime().tm_gmtoff or 0}
        local = list(local_trades or [])

        def datasets():
            """(dòng theo tab, nguồn) - sàn nếu đã tải được, không thì sổ app (lọc theo kỳ đang chọn)."""
            r = st["res"]
            if r is not None:
                return {"positions": histview.positions_from_broker(r), "orders": histview.orders_from_broker(r), "deals": histview.deals_from_broker(r)}, "sàn"
            return {"positions": histview.positions_from_trades(local), "orders": histview.orders_from_trades(local), "deals": histview.deals_from_trades(local)}, "sổ app"

        tabs_row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
        tab_btns = {}
        flt_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(4))
        sym_sp = mk_spinner(histview.ALL_SYMBOLS, [histview.ALL_SYMBOLS])
        side_sp = mk_spinner(histview.SIDES[0][1], [x[1] for x in histview.SIDES])
        res_sp = mk_spinner(histview.RESULTS[0][1], [x[1] for x in histview.RESULTS])
        sort_sp = mk_spinner(histview.SORTS[0][1], [x[1] for x in histview.SORTS])
        table_box = vbox(spacing=dp(4))

        def draw_table(*_):
            table_box.clear_widgets()
            rows_by_tab, src = datasets()
            st["symbol"] = sym_sp.text
            st["side"] = next((k for k, v in histview.SIDES if v == side_sp.text), "")
            st["result"] = next((k for k, v in histview.RESULTS if v == res_sp.text), "")
            st["sort"] = next((k for k, v in histview.SORTS if v == sort_sp.text), "time_desc")
            syms = [histview.ALL_SYMBOLS] + histview.symbols_of(rows_by_tab["positions"] + rows_by_tab["deals"])
            if list(sym_sp.values) != syms:
                sym_sp.values = syms
                if sym_sp.text not in syms:
                    sym_sp.text = syms[0]
                    st["symbol"] = syms[0]
            for k, b in tab_btns.items():
                b.background_color = BLUE if k == st["tab"] else PANEL2
            since, until = st["since"], st["until"]
            if st["res"] is None and since is None and until is None:
                pass                                                  # sổ app, chưa chọn kỳ: hiện hết
            rows, tot = histview.view(rows_by_tab, st["tab"], since=since, until=until, symbol=st["symbol"], side=st["side"], result=st["result"], sort=st["sort"])
            table_box.add_widget(wlabel("Nguồn: %s · %d dòng · Lãi/lỗ: %s · Thắng: %.0f%%%s" % (
                src, tot["count"], brokerhist.money(tot["profit"]), tot["win_pct"],
                (" · Phí qua đêm: %s · Hoa hồng: %s" % (brokerhist.money(tot["swap"]), brokerhist.money(tot["commission"]))) if (tot["swap"] or tot["commission"]) else ""),
                12, UP if tot["profit"] > 0 else DOWN if tot["profit"] < 0 else TEXT))
            if st["tab"] == "positions":
                tb = Table(["Mã", "Loại", "KL", "Vào → Ra", "P/L", "Đóng lúc"], [1.2, 0.6, 0.8, 1.8, 1.0, 1.2])
                tb.set_rows([[r["symbol"], (r["side"].upper(), UP if r["side"] == "buy" else DOWN), fmt_vol(r["volume"], r["symbol"]),
                              "%s → %s" % (fp(r["price"]) if r["price"] else "?", fp(r["price2"])), (fm(r["profit"]), UP if r["profit"] >= 0 else DOWN),
                              fmt_time("%d/%m %H:%M", r["time"])] for r in rows[:histview.MAX_ROWS]])
            elif st["tab"] == "orders":
                tb = Table(["Mã", "Loại", "KL", "Giá", "Trạng thái", "Lúc"], [1.2, 0.6, 0.8, 1.2, 1.1, 1.2])
                tb.set_rows([[r["symbol"], (r["side"].upper(), UP if r["side"] == "buy" else DOWN), fmt_vol(r["volume"], r["symbol"]), fp(r["price"]),
                              r["state"] or "-", fmt_time("%d/%m %H:%M", r["time"])] for r in rows[:histview.MAX_ROWS]])
            else:
                tb = Table(["Mã", "Loại", "Vào/Ra", "KL", "Giá", "P/L", "Lúc"], [1.1, 0.6, 0.7, 0.8, 1.1, 0.9, 1.1])
                tb.set_rows([[r["symbol"], (r["side"].upper(), UP if r["side"] == "buy" else DOWN), {"IN": "Vào", "OUT": "Ra", "INOUT": "Đảo", "OUT_BY": "Ra(đối)"}.get(r["entry"], "-"),
                              fmt_vol(r["volume"], r["symbol"]), fp(r["price"]), (fm(r["profit"]), UP if r["profit"] >= 0 else DOWN),
                              fmt_time("%d/%m %H:%M", r["time"])] for r in rows[:histview.MAX_ROWS]])
            table_box.add_widget(tb)
            if len(rows) > histview.MAX_ROWS:
                table_box.add_widget(wlabel("Chỉ hiện %d dòng đầu - thu hẹp kỳ/mã để xem phần còn lại." % histview.MAX_ROWS, 11, MUTED))
            if st["tab"] == "orders":
                table_box.add_widget(wlabel("Lệnh = các lệnh ĐÃ KHỚP. Lệnh chờ bị huỷ/hết hạn không có trong dữ liệu sàn trả về nên không hiện.", 11, MUTED))

        def set_tab(k):
            st["tab"] = k
            draw_table()
        for k, label in histview.TABS:
            b = mkbtn(label, BLUE if k == st["tab"] else PANEL2, h=MIN_TOUCH, size=12, on_release=lambda *_, kk=k: set_tab(kk))
            tab_btns[k] = b
            tabs_row.add_widget(b)
        for sp_ in (sym_sp, side_sp, res_sp, sort_sp):
            sp_.bind(text=draw_table)
            flt_row.add_widget(sp_)

        def render(res, err, token):
            if token != gen[0]:
                return                                              # đã bấm kỳ khác: bỏ kết quả cũ
            box.clear_widgets()
            st["res"] = None if err else res
            if err:
                status.text, status.color = err, AMBER
                draw_table()
                return
            sm = res["summary"]
            status.text, status.color = "%d vị thế đã đóng · %d deal" % (sm["positions"], sm["trades"]), MUTED
            for label, key in (("Lợi nhuận", "profit"), ("Tiền nạp", "deposit"), ("Phí qua đêm", "swap"), ("Phí trung gian", "commission"), ("Số dư", "balance")):
                v = sm[key]
                box.add_widget(wlabel("%s: %s" % (label, brokerhist.money(v)), 13, (UP if v > 0 else DOWN if v < 0 else TEXT) if key in ("profit", "balance") else TEXT))
            notes = res.get("notes") or []
            if notes:
                box.add_widget(section("GHI CHÚ VỀ SỐ LIỆU"))
                for n in notes:
                    box.add_widget(wlabel(n, 11, AMBER if brokerhist.is_warning(n) else MUTED))
            draw_table()

        def load_range(since, until):
            gen[0] += 1
            token = gen[0]
            st["since"], st["until"] = since, until
            status.text, status.color = "Đang tải lịch sử từ sàn...", MUTED
            box.clear_widgets()
            now = time.time()

            def work():
                try:
                    res, err = brokerhist.fetch_for_settings(self.settings, since if since is not None else now - 90 * 86400.0, until if until is not None else now + 3600), ""
                except NotImplementedError as e:
                    res, err = None, str(e)
                except Exception as e:                              # noqa: BLE001 - mất mạng/sàn lỗi: báo trên giao diện, không sập
                    res, err = None, "Không tải được lịch sử từ sàn: %s" % e
                Clock.schedule_once(lambda dt: render(res, err, token), 0)
            threading.Thread(target=work, daemon=True).start()

        def load(days):
            now = time.time()
            since = brokerhist.day_start(now, time.localtime().tm_gmtoff) if days <= 1 else now - days * 86400.0
            load_range(since, now + 3600)

        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
        for label, days in brokerhist.PERIODS:
            row.add_widget(mkbtn(label, PANEL2, on_release=lambda *_, d=days: load(d), size=11))
        body.add_widget(row)
        custom = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
        d_from = mk_input("", "Từ ngày 2026-10-01")
        d_to = mk_input("", "Đến ngày 2026-10-31")
        custom.add_widget(d_from)
        custom.add_widget(d_to)

        def go_custom(*_):
            try:
                since, until = histview.custom_range(d_from.text, d_to.text, st["tz"])
            except ValueError as e:
                status.text, status.color = str(e), AMBER
                return
            load_range(since, until)
        custom.add_widget(mkbtn("Tuỳ chọn", GREEN, on_release=go_custom, size=11, size_hint_x=0.6))
        body.add_widget(custom)
        body.add_widget(status)
        body.add_widget(box)
        body.add_widget(tabs_row)
        body.add_widget(flt_row)
        body.add_widget(table_box)
        draw_table()                                                 # trước khi tải: bảng sổ app (nếu có)
        self._bh_load = load                                         # test/UI có thể nạp kỳ mặc định

    # ------------------------------------------------------------------ sao lưu / khôi phục / chẩn đoán
    def backup_dialog(self, *_):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box.add_widget(wlabel("Sao lưu: bot (.py), tham số, bộ tham số có tên, cài đặt, chỉ báo/bố cục biểu đồ, cảnh báo giá.\n"
                              "KHÔNG gồm sổ lệnh/nhật ký. Mặc định XOÁ API key/secret/token khỏi file sao lưu.", 12, TEXT))
        pop = StyledPopup(title="Sao lưu", content=box, size_hint=(0.94, 0.55), auto_dismiss=True)

        def do(secrets):
            pop.dismiss()
            try:
                path = self.store.export_backup(include_secrets=secrets)
            except OSError as e:
                self.toast("Không sao lưu được: %s" % e)
                return
            popup("Đã sao lưu", "File:\n%s\n\n%s" % (path, "Có CHỨA API key - giữ cẩn thận." if secrets else "Đã xoá API key khỏi file."), size=(0.94, 0.55))
        box.add_widget(mkbtn("Sao lưu (không kèm API key)", GREEN, on_release=lambda *_: do(False)))
        box.add_widget(mkbtn("Sao lưu KÈM API key", RED, on_release=lambda *_: confirm(
            "Kèm API key?", "File sao lưu sẽ chứa khoá API dạng chữ thường. Ai có file là dùng được khoá. Tiếp tục?", lambda: do(True), "Sao lưu", RED)))
        box.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        pop.open()

    def restore_dialog(self, *_):
        if self.is_connected():
            self.toast("Hãy NGẮT kết nối phiên trước khi khôi phục.")
            return
        d = self.store.exports_dir
        try:
            files = sorted((n for n in os.listdir(d) if n.startswith("pyea-backup") and n.endswith(".zip")), reverse=True)
        except OSError:
            files = []
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Khôi phục từ sao lưu", content=box, size_hint=(0.95, 0.8), auto_dismiss=True)
        box.add_widget(wlabel("Chọn một file sao lưu trong thư mục:\n%s\n(chép file .zip sao lưu vào đó nếu bạn chuyển từ máy khác)" % d, 11, MUTED))
        if not files:
            body.add_widget(wlabel("Chưa có file sao lưu nào (pyea-backup-*.zip).", 12, MUTED))
        for n in files[:15]:
            body.add_widget(mkbtn(n, PANEL2, h=MIN_TOUCH, size=12, on_release=lambda *_, name=n: ask(name)))
        box.add_widget(vscroll(body))
        box.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))

        def ask(name):
            confirm("Khôi phục", "Ghi đè bot/tham số/cài đặt hiện có bằng nội dung của\n%s ?\n(API key hiện có được giữ nếu bản sao lưu không chứa khoá)" % name,
                    lambda: run(name), "Khôi phục", RED)

        def run(name):
            try:
                n, warns = self.store.import_backup(os.path.join(d, name))
            except Exception as e:
                popup("Khôi phục thất bại", str(e), size=(0.92, 0.5), color=DOWN)
                return
            pop.dismiss()
            self.settings = self.store.load_settings()
            from . import prefs as _prefs
            _prefs.apply(self.settings)
            self.attach_cfgs = self.store.load_instances()
            self.refresh_bots()
            self.settings_tab.build(self.settings)
            popup("Đã khôi phục", "%d file.%s" % (n, ("\nCảnh báo:\n" + "\n".join(warns[:6])) if warns else ""), size=(0.92, 0.5))
        pop.open()

    def changelog_dialog(self, *_):
        from . import __version__
        from .changelog import api_changes_text, changelog_text
        popup("Có gì mới - bản %s" % __version__, changelog_text(3) + "\n\n— Lịch sử API bot —\n" + api_changes_text(), size=(0.94, 0.85))

    # ---------------------------------------------------------- pháp lý · giới thiệu · cập nhật · gửi báo lỗi (pyea/legal.py, updater.py, crashsend.py)
    def legal_menu(self, *_):
        """Hướng dẫn nhanh + điều khoản + riêng tư + cảnh báo rủi ro + cài đặt mẫu."""
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        pop = StyledPopup(title="Hướng dẫn & pháp lý", content=box, size_hint=(0.92, 0.78), auto_dismiss=False)

        def to(fn):
            return lambda *_: (pop.dismiss(), fn())
        for text, fn in (("Hướng dẫn nhanh (6 bước)", self.onboarding), ("Điều khoản sử dụng", lambda: popup(legal.EULA_TITLE, legal.EULA_TEXT, size=(0.94, 0.9), color=TEXT)),
                         ("Chính sách riêng tư", lambda: popup(legal.PRIVACY_TITLE, legal.PRIVACY_TEXT, size=(0.94, 0.9), color=TEXT)),
                         ("Cảnh báo rủi ro", lambda: popup(risk.RISK_TITLE, risk.RISK_TEXT, size=(0.94, 0.9), color=TEXT)),
                         ("Dùng cài đặt mẫu an toàn (paper + giả lập)", self.apply_sample_settings),
                         ("Bản quyền · dùng thử 90 ngày", self.license_dialog),
                         ("Kiểm tra cập nhật", self.update_dialog)):
            box.add_widget(mkbtn(text, PANEL2, h=46, size=13, on_release=to(fn)))
        box.add_widget(mkbtn("Đóng", BLUE, h=46, size=13, on_release=lambda *_: pop.dismiss()))
        pop.open()

    # ---------------------------------------------------------- bản quyền: dùng thử 90 ngày CHỈ khi cài từ Google Play
    def license_status(self):
        """Trạng thái bản quyền (sideload / trial / expired / licensed). Không bao giờ ném lỗi: lỗi -> coi như sideload (không khoá người dùng)."""
        try:
            installer = native.installer_package() if native.IS_ANDROID else None
            return lic.evaluate(lic.Store(self.data_dir), installer)
        except Exception:                                      # noqa: BLE001 - lỗi đọc đĩa không được khoá app
            return {"state": "sideload", "iid": "", "days_left": None, "reason": ""}

    def license_blocks_live(self):
        return lic.blocks_live(self.license_status())

    def license_dialog(self, *_):
        st = self.license_status()
        lines = [lic.describe(st), "", "ID thiết bị (gửi cho người cấp khoá): %s" % st.get("iid", "")]
        if st.get("state") == "trial":
            lines.append("Hết dùng thử: %s" % time.strftime("%d/%m/%Y", time.localtime(st["trial_end"])))
        if st.get("rolled_back"):
            lines.append("Phát hiện đồng hồ máy bị chỉnh lùi: thời gian dùng thử vẫn tính theo mốc lớn nhất đã ghi nhận.")
        if st.get("reason"):
            lines.append("Khoá đã lưu không dùng được: %s" % st["reason"])
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        pop = StyledPopup(title="Bản quyền", content=box, size_hint=(0.94, 0.7), auto_dismiss=False)
        box.add_widget(wlabel(escape_markup("\n".join(lines)), 13, TEXT))
        inp = mk_input("", "Dán khoá kích hoạt (PYEA1-...)")
        box.add_widget(inp)

        def do(*_):
            ok, msg = lic.activate(lic.Store(self.data_dir), inp.text, st.get("installer") or None)
            self.toast(msg)
            if ok:
                pop.dismiss()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Sao chép ID", PANEL2, h=46, size=13, on_release=lambda *_: Clipboard.copy(st.get("iid", ""))))
        row.add_widget(mkbtn("Kích hoạt", GREEN, h=46, size=13, on_release=do))
        row.add_widget(mkbtn("Đóng", BLUE, h=46, size=13, on_release=lambda *_: pop.dismiss()))
        box.add_widget(row)
        pop.open()

    def license_gate_live(self):
        """True = được mở phiên LIVE. Hết dùng thử + chưa có khoá -> hiện hộp thoại và trả False."""
        if not self.license_blocks_live():
            return True
        self.license_dialog()
        return False

    def license_nag(self):
        """Nhắc nhẹ tối đa 1 lần/ngày: còn ≤14 ngày dùng thử hoặc đã hết hạn."""
        st = self.license_status()
        if st.get("state") not in ("trial", "expired"):
            return
        if st["state"] == "trial" and (st.get("days_left") or 0) > 14:
            return
        p = self.store.load_prefs()
        if time.time() - float(p.get("license_nag", 0) or 0) < 86400:
            return
        p["license_nag"] = time.time()
        self.store.save_prefs(p)
        self.toast(lic.describe(st))

    def first_run(self):
        """Lần mở đầu (hoặc khi LEGAL_VERSION tăng): điều khoản + riêng tư, bấm đồng ý rồi tới hướng dẫn nhanh."""
        if not legal.needed(self.store.load_prefs()):
            return False

        def ack(_p):
            p = self.store.load_prefs()
            legal.acknowledge(p)
            self.store.save_prefs(p)
            self.onboarding()
        popup(legal.EULA_TITLE, legal.EULA_TEXT + "\n\n" + legal.PRIVACY_TEXT, [("Tôi đã đọc và đồng ý", GREEN, ack)], size=(0.95, 0.92), color=TEXT)
        return True

    def onboarding(self, step=0):
        steps = legal.ONBOARDING
        step = max(0, min(step, len(steps) - 1))
        title, text = steps[step]
        last = step == len(steps) - 1
        btns = []
        if step > 0:
            btns.append(("Trước", PANEL2, lambda _p: (self.onboarding(step - 1), None)[1]))
        if last:
            btns.append(("Dùng cài đặt mẫu", AMBER, lambda _p: (self.apply_sample_settings(), None)[1]))
            btns.append(("Xong", GREEN, None))
        else:
            btns.append(("Bỏ qua", PANEL2, None))
            btns.append(("Tiếp", GREEN, lambda _p: (self.onboarding(step + 1), None)[1]))
        popup(title, text, btns, size=(0.92, 0.7), color=TEXT)

    def apply_sample_settings(self):
        """Đặt các khoá an toàn (paper + simulated + giới hạn lỗ) rồi lưu; giữ nguyên khoá API đã nhập."""
        def go():
            self.settings = legal.sample_patch(self.settings)
            tab = getattr(self, "settings_tab", None)
            if tab is not None and getattr(tab, "gform", None):
                tab.gform.set_values(self.settings)
            self._commit_settings(False)
            self.toast("Đã đặt cài đặt mẫu an toàn: paper + giả lập. Mở tab Thị trường → KẾT NỐI.")
        confirm("Cài đặt mẫu an toàn", "Chuyển sang chế độ PAPER, nguồn giá «simulated», số dư 10.000, đòn bẩy 1, dừng bot nếu lỗ quá 10%. Khoá API của bạn được giữ nguyên.",
                go, "Áp dụng", GREEN)

    def update_dialog(self, *_):
        import threading
        repo = str(self.settings.get("update_repo") or "").strip()
        if not repo:
            popup("Kiểm tra cập nhật", "Chưa nhập kho GitHub. Vào Cài đặt → «Hỗ trợ & cập nhật» → «Kho GitHub chứa bản phát hành» (dạng chủ/tên) rồi thử lại.", size=(0.92, 0.45))
            return
        self.toast("Đang kiểm tra bản cập nhật...")

        def work():
            r = updater.check(repo, self._app_version())
            self._show_update(r)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _show_update(self, r, quiet=False):
        st = r.get("status")
        if st == "newer":
            msg = "Có bản mới %s (đang dùng %s).\n\n%s\n\nTrang tải: %s%s" % (r["latest"], self._app_version(), (r.get("notes") or "").strip()[:800], r.get("url", ""),
                                                                           ("\nFile APK: " + r["apk"]) if r.get("apk") else "")
            popup("Có bản cập nhật", msg, [("Sao chép liên kết", PANEL2, lambda _p: (Clipboard.copy(r.get("apk") or r.get("url") or ""), None)[1]), ("Đóng", BLUE, None)], size=(0.94, 0.7))
        elif not quiet:
            popup("Kiểm tra cập nhật", {"current": "Bạn đang dùng bản mới nhất (%s)." % r.get("latest", "")}.get(st, r.get("message", "")), size=(0.92, 0.4))

    def startup_tasks(self, *_):
        """Chạy 1 lần sau khi giao diện dựng xong: hộp thoại lần đầu, kiểm tra cập nhật (nếu bật, tối đa 1 lần/ngày)."""
        import threading
        self.first_run()
        self.license_nag()
        st = self.settings

        def work():
            try:
                if st.get("check_updates") and str(st.get("update_repo") or "").strip():
                    p = self.store.load_prefs()
                    if time.time() - float(p.get("update_checked", 0) or 0) > 86400:
                        r = updater.check(st["update_repo"], self._app_version())
                        q = self.store.load_prefs()
                        q["update_checked"] = time.time()
                        self.store.save_prefs(q)
                        self._show_update(r, quiet=True)
            except Exception:                                  # noqa: BLE001 - tác vụ nền tuỳ chọn không được làm app lỗi
                pass
        threading.Thread(target=work, daemon=True).start()

    def send_crash_async(self, text):
        """Gửi nội dung crash.log của lần chạy trước tới địa chỉ người dùng đã cấu hình (mặc định TẮT)."""
        import threading
        st, ver = dict(self.settings), self._app_version()
        if not st.get("crash_report_auto"):
            return

        def work():
            try:
                crashsend.flush(st, text, ver)
            except Exception:                                  # noqa: BLE001
                pass
        threading.Thread(target=work, daemon=True).start()

    def diag_bundle_dialog(self, *_):
        snap = self.last_snap or {}
        extra = "status=%s mode=%s exchange=%s halted=%s health=%s\nversion=%s" % (
            snap.get("status"), self.settings.get("mode"), self.settings.get("exchange"), snap.get("halted"),
            (snap.get("health") or {}).get("state"), self._app_version())
        try:
            path = self.store.export_diagnostics(extra)
        except OSError as e:
            self.toast("Không xuất được gói chẩn đoán: %s" % e)
            return
        def _share(_p):
            self.share_report(_diag_text(path, extra), "PyEA - gói chẩn đoán")
            return False
        popup("Gói chẩn đoán", "Đã tạo (không chứa API key):\n%s\n\nBấm «Gửi» để gửi qua Zalo/Telegram/Gmail... cho người/AI hỗ trợ." % path,
              [("Gửi", GREEN, _share), ("Đóng", BLUE, None)], size=(0.94, 0.55))

    def load_dialog(self, *_):
        from .loadprobe import profiler_text
        text = self.meter.report() + "\n\n" + profiler_text((self.last_snap or {}).get("instances"))

        def _share(_p):
            self.share_report("PyEA %s - tải thiết bị\n%s" % (self._app_version(), text), "PyEA - tải thiết bị")
            return False
        popup("Tải thiết bị", text, [("Gửi", GREEN, _share), ("Đóng", BLUE, None)], size=(0.94, 0.62))

    def _app_version(self):
        from . import __version__
        return __version__

    # ---------------------------------------------------------- quyền của bot (# @permission: network(host))
    def _declared_perms(self, path):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                return botperms.parse_declared(f.read())
        except OSError:
            return {"network": [], "file": [], "ai_signal": False}

    def bot_perms_text(self, path):
        """Nội dung mô tả quyền bot xin + trạng thái cấp phép (dùng cho hộp thoại và panel thông tin bot)."""
        decl = self._declared_perms(path)
        lines = botperms.describe(decl)
        if not lines:
            return "Bot không xin quyền đặc biệt (chỉ self.api + thư mục riêng + thư viện chuẩn)."
        pend = botperms.PermStore(self.data_dir).pending(path, decl)
        status = "Đã cho phép." if not pend else "CHƯA cho phép: " + ", ".join(pend.get("network", []))
        enforce = (self.settings.get("bot_isolation") == "process" and self.settings.get("bot_net_policy") == "enforce")
        note = ("" if enforce else "\n(Quyền mạng chỉ được CƯỠNG CHẾ khi Cài đặt → «Bot chạy ở» = process; hiện chỉ để khai báo.)")
        return "Bot xin quyền:\n • " + "\n • ".join(lines) + "\n" + status + note

    def ask_bot_perms(self, path, then=None):
        """Hỏi «Cho phép / Từ chối» cho các quyền bot khai báo mà chưa được cấp. Từ chối: bot vẫn chạy (chỉ bị PermissionError khi gọi mạng)."""
        decl = self._declared_perms(path)
        pend = botperms.PermStore(self.data_dir).pending(path, decl)
        if not pend:
            if then:
                then()
            return False
        name = os.path.basename(path)

        def allow(_p):
            botperms.PermStore(self.data_dir).grant(path, "network", pend.get("network", []))
            if then:
                then()

        def deny(_p):
            if then:
                then()
        popup("Bot %s xin quyền" % name, self.bot_perms_text(path) + "\n\nTừ chối: bot vẫn chạy nhưng sẽ bị PermissionError khi gọi mạng "
              "(ở chế độ tiến trình riêng).", [("Từ chối", PANEL2, deny), ("Cho phép", GREEN, allow)], size=(0.94, 0.6))
        return True

    def bot_perms_dialog(self, *_):
        path = getattr(self, "selected", None)
        if not path:
            self.toast("Hãy chọn một file bot trong thư viện.")
            return
        decl = self._declared_perms(path)
        g = botperms.PermStore(self.data_dir).granted(path)

        def revoke(_p):
            botperms.PermStore(self.data_dir).revoke(path)
            self.toast("Đã thu hồi quyền của %s" % os.path.basename(path))
            self.attach_tab.show_info(self.get_info(path))

        def grant(_p):
            botperms.PermStore(self.data_dir).grant_declared(path, decl)
            self.attach_tab.show_info(self.get_info(path))
        btns = [("Đóng", PANEL2, None)]
        if g:
            btns.append(("Thu hồi", RED, revoke))
        if botperms.PermStore(self.data_dir).pending(path, decl):
            btns.append(("Cho phép", GREEN, grant))
        popup("Quyền bot %s" % os.path.basename(path), self.bot_perms_text(path), btns, size=(0.94, 0.6))

    # ---------------------------------------------------------- cảnh báo rủi ro lần đầu + chặn chụp màn hình
    def risk_needed(self):
        return risk.needed(self.store.load_prefs())

    def risk_dialog(self, on_ok=None):
        """Hiện lời cảnh báo rủi ro; bấm «Tôi hiểu» mới lưu xác nhận (đóng bằng cách khác = chưa xác nhận)."""
        def ack(_p):
            p = self.store.load_prefs()
            risk.acknowledge(p)
            self.store.save_prefs(p)
            if on_ok:
                on_ok()
        return popup(risk.RISK_TITLE, risk.RISK_TEXT, [("Tôi hiểu và đồng ý", GREEN, ack)], size=(0.94, 0.9), color=TEXT)

    def risk_gate(self, proceed):
        """Chạy `proceed()` ngay nếu đã xác nhận cảnh báo rủi ro, ngược lại hiện cảnh báo trước. -> True nếu chạy ngay."""
        if not self.risk_needed():
            proceed()
            return True
        self.risk_dialog(proceed)
        return False

    def want_secure(self):
        """Có nên bật FLAG_SECURE lúc này không (theo tuỳ chọn «Chặn chụp/quay màn hình» + tab đang xem)."""
        mode = self.settings.get("secure_screen", "sensitive")
        if mode == "always":
            return True
        if mode != "sensitive":
            return False
        try:
            return self.root_panel.current_tab is self.tabs["settings"]
        except (AttributeError, KeyError):
            return False

    def apply_secure(self, *_):
        return native.set_secure(self.want_secure())
