"""
COPY TRADING không cần máy chủ của tác giả: «bot chủ» công bố các vị thế của CHÍNH NÓ thành một tài liệu JSON có chữ ký HMAC-SHA256 (khoá bí mật dùng chung),
«bot theo» đọc tài liệu đó và sao chép (nhân khối lượng với tỉ lệ). Nơi đặt tài liệu: file chung (Syncthing/ổ mạng) hoặc URL https hỗ trợ GET/PUT (WebDAV, S3 ký sẵn...).

Phạm vi trung thực: mỗi bot gắn với MỘT mã nên mỗi cặp chủ/theo chỉ sao chép một mã (gắn nhiều cặp cho nhiều mã); chủ chỉ công bố vị thế của bot chủ
(không phải mọi lệnh tay trên tài khoản); độ trễ = chu kỳ hỏi (mặc định vài giây), KHÔNG phải copy tức thời; khớp giá ở bên theo có thể khác bên chủ (trượt giá).
Không có chợ tín hiệu/thanh toán/xếp hạng (cần máy chủ). Chữ ký HMAC chứng minh tài liệu do người giữ khoá chung tạo và không bị sửa; không che nội dung
(đừng đặt tài liệu ở nơi công khai nếu bạn không muốn lộ vị thế). Bot theo chỉ làm việc khi tài liệu còn mới (max_age).
"""
import hashlib
import hmac
import json
import os
import re
import time
import urllib.request

PREFIX = "cp:"
FIELDS = ("v", "master", "seq", "t", "positions")


class FeedError(Exception):
    pass


def _canon(doc):
    return json.dumps({k: doc.get(k) for k in FIELDS}, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sign(doc, secret):
    if not secret:
        raise FeedError("Cần khoá bí mật dùng chung.")
    d = {k: doc.get(k) for k in FIELDS}
    d["sig"] = hmac.new(secret.encode("utf-8"), _canon(d), hashlib.sha256).hexdigest()
    return d


def verify(raw, secret, max_age=30.0, now=None, last_seq=-1):
    """raw: bytes/str JSON. Trả dict đã xác minh hoặc ném FeedError (sai chữ ký / cũ / phát lại / sai cấu trúc)."""
    now = time.time() if now is None else now
    try:
        d = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
    except ValueError:
        raise FeedError("Tài liệu tín hiệu không phải JSON.")
    if not isinstance(d, dict) or d.get("v") != 1 or not isinstance(d.get("positions"), list) or not isinstance(d.get("sig"), str):
        raise FeedError("Tài liệu tín hiệu sai cấu trúc.")
    good = hmac.new(secret.encode("utf-8"), _canon(d), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(good, d["sig"]):
        raise FeedError("Chữ ký tín hiệu KHÔNG hợp lệ (sai khoá chung hoặc bị sửa).")
    if not isinstance(d.get("t"), (int, float)) or not isinstance(d.get("seq"), int):
        raise FeedError("Thiếu thời gian/số thứ tự.")
    if now - d["t"] > max_age:
        raise FeedError("Tín hiệu đã CŨ %.0f giây (tối đa %.0f) - không hành động." % (now - d["t"], max_age))
    if d["t"] - now > 120:
        raise FeedError("Thời gian tín hiệu ở tương lai quá xa - kiểm tra đồng hồ hai máy.")
    if d["seq"] < last_seq:
        raise FeedError("Số thứ tự lùi (có thể là bản cũ bị phát lại) - bỏ qua.")
    for p in d["positions"]:
        if not isinstance(p, dict) or not isinstance(p.get("id"), (int, str)) or p.get("side") not in ("buy", "sell") or not isinstance(p.get("symbol"), str):
            raise FeedError("Một vị thế trong tín hiệu sai định dạng.")
        try:
            float(p["volume"])
        except (KeyError, TypeError, ValueError):
            raise FeedError("Một vị thế trong tín hiệu thiếu khối lượng.")
    return d


# ------------------------------------------------------------------ nơi đặt tài liệu
def _auth(req, user, pw):
    if user:
        import base64
        req.add_header("Authorization", "Basic " + base64.b64encode(("%s:%s" % (user, pw or "")).encode("utf-8")).decode("ascii"))


def read(location, user="", pw="", timeout=5):
    if re.match(r"^https?://", location.lower()):
        if location.lower().startswith("http://") and not re.match(r"^http://(127\.0\.0\.1|localhost)[:/]", location.lower()):
            raise FeedError("Chỉ dùng https:// (http:// chỉ cho localhost).")
        req = urllib.request.Request(location, headers={"User-Agent": "PyEA-copy"})
        _auth(req, user, pw)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read(1 << 20)
    with open(location, "rb") as f:
        return f.read(1 << 20)


def write(location, data, user="", pw="", timeout=5):
    if re.match(r"^https?://", location.lower()):
        if location.lower().startswith("http://") and not re.match(r"^http://(127\.0\.0\.1|localhost)[:/]", location.lower()):
            raise FeedError("Chỉ dùng https:// (http:// chỉ cho localhost).")
        req = urllib.request.Request(location, data=data, method="PUT", headers={"Content-Type": "application/json", "User-Agent": "PyEA-copy"})
        _auth(req, user, pw)
        urllib.request.urlopen(req, timeout=timeout).read()
        return
    tmp = location + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, location)


# ------------------------------------------------------------------ logic
def plan(master_positions, mirrored, symbol, ratio, baseline=None, copy_sl_tp=True, master_symbol=None):
    """Quyết định thuần tuý. master_positions: danh sách từ tài liệu; mirrored: {id_chủ(str): (id_bên_theo, side)} của các vị thế bên theo đang giữ.
    Trả {"close": [id_bên_theo], "open": [{"mid","side","volume","sl","tp"}]}. Đóng trước, mở sau (sàn gộp vị thế không cho mua và bán cùng mã)."""
    msym = master_symbol or symbol
    want = {str(p["id"]): p for p in master_positions if p["symbol"] == msym}
    close, opens = [], []
    for mid, (fid, side) in mirrored.items():
        w = want.get(mid)
        if w is None or w["side"] != side:
            close.append(fid)
    base = set(baseline or ())
    for mid, p in sorted(want.items()):
        if mid in mirrored and want[mid]["side"] == mirrored[mid][1]:
            continue
        if mid in base:
            continue
        vol = float(p["volume"]) * ratio
        if vol <= 0:
            continue
        opens.append({"mid": mid, "side": p["side"], "volume": vol, "sl": float(p.get("sl") or 0) if copy_sl_tp else 0.0,
                      "tp": float(p.get("tp") or 0) if copy_sl_tp else 0.0})
    return {"close": close, "open": opens}


def mirrored_from(positions):
    """Vị thế bên theo có comment 'cp:<id chủ>' -> {id_chủ: (id, side)} (bền qua khởi động lại vì nằm ngay trên vị thế)."""
    out = {}
    for p in positions:
        c = getattr(p, "comment", "") or ""
        if c.startswith(PREFIX):
            out[c[len(PREFIX):]] = (p.id, p.side)
    return out


class MasterCore:
    def __init__(self, api, location, secret, name="master", user="", pw="", heartbeat=10.0, writer=write, clock=time.time):
        self.api, self.location, self.secret, self.name = api, location, secret, name
        self.user, self.pw, self.heartbeat, self.writer, self.clock = user, pw, heartbeat, writer, clock
        self.seq, self.last_sig, self.last_t = 0, None, 0.0

    def snapshot(self):
        return [{"id": p.id, "symbol": p.symbol, "side": p.side, "volume": p.volume, "sl": p.sl, "tp": p.tp, "open_price": p.open_price}
                for p in self.api.positions()]

    def publish(self, force=False):
        """Công bố nếu vị thế đổi hoặc đã quá `heartbeat` giây. Trả True nếu đã ghi."""
        now = self.clock()
        pos = self.snapshot()
        sig = json.dumps(pos, sort_keys=True)
        if not force and sig == self.last_sig and now - self.last_t < self.heartbeat:
            return False
        self.seq += 1
        doc = sign({"v": 1, "master": self.name, "seq": self.seq, "t": now, "positions": pos}, self.secret)
        self.writer(self.location, json.dumps(doc, ensure_ascii=False).encode("utf-8"), self.user, self.pw)
        self.last_sig, self.last_t = sig, now
        return True


class FollowerCore:
    def __init__(self, api, secret, ratio=1.0, max_age=30.0, copy_existing=False, copy_sl_tp=True, master_symbol="", log=None, clock=time.time):
        self.api, self.secret, self.ratio, self.max_age = api, secret, float(ratio), float(max_age)
        self.copy_existing, self.copy_sl_tp, self.master_symbol = copy_existing, copy_sl_tp, master_symbol or None
        self.log = log or (lambda *a: None)
        self.clock = clock
        self.baseline = None
        self.last_seq = -1

    def step(self, raw):
        """Xử lý một lần đọc tài liệu. Trả {"closed": n, "opened": n, "error": str|None}."""
        out = {"closed": 0, "opened": 0, "error": None}
        try:
            doc = verify(raw, self.secret, self.max_age, self.clock(), self.last_seq)
        except FeedError as e:
            out["error"] = str(e)
            return out
        self.last_seq = max(self.last_seq, doc["seq"])
        sym = self.api.symbol
        msym = self.master_symbol or sym
        if self.baseline is None:
            self.baseline = set() if self.copy_existing else {str(p["id"]) for p in doc["positions"] if p["symbol"] == msym}
            if self.baseline:
                self.log("Bỏ qua %d vị thế chủ đã mở trước khi theo (đặt copy_existing=true để sao chép cả chúng)." % len(self.baseline))
        mine = mirrored_from(self.api.positions())
        pl = plan(doc["positions"], mine, sym, self.ratio, self.baseline, self.copy_sl_tp, self.master_symbol)
        for fid in pl["close"]:
            r = self.api.close(fid, reason="Bot chủ đã đóng/đảo lệnh")
            if r:
                out["closed"] += 1
        for o in pl["open"]:
            fn = self.api.buy if o["side"] == "buy" else self.api.sell
            r = fn(o["volume"], sl=o["sl"], tp=o["tp"], comment=PREFIX + o["mid"], reason="Sao chép lệnh #%s của bot chủ" % o["mid"],
                   details={"master_id": o["mid"], "ratio": self.ratio})
            if r:
                out["opened"] += 1
            else:
                self.log("Không mở được bản sao của #%s: %s" % (o["mid"], getattr(r, "message", "")))
        return out
