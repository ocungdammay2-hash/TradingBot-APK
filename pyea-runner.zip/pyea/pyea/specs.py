"""Thông số mã (như hộp Symbol Specification của MT5) + sổ lệnh (DOM). Thuần Python."""


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def parse_symbol_info(row):
    """Chuẩn hoá 1 dòng exchangeInfo của Binance (spot hoặc futures). Dò theo TÊN TRƯỜNG chứ không theo tên bộ lọc, vì tài liệu futures ghi
    tên bộ lọc không nhất quán. Không dùng pricePrecision/quantityPrecision làm tick/step (Binance dặn rõ)."""
    out = {"symbol": row.get("symbol"), "status": row.get("status") or row.get("contractStatus"), "base": row.get("baseAsset"),
           "quote": row.get("quoteAsset"), "margin_asset": row.get("marginAsset"), "contract_type": row.get("contractType"),
           "tick": None, "step": None, "min_qty": None, "max_qty": None, "min_notional": None}
    for f in row.get("filters") or []:
        ft = f.get("filterType", "")
        if "tickSize" in f and out["tick"] is None:
            out["tick"] = _f(f["tickSize"])
        if "stepSize" in f and out["step"] is None and ft != "MARKET_LOT_SIZE":
            out["step"], out["min_qty"], out["max_qty"] = _f(f["stepSize"]), _f(f.get("minQty")), _f(f.get("maxQty"))
        if out["min_notional"] is None:
            for k in ("notional", "minNotional"):
                if k in f:
                    out["min_notional"] = _f(f[k])
    return out


def spec_text(info, last_price=None):
    """Văn bản tiếng Việt cho hộp thoại. Ước lượng giá trị 1 tick và số lượng tối thiểu theo giá hiện tại nếu có."""
    rows = [("Mã", info.get("symbol")), ("Trạng thái", info.get("status")), ("Cặp", "%s / %s" % (info.get("base") or "?", info.get("quote") or "?")),
            ("Loại hợp đồng", info.get("contract_type")), ("Tài sản ký quỹ", info.get("margin_asset")),
            ("Bước giá (tick)", info.get("tick")), ("Bước khối lượng", info.get("step")),
            ("Khối lượng tối thiểu", info.get("min_qty")), ("Khối lượng tối đa", info.get("max_qty")),
            ("Giá trị lệnh tối thiểu", info.get("min_notional"))]
    lines = ["%s: %s" % (k, v) for k, v in rows if v not in (None, "")]
    if last_price and info.get("min_qty"):
        lines.append("Lệnh nhỏ nhất ≈ %.6g (theo giá %.6g)" % (info["min_qty"] * last_price, last_price))
    return "\n".join(lines) if lines else "Sàn không trả thông số."


def depth_summary(book, levels=10):
    """Tóm tắt sổ lệnh: spread, tổng KL mỗi phía trong `levels` mức, mất cân bằng (-1..1, >0 = bên mua dày hơn), mức dày nhất mỗi phía."""
    bids = sorted((b for b in book.get("bids", []) if b[1] > 0), key=lambda x: -x[0])[:levels]
    asks = sorted((a for a in book.get("asks", []) if a[1] > 0), key=lambda x: x[0])[:levels]
    if not bids or not asks:
        return None
    bv, av = sum(b[1] for b in bids), sum(a[1] for a in asks)
    mid = (bids[0][0] + asks[0][0]) / 2.0
    cum, run = [], 0.0
    for p, q in bids:
        run += q
        cum.append(("bid", p, q, run))
    run = 0.0
    for p, q in asks:
        run += q
        cum.append(("ask", p, q, run))
    return {"best_bid": bids[0][0], "best_ask": asks[0][0], "spread": asks[0][0] - bids[0][0],
            "spread_pct": (asks[0][0] - bids[0][0]) / mid * 100.0, "bid_vol": bv, "ask_vol": av,
            "imbalance": (bv - av) / (bv + av), "wall_bid": max(bids, key=lambda x: x[1]), "wall_ask": max(asks, key=lambda x: x[1]),
            "rows": cum, "bids": bids, "asks": asks}


def depth_text(book, levels=10):
    s = depth_summary(book, levels)
    if not s:
        return "Sổ lệnh trống."
    lines = ["Spread %.8g (%.4f%%) · mất cân bằng %+.2f (>0: bên MUA dày hơn)" % (s["spread"], s["spread_pct"], s["imbalance"]),
             "Tường mua lớn nhất: %.8g × %.6g · tường bán lớn nhất: %.8g × %.6g" % (tuple(s["wall_bid"]) + tuple(s["wall_ask"])), ""]
    lines.append("%14s %14s | %14s %14s" % ("KL mua", "GIÁ MUA", "GIÁ BÁN", "KL bán"))
    for i in range(levels):
        b = s["bids"][i] if i < len(s["bids"]) else None
        a = s["asks"][i] if i < len(s["asks"]) else None
        lines.append("%14s %14s | %14s %14s" % ("%.6g" % b[1] if b else "", "%.8g" % b[0] if b else "", "%.8g" % a[0] if a else "", "%.6g" % a[1] if a else ""))
    return "\n".join(lines)
