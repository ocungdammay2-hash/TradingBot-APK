"""
Thống kê nâng cao + Monte Carlo cho danh sách lệnh đã đóng (theo PDF «thiếu gì»: Sortino/Calmar/R-multiple/theo tháng, Monte Carlo).
Chỉ thư viện chuẩn, tất định khi cho `seed`. Đầu vào: danh sách đối tượng có `.profit` (và `.close_time` cho phần theo tháng).
Nói thẳng: Monte Carlo trộn/lấy mẫu lại CHÍNH các lệnh đã có -> chỉ cho biết độ nhạy với THỨ TỰ lệnh, không dự báo tương lai.
"""
import math
import random
import time


def _profits(trades):
    return [float(getattr(t, "profit", t)) for t in trades]


def max_drawdown(profits, start_balance):
    """(sụt tuyệt đối, sụt %) trên đường vốn theo từng lệnh."""
    eq = peak = float(start_balance)
    dd = ddp = 0.0
    for p in profits:
        eq += p
        peak = max(peak, eq)
        dd = max(dd, peak - eq)
        if peak > 0:
            ddp = max(ddp, (peak - eq) / peak * 100.0)
    return dd, ddp


def sortino(profits, start_balance, target=0.0):
    """Sortino theo lợi suất từng lệnh (so với vốn đầu kỳ chạy), chỉ phạt phần dưới `target`. None nếu không có lệnh lỗ/ít dữ liệu."""
    if len(profits) < 3:
        return None
    eq = float(start_balance)
    rets = []
    for p in profits:
        if eq <= 0:
            break
        rets.append(p / eq)
        eq += p
    if len(rets) < 3:
        return None
    m = sum(rets) / len(rets)
    dsq = sum(min(0.0, r - target) ** 2 for r in rets) / len(rets)
    if dsq <= 0:
        return None
    return (m - target) / math.sqrt(dsq) * math.sqrt(len(rets))


def calmar(trades, start_balance):
    """Lợi suất quy năm / sụt vốn tối đa (%). None nếu thiếu thời gian hoặc không sụt."""
    ps = _profits(trades)
    ts = [getattr(t, "close_time", 0) or 0 for t in trades]
    if len(ps) < 2 or not any(ts):
        return None
    _, ddp = max_drawdown(ps, start_balance)
    span = max(ts) - min(getattr(t, "open_time", 0) or min(ts) for t in trades)
    if ddp <= 0 or span <= 0 or start_balance <= 0:
        return None
    ret = sum(ps) / start_balance
    years = span / (365.25 * 86400)
    ann = ((1 + ret) ** (1 / years) - 1) if (1 + ret) > 0 and years >= 1 / 365 else ret / max(years, 1e-9)
    return ann * 100.0 / ddp


def r_multiples(trades, risk_per_trade=None):
    """R-multiple = lợi nhuận / rủi ro 1 lệnh. Không biết SL từng lệnh -> dùng `risk_per_trade` (tiền) hoặc LỖ TRUNG BÌNH làm 1R (ghi rõ trong kết quả)."""
    ps = _profits(trades)
    losses = [-p for p in ps if p < 0]
    if risk_per_trade and risk_per_trade > 0:
        one_r, src = float(risk_per_trade), "rủi ro cho trước"
    elif losses:
        one_r, src = sum(losses) / len(losses), "lỗ trung bình"
    else:
        return {"one_r": None, "nguồn 1R": "không có lệnh lỗ", "kỳ vọng (R)": None, "R TB lãi": None, "R TB lỗ": None, "R": []}
    rs = [p / one_r for p in ps]
    w = [r for r in rs if r > 0]
    l = [r for r in rs if r < 0]
    return {"one_r": one_r, "nguồn 1R": src, "kỳ vọng (R)": sum(rs) / len(rs) if rs else None,
            "R TB lãi": sum(w) / len(w) if w else 0.0, "R TB lỗ": sum(l) / len(l) if l else 0.0, "R": rs}


def monthly(trades):
    """[{'thang': '2026-10', 'n', 'net'}] theo tháng ĐÓNG lệnh (UTC)."""
    acc = {}
    for t in trades:
        ct = getattr(t, "close_time", 0) or 0
        k = time.strftime("%Y-%m", time.gmtime(ct))
        a = acc.setdefault(k, [0, 0.0])
        a[0] += 1
        a[1] += float(t.profit)
    return [{"thang": k, "n": v[0], "net": v[1]} for k, v in sorted(acc.items())]


def extra_stats(trades, start_balance, risk_per_trade=None):
    ps = _profits(trades)
    r = r_multiples(trades, risk_per_trade)
    return {"Sortino (theo lệnh)": sortino(ps, start_balance), "Calmar": calmar(trades, start_balance),
            "Kỳ vọng (R)": r["kỳ vọng (R)"], "1R (nguồn)": "%s (%s)" % (r["one_r"], r["nguồn 1R"]), "Theo tháng": monthly(trades)}


def _pct(sorted_xs, q):
    if not sorted_xs:
        return None
    i = min(len(sorted_xs) - 1, max(0, int(round(q * (len(sorted_xs) - 1)))))
    return sorted_xs[i]


def monte_carlo(trades, start_balance, runs=1000, mode="shuffle", seed=None, ruin_level=0.5):
    """Mô phỏng `runs` đường vốn.
    mode='shuffle': hoán vị thứ tự lệnh (cùng tổng lãi, đổi sụt vốn) · mode='bootstrap': lấy mẫu có hoàn lại (đổi cả tổng lãi).
    ruin_level: tỷ lệ vốn đầu còn lại bị coi là «cháy» (0.5 = mất một nửa)."""
    ps = _profits(trades)
    if not ps:
        return {"ok": False, "runs": 0, "message": "Không có lệnh để mô phỏng."}
    if mode not in ("shuffle", "bootstrap"):
        raise ValueError("mode phải là shuffle|bootstrap")
    runs = max(1, int(runs))
    rng = random.Random(seed)
    finals, dds, ruin = [], [], 0
    floor = start_balance * ruin_level
    for _ in range(runs):
        seq = ps[:]
        if mode == "shuffle":
            rng.shuffle(seq)
        else:
            seq = [rng.choice(ps) for _ in ps]
        eq = float(start_balance)
        peak, dd, hit = eq, 0.0, False
        for p in seq:
            eq += p
            peak = max(peak, eq)
            if peak > 0:
                dd = max(dd, (peak - eq) / peak * 100.0)
            if eq <= floor:
                hit = True
        finals.append(eq)
        dds.append(dd)
        ruin += hit
    fs, ds = sorted(finals), sorted(dds)
    return {"ok": True, "runs": runs, "mode": mode, "n_trades": len(ps), "seed": seed,
            "final_p5": _pct(fs, 0.05), "final_p50": _pct(fs, 0.5), "final_p95": _pct(fs, 0.95),
            "dd_p50": _pct(ds, 0.5), "dd_p95": _pct(ds, 0.95), "dd_max": ds[-1],
            "prob_loss": sum(1 for f in finals if f < start_balance) / runs,
            "prob_ruin": ruin / runs, "ruin_level": ruin_level,
            "message": "Chỉ cho biết độ nhạy với thứ tự/mẫu lệnh đã có, không phải dự báo."}


def monte_carlo_text(mc):
    if not mc.get("ok"):
        return mc.get("message", "")
    return ("Monte Carlo %d lần (%s, %d lệnh): vốn cuối P5/P50/P95 = %.2f / %.2f / %.2f · sụt vốn P50/P95/tối đa = %.1f%% / %.1f%% / %.1f%% · "
            "xác suất lỗ %.1f%% · xác suất mất ≥%.0f%% vốn %.1f%%. %s") % (
        mc["runs"], mc["mode"], mc["n_trades"], mc["final_p5"], mc["final_p50"], mc["final_p95"], mc["dd_p50"], mc["dd_p95"], mc["dd_max"],
        mc["prob_loss"] * 100, (1 - mc["ruin_level"]) * 100, mc["prob_ruin"] * 100, mc["message"])
