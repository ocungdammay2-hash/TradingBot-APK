"""Gửi báo lỗi TỰ ĐỘNG (tuỳ chọn, mặc định TẮT; người dùng tự nhập địa chỉ máy chủ nhận). KHÔNG import Kivy.

Chỉ gửi nội dung crash.log của lần chạy trước (app đổi tên sang .old ngay sau khi đọc), đã che bí mật (pyea/redact.py), cắt tối đa 20.000 ký tự, kèm phiên bản app/hệ điều hành.
Địa chỉ phải là https:// (http:// chỉ được cho localhost để thử). Không có gì được gửi khi tắt hoặc chưa nhập địa chỉ."""
import platform
import time
from urllib.parse import urlparse

from . import redact
from .feeds import FeedError, http_json

MAX_CHARS = 20000


def valid_url(url):
    try:
        u = urlparse(str(url or "").strip())
    except ValueError:
        return False
    if u.scheme == "https" and u.netloc:
        return True
    return u.scheme == "http" and u.hostname in ("localhost", "127.0.0.1", "::1")


def build_payload(text, version, now=None):
    t = redact.redact(text or "", aggressive=False)
    if len(t) > MAX_CHARS:
        t = "…(cắt phần đầu)…\n" + t[-MAX_CHARS:]
    return {"app": "PyEA Runner", "version": str(version), "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() if now is None else now)),
            "platform": "%s %s" % (platform.system(), platform.release()), "report": t}


def send(url, payload, http=http_json, timeout=10):
    """-> (True, "") hoặc (False, lý do). Không bao giờ ném lỗi."""
    if not valid_url(url):
        return False, "Địa chỉ nhận báo lỗi phải là https:// (hoặc http://localhost để thử)"
    try:
        http(str(url).strip(), method="POST", body=payload, timeout=timeout, headers={"User-Agent": "PyEA-Runner"})
        return True, ""
    except (FeedError, OSError, ValueError) as e:
        return False, str(e)


def flush(settings, text, version, http=http_json):
    """Gọi lúc khởi động (luồng nền) với nội dung crash.log của LẦN CHẠY TRƯỚC (app đổi tên file sang .old ngay sau đó nên không gửi lại).
    Bật + có địa chỉ + có nội dung -> gửi. -> (đã gửi?, thông điệp)."""
    if not settings.get("crash_report_auto") or not str(settings.get("crash_report_url") or "").strip() or not str(text or "").strip():
        return False, ""
    return send(settings["crash_report_url"], build_payload(text, version), http=http)
