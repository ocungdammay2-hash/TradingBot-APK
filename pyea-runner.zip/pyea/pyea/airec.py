"""Ghi lại & PHÁT LẠI tín hiệu AI (PDF «thiếu gì»: backtest bot dùng `api.ai_signal` phải tái lập được).

Vấn đề: đầu ra LLM KHÔNG tái lập (cùng prompt, hai lần hỏi ra hai câu khác nhau) nên không thể "chạy lại AI" trong backtest.
Cách làm trung thực duy nhất: GHI mỗi tín hiệu thật (kèm model + dấu vân tay prompt + thời điểm) rồi PHÁT LẠI đúng các tín hiệu đó
theo đồng hồ thị trường của backtest. Lưu ý giới hạn (hiển thị cho người dùng, không giấu):
  - `prompt_hash` chỉ để ĐỐI CHIẾU/kiểm toán (biết hai tín hiệu đến từ cùng prompt hay không) - KHÔNG đủ để sinh lại câu trả lời.
  - Chỉ phát lại được trong khoảng thời gian đã có ghi tín hiệu (chạy paper/live trước, rồi backtest cùng giai đoạn).
  - Backtest KHÔNG phát lại -> `api.ai_signal` luôn None; báo cáo ghi rõ điều đó nếu bot có đọc.

Module thuần Python (không Kivy); lõi không phụ thuộc mạng.
"""
import bisect
import hashlib
import json
import math
import os
import threading

from . import redact

SIGNAL_FILE = "ai_signals.jsonl"
VERSION = 1
KEEP = ("uid", "id", "time", "symbol", "timeframe", "action", "confidence", "sl_pct", "tp_pct", "reason", "by", "model", "provider",
        "mode", "votes", "prompt_hash")
ACTIONS = ("buy", "sell", "hold", "close_all")


def prompt_hash(messages):
    """Dấu vân tay 16 ký tự của đúng những gì ĐÃ GỬI cho nhà cung cấp (sau khi che bí mật). Cùng nội dung -> cùng hash."""
    try:
        raw = json.dumps(messages, sort_keys=True, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        raw = repr(messages)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def combine_hashes(hashes):
    """Hash gộp của nhiều phiếu (bỏ trống/None); không phụ thuộc thứ tự."""
    hs = sorted(h for h in hashes if h)
    return hashlib.sha256("|".join(hs).encode("utf-8")).hexdigest()[:16] if hs else ""


def _num(v, default=0.0):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


def to_record(sig, symbol="", timeframe="", provider=""):
    """Tín hiệu AIHub -> dòng ghi (chỉ các khoá cần cho phát lại + kiểm toán, đã che bí mật; bỏ `discussion` vốn dài)."""
    t = _num(sig.get("time"))
    sid = sig.get("id", 0)
    out = {k: sig[k] for k in KEEP if k in sig}
    out.update(time=t, uid="%d-%s" % (int(t * 1000), sid), symbol=symbol or sig.get("symbol", ""), timeframe=timeframe or sig.get("timeframe", ""),
               provider=provider or sig.get("provider", ""), v=VERSION)
    if out.get("votes"):
        out["votes"] = [_clean(x, ("agent", "model", "action", "confidence", "reason", "prompt_hash")) for x in out["votes"] if isinstance(x, dict)]
    out.update(_clean(out, ("reason", "by", "model")))
    return out


def _clean(src, keys):
    """Giữ đúng các khoá cho phép; chuỗi nào cũng qua redact (bí mật có thể lọt vào lời giải thích của AI)."""
    return {k: (redact.redact(src[k]) if isinstance(src[k], str) else src[k]) for k in keys if k in src}


def valid(rec):
    """Bản ghi dùng được để phát lại: có thời điểm hữu hạn > 0 và hành động hợp lệ."""
    return isinstance(rec, dict) and _num(rec.get("time")) > 0 and rec.get("action") in ACTIONS


class SignalLog:
    """File JSONL ghi tín hiệu (mỗi dòng 1 tín hiệu). Ghi nối tiếp, chịu được dòng hỏng khi đọc."""

    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()

    def append(self, rec):
        try:
            with self._lock, open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False, allow_nan=False) + "\n")
            return True
        except (OSError, ValueError):
            return False

    def load(self, since=None, until=None, symbol=None):
        """-> list bản ghi hợp lệ theo thời gian tăng dần; lọc theo [since, until] và (nếu có) mã giao dịch."""
        out = []
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue
                    if not valid(rec):
                        continue
                    if since is not None and rec["time"] < since:
                        continue
                    if until is not None and rec["time"] > until:
                        continue
                    if symbol and rec.get("symbol") and str(rec["symbol"]).upper() != str(symbol).upper():
                        continue
                    out.append(rec)
        except OSError:
            return []
        out.sort(key=lambda r: r["time"])
        return out


def load_dir(base_dir, **kw):
    return SignalLog(os.path.join(base_dir, SIGNAL_FILE)).load(**kw)


class NullHub:
    """Hub của backtest KHÔNG phát lại: `api.ai_signal` luôn None, nhưng đếm số lần bot đọc để báo cáo biết kết quả không nói gì về AI."""
    replaying = False

    def __init__(self):
        self.reads = 0

    def get_signal(self):
        self.reads += 1
        return None

    def summary(self):
        if not self.reads:
            return ""
        return ("KHÔNG phát lại tín hiệu AI: bot đọc api.ai_signal %d lần nhưng luôn nhận None - kết quả này không phản ánh AI "
                "(bật 'Phát lại tín hiệu AI đã ghi' để thử với tín hiệu thật đã lưu)" % self.reads)


class ReplayHub:
    """Hub phát lại: `get_signal()` trả tín hiệu ghi gần nhất có time <= đồng hồ thị trường và còn hạn (ttl), nên KHÔNG nhìn trước tương lai."""
    replaying = True

    def __init__(self, signals, clock, ttl_minutes=30.0, window=None):
        sigs = sorted((s for s in (signals or []) if valid(s)), key=lambda r: r["time"])
        self._sigs = sigs
        self._times = [s["time"] for s in sigs]
        self.clock = clock
        self.ttl = max(0.0, _num(ttl_minutes, 30.0)) * 60.0
        self.window = window                       # (t0, t1) khoảng dữ liệu backtest - chỉ để báo cáo số tín hiệu nằm trong đó
        self.reads = self.hits = 0
        self.used = set()

    def get_signal(self):
        self.reads += 1
        try:
            now = float(self.clock())
        except (TypeError, ValueError):
            return None
        if not math.isfinite(now):
            return None
        i = bisect.bisect_right(self._times, now) - 1
        if i < 0:
            return None
        s = self._sigs[i]
        age = now - s["time"]
        if age > self.ttl:
            return None
        self.hits += 1
        self.used.add(s.get("uid") or i)
        out = dict(s)
        out["age"] = age
        out["replayed"] = True
        return out

    def in_window(self):
        if not self.window:
            return len(self._sigs)
        t0, t1 = self.window
        return sum(1 for s in self._sigs if t0 <= s["time"] <= t1)

    def summary(self):
        n_all, n_in = len(self._sigs), self.in_window()
        if not n_all:
            return "Phát lại tín hiệu AI: KHÔNG có tín hiệu đã ghi nào (chạy paper/live với nhóm AI trước) - bot luôn nhận None"
        if not n_in:
            return ("Phát lại tín hiệu AI: %d tín hiệu đã ghi nhưng KHÔNG cái nào nằm trong khoảng thời gian của dữ liệu backtest - "
                    "bot luôn nhận None (backtest đúng giai đoạn đã ghi tín hiệu)" % n_all)
        return ("Phát lại %d tín hiệu đã ghi (%d nằm trong khoảng dữ liệu): bot đọc %d lần, %d lần thấy tín hiệu còn hạn (%d tín hiệu khác nhau được dùng). "
                "LƯU Ý: chỉ tái lập đúng các tín hiệu đã ghi, KHÔNG sinh lại câu trả lời của AI" % (n_all, n_in, self.reads, self.hits, len(self.used)))


def market_now(sess):
    """Đồng hồ thị trường của phiên backtest = thời gian tick mới nhất của mọi mã."""
    ts = [t.time for t in list(sess.ticks.values())]
    return max(ts) if ts else float("-inf")
