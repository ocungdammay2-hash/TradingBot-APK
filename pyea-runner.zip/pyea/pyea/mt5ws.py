"""
MT5 Web Terminal (WebSocket) - NỐI THẲNG từ điện thoại tới máy chủ MT5 của broker: KHÔNG máy tính, KHÔNG VPS, KHÔNG dịch vụ trung gian.
Dùng đúng giao thức mà trang web.metatrader.app / «MT5 Web Terminal» của broker dùng (WebSocket nhị phân + AES-CBC), đã được cộng đồng dịch ngược
trong dự án mã nguồn mở pymt5 (cloudQuant, giấy phép MIT - xem docs/THIRD_PARTY.md). Mã ở đây là bản VIẾT LẠI chỉ bằng thư viện chuẩn (AES thuần Python,
có thể tăng tốc bằng `cryptography` nếu máy có) nên chạy được trong bản dựng Android (python-for-android) mà không thêm phụ thuộc.

Khung truyền: [uint32 độ dài][uint32 phiên bản=1] + AES-CBC(IV=0, PKCS7)( 2 byte ngẫu nhiên + uint16 lệnh + payload ). Trả lời: 2 byte + uint16 lệnh + 1 byte mã + thân.
Trình tự: bootstrap (lệnh 0, khoá AES khởi tạo cố định) -> nhận token + khoá phiên -> đăng nhập (lệnh 28) -> lệnh 3 tài khoản · 4 vị thế+lệnh chờ ·
5 lịch sử deal · 6/34 danh sách mã · 7 đăng ký giá (đẩy qua lệnh 8) · 11 nến · 12 gửi lệnh · 18 đặc tả mã · 51 nhịp tim.

CHƯA KIỂM CHỨNG VỚI SÀN THẬT (nói thẳng): chưa chạy với broker/tài khoản MT5 nào - toàn bộ thử nghiệm dùng máy chủ giả theo đúng bố cục byte của pymt5.
Giao thức này KHÔNG chính thức (MetaQuotes không công bố, có thể đổi khi họ nâng bản web terminal; pymt5 ghi nhận build 5687). Những chỗ chưa chắc có thẻ
`# CHƯA XÁC MINH`: cách chọn máy chủ broker (mt5ws_uri / mt5ws_url), thang khối lượng (mt5ws_volume_scale, mặc định 1 lot = 1e8), múi giờ máy chủ
(mt5ws_server_offset_hours, mặc định tự dò từ giá đẩy), ký quỹ/ký quỹ tự do (lệnh 3 không báo -> để None), chế độ khớp lệnh (filling).
LUÔN thử trên tài khoản DEMO trước khi dùng thật; chạy `selfcheck` để kiểm kết nối/đọc dữ liệu/giao dịch thử.
"""
import hashlib
import os
import re
import struct
import threading
import time
import zlib
from collections import deque

from . import ordertag
from .bridges import BridgeError, MtBackend
from .feeds import TIMEFRAMES
from .sdk import Candle
from .wsclient import WebSocketClient, WsClosed, WsError

DEFAULT_URI = "wss://web.metatrader.app/terminal"
ORIGIN = "https://web.metatrader.app"
INITIAL_KEY_OBFUSCATED = "13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75"
OUTER_VERSION = 1
HEARTBEAT_EVERY = 25.0

CMD_BOOTSTRAP, CMD_ACCOUNT, CMD_POS_ORDERS, CMD_HISTORY, CMD_SYMBOLS, CMD_SUBSCRIBE, CMD_TICK_PUSH = 0, 3, 4, 5, 6, 7, 8
CMD_RATES, CMD_TRADE, CMD_FULL_SYMBOL, CMD_LOGIN, CMD_SYMBOLS_GZ, CMD_PING = 11, 12, 18, 28, 34, 51
PERIOD_CODE = {1: 1, 5: 5, 15: 15, 30: 30, 60: 16385, 240: 16388, 1440: 16408, 10080: 32769, 43200: 49153}

ACT_DEAL, ACT_PENDING, ACT_SLTP, ACT_MODIFY, ACT_REMOVE = 1, 5, 6, 7, 8
OT_BUY, OT_SELL, OT_BUY_LIMIT, OT_SELL_LIMIT, OT_BUY_STOP, OT_SELL_STOP, OT_BUY_STOP_LIMIT, OT_SELL_STOP_LIMIT = 0, 1, 2, 3, 4, 5, 6, 7
FILL_FOK, FILL_IOC, FILL_RETURN = 0, 1, 2
TIME_GTC, TIME_SPECIFIED = 0, 2
RET_OK = (0, 10008, 10009, 10010)
RET_UNSURE = (10011, 10012, 10031)          # lỗi xử lý / hết giờ / mất kết nối: KHÔNG biết lệnh đã vào chưa -> phải đọc lại sàn để xác minh
RET_INFO = {                                # mã -> (nghĩa, cách xử lý)
    10004: ("Báo giá lại (requote)", "Giá vừa đổi. Thử lại, hoặc tăng ô «MT5 trượt giá tối đa»."),
    10006: ("Sàn từ chối lệnh", "Xem nguyên văn lý do của sàn bên dưới."),
    10007: ("Lệnh bị huỷ", "Lệnh bị huỷ trước khi khớp."),
    10011: ("Lỗi xử lý lệnh ở sàn", ""), 10012: ("Hết thời gian chờ khớp lệnh", ""),
    10013: ("Yêu cầu không hợp lệ", "Kiểm tra mã, khối lượng và giá."),
    10014: ("Khối lượng không hợp lệ", "Chọn khối lượng trong khoảng min-max của mã và là bội của bước khối lượng."),
    10015: ("Giá không hợp lệ", "Với lệnh chờ: giá sai phía (limit/stop) hoặc quá sát giá hiện tại."),
    10016: ("SL/TP không hợp lệ", "SL/TP quá sát giá hoặc sai phía. Cách giá tối thiểu theo «stops level» của mã."),
    10017: ("Mã này đang tắt giao dịch", "Tài khoản có thể là mật khẩu investor (chỉ xem), hoặc mã bị khoá."),
    10018: ("Thị trường đóng cửa", "Thử lại khi thị trường mở."),
    10019: ("Không đủ tiền ký quỹ", "Giảm khối lượng hoặc nạp thêm tiền."),
    10020: ("Giá đã đổi", "Thử lại."), 10021: ("Không có báo giá để xử lý", "Thử lại sau vài giây."),
    10022: ("Hạn lệnh không hợp lệ", "Bỏ hạn hoặc đặt hạn xa hơn."), 10023: ("Trạng thái lệnh đã đổi", "Đọc lại danh sách lệnh rồi thử lại."),
    10024: ("Gửi yêu cầu quá nhanh", "Chờ vài giây rồi thử lại."), 10025: ("Không có gì thay đổi", ""),
    10026: ("Máy chủ tắt giao dịch tự động", "Broker đang tắt giao dịch tự động cho tài khoản này."),
    10027: ("Phiên/tài khoản không cho giao dịch tự động", "Kiểm tra quyền của tài khoản (mật khẩu giao dịch, không phải investor)."),
    10028: ("Yêu cầu đang bị khoá xử lý", "Thử lại sau."), 10029: ("Lệnh/vị thế đang bị đóng băng", "Quá sát giá hiện tại; thử lại sau."),
    10030: ("Kiểu khớp lệnh (filling) không được hỗ trợ", "Đổi ô «MT5 kiểu khớp lệnh» sang fok, ioc hoặc return."),
    10031: ("Mất kết nối tới máy chủ giao dịch", ""), 10032: ("Chỉ cho tài khoản thật", ""),
    10033: ("Đã đủ số lệnh chờ tối đa", "Huỷ bớt lệnh chờ."), 10034: ("Vượt giới hạn khối lượng của mã", "Giảm khối lượng hoặc đóng bớt vị thế."),
    10035: ("Kiểu lệnh không hợp lệ/bị cấm", "Mã này không cho kiểu lệnh đó (vd chỉ cho đóng)."), 10036: ("Vị thế đã đóng rồi", "Làm mới danh sách vị thế.")}
RET_VI = {k: v[0] for k, v in RET_INFO.items()}


def raw_text(body, limit=240):
    """Trích nguyên văn phần chữ đọc được trong thân trả lời của sàn (UTF-16LE hoặc ASCII) - để người dùng/nhà phát triển tự đối chiếu mã lỗi."""
    body = bytes(body or b"")
    best = ""
    for enc in ("utf-16-le", "latin-1"):
        for off in (0, 1):
            try:
                t = body[off:].decode(enc, "ignore")
            except Exception:
                continue
            runs = re.findall(r"[\w .,:;!?()/'\"+\-=%#@&\u00C0-\u1EF9]{4,}", t)
            cand = " | ".join(r.strip() for r in runs if r.strip())
            if len(cand) > len(best):
                best = cand
    return best[:limit]


def explain_connect_error(e, uri):
    """Lỗi kết nối WebSocket -> câu hướng dẫn cụ thể (kèm nguyên văn lỗi)."""
    t = str(e).lower()
    status = getattr(e, "status", 0)
    host = uri.split("//", 1)[-1].split("/", 1)[0]
    if any(k in t for k in ("getaddrinfo", "name or service", "resolve", "nodename")):
        hint = "Không tìm thấy máy chủ «%s». Kiểm tra chính tả địa chỉ (mt5ws_uri), mạng Wi-Fi/4G và VPN." % host
    elif "refused" in t:
        hint = "Máy chủ «%s» từ chối kết nối: sai cổng/địa chỉ, hoặc dịch vụ không chạy." % host
    elif "timed out" in t or "timeout" in t:
        hint = "Hết thời gian chờ «%s»: mạng chậm/bị chặn, hoặc địa chỉ không đúng." % host
    elif "ssl" in t or "certificate" in t:
        hint = "Lỗi chứng chỉ TLS khi nối «%s»: kiểm tra giờ của điện thoại và địa chỉ wss://." % host
    elif status in (400, 401, 403, 404, 405):
        hint = ("Máy chủ trả HTTP %d: địa chỉ này có thể không phải web terminal MT5 (đường dẫn thường kết thúc /terminal), hoặc broker chặn "
                "nguồn web.metatrader.app." % status)
    else:
        hint = "Kiểm tra địa chỉ (mt5ws_uri) và mạng."
    return "%s\nĐịa chỉ đang dùng: %s\nNguyên văn lỗi: %s" % (hint, uri, e)


def problems(s, require=False):
    """Kiểm tra các ô «MT5 trực tiếp»; trả danh sách câu hướng dẫn CỤ THỂ (rỗng = hợp lệ). require=True: ô bắt buộc để trống cũng báo."""
    g = lambda k: str(s.get(k, "") or "")
    out = []
    login, pw, uri, off, scale, dev, otp = g("mt5ws_login").strip(), g("mt5ws_password"), g("mt5ws_uri").strip(), g("mt5ws_server_offset_hours").strip(), \
        g("mt5ws_volume_scale").strip(), g("mt5ws_deviation").strip(), g("mt5ws_otp").strip()
    if not login:
        if require:
            out.append("MT5 số tài khoản: chưa nhập. Đó là «Login» (dãy số) trong email broker gửi khi mở tài khoản.")
    elif not login.isdigit():
        out.append("MT5 số tài khoản: chỉ gồm chữ số (vd 51234567) - là «Login» trong email broker, không phải email/tên máy chủ. Bạn nhập: «%s»." % login)
    if not pw:
        if require:
            out.append("MT5 mật khẩu: chưa nhập. Dùng mật khẩu GIAO DỊCH (không phải mật khẩu investor, vì investor chỉ xem được).")
    else:
        if pw != pw.strip():
            out.append("MT5 mật khẩu: có khoảng trắng ở đầu/cuối - xoá khoảng trắng (thường do dán từ tin nhắn).")
        is_blob = len(pw) == 320 and all(c in "0123456789abcdefABCDEF" for c in pw)
        if len(pw) > 32 and not is_blob:
            out.append("MT5 mật khẩu: dài %d ký tự, MT5 chỉ nhận tối đa 32 ký tự - kiểm tra có dán nhầm không." % len(pw))
    if uri:
        low = uri.lower()
        host = low.split("//", 1)[-1].split("/", 1)[0].split(":")[0]
        if " " in uri:
            out.append("MT5 địa chỉ WebSocket: không được có khoảng trắng.")
        elif low.startswith(("http://", "https://")):
            out.append("MT5 địa chỉ WebSocket: phải bắt đầu bằng wss:// (không phải http/https). Thử: wss://%s" % uri.split("//", 1)[1])
        elif not low.startswith(("wss://", "ws://")):
            out.append("MT5 địa chỉ WebSocket: thiếu «wss://» ở đầu. Thử: wss://%s%s (hoặc để TRỐNG để dùng web.metatrader.app)." % (uri, "" if "/" in uri else "/terminal"))
        elif low.startswith("ws://") and host not in ("127.0.0.1", "localhost"):
            out.append("MT5 địa chỉ WebSocket: «ws://» không mã hoá, mật khẩu có thể bị lộ trên đường truyền. Dùng wss://.")
    if off:
        try:
            v = float(off)
            if not -12 <= v <= 14:
                raise ValueError
        except ValueError:
            out.append("MT5 múi giờ máy chủ: nhập SỐ GIỜ lệch so với UTC, từ -12 đến 14 (vd 2 hoặc 3; máy chủ MT5 thường UTC+2/UTC+3). Để trống = tự dò. Bạn nhập: «%s»." % off)
    if scale:
        try:
            v = float(scale)
            if not (v > 0 and v < 1e18):
                raise ValueError
        except ValueError:
            out.append("MT5 thang khối lượng: nhập một số dương (mặc định 100000000 = 1 lot). Bạn nhập: «%s»." % scale)
    if dev:
        if not dev.isdigit() or int(dev) > 10000:
            out.append("MT5 trượt giá tối đa: nhập số nguyên từ 0 đến 10000 (đơn vị điểm, vd 20). Bạn nhập: «%s»." % dev)
    if otp and not otp.isalnum():
        out.append("MT5 mã OTP: chỉ gồm chữ và số (thường 6 chữ số).")
    return out


# =========================================================================================== AES (thuần Python, CBC IV=0, PKCS7)
def _build_tables():
    sbox, p, q = [0] * 256, 1, 1
    while True:
        p = (p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)) & 0xFF
        q ^= (q << 1) & 0xFF
        q ^= (q << 2) & 0xFF
        q ^= (q << 4) & 0xFF
        q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        rot = lambda v, n: ((v << n) | (v >> (8 - n))) & 0xFF
        sbox[p] = (q ^ rot(q, 1) ^ rot(q, 2) ^ rot(q, 3) ^ rot(q, 4) ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    inv = [0] * 256
    for i, s in enumerate(sbox):
        inv[s] = i

    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            a = ((a << 1) & 0xFF) ^ (0x1B if a & 0x80 else 0)
            b >>= 1
        return r
    te = [[0] * 256 for _ in range(4)]
    td = [[0] * 256 for _ in range(4)]
    for x in range(256):
        s, i = sbox[x], inv[x]
        w = (mul(s, 2) << 24) | (s << 16) | (s << 8) | mul(s, 3)
        v = (mul(i, 14) << 24) | (mul(i, 9) << 16) | (mul(i, 13) << 8) | mul(i, 11)
        for k in range(4):
            te[k][x] = ((w >> (8 * k)) | (w << (32 - 8 * k))) & 0xFFFFFFFF
            td[k][x] = ((v >> (8 * k)) | (v << (32 - 8 * k))) & 0xFFFFFFFF
    return sbox, inv, te, td


_SBOX, _INV, _TE, _TD = _build_tables()


class AesCbc:
    """AES-128/192/256 CBC, IV = 0, đệm PKCS7 (đúng như web terminal). Dùng `cryptography` nếu có (nhanh), không thì mã thuần Python bên dưới."""

    def __init__(self, key, pure=False):
        key = bytes(key)
        if len(key) not in (16, 24, 32):
            raise BridgeError("Khoá AES sai độ dài (%d byte)" % len(key))
        self.key = key
        self._fast = None
        if not pure:
            try:
                from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
                self._fast = (Cipher, algorithms, modes)
            except Exception:
                self._fast = None
        nk = len(key) // 4
        self.nr = nk + 6
        w = list(struct.unpack(">%dI" % nk, key))
        rcon = 1
        for i in range(nk, 4 * (self.nr + 1)):
            t = w[i - 1]
            if i % nk == 0:
                t = ((t << 8) | (t >> 24)) & 0xFFFFFFFF
                t = (_SBOX[t >> 24] << 24) | (_SBOX[(t >> 16) & 255] << 16) | (_SBOX[(t >> 8) & 255] << 8) | _SBOX[t & 255]
                t ^= rcon << 24
                rcon = ((rcon << 1) ^ (0x11B if rcon & 0x80 else 0)) & 0xFF
            elif nk > 6 and i % nk == 4:
                t = (_SBOX[t >> 24] << 24) | (_SBOX[(t >> 16) & 255] << 16) | (_SBOX[(t >> 8) & 255] << 8) | _SBOX[t & 255]
            w.append(w[i - nk] ^ t)
        self.ek = w
        dk = []
        for r in range(self.nr, -1, -1):
            blk = w[4 * r:4 * r + 4]
            if 0 < r < self.nr:
                blk = [_TD[0][_SBOX[x >> 24]] ^ _TD[1][_SBOX[(x >> 16) & 255]] ^ _TD[2][_SBOX[(x >> 8) & 255]] ^ _TD[3][_SBOX[x & 255]] for x in blk]
            dk += blk
        self.dk = dk

    def _enc_block(self, s0, s1, s2, s3):
        rk, te0, te1, te2, te3, sb = self.ek, _TE[0], _TE[1], _TE[2], _TE[3], _SBOX
        s0 ^= rk[0]; s1 ^= rk[1]; s2 ^= rk[2]; s3 ^= rk[3]
        for r in range(1, self.nr):
            k = 4 * r
            t0 = te0[s0 >> 24] ^ te1[(s1 >> 16) & 255] ^ te2[(s2 >> 8) & 255] ^ te3[s3 & 255] ^ rk[k]
            t1 = te0[s1 >> 24] ^ te1[(s2 >> 16) & 255] ^ te2[(s3 >> 8) & 255] ^ te3[s0 & 255] ^ rk[k + 1]
            t2 = te0[s2 >> 24] ^ te1[(s3 >> 16) & 255] ^ te2[(s0 >> 8) & 255] ^ te3[s1 & 255] ^ rk[k + 2]
            t3 = te0[s3 >> 24] ^ te1[(s0 >> 16) & 255] ^ te2[(s1 >> 8) & 255] ^ te3[s2 & 255] ^ rk[k + 3]
            s0, s1, s2, s3 = t0, t1, t2, t3
        k = 4 * self.nr
        return ((((sb[s0 >> 24] << 24) | (sb[(s1 >> 16) & 255] << 16) | (sb[(s2 >> 8) & 255] << 8) | sb[s3 & 255]) ^ rk[k]),
                (((sb[s1 >> 24] << 24) | (sb[(s2 >> 16) & 255] << 16) | (sb[(s3 >> 8) & 255] << 8) | sb[s0 & 255]) ^ rk[k + 1]),
                (((sb[s2 >> 24] << 24) | (sb[(s3 >> 16) & 255] << 16) | (sb[(s0 >> 8) & 255] << 8) | sb[s1 & 255]) ^ rk[k + 2]),
                (((sb[s3 >> 24] << 24) | (sb[(s0 >> 16) & 255] << 16) | (sb[(s1 >> 8) & 255] << 8) | sb[s2 & 255]) ^ rk[k + 3]))

    def _dec_block(self, s0, s1, s2, s3):
        rk, td0, td1, td2, td3, si = self.dk, _TD[0], _TD[1], _TD[2], _TD[3], _INV
        s0 ^= rk[0]; s1 ^= rk[1]; s2 ^= rk[2]; s3 ^= rk[3]
        for r in range(1, self.nr):
            k = 4 * r
            t0 = td0[s0 >> 24] ^ td1[(s3 >> 16) & 255] ^ td2[(s2 >> 8) & 255] ^ td3[s1 & 255] ^ rk[k]
            t1 = td0[s1 >> 24] ^ td1[(s0 >> 16) & 255] ^ td2[(s3 >> 8) & 255] ^ td3[s2 & 255] ^ rk[k + 1]
            t2 = td0[s2 >> 24] ^ td1[(s1 >> 16) & 255] ^ td2[(s0 >> 8) & 255] ^ td3[s3 & 255] ^ rk[k + 2]
            t3 = td0[s3 >> 24] ^ td1[(s2 >> 16) & 255] ^ td2[(s1 >> 8) & 255] ^ td3[s0 & 255] ^ rk[k + 3]
            s0, s1, s2, s3 = t0, t1, t2, t3
        k = 4 * self.nr
        return ((((si[s0 >> 24] << 24) | (si[(s3 >> 16) & 255] << 16) | (si[(s2 >> 8) & 255] << 8) | si[s1 & 255]) ^ rk[k]),
                (((si[s1 >> 24] << 24) | (si[(s0 >> 16) & 255] << 16) | (si[(s3 >> 8) & 255] << 8) | si[s2 & 255]) ^ rk[k + 1]),
                (((si[s2 >> 24] << 24) | (si[(s1 >> 16) & 255] << 16) | (si[(s0 >> 8) & 255] << 8) | si[s3 & 255]) ^ rk[k + 2]),
                (((si[s3 >> 24] << 24) | (si[(s2 >> 16) & 255] << 16) | (si[(s1 >> 8) & 255] << 8) | si[s0 & 255]) ^ rk[k + 3]))

    def encrypt(self, data):
        pad = 16 - len(data) % 16
        data = bytes(data) + bytes([pad]) * pad
        if self._fast:
            C, A, M = self._fast
            e = C(A.AES(self.key), M.CBC(b"\0" * 16)).encryptor()
            return e.update(data) + e.finalize()
        out, p0, p1, p2, p3 = [], 0, 0, 0, 0
        for i in range(0, len(data), 16):
            a, b, c, d = struct.unpack_from(">4I", data, i)
            p0, p1, p2, p3 = self._enc_block(a ^ p0, b ^ p1, c ^ p2, d ^ p3)
            out.append(struct.pack(">4I", p0, p1, p2, p3))
        return b"".join(out)

    def decrypt(self, data):
        data = bytes(data)
        if not data or len(data) % 16:
            raise BridgeError("Dữ liệu mã hoá sai độ dài")
        if self._fast:
            C, A, M = self._fast
            d = C(A.AES(self.key), M.CBC(b"\0" * 16)).decryptor()
            raw = d.update(data) + d.finalize()
        else:
            out, p0, p1, p2, p3 = [], 0, 0, 0, 0
            for i in range(0, len(data), 16):
                a, b, c, d = struct.unpack_from(">4I", data, i)
                x0, x1, x2, x3 = self._dec_block(a, b, c, d)
                out.append(struct.pack(">4I", x0 ^ p0, x1 ^ p1, x2 ^ p2, x3 ^ p3))
                p0, p1, p2, p3 = a, b, c, d
            raw = b"".join(out)
        pad = raw[-1]
        if not 1 <= pad <= 16 or raw[-pad:] != bytes([pad]) * pad:
            raise BridgeError("Đệm PKCS7 sai (khoá AES không khớp?)")
        return raw[:-pad]


def initial_key():
    s = "".join("&" if ord(c) == 28 else "!" if ord(c) == 23 else chr(ord(c) - 1) for c in INITIAL_KEY_OBFUSCATED)
    return bytes.fromhex(s)


# =========================================================================================== mã hoá/giải mã các bản ghi theo "lược đồ"
# Mỗi token: chữ + (độ dài byte nếu là chuỗi/bytes). b/B/h/H/i/I/q/Q/f/d = số nguyên/thực little-endian; W = chuỗi UTF-16LE; X = bytes thô.
_FMT = {"b": "<b", "B": "<B", "h": "<h", "H": "<H", "i": "<i", "I": "<I", "q": "<q", "Q": "<Q", "f": "<f", "d": "<d"}


def _schema(spec):
    out = []
    for tok in spec.split():
        c = tok[0]
        if c in _FMT:
            out.append((c, struct.calcsize(_FMT[c])))
        else:
            out.append((c, int(tok[1:])))
    return out


def schema_size(sch):
    return sum(n for _, n in sch)


def parse_at(buf, sch, off=0):
    need = schema_size(sch)
    if len(buf) - off < need:
        raise BridgeError("Bản ghi MT5 ngắn hơn dự kiến (cần %d byte, có %d)" % (need, len(buf) - off))
    vals = []
    for c, n in sch:
        if c in _FMT:
            vals.append(struct.unpack_from(_FMT[c], buf, off)[0])
        elif c == "W":
            raw = bytes(buf[off:off + n])
            vals.append(raw.decode("utf-16-le", "ignore").split("\x00", 1)[0])
        else:
            vals.append(bytes(buf[off:off + n]))
        off += n
    return vals


def pack_vals(sch, vals):
    out = []
    for (c, n), v in zip(sch, vals):
        if c in _FMT:
            out.append(struct.pack(_FMT[c], float(v) if c in "fd" else int(v)))
        elif c == "W":
            out.append(str(v or "").encode("utf-16-le")[:n].ljust(n, b"\x00"))
        else:
            out.append(bytes(v or b"")[:n].ljust(n, b"\x00"))
    return b"".join(out)


S_TICK = _schema("I i I d d d q I H")
S_SYMBOL = _schema("W64 W128 I I W256 I W64 H")
S_POSITION = _schema("q q I I W64 I d d d d Q d d d d d q q W64 d I I I W64 i i")
F_POSITION = ["position_id", "order", "time_create", "time_update", "symbol", "action", "price_open", "price_close", "sl", "tp", "volume", "profit", "rate_profit",
              "rate_margin", "commission", "swap", "expert", "expert_pos", "comment", "contract_size", "digits", "digits_cur", "reason", "external", "ms_c", "ms_u"]
S_ORDER = _schema("q W64 W64 I I I I I I I d d d d d q q I q q W64 d I I d d d I i i")
F_ORDER = ["order", "order_id", "symbol", "time_setup", "time_exp", "time_done", "type", "filling", "type_time", "reason", "price_order", "price_trigger",
           "price_current", "sl", "tp", "vol_init", "vol_cur", "state", "expert", "position_id", "comment", "contract_size", "digits", "digits_cur", "comm_daily",
           "comm_monthly", "margin_rate", "activation", "ms_s", "ms_d"]
S_DEAL = _schema("q W64 q I I W64 I I d d d d Q d d d d d q q W64 d I I I i i d")
F_DEAL = ["deal", "deal_id", "order", "time_create", "time_update", "symbol", "action", "entry", "price_open", "price_close", "sl", "tp", "volume", "profit",
          "rate_profit", "rate_margin", "commission", "swap", "expert", "position_id", "comment", "contract_size", "digits", "digits_cur", "reason", "ms_c", "ms_u", "fee"]
S_ACCOUNT = _schema("B i i d d W64 I I W256 H W128 W256 i b I I d d I d I d d d I I")
F_ACCOUNT = ["account_type", "rights", "perm", "balance", "credit", "currency", "cur_digits", "leverage", "name", "build", "server", "company", "tz_shift",
             "daylight", "margin_mode", "margin_free_mode", "so_call", "so_so", "so_mode", "margin_virtual", "free_profit_mode", "acc_profit", "comm_daily",
             "comm_monthly", "auth_pw_min", "otp_status"]
S_FULLSYM = _schema("W64 W32 W128 W128 W64 W64 W512 W128 W128 W16 H H W8 W32 W32 W32 I I I I I I d d I I I I I i i d d d I I d d d d I d d I i i X628 X896 X8")
F_FULLSYM = {"symbol": 0, "digits": 21, "point": 22, "symbol_id": 24, "tick_value": 31, "tick_size": 32, "contract_size": 33, "trade": 46}
S_TRADECFG = _schema("W256 i i I i i" + " I" * 10 + " Q I I I Q Q Q Q" + " I d d X64 X64 d d d I d d i I I X56")      # = đúng 628 byte của khối «trade» trong lệnh 18
F_TRADECFG = {n: i for i, n in enumerate(
    ["symbol_path", "spread_diff", "spread_diff_balance", "trade_mode", "trade_stops_level", "trade_freeze_level", "trade_exemode", "trade_fill_flags", "trade_time_flags",
     "trade_order_flags", "trade_request_flags", "trade_request_timeout", "trade_instant_flags", "trade_instant_timeout", "trade_instant_slip_profit",
     "trade_instant_slip_losing", "trade_instant_volume", "trade_instant_checkmode", "trade_market_flags", "trade_exchange_flags", "volume_min", "volume_max",
     "volume_step", "volume_limit", "margin_flags", "margin_initial", "margin_maintenance", "margin_rates_initial", "margin_rates_maintenance",
     "margin_rate_liquidity", "margin_hedged", "margin_rate_currency", "swap_mode", "swap_long", "swap_short", "swap_rollover3days", "permissions_flags",
     "permissions_bookdepth", "swap_rates"])}
S_RATE = _schema("i d d d d q i")
S_RATE_EXT = _schema("i d d d d q i q")
S_TRADE_REQ = _schema("I I W64 Q I Q I I I I I d d d d Q W64 Q Q I")
S_TRADE_RESP = _schema("I Q Q Q d d d W64 I")
S_LOGIN = _schema("I W64 W128 X16 W64 W64 Q W128 I W256 Q X160 Q")
S_LOGIN_RES = _schema("X160 Q")


def _rec(vals, names):
    return dict(zip(names, vals))


def parse_counted(body, sch, names, off=0):
    """[uint32 số lượng] + các bản ghi liên tiếp -> (list dict, offset sau cùng)."""
    if len(body) - off < 4:
        return [], off
    n = struct.unpack_from("<I", body, off)[0]
    size, off, out = schema_size(sch), off + 4, []
    for _ in range(n):
        if off + size > len(body):
            break
        out.append(_rec(parse_at(body, sch, off), names))
        off += size
    return out, off


# =========================================================================================== khung giao thức
def pack_outer(body):
    return struct.pack("<II", len(body), OUTER_VERSION) + body


def unpack_outer(frame):
    if len(frame) < 8:
        raise BridgeError("Khung MT5 quá ngắn")
    n, _ver = struct.unpack_from("<II", frame, 0)
    body = frame[8:]
    if n != len(body):
        raise BridgeError("Khung MT5 sai độ dài (header %d, thực %d)" % (n, len(body)))
    return body


def norm_price(value, digits, symbol=""):
    """Giá trong tick đôi khi là số nguyên ×10^digits - đưa về giá thật (cùng heuristic với pymt5)."""
    price = float(value or 0.0)
    if digits <= 0 or price == 0.0:
        return price
    scale = float(10 ** digits)
    base = str(symbol or "").upper()[:6]
    forex = len(base) == 6 and base.isalpha()
    thr = scale
    if digits >= 4 and forex and "JPY" not in base:
        thr = scale / 10.0
    if forex and digits >= 3:
        return price / scale if abs(price) >= thr else price
    r = round(price)
    if abs(price - r) > 1e-9 or abs(r) < thr:
        return price
    return float(r) / scale


class _Waiter:
    __slots__ = ("ev", "res", "err")

    def __init__(self):
        self.ev, self.res, self.err = threading.Event(), None, None


# =========================================================================================== kết nối
class Mt5WsConn:
    def __init__(self, uri, login, password, otp="", url="", timeout=20.0, server_offset=None):
        self.uri, self.login, self.password, self.otp, self.url = uri or DEFAULT_URI, login, password, otp or "", url or ""
        self.timeout = float(timeout)
        self.offset = None if server_offset in (None, "") else float(server_offset)      # giây: giờ máy chủ - UTC (None = chưa biết)
        self.offset_fixed = self.offset is not None
        self._ws = None
        self._cipher = AesCbc(initial_key())
        self._lock = threading.RLock()           # gửi + (kết nối lại)
        self._pending = {}
        self._pl = threading.Lock()
        self.up = False
        self._gen = 0
        self.sym_by_id, self.sym_by_name = {}, {}
        self.sub_ids = set()
        self.ticks = {}                          # symbol_id -> [bid, ask, tick_epoch_utc_or_None, recv_monotonic, recv_wall]
        self.last_error = ""

    # ---- khung ----
    def _send_raw(self, cmd, payload):
        inner = os.urandom(2) + struct.pack("<H", cmd) + (payload or b"")
        self._ws.send_binary(pack_outer(self._cipher.encrypt(inner)))

    def _decode(self, msg):
        raw = self._cipher.decrypt(unpack_outer(bytes(msg)))
        if len(raw) < 5:
            raise BridgeError("Khung trả lời MT5 quá ngắn")
        return struct.unpack_from("<H", raw, 2)[0], raw[4], raw[5:]

    def _sync_rpc(self, cmd, payload, timeout):
        self._send_raw(cmd, payload)
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            msg = self._ws.recv(timeout=max(0.05, end - time.monotonic()))
            if msg is None:
                continue
            if isinstance(msg, str):
                continue
            c, code, body = self._decode(msg)
            if c == cmd:
                return code, body
        raise BridgeError("MT5 không trả lời lệnh %d trong %.0fs" % (cmd, timeout))

    # ---- kết nối / đăng nhập ----
    def ensure(self):
        with self._lock:
            if self.up and self._ws is not None and not self._ws.closed:
                return
            self._connect()

    def _connect(self):
        self._teardown("kết nối lại")
        bad = problems({"mt5ws_login": self.login, "mt5ws_password": self.password, "mt5ws_uri": self.uri, "mt5ws_otp": self.otp}, require=True)
        if bad:
            raise BridgeError("Cài đặt MT5 chưa đúng:\n- " + "\n- ".join(bad))
        ws = WebSocketClient(self.uri, headers={"Origin": ORIGIN}, timeout=self.timeout)
        ws.binary = True
        try:
            ws.connect()
        except WsError as e:
            raise BridgeError("Không kết nối được MT5 Web Terminal.\n" + explain_connect_error(e, self.uri))
        self._ws = ws
        self._cipher = AesCbc(initial_key())
        try:
            code, body = self._sync_rpc(CMD_BOOTSTRAP, bytes(64), self.timeout)
            if code != 0 or len(body) < 66:
                raise BridgeError("MT5 từ chối bắt tay (mã %s, %d byte). Máy chủ ở «%s» có thể không phải web terminal MT5, hoặc giao thức đã đổi. Nguyên văn: %s"
                                  % (code, len(body), self.uri, raw_text(body) or "(không có chữ)"))
            self.server_build = struct.unpack_from("<H", body, 0)[0]
            self._cipher = AesCbc(body[66:])
            cid = hashlib.sha1((";".join(["python", "1", "en-US", "0x0", str(int.from_bytes(os.urandom(3), "big"))])).encode()).digest()[:16]
            pw = str(self.password)
            blob = bytes.fromhex(pw) if len(pw) == 320 else None           # mật khẩu dạng token 160 byte (hex) - giữ đúng như pymt5
            payload = pack_vals(S_LOGIN, [0, "" if blob else pw[:32], self.otp[:64], cid, "", "", 0, "", min(len(self.url), 128), self.url[:128],
                                          int(self.login), blob or bytes(160), 0])
            code, body = self._sync_rpc(CMD_LOGIN, payload, self.timeout)
            if code != 0:
                raise BridgeError("Đăng nhập MT5 thất bại (mã %s của máy chủ, giao thức không công bố ý nghĩa).\nKiểm tra: (1) số tài khoản %s và mật khẩu GIAO DỊCH đúng; "
                                  "(2) địa chỉ máy chủ (mt5ws_uri = %s) đúng là web terminal của broker chứa tài khoản này; (3) nếu bật xác thực 2 lớp thì nhập mã OTP "
                                  "(mt5ws_otp); (4) thử đăng nhập cùng thông tin ở web terminal của broker để loại trừ sai thông tin.\nNguyên văn từ máy chủ: %s"
                                  % (code, self.login, self.uri, raw_text(body) or "(không có)"), code=str(code))
        except (WsClosed, WsError) as e:
            self._teardown(str(e))
            raise BridgeError("Mất kết nối khi đăng nhập MT5: %s" % e)
        except BridgeError:
            self._teardown("đăng nhập lỗi")
            raise
        self._gen += 1
        self.up = True
        threading.Thread(target=self._reader, args=(ws, self._gen), daemon=True, name="mt5ws-reader").start()
        threading.Thread(target=self._beat, args=(ws, self._gen), daemon=True, name="mt5ws-beat").start()
        if self.sub_ids:
            try:
                self._subscribe(sorted(self.sub_ids))
            except BridgeError:
                pass

    def _teardown(self, why=""):
        ws, self._ws, self.up = self._ws, None, False
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass
        self._fail_all(BridgeError("Mất kết nối MT5 (%s)" % (why or "đóng")))

    def _fail_all(self, err):
        with self._pl:
            ws = list(self._pending.values())
            self._pending = {}
        for q in ws:
            for w in q:
                w.err = err
                w.ev.set()

    def _reader(self, ws, gen):
        why = "đóng"
        try:
            while self._gen == gen and not ws.closed:
                msg = ws.recv(timeout=1.0)
                if msg is None or isinstance(msg, str):
                    continue
                try:
                    cmd, code, body = self._decode(msg)
                except BridgeError as e:
                    self.last_error = str(e)
                    continue
                self._dispatch(cmd, code, body)
        except WsClosed as e:
            why = str(e)
        except Exception as e:             # noqa: BLE001 - luồng đọc không được chết lặng lẽ
            why = "lỗi: %s" % e
        if self._gen == gen:
            self.up = False
            self._fail_all(BridgeError("Mất kết nối MT5 (%s)" % why))

    def _beat(self, ws, gen):
        while self._gen == gen and not ws.closed:
            for _ in range(int(HEARTBEAT_EVERY * 4)):
                if self._gen != gen or ws.closed:
                    return
                time.sleep(0.25)
            try:
                with self._lock:
                    if self._gen == gen and self._ws is ws:
                        self._send_raw(CMD_PING, b"")
            except Exception:
                return

    def _dispatch(self, cmd, code, body):
        if cmd == CMD_TICK_PUSH:
            self._on_ticks(body, push=True)
            return
        with self._pl:
            q = self._pending.get(cmd)
            w = q.popleft() if q else None
        if cmd == CMD_SUBSCRIBE and code == 0 and body:
            self._on_ticks(body, push=False)
        if w is not None:
            w.res = (code, body)
            w.ev.set()

    # ---- giá ----
    def _on_ticks(self, body, push):
        size = schema_size(S_TICK)
        off = 4 if len(body) % size == 4 else 0                      # chịu được cả khi có tiền tố đếm 4 byte
        now_m, now_w = time.monotonic(), time.time()
        while off + size <= len(body):
            sid, tt, _fields, bid, ask, last, _vol, dms, _fl = parse_at(body, S_TICK, off)
            off += size
            info = self.sym_by_id.get(sid)
            digits, name = (info["digits"], info["name"]) if info else (0, "")
            bid, ask = norm_price(bid, digits, name), norm_price(ask, digits, name)
            prev = self.ticks.get(sid)
            if prev:                                                   # tick đẩy theo kiểu một phần: 0 = không đổi
                bid, ask = bid or prev[0], ask or prev[1]
            if not (bid and ask):
                if bid or ask:
                    self.ticks[sid] = [bid or (prev[0] if prev else 0.0), ask or (prev[1] if prev else 0.0), None, now_m, now_w]
                continue
            if push and self.offset is None and tt > 0:
                diff = tt - now_w
                cand = round(diff / 900.0) * 900.0
                if abs(cand) <= 14 * 3600 and abs(diff - cand) < 120:     # giá tươi: lệch giờ = bội 15 phút gần nhất
                    self.offset = cand
            epoch = (tt + dms / 1000.0 - self.offset) if (self.offset is not None and tt > 0) else None
            self.ticks[sid] = [bid, ask, epoch, now_m, now_w]

    def _subscribe(self, ids):
        payload = struct.pack("<%dI" % (len(ids) + 1), len(ids), *ids)
        self.call(CMD_SUBSCRIBE, payload, retry=False, ensure=False)

    # ---- gọi lệnh ----
    def call(self, cmd, payload=b"", timeout=None, retry=True, allow_code=False, ensure=True, on_send=None):
        timeout = self.timeout if timeout is None else timeout
        for attempt in (0, 1):
            if ensure:
                self.ensure()
            w = _Waiter()
            try:
                with self._lock:
                    if self._ws is None:
                        raise BridgeError("Chưa kết nối MT5")
                    with self._pl:
                        self._pending.setdefault(cmd, deque()).append(w)
                    if on_send:
                        on_send()                       # chạy NGAY trước khi byte đầu tiên rời máy, dưới khoá gửi -> thứ tự gửi chính xác
                    self._send_raw(cmd, payload)
            except (WsError, WsClosed, OSError) as e:
                self._pop(cmd, w)
                self._teardown(str(e))
                if retry and attempt == 0:
                    continue
                raise BridgeError("Gửi lệnh %d tới MT5 lỗi: %s" % (cmd, e))
            if not w.ev.wait(timeout):
                self._pop(cmd, w)
                raise BridgeError("MT5 không trả lời lệnh %d trong %.0fs" % (cmd, timeout))
            if w.err is not None:
                if retry and attempt == 0:
                    continue
                raise w.err
            code, body = w.res
            if code != 0 and not allow_code:
                raise BridgeError("MT5 báo lỗi cho lệnh %d (mã %d, giao thức không công bố ý nghĩa). Nguyên văn từ sàn: %s" % (cmd, code, raw_text(body) or "(không có)"),
                                  code=str(code))
            return code, body
        raise BridgeError("Không gọi được lệnh %d" % cmd)

    def _pop(self, cmd, w):
        with self._pl:
            q = self._pending.get(cmd)
            if q and w in q:
                q.remove(w)

    def close(self):
        with self._lock:
            self._gen += 1
            try:
                if self._ws is not None and self.up:
                    self._send_raw(2, b"")
            except Exception:
                pass
            self._teardown("đóng")


# =========================================================================================== backend
def _num(x, d=0.0):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return d
    return v if v == v else d


class _Unsure(BridgeError):
    """Kết quả gửi lệnh chưa chắc chắn (khác với bị sàn từ chối rõ ràng)."""

    def __init__(self, msg, code=""):
        BridgeError.__init__(self, msg, code=code)


def _sessions(blob):
    """Khối lịch phiên (896 byte) -> [phiên_báo_giá, phiên_giao_dịch], mỗi cái 7 ngày × tối đa 16 cặp (phút bắt đầu, phút kết thúc) trong ngày giờ máy chủ.
    Bố cục theo pymt5 (`<HH` × 16 × 7 ngày, báo giá rồi giao dịch). Ngày 0 = Chủ nhật theo kiểu MT5 - CHƯA XÁC MINH với sàn thật."""
    out, off, blob = [], 0, bytes(blob or b"")
    for _ in range(2):
        days = []
        for _d in range(7):
            ds = []
            for _i in range(16):
                if off + 4 > len(blob):
                    break
                a, b = struct.unpack_from("<HH", blob, off)
                off += 4
                if b > a:
                    ds.append((a, b))
            days.append(ds)
        out.append(days)
    return out


class Mt5WsBackend(MtBackend):
    name = "mt5ws"
    max_chunk = 1000
    native_tfs = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w", "1mo"]      # khung có sẵn trên cổng web (PERIOD_CODE); khung khác được ghép
    native_kinds = {"limit", "stop", "stop_limit"}               # stop-limit để vỏ tự theo dõi (chưa xác minh ngữ nghĩa price_order/price_trigger trên sàn thật)
    limiter_kind = "generic"
    can_modify_position = True
    OP_WAIT = 12.0

    def __init__(self, conn, volume_scale=1e8, deviation=20, filling="auto", use_magic=False, precheck=True):
        self.c = conn
        self.precheck = bool(precheck)               # kiểm tra luật mã (trade_mode/stops/freeze) TRƯỚC khi gửi; tắt nếu máy chủ trả bảng sai
        self.use_magic = bool(use_magic)             # gửi thêm magic (type_reason) làm nhãn số thứ hai - CHƯA XÁC MINH sàn có nhận, mặc định tắt
        self.tags_ok = None                          # None = chưa biết sàn có GIỮ nhãn comment; True/False = đã quan sát
        self._claimed = deque(maxlen=1000)           # ticket đã gán cho một lệnh (để không gán trùng cho lệnh giống hệt khác)
        self._inflight = {}                          # nonce -> (khoá lệnh, thứ tự gửi) của các lệnh đang chờ kết quả
        self._ilock = threading.Lock()
        self._seq = 0
        self.scale = float(volume_scale) or 1e8
        self.deviation = int(deviation)
        self.filling = str(filling or "auto").lower()
        self._spec = {}
        self._lock = threading.RLock()

    # ---- mã ----
    def _load_symbols(self):
        if not self.c.sym_by_name:
            body = b""
            try:
                _, raw = self.c.call(CMD_SYMBOLS_GZ)
                if len(raw) > 4:
                    body = zlib.decompress(raw[4:])
            except (BridgeError, zlib.error):
                body = b""
            if not body:
                _, body = self.c.call(CMD_SYMBOLS)
            recs, _ = parse_counted(body, S_SYMBOL, ["name", "desc", "digits", "id", "path", "calc", "basis", "sector"])
            by_name, by_id = {}, {}
            for r in recs:
                if r["name"]:
                    by_name[r["name"]] = r
                    by_id[r["id"]] = r
            self.c.sym_by_name, self.c.sym_by_id = by_name, by_id
        return self.c.sym_by_name

    def symbols(self):
        return sorted(self._load_symbols())

    def _sym(self, symbol):
        m = self._load_symbols()
        if symbol in m:
            return m[symbol]
        key = str(symbol).upper().replace("/", "")
        for k, v in m.items():
            if k.upper().replace("/", "") == key:
                return v
        raise BridgeError("MT5 không có mã %s" % symbol)

    # ---- khối lượng ----
    def _raw_vol(self, lots):
        return int(round(float(lots) * self.scale))

    def _lots(self, raw):
        return float(raw) / self.scale

    def spec(self, symbol):
        s = self._sym(symbol)
        if s["name"] in self._spec:
            return dict(self._spec[s["name"]])
        _, body = self.c.call(CMD_FULL_SYMBOL, pack_vals(_schema("W64"), [s["name"][:32]]))
        size = schema_size(S_FULLSYM)
        off = 4 if len(body) >= 4 + size and struct.unpack_from("<I", body, 0)[0] == 1 else 0
        if len(body) - off < size:
            raise BridgeError("MT5 trả đặc tả mã %s sai bố cục (%d byte, cần %d)" % (s["name"], len(body), size))
        v = parse_at(body, S_FULLSYM, off)
        cfg = parse_at(v[F_FULLSYM["trade"]], S_TRADECFG)
        vmin, vmax, vstep = cfg[20], cfg[21], cfg[22]
        if vstep <= 0 or not (1e-6 <= vstep / self.scale <= 1000):
            raise BridgeError("Thang khối lượng MT5 có vẻ sai: bước khối lượng thô = %d, chia %.0f = %.3g lot. Chỉnh mt5ws_volume_scale cho khớp máy chủ" %
                              (vstep, self.scale, vstep / self.scale))
        out = {"volume_min": self._lots(vmin), "volume_max": self._lots(vmax) or 1e9, "volume_step": self._lots(vstep), "digits": int(v[F_FULLSYM["digits"]]),
               "contract_size": float(v[F_FULLSYM["contract_size"]]), "tick_size": float(v[F_FULLSYM["tick_size"]]), "fill_flags": int(cfg[7]),
               "stops_level": int(cfg[4]), "trade_mode": int(cfg[3]), "freeze_level": int(cfg[5]), "point": float(v[F_FULLSYM["point"]]) or 10.0 ** -int(v[F_FULLSYM["digits"]]),
               "calc_mode": int(v[35]), "tick_value": float(v[31]), "ccy_base": str(v[13] or ""), "ccy_profit": str(v[14] or ""), "ccy_margin": str(v[15] or ""),
               "margin_initial": float(cfg[F_TRADECFG["margin_initial"]]), "swap_long": float(cfg[F_TRADECFG["swap_long"]]), "swap_short": float(cfg[F_TRADECFG["swap_short"]]),
               "swap_mode": int(cfg[F_TRADECFG["swap_mode"]]), "trade_sessions": _sessions(v[47])[1]}
        self._spec[s["name"]] = out
        return dict(out)

    def _fill(self, symbol, market=True):
        f = self.filling
        if f in ("fok", "ioc", "return"):
            return {"fok": FILL_FOK, "ioc": FILL_IOC, "return": FILL_RETURN}[f]
        if not market:
            return FILL_RETURN
        try:
            flags = self.spec(symbol)["fill_flags"]
        except BridgeError:
            return FILL_IOC
        return FILL_IOC if flags & 2 else FILL_FOK if flags & 1 else FILL_RETURN        # CHƯA XÁC MINH: bit 1=FOK, 2=IOC theo SYMBOL_FILLING_*

    # ---- giá / nến ----
    def tick(self, symbol):
        s = self._sym(symbol)
        sid = s["id"]
        if sid not in self.c.sub_ids:
            self.c.sub_ids.add(sid)
            self.c._subscribe(sorted(self.c.sub_ids))
        end = time.monotonic() + 5.0
        while time.monotonic() < end:
            t = self.c.ticks.get(sid)
            if t and t[0] > 0 and t[1] > 0:
                return t[0], t[1], (t[2] if t[2] else t[4])
            time.sleep(0.05)
        raise BridgeError("Chưa có giá %s từ MT5 (thị trường đóng cửa?)" % symbol)

    OFFSET_WAIT = 4.0

    # ---- giờ giao dịch & luật mã (đọc từ đặc tả sàn) ----
    def market_open(self, symbol):
        """True/False theo lịch phiên giao dịch của mã; None = không biết (lịch trống/chưa có giờ máy chủ) -> bên gọi dùng suy đoán theo độ tươi của giá."""
        try:
            sess = self.spec(symbol).get("trade_sessions")
        except BridgeError:
            return None
        if not sess or not any(sess) or self.c.offset is None:
            return None
        t = time.gmtime(time.time() + self.c.offset)
        day, minute = (t.tm_wday + 1) % 7, t.tm_hour * 60 + t.tm_min          # MT5: 0 = Chủ nhật
        return any(a <= minute < b for a, b in sess[day])

    @staticmethod
    def _spec_sane(sp):
        return (sp.get("trade_mode") in (0, 1, 2, 3, 4) and 0 <= sp.get("stops_level", 0) <= 100000 and 0 <= sp.get("freeze_level", 0) <= 100000
                and sp.get("point", 0) > 0)

    def _spec_for_check(self, symbol):
        if not self.precheck:
            return None
        try:
            sp = self.spec(symbol)
        except BridgeError:
            return None
        return sp if self._spec_sane(sp) else None           # đặc tả đọc ra vô lý -> không chặn gì (để sàn quyết định)

    def _pre_open(self, symbol, side):
        sp = self._spec_for_check(symbol)
        if sp is None:
            return None
        tm = sp["trade_mode"]
        why = {0: "đang bị CẤM giao dịch", 3: "chỉ cho ĐÓNG lệnh (close-only), không mở mới"}.get(tm)
        if tm == 1 and side == "sell":
            why = "chỉ cho MUA (long-only)"
        if tm == 2 and side == "buy":
            why = "chỉ cho BÁN (short-only)"
        if why:
            raise BridgeError("MT5: mã %s %s (chế độ giao dịch=%d đọc từ sàn). Lệnh KHÔNG được gửi. Tắt kiểm tra này bằng mt5ws_precheck=off nếu thấy sàn báo sai." % (symbol, why, tm))
        return sp

    def _pre_distance(self, sp, symbol, what, ref, value):
        dist = sp["stops_level"] * sp["point"]
        if value and dist > 0 and abs(ref - value) < dist - 1e-12:
            raise BridgeError("MT5: %s %s quá gần giá hiện tại: cách %.10g, sàn yêu cầu tối thiểu %.10g (stops level %d điểm). Lệnh KHÔNG được gửi; đặt xa hơn."
                              % (what, symbol, abs(ref - value), dist, sp["stops_level"]))

    # ---- ước tính ký quỹ (lệnh tài khoản không báo) ----
    def _fx_rate(self, cur_from, cur_to, hint):
        """Tỷ giá cur_from -> cur_to từ giá đang có của chính cầu nối; None nếu không có cặp trực tiếp."""
        if not cur_from or not cur_to or cur_from == cur_to:
            return 1.0
        suffix = hint[6:] if len(hint) > 6 and hint[:6].isalpha() else ""
        have = set(self.symbols())
        for name, inv in ((cur_from + cur_to + suffix, False), (cur_from + cur_to, False), (cur_to + cur_from + suffix, True), (cur_to + cur_from, True)):
            if name in have:
                try:
                    bid, ask, _ = self.tick(name)
                except BridgeError:
                    return None
                px = (1.0 / ask) if inv else bid
                return px if px > 0 else None
        return None

    def estimate_margin(self, positions, leverage, acct_ccy):
        """Ký quỹ ƯỚC TÍNH theo công thức của pymt5 (forex/CFD/futures; chưa gồm lệnh chờ, bù trừ hedge, bậc đòn bẩy). None nếu có vị thế không tính được."""
        total = 0.0
        for p in positions:
            sp = self.spec(p["symbol"])
            lots, price, mode = self._lots(p["volume"]), float(p["price_open"]), sp["calc_mode"]
            units = lots * sp["contract_size"]
            if mode in (0, 5):
                raw = units / leverage if (mode == 0 and leverage > 0) else (units if mode == 5 else None)
            elif mode == 4:
                raw = units / leverage * price if leverage > 0 else None
            elif mode == 2:
                raw = units * price
            elif mode == 1 and sp["margin_initial"] > 0:
                raw = lots * sp["margin_initial"]
            else:
                return None
            rate = self._fx_rate(sp["ccy_margin"], acct_ccy, p["symbol"]) if raw is not None else None
            if raw is None or rate is None:
                return None
            total += raw * rate
        return total

    def _off(self):
        """Giờ máy chủ - UTC (giây). Chưa biết -> đăng ký giá vài mã rồi chờ một tick ĐẨY (tươi) để dò; vẫn không ra (thị trường đóng) thì dùng 0
        và thử lại sau 60s. Với thị trường đóng cửa, đặt mt5ws_server_offset_hours để giờ vị thế/lịch sử không lệch."""
        c = self.c
        if c.offset is None and time.monotonic() - getattr(self, "_off_try", -1e9) > 60.0:
            self._off_try = time.monotonic()
            try:
                names = self.symbols()[:3]
                ids = {self._sym(n)["id"] for n in names} | set(c.sub_ids)
                if ids - c.sub_ids:
                    c.sub_ids |= ids
                    c._subscribe(sorted(c.sub_ids))
                end = time.monotonic() + self.OFFSET_WAIT
                while c.offset is None and time.monotonic() < end:
                    time.sleep(0.05)
            except BridgeError:
                pass
        return c.offset or 0.0

    def candles(self, symbol, tf, count, end=None):
        step = TIMEFRAMES.get(tf)
        mins = step // 60 if step else 0
        if mins not in PERIOD_CODE:
            raise BridgeError("MT5 Web Terminal không có khung %s (chỉ M1 M5 M15 M30 H1 H4 D1 W1 MN1)" % tf)
        s = self._sym(symbol)
        want, off = int(count), self._off()
        to_utc = float(end) - 1 if end is not None else time.time() + 120
        got, empty = {}, 0
        for _ in range(40):
            if len(got) >= want:
                break
            span = max(want - len(got), 50) * step * 1.6 + 7 * 86400
            frm_utc = to_utc - span
            payload = pack_vals(_schema("W64 H i i"), [s["name"][:32], PERIOD_CODE[mins], int(frm_utc + off), int(to_utc + off)])
            _, body = self.c.call(CMD_RATES, payload)
            std, ext = schema_size(S_RATE), schema_size(S_RATE_EXT)
            sch, size = (S_RATE_EXT, ext) if (len(body) % std and len(body) % ext == 0) else (S_RATE, std)
            n = len(body) // size
            new = 0
            for i in range(n):
                t, o, h, lo, c, v, _sp = parse_at(body, sch, i * size)[:7]
                tu = float(t) - off
                if tu not in got and (end is None or tu < end):
                    got[tu] = Candle(tu, o, h, lo, c, float(v))
                    new += 1
            empty = empty + 1 if new == 0 else 0
            if empty >= 2 or frm_utc < 946684800:
                break
            to_utc = frm_utc - 1
        return sorted(got.values(), key=lambda c: c.time)[-want:]

    # ---- tài khoản ----
    def _raw_pos_orders(self):
        _, body = self.c.call(CMD_POS_ORDERS)
        pos, off = parse_counted(body, S_POSITION, F_POSITION)
        orders, _ = parse_counted(body, S_ORDER, F_ORDER, off)
        return pos, orders

    def account(self):
        _, body = self.c.call(CMD_ACCOUNT)
        if len(body) < schema_size(S_ACCOUNT):
            raise BridgeError("MT5 trả thông tin tài khoản sai bố cục (%d byte)" % len(body))
        a = _rec(parse_at(body, S_ACCOUNT), F_ACCOUNT)
        pos, ords = self._raw_pos_orders()
        floating = sum(p["profit"] + p["swap"] for p in pos)
        bal, cr = a["balance"], a["credit"]
        mg = None
        try:
            mg = None if ords else self.estimate_margin(pos, float(a["leverage"] or 0), a["currency"] or "")   # có lệnh chờ -> sàn giữ thêm ký quỹ mà app không tính được; lệnh 3 không báo ký quỹ: chỉ ước tính khi tính được trọn vẹn, không thì None
        except (BridgeError, KeyError, ZeroDivisionError):
            mg = None
        return {"balance": bal, "equity": bal + cr + floating, "margin": mg, "free_margin": None, "margin_level": None, "margin_estimated": mg is not None,
                "profit": floating, "credit": cr, "leverage": float(a["leverage"] or 1), "currency": a["currency"] or "", "hedging": a["margin_mode"] == 2,
                "platform": "MT5", "demo": a["account_type"] == 1, "server": a["server"], "company": a["company"], "name": a["name"],
                "trade_allowed": not bool(a["rights"] & 4) and not bool(a["rights"] & 8) and not bool(a["rights"] & 512)}

    def positions(self):
        pos, _ = self._raw_pos_orders()
        off = self._off()
        return [{"id": str(p["position_id"]), "symbol": p["symbol"], "side": "sell" if p["action"] == 1 else "buy", "volume": self._lots(p["volume"]),
                 "price": p["price_open"], "sl": p["sl"], "tp": p["tp"], "time": p["time_create"] - off, "comment": p["comment"], "profit": p["profit"],
                 "swap": p["swap"], "commission": p["commission"], "magic": p["expert"], "origin": ordertag.classify(p["comment"], p["expert"], p["reason"]),
                 "reason_code": p["reason"]} for p in pos]

    _KIND = {OT_BUY_LIMIT: ("buy", "limit"), OT_SELL_LIMIT: ("sell", "limit"), OT_BUY_STOP: ("buy", "stop"), OT_SELL_STOP: ("sell", "stop"),
             6: ("buy", "stop_limit"), 7: ("sell", "stop_limit")}

    def orders(self):
        _, raw = self._raw_pos_orders()
        out = []
        for o in raw:
            if o["type"] not in self._KIND:
                continue
            side, kind = self._KIND[o["type"]]
            price = o["price_order"]                                    # stop-limit: price = giá limit, stop_price = giá kích hoạt (cùng quy ước vỏ app)
            out.append({"stop_price": o["price_trigger"] if kind == "stop_limit" else None, "id": str(o["order"]), "symbol": o["symbol"], "side": side, "kind": kind, "volume": self._lots(o["vol_cur"] or o["vol_init"]),
                        "price": price, "sl": o["sl"], "tp": o["tp"], "type_code": o["type"], "comment": o["comment"], "magic": o["expert"],
                        "origin": ordertag.classify(o["comment"], o["expert"])})
        return out

    # ---- giao dịch ----
    VERIFY_TRIES = 4
    VERIFY_GAP = 1.5

    def _trade(self, on_send=None, **kw):
        """Gửi MỘT yêu cầu giao dịch, KHÔNG tự gửi lại. Kết quả không chắc (mất kết nối/hết giờ/thân rỗng/mã lỗi lạ hoặc 10011-10012-10031)
        -> ném `_Unsure`; lớp ngoài (`_run`) tự đọc lại sàn để xác minh lệnh đã vào hay chưa."""
        a = dict(action_id=0, action=0, symbol="", volume=0, digits=0, order=0, type=0, filling=0, ttype=0, tflags=0, reason=0, price=0.0, trigger=0.0,
                 sl=0.0, tp=0.0, deviation=0, comment="", position=0, by=0, expiry=0)
        a.update(kw)
        payload = pack_vals(S_TRADE_REQ, [a["action_id"], a["action"], a["symbol"][:32], a["volume"], a["digits"], a["order"], a["type"], a["filling"], a["ttype"],
                                          a["tflags"], a["reason"], a["price"], a["trigger"], a["sl"], a["tp"], a["deviation"], a["comment"][:31], a["position"],
                                          a["by"], a["expiry"]])
        self.c.ensure()                                 # không nối được = lệnh CHƯA được gửi (lỗi chắc chắn, không cần xác minh)
        try:
            code, body = self.c.call(CMD_TRADE, payload, timeout=self.OP_WAIT, retry=False, allow_code=True, ensure=False, on_send=on_send)
        except BridgeError as e:
            raise _Unsure("Mất liên lạc với MT5 khi gửi lệnh (%s)" % e)
        if not body:
            raise _Unsure("MT5 trả lời lệnh giao dịch rỗng (mã khung %d)" % code)
        ret = struct.unpack_from("<I", body, 0)[0]
        res = {"retcode": ret, "frame_code": code}
        if len(body) >= schema_size(S_TRADE_RESP):
            v = parse_at(body, S_TRADE_RESP)
            res.update(deal=v[1], order=v[2], volume=v[3], price=v[4], bid=v[5], ask=v[6], comment=v[7])
        if ret in RET_OK:
            return res
        text = res.get("comment") or raw_text(body)
        quote = (" Nguyên văn từ sàn: «%s»." % text) if text else ""
        meaning, fix = RET_INFO.get(ret, (None, None))
        if meaning is None:
            raise _Unsure("MT5 trả mã %d - mã này chưa có trong bảng của app.%s" % (ret, quote), code=str(ret))
        if ret in RET_UNSURE:
            raise _Unsure("MT5 báo «%s» (mã %d): chưa rõ lệnh đã vào hay chưa.%s" % (meaning, ret, quote), code=str(ret))
        raise BridgeError("MT5 từ chối lệnh: %s (mã %d). %s%s" % (meaning, ret, fix or "", quote), code=str(ret))

    def _run(self, send, verify, what):
        """Chạy `send`; nếu kết quả KHÔNG CHẮC thì đọc lại trạng thái sàn bằng `verify()` (trả kết quả nếu lệnh đã có hiệu lực, None nếu chưa).
        Không bao giờ gửi lại yêu cầu. Hết số lần mà vẫn không thấy -> báo rõ KHÔNG vào (nếu đọc được sàn) hoặc KHÔNG XÁC ĐỊNH (nếu không đọc được)."""
        try:
            return send()
        except _Unsure as u:
            why, code = str(u), u.code
        readable, last = 0, None
        for _ in range(self.VERIFY_TRIES):
            time.sleep(self.VERIFY_GAP)
            try:
                out = verify()
            except BridgeError as e:
                last = e
                continue
            readable += 1
            if out is not None:
                return out
        if readable:
            raise BridgeError("%s.\nĐã đọc lại sàn %d lần trong ~%.0fs: %s KHÔNG thấy có hiệu lực - coi như chưa thực hiện (nếu sau đó vẫn xuất hiện, "
                              "app sẽ đồng bộ ở lần đọc kế tiếp)." % (why, readable, self.VERIFY_TRIES * self.VERIFY_GAP, what), code=code)
        raise BridgeError("%s.\nKHÔNG đọc lại được sàn để xác minh (%s). Chưa biết %s đã thực hiện chưa - hãy mở danh sách vị thế/lệnh để kiểm tra bằng mắt "
                          "trước khi thử lại." % (why, last, what), code=code)

    # ---- NHÃN DUY NHẤT cho từng lệnh (giải quyết "hai lệnh giống hệt nhau") ----
    # Mỗi lệnh mở/lệnh chờ gửi đi mang comment «<nhãn chủ>~<8 hex ngẫu nhiên>» (chủ = 'pyea', vẫn bắt đầu bằng OWN_TAG của vỏ) và tuỳ chọn magic = 32 bit
    # đó. Khi mất phản hồi, app tìm lại ĐÚNG lệnh theo nhãn chứ không đoán theo (mã, chiều, khối lượng). Sàn có giữ nhãn hay không được QUAN SÁT lúc chạy
    # (`tags_ok`) - nếu đã thấy sàn giữ nhãn thì "không có nhãn đó" nghĩa là lệnh chưa vào (kết luận chắc chắn).
    def _new_tag(self, base):
        magic = (int.from_bytes(os.urandom(4), "big") | 1) & 0xFFFFFFFF
        nonce = "%08x" % magic
        return nonce, magic, "%s~%s" % ((base or "pyea")[:22], nonce), None

    def _mark_sent(self, nonce, key):
        """Gọi đúng lúc lệnh được gửi đi: ghi thứ tự gửi thật (ticket tăng theo thứ tự tới máy chủ)."""
        def mark():
            with self._ilock:
                self._seq += 1
                self._inflight[nonce] = (key, self._seq)
        return mark

    def _remember(self, *ids):
        for i in ids:
            if i not in ("", "0", 0, None):
                self._claimed.append(str(i))

    def _is_claimed(self, i):
        return str(i) in self._claimed

    @staticmethod
    def _has_tag(rec, nonce, magic):
        return nonce in str(rec.get("comment") or "") or bool(magic and rec.get("expert") == magic)

    def _choose(self, cands, nonce, magic, key, idof, what):
        """Chọn ĐÚNG bản ghi của lệnh này trong số `cands` (vị thế/lệnh mới khớp mã-chiều-khối lượng). Trả bản ghi, hoặc None nếu chắc chắn chưa vào;
        ném BridgeError nếu thật sự không phân biệt được."""
        cands = [c for c in cands if not self._is_claimed(idof(c))]
        tagged = [c for c in cands if self._has_tag(c, nonce, magic)]
        if len(tagged) == 1:
            return tagged[0]
        if len(tagged) > 1:
            raise BridgeError("thấy %d %s cùng nhãn - bất thường" % (len(tagged), what))
        if self.tags_ok is True:
            return None                                  # sàn đã được thấy là giữ nhãn mà không có nhãn này => lệnh chưa vào
        if not cands:
            return None
        with self._ilock:
            same = sorted((v[1], n) for n, v in self._inflight.items() if v[0] == key and v[1] is not None)
        order = [n for _, n in same]
        if len(order) <= 1:
            if len(cands) == 1:
                return cands[0]
            raise BridgeError("thấy %d %s mới giống hệt và sàn không giữ nhãn để phân biệt" % (len(cands), what))
        if len(cands) == len(order) and nonce in order:      # ticket tăng theo thứ tự tới máy chủ; gửi tuần tự trên một kết nối nên = thứ tự gửi
            return sorted(cands, key=idof)[order.index(nonce)]
        raise BridgeError("có %d lệnh giống hệt đang chờ xác minh nhưng chỉ thấy %d %s mới - không gán được" % (len(order), len(cands), what))

    def _own_position(self, order_ticket, nonce=None):
        try:
            for p in self._raw_pos_orders()[0]:
                if p["position_id"] == order_ticket or p["order"] == order_ticket:
                    if nonce:
                        ok = nonce in str(p.get("comment") or "")
                        self.tags_ok = ok if self.tags_ok in (None, True) else False     # chỉ cần một lần sàn làm mất nhãn là không tin nhãn nữa
                    return str(p["position_id"])
        except BridgeError:
            pass
        return str(order_ticket)                     # tài khoản hedging: id vị thế = ticket lệnh mở

    def _snap(self):
        pos, orders = self._raw_pos_orders()
        return {p["position_id"] for p in pos}, {o["order"] for o in orders}

    def market(self, symbol, side, volume, comment=""):
        self._pre_open(symbol, side)
        s = self._sym(symbol)
        raw = self._raw_vol(volume)
        otype = OT_BUY if side == "buy" else OT_SELL
        nonce, magic, tagged_comment, seq = self._new_tag(comment)
        key = ("m", s["name"], otype, raw)
        try:
            before = self._snap()
        except BridgeError:
            before = None
        t0 = time.time()
        with self._ilock:
            self._inflight[nonce] = (key, None)

        def send():
            r = self._trade(on_send=self._mark_sent(nonce, key), action=ACT_DEAL, symbol=s["name"], volume=raw, digits=s["digits"], type=otype,
                            filling=self._fill(s["name"]), deviation=self.deviation, comment=tagged_comment, reason=magic if self.use_magic else 0)
            o = int(r.get("order") or 0)
            pid = self._own_position(o, nonce) if o else ""
            self._remember(pid, o)
            return {"order_id": str(o), "position_id": pid, "price": r.get("price") or None, "volume": self._lots(r.get("volume") or raw)}

        def verify():
            if before is None:
                raise BridgeError("không có ảnh chụp vị thế trước khi gửi nên không phân biệt được lệnh mới")
            pos, _ = self._raw_pos_orders()
            cand = [p for p in pos if p["position_id"] not in before[0] and p["symbol"] == s["name"] and p["action"] == otype and p["volume"] == raw]
            hit = self._choose(cand, nonce, magic if self.use_magic else 0, key, lambda p: str(p["position_id"]), "vị thế")
            if hit is not None:
                if nonce in str(hit.get("comment") or ""):
                    self.tags_ok = True if self.tags_ok is None else self.tags_ok
                self._remember(hit["position_id"], hit["order"])
                return {"order_id": str(hit["order"]), "position_id": str(hit["position_id"]), "price": hit["price_open"], "volume": self._lots(hit["volume"]), "verified": True}
            if self.c.offset is not None:                                   # vị thế có thể đã mở rồi đóng ngay (SL/TP/stop-out): tìm trong deal MỞ
                off = self.c.offset
                deals = [d for d in self._deal_rows(t0 - 120, time.time() + 3600) if d["action"] == otype and d["entry"] == 0 and d["symbol"] == s["name"]
                         and d["volume"] == raw and d["time_create"] - off >= t0 - 5 and not self._is_claimed(d["position_id"])]
                tagged = [d for d in deals if nonce in str(d.get("comment") or "")]
                pick = tagged[0] if tagged else (deals[0] if len(deals) == 1 and self.tags_ok is not True and len([1 for v in self._inflight.values() if v[0] == key and v[1] is not None]) <= 1 else None)
                if pick:
                    self._remember(pick["position_id"], pick["order"])
                    return {"order_id": str(pick["order"]), "position_id": str(pick["position_id"]), "price": pick["price_open"], "volume": self._lots(raw), "verified": True}
            return None
        try:
            return self._run(send, verify, "lệnh %s %s %s" % (side, symbol, volume))
        finally:
            with self._ilock:
                self._inflight.pop(nonce, None)

    def close_position(self, position_id, volume=None):
        pid = int(position_id)
        cur = [p for p in self._raw_pos_orders()[0] if p["position_id"] == pid]
        if not cur:
            raise BridgeError("Không thấy vị thế #%s trên MT5" % position_id)
        p = cur[0]
        sym = self._sym(p["symbol"])
        raw = p["volume"] if volume is None else min(p["volume"], self._raw_vol(volume))
        v0 = p["volume"]

        def send():
            r = self._trade(action=ACT_DEAL, symbol=p["symbol"], volume=raw, digits=sym["digits"], type=OT_BUY if p["action"] == 1 else OT_SELL,
                            filling=self._fill(p["symbol"]), deviation=self.deviation, position=pid, comment="pyea")
            return {"order_id": str(r.get("order") or ""), "position_id": str(pid), "price": r.get("price") or None, "volume": self._lots(raw)}

        def verify():
            now = [q for q in self._raw_pos_orders()[0] if q["position_id"] == pid]
            if not now or now[0]["volume"] <= v0 - raw:
                return {"order_id": "", "position_id": str(pid), "price": None, "volume": self._lots(raw), "verified": True}
            return None
        return self._run(send, verify, "lệnh đóng vị thế #%s" % pid)

    def modify_position(self, position_id, sl, tp):
        pid = int(position_id)
        cur = [p for p in self._raw_pos_orders()[0] if p["position_id"] == pid]
        if not cur:
            raise BridgeError("Không thấy vị thế #%s trên MT5" % position_id)
        sym = self._sym(cur[0]["symbol"])
        tol, sl, tp = 0.5 * 10 ** -int(sym["digits"]), float(sl or 0), float(tp or 0)
        sp = self._spec_for_check(cur[0]["symbol"])
        if sp is not None and (sl or tp):
            bid, ask, _ = self.tick(cur[0]["symbol"])
            ref = bid if cur[0]["action"] == 0 else ask
            for what, val, old in (("SL", sl, cur[0]["sl"]), ("TP", tp, cur[0]["tp"])):
                if val and abs(val - old) > tol:                                    # chỉ kiểm mức MỚI/đổi; mức cũ giữ nguyên thì sàn đã chấp nhận
                    self._pre_distance(sp, cur[0]["symbol"], what, ref, val)

        def verify():
            now = [q for q in self._raw_pos_orders()[0] if q["position_id"] == pid]
            if now and abs(now[0]["sl"] - sl) <= tol and abs(now[0]["tp"] - tp) <= tol:
                return True
            return None
        self._run(lambda: self._trade(action=ACT_SLTP, symbol=cur[0]["symbol"], digits=sym["digits"], position=pid, sl=sl, tp=tp), verify,
                  "lệnh sửa SL/TP của vị thế #%s" % pid)

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        if kind not in self.native_kinds:
            raise BridgeError("MT5: lệnh chờ '%s' chưa được hỗ trợ native" % kind)
        sp = self._pre_open(symbol, side)
        s = self._sym(symbol)
        ot = {("buy", "limit"): OT_BUY_LIMIT, ("sell", "limit"): OT_SELL_LIMIT, ("buy", "stop"): OT_BUY_STOP, ("sell", "stop"): OT_SELL_STOP,
              ("buy", "stop_limit"): OT_BUY_STOP_LIMIT, ("sell", "stop_limit"): OT_SELL_STOP_LIMIT}[(side, kind)]
        exp = int(float(expiry) + self._off()) if expiry else 0
        raw, price = self._raw_vol(volume), float(price)
        trigger = 0.0
        if kind == "stop_limit":                                    # theo pymt5: price = giá LIMIT đặt sau khi kích hoạt, trigger = giá STOP kích hoạt
            if not stop_price:
                raise BridgeError("MT5: lệnh stop-limit cần cả giá stop (kích hoạt) và giá limit")
            trigger = float(stop_price)
        if sp is not None:
            bid, ask, _ = self.tick(symbol)
            ref = ask if side == "buy" else bid
            self._pre_distance(sp, symbol, "giá kích hoạt lệnh chờ" if kind == "stop_limit" else "giá lệnh chờ", ref, trigger or price)
            if kind == "stop_limit":
                self._pre_distance(sp, symbol, "giá limit của stop-limit so với giá stop", trigger, price)
        nonce, magic, tagged_comment, seq = self._new_tag(comment)
        key = ("p", s["name"], ot, raw, round(price, 8))
        try:
            before = self._snap()
        except BridgeError:
            before = None
        tol = 0.5 * 10 ** -int(s["digits"])
        with self._ilock:
            self._inflight[nonce] = (key, None)

        def send():
            r = self._trade(on_send=self._mark_sent(nonce, key), action=ACT_PENDING, symbol=s["name"], volume=raw, digits=s["digits"], type=ot, filling=self._fill(s["name"], False),
                            ttype=TIME_SPECIFIED if exp else TIME_GTC, price=price, trigger=trigger, comment=tagged_comment, expiry=exp, reason=magic if self.use_magic else 0)
            self._remember(r.get("order"))
            return str(r.get("order") or "")

        def verify():
            if before is None:
                raise BridgeError("không có ảnh chụp lệnh chờ trước khi gửi")
            cand = [o for o in self._raw_pos_orders()[1] if o["order"] not in before[1] and o["symbol"] == s["name"] and o["type"] == ot
                    and (o["vol_cur"] or o["vol_init"]) == raw and (abs(o["price_order"] - price) <= tol or kind == "stop_limit")]
            hit = self._choose(cand, nonce, magic if self.use_magic else 0, key, lambda o: str(o["order"]), "lệnh chờ")
            if hit is None:
                return None
            self._remember(hit["order"])
            return str(hit["order"])
        try:
            oid = self._run(send, verify, "lệnh chờ %s %s %s" % (side, kind, symbol))
            if kind == "stop_limit":
                self._check_stop_limit(oid, s["name"], s["digits"], price, trigger, tol)
            return oid
        finally:
            with self._ilock:
                self._inflight.pop(nonce, None)

    def _check_stop_limit(self, oid, name, digits, limit, trigger, tol):
        """Đọc lại lệnh stop-limit vừa đặt: nếu sàn ghi giá limit/stop KHÁC cách app gửi (hiểu ngược) thì huỷ ngay, ngừng dùng native cho stop-limit."""
        try:
            o = self._find_order(oid)
        except BridgeError:
            return                                              # chưa thấy lệnh để so (đã khớp/huỷ): không kết luận
        if abs(o["price_order"] - limit) <= tol and abs(o["price_trigger"] - trigger) <= tol:
            return
        self.native_kinds = set(self.native_kinds) - {"stop_limit"}
        try:
            self._trade(action=ACT_REMOVE, symbol=name, digits=digits, order=o["order"])
        except BridgeError:
            pass
        raise BridgeError("MT5: sàn ghi lệnh stop-limit khác giá app gửi (sàn: limit %s / stop %s; app gửi: limit %s / stop %s). Đã huỷ lệnh đó và tắt stop-limit native; "
                          "app sẽ tự theo dõi stop-limit. Hãy kiểm tra danh sách lệnh trên MT5." % (o["price_order"], o["price_trigger"], limit, trigger))

    def _find_order(self, order_id):
        oid = int(order_id)
        for o in self._raw_pos_orders()[1]:
            if o["order"] == oid:
                return o
        raise BridgeError("Không thấy lệnh chờ #%s trên MT5" % order_id)

    def _pre_freeze(self, o, what):
        sp = self._spec_for_check(o["symbol"])
        if sp is None or sp["freeze_level"] <= 0:
            return
        bid, ask, _ = self.tick(o["symbol"])
        ref = ask if o["type"] in (OT_BUY_LIMIT, OT_BUY_STOP, 6) else bid
        ptr = o["price_trigger"] if o["type"] in (6, 7) and o["price_trigger"] else o["price_order"]
        if abs(ref - ptr) <= sp["freeze_level"] * sp["point"] + 1e-12:
            raise BridgeError("MT5: không thể %s lệnh chờ #%s: giá đang nằm trong vùng đóng băng (freeze level %d điểm) quanh giá lệnh. Lệnh KHÔNG được gửi; thử lại khi giá xa hơn."
                              % (what, o["order"], sp["freeze_level"]))

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        o = self._find_order(order_id)
        self._pre_freeze(o, "sửa")
        sym = self._sym(o["symbol"])
        tol = 0.5 * 10 ** -int(sym["digits"])
        np_, nsl, ntp = float(price if price is not None else o["price_order"]), float(sl if sl is not None else o["sl"]), float(tp if tp is not None else o["tp"])

        def verify():
            now = [q for q in self._raw_pos_orders()[1] if q["order"] == o["order"]]
            if now and abs(now[0]["price_order"] - np_) <= tol and abs(now[0]["sl"] - nsl) <= tol and abs(now[0]["tp"] - ntp) <= tol:
                return True
            return None
        self._run(lambda: self._trade(action=ACT_MODIFY, symbol=o["symbol"], digits=sym["digits"], order=o["order"], type=o["type"], filling=o["filling"],
                                      ttype=o["type_time"], price=np_, trigger=o["price_trigger"], sl=nsl, tp=ntp, expiry=o["time_exp"]), verify,
                  "lệnh sửa lệnh chờ #%s" % order_id)

    def cancel_pending(self, order_id):
        o = self._find_order(order_id)
        self._pre_freeze(o, "huỷ")

        def verify():
            return True if not [q for q in self._raw_pos_orders()[1] if q["order"] == o["order"]] else None
        self._run(lambda: self._trade(action=ACT_REMOVE, symbol=o["symbol"], digits=self._sym(o["symbol"])["digits"], order=o["order"]), verify,
                  "lệnh huỷ lệnh chờ #%s" % order_id)

    # ---- lịch sử ----
    def _deal_rows(self, since, until):
        off = self._off()
        payload = struct.pack("<ii", int(since + off), int(until + off))
        _, body = self.c.call(CMD_HISTORY, payload, timeout=40.0)
        rows, _ = parse_counted(body, S_DEAL, F_DEAL)
        return rows

    # mã lý do của giao dịch theo bảng DEAL_REASON_* của MT5 (CHƯA XÁC MINH cổng web dùng đúng bảng này); chữ thường như các cầu nối khác
    DEAL_REASON = {0: "client", 1: "mobile", 2: "web", 3: "expert", 4: "sl", 5: "tp", 6: "so", 7: "rollover", 8: "vmargin", 9: "split"}

    def _norm(self, rows):
        off, out = self._off(), []
        for d in rows:
            kind = "trade" if d["action"] in (0, 1) else "balance" if d["action"] == 2 else "credit" if d["action"] == 3 else "other"
            entry = {0: "IN", 1: "OUT", 2: "INOUT", 3: "OUT_BY"}.get(d["entry"], "")
            qty = self._lots(d["volume"])
            out.append({"id": str(d["deal"]), "time": d["time_create"] + d["ms_c"] / 1000.0 - off if d["ms_c"] >= 0 else d["time_create"] - off,
                        "symbol": d["symbol"], "side": "sell" if d["action"] == 1 else "buy" if d["action"] == 0 else "", "qty": qty, "price": d["price_open"],
                        "fee": d["commission"] + d["swap"] + d["fee"], "pnl": d["profit"] if kind == "trade" else 0.0, "order_id": str(d["order"]),
                        "position_id": str(d["position_id"]), "entry": entry if kind == "trade" else "", "reason": self.DEAL_REASON.get(d["reason"], ""), "profit": d["profit"],
                        "commission": d["commission"], "swap": d["swap"], "kind": kind, "comment": d["comment"], "magic": d["expert"],
                        "origin": ordertag.classify(d["comment"], d["expert"]), "price_close": d["price_close"], "sl": d["sl"], "tp": d["tp"]})
        return sorted(out, key=lambda x: x["time"])

    def deals(self, since):
        return [x for x in self._norm(self._deal_rows(since, time.time() + 3600)) if x["kind"] == "trade" and x["qty"] > 0]

    def history(self, since, until=None):
        return self._norm(self._deal_rows(since, until or time.time() + 3600))

    def deals_by_position(self, position_id):
        pid = str(position_id)
        return [x for x in self._norm(self._deal_rows(time.time() - 90 * 86400, time.time() + 3600)) if x["position_id"] == pid and x["kind"] == "trade"]

    def close(self):
        self.c.close()


# =========================================================================================== tạo từ cài đặt
def make_backend(settings):
    bad = problems(settings, require=True)
    if bad:
        raise BridgeError("Cài đặt MT5 chưa đúng:\n- " + "\n- ".join(bad))
    off = str(settings.get("mt5ws_server_offset_hours", "") or "").strip()
    offset = float(off) * 3600.0 if off else None
    conn = Mt5WsConn(str(settings.get("mt5ws_uri") or "").strip() or DEFAULT_URI, str(settings.get("mt5ws_login", "")).strip(), str(settings.get("mt5ws_password", "")),
                     str(settings.get("mt5ws_otp", "") or "").strip(), str(settings.get("mt5ws_url", "") or "").strip(), server_offset=offset)
    scale = float(str(settings.get("mt5ws_volume_scale") or "").strip() or 1e8)
    dev = int(str(settings.get("mt5ws_deviation") or "").strip() or 20)
    return Mt5WsBackend(conn, scale, dev, str(settings.get("mt5ws_filling") or "auto"), str(settings.get("mt5ws_magic") or "off").lower() in ("on", "auto", "yes", "1"),
                        str(settings.get("mt5ws_precheck") or "on").lower() not in ("off", "no", "0"))


# =========================================================================================== tự kiểm tra (nút trong app / selfcheck)
def selftest(settings, trade=False, symbol=None, log=None):
    """Chạy từng bước kết nối -> đọc dữ liệu (-> thử lệnh nếu trade=True, CHỈ tài khoản DEMO). Trả [(mức, nội dung)], mức: OK | CHÚ Ý | LỖI.
    Không bao giờ ném lỗi ra ngoài; mọi lỗi thành dòng LỖI kèm hướng dẫn."""
    rows = []

    def add(level, text):
        rows.append((level, text))
        if log:
            log(level, text)
    b = None
    try:
        b = make_backend(settings)
        b.c.ensure()
        add("OK", "Đăng nhập thành công (build máy chủ %s)." % getattr(b.c, "server_build", "?"))
    except BridgeError as e:
        add("LỖI", str(e))
        return rows
    except Exception as e:                                           # noqa: BLE001
        add("LỖI", "Lỗi không lường trước: %s" % e)
        return rows
    try:
        names = b.symbols()
        add("OK" if names else "CHÚ Ý", "Danh sách mã: %d mã." % len(names))
        a = b.account()
        add("OK", "Tài khoản %s · %s · số dư %.2f %s · đòn bẩy 1:%d · %s." % ("DEMO" if a["demo"] else "THẬT", a["server"] or "?", a["balance"], a["currency"],
                                                                         a["leverage"], "hedging" if a["hedging"] else "netting"))
        if not a["trade_allowed"]:
            add("CHÚ Ý", "Quyền tài khoản có thể không cho giao dịch (đang dùng mật khẩu investor?).")
        sym = symbol or next((n for n in ("EURUSD", "XAUUSD", "GBPUSD") if n in names), names[0] if names else None)
        if sym:
            bid, ask, ts = b.tick(sym)
            add("OK", "Giá %s: bid %s / ask %s." % (sym, bid, ask))
            b._off()
            if b.c.offset is None:
                add("CHÚ Ý", "Chưa dò được múi giờ máy chủ (thị trường đóng?). Hãy đặt ô «MT5 múi giờ máy chủ» (vd 2 hoặc 3) để giờ vị thế/lịch sử không lệch.")
            else:
                add("OK", "Múi giờ máy chủ: UTC%+g giờ." % (b.c.offset / 3600.0))
            cs = b.candles(sym, "5m", 20)
            if cs:
                age = time.time() - cs[-1].time
                add("OK" if age < 3 * 86400 else "CHÚ Ý", "Nến M5: %d nến, nến cuối cách đây %.0f phút%s." % (len(cs), age / 60, "" if age < 3 * 86400 else " (thị trường đóng/dữ liệu cũ?)"))
            else:
                add("CHÚ Ý", "Không có nến M5 cho %s." % sym)
            sp = b.spec(sym)
            add("OK", "Đặc tả %s: khối lượng min %g · max %g · bước %g." % (sym, sp["volume_min"], sp["volume_max"], sp["volume_step"]))
            modes = {0: "CẤM giao dịch", 1: "chỉ mua", 2: "chỉ bán", 3: "chỉ đóng lệnh", 4: "đầy đủ"}
            sane = b._spec_sane(sp)
            mo = b.market_open(sym)
            add("OK" if sane and sp["trade_mode"] == 4 else "CHÚ Ý",
                "Luật mã %s đọc từ sàn: chế độ giao dịch=%s · stops level=%d điểm · freeze level=%d điểm · giờ phiên: %s.%s" % (
                    sym, modes.get(sp["trade_mode"], "?"), sp["stops_level"], sp["freeze_level"],
                    {True: "đang MỞ", False: "đang ĐÓNG", None: "không đọc được lịch"}[mo],
                    "" if sane else " Giá trị trông VÔ LÝ -> app sẽ KHÔNG chặn lệnh theo luật này (đặt mt5ws_precheck=off nếu muốn tắt hẳn)."))
        mg = a.get("margin") if isinstance(a, dict) else None
        add("OK", "Ký quỹ: sàn không báo; app %s." % ("ƯỚC TÍNH %.2f %s (chưa gồm lệnh chờ/bù trừ hedge)" % (mg, a.get("currency", "")) if mg is not None
                                                      else "không ước tính được (có lệnh chờ hoặc loại mã chưa hỗ trợ) nên để trống"))
        add("OK", "Vị thế đang mở: %d · lệnh chờ: %d." % (len(b.positions()), len(b.orders())))
        if trade:
            if not sym:
                add("LỖI", "Không có mã để thử lệnh.")
            elif not a["demo"]:
                add("LỖI", "Từ chối thử lệnh: đây là tài khoản THẬT. Chỉ thử lệnh trên DEMO.")
            else:
                lot = b.spec(sym)["volume_min"]
                r = b.market(sym, "buy", lot, "pyea-test")
                add("OK", "Đã mua %g lot %s (vị thế #%s, giá %s)%s." % (lot, sym, r["position_id"], r["price"], " - xác minh bằng đọc lại sàn" if r.get("verified") else ""))
                time.sleep(1.0)
                if not [p for p in b.positions() if p["id"] == r["position_id"]]:
                    add("CHÚ Ý", "Mua xong nhưng KHÔNG thấy vị thế #%s trong danh sách - id vị thế có thể khác ticket lệnh (xem HANDOFF 5bg mục 6)." % r["position_id"])
                else:
                    add("OK", "Vị thế hiện đúng trong danh sách đọc từ sàn.")
                    if b.tags_ok is True:
                        add("OK", "Sàn GIỮ nhãn comment của lệnh: app phân biệt được từng lệnh kể cả lệnh giống hệt nhau khi mất phản hồi.")
                    else:
                        add("CHÚ Ý", "Sàn KHÔNG giữ nhãn comment: khi mất phản hồi app vẫn xác minh được nhưng phải dựa vào thứ tự gửi; "
                                     "thử bật «MT5 gửi thêm magic» (on) rồi chạy lại để xem sàn có giữ magic không.")
                    b.close_position(r["position_id"])
                    time.sleep(1.0)
                    left = [p for p in b.positions() if p["id"] == r["position_id"]]
                    add("OK" if not left else "LỖI", "Đóng vị thế: %s." % ("xong, danh sách đã sạch" if not left else "vị thế vẫn còn - hãy đóng tay!"))
    except BridgeError as e:
        add("LỖI", str(e))
    except Exception as e:                                           # noqa: BLE001
        add("LỖI", "Lỗi không lường trước: %s" % e)
    finally:
        try:
            b.close()
        except Exception:                                            # noqa: BLE001
            pass
    return rows
