"""
Sao lưu / đồng bộ ĐA THIẾT BỊ không cần máy chủ của tác giả: gói dữ liệu (bot, tham số, bot đã gắn, giao diện/biểu đồ/hình vẽ, tuỳ chọn cả cài đặt)
được MÃ HOÁ bằng mật khẩu của bạn rồi cất ở nơi BẠN chọn: một file (Syncthing/Drive/USB...) hoặc WebDAV (Nextcloud, NAS...).
Chỉ dùng thư viện chuẩn (PBKDF2-HMAC-SHA256 + dòng khoá HMAC-SHA256-CTR + mã xác thực HMAC "mã hoá rồi ký") nên chạy được trên Android.

KHÔNG đồng bộ: nhật ký, sổ lệnh/trạng thái phiên (mỗi thiết bị tự giữ), bot_perms.json (quyền bot phải được cấp lại trên mỗi máy),
khoá API (trừ khi bạn chọn include_secrets; khi đó chúng được giải mã bằng khoá thiết bị này rồi mã hoá bằng mật khẩu gói, và máy nhận mã hoá lại bằng khoá của máy đó).
Hợp nhất: file nào mới hơn (theo thời điểm sửa) thì thắng; bot bị ghi đè được lưu vào phiên bản cũ (botversions) nên hoàn tác được.
Giới hạn trung thực: đồng bộ theo thao tác (bấm «Đồng bộ»), không theo thời gian thực; hai máy sửa CÙNG file giữa hai lần đồng bộ thì bản mới hơn thắng.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import time
import urllib.error
import urllib.request

from . import botversions

MAGIC = b"PYEABUNDLE1"
ITER = 200_000
SAFE_BOT = re.compile(r"^bots/[\w\-]+\.py$")
SAFE_PARAM = re.compile(r"^params/[\w\-\.]+\.json$")
FIXED = ("instances.json", "ui_prefs.json")


class BundleError(Exception):
    pass


def _keys(pw, salt, iters):
    k = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, iters, 64)
    return k[:32], k[32:]


def _stream(key, nonce, n):
    out, ctr = bytearray(), 0
    while len(out) < n:
        out += hmac.new(key, nonce + ctr.to_bytes(8, "big"), hashlib.sha256).digest()
        ctr += 1
    return bytes(out[:n])


def seal(plain, pw, iters=ITER, salt=None, nonce=None):
    if not pw:
        raise BundleError("Cần mật khẩu.")
    salt = salt or os.urandom(16)
    nonce = nonce or os.urandom(16)
    ek, mk = _keys(pw, salt, iters)
    ct = bytes(a ^ b for a, b in zip(plain, _stream(ek, nonce, len(plain))))
    head = MAGIC + iters.to_bytes(4, "big") + salt + nonce
    return head + ct + hmac.new(mk, head + ct, hashlib.sha256).digest()


def unseal(blob, pw):
    if not blob.startswith(MAGIC) or len(blob) < len(MAGIC) + 4 + 32 + 32:
        raise BundleError("Không phải gói PyEA.")
    o = len(MAGIC)
    iters = int.from_bytes(blob[o:o + 4], "big")
    if not (1000 <= iters <= 5_000_000):
        raise BundleError("Gói hỏng (số vòng băm lạ).")
    salt, nonce = blob[o + 4:o + 20], blob[o + 20:o + 36]
    ct, tag = blob[o + 36:-32], blob[-32:]
    ek, mk = _keys(pw, salt, iters)
    if not hmac.compare_digest(tag, hmac.new(mk, blob[:-32], hashlib.sha256).digest()):
        raise BundleError("Sai mật khẩu hoặc gói đã bị sửa.")
    return bytes(a ^ b for a, b in zip(ct, _stream(ek, nonce, len(ct))))


def _collect(store, include_secrets):
    files = {}

    def add(rel, path):
        try:
            with open(path, "rb") as f:
                data = f.read()
            files[rel] = {"b": base64.b64encode(data).decode("ascii"), "m": os.path.getmtime(path)}
        except OSError:
            pass
    for n in sorted(os.listdir(store.bots_dir)) if os.path.isdir(store.bots_dir) else []:
        if n.endswith(".py"):
            add("bots/" + n, os.path.join(store.bots_dir, n))
    for n in sorted(os.listdir(store.params_dir)) if os.path.isdir(store.params_dir) else []:
        if n.endswith(".json"):
            add("params/" + n, os.path.join(store.params_dir, n))
    add("instances.json", os.path.join(store.base, "instances.json"))
    add("ui_prefs.json", store.prefs_path)
    if include_secrets:
        try:
            raw = json.dumps(store.load_settings(), ensure_ascii=False).encode("utf-8")
            files["settings"] = {"b": base64.b64encode(raw).decode("ascii"), "m": os.path.getmtime(store.settings_path)}
        except OSError:
            pass
    return files


def export_bundle(store, password, include_secrets=False, now=None):
    doc = {"v": 1, "time": now or time.time(), "secrets": bool(include_secrets), "files": _collect(store, include_secrets)}
    return seal(json.dumps(doc, ensure_ascii=False).encode("utf-8"), password)


def read_bundle(blob, password):
    try:
        doc = json.loads(unseal(blob, password).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise BundleError("Nội dung gói không đọc được.")
    if not isinstance(doc, dict) or not isinstance(doc.get("files"), dict):
        raise BundleError("Gói sai cấu trúc.")
    return doc


def _local_target(store, rel):
    if rel == "settings":
        return store.settings_path
    if SAFE_BOT.match(rel):
        return os.path.join(store.bots_dir, rel[5:])
    if SAFE_PARAM.match(rel):
        return os.path.join(store.params_dir, rel[7:])
    if rel == "instances.json":
        return os.path.join(store.base, "instances.json")
    if rel == "ui_prefs.json":
        return store.prefs_path
    return None


def import_bundle(store, blob, password, mode="merge", dry_run=False):
    """mode: merge (file mới hơn thắng) | replace (luôn lấy từ gói). Trả {"written": [...], "kept": [...], "skipped": [...]}. Tên file lạ bị bỏ (chống ghi ra ngoài thư mục)."""
    doc = read_bundle(blob, password)
    rep = {"written": [], "kept": [], "skipped": []}
    for rel, ent in sorted(doc["files"].items()):
        path = _local_target(store, rel)
        if path is None or not isinstance(ent, dict):
            rep["skipped"].append(rel)
            continue
        try:
            data = base64.b64decode(ent["b"], validate=True)
            remote_m = float(ent.get("m", 0))
        except (KeyError, ValueError, TypeError):
            rep["skipped"].append(rel)
            continue
        exists = os.path.exists(path)
        if exists and mode == "merge":
            try:
                with open(path, "rb") as f:
                    same = f.read() == data if rel != "settings" else False
            except OSError:
                same = False
            if same:
                continue
            if os.path.getmtime(path) >= remote_m:
                rep["kept"].append(rel)
                continue
        if dry_run:
            rep["written"].append(rel)
            continue
        if rel == "settings":
            try:
                store.save_settings(json.loads(data.decode("utf-8")))           # lưu qua Store: mã hoá lại bằng khoá của máy này
            except (ValueError, OSError):
                rep["skipped"].append(rel)
                continue
        else:
            if rel.startswith("bots/") and exists:
                botversions.snapshot(path, "nap")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, path)
        try:
            os.utime(path, (remote_m, remote_m))                                 # giữ mốc thời gian gốc để lần sau so sánh đúng
        except OSError:
            pass
        rep["written"].append(rel)
    return rep


# ------------------------------------------------------------------ nơi lưu
def _dav(url, method, user, pw, data=None, timeout=30):
    req = urllib.request.Request(url, data=data, method=method)
    if user:
        req.add_header("Authorization", "Basic " + base64.b64encode(("%s:%s" % (user, pw or "")).encode("utf-8")).decode("ascii"))
    if data is not None:
        req.add_header("Content-Type", "application/octet-stream")
    return urllib.request.urlopen(req, timeout=timeout)


def sync(store, password, target, include_secrets=False, user="", webdav_password=""):
    """Đồng bộ hai chiều: kéo gói ở `target` (đường dẫn file hoặc URL http(s) WebDAV) → hợp nhất vào máy này → đẩy gói mới lên.
    Trả {"pulled": báo cáo hoặc None, "pushed": True}."""
    is_url = target.lower().startswith(("http://", "https://"))
    if is_url and target.lower().startswith("http://") and not re.match(r"^http://(127\.0\.0\.1|localhost)(:|/)", target.lower()):
        raise BundleError("Chỉ dùng https:// (http:// chỉ cho localhost).")
    blob = None
    try:
        if is_url:
            blob = _dav(target, "GET", user, webdav_password).read()
        elif os.path.exists(target):
            with open(target, "rb") as f:
                blob = f.read()
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise BundleError("Máy chủ trả lỗi %s khi tải gói." % e.code)
    except (urllib.error.URLError, OSError) as e:
        raise BundleError("Không truy cập được %s: %s" % (target, e))
    pulled = import_bundle(store, blob, password, "merge") if blob else None
    out = export_bundle(store, password, include_secrets)
    try:
        if is_url:
            _dav(target, "PUT", user, webdav_password, out).read()
        else:
            tmp = target + ".tmp"
            with open(tmp, "wb") as f:
                f.write(out)
            os.replace(tmp, target)
    except (urllib.error.URLError, OSError) as e:
        raise BundleError("Không ghi được gói lên %s: %s" % (target, e))
    return {"pulled": pulled, "pushed": True}
