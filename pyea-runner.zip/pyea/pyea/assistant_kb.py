"""
SỔ TAY NGOẠI TUYẾN của Trợ lý: cách DÙNG app, cách CÀI ĐẶT và cách XỬ LÝ SỰ CỐ - viết theo đúng tên nút/mục có trong app.

Vì sao có file này khi đã có model AI:
  - khi app gặp sự cố (mất mạng, hết hạn khoá AI, model lỗi...) thì đó chính là lúc người dùng cần hướng dẫn nhất, mà model lại gọi không được;
  - model được đưa các mục liên quan làm TÀI LIỆU CHUẨN nên trả lời đúng tên nút thay vì bịa;
  - nội dung ở đây kiểm tra được bằng test (tests/test_assistant.py khớp tên khoá cài đặt với settings.py, tên nút với giao diện).
Quy ước: mỗi mục = (id, loại, tiêu đề, từ khoá, nội dung). Loại: dung (cách dùng) · caidat (cài đặt/kết nối) · loi (xử lý sự cố).
Không đưa vào đây điều app chưa làm được hoặc chưa kiểm chứng: chỗ nào chưa kiểm chứng thì nói thẳng.
"""
import re
import unicodedata

DUNG, CAIDAT, LOI = "dung", "caidat", "loi"


def fold(text):
    """Chữ thường, bỏ dấu tiếng Việt (đ -> d) để so khớp từ khoá."""
    t = unicodedata.normalize("NFD", str(text or "").lower().replace("đ", "d"))
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


TOPICS = [
    ("tabs", DUNG, "Tổng quan 8 tab",
     "tab man hinh giao dien thi truong giao dich bot bieu do backtest ai cai dat nhat ky bat dau huong dan su dung",
     "8 tab ở dưới: Thị trường (giá nhiều mã, nút KẾT NỐI) · Giao dịch (số dư/ký quỹ, vị thế, Lệnh mới, Lịch sử & báo cáo, Cảnh báo giá) · Bot (nạp file .py, Gắn bot vào mã + khung giờ) · "
     "Biểu đồ (nến + chỉ báo + chấm vào/ra) · Backtest (Strategy Tester) · AI (chat/nhóm AI, Quản lý AI) · Cài đặt (sàn, chế độ, rủi ro, chạy nền, API) · Nhật ký (log, Kiểm tra hệ thống). "
     "Bắt đầu nhanh: Cài đặt chọn sàn (mặc định «simulated» = giả lập offline) → Lưu → tab Thị trường bấm KẾT NỐI → tab Bot gắn bot mẫu."),
    ("connect", DUNG, "Kết nối phiên (paper / live)",
     "ket noi ngat phien chay paper live that gia lap tien that chay dung connect",
     "Phiên = app lấy giá và chạy bot. Bấm KẾT NỐI (tab Thị trường) hoặc «▶ KẾT NỐI & CHẠY» (tab Bot); bấm lại để NGẮT KẾT NỐI. Cài đặt đổi xong phải Lưu rồi KẾT NỐI lại mới áp dụng (riêng danh sách theo dõi áp dụng ngay). "
     "«paper» = giao dịch giả lập (giá thật nếu chọn sàn thật, tiền giả). «live» = TIỀN THẬT: cần tick «Tôi hiểu rủi ro giao dịch tiền thật», khoá API của sàn và nên thử Testnet/Demo trước. Trợ lý không đổi được paper↔live giúp bạn."),
    ("manual_order", DUNG, "Đặt lệnh tay, sửa SL/TP, đóng lệnh",
     "dat lenh tay mua ban lenh moi sl tp stop loss take profit dong lenh sua khoi luong xac nhan",
     "Tab Giao dịch → «Lệnh mới» (hoặc chạm mã ở Thị trường → đặt lệnh): chọn mua/bán, khối lượng, SL/TP (để trống thì dùng «SL/TP mặc định» trong Cài đặt nếu có), rồi MUA/BÁN. "
     "Mỗi vị thế có nút «Sửa» (đổi SL/TP) và «Đóng»; «Đóng tất cả» đóng mọi vị thế. Mặc định app hỏi xác nhận (Cài đặt → «Hỏi xác nhận khi đặt lệnh tay»). "
     "Phải KẾT NỐI trước. Bị từ chối thì xem mã lỗi ở mục «Lệnh bị từ chối»."),
    ("attach_bot", DUNG, "Nạp và gắn bot",
     "bot gan nap file py tham so inputs bat tat bot ea gan vao bieu do mau",
     "Tab Bot → «Nạp file .py» (hoặc dùng bot mẫu có sẵn) → «Gắn bot mới»: chọn bot + mã + khung giờ; một bot gắn được nhiều nơi, tham số riêng từng chỗ (nút «Tham số» tự sinh form từ khai báo Input trong code, như hộp Inputs của MT5). "
     "Bot chạy khi đã KẾT NỐI; có bật/tắt từng bot. Bot lỗi nhiều lần/giờ sẽ bị tắt (circuit breaker), bot treo bị đánh dấu và ngừng nhận tick. «Giải thích bot» nhờ AI đọc code. App chặn mã nguy hiểm trong file bot (trừ khi bật Chế độ nhà phát triển - chỉ khi TIN file đó)."),
    ("bot_inputs", DUNG, "Chuẩn tham số bot (như input của MQL5)",
     "input chuan bot group enum color datetime form nhan dang chuyen doi mql5 khai bao",
     "Khai báo tham số trong code bot: `from pyea import BaseBot, Group, Input`; `Group(\"Tín hiệu\")` đặt nhóm; `Input(10, \"SMA nhanh\", min=2, max=200)`. Kiểu ô suy ra từ giá trị mặc định (bật/tắt, số nguyên, số thực, chữ); `choices=[...]`, `{giá_trị: \"Nhãn\"}` hoặc lớp `enum.Enum` = ô chọn xổ xuống; `subtype=\"color\"|\"time\"|\"datetime\"|\"text\"` = ô màu/giờ/ngày-giờ/văn bản. Trong code đọc `self.tên`.",
     "Bot không khai báo Input vẫn được nhận dạng thuộc tính literal (`fast = 10  # SMA nhanh {2..200}`, `[a|b|c]` = ô chọn). Bot cũ muốn chuyển sang chuẩn: tab Bot → chọn bot → «Nhờ AI chuyển sang chuẩn tham số». Mẫu đủ kiểu: bot «Chuẩn tham số (mẫu đủ kiểu ô)»; tài liệu: docs/BOT_INPUTS.md."),
    ("backtest", DUNG, "Backtest (Strategy Tester)",
     "backtest kiem thu lich su toi uu walk forward spread phi swap strategy tester",
     "Tab Backtest → chọn bot, mã, khung, số nến, vốn, đòn bẩy → «CHẠY BACKTEST». Chi phí (spread cố định, phí/lot, trượt giá, swap, funding) khai ở Cài đặt nhóm «Backtest chi phí». "
     "Có «Tối ưu hoá tham số», «Walk-forward», «So sánh thứ tự giá trong nến» (kết quả đổi dấu = chiến lược dựa vào giả định dữ liệu OHLC không kiểm chứng được). Kết quả backtest không bảo đảm kết quả thật."),
    ("chart_draw_report", CAIDAT, "Công cụ vẽ, báo cáo HTML, debug bot, cập nhật",
     "ve bieu do duong xu huong fibonacci hinh chu nhat doi tuong bao cao html debug bot diem dung profiler cap nhat bao loi hedge",
     "Biểu đồ → nút «Vẽ»: đường ngang, xu hướng, hình chữ nhật, Fibonacci, chữ; chạm vào hình để xoá; «Danh sách đối tượng» để xoá từng cái. Hình lưu theo mã và KHÔNG tự đặt lệnh. "
     "Backtest → «Báo cáo HTML» (tăng trưởng, sụt vốn, theo mã/phiên/giờ); «Debug bot» = Từng dòng/Chỉ điểm dừng rồi «Nhật ký debug» (5 lần gọi đầu). Cài đặt → «Tải thiết bị» có thời gian callback từng bot. "
     "Binance Futures chạy được cả One-way và Hedge mode (tự nhận). Kiểm tra cập nhật và tự gửi báo lỗi mặc định TẮT: bật ở Cài đặt → «Hỗ trợ & cập nhật». Hướng dẫn đầy đủ: Cài đặt → «Hướng dẫn · điều khoản · riêng tư · cập nhật»."),
    ("ai_setup", CAIDAT, "Thêm AI (cũng là AI của Trợ lý)",
     "them ai model api key nha cung cap openrouter groq gemini mistral base url quan ly ai tro ly",
     "Tab AI → «Quản lý AI» → «Thêm AI»: chọn nhà cung cấp (OpenRouter, Groq, Google Gemini, Cerebras, Mistral, NVIDIA NIM, Máy chủ riêng, Tuỳ chỉnh), nhập model và API key. "
     "Trợ lý dùng AI đang bật đầu tiên (hoặc AI có tên đặt ở Cài đặt → «Trợ lý: dùng AI nào»). Lỗi 401 = sai key; 404/“model not found” = model không còn: chọn model khác theo tài liệu nhà cung cấp; "
     "timeout = mạng chậm hoặc nhà cung cấp bận. Model “gợi ý” có thể đã đổi - app ghi rõ chỗ nào chưa xác minh. Khoá được mã hoá khi lưu và bị che khỏi nhật ký/chat."),
    ("exchange_connect", CAIDAT, "Kết nối một sàn mới",
     "ket noi san exness oanda binance mt5 metaapi gateway bridge ccxt api key demo testnet nguon thi truong them san moi",
     "Cài đặt → «Nguồn thị trường / sàn»: simulated · binance_spot · binance_futures · oanda · exness (API chính thức, chỉ VN/TH) · metaapi / mt5gw / bridge (MT4/MT5 mọi broker qua cầu nối) · ccxt (~100 sàn). "
     "Điền đúng nhóm khoá của sàn đó rồi Lưu. Thử trên DEMO/Testnet trước. Sau khi KẾT NỐI chạy «Kiểm tra hệ thống» (Nhật ký): nó thử đọc giá, số dư, vị thế, lịch sử CHỈ ĐỌC và báo CHỖ NÀO lệch. "
     "Sàn nào đặt tên trường khác bảng chung (số hiện «-») thì KHÔNG cần sửa mã: dùng «Ánh xạ trường tuỳ chỉnh» (mục tiếp) - Trợ lý có thể đề xuất giúp. Cầu nối MT: xem gateway/README.md."),
    ("field_mapping", CAIDAT, "Ánh xạ trường cho sàn mới (không sửa mã)",
     "anh xa truong field mapping so lieu gach ngang dau tru hien khong co so tai san so du equity profit ten truong khac san khac",
     "Mỗi sàn gọi số liệu một tên khác (equity / NAV / account_equity...). App chỉ biết các trường chuẩn và một bảng bí danh chung; sàn đặt tên khác bảng thì số hiện «-» (không bịa 0). "
     "Cách chữa: «Kiểm tra hệ thống» có mục «Ánh xạ trường» liệt kê trường nào chưa khớp kèm khoá số chưa dùng của bản ghi thô → điền Cài đặt → «Ánh xạ trường tuỳ chỉnh (JSON)», vd "
     '{"tên_sàn": {"position": {"profit": "khoá_thật"}}}. Trợ lý đọc được báo cáo đó (nếu bạn bật «Cho Trợ lý xem trạng thái») và đề xuất đúng một dòng ghi đè để bạn bấm Áp dụng. Có hiệu lực ở lần KẾT NỐI kế tiếp.'),
    ("numbers", DUNG, "Số trên khung Giao dịch: «SÀN», «sổ app», «-»",
     "so lieu san so app dau gach ngang equity ky quy ky quy con du muc ky quy lai lo tha noi",
     "Nhãn «SÀN» = số do sàn báo (như MT5: Số dư, Tài sản, Lãi/lỗ thả nổi, Ký quỹ, Ký quỹ còn dư, Mức ký quỹ). «sổ app» = số app tự tính (khi sàn không báo, vd paper). "
     "«-» = sàn không báo trường đó hoặc tên trường chưa khớp (xem «Ánh xạ trường»), KHÁC với 0. «Tổng lãi/lỗ (sổ app)» và «Thắng / số lệnh (sổ app)» luôn là sổ app. "
     "Lịch sử & báo cáo → «LỊCH SỬ TỪ SÀN» (Hôm nay/7/30/90 ngày) chỉ có ở một số sàn và chỉ ở chế độ chạy thật; sàn chưa hỗ trợ thì app nói rõ."),
    ("kill_switch", DUNG, "KILL SWITCH và Mở lại giao dịch",
     "kill switch khoa giao dich dung khan cap dong het mo lai giao dich",
     "Nút đỏ KILL SWITCH (tab Giao dịch): dừng bot → huỷ lệnh chờ → đóng hết vị thế → KHOÁ giao dịch (sống qua restart). Muốn giao dịch lại bấm «Mở lại giao dịch». "
     "Trợ lý KHÔNG có quyền bấm hộ nút này."),
    ("sltp_native", CAIDAT, "SL/TP do sàn canh (native) và giới hạn khi app chết",
     "sl tp native bao ve san canh app chet mat mang oco reduce only lenh cho",
     "Mặc định SL/TP do APP canh: app chết hoặc mất mạng thì SL/TP KHÔNG chạy. Bật Cài đặt → «SL/TP NATIVE trên sàn» (THỬ NGHIỆM) để sàn tự canh khi sàn hỗ trợ (Binance Futures/Spot, OANDA, MetaApi/cổng MT, Exness - mức đã kiểm chứng khác nhau, chủ yếu mới thử bằng sàn giả). "
     "Thử trên DEMO/Testnet và vị thế nhỏ trước. «Lệnh chờ đặt ở đâu = auto» đặt lệnh chờ TRÊN sàn nếu sàn hỗ trợ."),
    ("history_backup", DUNG, "Lịch sử, báo cáo, sao lưu / khôi phục",
     "lich su bao cao csv sao luu khoi phuc backup restore xuat file goi chan doan",
     "Tab Giao dịch → «Lịch sử & báo cáo»: win rate, profit factor, sụt vốn, theo từng bot, xuất CSV. Cài đặt → «Sao lưu» / «Khôi phục» (mặc định KHÔNG kèm API key; «Sao lưu KÈM API key» ghi khoá dạng chữ - giữ file thật kín). "
     "«Gói chẩn đoán» = file zip log + cài đặt đã xoá khoá để gửi người hỗ trợ."),
    ("multi_account", DUNG, "Nhiều tài khoản chạy song song",
     "nhieu tai khoan song song tai khoan phu chinh xem",
     "Cài đặt → «Tài khoản (chạy song song)…»: «Thêm từ cài đặt hiện tại» lưu hồ sơ sàn; bot gắn theo tài khoản; «Xem» đổi tài khoản đang xem, «Xem tài khoản chính» quay lại. Tài khoản phụ chạy được cả khi không bật chạy nền, nhưng không có AI hub và dừng khi đóng app."),
    ("alerts_dnd", DUNG, "Cảnh báo giá, thông báo, Không làm phiền",
     "canh bao gia thong bao am thanh rung khong lam phien dnd yen tinh khung gio",
     "Tab Giao dịch → «Cảnh báo giá» (≥/≤/±%): chạy cả khi không có bot, cần đang KẾT NỐI. Cài đặt → nhóm «Chạy nền & cảnh báo» có âm/rung, và nút 1/4/8/24 giờ «Không làm phiền» hoặc khung giờ hằng ngày. "
     "Cảnh báo nghiêm trọng (kill switch, margin call, bot/dịch vụ lỗi, lệch vị thế...) mặc định VẪN kêu khi đang Không làm phiền."),
    ("install", CAIDAT, "Cài app lên điện thoại (APK) và quyền cần cấp",
     "cai dat apk build github actions cai app android nguon khong ro quyen thong bao cat s52 android 9",
     "APK dựng bằng GitHub Actions (README mục 1: đẩy nội dung zip đã giải nén lên repo → tab Actions → Build APK → tải Artifacts). Máy phải cho phép “cài ứng dụng từ nguồn này” cho trình duyệt/trình quản lý file bạn dùng mở APK. "
     "Quyền thông báo: Android 13+ app tự hỏi; Android 9 không cần hỏi nhưng vẫn phải để thông báo của app BẬT trong Cài đặt máy. Bản build mặc định có cả arm64-v8a và armeabi-v7a (32-bit). App chưa được chạy thử trên máy thật - báo lỗi kèm Gói chẩn đoán."),
    ("battery", CAIDAT, "Chạy nền không bị Android giết (pin)",
     "pin toi uu pin chay nen dich vu nen bi giet tat man hinh khoi dong lai bao thuc tu khoi phuc doze",
     "Nhiều máy Android giết app nền để tiết kiệm pin. Làm: (1) Nhật ký → «Kiểm tra hệ thống» → nút «Tối ưu pin» (hoặc Cài đặt máy → Ứng dụng → Truy cập đặc biệt → Tối ưu hoá pin → PyEA Runner → Không tối ưu; tên mục tuỳ hãng máy). "
     "(2) Bật Cài đặt → «Chạy nền bằng dịch vụ» + «Tự khôi phục phiên sau sự cố» + «Báo thức giám sát dịch vụ». (3) Một số hãng có thêm “Tự khởi động”/“Khoá ứng dụng trong đa nhiệm” - bật cho app. "
     "“Buộc dừng” trong Cài đặt Android sẽ xoá báo thức giám sát. Giới hạn: SL/TP do app canh không chạy lúc app chết (xem mục SL/TP native)."),
    ("fix_crash", LOI, "App báo lỗi / thoát đột ngột / treo",
     "loi crash thoat dot ngot treo dung hinh bi dung ung dung loi lan chay truoc khong mo duoc",
     "Mở lại app: nếu lần trước bị lỗi sẽ hiện hộp «Lần chạy trước ứng dụng bị lỗi» kèm chi tiết (có nút Sao chép). Phiên chạy nền (nếu bật) vẫn chạy bình thường. Làm theo thứ tự: (1) Sao chép chi tiết lỗi; "
     "(2) Cài đặt → «Gói chẩn đoán» (zip không chứa API key) rồi gửi; (3) Nhật ký → «Kiểm tra hệ thống»; (4) thử Cài đặt → «Mặc định» cho ô nghi ngờ; (5) nếu nghi dữ liệu hỏng: «Khôi phục» bản «Sao lưu». "
     "Màn hình đứng/chậm: tăng «Tần suất cập nhật giao diện», giảm «Số nến đưa lên biểu đồ», đặt «Chế độ năng lượng = saver»."),
    ("fix_no_link", LOI, "Mất kết nối giá / sàn",
     "mat ket noi mat gia gia cu khong co gia mang loi api san disconnected degraded stale no quotes timeout",
     "Dải trạng thái ở tab Giao dịch cho biết: «giá OK» / «MỘT SỐ MÃ MẤT GIÁ» / «MẤT KẾT NỐI GIÁ - vỏ chặn lệnh bằng giá cũ» (kèm lỗi API sàn nếu có). Khi mất giá app CHẶN lệnh mới (mã NO_QUOTES) để khỏi vào lệnh bằng giá cũ. "
     "Kiểm tra: (1) mạng điện thoại; (2) Nhật ký → «Kiểm tra hệ thống» xem dòng nào LỖI; (3) khoá API/URL đúng sàn, hết hạn hoặc bị giới hạn IP; (4) mã trong danh sách theo dõi đúng cách đặt tên của sàn (Binance BTCUSDT, OANDA EUR_USD...). "
     "Sau 30 giây app báo động nghiêm trọng và nói vị thế nào do SÀN canh, vị thế nào do APP canh (đang KHÔNG chạy); có lại mạng thì tự đối soát với sàn."),
    ("fix_dash", LOI, "Số liệu hiện «-» hoặc sai lệch so với MT5",
     "so lieu dau gach ngang khong hien sai lech khac mt5 so du khong khop equity lai lo sai lich su trong",
     "«-» nghĩa là sàn không báo hoặc tên trường chưa khớp: chạy «Kiểm tra hệ thống», đọc mục «Ánh xạ trường» → thêm «Ánh xạ trường tuỳ chỉnh» (hoặc nhờ Trợ lý đề xuất). "
     "Số «sổ app» có thể lệch số «SÀN» (phí, swap, quy đổi tiền): hãy so với tab Giao dịch/Lịch sử của MT5 thật rồi báo chỗ lệch kèm Gói chẩn đoán. Lệch số dư vượt «Ngưỡng lệch số dư» thì app báo động theo «Khi số dư sổ app lệch số dư sàn»."),
    ("fix_order", LOI, "Lệnh bị từ chối (mã lỗi)",
     "lenh bi tu choi retcode invalid stops invalid volume margin trade disabled symbol mode market closed frozen news block rejected not supported hedge",
     "INVALID_VOLUME: khối lượng sai min/max/step · INVALID_STOPS: SL/TP sai phía hoặc quá sát giá (xem «Khoảng cách tối thiểu SL/TP») · INSUFFICIENT_MARGIN: thiếu ký quỹ · "
     "TRADE_DISABLED: đang «CHỈ-XEM» hoặc đã bấm Kill switch (bấm «Mở lại giao dịch») · SYMBOL_MODE: mã đang close-only/long-only/short-only/disabled («Luật riêng theo mã») · MARKET_CLOSED: thị trường đóng · "
     "NO_QUOTES: mất giá/giá cũ · FROZEN: giá trong vùng freeze, thử lại sau · NEWS_BLOCK: đang trong cửa sổ tin đã bật chặn · NOT_SUPPORTED: sàn/chế độ không hỗ trợ (vd bán khống Binance Spot) · "
     "HEDGE_NOT_ALLOWED: sàn gộp vị thế, không giữ mua và bán cùng mã · REJECTED: sàn từ chối - xem Nhật ký để biết lý do sàn nêu."),
    ("fix_bot", LOI, "Bot lỗi, bị tắt hoặc treo",
     "bot loi tat treo hang exception circuit breaker callback timeout khong vao lenh bot khong chay",
     "Xem tab Nhật ký (có ô lọc theo mức, thời gian, chữ) và tab Bot (trạng thái, lỗi gần nhất). Bot bị tắt khi vượt «Bot được lỗi bao nhiêu lần/giờ»; bị coi là treo khi một hàm chạy quá «Coi bot là TREO nếu một hàm chạy quá». "
     "Trong cửa sổ sửa bot có «Gửi lỗi cho AI» để nhờ AI đọc lỗi; «Giải thích bot» để hiểu logic. Bot không vào lệnh: kiểm tra đã KẾT NỐI, có giá, «CHỈ-XEM» đang tắt, mã lỗi lệnh (mục «Lệnh bị từ chối»), tham số."),
    ("fix_ai", LOI, "AI / Trợ lý không trả lời hoặc báo lỗi",
     "ai khong tra loi loi 401 404 429 timeout model not found het han quota tro ly khong chay",
     "401/403 = key sai hoặc hết hạn · 404 = sai Base URL hoặc model không tồn tại (chọn model khác) · 429 = hết lượt/quota (đợi hoặc đổi nhà cung cấp) · timeout = mạng chậm. "
     "Sửa ở tab AI → «Quản lý AI» (hoặc đặt tên AI khác ở Cài đặt → «Trợ lý: dùng AI nào»). Không có mạng/không có AI thì Trợ lý vẫn trả lời từ sổ tay có sẵn trong app (ngắn hơn và không phân tích dữ liệu của bạn)."),
    ("fix_reset", LOI, "Muốn làm lại từ đầu / dữ liệu lạ",
     "dat lai reset lam lai tu dau du lieu hong cu hon phien ban moi hon paper xoa",
     "Cài đặt → «Đặt lại paper» (chỉ ở chế độ paper: xoá vị thế/lệnh chờ giả lập, đưa số dư về vốn ban đầu, giữ trades.csv; KHÔNG chạm tài khoản thật). «Mặc định» đưa các ô cài đặt về giá trị gốc. Muốn quay về trạng thái đã lưu: «Khôi phục» từ «Sao lưu». "
     "Nếu app báo file dữ liệu thuộc định dạng mới hơn app, app giữ nguyên file đó (đổi tên .bak) và dùng mặc định - đừng xoá, hãy cập nhật app."),
]

_STOP = {"la", "va", "cua", "cho", "nay", "nao", "khong", "co", "sao", "bi", "toi", "minh", "app", "voi", "mot", "nhung", "duoc", "de", "in", "to", "of", "the", "is",
         "it", "my", "how", "why", "what", "do", "an", "and", "are", "can", "does", "lam", "the", "nhu", "thi", "ma", "roi", "dang", "da", "khi", "ung", "dung", "cai"}
KIND_VN = {DUNG: "Cách dùng", CAIDAT: "Cài đặt", LOI: "Xử lý sự cố"}


def words(text):
    return [w for w in re.findall(r"[a-z0-9_]{2,}", fold(text)) if w not in _STOP]


PROBLEM_WORDS = {"loi", "sai", "hong", "treo", "mat", "crash", "sao", "tai", "bi", "why", "error", "fail", "failed", "khong", "dung", "ket", "giet", "lech"}


def search(question, limit=3):
    """Mục sổ tay liên quan nhất tới câu hỏi: [(điểm, mục)] giảm dần. Rỗng nếu không từ nào khớp.
    Câu hỏi nghe như đang gặp sự cố («sao...», «lỗi», «bị...») thì mục xử lý sự cố được cộng điểm khi đã có từ khớp."""
    ws = words(question)
    if not ws:
        return []
    trouble = bool(set(re.findall(r"[a-z0-9_]+", fold(question))) & PROBLEM_WORDS)
    scored = []
    for i, t in enumerate(TOPICS):
        tags = set(t[3].split())
        title = fold(t[2])
        body = fold(t[4])
        s = sum(3 for w in ws if w in tags) + sum(2 for w in ws if w in title) + sum(1 for w in ws if w in body)
        if s:
            if trouble and t[1] == LOI:
                s += 2
            scored.append((s, -i, t))
    scored.sort(reverse=True)
    return [(s, t) for s, _i, t in scored[:limit]]


def render(topic):
    return "%s · %s\n%s" % (KIND_VN.get(topic[1], topic[1]), topic[2], topic[4])


def offline_answer(question, limit=2):
    """Trả lời KHÔNG cần model: các mục sổ tay khớp nhất. Rỗng nếu không có mục nào khớp."""
    hits = search(question, limit)
    if not hits:
        return ""
    return "\n\n".join(render(t) for _s, t in hits)


def toc():
    """Mục lục (để hỏi người dùng muốn xem gì khi câu hỏi không khớp mục nào)."""
    return "\n".join("• %s (%s)" % (t[2], KIND_VN[t[1]]) for t in TOPICS)
