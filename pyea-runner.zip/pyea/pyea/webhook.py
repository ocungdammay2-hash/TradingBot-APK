"""
Nhận tín hiệu WEBHOOK (TradingView) và đổi thành lệnh qua một `executor` (cổng MT / phiên PyEA). Theo PDF «PyEA thiếu gì» phần webhook.
Lớp bảo vệ (đều tuỳ chọn trừ secret): secret dùng chung (so sánh hằng thời gian) · HMAC-SHA256 nếu nguồn ký được · danh sách IP cho phép ·
chống trùng theo `id` (idempotency) · giới hạn tần suất · kiểm tra lệnh (mã cho phép, khối lượng tối đa) · `dry_run`.
Sự thật về TradingView (tài liệu chính thức): chỉ cổng 80/443, timeout 3 giây, IP nguồn 52.89.214.238 · 34.212.75.30 · 54.218.53.128 · 52.32.178.7,
KHÔNG ký HMAC được (nên secret nằm trong nội dung JSON), không hỗ trợ IPv6. => handler PHẢI trả lời < 3 giây: executor chạy ở luồng riêng khi `async_exec=True`.
Payload: {"secret":"...","id":"alert-123","action":"buy|sell|close|close_all","symbol":"EURUSD","volume":0.01,"sl":0,"tp":0,"comment":"..."}
"""
import hashlib
import hmac
import json
import threading
import time

TV_IPS = ("52.89.214.238", "34.212.75.30", "54.218.53.128", "52.32.178.7")
ACTIONS = ("buy", "sell", "close", "close_all")
# Bí danh thường gặp trong alert TradingView ({{strategy.order.action}} cho "buy"/"sell"; người dùng hay viết long/short/exit/flat)
ACTION_ALIASES = {"long": "buy", "enter_long": "buy", "short": "sell", "enter_short": "sell", "exit": "close", "flat": "close",
                  "close_long": "close", "close_short": "close", "closeall": "close_all", "exit_all": "close_all", "flatten": "close_all"}
_PERP_SUFFIXES = (".P", ".PERP", "PERP")


def normalize_symbol(raw, symbol_map=None, suffix=""):
    """Mã TradingView -> mã của sàn đang nối.
    Thứ tự: (1) `symbol_map` khớp NGUYÊN VĂN (không phân biệt hoa/thường, vd 'BINANCE:BTCUSDT' hoặc 'VN30F1M') ->
    (2) bỏ tiền tố sàn 'SÀN:' -> (3) bỏ hậu tố hợp đồng treo '.P'/'.PERP' và '1!'/'2!' -> (4) tra lại `symbol_map` -> (5) thêm `suffix` (vd '.m' của Exness).
    Không đoán tên mã sàn: chuyển đổi chuyên biệt (VN30F1M -> VN30F2611...) phải khai trong `symbol_map`."""
    m = {str(k).upper(): str(v).upper() for k, v in (symbol_map or {}).items()}
    s = str(raw or "").strip().upper()
    if s in m:
        return m[s]
    if ":" in s:
        s = s.split(":", 1)[1]
    if s in m:
        return m[s]
    for suf in _PERP_SUFFIXES:
        if s.endswith(suf) and len(s) > len(suf):
            s = s[:-len(suf)]
            break
    if len(s) > 2 and s[-1] == "!" and s[-2].isdigit():
        s = s[:-2]
    s = m.get(s, s)
    return s + suffix if (suffix and not s.endswith(suffix.upper())) else s


class WebhookError(Exception):
    def __init__(self, msg, status=400, code="BAD_REQUEST"):
        Exception.__init__(self, msg)
        self.status, self.code = status, code


class WebhookCore:
    def __init__(self, executor, secret, allowed_ips=None, allowed_symbols=None, max_volume=None, rate_per_min=30, id_ttl=3600.0,
                 hmac_secret=None, dry_run=False, async_exec=False, log=None, clock=time.time, symbol_map=None, symbol_suffix=""):
        if not secret or len(secret) < 12:
            raise ValueError("secret phải dài ≥ 12 ký tự")
        self.executor, self.secret, self.hmac_secret = executor, secret, hmac_secret
        self.allowed_ips = set(allowed_ips) if allowed_ips else None
        self.allowed_symbols = {s.upper() for s in allowed_symbols} if allowed_symbols else None
        self.symbol_map, self.symbol_suffix = dict(symbol_map or {}), str(symbol_suffix or "")
        self.max_volume, self.rate, self.id_ttl = max_volume, int(rate_per_min), float(id_ttl)
        self.dry_run, self.async_exec, self.log, self.clock = dry_run, async_exec, log or (lambda *a: None), clock
        self._seen, self._hits, self._lock = {}, [], threading.Lock()

    def _check_rate(self, now):
        self._hits = [t for t in self._hits if now - t < 60.0]
        if len(self._hits) >= self.rate:
            raise WebhookError("quá nhiều tín hiệu/phút", 429, "RATE_LIMIT")
        self._hits.append(now)

    def handle(self, raw, ip="", signature=""):
        """Trả (status, dict). Không bao giờ ném ra ngoài."""
        try:
            return 200, self._handle(raw, ip, signature)
        except WebhookError as e:
            self.log("webhook từ chối %s: %s" % (ip, e))
            return e.status, {"ok": False, "error": str(e), "code": e.code}
        except Exception as e:                                    # noqa: BLE001
            self.log("webhook lỗi: %r" % (e,))
            return 500, {"ok": False, "error": "lỗi nội bộ", "code": "ERROR"}

    def _handle(self, raw, ip, signature):
        if self.allowed_ips is not None and ip not in self.allowed_ips:
            raise WebhookError("IP không được phép", 403, "IP_DENIED")
        if len(raw) > 4096:
            raise WebhookError("nội dung quá lớn", 413, "TOO_LARGE")
        if self.hmac_secret:
            want = hmac.new(self.hmac_secret.encode(), raw, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(want, (signature or "").strip().lower()):
                raise WebhookError("sai chữ ký", 401, "BAD_SIGNATURE")
        try:
            b = json.loads(raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else raw)
        except ValueError:
            raise WebhookError("nội dung không phải JSON")
        if not isinstance(b, dict):
            raise WebhookError("JSON phải là đối tượng")
        if not hmac.compare_digest(str(b.get("secret", "")).encode(), self.secret.encode()):
            raise WebhookError("sai secret", 401, "BAD_SECRET")
        order = self._validate(b)
        now = self.clock()
        with self._lock:
            self._check_rate(now)
            self._seen = {k: t for k, t in self._seen.items() if now - t < self.id_ttl}
            aid = str(b.get("id") or "")
            if aid:
                if aid in self._seen:
                    return {"ok": True, "duplicate": True, "id": aid}
                self._seen[aid] = now
        if self.dry_run:
            return {"ok": True, "dry_run": True, "order": order}
        if self.async_exec:
            threading.Thread(target=self._run, args=(order,), daemon=True).start()
            return {"ok": True, "accepted": True, "order": order}
        return {"ok": True, "result": self._run(order), "order": order}

    def _run(self, order):
        try:
            return self.executor(order)
        except Exception as e:                                    # noqa: BLE001
            self.log("executor lỗi: %r" % (e,))
            return {"ok": False, "error": str(e)}

    def _validate(self, b):
        act = str(b.get("action", "")).strip().lower().replace(" ", "_")
        act = ACTION_ALIASES.get(act, act)
        if act not in ACTIONS:
            raise WebhookError("action phải thuộc %s (hoặc bí danh %s)" % (ACTIONS, sorted(ACTION_ALIASES)))
        sym = normalize_symbol(b.get("symbol", ""), self.symbol_map, self.symbol_suffix)
        if act != "close_all" and not sym:
            raise WebhookError("thiếu symbol")
        if self.allowed_symbols is not None and sym and sym not in self.allowed_symbols:
            raise WebhookError("mã %s không nằm trong danh sách cho phép" % sym, 403, "SYMBOL_DENIED")
        o = {"action": act, "symbol": sym, "comment": str(b.get("comment") or "tv")[:30]}
        if act in ("buy", "sell"):
            try:
                vol = float(b.get("volume", b.get("qty", b.get("quantity", b.get("contracts")))))
            except (TypeError, ValueError):
                raise WebhookError("volume không hợp lệ")
            if not (vol > 0):
                raise WebhookError("volume phải > 0")
            if self.max_volume is not None and vol > self.max_volume:
                raise WebhookError("volume vượt mức tối đa %s" % self.max_volume, 403, "VOLUME_DENIED")
            o["volume"] = vol
            for k in ("sl", "tp"):
                v = float(b.get(k) or 0)
                if v < 0:
                    raise WebhookError("%s không được âm" % k)
                o[k] = v
        return o


def gateway_executor(backend):
    """Đổi lệnh webhook thành gọi backend của mt_gateway (market/close/positions/modify_position)."""
    def run(o):
        a, sym = o["action"], o["symbol"]
        if a in ("buy", "sell"):
            r = backend.market(sym, a, o["volume"], o.get("comment", "tv"))
            if (o.get("sl") or o.get("tp")) and r.get("position_id"):
                backend.modify_position(r["position_id"], o.get("sl", 0), o.get("tp", 0))
            return r
        ps = backend.positions()
        ps = ps.get("positions", ps) if isinstance(ps, dict) else ps
        done = []
        for p in ps:
            if a == "close_all" or str(p.get("symbol", "")).upper() == sym:
                done.append(backend.close(str(p.get("id"))))
        return {"closed": len(done)}
    return run


def session_executor(session, owner="webhook"):
    """Đổi lệnh webhook thành gọi TradingSession của PyEA (chạy trong app, không cần cổng MT). Cùng định dạng kết quả với gateway_executor."""
    def run(o):
        a, sym = o["action"], o["symbol"]
        if a in ("buy", "sell"):
            r = session.open_position(sym, a, o["volume"], o.get("sl", 0.0), o.get("tp", 0.0), o.get("comment", "tv"), owner, "webhook TradingView")
            return {"ok": bool(r), "retcode": str(getattr(r, "retcode", "")), "message": getattr(r, "message", "")}
        n = session.close_all("webhook", "webhook TradingView", None if a == "close_all" else sym)
        return {"ok": True, "closed": n}
    return run
