"""
Gọi API Android bằng pyjnius - KHÔNG import Kivy (dùng được trong cả UI lẫn dịch vụ nền).
Mọi hàm đều an toàn: lỗi -> trả về False/None, không làm sập app.
"""
import os
import traceback

IS_ANDROID = "ANDROID_ARGUMENT" in os.environ or "ANDROID_PRIVATE" in os.environ
SERVICE_NAME = "Botservice"
CH_RUN = "pyea_run"
CH_ALARM = "pyea_alarm"
NOTIF_RUN = 7001
_alarm_seq = [7100]
_locks = {}


def _jnius():
    from jnius import autoclass
    return autoclass


def context():
    """Context hiện tại: Service (trong tiến trình dịch vụ) hoặc Activity (trong UI)."""
    ac = _jnius()
    svc = ac("org.kivy.android.PythonService").mService
    if svc is not None:
        return svc
    return ac("org.kivy.android.PythonActivity").mActivity


def package_name():
    return context().getPackageName()


def files_dir():
    """Thư mục files riêng của app (cùng thư mục cho UI và dịch vụ nền)."""
    try:
        return str(context().getFilesDir().getAbsolutePath())
    except Exception:
        return None


def sdk_int():
    try:
        return int(_jnius()("android.os.Build$VERSION").SDK_INT)
    except Exception:
        return 0


# ------------------------------------------------------------------ dịch vụ
WORKER_PREFIX = "Botworker"       # dịch vụ worker cô lập bot: Botworker0..N (buildozer.spec, service_botworker.py) - xem botproc.py


def worker_name(slot):
    return "%s%d" % (WORKER_PREFIX, int(slot))


def _service_class(name):
    return _jnius()("%s.Service%s" % (package_name(), name))


def worker_services_present(slots=None):
    """True nếu APK có đủ lớp dịch vụ worker (APK dựng từ buildozer.spec cũ thì không có). Ném ngoại lệ nếu không phải Android thật."""
    from .botproc import WORKER_SLOTS
    n = int(slots or WORKER_SLOTS)
    for k in range(n):
        try:
            _service_class(worker_name(k))
        except Exception:                                    # noqa: BLE001 - pyjnius ném JavaException/ClassNotFound: lớp không tồn tại
            return False
    return True


def start_service(argument="", title="PyEA Runner", text="Bot đang chạy nền", name=SERVICE_NAME, foreground=True):
    """Khởi động một dịch vụ p4a. Dịch vụ chính (foreground) do UI gọi; worker (foreground=False) do dịch vụ chính/UI gọi để cô lập bot.
    Ngữ cảnh: trong tiến trình dịch vụ không có Activity -> dùng context() (Service cũng là Context). Trả về (ok, lỗi)."""
    if not IS_ANDROID:
        return False, "không phải Android"
    try:
        cls = _service_class(name)
        ctx = context()
        if foreground:
            try:
                cls.start(ctx, "icon", title, text, argument)
            except Exception:
                cls.start(ctx, argument)
        else:
            try:
                cls.start(ctx, argument)                       # tài liệu p4a: service.start(mActivity, argument)
            except Exception:
                cls.start(ctx, "icon", title, text, argument)
        return True, ""
    except Exception:
        return False, traceback.format_exc(limit=3)


def stop_service(name=SERVICE_NAME):
    """Dừng dịch vụ (p4a: onDestroy -> Process.killProcess của CHÍNH tiến trình dịch vụ đó). Bất đồng bộ."""
    try:
        _service_class(name).stop(context())
        return True
    except Exception:
        return False


def _channel(ctx, cid, name, importance, vibrate=False, silent=False):
    ac = _jnius()
    if sdk_int() < 26:
        return
    NM = ac("android.app.NotificationManager")
    NC = ac("android.app.NotificationChannel")
    ch = NC(cid, name, importance)
    ch.enableVibration(bool(vibrate))
    if silent:
        ch.setSound(None, None)                 # Android 8+: âm thanh/rung là thuộc tính của KÊNH, không đổi được sau khi tạo -> mỗi tổ hợp một kênh
    ctx.getSystemService(ac("android.content.Context").NOTIFICATION_SERVICE).createNotificationChannel(ch)


def _builder(ctx, cid):
    ac = _jnius()
    B = ac("android.app.Notification$Builder")
    return B(ctx, cid) if sdk_int() >= 26 else B(ctx)


def _launch_intent(ctx):
    ac = _jnius()
    pm = ctx.getPackageManager()
    intent = pm.getLaunchIntentForPackage(ctx.getPackageName())
    PI = ac("android.app.PendingIntent")
    flags = PI.FLAG_UPDATE_CURRENT | (PI.FLAG_IMMUTABLE if sdk_int() >= 23 else 0)
    return PI.getActivity(ctx, 0, intent, flags)


def set_service_notification(title, text):
    """Cập nhật thông báo foreground của dịch vụ (hiện trên thanh trạng thái). Chạy trong tiến trình dịch vụ."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        svc = ac("org.kivy.android.PythonService").mService
        if svc is None:
            return False
        _channel(svc, CH_RUN, "Bot đang chạy", ac("android.app.NotificationManager").IMPORTANCE_LOW)
        b = _builder(svc, CH_RUN)
        b.setSmallIcon(svc.getApplicationInfo().icon)
        b.setContentTitle(title)
        b.setContentText(text)
        b.setOngoing(True)
        b.setContentIntent(_launch_intent(svc))
        svc.startForeground(NOTIF_RUN, b.build())
        return True
    except Exception:
        return False


CH_ALARM_DND = "pyea_alarm_dnd"


def alarm_channel_id(sound, vibrate, quiet=False):
    """(id kênh, tên) cho tổ hợp âm/rung. Tổ hợp mặc định (có cả hai) giữ nguyên id cũ để không tạo kênh thừa.
    quiet=True («Không làm phiền»): kênh riêng, mức thấp, KHÔNG âm/rung - cảnh báo vẫn hiện trong khay thông báo."""
    if quiet:
        return CH_ALARM_DND, "Cảnh báo bot (đang không làm phiền)"
    if sound and vibrate:
        return CH_ALARM, "Cảnh báo bot"
    return "%s_%s%s" % (CH_ALARM, "s" if sound else "x", "v" if vibrate else "x"), \
        "Cảnh báo bot (%s)" % ", ".join(n for n, on in (("âm thanh", sound), ("rung", vibrate)) if on) if (sound or vibrate) else "Cảnh báo bot (im lặng)"


def notify_alarm(title, text, quiet=False):
    """Thông báo CẢNH BÁO (rung + âm báo, mức quan trọng cao). Dùng được từ UI hoặc dịch vụ.
    quiet=True: đang «Không làm phiền» -> vẫn đăng thông báo nhưng IM LẶNG (kênh riêng mức thấp, không âm/rung)."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = context()
        NM = ac("android.app.NotificationManager")
        from .prefs import alarm_prefs
        sound, vib = (False, False) if quiet else alarm_prefs()
        cid, label = alarm_channel_id(sound, vib, quiet)
        _channel(ctx, cid, label, NM.IMPORTANCE_LOW if quiet else (NM.IMPORTANCE_HIGH if (sound or vib) else NM.IMPORTANCE_DEFAULT),
                 vibrate=vib, silent=not sound)
        b = _builder(ctx, cid)
        b.setSmallIcon(ctx.getApplicationInfo().icon)
        b.setContentTitle(title)
        b.setContentText(text)
        b.setStyle(ac("android.app.Notification$BigTextStyle")().bigText(text))
        b.setAutoCancel(True)
        b.setContentIntent(_launch_intent(ctx))
        if sdk_int() < 26:
            b.setDefaults((1 if sound else 0) | (2 if vib else 0))      # Notification.DEFAULT_SOUND=1, DEFAULT_VIBRATE=2
            b.setPriority(-1 if quiet else (1 if (sound or vib) else 0))   # PRIORITY_LOW / HIGH / DEFAULT
        _alarm_seq[0] += 1
        ctx.getSystemService(ac("android.content.Context").NOTIFICATION_SERVICE).notify(_alarm_seq[0], b.build())
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ watchdog (AlarmManager)
WD_REQUEST = 7201


def _watchdog_pending(ctx, ac, argument=""):
    """PendingIntent khởi động lại dịch vụ foreground (cùng Intent mà p4a dựng cho `start`). Android 8+ dùng getForegroundService (cách chính thức để báo thức
    khởi động dịch vụ foreground); trước đó getService. FLAG_IMMUTABLE bắt buộc khi target API 31+."""
    cls = ac("%s.Service%s" % (ctx.getPackageName(), SERVICE_NAME))
    intent = cls.getDefaultIntent(ctx, "icon", "PyEA Runner", "Khôi phục phiên sau khi bị hệ thống dừng", argument)
    PI = ac("android.app.PendingIntent")
    flags = PI.FLAG_UPDATE_CURRENT | (PI.FLAG_IMMUTABLE if sdk_int() >= 23 else 0)
    if sdk_int() >= 26:
        return PI.getForegroundService(ctx, WD_REQUEST, intent, flags)
    return PI.getService(ctx, WD_REQUEST, intent, flags)


def schedule_watchdog(delay_s, argument=""):
    """Đặt (hoặc DỜI - cùng PendingIntent thì thay báo thức cũ) báo thức nổ sau `delay_s` giây để dựng lại dịch vụ. Dùng setExactAndAllowWhileIdle khi được phép,
    nếu không (Android 12+ chưa cấp «báo thức chính xác») thì setAndAllowWhileIdle - không cần quyền, có thể trễ khi máy ở Doze. Trả về True nếu đã đặt."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = context()
        Context = ac("android.content.Context")
        am = ctx.getSystemService(Context.ALARM_SERVICE)
        pi = _watchdog_pending(ctx, ac, argument)
        AM = ac("android.app.AlarmManager")
        when = int(ac("java.lang.System").currentTimeMillis()) + int(float(delay_s) * 1000)
        exact = sdk_int() < 31 or bool(am.canScheduleExactAlarms())
        if exact:
            am.setExactAndAllowWhileIdle(AM.RTC_WAKEUP, when, pi)
        else:
            am.setAndAllowWhileIdle(AM.RTC_WAKEUP, when, pi)
        return True
    except Exception:
        return False


def cancel_watchdog():
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = context()
        am = ctx.getSystemService(ac("android.content.Context").ALARM_SERVICE)
        am.cancel(_watchdog_pending(ctx, ac))
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ giữ CPU/Wi-Fi thức
def acquire_wakelocks():
    """Partial wake lock + Wi-Fi lock cho tiến trình dịch vụ (tắt màn hình vẫn lấy giá được)."""
    if not IS_ANDROID or _locks:
        return bool(_locks)
    try:
        ac = _jnius()
        ctx = context()
        Context = ac("android.content.Context")
        pm = ctx.getSystemService(Context.POWER_SERVICE)
        wl = pm.newWakeLock(ac("android.os.PowerManager").PARTIAL_WAKE_LOCK, "pyea:service")
        wl.setReferenceCounted(False)
        wl.acquire()
        _locks["cpu"] = wl
    except Exception:
        pass
    try:
        wm = context().getApplicationContext().getSystemService(ac("android.content.Context").WIFI_SERVICE)
        wf = wm.createWifiLock(3, "pyea:wifi")      # WIFI_MODE_FULL_HIGH_PERF
        wf.setReferenceCounted(False)
        wf.acquire()
        _locks["wifi"] = wf
    except Exception:
        pass
    return bool(_locks)


def release_wakelocks():
    for k, lk in list(_locks.items()):
        try:
            if lk.isHeld():
                lk.release()
        except Exception:
            pass
        _locks.pop(k, None)


# ------------------------------------------------------------------ chống chụp / quay màn hình
FLAG_SECURE = 0x2000                  # WindowManager.LayoutParams.FLAG_SECURE
_secure_state = {"on": None}


def set_secure(on):
    """Bật/tắt FLAG_SECURE cho cửa sổ app: chặn ảnh chụp màn hình, quay màn hình và ảnh xem trước ở màn hình đa nhiệm.
    Gọi từ luồng bất kỳ (tự chuyển sang luồng UI của Android). -> True nếu đã gửi lệnh (không phải Android: False)."""
    on = bool(on)
    if _secure_state["on"] == on:
        return True
    if not IS_ANDROID:
        return False
    try:
        from android.runnable import run_on_ui_thread
        act = _jnius()("org.kivy.android.PythonActivity").mActivity

        @run_on_ui_thread
        def apply():
            win = act.getWindow()
            if on:
                win.addFlags(FLAG_SECURE)
            else:
                win.clearFlags(FLAG_SECURE)
        apply()
        _secure_state["on"] = on
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ quyền / pin
def is_ignoring_battery_optimizations():
    if not IS_ANDROID:
        return True
    try:
        ac = _jnius()
        ctx = context()
        pm = ctx.getSystemService(ac("android.content.Context").POWER_SERVICE)
        return bool(pm.isIgnoringBatteryOptimizations(ctx.getPackageName()))
    except Exception:
        return True


def request_ignore_battery_optimizations():
    """Mở hộp thoại hệ thống xin loại app khỏi tối ưu pin (để Android không giết bot nền)."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = ac("org.kivy.android.PythonActivity").mActivity
        Intent = ac("android.content.Intent")
        Uri = ac("android.net.Uri")
        i = Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")
        i.setData(Uri.parse("package:" + ctx.getPackageName()))
        ctx.startActivity(i)
        return True
    except Exception:
        return False


def request_notification_permission():
    """Android 13+: xin quyền hiện thông báo."""
    if not IS_ANDROID or sdk_int() < 33:
        return False
    try:
        from android.permissions import request_permissions
        request_permissions(["android.permission.POST_NOTIFICATIONS"])
        return True
    except Exception:
        return False


def device_info():
    try:
        ac = _jnius()
        B = ac("android.os.Build")
        V = ac("android.os.Build$VERSION")
        abis = ",".join(str(x) for x in B.SUPPORTED_ABIS)
        return {"model": "%s %s" % (B.MANUFACTURER, B.MODEL), "android": str(V.RELEASE), "sdk": int(V.SDK_INT), "abis": abis}
    except Exception:
        return {}
