"""«Công tắc người chết» (dead man's switch) cho dịch vụ nền - phần LOGIC, không phụ thuộc Android.

Vấn đề: Android (đặc biệt các hãng tuỳ biến mạnh) có thể giết tiến trình dịch vụ; cờ sticky chỉ nhờ hệ điều hành khởi động lại khi nó muốn.
Cách làm (kinh điển với AlarmManager): khi phiên ĐANG cần chạy, dịch vụ liên tục DỜI một báo thức về `interval` giây sau. Báo thức nào cũng
không bao giờ kịp nổ khi dịch vụ còn sống. Nếu tiến trình bị giết thì không ai dời nữa -> báo thức nổ -> Android dựng lại dịch vụ -> `ServiceHost._maybe_resume`
khôi phục phiên + sổ lệnh (đã có sẵn, kèm chặn vòng khởi động lại liên tục). Người dùng chủ động dừng phiên -> `want=False` -> huỷ báo thức.
(Người dùng «Buộc dừng» ứng dụng trong Cài đặt Android: hệ điều hành tự xoá mọi báo thức của app nên không bị dựng lại ngoài ý muốn.)

`arm(delay_s) -> bool` và `cancel() -> bool` do nơi gọi truyền vào (Android: `android_native.schedule_watchdog/cancel_watchdog`) nên logic này kiểm thử được
không cần thiết bị."""
import time


class Watchdog:
    def __init__(self, arm, cancel, interval_s=300.0, clock=time.time, retry_s=60.0):
        self._arm, self._cancel, self._clock = arm, cancel, clock
        self.interval = max(30.0, float(interval_s))
        self.retry_s = float(retry_s)
        self.armed = False
        self.last_arm = 0.0
        self.next_try = 0.0
        self.arms = 0
        self.error = ""
        self._synced = False         # đã huỷ ít nhất một lần trong tiến trình này (báo thức của tiến trình trước có thể còn treo)

    def set_interval(self, seconds):
        self.interval = max(30.0, float(seconds))

    def tick(self, want):
        """Gọi định kỳ (vài giây/lần). want=True: giữ báo thức nằm ở now+interval (dời khi đã qua 40% chu kỳ). want=False: huỷ nếu đang đặt."""
        now = self._clock()
        if want:
            if self.armed and now - self.last_arm < self.interval * 0.4:
                return
            if now < self.next_try:
                return
            try:
                ok = bool(self._arm(self.interval))
                self.error = "" if ok else "không đặt được báo thức"
            except Exception as e:                                   # noqa: BLE001 - watchdog hỏng không được làm sập dịch vụ
                ok, self.error = False, str(e)[:160]
            if ok:
                self.armed, self.last_arm, self.next_try = True, now, 0.0
                self.arms += 1
            else:
                self.next_try = now + self.retry_s                  # đừng gọi lại mỗi vòng
        elif self.armed or not self._synced:
            try:
                self._cancel()
            except Exception as e:                                   # noqa: BLE001
                self.error = str(e)[:160]
            self.armed, self._synced = False, True
            self.next_try = 0.0

    def stop(self):
        self.tick(False)
