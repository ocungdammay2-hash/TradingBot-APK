"""Tuỳ chọn dùng chung toàn app: giờ hiển thị (máy / UTC / lệch giờ tự chọn) và âm thanh/rung của thông báo.
Được nạp từ settings bằng `apply(settings)` (UI gọi khi khởi động và khi lưu cài đặt; dịch vụ nền gọi khi mở phiên).
Chỉ ảnh hưởng CÁCH HIỂN THỊ - mọi thời gian bên trong vỏ/bot vẫn là epoch UTC."""
import time

_state = {"mode": "local", "offset": 0.0, "sound": True, "vibrate": True, "lot": "native", "contracts": {}}


def apply(settings):
    s = settings or {}
    mode = str(s.get("time_display") or "local")
    _state["mode"] = mode if mode in ("local", "utc", "offset") else "local"
    try:
        _state["offset"] = max(-14.0, min(14.0, float(s.get("time_offset_hours") or 0.0)))
    except (TypeError, ValueError):
        _state["offset"] = 0.0
    lot = str(s.get("lot_display") or "native")
    _state["lot"] = lot if lot in ("native", "units", "both") else "native"
    _state["sound"] = bool(s.get("notify_sound", True))
    _state["vibrate"] = bool(s.get("notify_vibrate", True))
    try:
        from . import dnd
        dnd.apply(s)                                    # khung yên tĩnh + «vẫn kêu cảnh báo nghiêm trọng»
    except Exception:                                  # noqa: BLE001
        pass
    try:
        from . import redact
        redact.learn_settings(s)                       # mọi nơi ghi nhật ký/chat từ giờ che đúng các khoá này
    except Exception:                                  # noqa: BLE001 - che bí mật không được làm hỏng việc nạp cài đặt
        pass


def fmt_time(fmt, ts):
    """Như time.strftime(fmt, time.localtime(ts)) nhưng theo tuỳ chọn «Giờ hiển thị»."""
    ts = float(ts)
    m = _state["mode"]
    if m == "utc":
        return time.strftime(fmt, time.gmtime(ts))
    if m == "offset":
        return time.strftime(fmt, time.gmtime(ts + _state["offset"] * 3600.0))
    return time.strftime(fmt, time.localtime(ts))


def time_label():
    """Nhãn múi giờ đang hiển thị, vd 'giờ máy', 'UTC', 'UTC+7'."""
    m = _state["mode"]
    if m == "utc":
        return "UTC"
    if m == "offset":
        o = _state["offset"]
        return "UTC%+g" % o if o else "UTC"
    return "giờ máy"


def alarm_prefs():
    """(âm_thanh, rung) cho thông báo cảnh báo."""
    return _state["sound"], _state["vibrate"]


def set_contracts(d):
    """Kích thước hợp đồng theo mã ({symbol: contract_size}, chỉ các mã ≠ 1) do phiên gửi lên cùng snapshot."""
    out = {}
    for k, v in (d or {}).items():
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if f > 0 and f != 1.0:
            out[str(k)] = f
    _state["contracts"] = out


def fmt_vol(volume, symbol=None):
    """Khối lượng để HIỂN THỊ theo tuỳ chọn «Hiển thị khối lượng»: native = đúng như sàn/MT (lot), units = nhân kích thước hợp đồng,
    both = «0.1 lot (10000 đv)». Mã có hợp đồng = 1 (crypto, OANDA...) luôn hiện như cũ. Chỉ đổi cách hiển thị - số liệu bên trong không đổi."""
    v = float(volume)
    cs = _state["contracts"].get(symbol, 1.0) if symbol else 1.0
    m = _state["lot"]
    if cs == 1.0 or m == "native":
        return "%.6g" % v
    if m == "units":
        return "%.6g đv" % (v * cs)
    return "%.6g lot (%.6g đv)" % (v, v * cs)
