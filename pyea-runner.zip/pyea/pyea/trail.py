"""TRAILING STOP + HÒA VỐN (break-even) cho vị thế đang mở - như chuột phải «Trailing Stop» của MT5.

Luật gắn theo TỪNG VỊ THẾ (id vị thế của app), do NGƯỜI DÙNG đặt (không bot/AI nào tự đặt). Mọi khoảng cách là KHOẢNG GIÁ tuyệt đối
(đơn vị giá của mã, vd 0.0020 với EURUSD), không phải pip - để không phụ thuộc quy ước từng sàn.

Luật = {"distance": d, "start": s, "step": t, "be_at": b, "be_offset": o}  (số 0/None = không dùng mục đó)
  * Trailing: khi lãi >= `start` (mặc định = `distance`), SL = giá - distance (mua: dùng bid; bán: ask + distance). SL CHỈ DỜI THEO CHIỀU CÓ LỢI
    (mua: lên; bán: xuống), và chỉ khi tiến thêm >= `step` (mặc định 10% distance - chống gọi sàn dồn dập).
  * Hòa vốn: khi lãi >= `be_at`, SL được kéo về giá mở ± `be_offset` (chốt phí), nếu SL hiện tại còn xấu hơn mức đó.
  * Cả hai cùng bật: lấy mức TỐT HƠN cho vị thế.
Hàm `target_sl` thuần (không I/O) nên test được kỹ; TrailMixin chỉ nối nó vào vòng tick và `modify_position` (nên đi qua đúng kiểm tra stops_level/freeze
và đồng bộ SL native như sửa tay). Luật lưu ở trails.json cạnh state nên sống qua khởi động lại; vị thế đã đóng thì luật bị xoá.
"""
import json
import os
import threading
import time

MIN_INTERVAL = 2.0              # giây, tối thiểu giữa hai lần sửa SL của MỘT vị thế
MAX_RULES = 200


def clean_rule(rule):
    """Chuẩn hoá luật người dùng nhập. Trả dict số dương hoặc ValueError (tiếng Việt). Luật rỗng (không mục nào bật) -> None."""
    if rule is None:
        return None
    out = {}
    for k in ("distance", "start", "step", "be_at", "be_offset"):
        v = rule.get(k) if isinstance(rule, dict) else None
        if v in (None, "", 0, 0.0):
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            raise ValueError("«%s» không phải số" % k)
        if f != f or f in (float("inf"), float("-inf")) or f < 0:
            raise ValueError("«%s» phải là số không âm" % k)
        if f:
            out[k] = f
    if ("start" in out or "step" in out) and "distance" not in out:
        raise ValueError("«start»/«step» chỉ dùng cùng khoảng trailing «distance»")
    if "be_offset" in out and "be_at" not in out:
        raise ValueError("«be_offset» chỉ dùng cùng «be_at» (ngưỡng hòa vốn)")
    if "distance" not in out and "be_at" not in out:
        return None
    return out


def target_sl(rule, side, open_price, cur_sl, bid, ask):
    """SL mới theo luật hoặc None (không đổi). Giá dùng để đóng vị thế: mua = bid, bán = ask."""
    if not rule:
        return None
    buy = side == "buy"
    px = bid if buy else ask
    if not px or px <= 0:
        return None
    profit = (px - open_price) if buy else (open_price - px)
    cands = []
    be = rule.get("be_at")
    if be and profit >= be:
        off = rule.get("be_offset", 0.0)
        cands.append(open_price + off if buy else open_price - off)
    d = rule.get("distance")
    if d:
        start = rule.get("start", d)
        if profit >= start:
            cands.append(px - d if buy else px + d)
    if not cands:
        return None
    new = max(cands) if buy else min(cands)
    step = rule.get("step", (d or 0.0) * 0.1)
    if cur_sl:
        gain = (new - cur_sl) if buy else (cur_sl - new)
        if gain <= 0 or gain < step - 1e-12:
            return None
    elif (buy and new >= px) or ((not buy) and new <= px):          # SL phải nằm phía lỗ của giá hiện tại
        return None
    return new


class TrailMixin:
    def _trail_init(self):
        self._trail_lock = threading.RLock()
        self._trails = {}
        self._trail_last = {}
        self._trail_warn = {}
        self._trail_load()

    def _trail_path(self):
        sf = getattr(self, "state_file", None)
        return os.path.join(os.path.dirname(os.path.abspath(sf)), "trails.json") if sf else None

    def _trail_load(self):
        p = self._trail_path()
        if not p or not os.path.exists(p):
            return
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            self._trails = {int(k): clean_rule(v) for k, v in (d.get("rules") or {}).items() if clean_rule(v)}
        except (OSError, ValueError, TypeError, AttributeError):
            self._trails = {}

    def _trail_save(self):
        p = self._trail_path()
        if not p:
            return
        tmp = p + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"rules": {str(k): v for k, v in self._trails.items()}}, f)
            os.replace(tmp, p)
        except OSError:
            pass

    def trail_rules(self):
        with self._trail_lock:
            return {k: dict(v) for k, v in self._trails.items()}

    def set_trailing(self, pos_id, rule):
        """Đặt/xoá luật cho một vị thế (rule rỗng/None = xoá). Trả (ok, lời nhắn)."""
        pos_id = int(pos_id)
        try:
            r = clean_rule(rule)
        except ValueError as e:
            return False, str(e)
        with self.lock:
            p = self.account.positions.get(pos_id)
        if p is None:
            return False, "Không có vị thế #%s" % pos_id
        with self._trail_lock:
            if r is None:
                self._trails.pop(pos_id, None)
                msg = "Đã tắt trailing/hòa vốn cho #%d" % pos_id
            else:
                if pos_id not in self._trails and len(self._trails) >= MAX_RULES:
                    return False, "Quá nhiều luật trailing (tối đa %d)" % MAX_RULES
                self._trails[pos_id] = r
                msg = "Đã đặt trailing/hòa vốn cho #%d: %s" % (pos_id, json.dumps(r))
            self._trail_last.pop(pos_id, None)
            self._trail_save()
        self.log(msg)
        return True, msg

    def _check_trails(self, tick):
        if not getattr(self, "_trails", None):
            return
        with self._trail_lock:
            rules = dict(self._trails)
        with self.lock:
            live = set(self.account.positions)
            plist = [self.account.positions[i] for i in rules if i in live and self.account.positions[i].symbol == tick.symbol]
        gone = [i for i in rules if i not in live]
        if gone:
            with self._trail_lock:
                for i in gone:
                    self._trails.pop(i, None)
                    self._trail_last.pop(i, None)
                self._trail_save()
        now = time.time()
        for p in plist:
            if now - self._trail_last.get(p.id, 0.0) < MIN_INTERVAL:
                continue
            new = target_sl(rules[p.id], p.side, p.open_price, p.sl, tick.bid, tick.ask)
            if new is None:
                continue
            self._trail_last[p.id] = now
            res = self.modify_position(p.id, sl=new)
            if not getattr(res, "ok", False):
                if now - self._trail_warn.get(p.id, 0.0) > 60.0:          # sàn từ chối (stops_level...): báo 1 lần/phút, thử lại ở tick sau
                    self._trail_warn[p.id] = now
                    self.log("Trailing #%d không dời được SL tới %.8g: %s" % (p.id, new, getattr(res, "message", "")), "WARN")
            else:
                self.log("Trailing #%d: SL -> %.8g" % (p.id, new))
