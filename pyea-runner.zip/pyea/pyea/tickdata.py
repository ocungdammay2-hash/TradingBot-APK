"""
Tick thật cho backtest từ Binance aggTrades (công khai, không cần key).
Quy tắc đã kiểm chứng trong tài liệu Binance: giới hạn 1000 dòng/lần; cặp startTime/endTime phải < 1 giờ; futures chỉ trả dữ liệu 48 giờ gần nhất
(spot không nêu giới hạn đó); nên dùng HOẶC fromId HOẶC cặp thời gian, không trộn (trộn có thể timeout) -> nhiều giao dịch cùng 1 ms thì chuyển sang fromId.
Giới hạn cứng `max_trades` để bộ nhớ/mạng không phình; nếu bị cắt, backtest chỉ dùng tick thật cho phần đã tải, các nến còn lại rơi về OHLC (có báo cáo).
"""
import time

HOUR_MS = 3600 * 1000
FUTURES_WINDOW_S = 48 * 3600


class TickError(Exception):
    pass


def fetch(feed, symbol, t0, t1, max_trades=300000, progress=None, stop=None, now=None):
    """Tải giao dịch gộp trong [t0, t1) (giây). Trả {"ticks": [(t, giá)] tăng dần, "truncated": bool, "first": t, "last": t, "calls": n}."""
    now = time.time() if now is None else now
    fut = getattr(feed, "p", "").startswith("/fapi")
    if fut and t0 < now - FUTURES_WINDOW_S:
        raise TickError("Binance Futures chỉ cho tải tick của 48 giờ gần nhất (khoảng bạn chọn bắt đầu quá xa). Chọn khoảng gần hơn hoặc dùng Spot.")
    if t1 <= t0:
        raise TickError("Khoảng thời gian rỗng.")
    ticks, seen_last, calls, truncated = [], None, 0, False
    w_start = int(t0 * 1000)
    end_ms = int(t1 * 1000) - 1
    while w_start <= end_ms:
        if stop is not None and stop.is_set():
            truncated = True
            break
        w_end = min(end_ms, w_start + HOUR_MS - 2)                 # < 1 giờ
        cur, use_id = w_start, None
        while True:
            if stop is not None and stop.is_set():
                truncated = True
                break
            rows = feed.agg_trades(symbol, from_id=use_id) if use_id is not None else feed.agg_trades(symbol, cur, w_end)
            calls += 1
            if use_id is not None:
                rows = [r for r in rows if r["t"] * 1000 <= w_end]
            new = [r for r in rows if seen_last is None or r["id"] > seen_last]
            for r in new:
                ticks.append((r["t"], r["p"]))
            if new:
                seen_last = new[-1]["id"]
            if progress:
                progress(len(ticks), max_trades)
            if len(ticks) >= max_trades:
                truncated = True
                break
            if len(rows) < 1000:
                break
            last_t = int(rows[-1]["t"] * 1000)
            if use_id is None and last_t == cur:                  # ≥1000 giao dịch trong cùng 1 ms: nhảy sang phân trang theo fromId
                use_id = rows[-1]["id"] + 1
            elif use_id is not None:
                use_id = rows[-1]["id"] + 1
            else:
                cur = last_t
            if calls > 100000:
                raise TickError("Quá nhiều lần gọi - dừng.")
        if truncated:
            break
        w_start = w_end + 1
    ticks.sort(key=lambda x: x[0])
    return {"ticks": ticks, "truncated": truncated, "calls": calls,
            "first": ticks[0][0] if ticks else None, "last": ticks[-1][0] if ticks else None}


def by_candle(ticks, step):
    """Gom tick theo nến: {thời_gian_mở_nến: [(t, giá), ...]} (giữ thứ tự thời gian)."""
    out = {}
    for t, p in ticks:
        out.setdefault(t - (t % step), []).append((t, p))
    return out
