"""
Ký Ed25519 (RFC 8032) thuần Python - chỉ cần `hashlib`, nên KHÔNG kéo thêm thư viện native vào bản dựng Android.
Nếu máy có `cryptography` thì dùng nó (nhanh hơn ~100 lần); kết quả của hai đường luôn giống hệt (đã kiểm chứng trong test).

  load_private_seed(text)  : nhận PEM PKCS#8 ("-----BEGIN PRIVATE KEY-----"), base64/base64url 32 byte, hoặc hex 64 ký tự
  sign(seed, msg) -> 64 byte        public_key(seed) -> 32 byte

Chỉ có phần ký/suy ra khoá công khai (không xác minh) - đủ cho client API.
"""
import base64
import binascii
import hashlib
import re

P = 2 ** 255 - 19
Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, P - 2, P) % P
_SQRT_M1 = pow(2, (P - 1) // 4, P)

# PKCS#8 của khoá Ed25519: 16 byte tiền tố cố định + 32 byte seed
_PKCS8_PREFIX = bytes.fromhex("302e020100300506032b657004220420")


def _inv(x):
    return pow(x, P - 2, P)


def _add(a, b):
    A = (a[1] - a[0]) * (b[1] - b[0]) % P
    B = (a[1] + a[0]) * (b[1] + b[0]) % P
    C = 2 * a[3] * b[3] * _D % P
    D = 2 * a[2] * b[2] % P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % P, G * H % P, F * G % P, E * H % P)


def _mul(s, pt):
    r = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            r = _add(r, pt)
        pt = _add(pt, pt)
        s >>= 1
    return r


def _compress(pt):
    zi = _inv(pt[2])
    x, y = pt[0] * zi % P, pt[1] * zi % P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _recover_x(y, sign):
    if y >= P:
        return None
    x2 = (y * y - 1) * _inv(_D * y * y + 1) % P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P != 0:
        x = x * _SQRT_M1 % P
    if (x * x - x2) % P != 0:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


_GY = 4 * _inv(5) % P
_GX = _recover_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % P)


def _h(s):
    return hashlib.sha512(s).digest()


def _expand(seed):
    if len(seed) != 32:
        raise ValueError("seed Ed25519 phải đúng 32 byte")
    h = _h(seed)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def _py_public_key(seed):
    a, _ = _expand(seed)
    return _compress(_mul(a, _G))


def _py_sign(seed, msg):
    a, prefix = _expand(seed)
    A = _compress(_mul(a, _G))
    r = int.from_bytes(_h(prefix + msg), "little") % Q
    Rs = _compress(_mul(r, _G))
    k = int.from_bytes(_h(Rs + A + msg), "little") % Q
    s = (r + k * a) % Q
    return Rs + int.to_bytes(s, 32, "little")


try:                                                     # tăng tốc nếu có
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey as _EdKey

    def sign(seed, msg):
        return _EdKey.from_private_bytes(seed).sign(msg)

    def public_key(seed):
        from cryptography.hazmat.primitives import serialization
        return _EdKey.from_private_bytes(seed).public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    BACKEND = "cryptography"
except Exception:                                        # noqa: BLE001 - Android thường rơi vào đây
    sign, public_key = _py_sign, _py_public_key
    BACKEND = "python"


def _b64any(s):
    s = re.sub(r"\s+", "", s)
    s = s.replace("-", "+").replace("_", "/")
    return base64.b64decode(s + "=" * (-len(s) % 4), validate=True)


def load_private_seed(text):
    """Chấp nhận: PEM PKCS#8, base64/base64url (32 byte seed hoặc DER 48 byte), hoặc hex 64 ký tự. Trả 32 byte seed."""
    if text is None:
        raise ValueError("chưa nhập khoá riêng Ed25519")
    t = str(text).strip()
    if not t:
        raise ValueError("chưa nhập khoá riêng Ed25519")
    if "BEGIN" in t:
        m = re.search(r"-----BEGIN ([A-Z ]+)-----(.*?)-----END \1-----", t, re.S)
        if not m:
            raise ValueError("PEM không đúng định dạng (thiếu dòng BEGIN/END)")
        if "ENCRYPTED" in m.group(1):
            raise ValueError("khoá PEM đang được đặt mật khẩu - hãy xuất lại khoá không mật khẩu")
        try:
            der = _b64any(m.group(2))
        except (binascii.Error, ValueError):
            raise ValueError("PEM không giải mã được base64")
        if der.startswith(_PKCS8_PREFIX) and len(der) == 48:
            return der[16:]
        raise ValueError("PEM không phải khoá riêng Ed25519 dạng PKCS#8 (48 byte)")
    compact = re.sub(r"\s+", "", t)
    if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
        return bytes.fromhex(compact)
    try:
        raw = _b64any(compact)
    except (binascii.Error, ValueError):
        raise ValueError("khoá riêng không đọc được: hãy dán PEM, base64 hoặc hex 64 ký tự")
    if len(raw) == 32:
        return raw
    if len(raw) == 48 and raw.startswith(_PKCS8_PREFIX):
        return raw[16:]
    raise ValueError("khoá riêng có %d byte, cần 32 (seed) hoặc 48 (PKCS#8)" % len(raw))


def b64u(b):
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")
