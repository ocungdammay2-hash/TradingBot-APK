"""Giao diện «MT5 trên đám mây MetaApi» (TUỲ CHỌN KHÁC, không phải «Kết nối MT5 nhanh» - cái đó là MT5 thật trong giả lập, pyea/ui_mt5emu.py): nhập login + mật khẩu + server (+ token MetaApi, một lần) -> app tự tạo/bật tài khoản trên MetaApi và đặt sẵn nguồn
«metaapi» trong Cài đặt. Logic và lỗi ở pyea/mt5quick.py. Mật khẩu MT chỉ nằm trong ô nhập, bị xoá ngay khi xong, KHÔNG lưu vào cài đặt."""
import threading

from kivy.clock import mainthread
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout

from . import mt5quick
from .ui_widgets import AMBER, BLUE, DOWN, MUTED, PANEL2, UP, StyledPopup, mk_input, mk_spinner, mkbtn, popup, vscroll, wlabel


def mt5quick_dialog(app):
    form = app.settings_tab.gform
    cur = {}
    try:
        cur = form.read()[0] if form else {}
    except Exception:
        cur = {}
    token0 = str(cur.get("metaapi_token") or app.settings.get("metaapi_token") or "")
    box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8), size_hint_y=None)
    box.bind(minimum_height=box.setter("height"))
    box.add_widget(wlabel("Nhập tài khoản MT5 của bạn - app tự lo phần còn lại, KHÔNG cài thêm gì. MT5 chạy trên đám mây MetaApi (dịch vụ bên thứ ba: có gói "
                          "miễn phí/dùng thử, sau đó tính phí). Mật khẩu chỉ gửi tới MetaApi, app KHÔNG lưu.\nChưa có token? metaapi.cloud → đăng ký → Tokens "
                          "(chỉ làm một lần). Nên thử bằng tài khoản DEMO trước.", 12, MUTED))
    login = mk_input("", "Login MT5 (chữ số)", input_filter="int")
    pw = mk_input("", "Mật khẩu MT5 (giao dịch hoặc investor)", password=True)
    server = mk_input("", "Tên server (vd ICMarketsSC-Demo)")
    tok = mk_input(token0, "Token MetaApi (dán một lần)", password=True)
    plat = mk_spinner("mt5", mt5quick.PLATFORMS)
    for w in (login, pw, server, tok, plat):
        box.add_widget(w)
    status = wlabel("", 12, MUTED)
    box.add_widget(status)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
    pop = StyledPopup(title="MT5 trên đám mây MetaApi", content=vscroll(box), size_hint=(0.94, 0.9), auto_dismiss=False)
    go_btn = mkbtn("Kết nối", BLUE)

    @mainthread
    def say(text, color=MUTED):
        status.text, status.color = text, color

    @mainthread
    def finish(res, err):
        pw.text = ""                                         # xoá mật khẩu khỏi ô ngay khi xong
        go_btn.disabled = False
        res = res or (err.result if err is not None else None)
        if err is not None and not res:
            say(str(err), DOWN)
            return
        # có account id (kể cả chưa nối): đặt sẵn nguồn metaapi trong Cài đặt rồi lưu
        s = mt5quick.apply_settings({}, res, tok.text)
        try:
            form.update_values({k: s[k] for k in ("exchange", "metaapi_token", "metaapi_account", "metaapi_region")})
        except Exception:
            pass
        saved = app.save_forms(False)
        pop.dismiss()
        text = mt5quick.summary(res) + ("" if saved else "\n\nChưa lưu được cài đặt: mở tab Cài đặt, sửa ô báo lỗi rồi bấm Lưu.")
        popup("MT5 trên đám mây MetaApi", text, size=(0.94, 0.7), color=UP if res.get("connected") else AMBER)

    def work(args):
        try:
            res = mt5quick.connect(*args, progress=lambda m: say(m))
            finish(res, None)
        except mt5quick.QuickError as e:
            finish(None, e)
        except Exception as e:                               # lỗi không lường trước: vẫn báo rõ, không treo nút
            finish(None, mt5quick.QuickError("Lỗi không mong đợi: %s" % e, "lỗi"))

    def go(*_):
        args = (login.text.strip(), pw.text, server.text.strip(), tok.text.strip(), plat.text)
        bad = mt5quick.problems(*args)
        if bad:
            say("\n".join(bad), DOWN)
            return
        go_btn.disabled = True
        say("Bắt đầu...", MUTED)
        threading.Thread(target=work, args=(args,), daemon=True).start()
    go_btn.bind(on_release=go)
    row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
    row.add_widget(go_btn)
    box.add_widget(row)
    pop.open()
