"""Bot GỌI AI theo ý mình: `self.api.ask_ai(câu_hỏi, include=[...], data={...}, schema={...}, web=False)` - TỔNG QUÁT, không gắn kịch bản nào.

Nguyên tắc: vỏ chỉ lo phần CHUNG (gửi câu hỏi + dữ liệu bot chọn, kiểm schema do BOT khai, chạy nền, giới hạn chi phí, ghi lại để backtest phát lại);
bot tự quyết hỏi gì, kèm dữ liệu gì, cần trả lời dạng nào và làm gì với câu trả lời. Không có «kịch bản dựng sẵn» (giữ/đóng/hoà vốn...) nào trong vỏ.

  include   danh sách «nguồn ngữ cảnh» dựng sẵn, dạng "tên" hoặc "tên:đối_số:..." (xem CONTEXT_PROVIDERS): positions, orders, account, symbol, tick,
            candles:<khung>:<số_nến>, calendar:<giờ>:<mức>, stats, store, time. Có thể kết hợp tuỳ ý + `data` (dict bất kỳ do bot tự dựng).
  schema    {"khoá": đặc_tả} do BOT khai; đặc_tả: list = chỉ nhận các giá trị đó · "number"/"int"/"bool"/"str" · "0..1" (khoảng) · dict {type,min,max,choices,maxlen,desc}.
            Khoá kết thúc bằng «?» là không bắt buộc. Có schema -> vỏ dặn AI chỉ trả một JSON object đúng schema và KIỂM lại; sai -> status "error".
  web       True -> dùng cấu hình tra web của AI đã chọn (ô «Model tra web» / «Tham số thêm khi tra web» ở tab AI); AI chưa cấu hình thì báo lỗi, KHÔNG âm thầm bỏ qua.
Không chặn bot: lần gọi đầu trả status "pending" (hỏi chạy nền); gọi lại CÙNG `key` ở tick sau để nhận kết quả (hoặc `wait=giây` để chờ có giới hạn).
Chi phí/riêng tư: mặc định TẮT; người dùng đặt hạn mức theo giờ/ngày, cỡ ngữ cảnh, AI nào được dùng, có cho tra web không (tab Cài đặt, nhóm «Bot gọi AI»).
Backtest: không gọi AI. Có «Phát lại tín hiệu AI đã ghi» thì trả lại câu trả lời thật đã ghi trước đó (khớp theo `tag`, không nhìn trước tương lai); không thì status "disabled".
Module thuần Python (không Kivy); mạng/đồng hồ/AI đều tiêm vào nên kiểm thử được."""
import hashlib
import json
import math
import os
import re
import threading
import time

from . import redact
from .sdk import AIAnswer

ASK_FILE = "ai_asks.jsonl"
HIST_FILE = "ai_ask_history.jsonl"      # nhật ký MỌI lần bot hỏi AI (kể cả lỗi/hết hạn mức) để người dùng xem; khác ASK_FILE (chỉ câu trả lời tốt, dùng cho backtest)
HIST_KEEP = 500
MAX_WAIT = 60.0


# ---------------------------------------------------------------- schema
def _spec_norm(spec):
    """Đặc tả bất kỳ -> dict chuẩn {type, min, max, choices, maxlen, desc}."""
    if isinstance(spec, dict):
        d = dict(spec)
        d.setdefault("type", "str" if d.get("choices") else "any")
        return d
    if isinstance(spec, (list, tuple)):
        return {"type": "str", "choices": list(spec)}
    if isinstance(spec, str):
        m = re.fullmatch(r"\s*(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)\s*", spec)
        if m:
            return {"type": "number", "min": float(m.group(1)), "max": float(m.group(2))}
        t = spec.strip().lower()
        if t in ("number", "float", "int", "integer", "bool", "boolean", "str", "string", "any"):
            return {"type": {"float": "number", "integer": "int", "boolean": "bool", "string": "str"}.get(t, t)}
        return {"type": "str", "desc": spec}
    return {"type": "any"}


def schema_prompt(schema):
    """Mô tả schema cho AI (do vỏ sinh từ schema của bot, không chứa nội dung kịch bản)."""
    lines = []
    for k, spec in schema.items():
        name = k.rstrip("?")
        d = _spec_norm(spec)
        if d.get("choices"):
            t = "một trong " + json.dumps(list(d["choices"]), ensure_ascii=False)
        elif d["type"] == "number" or d["type"] == "int":
            lo, hi = d.get("min"), d.get("max")
            t = ("số nguyên" if d["type"] == "int" else "số") + ((" từ %s đến %s" % (lo, hi)) if lo is not None and hi is not None else "")
        elif d["type"] == "bool":
            t = "true/false"
        elif d["type"] == "str":
            t = "chuỗi" + ((" (tối đa %d ký tự)" % d["maxlen"]) if d.get("maxlen") else "")
        else:
            t = "giá trị JSON bất kỳ"
        lines.append('  "%s": %s%s%s' % (name, t, " (không bắt buộc)" if k.endswith("?") else "", (" - " + str(d["desc"])) if d.get("desc") else ""))
    return "Chỉ trả về MỘT JSON object (không văn bản khác) với các khoá:\n" + "\n".join(lines)


def extract_json(text):
    """JSON object đầu tiên trong văn bản (chịu được ```json ... ``` và chữ thừa). None nếu không có."""
    t = str(text or "")
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.S | re.I)
    i = t.find("{")
    while i >= 0:
        depth, in_s, esc = 0, False, False
        for j in range(i, len(t)):
            ch = t[j]
            if in_s:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_s = False
                continue
            if ch == '"':
                in_s = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        v = json.loads(t[i:j + 1])
                        if isinstance(v, dict):
                            return v
                    except ValueError:
                        pass
                    break
        i = t.find("{", i + 1)
    return None


def validate(schema, data):
    """(dict đã chuẩn hoá, lỗi) - lỗi "" nếu hợp lệ. Số được ép về khoảng nếu lệch nhẹ? KHÔNG: ngoài khoảng là lỗi (không đoán ý AI)."""
    if not isinstance(data, dict):
        return {}, "không phải JSON object"
    out = {}
    for k, spec in schema.items():
        name, optional = k.rstrip("?"), k.endswith("?")
        d = _spec_norm(spec)
        if name not in data or data[name] is None:
            if optional:
                continue
            return {}, "thiếu khoá «%s»" % name
        v = data[name]
        t = d["type"]
        try:
            if t in ("number", "int"):
                if isinstance(v, bool):
                    raise ValueError
                x = float(v)
                if not math.isfinite(x):
                    raise ValueError
                if t == "int":
                    if x != int(x):
                        raise ValueError
                    x = int(x)
                if d.get("min") is not None and x < d["min"] or d.get("max") is not None and x > d["max"]:
                    return {}, "«%s»=%s ngoài khoảng %s..%s" % (name, x, d.get("min"), d.get("max"))
                v = x
            elif t == "bool":
                if isinstance(v, str) and v.strip().lower() in ("true", "false"):
                    v = v.strip().lower() == "true"
                if not isinstance(v, bool):
                    raise ValueError
            elif t == "str":
                v = str(v)
                if d.get("maxlen"):
                    v = v[:int(d["maxlen"])]
        except (TypeError, ValueError):
            return {}, "«%s» sai kiểu (cần %s)" % (name, t)
        if d.get("choices"):
            ch = list(d["choices"])
            hit = next((c for c in ch if c == v or str(c).lower() == str(v).strip().lower()), None)
            if hit is None:
                return {}, "«%s»=%r không nằm trong %s" % (name, v, ch)
            v = hit
        out[name] = v
    return out, ""


# ---------------------------------------------------------------- nguồn ngữ cảnh (tham chiếu API của bot; thêm nguồn mới = thêm 1 hàm vào đây)
def _r(x, nd=6):
    return round(x, nd) if isinstance(x, float) and math.isfinite(x) else x


def _pos(p):
    return {k: _r(getattr(p, k, None)) for k in ("id", "symbol", "side", "volume", "open_price", "sl", "tp", "open_time", "profit", "comment")
            if hasattr(p, k)}


def _ctx_positions(api, *a):
    return [_pos(p) for p in api.positions(a[0] if a and a[0] in ("buy", "sell") else None)]


def _ctx_orders(api, *a):
    return [{k: _r(getattr(o, k, None)) for k in ("id", "kind", "side", "volume", "price", "sl", "tp") if hasattr(o, k)} for o in api.orders()]


def _ctx_account(api, *a):
    ai = api.account_info()
    return {k: _r(getattr(ai, k, None)) for k in ("balance", "equity", "margin", "free_margin", "margin_level", "leverage", "mode") if hasattr(ai, k)}


def _ctx_symbol(api, *a):
    si = api.symbol_info()
    return {"symbol": api.symbol, "timeframe": api.timeframe,
            **{k: _r(getattr(si, k, None)) for k in ("volume_min", "volume_max", "volume_step", "spread", "market_open") if hasattr(si, k)}}


def _ctx_tick(api, *a):
    t = api.tick
    return {"bid": t.bid, "ask": t.ask, "time": t.time} if t is not None else None


def _ctx_candles(api, *a):
    tf = a[0] if a and a[0] else None
    n = max(1, min(300, int(a[1]))) if len(a) > 1 and a[1] else 50
    cs = api.candles(n, include_current=False, timeframe=tf or None)
    return {"timeframe": tf or api.timeframe, "columns": ["time", "open", "high", "low", "close"],
            "rows": [[int(c.time), _r(c.open), _r(c.high), _r(c.low), _r(c.close)] for c in cs]}


def _ctx_calendar(api, *a):
    hrs = float(a[0]) if a and a[0] else 24.0
    imp = a[1] if len(a) > 1 and a[1] else "medium"
    return [{k: e.get(k) for k in ("ts", "currency", "title", "impact", "forecast", "previous", "actual")} for e in api.calendar(hrs, imp)[:30]]


def _ctx_stats(api, *a):
    return {k: _r(v) for k, v in api.stats().items()}


def _ctx_store(api, *a):
    return dict(api.store.items())


def _ctx_time(api, *a):
    return api.time_info()


CONTEXT_PROVIDERS = {"positions": _ctx_positions, "orders": _ctx_orders, "account": _ctx_account, "symbol": _ctx_symbol, "tick": _ctx_tick,
                     "candles": _ctx_candles, "calendar": _ctx_calendar, "stats": _ctx_stats, "store": _ctx_store, "time": _ctx_time}


def build_context(api, include=None, data=None):
    """Dựng dict ngữ cảnh từ `include` + `data`. Nguồn lạ -> ValueError (báo rõ, không bỏ qua im lặng). Khoá trùng tên: «tên», «tên#2»..."""
    out = {}
    for item in (include or []):
        parts = str(item).split(":")
        name, args = parts[0].strip(), [x.strip() for x in parts[1:]]
        fn = CONTEXT_PROVIDERS.get(name)
        if fn is None:
            raise ValueError("include «%s» không có. Có: %s" % (name, ", ".join(sorted(CONTEXT_PROVIDERS))))
        key, n = str(item), 2
        out[key] = fn(api, *args)
    if data:
        if not isinstance(data, dict):
            raise ValueError("data phải là dict")
        out["data"] = data
    return out


# ---------------------------------------------------------------- ghi / phát lại
class AskLog:
    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()

    def append(self, rec):
        try:
            with self._lock, open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False, allow_nan=False, default=str) + "\n")
            return True
        except (OSError, ValueError):
            return False

    def load(self, since=None, until=None):
        out = []
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    try:
                        r = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(r, dict) or not isinstance(r.get("time"), (int, float)) or not r.get("tag"):
                        continue
                    if (since is not None and r["time"] < since) or (until is not None and r["time"] > until):
                        continue
                    out.append(r)
        except OSError:
            return []
        out.sort(key=lambda r: r["time"])
        return out


def load_history(base_dir, limit=100):
    """Các lần bot hỏi AI, MỚI NHẤT trước (tối đa `limit`)."""
    return AskLog(os.path.join(base_dir, HIST_FILE)).load()[::-1][:limit] if base_dir else []


def clear_history(base_dir):
    try:
        os.remove(os.path.join(base_dir, HIST_FILE))
        return True
    except OSError:
        return False


def usage_counts(base_dir, now=None):
    """(số lần GỌI AI trong 1 giờ, trong 24 giờ) theo nhật ký (không đếm lần bị từ chối vì hạn mức/lỗi trước khi gọi)."""
    now = time.time() if now is None else now
    recs = [r for r in AskLog(os.path.join(base_dir, HIST_FILE)).load(since=now - 86400) if r.get("status") in ("ok", "error") and r.get("took_s") is not None]
    return sum(1 for r in recs if now - r["time"] < 3600), len(recs)


def hist_line(r):
    """Một dòng tóm tắt cho danh sách."""
    st = {"ok": "✔", "error": "✖", "limited": "⏳"}.get(r.get("status"), "•")
    return "%s %s  %s  %s%s%s" % (time.strftime("%H:%M:%S", time.localtime(r["time"])), st, r.get("bot") or "?", r.get("symbol") or "",
                                  "  [web]" if r.get("web") else "", ("  " + str(r.get("agent"))) if r.get("agent") else "")


def hist_detail(r):
    d = ["Giờ: " + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r["time"])), "Bot: %s · %s" % (r.get("bot") or "?", r.get("symbol") or "?"),
         "Trạng thái: %s%s" % (r.get("status"), (" - " + r["error"]) if r.get("error") else ""),
         "AI: %s %s%s · %.1f giây · ngữ cảnh %s ký tự" % (r.get("agent") or "-", r.get("model") or "", " (tra web)" if r.get("web") else "", r.get("took_s") or 0.0, r.get("ctx_chars", 0)),
         "", "Câu hỏi:", r.get("q", "")]
    if r.get("data"):
        d += ["", "Kết quả (đã kiểm schema):", json.dumps(r["data"], ensure_ascii=False)]
    if r.get("text"):
        d += ["", "Nguyên văn trả lời:", r["text"]]
    return "\n".join(d)


def load_asks(base_dir, **kw):
    return AskLog(os.path.join(base_dir, ASK_FILE)).load(**kw)


class ReplayAsk:
    """Phát lại câu trả lời đã ghi theo `tag`: trả bản ghi mới nhất có time <= đồng hồ thị trường và chưa quá `ttl` giây. Không nhìn trước tương lai."""

    def __init__(self, records, clock, ttl_s=86400.0):
        self.by_tag = {}
        for r in sorted(records or [], key=lambda r: r["time"]):
            self.by_tag.setdefault(r["tag"], []).append(r)
        self.clock, self.ttl = clock, float(ttl_s)
        self.asks = self.hits = 0

    def ask(self, spec):
        self.asks += 1
        tag = spec.get("tag") or tag_of(spec.get("question", ""))
        try:
            now = float(self.clock())
        except (TypeError, ValueError):
            now = float("-inf")
        best = None
        for r in self.by_tag.get(tag, []):
            if r["time"] <= now:
                best = r
            else:
                break
        if best is None or now - best["time"] > self.ttl:
            return AIAnswer(status="no_replay", error="Backtest: không có câu trả lời AI đã ghi cho tag «%s» trước thời điểm này" % tag, key=spec.get("key", ""))
        self.hits += 1
        return AIAnswer(status="ok", ok=True, text=best.get("text", ""), data=best.get("data") or {}, key=spec.get("key", ""), agent=best.get("agent", ""),
                        model=best.get("model", ""), web=bool(best.get("web")), cached=True, age_s=max(0.0, now - best["time"]))

    def summary(self):
        n = sum(len(v) for v in self.by_tag.values())
        return "Phát lại câu trả lời AI đã ghi (ask_ai): %d bản ghi, bot hỏi %d lần, %d lần có câu trả lời còn hạn. Chỉ tái lập đúng các câu đã ghi, KHÔNG sinh lại." % (n, self.asks, self.hits)


class NullAsk:
    def __init__(self):
        self.asks = 0

    def ask(self, spec):
        self.asks += 1
        return AIAnswer(status="disabled", error="Backtest không gọi AI (bật «Phát lại tín hiệu AI đã ghi» để dùng câu trả lời thật đã ghi trước đó)", key=spec.get("key", ""))

    def summary(self):
        return ("KHÔNG gọi AI trong backtest: bot gọi ask_ai %d lần nhưng luôn nhận status 'disabled' - kết quả không phản ánh AI" % self.asks) if self.asks else ""


def tag_of(question):
    return "q:" + hashlib.sha256(str(question).encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------- dịch vụ
class AskService:
    """settings_fn() -> dict cài đặt · agents_fn() -> list agent · chat_fn(agent, messages, max_tokens, timeout) -> str · log: AskLog hoặc None."""

    def __init__(self, settings_fn, agents_fn, chat_fn, log=None, clock=time.time, runner=None, history=None):
        self.settings_fn, self.agents_fn, self.chat_fn, self.log, self.clock = settings_fn, agents_fn, chat_fn, log, clock
        self.history = history                # AskLog hoặc None; ghi mọi lần hỏi để hiển thị
        self._limit_logged = {}
        self.lock = threading.RLock()
        self.state = {}                      # key -> {"t": giờ bắt đầu, "ans": AIAnswer|None, "done": giờ xong}
        self.calls = []                      # giờ các lần GỌI MẠNG (hạn mức)
        self.runner = runner or self._thread

    @staticmethod
    def _thread(fn):
        threading.Thread(target=fn, name="ask-ai", daemon=True).start()

    # ---- thông tin hạn mức (bot xem được để tự điều chỉnh) ----
    def info(self):
        st = self.settings_fn() or {}
        now = self.clock()
        with self.lock:
            self.calls = [t for t in self.calls if now - t < 86400]
            h = sum(1 for t in self.calls if now - t < 3600)
            d = len(self.calls)
        return {"enabled": bool(st.get("bot_ai_enabled")), "used_hour": h, "limit_hour": int(st.get("bot_ai_max_per_hour", 20) or 0),
                "used_day": d, "limit_day": int(st.get("bot_ai_max_per_day", 200) or 0), "web_allowed": bool(st.get("bot_ai_allow_web")),
                "pending": sum(1 for v in self.state.values() if v.get("ans") is None)}

    def _pick_agent(self, st, name):
        ags = [a for a in (self.agents_fn() or []) if isinstance(a, dict) and a.get("enabled", True)]
        want = (name or st.get("bot_ai_agent") or "").strip()
        if want:
            a = next((a for a in ags if a.get("name") == want), None)
            if a is None:
                raise ValueError("Không có AI tên «%s» (đang bật: %s)" % (want, ", ".join(a.get("name", "?") for a in ags) or "không có"))
            return a
        if not ags:
            raise ValueError("Chưa có AI nào được bật ở tab AI")
        return ags[0]

    def ask(self, spec):
        st = self.settings_fn() or {}
        key = spec.get("key") or ""
        if not st.get("bot_ai_enabled"):
            return AIAnswer(status="disabled", error="Người dùng chưa bật «Cho bot gọi AI» (Cài đặt → Bot gọi AI)", key=key)
        now = self.clock()
        cache_s = float(spec["cache_s"] if spec.get("cache_s") is not None else st.get("bot_ai_cache_s", 300) or 0)
        wait = max(0.0, min(float(spec.get("wait") or 0.0), MAX_WAIT))
        with self.lock:
            e = self.state.get(key)
            if e is not None:
                ans = e["ans"]
                if ans is None:                                                      # đang hỏi
                    pass
                elif ans.status == "ok" and cache_s > 0 and now - e["done"] <= cache_s:
                    out = _copy(ans, cached=True, age_s=now - e["done"])
                    return out
                elif ans.status != "ok" and now - e["done"] <= 30.0:                         # lỗi: đừng gọi dồn dập, thử lại sau ≤ 30 s
                    return _copy(ans, cached=True, age_s=now - e["done"])
                else:
                    e = None
            if e is None:
                lim = self._limit(st, now)
                if lim is not None:
                    if now - self._limit_logged.get(key, -1e9) > 60:                 # hết hạn mức: ghi tối đa 1 dòng/phút/key
                        self._limit_logged[key] = now
                        self._hist(spec, now, "limited", lim[0])
                    return AIAnswer(status="limited", error=lim[0], retry_after_s=lim[1], key=key)
                try:
                    agent = self._pick_agent(st, spec.get("agent"))
                    call_agent = self._web_agent(st, agent) if spec.get("web") else agent
                except ValueError as ex:
                    return AIAnswer(status="error", error=str(ex), key=key)
                try:
                    messages = self._messages(st, spec)
                except ValueError as ex:
                    return AIAnswer(status="error", error=str(ex), key=key)
                self.calls.append(now)
                e = self.state[key] = {"t": now, "ans": None, "done": None}
                self._evict(now)
                self.runner(lambda: self._run(key, e, call_agent, messages, spec, st, agent))
        if wait > 0:
            end = time.time() + wait
            while time.time() < end:
                with self.lock:
                    if e["ans"] is not None:
                        break
                time.sleep(0.05)
        with self.lock:
            if e["ans"] is None:
                return AIAnswer(status="pending", pending=True, key=key, age_s=max(0.0, self.clock() - e["t"]))
            return _copy(e["ans"], age_s=max(0.0, self.clock() - e["done"]))

    def _evict(self, now):
        if len(self.state) > 200:
            for k in sorted(self.state, key=lambda k: self.state[k]["t"])[:100]:
                if self.state[k]["ans"] is not None:
                    del self.state[k]

    def _limit(self, st, now):
        self.calls = [t for t in self.calls if now - t < 86400]
        h = [t for t in self.calls if now - t < 3600]
        lh, ld = int(st.get("bot_ai_max_per_hour", 20) or 0), int(st.get("bot_ai_max_per_day", 200) or 0)
        if lh and len(h) >= lh:
            return ("Hết hạn mức %d lần/giờ (Cài đặt → Bot gọi AI)" % lh, max(1.0, 3600 - (now - min(h))))
        if ld and len(self.calls) >= ld:
            return ("Hết hạn mức %d lần/ngày (Cài đặt → Bot gọi AI)" % ld, max(1.0, 86400 - (now - min(self.calls))))
        return None

    def _web_agent(self, st, agent):
        if not st.get("bot_ai_allow_web"):
            raise ValueError("Người dùng chưa cho phép AI tra web (Cài đặt → Bot gọi AI → «Cho phép AI tra web»)")
        model = (agent.get("web_model") or "").strip()
        extra = (agent.get("web_extra_body") or "").strip()
        if not model and not extra:
            raise ValueError("AI «%s» chưa cấu hình tra web (tab AI → sửa AI → «Model tra web» và/hoặc «Tham số thêm khi tra web»)" % agent.get("name", "?"))
        a = dict(agent)
        if model:
            a["model"] = model
        if extra:
            a["extra_body"] = extra
        return a

    def _messages(self, st, spec):
        q = str(spec.get("question") or "").strip()
        if not q:
            raise ValueError("Thiếu câu hỏi")
        ctx = spec.get("context") or {}
        raw = json.dumps(ctx, ensure_ascii=False, default=str, separators=(",", ":"))
        cap = int(st.get("bot_ai_max_context", 12000) or 0)
        if cap and len(raw) > cap:
            raise ValueError("Ngữ cảnh quá lớn (%d > %d ký tự) - bớt nến/dữ liệu hoặc tăng «Cỡ ngữ cảnh tối đa»" % (len(raw), cap))
        sysm = "Bạn là cố vấn cho một bot giao dịch. Bot là bên quyết định cuối cùng; bạn chỉ đưa ý kiến tham khảo, ngắn gọn, nêu rõ giả định. Không bịa số liệu."
        extra = (st.get("bot_ai_system") or "").strip()
        if extra:
            sysm += "\n" + extra
        if spec.get("system"):
            sysm += "\n" + str(spec["system"])
        user = q
        if ctx:
            user += "\n\nDữ liệu (JSON):\n" + raw
        if spec.get("schema"):
            user += "\n\n" + schema_prompt(spec["schema"])
        return [{"role": "system", "content": redact.redact(sysm)}, {"role": "user", "content": redact.redact(user)}]

    def _run(self, key, e, call_agent, messages, spec, st, agent):
        timeout = float(spec.get("timeout") or st.get("bot_ai_timeout", 60) or 60)
        max_tokens = int(spec.get("max_tokens") or st.get("bot_ai_max_tokens", 600) or 600)
        web = bool(spec.get("web"))
        try:
            text = self.chat_fn(call_agent, messages, max_tokens, timeout)
            ans = AIAnswer(status="ok", ok=True, text=text, key=key, agent=agent.get("name", ""), model=call_agent.get("model", ""), web=web)
            sc = spec.get("schema")
            if sc:
                js = extract_json(text)
                if js is None:
                    ans.status, ans.ok, ans.error = "error", False, "AI không trả JSON"
                else:
                    data, err = validate(sc, js)
                    if err:
                        ans.status, ans.ok, ans.error = "error", False, "Trả lời sai schema: " + err
                    else:
                        ans.data = data
        except Exception as ex:                                      # noqa: BLE001 - lỗi mạng/AI không được làm sập bot
            ans = AIAnswer(status="error", error=str(ex)[:300], key=key, agent=agent.get("name", ""), web=web)
        now = self.clock()
        if ans.ok and self.log is not None and st.get("bot_ai_record", True):
            self.log.append({"time": now, "tag": spec.get("tag") or tag_of(spec.get("question", "")), "key": key, "text": redact.redact(ans.text),
                             "data": ans.data, "agent": ans.agent, "model": ans.model, "web": web, "symbol": spec.get("symbol", ""), "v": 1})
        self._hist(spec, now, ans.status, ans.error, ans, took=now - e["t"], ctx_chars=len(json.dumps(spec.get("context") or {}, default=str)))
        with self.lock:
            e["ans"], e["done"] = ans, now

    def _hist(self, spec, now, status, error, ans=None, took=0.0, ctx_chars=0):
        if self.history is None:
            return
        self.history.append({"time": now, "bot": spec.get("bot", ""), "symbol": spec.get("symbol", ""), "key": spec.get("key", ""), "tag": spec.get("tag", ""),
                             "q": redact.redact(str(spec.get("question", ""))[:600]), "status": status, "error": redact.redact(str(error or ""))[:300],
                             "agent": getattr(ans, "agent", ""), "model": getattr(ans, "model", ""), "web": bool(spec.get("web")),
                             "text": redact.redact(str(getattr(ans, "text", "") or "")[:1500]), "data": getattr(ans, "data", None) or {},
                             "took_s": round(took, 2), "ctx_chars": ctx_chars, "v": 1})


def _copy(a, **kw):
    d = dict(a.__dict__)
    d["data"] = dict(a.data or {})
    d.update(kw)
    return AIAnswer(**d)
