"""
ÁNH XẠ TRƯỜNG DÙNG CHUNG cho MỌI sàn (không viết riêng cho sàn nào).

Vì sao có file này: mỗi sàn đặt tên trường một kiểu (`equity` / `NAV` / `account_equity`, `profit` / `unrealizedPL` / `realized_pnl`...). Nếu mỗi lần gặp sàn mới
mà phải sửa code thì đó là hardcode theo sàn. Thay vào đó vỏ chỉ biết CÁC TRƯỜNG NGỮ NGHĨA (balance, equity, profit, swap, qty, position_id...) và một bảng bí danh chung;
tên của sàn được dò theo thứ tự:
  1. GHI ĐÈ của người dùng (Cài đặt → «Ánh xạ trường tuỳ chỉnh», hoặc nút «Áp dụng» do Trợ lý đề xuất) - theo từng sàn (`"exness": {...}`) hoặc chung (`"*": {...}`);
  2. bảng bí danh chung `SCHEMAS` (không phân biệt hoa thường và dấu `_`/`-`: `free_margin` = `freeMargin` = `FreeMargin`);
  3. không thấy -> trường VẮNG (giao diện hiện «-»), KHÔNG bịa số.
Cách chốt tên cho sàn mới: chạy «Kiểm tra hệ thống» (có mục «Ánh xạ trường») -> thấy trường nào chưa khớp kèm các khoá số chưa dùng của bản ghi thô -> điền ghi đè.
Không cần sửa mã, không cần phát hành lại.

Định dạng ghi đè (JSON):
    {"exness": {"position": {"profit": "unrealized_pnl"}, "deal": {"amount": "sum"}}, "*": {"account": {"equity": "totals.nav"}}}
  - khoá cấp 1: tên sàn (`exchange` trong Cài đặt) hoặc "*" (mọi sàn); sàn cụ thể thắng "*"
  - cấp 2: loại bản ghi ∈ SCHEMAS (account | position | deal); cấp 3: trường ngữ nghĩa -> đường dẫn chấm tới khoá trong bản ghi thô (`a.b.c`)
"""
import json
import math
import re
import threading

SCHEMAS = {
    "account": {
        "balance": ("balance",),
        "equity": ("equity", "nav"),
        "margin": ("margin", "used_margin", "margin_used"),
        "free_margin": ("free_margin", "margin_free", "margin_available"),
        "margin_level": ("margin_level", "margin_level_pct"),
        "profit": ("profit", "floating", "unrealized_pnl", "unrealizedpl", "floating_profit"),
        "credit": ("credit",),
        "leverage": ("leverage",),
        "currency": ("currency", "account_currency"),
    },
    "position": {
        "id": ("ref", "position_id", "id", "ticket"),
        "profit": ("profit", "unrealizedprofit", "unrealized_profit", "unrealized_pnl", "unrealizedpl", "floating_profit", "pnl"),
        "swap": ("swap", "unrealizedswap", "swaps"),
        "commission": ("commission", "unrealizedcommission"),
        "price": ("price_now", "currentprice", "current_price", "price_current", "mark_price"),
    },
    "deal": {
        "id": ("deal_id", "id", "ticket", "order_id"),
        "time": ("event_time", "time", "executed_at", "created_at", "timestamp"),
        "type": ("deal_type", "type", "entry"),
        "symbol": ("instrument", "symbol"),
        "side": ("side", "direction"),
        "qty": ("volume", "qty", "quantity"),
        "price": ("price", "fill_price", "open_price"),
        "profit": ("profit", "pnl", "realized_pnl"),                      # lãi/lỗ của deal GIAO DỊCH
        "amount": ("profit", "amount", "pnl", "value", "realized_pnl"),   # số tiền của deal TÀI CHÍNH (nạp/rút/phí...): có sàn đặt tên là amount
        "commission": ("commission",),
        "swap": ("swap",),
        "fee": ("fee",),
        "position_id": ("position_id",),
        "order_id": ("order_id",),
        "comment": ("comment",),
    },
    "order": {                                                           # lệnh SLTP/lệnh chờ trong snapshot: lệnh nào gắn với vị thế nào
        "id": ("order_id", "id", "ticket"),
        "position_ref": ("position_id", "position", "position_ticket", "positionid"),
        "sl": ("stop_loss_price", "stop_loss", "sl"),
        "tp": ("take_profit_price", "take_profit", "tp"),
    },
    "request": {                                                         # tên khoá app GỬI đi (không phải đọc): ghi đè để sửa khi sàn đặt tên khác
        "sltp_position": ("position_id", "position"),
    },
}
# Trường mà giao diện/vỏ THỰC SỰ cần từ bản ghi thô (các trường khác hoặc tính được từ chúng, hoặc chỉ có ở một số loại bản ghi): thiếu một trong số này mới là vấn đề ánh xạ.
CORE = {"account": ("equity", "margin"), "position": ("profit",), "deal": ("id", "time", "type"), "order": ("position_ref",), "request": ()}
KIND_VN = {"account": "tài khoản", "position": "vị thế", "deal": "deal (lịch sử)", "order": "lệnh SLTP", "request": "thân yêu cầu gửi đi"}

_PATH = re.compile(r"^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+){0,4}$")
_NORM = re.compile(r"[^a-z0-9]")


def _k(name):
    return _NORM.sub("", str(name).lower())


def num(v):
    """float hữu hạn hoặc None (chuỗi số như '1.5' cũng nhận - nhiều sàn trả số dạng chuỗi thập phân)."""
    if isinstance(v, bool):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


# ---------------------------------------------------------------------------------------------- ghi đè
_lock = threading.RLock()
_OVERRIDES = {}                  # {scope: {kind: {field: path}}} đã kiểm hợp lệ
_SAMPLES = {}                    # {(scope, kind): [tối đa 6 bản ghi thô gần nhất, mỗi DẠNG khoá một bản]} - để «Kiểm tra hệ thống»/Trợ lý chỉ ra trường nào đã khớp
_SRC = {}                        # {(scope, kind, field): khoá thật đã dùng}


def parse_overrides(text):
    """JSON (chuỗi hoặc dict) -> (dict hợp lệ, [lỗi]). Mục sai bị bỏ kèm lý do; không ném."""
    errs = []
    if text in (None, "", {}):
        return {}, errs
    if isinstance(text, str):
        try:
            raw = json.loads(text)
        except ValueError as e:
            return {}, ["Ánh xạ trường: JSON không hợp lệ (%s)" % e]
    else:
        raw = text
    if not isinstance(raw, dict):
        return {}, ["Ánh xạ trường: phải là đối tượng {sàn: {loại: {trường: đường dẫn}}}"]
    out = {}
    for scope, kinds in raw.items():
        if not isinstance(kinds, dict):
            errs.append("«%s»: phải là đối tượng {loại: {...}}" % scope)
            continue
        for kind, fields in kinds.items():
            if kind not in SCHEMAS:
                errs.append("«%s»: loại «%s» không có (chỉ: %s)" % (scope, kind, ", ".join(SCHEMAS)))
                continue
            if not isinstance(fields, dict):
                errs.append("«%s.%s»: phải là đối tượng {trường: đường dẫn}" % (scope, kind))
                continue
            for field, path in fields.items():
                if field not in SCHEMAS[kind]:
                    errs.append("«%s.%s»: trường «%s» không có (chỉ: %s)" % (scope, kind, field, ", ".join(SCHEMAS[kind])))
                elif not isinstance(path, str) or not _PATH.match(path):
                    errs.append("«%s.%s.%s»: đường dẫn «%s» không hợp lệ (chỉ chữ/số/_/-, phân cấp bằng dấu chấm)" % (scope, kind, field, path))
                else:
                    out.setdefault(str(scope), {}).setdefault(kind, {})[field] = path
    return out, errs


def configure(settings_or_text):
    """Nạp ghi đè từ Cài đặt (`field_overrides`) hoặc chuỗi JSON. Gọi khi dựng broker và khi người dùng lưu cài đặt. Trả danh sách lỗi."""
    text = settings_or_text.get("field_overrides") if isinstance(settings_or_text, dict) else settings_or_text
    ov, errs = parse_overrides(text)
    with _lock:
        _OVERRIDES.clear()
        _OVERRIDES.update(ov)
    return errs


def overrides():
    with _lock:
        return json.loads(json.dumps(_OVERRIDES))


def add_override(text, scope, kind, field, path):
    """Thêm MỘT ghi đè vào chuỗi JSON hiện có -> (chuỗi JSON mới, [lỗi]). Dùng cho nút «Áp dụng» của Trợ lý: luôn kiểm hợp lệ trước khi nhận."""
    cur, _ = parse_overrides(text)
    cand = json.loads(json.dumps(cur))
    cand.setdefault(str(scope or "*"), {}).setdefault(kind, {})[field] = path
    ov, errs = parse_overrides(cand)
    if errs:
        return text or "", errs
    return json.dumps(ov, ensure_ascii=False, sort_keys=True), []


def override(kind, field, scope=None):
    """Đường dẫn ghi đè tay đang có cho (kind, field) của sàn `scope` (hoặc "*"), None nếu chưa có."""
    return _scoped(scope, kind, field)


def _scoped(scope, kind, field):
    with _lock:
        for sc in (scope, "*"):
            p = _OVERRIDES.get(sc, {}).get(kind, {}).get(field)
            if p:
                return p
    return None


# ---------------------------------------------------------------------------------------------- dò trường
def _get_path(rec, path):
    cur = rec
    for part in path.split("."):
        if not isinstance(cur, dict):
            return None, None
        hit = next((k for k in cur if _k(k) == _k(part)), None)
        if hit is None:
            return None, None
        cur = cur[hit]
    return (cur, path) if cur not in (None, "") else (None, None)


def _find(rec, names, depth):
    """(giá trị, đường dẫn khoá) đầu tiên có khoá thuộc `names` (đã chuẩn hoá), tìm lồng tới `depth` cấp (dict và 5 phần tử đầu của list)."""
    if isinstance(rec, dict):
        low = {}
        for k, v in rec.items():
            low.setdefault(_k(k), (k, v))
        for n in names:
            hit = low.get(n)
            if hit is not None and hit[1] not in (None, ""):
                return hit[1], str(hit[0])
        if depth > 0:
            for k, v in rec.items():
                if isinstance(v, (dict, list)):
                    r, p = _find(v, names, depth - 1)
                    if r is not None:
                        return r, "%s.%s" % (k, p)
    elif isinstance(rec, list) and depth > 0:
        for i, v in enumerate(rec[:5]):
            r, p = _find(v, names, depth - 1)
            if r is not None:
                return r, "%d.%s" % (i, p)
    return None, None


def pick(kind, rec, field, scope=None, depth=0, extra=()):
    """Giá trị THÔ của `field` trong bản ghi `rec` của sàn `scope` (None nếu sàn không báo). `extra`: bí danh bổ sung chỉ cho lời gọi này."""
    return lookup(kind, rec, field, scope, depth, extra)[0]


def lookup(kind, rec, field, scope=None, depth=0, extra=()):
    """Như pick nhưng trả (giá trị, khoá thật đã dùng)."""
    if not isinstance(rec, dict):
        return None, None
    ov = _scoped(scope, kind, field)
    if ov:
        v, p = _get_path(rec, ov)
        if v is not None:
            _SRC[(scope, kind, field)] = p
            return v, p
        return None, None                  # đã ghi đè mà sàn không có khoá đó: KHÔNG lặng lẽ rơi về bảng chung (sẽ che lỗi cấu hình)
    names = tuple(_k(n) for n in tuple(extra) + SCHEMAS[kind][field])
    v, p = _find(rec, names, depth)
    if v is not None:
        _SRC[(scope, kind, field)] = p
    return v, p


def remember(scope, kind, rec):
    """Lưu bản ghi thô gần nhất (mỗi dạng khoá một bản, tối đa 6) để chẩn đoán (không giữ khoá/bí mật: chỉ dùng khi in báo cáo, qua redact)."""
    if isinstance(rec, dict):
        sig = tuple(sorted(str(k) for k in rec))
        with _lock:
            lst = [(g, r) for g, r in _SAMPLES.get((scope, kind), []) if g != sig]
            lst.append((sig, dict(rec)))
            _SAMPLES[(scope, kind)] = lst[-6:]


def sample_keys(scope, kind, depth=3):
    """Mọi đường dẫn khoá (a, a.b, ...) đã THẤY trong các bản ghi thô gần nhất của (sàn, loại) - để kiểm một đề xuất ghi đè có trỏ vào khoá có thật không.
    Trả về set (rỗng = chưa thấy bản ghi nào)."""
    with _lock:
        recs = [r for _, r in _SAMPLES.get((scope, kind), [])]
    out = set()

    def walk(rec, prefix, d):
        if isinstance(rec, dict):
            for k, v in rec.items():
                p = "%s.%s" % (prefix, k) if prefix else str(k)
                out.add(p)
                if d > 0 and isinstance(v, (dict, list)):
                    walk(v, p, d - 1)
        elif isinstance(rec, list) and d > 0:
            for i, v in enumerate(rec[:5]):
                walk(v, "%s.%d" % (prefix, i) if prefix else str(i), d - 1)
    for r in recs:
        walk(r, "", depth)
    return out


def path_seen(scope, kind, path):
    """True/False: đường dẫn `path` có (không phân biệt hoa thường và `_`/`-`) trong bản ghi thô đã thấy của (sàn, loại) không; None = chưa thấy bản ghi nào để đối chiếu."""
    keys = sample_keys(scope, kind)
    if not keys:
        return None
    want = tuple(_k(x) for x in str(path).split("."))
    return any(tuple(_k(x) for x in k.split(".")) == want for k in keys)


def forget():
    with _lock:
        _SAMPLES.clear()
        _SRC.clear()


def diagnose(kind, rec, scope=None, depth=0):
    """Một bản ghi thô -> {"mapped": {trường: khoá thật}, "missing": [trường sàn không báo], "unmatched": [khoá số chưa được trường nào dùng], "overridden": [...]}.
    `unmatched` là danh sách ứng viên để người dùng/Trợ lý ghi đè khi một trường đang thiếu."""
    mapped, missing, used = {}, [], set()
    for field in SCHEMAS[kind]:
        v, p = lookup(kind, rec, field, scope, depth)
        if v is None:
            missing.append(field)
        else:
            mapped[field] = p
            if "." not in p:
                used.add(_k(p))
    unmatched = []
    if isinstance(rec, dict):
        for k, v in rec.items():
            if _k(k) in used or isinstance(v, (dict, list)):
                continue
            if num(v) is not None:
                unmatched.append(str(k))
    ov = [f for f in SCHEMAS[kind] if _scoped(scope, kind, f)]
    return {"mapped": mapped, "missing": missing, "core_missing": [f for f in CORE.get(kind, ()) if f in missing], "unmatched": unmatched[:30], "overridden": ov}


def report(scope):
    """Báo cáo ánh xạ từ các bản ghi thô gần nhất của sàn `scope` -> {kind: diagnose(...)}."""
    with _lock:
        items = [(k[1], [r for _, r in v]) for k, v in _SAMPLES.items() if k[0] == scope]
    out = {}
    for kind, recs in items:
        merged = {}
        for r in recs:                                        # gộp các dạng bản ghi (vd deal giao dịch + deal nạp/rút): bản mới thắng
            merged.update(r)
        out[kind] = diagnose(kind, merged, scope, depth=3)
    return out


def format_report(rep):
    """Báo cáo dạng chữ (cho Kiểm tra hệ thống và Trợ lý)."""
    lines = []
    for kind, d in rep.items():
        lines.append("%s: khớp %s" % (KIND_VN.get(kind, kind), ", ".join("%s←%s" % (f, p) for f, p in d["mapped"].items()) or "(chưa có)"))
        if d["missing"]:
            lines.append("  sàn KHÔNG báo / chưa khớp: %s%s" % (", ".join(d["missing"]), (" (THIẾU CẦN THIẾT: %s)" % ", ".join(d["core_missing"])) if d["core_missing"] else ""))
        if d["unmatched"] and d["core_missing"]:
            lines.append("  khoá số chưa dùng (ứng viên để ghi đè): %s" % ", ".join(d["unmatched"]))
        if d["overridden"]:
            lines.append("  đang ghi đè tay: %s" % ", ".join(d["overridden"]))
    return "\n".join(lines)
