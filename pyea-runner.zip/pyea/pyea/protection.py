"""SL/TP NATIVE - phần DÙNG CHUNG phía broker (học theo cách MT5 làm).

MT5 làm thế nào (https://www.mql5.com/en/docs/constants/tradingconstants/enum_trade_request_actions, .../dealproperties):
  * SL/TP là THUỘC TÍNH CỦA VỊ THẾ; chương trình chỉ nói «vị thế này, SL này, TP này» (TRADE_ACTION_SLTP + ticket + sl + tp). Máy chủ lo cách giữ và canh.
  * Khi SL/TP kích hoạt, deal đóng ghi LÝ DO (DEAL_REASON_SL / DEAL_REASON_TP) và kiểu (DEAL_ENTRY_OUT); chương trình đọc lại để biết chuyện gì đã xảy ra.
  Chương trình KHÔNG biết (và không cần biết) máy chủ giữ SL/TP bằng cơ chế nào.

Vỏ PyEA làm y như vậy. Hợp đồng giữa vỏ (protect.py) và MỌI broker chỉ có MỘT dạng:

    sync_protection(symbol, intents) -> {"live": [...], "covered": {pid: ["sl","tp"]}, "errors": [...]}
        intents = [{"pid": id vị thế ảo, "ref": ticket sàn hoặc "", "side": chiều ĐÓNG, "qty": khối lượng, "sl": giá|0, "tp": giá|0}]  (mỗi vị thế có SL/TP một phần tử)
    protection_orders(symbol) -> [{"id", "side", "qty", + mức: ("kind": "sl"|"tp", "trigger") hoặc ("sl", "tp"), tuỳ chọn "ref", "step"}]   lệnh/mức bảo vệ của vỏ đang sống
    order_result(id, symbol)  -> {"state": "filled"|"open"|"canceled"|"expired"|"rejected"|"unknown", "price", "qty", tuỳ chọn "leg", "deals"}

Sàn nào cũng chỉ khác nhau ở CÁCH giữ mức trên sàn, nên phần khác nhau đó là một PHONG CÁCH (`PROT_STYLE`) chọn trong số các phong cách dưới đây; broker mới chỉ cần
chọn phong cách khớp với API của sàn và viết vài hàm nguyên thuỷ của sàn đó - KHÔNG phải đụng vào vỏ:

  "ladder"   sàn có lệnh điều kiện giảm-vị-thế (Binance Futures reduceOnly, OANDA REDUCE_ONLY): vị thế ảo gộp trên sàn nên các mức giống nhau được GỘP khối lượng
             thành «bậc thang». Hàm nguyên thuỷ: `sync_steps(symbol, steps)` (thường gọi `sync_ladder` kèm 3 hàm list/cancel/place) và `protection_orders`.
  "pair"     như ladder nhưng sàn không có reduceOnly và lệnh bán đang chờ KHOÁ coin (Binance Spot): vị thế có cả SL lẫn TP đi chung MỘT lệnh OCO.
  "position" sàn gắn SL/TP lên CHÍNH vị thế (MT/MetaApi, kiểu Bybit trading-stop...): mỗi vị thế một bước, sửa tại chỗ bằng một lời gọi. Hàm nguyên thuỷ:
             `position_levels(symbol)` (đọc vị thế sàn) và `set_position_levels(ref, sl, tp)`. `sync_steps`/`protection_orders` đã có sẵn trong `ProtectionAPI`.

Thêm sàn mới = chọn phong cách + viết hàm nguyên thuỷ; `tests/test_protect_contract.py` chạy MỘT bộ kịch bản chung cho mọi phong cách nên không phải viết lại bộ test.
"""

PROT_PREFIX = "pyeaP"      # tiền tố mã lệnh khách của MỌI lệnh bảo vệ do vỏ đặt (clientAlgoId / clientExtensions.id ...) - nhận ra lệnh của vỏ
POS_PREFIX = "pos:"        # tiền tố id của «bảo vệ gắn trên vị thế» (phong cách position): "pos:<ticket>"
STYLES = ("ladder", "pair", "position")
STEP_KEYS = ("kind", "side", "trigger", "qty", "sl", "tp", "ref")


def _err():
    from .broker import BrokerError                       # nạp muộn: broker.py nhập module này
    return BrokerError


# ----------------------------------------------------------------------------------------------- dữ liệu chung
def levels_of(o):
    """(sl, tp) của một lệnh/mức bảo vệ - nhận cả dạng `kind sl|tp + trigger` lẫn dạng `sl`, `tp`. Mức không có = 0.0."""
    sl, tp = float(o.get("sl") or 0.0), float(o.get("tp") or 0.0)
    if not (sl or tp):
        trig = float(o.get("trigger") or 0.0)
        kind = o.get("kind")
        sl, tp = (trig, 0.0) if kind == "sl" else (0.0, trig) if kind == "tp" else (0.0, 0.0)
    return sl, tp


def infer_leg(pos_side, price, sl, tp, tol=0.0, allow_manual=False):
    """Chân nào đã khớp, suy từ GIÁ KHỚP (MT5 ghi thẳng DEAL_REASON_SL/TP; sàn không ghi thì suy): giá đã tới/vượt mức SL -> "sl", tới/vượt mức TP -> "tp".
    Giá không chạm mức nào: `allow_manual` -> "manual" (đóng tay/EA khác/stop-out), ngược lại chân gần giá hơn. Chỉ có một mức -> chính nó."""
    if sl and not tp:
        return "sl"
    if tp and not sl:
        return "tp"
    t_sl, t_tp = max(abs(sl) * 1e-9, tol), max(abs(tp) * 1e-9, tol)
    if pos_side == "buy":
        hit_sl, hit_tp = bool(sl) and price <= sl + t_sl, bool(tp) and price >= tp - t_tp
    else:
        hit_sl, hit_tp = bool(sl) and price >= sl - t_sl, bool(tp) and price <= tp + t_tp
    if hit_sl:
        return "sl"
    if hit_tp:
        return "tp"
    if allow_manual:
        return "manual"
    return "sl" if abs(price - sl) <= abs(price - tp) else "tp"


# ----------------------------------------------------------------------------------------------- lập kế hoạch
def plan_steps(intents, style):
    """intents (mỗi vị thế một phần tử) -> các «bước» theo phong cách của sàn; mỗi bước có `pos_ids` (vị thế nó phủ) và `legs` (mức nào của các vị thế đó).
    Bước: {kind, side, trigger, qty, sl, tp, ref, pos_ids, legs}. Có thứ tự xác định. Vị thế không đặt được theo phong cách (vd position mà không có ticket) bị bỏ -> vỏ tự canh."""
    if style not in STYLES:
        raise ValueError("PROT_STYLE phải thuộc %s, nhận %r" % (list(STYLES), style))
    items = []
    for it in sorted(intents, key=lambda x: x["pid"]):
        sl = float(it.get("sl") or 0.0)
        tp = float(it.get("tp") or 0.0)
        if (sl > 0 or tp > 0) and float(it.get("qty") or 0.0) > 0:
            items.append((it, max(sl, 0.0), max(tp, 0.0)))
    if style == "position":
        out, seen = [], set()
        for it, sl, tp in items:
            ref = str(it.get("ref") or "")
            if not ref or ref in seen:
                continue                                         # không có ticket (hoặc trùng ticket): không gắn được lên vị thế sàn
            seen.add(ref)
            out.append({"kind": "pos", "side": it["side"], "trigger": sl or tp, "sl": sl, "tp": tp, "qty": float(it["qty"]), "ref": ref,
                        "pos_ids": [it["pid"]], "legs": [k for k, v in (("sl", sl), ("tp", tp)) if v]})
        return out
    groups = {}
    for it, sl, tp in items:
        side, qty = it["side"], float(it["qty"])
        if style == "pair" and sl and tp:                        # OCO: SL+TP của CÙNG vị thế đi chung một lệnh (một khối lượng, bên nào khớp thì bên kia tự huỷ)
            g = groups.setdefault(("oco", side, round(sl, 10), round(tp, 10)),
                                  {"kind": "oco", "side": side, "trigger": sl, "sl": sl, "tp": tp, "qty": 0.0, "pos_ids": [], "legs": ["sl", "tp"]})
            g["qty"] += qty
            g["pos_ids"].append(it["pid"])
            continue
        for kind, level in (("sl", sl), ("tp", tp)):
            if level:
                g = groups.setdefault((kind, side, round(level, 10), 0.0),
                                      {"kind": kind, "side": side, "trigger": level, "qty": 0.0, "pos_ids": [], "legs": [kind]})
                g["qty"] += qty
                g["pos_ids"].append(it["pid"])
    return [groups[k] for k in sorted(groups)]


def covered_map(steps, covered_idx):
    """Chỉ số bước đã có lệnh sống -> {pid: [legs]} (vỏ chỉ ngừng tự canh đúng những mức này)."""
    out = {}
    for i in covered_idx or []:
        for pid in steps[i]["pos_ids"]:
            legs = out.setdefault(pid, [])
            for k in steps[i]["legs"]:
                if k not in legs:
                    legs.append(k)
    return {pid: sorted(v) for pid, v in out.items()}


# ----------------------------------------------------------------------------------------------- bộ đồng bộ
def sync_ladder(desired, key_fn, qty_ok, list_fn, cancel_fn, place_fn):
    """Thuật toán đồng bộ «bậc thang bảo vệ» dùng chung mọi sàn (idempotent): đưa các lệnh bảo vệ trên sàn về ĐÚNG `desired`.
      desired   : [{kind: sl|tp|oco, side: chiều ĐÓNG, trigger, qty}]
      key_fn(d) : khoá so khớp (kind, side, giá đã định dạng theo sàn, khối lượng đã làm tròn theo sàn) - nhận dict có 4 trường trên
      qty_ok(d) : False nếu khối lượng sau khi làm tròn bằng 0 (bỏ qua mức đó)
      list_fn() : các lệnh bảo vệ của vỏ đang sống trên sàn -> [{id, kind, side, trigger, qty}]
      cancel_fn(o), place_fn(d) -> dict lệnh vừa đặt ({id, kind, side, trigger, qty}); ném BrokerError khi sàn từ chối.
    -> {"live": [...], "covered": [chỉ số trong desired đã có lệnh sống], "errors": [chuỗi lỗi]} - lỗi từng lệnh KHÔNG làm hỏng cả lượt."""
    BrokerError = _err()
    want = {}
    for i, d in enumerate(desired):
        if qty_ok(d):
            want.setdefault(key_fn(d), i)
    errors, live, have = [], [], {}
    for o in list_fn():
        k = key_fn(o)
        if k in want and k not in have:
            have[k] = o
            live.append(o)
        else:                                                      # thừa (hoặc trùng): huỷ
            try:
                cancel_fn(o)
            except BrokerError as e:
                errors.append("huỷ %s %s @%s: %s" % (o["kind"].upper(), o["id"], o["trigger"], e))
    covered = []
    for k, i in want.items():
        if k in have:
            covered.append(i)
            continue
        d = desired[i]
        try:
            live.append(place_fn(d))
            covered.append(i)
        except BrokerError as e:
            errors.append("%s %s @%s: %s" % (d["kind"].upper(), d["side"], d["trigger"], e))
    return {"live": live, "covered": sorted(covered), "errors": errors}


def same_level(a, b):
    """Hai mức giá coi như bằng nhau (sàn làm tròn theo số lẻ của mã): dung sai 0.001% - tránh sửa đi sửa lại mãi. 0 chỉ bằng 0."""
    a, b = float(a or 0.0), float(b or 0.0)
    if a <= 0.0 or b <= 0.0:
        return a <= 0.0 and b <= 0.0
    return abs(a - b) <= max(abs(b) * 1e-5, 1e-9)


def position_entry(row, sl, tp):
    """Mô tả «bảo vệ gắn trên vị thế sàn» theo định dạng protection_orders."""
    return {"id": POS_PREFIX + str(row["ref"]), "kind": "pos", "side": "sell" if row["side"] == "buy" else "buy", "trigger": sl or tp, "sl": sl, "tp": tp,
            "qty": float(row["qty"]), "ref": str(row["ref"])}


def qty_close(a, b):
    """Hai khối lượng coi như bằng nhau (dung sai 0.01% - làm tròn bước khối lượng của sàn)."""
    a, b = float(a or 0.0), float(b or 0.0)
    return abs(a - b) <= max(abs(b) * 1e-4, 1e-9)


def sync_position_levels(steps, rows, set_fn):
    """Đồng bộ phong cách «position»: `steps` (plan_steps), `rows` = vị thế sàn của mã [{ref, side, qty, sl, tp, owned}], `set_fn(ref, sl, tp)` sửa SL/TP của MỘT
    vị thế (ném BrokerError khi sàn từ chối). Mỗi vị thế chỉ bị sửa khi mức khác (một lời gọi, không «huỷ rồi đặt» nên không có khoảng hở); vị thế KHÔNG
    do vỏ mở (owned=False) không bao giờ bị đụng; vị thế của vỏ còn mức mà không còn trong `steps` thì xoá mức.
    AN TOÀN KHI SÀN GỘP (netting): SL/TP trên sàn là của CẢ vị thế gộp. Vị thế ảo chỉ được gắn mức lên ticket khi nó là TOÀN BỘ ticket đó (cùng khối lượng);
    nếu ticket lớn hơn (còn vị thế ảo khác dùng chung, hoặc bạn cộng thêm bằng tay) thì KHÔNG gắn - mức đó vỏ tự canh - và mức cũ đã gắn bị gỡ.
    -> {"live", "covered": [chỉ số], "errors"}."""
    BrokerError = _err()
    by_ref = {str(r["ref"]): r for r in rows}
    live, covered, errors, wanted = [], [], [], set()
    for i, d in enumerate(steps):
        ref = str(d.get("ref") or "")
        if not ref or ref in wanted:
            continue
        wanted.add(ref)
        row = by_ref.get(ref)
        if row is None:
            errors.append("vị thế sàn #%s không còn trên sàn" % ref)
            continue
        if not row.get("owned", True):
            errors.append("vị thế sàn #%s không phải do app mở nên không đụng" % ref)
            continue
        want_side = "buy" if d.get("side") == "sell" else ("sell" if d.get("side") == "buy" else "")
        if row.get("side") and want_side and row["side"] != want_side:
            wanted.discard(ref)
            errors.append("vị thế sàn #%s đã đổi chiều (%s) so với vị thế ảo nên không gắn SL/TP - app tự canh" % (ref, row["side"]))
            continue
        if not qty_close(row.get("qty"), d.get("qty")):
            wanted.discard(ref)                                   # rơi xuống vòng «gỡ mức thừa» bên dưới
            errors.append("vị thế sàn #%s lớn hơn vị thế ảo (%.8g so với %.8g: gộp nhiều vị thế hoặc đã cộng thêm) nên không gắn SL/TP riêng được - app tự canh"
                          % (ref, float(row.get("qty") or 0.0), float(d.get("qty") or 0.0)))
            continue
        sl, tp = float(d.get("sl") or 0.0), float(d.get("tp") or 0.0)
        if not (same_level(row.get("sl"), sl) and same_level(row.get("tp"), tp)):
            try:
                set_fn(ref, sl, tp)
            except BrokerError as e:
                errors.append("đặt SL/TP cho #%s: %s" % (ref, e))
                continue
        live.append(position_entry(row, sl, tp))
        covered.append(i)
    for ref, row in by_ref.items():
        if ref in wanted or not row.get("owned", True):
            continue
        if float(row.get("sl") or 0.0) > 0.0 or float(row.get("tp") or 0.0) > 0.0:
            try:
                set_fn(ref, 0.0, 0.0)
            except BrokerError as e:
                errors.append("xoá SL/TP của #%s: %s" % (ref, e))
    return {"live": live, "covered": sorted(covered), "errors": errors}


def close_from_deals(deals):
    """Từ các deal của MỘT vị thế (mỗi deal: {price, qty, time, entry: chứa "OUT" nếu là deal đóng, id}) -> kết quả đóng
    {"state": "filled", "price", "qty", "deals": [...]} (deal đóng CUỐI quyết định giá; `deals` = mọi deal đóng để vỏ chọn đúng phần còn lại) hoặc None khi chưa có deal đóng."""
    outs = sorted((d for d in deals or [] if "OUT" in str(d.get("entry") or "").upper() and d.get("qty")), key=lambda d: (d.get("time") or 0, str(d.get("id"))))
    if not outs:
        return None
    last = outs[-1]
    return {"state": "filled", "price": last["price"], "qty": last["qty"], "time": last.get("time") or 0,
            "reason": str(last.get("reason") or ""),
            "deals": [{"price": d["price"], "qty": d["qty"], "time": d.get("time") or 0} for d in outs]}


# ----------------------------------------------------------------------------------------------- mixin cho broker
class ProtectionAPI:
    """Mixin: broker khai `PROT_STYLE` rồi có sẵn `sync_protection(symbol, intents)` đúng hợp đồng.
    ladder/pair: broker viết `sync_steps(symbol, steps)` + `protection_orders(symbol)`. position: broker viết `position_levels` + `set_position_levels`."""
    PROT_STYLE = "ladder"

    def _known_refs(self):
        k = getattr(self, "_prot_known", None)
        if k is None:
            k = self._prot_known = set()
        return k

    OWNER_BY_TAG = False        # True: broker đọc được nhãn trên sàn (vd comment 'pyea' của MT) và `owned` của nó là quyết định cuối

    def _row_owned(self, row):
        """Vị thế sàn có phải của app không. Sàn có nhãn (OWNER_BY_TAG): theo `owned`. Sàn không có nhãn (vd Exness): ticket do chính app mở
        (Fill.ref, hoặc intent `own`) mới tính; vị thế bạn mở tay/được nhận từ sàn thì KHÔNG bị sửa. Không khai gì thì coi là của app (như trước)."""
        if self.OWNER_BY_TAG:
            return bool(row.get("owned", True))
        if "owned" not in row:
            return True
        return bool(row["owned"]) or str(row.get("ref")) in self._known_refs()

    def note_own_ref(self, ref):
        """Ghi nhớ «ticket này do app mở» (broker gọi khi market_order trả Fill.ref; vỏ gọi qua intents). Sàn không có chỗ ghi nhãn (comment) dựa vào đây để
        biết vị thế nào là của app - vị thế bạn mở tay không bao giờ bị sửa SL/TP."""
        if ref:
            self._known_refs().add(str(ref))

    def sync_protection(self, symbol, intents):
        for it in intents:
            if it.get("own", True):
                self.note_own_ref(it.get("ref"))
        steps = plan_steps(intents, self.PROT_STYLE)
        res = self.sync_steps(symbol, [{k: s[k] for k in STEP_KEYS if k in s} for s in steps])
        return {"live": list(res.get("live") or []), "covered": covered_map(steps, res.get("covered")), "errors": list(res.get("errors") or [])}

    def sync_steps(self, symbol, steps):                           # mặc định cho phong cách position
        if self.PROT_STYLE != "position":
            raise NotImplementedError("%s phải tự viết sync_steps() cho PROT_STYLE=%r" % (type(self).__name__, self.PROT_STYLE))
        rows = [dict(r, owned=self._row_owned(r)) for r in self.position_levels(symbol)]
        return sync_position_levels(steps, rows, self.set_position_levels)

    def protection_orders(self, symbol):                           # mặc định cho phong cách position
        if self.PROT_STYLE != "position":
            raise NotImplementedError("%s phải tự viết protection_orders() cho PROT_STYLE=%r" % (type(self).__name__, self.PROT_STYLE))
        out = []
        for row in self.position_levels(symbol):
            sl, tp = float(row.get("sl") or 0.0), float(row.get("tp") or 0.0)
            if self._row_owned(row) and (sl > 0.0 or tp > 0.0):
                out.append(position_entry(row, sl, tp))
        return out
