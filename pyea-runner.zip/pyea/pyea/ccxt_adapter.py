"""
Adapter `ccxt` - "mọi sàn khác dùng API" (Bybit, OKX, Kraken, KuCoin, Bitget, Gate, MEXC, ... khoảng 100 sàn).
exchange = ccxt, đặt `ccxt_id` = tên sàn theo ccxt (vd bybit, okx, kraken), khoá API ở các ô ccxt_*.

LƯU Ý THẲNG THẮN:
  - ccxt KHÔNG nằm trong requirements mặc định của bản dựng Android (thư viện lớn, kéo theo nhiều gói; chưa kiểm chứng build trên p4a).
    Nếu chưa có, app báo rõ cách bật: thêm `ccxt` vào `requirements` trong buildozer.spec rồi build lại (hoặc chạy trên máy tính).
  - Mỗi sàn có khác biệt riêng (lệnh dừng, ký quỹ, hedge/one-way). Vỏ chỉ dùng phần UNIFIED: market, limit (+ stop-market nếu sàn khai báo
    has['createStopMarketOrder']), cancel, fetch_order, fetch_open_orders, fetch_positions, fetch_balance, fetch_my_trades.
    LUÔN thử bằng testnet/sandbox (ccxt_options {"sandbox": true}) trước khi live.
  - Spot: ví coin (spot_like, không bán khống). Phái sinh (swap/future): vị thế thật qua fetch_positions.
"""
import json
import re
import time

from .broker import BrokerError, Fill
from .feeds import FeedError, TIMEFRAMES, history_resampled, tf_seconds
from .ratelimit import limiter_for
from .sdk import Candle, Tick


def _load_ccxt():
    try:
        import ccxt                                           # noqa: PLC0415
    except ImportError:
        raise BrokerError("Chưa cài thư viện ccxt. Máy tính: pip install ccxt. Android: thêm 'ccxt' vào requirements trong buildozer.spec rồi build lại "
                          "(chưa kiểm chứng trên p4a - nếu build lỗi hãy dùng Exness/MetaApi/cổng MT hoặc Binance/OANDA có sẵn).")
    return ccxt


def _opts(settings):
    raw = str(settings.get("ccxt_options") or "").strip()
    if not raw:
        return {}
    try:
        d = json.loads(raw)
        return d if isinstance(d, dict) else {}
    except ValueError as e:
        raise BrokerError("ccxt_options không phải JSON hợp lệ: %s" % e)


_EX = {}


def exchange_for(settings):
    """Một đối tượng ccxt cho mỗi cấu hình (feed + broker dùng chung)."""
    key = json.dumps({k: settings.get(k) for k in ("ccxt_id", "ccxt_api_key", "ccxt_secret", "ccxt_password", "ccxt_options")}, sort_keys=True)
    if key in _EX:
        return _EX[key]
    ccxt = _load_ccxt()
    eid = str(settings.get("ccxt_id") or "").strip().lower()
    if not eid:
        raise BrokerError("Chưa nhập ccxt_id (tên sàn theo ccxt, vd bybit, okx, kraken)")
    cls = getattr(ccxt, eid, None)
    if cls is None:
        raise BrokerError("ccxt không có sàn '%s' (xem danh sách: ccxt.exchanges)" % eid)
    opts = _opts(settings)
    sandbox = bool(opts.pop("sandbox", False))
    cfg = {"enableRateLimit": True, "timeout": 20000}
    if settings.get("ccxt_api_key"):
        cfg["apiKey"] = settings["ccxt_api_key"]
    if settings.get("ccxt_secret"):
        cfg["secret"] = settings["ccxt_secret"]
    if settings.get("ccxt_password"):
        cfg["password"] = settings["ccxt_password"]
    cfg.update(opts)
    ex = cls(cfg)
    if sandbox and hasattr(ex, "set_sandbox_mode"):
        ex.set_sandbox_mode(True)
    _EX[key] = ex
    return ex


def _wrap(fn, *a, **k):
    try:
        return fn(*a, **k)
    except BrokerError:
        raise
    except Exception as e:                                    # noqa: BLE001 - mọi lỗi ccxt (NetworkError, ExchangeError, ...) -> thông điệp rõ
        raise BrokerError("%s: %s" % (type(e).__name__, str(e)[:240]))


class CcxtFeed:
    name = "ccxt"
    max_chunk = 500

    def __init__(self, ex, limiter=None):
        self.ex = ex
        self.lim = limiter or limiter_for("ccxt", getattr(ex, "id", "ccxt"))
        self._loaded = False

    def _markets(self):
        if not self._loaded:
            self.lim.acquire(5)
            _wrap(self.ex.load_markets)
            self._loaded = True
        return self.ex.markets

    def symbols(self):
        try:
            return sorted(s for s, m in self._markets().items() if m.get("active", True) is not False)
        except BrokerError as e:
            raise FeedError(str(e))

    def tick(self, symbol):
        try:
            self.lim.acquire(1)
            t = _wrap(self.ex.fetch_ticker, symbol)
        except BrokerError as e:
            raise FeedError(str(e))
        bid, ask, last = t.get("bid"), t.get("ask"), t.get("last")
        bid = bid or last
        ask = ask or last
        if not bid or not ask:
            raise FeedError("Chưa có giá %s" % symbol)
        ts = (t.get("timestamp") or time.time() * 1000) / 1000.0
        return Tick(symbol, ts, float(bid), float(ask), tradeable=True)

    def history(self, symbol, tf, n, end=None):
        from .feeds import utc_guard
        return utc_guard(self, lambda: self._native_history(symbol, tf, n, end), symbol, tf, n, end)

    def _native_history(self, symbol, tf, n, end=None):
        tfs = getattr(self.ex, "timeframes", None) or {}
        step = tf_seconds(tf)
        if tfs and tf not in tfs:
            base = [x for x in ("1m", "5m", "15m", "30m", "1h", "1d") if x in tfs and tf_seconds(x) <= step and step % tf_seconds(x) == 0]
            if not base:
                raise FeedError("Sàn không có khung %s" % tf)
            return history_resampled(self, base, symbol, tf, n, end)
        n = int(min(n, self.max_chunk))
        since = None
        if end is not None:
            since = int((end - (n + 1) * step) * 1000)
        else:
            since = int((time.time() - (n + 2) * step) * 1000)
        try:
            self.lim.acquire(2)
            rows = _wrap(self.ex.fetch_ohlcv, symbol, tf, since, n + 2)
        except BrokerError as e:
            raise FeedError(str(e))
        out = [Candle(r[0] / 1000.0, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5] or 0)) for r in rows or []]
        if end is not None:
            out = [c for c in out if c.time < end]
        return sorted(out, key=lambda c: c.time)[-n:]

    def close(self):
        pass


class CcxtBroker:
    supports_short = True
    netting = True
    spot_like = False

    def __init__(self, ex, limiter=None):
        self.ex = ex
        self.lim = limiter or limiter_for("ccxt", getattr(ex, "id", "ccxt"))
        self.native_pending = {"limit"}
        has = getattr(ex, "has", {}) or {}
        if has.get("createStopMarketOrder") or has.get("createStopOrder"):
            self.native_pending.add("stop")
        self._watch = set()
        self._native = {}
        self._quote = "USDT"
        self._loaded = False

    # ---- thị trường ----
    def _market(self, symbol):
        if not self._loaded:
            self.lim.acquire(5)
            _wrap(self.ex.load_markets)
            self._loaded = True
        m = (self.ex.markets or {}).get(symbol)
        if not m:
            raise BrokerError("Sàn không có mã %s" % symbol)
        return m

    def set_watch(self, symbols):
        self._watch = set(symbols or ())

    def prepare(self, symbol, leverage=1.0):
        m = self._market(symbol)
        spot = bool(m.get("spot"))
        self.supports_short, self.spot_like, self.netting = (not spot), spot, True
        self._quote = m.get("quote") or "USDT"
        if not spot and leverage and leverage > 1 and hasattr(self.ex, "set_leverage"):
            try:
                self.lim.acquire(1)
                _wrap(self.ex.set_leverage, int(leverage), symbol)
            except BrokerError:
                pass                                          # nhiều sàn đã đặt sẵn đòn bẩy hoặc không cho đổi: không chặn phiên
        return self.balance()

    def balance(self):
        self.lim.acquire(2)
        b = _wrap(self.ex.fetch_balance)
        tot = (b.get("total") or {}).get(self._quote)
        if tot is None:
            tot = (b.get(self._quote) or {}).get("total")
        if tot is None:
            raise BrokerError("Không đọc được số dư %s từ sàn" % self._quote)
        return float(tot)

    def _amount(self, symbol, qty):
        try:
            return float(self.ex.amount_to_precision(symbol, qty))
        except Exception:                                      # noqa: BLE001
            return float(qty)

    def _price(self, symbol, price):
        try:
            return float(self.ex.price_to_precision(symbol, price))
        except Exception:                                      # noqa: BLE001
            return float(price)

    def _fill(self, order, symbol, side, qty):
        px = order.get("average") or order.get("price")
        filled = order.get("filled") or qty
        if (not px or not order.get("filled")) and order.get("id"):
            try:
                self.lim.acquire(1)
                o2 = _wrap(self.ex.fetch_order, order["id"], symbol)
                px = o2.get("average") or o2.get("price") or px
                filled = o2.get("filled") or filled
            except BrokerError:
                pass
        if not px:
            t = _wrap(self.ex.fetch_ticker, symbol)
            px = t.get("ask") if side == "buy" else t.get("bid")
        return Fill(float(px), float(filled))

    def market_order(self, symbol, side, qty, reduce_only=False):
        m = self._market(symbol)
        amt = self._amount(symbol, qty)
        if amt <= 0:
            raise BrokerError("Khối lượng %.8g làm tròn theo bước của sàn thành 0" % qty)
        params = {"reduceOnly": True} if (reduce_only and not m.get("spot")) else {}
        self.lim.acquire(1)
        o = _wrap(self.ex.create_order, symbol, "market", side, amt, None, params)
        return self._fill(o, symbol, side, amt)

    # ---- vị thế ----
    def positions(self):
        out = {}
        if self.spot_like:
            if not self._watch:
                return {}
            self.lim.acquire(2)
            tot = (_wrap(self.ex.fetch_balance).get("total")) or {}
            for sy in sorted(self._watch):
                m = (self.ex.markets or {}).get(sy)
                if m and m.get("spot") and (tot.get(m.get("base")) or 0) > 0:
                    out[sy] = {"qty": float(tot[m["base"]]), "price": 0.0}
            return out
        if not hasattr(self.ex, "fetch_positions"):
            raise BrokerError("Sàn này không có fetch_positions (không đối soát được)")
        self.lim.acquire(2)
        for p in _wrap(self.ex.fetch_positions) or []:
            sy, c = p.get("symbol"), float(p.get("contracts") or 0)
            if not sy or c <= 0:
                continue
            q = c if str(p.get("side", "")).lower() == "long" else -c
            n = out.setdefault(sy, {"qty": 0.0, "price": 0.0})
            n["qty"] += q
            n["price"] = float(p.get("entryPrice") or n["price"])
        return out

    # ---- lệnh chờ native ----
    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind not in self.native_pending:
            raise BrokerError("Sàn ccxt này không hỗ trợ lệnh chờ native '%s' qua giao diện thống nhất" % kind)
        amt = self._amount(symbol, volume)
        px = self._price(symbol, price)
        self.lim.acquire(1)
        if kind == "limit":
            o = _wrap(self.ex.create_order, symbol, "limit", side, amt, px, {})
        elif getattr(self.ex, "has", {}).get("createStopMarketOrder"):
            o = _wrap(self.ex.create_stop_market_order, symbol, side, amt, px)
        else:
            o = _wrap(self.ex.create_order, symbol, "market", side, amt, None, {"stopPrice": px, "triggerPrice": px})
        oid = o.get("id")
        if not oid:
            raise BrokerError("Sàn nhận lệnh chờ nhưng không trả mã lệnh")
        self._native[str(oid)] = symbol
        return str(oid)

    def cancel_pending(self, native_id, symbol=None):
        symbol = symbol or self._native.get(str(native_id))
        self.lim.acquire(1)
        _wrap(self.ex.cancel_order, native_id, symbol)
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        """Dùng edit_order nếu sàn có; không thì huỷ + đặt lại (mã lệnh ĐỔI)."""
        if price is None:
            return str(native_id)
        symbol = symbol or self._native.get(str(native_id))
        self.lim.acquire(1)
        old = _wrap(self.ex.fetch_order, native_id, symbol)
        side, typ, amt = old.get("side"), str(old.get("type") or "limit"), float(old.get("remaining") or old.get("amount") or 0)
        if getattr(self.ex, "has", {}).get("editOrder"):
            o = _wrap(self.ex.edit_order, native_id, symbol, typ, side, amt, self._price(symbol, price))
            nid = str(o.get("id") or native_id)
        else:
            self.cancel_pending(native_id, symbol)
            kind = "limit" if typ == "limit" else "stop"
            nid = self.place_pending(symbol, side, kind, amt, price)
        if nid != str(native_id):
            self._native.pop(str(native_id), None)
            self._native[nid] = symbol
        return nid

    def pending_orders(self, known=None):
        syms = set(self._native.values()) | {s for _, s in (known or [])}
        out = {}
        for sy in sorted(syms):
            self.lim.acquire(1)
            for o in _wrap(self.ex.fetch_open_orders, sy) or []:
                px = o.get("price") or o.get("stopPrice") or o.get("triggerPrice") or (o.get("info") or {}).get("stopPrice") or 0
                out[str(o.get("id"))] = {"symbol": sy, "side": o.get("side"), "price": float(px), "qty": float(o.get("amount") or 0), "type": o.get("type")}
        return out

    _STATE = {"open": "open", "closed": "filled", "canceled": "canceled", "cancelled": "canceled", "expired": "expired", "rejected": "rejected"}

    def order_result(self, native_id, symbol=None):
        symbol = symbol or self._native.get(str(native_id))
        self.lim.acquire(1)
        o = _wrap(self.ex.fetch_order, native_id, symbol)
        st = self._STATE.get(str(o.get("status", "")).lower(), "unknown")
        filled = float(o.get("filled") or 0)
        if st in ("canceled", "expired") and filled > 0:
            st = "filled"
        out = {"state": st}
        if st == "filled" and filled > 0:
            out.update(price=float(o.get("average") or o.get("price") or 0), qty=filled)
        if st in ("filled", "canceled", "expired", "rejected"):
            self._native.pop(str(native_id), None)
        return out

    # ---- lịch sử ----
    def history(self, since=0.0, symbols=None):
        out = []
        for sy in sorted(set(symbols or self._watch or [])):
            self.lim.acquire(2)
            for t in _wrap(self.ex.fetch_my_trades, sy, int(since * 1000) if since else None) or []:
                fee = t.get("fee") or {}
                out.append({"id": str(t.get("id")), "time": (t.get("timestamp") or 0) / 1000.0, "symbol": sy, "side": t.get("side"),
                            "qty": float(t.get("amount") or 0), "price": float(t.get("price") or 0), "fee": float(fee.get("cost") or 0),
                            "fee_asset": fee.get("currency", ""), "pnl": 0.0, "order_id": str(t.get("order") or "")})
        return sorted(out, key=lambda r: r["time"])

    # ---- lịch sử tài khoản đầy đủ qua bộ máy chung pyea/histengine.py (hồ sơ «ccxt»). CHỈ các hàm ĐỌC trong danh sách này được gọi ----
    HIST_METHODS = {"fetch_my_trades": ("symbol", "since", "limit"), "fetch_funding_history": ("symbol", "since", "limit"),
                    "fetch_deposits": ("code", "since", "limit"), "fetch_withdrawals": ("code", "since", "limit"),
                    "fetch_ledger": ("code", "since", "limit")}

    def history_call(self, method, name, params=None, body=None):
        names = self.HIST_METHODS.get(name)
        if names is None:
            raise BrokerError("ccxt: hàm «%s» không nằm trong danh sách hàm ĐỌC lịch sử được phép (%s)" % (name, ", ".join(sorted(self.HIST_METHODS))))
        fn = getattr(self.ex, name, None)
        if not callable(fn):
            raise BrokerError("ccxt: sàn này không có %s" % name)
        args = [(params or {}).get(a) for a in names]
        while args and args[-1] is None:                         # ccxt: tham số cuối bỏ trống thì không truyền (tương thích cả bản cũ)
            args.pop()
        self.lim.acquire(2)
        return _wrap(fn, *args)

    def history_ctx(self):
        has = getattr(self.ex, "has", {}) or {}
        return {"symbols": sorted(self._watch or []), "quote": self._quote, "account": "",
                "capabilities": {k for k, v in has.items() if v}}

    def account_history(self, since, until=None):
        from . import histengine
        return histengine.run_for_broker(self, "ccxt", since, until)


def make_ccxt_feed(settings):
    return CcxtFeed(exchange_for(settings))


def make_ccxt_broker(settings):
    return CcxtBroker(exchange_for(settings))
