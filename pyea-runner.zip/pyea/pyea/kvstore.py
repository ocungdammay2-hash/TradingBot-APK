"""
Kho khoá-giá trị JSON cho bot: `self.api.store` (RIÊNG từng bot, sống qua lần khởi động lại) và `self.api.shared` (DÙNG CHUNG giữa các bot
trong cùng tài khoản - giống GlobalVariableSet/Get của MT5). Chỉ nhận giá trị JSON (None/bool/số/chuỗi/list/dict); get() trả BẢN SAO
nên bot không vô tình sửa kho bằng cách sửa đối tượng đã lấy ra.

  - ghi NGAY (ghi tạm + đổi tên nguyên tử) nhưng BỎ QUA nếu giá trị không đổi -> gọi set() mỗi tick không làm mòn bộ nhớ flash;
  - giới hạn: khoá ≤ 80 ký tự, mỗi giá trị ≤ 64 KB, tối đa 500 khoá, tổng ≤ 256 KB (vượt -> ValueError);
  - path=None -> chỉ trong bộ nhớ (backtest/tối ưu: KHÔNG được rò trạng thái giữa các lần chạy);
  - file hỏng/không đọc được -> bắt đầu rỗng, giữ file cũ thành *.corrupt để người dùng cứu dữ liệu.
"""
import copy
import json
import os
import threading

MAX_KEY = 80
MAX_VALUE = 64 * 1024
MAX_KEYS = 500
MAX_TOTAL = 256 * 1024

OPS = ("get", "set", "delete", "keys", "items", "clear", "incr", "has", "size")


class KVStore:
    def __init__(self, path=None, max_total=MAX_TOTAL, max_value=MAX_VALUE, max_keys=MAX_KEYS):
        self.path = path
        self.max_total, self.max_value, self.max_keys = max_total, max_value, max_keys
        self._lock = threading.RLock()
        self._d = {}
        self._load()

    # ---- đĩa ----
    def _load(self):
        if not self.path or not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if not isinstance(d, dict):
                raise ValueError("không phải dict")
            self._d = {str(k): v for k, v in d.items()}
        except (OSError, ValueError):
            try:
                os.replace(self.path, self.path + ".corrupt")
            except OSError:
                pass
            self._d = {}

    def _flush(self):
        if not self.path:
            return
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self._d, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, self.path)

    # ---- kiểm tra ----
    @staticmethod
    def _key(key):
        if not isinstance(key, str) or not key or len(key) > MAX_KEY:
            raise ValueError("Khoá phải là chuỗi không rỗng, tối đa %d ký tự" % MAX_KEY)
        return key

    def _clean(self, value):
        try:
            raw = json.dumps(value, ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError) as e:
            raise ValueError("Giá trị phải là JSON (None/bool/số/chuỗi/list/dict, không NaN): %s" % e)
        if len(raw.encode("utf-8")) > self.max_value:
            raise ValueError("Giá trị quá lớn (> %d byte)" % self.max_value)
        return json.loads(raw)

    def _total(self, d):
        return sum(len(k.encode("utf-8")) + len(json.dumps(v, ensure_ascii=False).encode("utf-8")) for k, v in d.items())

    # ---- API ----
    def get(self, key, default=None):
        with self._lock:
            v = self._d.get(self._key(key), default)
            return copy.deepcopy(v)

    def has(self, key):
        with self._lock:
            return self._key(key) in self._d

    def set(self, key, value):
        key, value = self._key(key), self._clean(value)
        with self._lock:
            if key in self._d and self._d[key] == value:
                return False                                   # không đổi -> không ghi đĩa
            new = dict(self._d)
            new[key] = value
            if len(new) > self.max_keys:
                raise ValueError("Quá nhiều khoá (> %d)" % self.max_keys)
            if self._total(new) > self.max_total:
                raise ValueError("Kho đầy (> %d byte)" % self.max_total)
            self._d = new
            self._flush()
            return True

    def incr(self, key, delta=1):
        """Cộng `delta` (số) vào giá trị (thiếu = 0), nguyên tử giữa các luồng. -> giá trị mới."""
        with self._lock:
            cur = self._d.get(self._key(key), 0)
            if isinstance(cur, bool) or not isinstance(cur, (int, float)):
                raise ValueError("Khoá %r không phải số" % key)
            if isinstance(delta, bool) or not isinstance(delta, (int, float)):
                raise ValueError("delta phải là số")
            self.set(key, cur + delta)
            return self._d[key]

    def delete(self, key):
        with self._lock:
            if self._key(key) not in self._d:
                return False
            new = dict(self._d)
            del new[key]
            self._d = new
            self._flush()
            return True

    def keys(self):
        with self._lock:
            return sorted(self._d)

    def items(self):
        with self._lock:
            return {k: copy.deepcopy(v) for k, v in sorted(self._d.items())}

    def clear(self):
        with self._lock:
            if not self._d:
                return 0
            n = len(self._d)
            self._d = {}
            self._flush()
            return n

    def size(self):
        with self._lock:
            return len(self._d)

    def call(self, op, *args):
        """Cổng RPC (bot chạy ở tiến trình riêng): chỉ cho các thao tác trong OPS."""
        if op not in OPS:
            raise AttributeError("kho không có thao tác '%s'" % op)
        return getattr(self, op)(*args)
