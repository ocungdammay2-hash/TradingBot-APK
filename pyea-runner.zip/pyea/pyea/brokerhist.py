"""
LỊCH SỬ DO SÀN BÁO (giống tab «Lịch sử» của MT5: Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư, và danh sách vị thế đã đóng).

Hợp đồng chung cho broker (tuỳ chọn): `broker.account_history(since, until) -> [deal]`, mỗi deal là dict đã chuẩn hoá:
    id, time (epoch UTC), kind ("trade" | "balance" | "credit" | "other"), symbol, side ("buy"|"sell"), qty, price,
    entry ("IN" | "OUT" | "INOUT" | "OUT_BY" | ""), position_id, order_id,
    profit (lãi/lỗ của deal; với kind != trade là SỐ TIỀN của thao tác: nạp +, rút -),
    commission, swap, fee (mỗi thứ MỘT số riêng - không gộp), comment
Hàm ở đây chỉ xử lý dữ liệu ĐÃ chuẩn hoá nên chạy giống nhau cho mọi sàn (MT/MetaApi/cổng/Profile/Exness...). Sàn không báo trường nào thì để 0 hoặc None -
KHÔNG bịa số; sàn không có `account_history` thì giao diện nói rõ «sàn này chưa có lịch sử đồng bộ».

Định nghĩa các số theo tài liệu MT5 («History» của MetaTrader 5 mobile):
    Tiền nạp  = tổng nạp và rút (deal loại balance)
    Lợi nhuận = tổng lãi/lỗ của các deal giao dịch, KHÔNG gồm swap và hoa hồng
    Phí qua đêm = tổng swap · Phí trung gian = tổng hoa hồng (và phí `fee` của deal)
    Số dư     = tổng các thao tác trong kỳ = tiền nạp + lợi nhuận + swap + hoa hồng (+ khoản khác như credit/điều chỉnh)
    Vị thế    = các deal cùng một position_id gộp lại: giờ mở/đóng, khối lượng, giá mở/đóng bình quân gia quyền, kết quả KHÔNG gồm swap/hoa hồng
"""
KINDS = ("trade", "balance", "credit", "other")


def classify(raw_type):
    """Tên loại deal gốc của sàn (vd MT5 'DEAL_TYPE_BALANCE', 'balance', 'swap_fee') -> kind chuẩn."""
    t = str(raw_type or "").upper()
    if "BUY" in t or "SELL" in t:
        return "trade"
    if "BALANCE" in t or "DEPOSIT" in t or "WITHDRAW" in t:
        return "balance"
    if "CREDIT" in t:
        return "credit"
    return "other"


def _f(x, d=0.0):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return d
    return v if v == v and abs(v) != float("inf") else d


def norm_deal(d):
    """Đảm bảo mọi khoá của hợp đồng có mặt (kiểu đúng), giữ nguyên giá trị đã có."""
    out = dict(d)
    out["id"] = str(d.get("id", ""))
    out["time"] = _f(d.get("time"))
    kind = d.get("kind")
    out["kind"] = kind if kind in KINDS else "trade"
    out["symbol"] = d.get("symbol") or ""
    out["side"] = d.get("side") or ""
    for k in ("qty", "price", "profit", "commission", "swap", "fee"):
        out[k] = _f(d.get(k))
    out["entry"] = str(d.get("entry") or "").upper()
    out["position_id"] = str(d.get("position_id") or "")
    out["order_id"] = str(d.get("order_id") or "")
    out["comment"] = str(d.get("comment") or "")
    return out


def _is_out(d):
    return "OUT" in d["entry"]


def _is_in(d):
    return d["entry"] == "IN"


def summarize(deals):
    """Tổng kỳ như khung tóm tắt của tab Lịch sử MT5. Trả dict: profit, deposit, swap, commission, other, balance, trades (số deal giao dịch),
    positions (số vị thế đã đóng trong kỳ), deposits (số lần nạp/rút)."""
    ds = [norm_deal(d) for d in deals or []]
    profit = sum(d["profit"] for d in ds if d["kind"] == "trade")
    swap = sum(d["swap"] for d in ds)                                   # swap/hoa hồng tính trên MỌI deal: có sàn ghi chúng thành deal riêng (vd phí swap, phí quản trị)
    comm = sum(d["commission"] + d["fee"] for d in ds)
    dep = sum(d["profit"] for d in ds if d["kind"] == "balance")
    other = sum(d["profit"] for d in ds if d["kind"] in ("credit", "other"))
    return {"profit": profit, "deposit": dep, "swap": swap, "commission": comm, "other": other,
            "balance": dep + profit + swap + comm + other,
            "trades": sum(1 for d in ds if d["kind"] == "trade"), "positions": len(positions_from_deals(ds)),
            "deposits": sum(1 for d in ds if d["kind"] == "balance")}


def positions_from_deals(deals):
    """Gộp deal giao dịch theo position_id -> vị thế ĐÃ ĐÓNG (có ít nhất một deal đóng trong dữ liệu), mới nhất trước.
    Mỗi dòng: position_id, symbol, side (chiều của vị thế), volume, open_price, close_price (bình quân theo khối lượng), open_time (None nếu mở trước kỳ),
    close_time, profit (không gồm swap/hoa hồng), swap, commission, comment."""
    groups, order = {}, []
    for raw in deals or []:
        d = norm_deal(raw)
        if d["kind"] != "trade":
            continue
        key = d["position_id"] or ("deal:" + d["id"])
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(d)
    rows = []
    for key in order:
        g = sorted(groups[key], key=lambda d: (d["time"], d["id"]))
        outs = [d for d in g if _is_out(d)]
        if not outs:
            continue                                         # còn đang mở (hoặc deal lẻ không rõ chiều vào/ra) - không phải lịch sử
        ins = [d for d in g if _is_in(d)]
        ref = ins[0] if ins else outs[0]
        side = ref["side"] if ins else ("sell" if ref["side"] == "buy" else "buy")     # không thấy deal mở (mở trước kỳ): chiều vị thế ngược chiều deal đóng
        vin, vout = sum(d["qty"] for d in ins), sum(d["qty"] for d in outs)

        def vwap(rs):
            q = sum(d["qty"] for d in rs)
            return sum(d["price"] * d["qty"] for d in rs) / q if q > 0 else 0.0
        rows.append({"position_id": "" if key.startswith("deal:") else key, "symbol": ref["symbol"], "side": side, "volume": vin or vout,
                     "open_price": vwap(ins) if ins else 0.0, "close_price": vwap(outs), "open_time": ins[0]["time"] if ins else None,
                     "close_time": outs[-1]["time"], "profit": sum(d["profit"] for d in g), "swap": sum(d["swap"] for d in g),
                     "commission": sum(d["commission"] + d["fee"] for d in g), "comment": next((d["comment"] for d in g if d["comment"]), "")})
    rows.sort(key=lambda r: -r["close_time"])
    return rows


# ---------------------------------------------------------------------------------------------- lấy từ sàn
PERIODS = (("Hôm nay", 1), ("7 ngày", 7), ("30 ngày", 30), ("90 ngày", 90), ("180 ngày", 180))


def day_start(now, tz_offset_s=0.0):
    """0h của ngày hiện tại theo múi giờ cho trước (epoch UTC)."""
    local = now + tz_offset_s
    return local - (local % 86400.0) - tz_offset_s


def fetch(broker, since, until=None):
    """Gọi broker.account_history; trả {"deals": [...], "summary": {...}, "positions": [...]}. Broker không hỗ trợ -> ném NotImplementedError với lời nhắn rõ."""
    fn = getattr(broker, "account_history", None)
    if fn is None:
        raise NotImplementedError("Sàn/cầu nối này chưa có lịch sử đồng bộ từ sàn (app vẫn có lịch sử các lệnh do chính nó đóng)")
    try:
        broker.history_notes = []                           # ghi chú của LẦN GỌI NÀY (bộ máy lịch sử chung đặt lại sau khi chạy)
    except AttributeError:
        pass
    deals = [norm_deal(d) for d in (fn(float(since), float(until) if until else None) or [])]
    return {"deals": deals, "summary": summarize(deals), "positions": positions_from_deals(deals),
            "notes": [str(n) for n in (getattr(broker, "history_notes", None) or [])]}


def is_warning(note):
    """Ghi chú cảnh báo (số liệu có thể thiếu) khác ghi chú thông tin - giao diện tô vàng."""
    return str(note).startswith("CHÚ Ý")


def fetch_for_settings(settings, since, until=None):
    """Dựng MỘT broker tạm từ cài đặt (chỉ đọc), lấy lịch sử rồi đóng. Dùng cho giao diện (không cần phiên đang chạy)."""
    from .broker import make_broker
    if str(settings.get("mode")) != "live" or str(settings.get("exchange")) == "simulated":
        raise NotImplementedError("Đang ở chế độ giả lập (paper): không có lịch sử từ sàn thật - chọn chế độ chạy thật để xem")
    b = make_broker(settings)
    try:
        sw = getattr(b, "set_watch", None)                    # sàn hỏi lịch sử theo từng mã: cho nó biết các mã trong Danh sách theo dõi
        if callable(sw):
            from .engine import parse_watchlist
            sw(parse_watchlist(settings.get("watchlist")))
        return fetch(b, since, until)
    finally:
        close = getattr(b, "close", None)
        if callable(close):
            try:
                close()
            except Exception:                                # noqa: BLE001 - đóng thất bại không được che kết quả
                pass


def money(x, digits=2):
    """12345.6 -> '12 345.60' (nhóm nghìn bằng dấu cách như MT5 mobile)."""
    s = "%.*f" % (digits, _f(x))
    ip, _, fp = s.partition(".")
    neg = ip.startswith("-")
    ip = ip.lstrip("-")
    grp = []
    while len(ip) > 3:
        grp.insert(0, ip[-3:])
        ip = ip[:-3]
    grp.insert(0, ip)
    return ("-" if neg else "") + " ".join(grp) + ("." + fp if fp else "")
