"""
Đối soát vị thế giữa SỔ NỘI BỘ của app và SÀN THẬT (chỉ live, sàn có hàm positions()):
  orphan   sàn có vị thế mà sổ app không có (vd bạn tự vào lệnh trên app của sàn, hoặc app crash giữa chừng)
  ghost    sổ app còn vị thế mà sàn không còn (vd bị thanh lý/chốt trên app sàn)
  mismatch cả hai có nhưng khác chiều/khối lượng
Chính sách (settings.reconcile_policy): "adopt" (mặc định - sổ app đổi theo SÀN), "alert" (chỉ báo), "off".
Chạy mỗi reconcile_interval giây, NGAY sau khi một lệnh gửi sàn lỗi/không rõ kết quả, và ngay khi có lại kết nối (xem linkwatch.py).

«adopt» sửa sổ app SAO CHO ĐÚNG SỰ THẬT TRÊN SÀN mà vẫn giữ được nhiều nhất có thể:
  * chỉ sửa khi cùng một chênh lệch xuất hiện ở HAI lần đối soát liên tiếp (chặn một lần sàn trả lời thiếu/lỗi làm xoá nhầm sổ);
  * sàn đóng BỚT/HẾT vị thế (SL/TP/thanh lý/đóng tay trên app sàn lúc app tắt hay mất mạng): chỉ đóng phần chênh trong sổ app, vị thế MỚI NHẤT trước,
    các vị thế còn lại giữ nguyên id/chủ sở hữu/SL/TP; GIÁ RA và GIỜ RA lấy từ các lần khớp THẬT của sàn (`history`) mà app chưa ghi sổ - không có
    lịch sử thì dùng giá hiện tại và ghi rõ trong sự kiện;
  * sàn có THÊM vị thế app không có (lệnh gửi dở lúc crash, hoặc bạn vào tay): nhập phần chênh thành vị thế «thủ công» (giá vào theo lần khớp thật nếu tra được);
    vị thế sẵn có KHÔNG bị đụng tới;
  * sàn đảo chiều so với sổ: đóng hết vị thế trong sổ rồi nhập vị thế thật.
  * DANH TÍNH VỊ THẾ (sàn có vị thế riêng + ticket: MT hedging, Exness...): khi broker khai `CLOSE_BY_REF` + `hedged_positions()` và mọi vị thế ảo của mã mang
    ticket duy nhất thì đối chiếu CHÍNH XÁC theo ticket (vị thế nào đã mất/giảm, vị thế nào mới xuất hiện kèm SL/TP và giá vào của sàn) thay vì suy «mới nhất
    trước»; giá ra lấy từ deal đóng của chính ticket đó (`broker.position_close(ref)`) nếu có.
"""
import time

from .broker import BrokerError
from .feeds import FeedError
from .sdk import Position


_BOOKED_MAX = 3000
CONFIRM_S = 2.0                             # lần thấy lại phải cách lần đầu ít nhất chừng này giây


class ReconcileMixin:
    def _book_order(self, oid):
        """Ghi nhớ «lệnh sàn này app đã ghi sổ» - để khi tra lịch sử khớp của sàn biết lần khớp nào là của app, lần nào là từ bên ngoài.
        Nhận một mã hoặc nhiều mã cách nhau dấu phẩy (một lần đóng chia nhiều ticket sinh nhiều lệnh)."""
        for one in str(oid or "").split(","):
            one = one.strip()
            if not one:
                continue
            self._booked.pop(one, None)
            self._booked[one] = 1
        while len(self._booked) > _BOOKED_MAX:
            self._booked.pop(next(iter(self._booked)))

    def _recon_init(self):
        self.recon = {"last": 0.0, "ok": None, "issues": [], "checks": 0, "supported": False, "policy": "adopt"}
        self._recon_next = 0.0
        self._recon_seen = set()
        self._recon_pending = {}            # khoá chênh lệch -> giờ thấy lần đầu (adopt chỉ sửa khi thấy lại)
        self._recon_ok = {}                 # mã -> giờ gần nhất sổ app KHỚP sàn (mốc để tra các lần khớp chưa ghi sổ)
        self._booked = {}                   # mã lệnh sàn mà app đã ghi sổ (giữ thứ tự thêm vào, tối đa _BOOKED_MAX)

    def reconcile_due(self, delay=0.0):
        """Yêu cầu đối soát sớm (vd sau khi gửi lệnh bị lỗi không rõ kết quả)."""
        self._recon_next = time.time() + delay

    PUSH_DEBOUNCE = 3.0

    def _push_reconcile_due(self, b):
        """Sàn có ĐẨY sự kiện lệnh/vị thế (broker khai `change_seq()`, vd MT5 trực tiếp): có thay đổi mới -> đối soát sớm sau PUSH_DEBOUNCE giây (chờ vỏ ghi sổ xong lệnh của chính
        mình, và không chạy khi đang gửi lệnh) thay vì chờ hết chu kỳ. Nhờ vậy SL/TP chạm trên sàn được ghi nhận sau vài giây chứ không phải tới 60 giây."""
        cs = getattr(b, "change_seq", None)
        if not callable(cs):
            return False
        try:
            cur = cs()
        except Exception:                                       # noqa: BLE001 - tín hiệu phụ, không được làm sập vòng lặp
            return False
        last, now = getattr(self, "_recon_seq", None), time.time()
        if last is None:
            self._recon_seq = cur
            return False
        if cur != last and getattr(self, "_recon_push_at", None) is None:
            self._recon_push_at = now + self.PUSH_DEBOUNCE
        at = getattr(self, "_recon_push_at", None)
        if at is None or now < at:
            return False
        lock = getattr(self, "_trade_lock", None)
        if lock is not None and not lock.acquire(False):
            return False                                        # đang gửi lệnh: để lượt sau
        if lock is not None:
            lock.release()
        self._recon_seq, self._recon_push_at = cur, None
        return True

    def _bridge_alerts_due(self, b):
        """Cầu nối khai `pop_alerts()` (vd MT5 qua EA: mất cầu nối, EA đứng, công tắc người chết đã chạy, token sai...) -> báo động ngay cho người dùng, không chờ chu kỳ đối soát."""
        fn = getattr(b, "pop_alerts", None)
        if not callable(fn):
            return
        try:
            alerts = fn()
        except Exception:                                       # noqa: BLE001 - tín hiệu phụ
            return
        for a in alerts or ():
            try:
                self.alarm(a.get("title", "Cầu nối"), a.get("text", ""), critical=bool(a.get("critical", True)))
            except Exception:                                   # noqa: BLE001
                pass

    def _check_reconcile(self):
        iv = float(self.settings.get("reconcile_interval") or 0)
        b = self.broker
        if b is not None:
            self._bridge_alerts_due(b)
        if b is None or iv <= 0 or not hasattr(b, "positions") or self.settings.get("reconcile_policy", "adopt") == "off":
            return
        push = self._push_reconcile_due(b)
        if not push and time.time() < self._recon_next:
            return
        self._recon_next = time.time() + iv
        try:
            self.reconcile_now()
        except Exception as e:                                  # đối soát lỗi không được làm sập phiên
            self.log("Đối soát với sàn lỗi: %s" % e, "WARN")

    def _local_net(self):
        net = {}
        for p in self.account.positions.values():
            net[p.symbol] = net.get(p.symbol, 0.0) + (p.volume if p.side == "buy" else -p.volume)
        return net

    def reconcile_now(self):
        """Một lượt đối soát. Trả về list issue (dict). Cập nhật self.recon (hiện trên giao diện)."""
        b = self.broker
        policy = self.settings.get("reconcile_policy", "adopt")
        if b is None or not hasattr(b, "positions"):
            return []
        if hasattr(b, "set_watch"):                             # Spot: chỉ hỏi số dư của các mã vỏ đang quan tâm
            with self.lock:
                b.set_watch(set(self._local_net()) | set(self.needed_symbols()))
        try:
            remote = b.positions()
            self.link_note("reconcile", True)
        except BrokerError as e:
            self.link_note("reconcile", False, e)
            self.recon.update(last=time.time(), ok=None, issues=["Không lấy được vị thế từ sàn: %s" % e], supported=True)
            self.log("Đối soát: không lấy được vị thế từ sàn: %s" % e, "WARN")
            return []
        if remote is None:
            self.recon.update(supported=False)
            return []
        with self.lock:
            local = self._local_net()
        scope_all = self.settings.get("reconcile_scope", "app") == "all"
        relevant = set(local) | set(self.needed_symbols())
        syms = (set(local) | set(remote)) if scope_all else (relevant & (set(local) | set(remote)))
        issues = []
        spot_like = bool(getattr(b, "spot_like", False))
        for sym in sorted(syms):
            lq = local.get(sym, 0.0)
            rq = (remote.get(sym) or {}).get("qty", 0.0)
            spec = self.spec(sym)
            tol = max(1e-9, abs(rq) * 1e-6, 0.5 * spec.volume_step)
            if abs(lq - rq) <= tol:
                self._recon_ok[sym] = time.time()
                continue
            if spot_like:
                if rq + tol >= lq:
                    continue                                    # sàn có >= sổ app: phần dư là coin có sẵn ngoài app (không phải lỗi)
                issues_spot = True
            kind = "orphan" if abs(lq) <= tol else ("ghost" if abs(rq) <= tol else "mismatch")
            text = {"orphan": "Sàn có vị thế %s %.8g nhưng sổ app KHÔNG có", "ghost": "Sổ app có vị thế %s %.8g nhưng sàn KHÔNG còn",
                    "mismatch": "Lệch vị thế %s: sàn %.8g · sổ app %.8g"}[kind]
            if spot_like:
                text = {"ghost": "Sổ app giữ %s %.8g nhưng ví Spot KHÔNG còn coin này (đã bán/rút ở nơi khác?)",
                        "mismatch": "Ví Spot có ÍT hơn sổ app %s: ví %.8g · sổ app %.8g", "orphan": text}[kind]
            text = (text % (sym, rq)) if kind == "orphan" else ((text % (sym, lq)) if kind == "ghost" else (text % (sym, rq, lq)))
            issues.append({"symbol": sym, "kind": kind, "local": lq, "remote": rq, "text": text,
                           "price": (remote.get(sym) or {}).get("price", 0.0)})
        self.recon.update(last=time.time(), ok=not issues, issues=[i["text"] for i in issues], checks=self.recon["checks"] + 1,
                          supported=True, policy=policy)
        now = time.time()
        keys = {(i["symbol"], i["kind"], round(i["local"], 8), round(i["remote"], 8)) for i in issues}
        for k in [k for k in self._recon_pending if k not in keys]:
            self._recon_pending.pop(k, None)                    # chênh lệch đã tự hết/đổi: bỏ chờ xác nhận
        for i in issues:
            key = (i["symbol"], i["kind"], round(i["local"], 8), round(i["remote"], 8))
            if key not in self._recon_seen:
                self._recon_seen.add(key)
                self.log("ĐỐI SOÁT: %s%s" % (i["text"], " -> app sẽ đổi sổ theo sàn" if policy == "adopt" else ""), "WARN")
                self.alarm("Lệch vị thế với sàn: %s" % i["symbol"], i["text"])
            if policy == "adopt":
                first = self._recon_pending.setdefault(key, now)
                if now - first < CONFIRM_S:
                    self.reconcile_due(CONFIRM_S + 0.5)        # lần đầu thấy: hỏi lại sớm để xác nhận rồi mới sửa sổ
                    continue
                self._recon_pending.pop(key, None)
                self._adopt(i)
        if not issues:
            self._recon_seen.clear()
        return issues

    # ---- tra các lần khớp THẬT của sàn mà app chưa ghi sổ ----
    def _unbooked_fills(self, sym, side, qty, since):
        """(giá TB, giờ cuối, số lượng tìm được) của các lần khớp chiều `side` từ `since` mà app CHƯA ghi sổ (mới nhất trước, đủ `qty`);
        None nếu sàn không có lịch sử hoặc tìm được dưới một nửa số lượng cần."""
        b = self.broker
        if b is None or not hasattr(b, "history") or qty <= 0:
            return None
        try:
            rows = b.history(max(0.0, since - 120.0), [sym])
        except Exception:                                          # noqa: BLE001 - tra lịch sử hỏng thì dùng giá hiện tại, không làm hỏng đối soát
            return None
        cand = []
        for r in rows or []:
            try:
                if str(r.get("symbol") or sym) != sym or str(r.get("side", "")).lower() != side or float(r.get("time", 0)) < since - 1.0:
                    continue
                if str(r.get("order_id") or "") in self._booked:
                    continue                                        # lệnh của chính app (đã ghi sổ)
                cand.append((float(r["time"]), float(r["qty"]), float(r["price"])))
            except (KeyError, TypeError, ValueError):
                continue
        cand.sort(key=lambda x: -x[0])
        got, notional, last = 0.0, 0.0, 0.0
        for t, q, px in cand:
            take = min(q, qty - got)
            if take <= 0:
                break
            got += take
            notional += take * px
            last = max(last, t)
        if got < qty * 0.5 or got <= 0:
            return None
        return notional / got, last, got

    def _recon_since(self, sym, positions=()):
        """Mốc thời gian để tra lịch sử: lần gần nhất sổ khớp sàn, nhưng không sớm hơn lúc mở vị thế cũ nhất đang xét."""
        base = min((p.open_time for p in positions), default=0.0)
        return max(self._recon_ok.get(sym, 0.0) or 0.0, base) or (time.time() - 6 * 3600.0)

    def _adopt(self, issue):
        """Sửa sổ app theo sàn cho 1 mã (xem chú thích đầu file): đóng PHẦN CHÊNH (mới nhất trước) hoặc nhập phần thiếu; không đụng phần đã khớp."""
        sym, rq = issue["symbol"], issue["remote"]
        try:
            tick = self.get_tick(sym)
        except (FeedError, KeyError, AttributeError):
            return
        if getattr(self.broker, "spot_like", False):
            return self._adopt_spot_shortfall(sym, rq, tick)
        if self._adopt_by_ref(sym, tick):
            self.log("ĐỐI SOÁT: đã đổi sổ app theo sàn cho %s theo TICKET (sàn: %.8g)" % (sym, rq), "WARN")
            self._save_state()
            return
        with self.lock:
            held = sorted((p for p in self.account.positions.values() if p.symbol == sym), key=lambda p: -p.id)
            lq = self._local_net().get(sym, 0.0)
        tol = max(1e-9, abs(rq) * 1e-6, 0.5 * self.spec(sym).volume_step)
        same_side = lq * rq > 0
        if abs(rq) <= tol or (same_side and abs(rq) < abs(lq) - tol):          # sàn đóng bớt/hết: đóng phần chênh trong sổ
            self._adopt_shrink(sym, held, abs(lq) if abs(rq) <= tol else abs(lq) - abs(rq), tick, "sàn đã đóng bớt vị thế này")
        elif same_side and abs(rq) > abs(lq) + tol:                           # sàn có thêm: chỉ nhập phần thêm
            self._adopt_open(sym, rq, abs(rq) - abs(lq), tick, issue.get("price") or 0.0, held)
        else:                                                                   # ngược chiều, hoặc sổ trống mà sàn có (orphan)
            if held:
                self._adopt_shrink(sym, held, abs(lq), tick, "sàn đã đảo chiều so với sổ app")
            self._adopt_open(sym, rq, abs(rq), tick, issue.get("price") or 0.0, [])
        self.log("ĐỐI SOÁT: đã đổi sổ app theo sàn cho %s (sàn: %.8g)" % (sym, rq), "WARN")
        self._save_state()

    def _adopt_shrink(self, sym, held, excess, tick, why, fixed=None):
        """Đóng `excess` khối lượng trong sổ (vị thế mới nhất trước) ở GIÁ/GIỜ khớp thật của sàn (hoặc giá hiện tại nếu không tra được).
        `fixed` = (giá, giờ, cách tính) đã biết chắc (vd deal đóng của đúng ticket)."""
        if excess <= 1e-12 or not held:
            return
        side = held[0].side
        if fixed:
            price, t, how = fixed
        else:
            found = self._unbooked_fills(sym, "sell" if side == "buy" else "buy", excess, self._recon_since(sym, held))
            price, t, how = (found[0], found[1], "lần khớp thật của sàn") if found else (tick.mid, tick.time, "giá hiện tại (không tra được lịch sử khớp của sàn)")
        with self.lock:
            for p in held:
                if excess <= 1e-12:
                    break
                if p.id not in self.account.positions:
                    continue
                cut = min(p.volume, excess)
                tr = self.account.close(p.id, price, t, "reconcile") if cut >= p.volume - 1e-12 else self.account.reduce(p.id, cut, price, t, "reconcile")
                tr.reason = "Đối soát"
                self.add_event("close", sym, price, p.side, cut, p.id, "manual", "Đối soát: %s - sổ app đóng phần này theo sàn" % why,
                               {"nguồn": "đối soát", "giá ra": price, "cách tính giá ra": how}, None, tr.profit, None, p.owner)
                self._save_trade(tr)
                excess -= cut

    def _adopt_by_ref(self, sym, tick):
        """Đối chiếu theo TICKET (xem chú thích đầu file). True nếu đã xử lý (không cần cách suy theo tổng khối lượng)."""
        b = self.broker
        if not (getattr(b, "CLOSE_BY_REF", False) and hasattr(b, "hedged_positions")):
            return False
        with self.lock:
            held = sorted((p for p in self.account.positions.values() if p.symbol == sym), key=lambda p: p.id)
        refs = [p.ref for p in held]
        if any(not r for r in refs) or len(set(refs)) != len(refs):
            return False                                        # sổ cũ chưa có ticket, hoặc nhiều vị thế ảo dùng chung một ticket (netting): suy theo tổng
        try:
            rows = [r for r in b.hedged_positions() if r.get("symbol") == sym]
        except Exception:                                       # noqa: BLE001
            return False
        by = {str(r["id"]): r for r in rows}
        tol = max(1e-9, 0.5 * self.spec(sym).volume_step)
        for p in held:
            r = by.pop(p.ref, None)
            gone = r is None or str(r.get("side") or p.side) != p.side
            left = 0.0 if gone else float(r.get("volume") or 0.0)
            cut = p.volume if gone else p.volume - left
            if cut <= tol:
                continue
            fixed = None
            info = None
            fn = getattr(b, "position_close", None)
            if gone and callable(fn):
                try:
                    info = fn(p.ref)
                except Exception:                               # noqa: BLE001 - tra hỏng thì dùng cách khác
                    info = None
            if info and info.get("price"):
                fixed = (float(info["price"]), float(info.get("time") or tick.time), "deal đóng của chính ticket #%s" % p.ref)
            self._adopt_shrink(sym, [p], cut, tick, "ticket #%s %s" % (p.ref, "không còn trên sàn" if gone else "đã giảm khối lượng"), fixed)
        for rid, r in by.items():                               # vị thế có trên sàn mà sổ app không có ticket đó: nhận vào (kèm SL/TP của sàn)
            self._adopt_open_row(sym, r, tick)
        return True

    def _adopt_open_row(self, sym, r, tick):
        side = str(r.get("side") or "")
        qty = float(r.get("volume") or 0.0)
        if side not in ("buy", "sell") or qty <= 0:
            return
        px = float(r.get("price") or 0.0) or tick.mid
        sl, tp = float(r.get("sl") or 0.0), float(r.get("tp") or 0.0)
        with self.lock:
            from . import ordertag
            origin = str(r.get("origin") or ordertag.classify(r.get("comment"), r.get("magic") or 0))
            tag = ordertag.decode(r.get("comment"))
            owner = "manual"
            if tag["app"] and tag["code"]:                       # app mở nhưng sổ mất (cài lại/xoá dữ liệu): khôi phục bot theo mã trong nhãn
                found = ordertag.match_owner(tag["code"], list(getattr(self, "instances", {}) or {}))
                owner = found or "manual"
            pos = self.account.open(sym, side, qty, px, sl, tp, "Nhận từ sàn (đối soát)", float(r.get("time") or tick.time), owner, ref=str(r["id"]))
            pos.origin = origin
            pos.adopted = owner == "manual"
            why = "Đối soát: nhận vị thế #%s đang có trên sàn vào sổ app (nguồn: %s%s)" % (r["id"], ordertag.origin_name(origin),
                                                                                  "; khôi phục bot %s" % owner if owner != "manual" else "")
            self.add_event("open", sym, px, side, qty, pos.id, owner, why,
                           {"nguồn": "đối soát", "giá vào": px, "ticket": str(r["id"]), "sl": sl or None, "tp": tp or None,
                            "nhãn sàn": str(r.get("comment") or ""), "magic": r.get("magic") or 0}, None, 0.0, None, owner)

    def _adopt_open(self, sym, rq, qty, tick, remote_price, held):
        side = "buy" if rq > 0 else "sell"
        found = self._unbooked_fills(sym, side, qty, self._recon_since(sym, held))
        px, how = (found[0], "lần khớp thật của sàn") if found else (remote_price or tick.mid, "giá vào trung bình sàn báo" if remote_price else "giá hiện tại")
        with self.lock:
            pos = self.account.open(sym, side, qty, px, 0.0, 0.0, "Nhận từ sàn (đối soát)", tick.time, "manual")
            pos.adopted = True
            self.add_event("open", sym, px, side, qty, pos.id, "manual", "Đối soát: nhận vị thế đang có trên sàn vào sổ app",
                           {"nguồn": "đối soát", "giá vào": px, "cách tính giá vào": how}, None, 0.0, None, "manual")

    def _adopt_spot_shortfall(self, sym, rq, tick):
        """Spot: ví có ít coin hơn sổ app -> cắt các vị thế nội bộ (mới nhất trước) cho khớp ví. KHÔNG nhập coin có sẵn ngoài app."""
        with self.lock:
            held = sorted((p for p in self.account.positions.values() if p.symbol == sym), key=lambda p: -p.id)
            excess = sum(p.volume for p in held) - max(0.0, rq)
        self._adopt_shrink(sym, held, excess, tick, "ví Spot có ít coin hơn sổ app")
        self.log("ĐỐI SOÁT (Spot): sổ app %s cắt cho khớp ví (%.8g)" % (sym, rq), "WARN")
        self._save_state()
