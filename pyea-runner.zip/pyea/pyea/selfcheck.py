"""
TỰ KIỂM TRA SÀN - MỘT công cụ chung cho MỌI sàn (Exness, Binance, OANDA, cầu nối MT, ccxt...).

Không có nhánh riêng từng sàn: công cụ chỉ đi qua giao diện chung mà vỏ dùng (pyea/contract.py), tự dò khả năng của adapter
(native_pending, hedged_positions, account_flags, sync_protection...) và kiểm tra HÌNH DẠNG dữ liệu trả về bằng chính các hàm
`contract.check_*`. Cùng đoạn code này được test chạy trên máy chủ giả của từng sàn (tests/test_selfcheck.py), nên cái bạn chạy
trên tài khoản demo là cái đã được kiểm với giả lập - nếu sàn thật khác giả lập, báo cáo sẽ chỉ ra CHỖ NÀO lệch kèm phản hồi
thô của sàn (đã che khoá/chữ ký) để dán lại.

Dùng:
    python -m pyea.selfcheck --template exness > exness.json        # mẫu khoá cần điền (khoá riêng có thể ghi "@/đường/dẫn/key.pem")
    python -m pyea.selfcheck --exchange exness --settings exness.json                 # CHỈ ĐỌC: không gửi lệnh nào
    python -m pyea.selfcheck --exchange exness --settings exness.json --trade --yes   # + lệnh thật KHỐI LƯỢNG NHỎ NHẤT (dùng DEMO)
Bước giao dịch: mua 2 lô nhỏ nhất -> (lệnh chờ xa giá: đặt/sửa/huỷ) -> đóng MỘT PHẦN -> (bảo vệ SL/TP native nếu sàn có) -> đóng nốt,
rồi dọn: huỷ lệnh chờ còn sót, đưa vị thế về mức ban đầu. Mã thoát 0 nếu không có dòng LỖI.
"""
import argparse
import json
import os
import re
import sys
import threading
import time
from urllib.parse import parse_qsl, urlencode, urlsplit

from . import contract, feeds, redact
from .broker import make_broker
from .protection import plan_steps
from .feeds import FeedError, fetch_history, make_feed, tf_seconds

OK, WARN, FAIL, SKIP = "OK", "CHÚ Ý", "LỖI", "BỎ QUA"

DEFAULT_QTY = {"exness": 0.01, "oanda": 1, "binance_spot": 0.001, "binance_futures": 0.002, "metaapi": 0.01, "mt5gw": 0.01,
               "bridge": 0.01, "ccxt": 0.001}
KEY_PREFIXES = {"exness": ("exness_",), "oanda": ("oanda_", "testnet", "base_url"), "binance_spot": ("api_key", "api_secret", "testnet", "base_url"),
                "binance_futures": ("api_key", "api_secret", "testnet", "base_url"), "metaapi": ("metaapi_",), "mt5gw": ("mt5gw_",),
                "bridge": ("bridge_",), "ccxt": ("ccxt_",)}

# ------------------------------------------------------------------------------------------------ che bí mật
_SECRET_NAME = re.compile(r"secret|token|password|passphrase|private|api[_-]?key|apikey|signature|authorization|sign\b", re.I)


def redact_text(txt):
    return redact.redact(txt, aggressive=True)


def redact_url(url):
    u = urlsplit(url)
    q = urlencode([(k, "***" if _SECRET_NAME.search(k) else v) for k, v in parse_qsl(u.query, keep_blank_values=True)])
    return "%s://%s%s%s" % (u.scheme, u.netloc, u.path, ("?" + q) if q else "")


def json_example(scope, miss, rep):
    """Một ví dụ ghi đè cho trường đầu tiên còn thiếu, lấy khoá số chưa dùng đầu tiên làm ứng viên (chỉ là GỢI Ý để người dùng kiểm với bản ghi thô)."""
    import json
    for kind, fields in miss.items():
        cand = rep[kind]["unmatched"]
        if fields and cand:
            return json.dumps({scope or "*": {kind: {fields[0]: cand[0]}}}, ensure_ascii=False)
    return json.dumps({scope or "*": {"position": {"profit": "<tên khoá thật>"}}}, ensure_ascii=False)


def clip(txt, n=500):
    txt = str(txt)
    return txt if len(txt) <= n else txt[:n] + "…(+%d ký tự)" % (len(txt) - n)


# ------------------------------------------------------------------------------------------------ bộ chạy
class Check:
    """Một lượt kiểm tra. `rows` = [{name, status, detail, raw:[phản hồi thô]}]."""

    def __init__(self, settings, trade=False, qty=None, symbol=None, tfs=("1m", "5m", "15m", "1h", "4h"), protect=True, say=None, poll=10.0,
                 feed=None, broker=None, deep=True):
        self.s = dict(settings)
        self.deep = deep
        self._given = (feed, broker)             # adapter dựng sẵn (test cầu nối MT với máy chủ giả mà không đi qua nhà máy cài đặt)
        self.ex = self.s.get("exchange", "simulated")
        self.trade, self.protect, self.say, self.poll_s = trade, protect, say or (lambda m: None), poll
        self.qty = float(qty) if qty else float(DEFAULT_QTY.get(self.ex, 0.01))
        self.symbol_arg, self.tfs = symbol, tuple(tfs)
        self.rows, self.feed, self.broker, self.symbol = [], None, None, None
        self.market_open = True
        self._cur, self._lock, self._seen = None, threading.Lock(), set()
        self.appendix = []

    # ---- thu phản hồi thô ----
    def _tap(self, method, url, status, data, text):
        row = {"method": method, "url": redact_url(url), "status": status, "req": clip(redact_text(data.decode("utf-8", "ignore") if data else ""), 200),
               "resp": clip(redact_text(text), 500)}
        with self._lock:
            if self._cur is not None:
                self._cur.append(row)
            key = (method, re.sub(r"\d+", "#", urlsplit(url).path), status >= 400)
            if key not in self._seen and len(self.appendix) < 40:
                self._seen.add(key)
                self.appendix.append(row)

    def add(self, name, status, detail="", raw=None):
        self.rows.append({"name": name, "status": status, "detail": str(detail), "raw": raw or []})
        self.say("%-7s %s%s" % (status, name, (" - " + str(detail)[:120]) if detail else ""))

    def step(self, name, fn):
        """Chạy fn() -> chuỗi chi tiết | (status, chi tiết) | None. Ngoại lệ -> LỖI kèm phản hồi thô của lần gọi cuối."""
        with self._lock:
            self._cur = []
        try:
            r = fn()
            status, detail = (r if isinstance(r, tuple) else (OK, r or ""))
            with self._lock:
                raw = list(self._cur) if status in (FAIL, WARN) else []
            self.add(name, status, detail, raw)
            return status != FAIL
        except Exception as e:                                          # noqa: BLE001 - báo cáo, không ném
            with self._lock:
                raw = list(self._cur)[-3:]
            self.add(name, FAIL, "%s: %s" % (type(e).__name__, clip(e, 300)), raw)
            return False
        finally:
            with self._lock:
                self._cur = None

    def poll(self, fn, pred, timeout=None):
        """Gọi fn() tới khi pred(kết quả) đúng. -> (đúng?, kết quả cuối). Sàn async (Exness) cần vài trăm ms."""
        end = time.monotonic() + (timeout or self.poll_s)
        r = None
        while True:
            r = fn()
            if pred(r):
                return True, r
            if time.monotonic() >= end:
                return False, r
            time.sleep(0.25)

    # ---- dựng ----
    def build(self):
        if self.ex == "simulated":
            self.add("Nguồn", WARN, "'simulated' không có sàn thật để kiểm tra - chọn --exchange khác")
        try:
            self.feed = self._given[0] or make_feed(self.ex, self.s)
            self.add("Dựng feed (%s)" % self.ex, OK, type(self.feed).__name__)
        except Exception as e:                                          # noqa: BLE001
            self.add("Dựng feed (%s)" % self.ex, FAIL, "%s: %s" % (type(e).__name__, e))
            return False
        if self.ex != "simulated":
            try:
                self.broker = self._given[1] or make_broker(self.s)
                self.add("Dựng broker", OK, type(self.broker).__name__)
            except Exception as e:                                      # noqa: BLE001
                self.add("Dựng broker", FAIL, "%s: %s" % (type(e).__name__, e))
        for what, obj, calls in (("feed", self.feed, contract.FEED_CALLS), ("broker", self.broker, contract.BROKER_CALLS)):
            if obj is not None:
                bad = contract.check_class(type(obj), calls)
                self.add("Hợp đồng chữ ký %s" % what, FAIL if bad else OK, "; ".join(bad) or "mọi lời gọi của vỏ đều nhận được")
        if self.broker is not None:
            bad = contract.check_broker_attrs(self.broker)
            self.add("Khai báo khả năng broker", FAIL if bad else OK, "; ".join(bad) or self.capabilities())
        return True

    def capabilities(self):
        b = self.broker
        caps = ["supports_short=%s" % getattr(b, "supports_short", "?"), "netting=%s" % getattr(b, "netting", False),
                "lệnh chờ native=%s" % (sorted(getattr(b, "native_pending", ()) or ()) or "không")]
        for n in ("hedged_positions", "account_flags", "account_state", "position_stats", "account_history", "sync_protection", "check_permissions", "close_market"):
            if hasattr(b, n):
                caps.append(n)
        return ", ".join(caps)

    # ---- feed ----
    def pick_symbol(self):
        from .settings import EXCHANGE_WATCH
        want = self.symbol_arg or EXCHANGE_WATCH.get(self.ex, "BTCUSD").split(",")[0]
        syms = None
        if hasattr(self.feed, "symbols"):
            def f():
                nonlocal syms
                syms = list(self.feed.symbols())
                return OK, "%d mã (vd %s)" % (len(syms), ", ".join(syms[:5]))
            self.step("Feed: danh sách mã", f)
        self.symbol = want
        if syms:
            if want not in syms:
                alt = next((x for x in syms if x.upper().startswith(want.upper().replace("_", "").replace("/", ""))), None) or \
                    next((x for x in syms if x.upper() == want.upper()), None)
                self.symbol = alt or syms[0]
                self.add("Chọn mã kiểm tra", WARN, "'%s' không có trong danh sách của sàn -> dùng '%s' (đổi bằng --symbol)" % (want, self.symbol))
        return self.symbol

    def feed_checks(self):
        sym = self.pick_symbol()
        holder = {}

        def tick():
            t = self.feed.tick(sym)
            holder["tick"] = t
            bad = contract.check_tick(t, sym)
            if bad:
                return FAIL, "; ".join(bad)
            age = time.time() - t.time
            self.market_open = bool(t.tradeable)
            note = "bid=%s ask=%s spread=%.3g%% tuổi giá=%.0fs tradeable=%s" % (t.bid, t.ask, (t.ask - t.bid) / t.bid * 100, age, t.tradeable)
            if not t.tradeable:
                return WARN, note + " -> thị trường đang ĐÓNG: các bước lệnh sẽ bị bỏ qua"
            if abs(age) > 120:
                return WARN, note + " -> giá cũ hoặc đồng hồ máy lệch (kiểm tra giờ tự động)"
            return OK, note
        self.step("Feed: tick %s" % sym, tick)
        last = {}
        for tf in self.tfs:
            def cand(tf=tf):
                n = 50
                cs = self.feed.history(sym, tf, n)
                bad = contract.check_candles(cs, tf_seconds(tf), n)
                if bad:
                    return FAIL, "; ".join(bad)
                last[tf] = cs
                older = self.feed.history(sym, tf, n, cs[0].time)
                bad = contract.check_candles(older, tf_seconds(tf), n, before=cs[0].time)
                if bad:
                    return FAIL, "phân trang (end=nến đầu): " + "; ".join(bad)
                return OK, "%d nến, mới nhất %s, trang trước %d nến" % (len(cs), time.strftime("%m-%d %H:%M", time.gmtime(cs[-1].time)), len(older))
            self.step("Feed: nến %s" % tf, cand)

        def deep():
            cs = fetch_history(self.feed, sym, self.tfs[0], 1200)
            bad = contract.check_candles(cs, tf_seconds(self.tfs[0]))
            if bad:
                return FAIL, "; ".join(bad)
            if len(cs) < 1000:
                return WARN, "chỉ lấy được %d/1200 nến %s (độ sâu lịch sử hạn chế hoặc phân trang chưa chạy hết)" % (len(cs), self.tfs[0])
            return OK, "%d nến qua nhiều trang, không trùng" % len(cs)
        if self.tfs and self.deep:
            self.step("Feed: tải sâu 1200 nến %s" % self.tfs[0], deep)

        def consistent():
            t, cs = holder.get("tick"), last.get(self.tfs[0]) if self.tfs else None
            if not t or not cs:
                return SKIP, "thiếu tick hoặc nến"
            ref = cs[-1].close
            off = abs(t.bid - ref) / ref * 100
            return (OK if off < 3 else WARN), "tick %.6g vs nến cuối %.6g (lệch %.2f%%)%s" % (t.bid, ref, off, "" if off < 3 else " - sai mã/đơn vị giá?")
        self.step("Feed: tick khớp nến", consistent)

    # ---- broker (chỉ đọc) ----
    def broker_read_checks(self):
        b, sym = self.broker, self.symbol
        if b is None:
            return
        bal = {}

        def prep():
            v = b.prepare(sym, 1.0)
            bal["v"] = v
            if not isinstance(v, (int, float)):
                return FAIL, "prepare() phải trả số dư (số), nhận %r" % (v,)
            return OK, "số dư %s" % v
        self.step("Broker: prepare + số dư", prep)

        def balance():
            v = b.balance()
            if not isinstance(v, (int, float)):
                return FAIL, "balance() phải trả số, nhận %r" % (v,)
            d = abs(v - bal.get("v", v))
            return (OK if d <= max(1.0, abs(v) * 0.01) else WARN), "số dư %s%s" % (v, "" if d <= max(1.0, abs(v) * 0.01) else " (khác prepare() %.2f)" % d)
        self.step("Broker: balance()", balance)

        def positions():
            if hasattr(b, "set_watch"):
                b.set_watch({sym})
            p = b.positions()
            bad = contract.check_positions(p)
            if bad:
                return FAIL, "; ".join(bad)
            return OK, "%d mã đang có vị thế%s" % (len(p), (": " + ", ".join("%s %+g" % (k, v["qty"]) for k, v in list(p.items())[:5])) if p else "")
        self.step("Broker: positions()", positions)

        def pend():
            p = b.pending_orders()
            bad = contract.check_pending(p)
            return (FAIL, "; ".join(bad)) if bad else (OK, "%d lệnh chờ đang sống" % len(p))
        self.step("Broker: pending_orders()", pend)

        if hasattr(b, "hedged_positions"):
            def hedged():
                rows = b.hedged_positions()
                if not isinstance(rows, list) or any(not isinstance(r, dict) or not {"id", "symbol", "side", "volume"} <= set(r) for r in rows):
                    return FAIL, "hedged_positions() phải là list dict có id/symbol/side/volume, nhận %s" % clip(rows, 200)
                return OK, "%d vị thế riêng lẻ" % len(rows)
            self.step("Broker: hedged_positions()", hedged)
        if hasattr(b, "account_flags"):
            def flags():
                fl = b.account_flags()
                bad = contract.check_flags(fl)
                if bad:
                    return FAIL, "; ".join(bad)
                if fl.get("can_trade") is False:
                    return WARN, "sàn báo KHÔNG được giao dịch: %s" % fl
                return OK, str(fl)
            self.step("Broker: account_flags()", flags)
        if hasattr(b, "check_permissions"):
            def perms():
                w = b.check_permissions()
                if not isinstance(w, list):
                    return FAIL, "check_permissions() phải trả list cảnh báo, nhận %r" % (w,)
                return (WARN, "; ".join(map(str, w))) if w else (OK, "không có cảnh báo quyền")
            self.step("Broker: check_permissions()", perms)

        def hist():
            rows = b.history(time.time() - 7 * 86400, [sym])
            bad = contract.check_history_rows(rows)
            return (FAIL, "; ".join(bad)) if bad else (OK, "%d lần khớp trong 7 ngày" % len(rows))
        self.step("Broker: history(since, symbols)", hist)
        self.numbers_checks()

    def numbers_checks(self):
        """Số liệu do SÀN báo để hiển thị như MT5 (tài khoản · lãi/lỗ vị thế · lịch sử). Tuỳ chọn: adapter không có thì SKIP kèm lý do. Phản hồi thô của các lần
        gọi này có trong PHỤ LỤC của báo cáo -> dán lên để chỉnh tên trường nếu sàn đặt tên khác."""
        b = self.broker

        def acct():
            bad, st = contract.check_account_state(b.account_state(), self.ex)
            if bad:
                return FAIL, "; ".join(bad)
            none = [k for k in ("equity", "margin", "free_margin", "margin_level", "profit") if st.get(k) is None]
            note = "Số dư %s · Tài sản %s · Ký quỹ %s · Còn dư %s · Mức KQ %s · Thả nổi %s · %s" % (
                st["balance"], st["equity"], st.get("margin"), st.get("free_margin"), st.get("margin_level"), st.get("profit"), st.get("currency") or "?")
            return (WARN, note + " -> sàn KHÔNG báo %s (giao diện hiện «-» cho các ô đó)" % ", ".join(none)) if none else (OK, note)
        if hasattr(b, "account_state"):
            self.step("Broker: account_state() (số của sàn)", acct)
        else:
            self.add("Broker: account_state() (số của sàn)", SKIP, "adapter chưa có - giao diện dùng sổ app và ghi «sổ app»")

        def pstats():
            st = b.position_stats()
            bad = contract.check_position_stats(st)
            if bad:
                return FAIL, "; ".join(bad)
            if not st:
                return SKIP, "không có vị thế đang mở (hoặc sàn không báo lãi/lỗ theo vị thế); bước giao dịch bên dưới sẽ kiểm lại với vị thế vừa mở"
            fields = sorted({f for v in st.values() for f in v})
            return OK, "%d vị thế có số của sàn (trường: %s)" % (len(st), ", ".join(fields))
        if hasattr(b, "position_stats"):
            self.step("Broker: position_stats() (lãi/lỗ vị thế)", pstats)
        else:
            self.add("Broker: position_stats() (lãi/lỗ vị thế)", SKIP, "adapter chưa có - lãi/lỗ vị thế là số tự tính của app")

        def ahist():
            rows = b.account_history(time.time() - 30 * 86400, time.time() + 3600)
            bad = contract.check_history_deals(rows)
            if bad:
                return FAIL, "; ".join(bad)
            from . import brokerhist
            sm = brokerhist.summarize(rows)
            return OK, "%d deal/30 ngày: Lợi nhuận %s · Tiền nạp %s · Phí qua đêm %s · Phí trung gian %s · Số dư %s · %d vị thế đã đóng" % (
                len(rows), brokerhist.money(sm["profit"]), brokerhist.money(sm["deposit"]), brokerhist.money(sm["swap"]),
                brokerhist.money(sm["commission"]), brokerhist.money(sm["balance"]), sm["positions"])
        if hasattr(b, "account_history"):
            self.step("Broker: account_history() (lịch sử sàn)", ahist)
        else:
            self.add("Broker: account_history() (lịch sử sàn)", SKIP, "adapter chưa có - mục «Lịch sử từ sàn» báo chưa hỗ trợ")
        self.mapping_check()

    def mapping_check(self):
        """«Ánh xạ trường»: trường ngữ nghĩa nào đã khớp khoá nào của sàn, trường nào thiếu + các khoá số chưa dùng (ứng viên). Chữa bằng ghi đè trong Cài đặt
        («Ánh xạ trường tuỳ chỉnh») - không sửa mã. Chạy lại sau chu trình lệnh thật để có cả bản ghi vị thế/deal."""
        from . import fieldmap, redact
        rep = fieldmap.report(self.ex)
        if not rep:
            self.add("Ánh xạ trường", SKIP, "chưa có bản ghi thô nào từ sàn để đối chiếu (adapter báo số đã chuẩn hoá sẵn hoặc chưa có dữ liệu)")
            return
        miss = {k: d["core_missing"] for k, d in rep.items() if d["core_missing"]}
        text = redact.redact(fieldmap.format_report(rep))
        if miss:
            hint = " -> chỉnh «Ánh xạ trường tuỳ chỉnh» (Cài đặt) hoặc nhờ Trợ lý đề xuất; ví dụ: %s" % json_example(self.ex, miss, rep)
            self.add("Ánh xạ trường", WARN, text + hint)
        else:
            self.add("Ánh xạ trường", OK, text)

    # ---- broker (lệnh thật, khối lượng nhỏ nhất) ----
    def _net(self):
        if hasattr(self.broker, "set_watch"):                           # như vỏ (reconcile.py/sync.py): Spot chỉ hỏi số dư các mã được quan tâm
            self.broker.set_watch({self.symbol})
        return float((self.broker.positions().get(self.symbol) or {}).get("qty", 0.0))

    def _spot(self):
        return bool(getattr(self.broker, "spot_like", False))

    def _tol(self, ref=0.0):
        """Sai số chấp nhận khi so vị thế: spot có 'bụi' (phí trả bằng coin + bước khối lượng) tới 1 lô nhỏ nhất."""
        return self.qty if self._spot() else max(1e-9, abs(ref) * 0.02)

    def trade_checks(self):
        b, sym, q = self.broker, self.symbol, self.qty
        if b is None or not self.market_open or sym is None:
            self.add("Giao dịch thật", SKIP, "không có broker / thị trường đóng / chưa chọn được mã")
            return
        fl = b.account_flags() if hasattr(b, "account_flags") else {}
        if fl.get("can_trade") is False:
            self.add("Giao dịch thật", SKIP, "sàn báo tài khoản không được giao dịch: %s" % fl)
            return
        base = self._net()
        self.add("Vị thế ban đầu %s" % sym, WARN if abs(base) > 1e-12 else OK,
                 "%+g%s" % (base, " - đã có vị thế: bước kiểm tra chỉ đo chênh lệch và chỉ đóng phần của chính nó" if abs(base) > 1e-12 else ""))
        made_orders, state = [], {"opened": 0.0}
        t0 = time.time()
        try:
            self._t_open(base, state, q)
            if state["opened"] > 0:
                self._t_stats(state)
                self._t_pending(made_orders, q)
                self._t_partial(base, state, q)
                self._t_protect(base, state)
                self._t_close(base, state)
        finally:
            self._cleanup(base, made_orders)
        self.step("Broker: history() thấy lệnh vừa chạy", lambda: self._t_history(t0))
        if hasattr(b, "account_history"):
            self.step("Broker: account_history() thấy lệnh vừa chạy", lambda: self._t_acct_history(t0))
        self.mapping_check()

    def _mult(self):
        return 3 if self._spot() else 2                                  # spot: phí bằng coin làm vị thế hao nhẹ -> mua dư để còn đóng được từng phần

    def _t_open(self, base, state, q):
        b, sym = self.broker, self.symbol

        def go():
            t = self.feed.tick(sym)
            fill = b.market_order(sym, "buy", q * self._mult())
            bad = contract.check_fill(fill)
            if bad:
                return FAIL, "; ".join(bad)
            state["opened"] = float(fill.qty)
            state["ref"] = str(getattr(fill, "ref", "") or "")           # ticket vị thế trên sàn (MT...) nếu có - cần cho SL/TP native kiểu «gắn lên vị thế»
            ok, net = self.poll(self._net, lambda v: abs(v - base - fill.qty) <= max(1e-9, fill.qty * 0.02))
            slip = abs(fill.price - t.ask) / t.ask * 100
            note = "khớp %.8g @ %.8g (ask lúc gửi %.8g, trượt %.3f%%)" % (fill.qty, fill.price, t.ask, slip)
            if not ok:
                state["opened"] = max(0.0, net - base)
                return FAIL, note + "; positions() báo %+g (kỳ vọng %+g) - vị thế trên sàn không khớp lệnh vừa gửi" % (net, base + fill.qty)
            return (WARN if slip > 0.5 else OK), note
        self.step("Lệnh: mua thị trường %g (%d lô nhỏ nhất)" % (q * self._mult(), self._mult()), go)

    def _t_stats(self, state):
        """Vị thế VỪA MỞ phải có số lãi/lỗ do sàn báo, tra theo đúng ticket (Fill.ref): nếu không, giao diện rơi về số tự tính của app."""
        b = self.broker
        if not hasattr(b, "position_stats"):
            return
        ref = state.get("ref")
        if not ref:
            self.add("Broker: position_stats() thấy vị thế vừa mở", SKIP, "market_order không trả Fill.ref (ticket) nên không đối chiếu được theo vị thế")
            return

        def go():
            ok, st = self.poll(b.position_stats, lambda d: isinstance(d, dict) and ref in d)
            bad = contract.check_position_stats(st)
            if bad:
                return FAIL, "; ".join(bad)
            if not ok:
                return WARN, "không thấy ticket %s trong position_stats() (có %d vị thế khác) -> lãi/lỗ vị thế hiển thị là số tự tính của app" % (ref, len(st or {}))
            v = st[ref]
            return OK, "ticket %s: %s" % (ref, ", ".join("%s=%s" % (k, v[k]) for k in sorted(v)))
        self.step("Broker: position_stats() thấy vị thế vừa mở", go)

    def _t_acct_history(self, t0):
        b, sym = self.broker, self.symbol

        def get():
            return b.account_history(t0 - 5.0, time.time() + 3600)
        ok, rows = self.poll(get, lambda r: isinstance(r, list) and sum(1 for d in r if isinstance(d, dict) and d.get("kind") == "trade" and d.get("symbol") == sym) >= 2)
        bad = contract.check_history_deals(rows)
        if bad:
            return FAIL, "; ".join(bad)
        mine = [d for d in rows if d.get("kind") == "trade" and d.get("symbol") == sym]
        if not ok:
            return WARN, "chỉ thấy %d deal giao dịch %s kể từ lúc bắt đầu (kỳ vọng ≥2: mở + đóng) - lịch sử của sàn có thể trễ hoặc tên trường deal khác" % (len(mine), sym)
        entries = sorted({d["entry"] for d in mine if d["entry"]})
        return OK, "%d deal %s mới (entry: %s)" % (len(mine), sym, ", ".join(entries) or "sàn không báo vào/ra")

    def _t_pending(self, made, q):
        b, sym = self.broker, self.symbol
        kinds = [k for k in ("limit", "stop") if k in (getattr(b, "native_pending", None) or ())]
        if not kinds:
            self.add("Lệnh chờ native", SKIP, "adapter không khai báo native_pending (vỏ sẽ giữ lệnh chờ trong app)")
            return
        for kind in kinds:
            ref = self.feed.tick(sym)
            far = ref.bid * 0.97 if kind == "limit" else ref.ask * 1.03                 # mua limit dưới giá / mua stop trên giá: xa, không thể khớp
            holder = {}

            def place(kind=kind, far=far):
                nid = str(b.place_pending(sym, "buy", kind, q, far, None, None, None, None, "pyea-selfcheck"))
                if not nid:
                    return FAIL, "place_pending() không trả mã lệnh"
                made.append(nid)
                holder["id"] = nid
                ok, rows = self.poll(b.pending_orders, lambda r: nid in r)
                bad = contract.check_pending(rows)
                if not ok:
                    return FAIL, "mã %s không xuất hiện trong pending_orders() sau %.0fs: %s" % (nid, self.poll_s, sorted(rows)[:5])
                return (FAIL, "; ".join(bad)) if bad else (OK, "mã %s @ %.8g" % (nid, rows[nid].get("price", 0)))
            self.step("Lệnh chờ %s: đặt xa giá + thấy trong danh sách" % kind, place)
            if "id" not in holder:
                continue

            def result():
                bad = contract.check_order_result(b.order_result(holder["id"], sym))
                return (FAIL, "; ".join(bad)) if bad else (OK, str(b.order_result(holder["id"], sym)))
            self.step("Lệnh chờ %s: order_result()" % kind, result)

            def modify():
                newp = far * 1.002
                new_id = b.modify_pending(holder["id"], sym, price=newp, sl=None, tp=None)
                if isinstance(new_id, str) and new_id and new_id != holder["id"]:
                    made[:] = [x for x in made if x != holder["id"]] + [new_id]                 # sửa = huỷ + đặt lại: mã cũ không còn
                    holder["id"] = new_id
                ok, rows = self.poll(b.pending_orders, lambda r: holder["id"] in r and abs(float(r[holder["id"]].get("price") or 0) - newp) <= newp * 0.001)
                if not ok:
                    return FAIL, "sau sửa giá -> %.8g, pending_orders() báo %s" % (newp, rows.get(holder["id"]))
                return OK, "giá đổi sang %.8g%s" % (newp, " (mã đổi: sửa = huỷ + đặt lại)" if new_id and new_id != holder["id"] else "")
            self.step("Lệnh chờ %s: sửa giá" % kind, modify)

            def cancel():
                b.cancel_pending(holder["id"], sym)
                ok, rows = self.poll(b.pending_orders, lambda r: holder["id"] not in r)
                if not ok:
                    return FAIL, "đã huỷ nhưng %s vẫn còn trong pending_orders()" % holder["id"]
                made[:] = [x for x in made if x != holder["id"]]
                bad = contract.check_order_result(b.order_result(holder["id"], sym))
                return (FAIL, "; ".join(bad)) if bad else (OK, "đã huỷ, order_result=%s" % (b.order_result(holder["id"], sym),))
            self.step("Lệnh chờ %s: huỷ" % kind, cancel)

    def _t_partial(self, base, state, q):
        b, sym = self.broker, self.symbol

        def go():
            take = min(q, state["opened"])
            fill = b.market_order(sym, "sell", take, reduce_only=True)
            bad = contract.check_fill(fill)
            if bad:
                return FAIL, "; ".join(bad)
            want = base + state["opened"] - fill.qty
            ok, net = self.poll(self._net, lambda v: abs(v - want) <= max(1e-9, state["opened"] * 0.02))
            state["opened"] = max(0.0, net - base)
            if not ok:
                return FAIL, "đóng một phần %.8g nhưng positions() báo %+g (kỳ vọng %+g) - sàn có thể đã đóng SAI khối lượng" % (fill.qty, net, want)
            return OK, "đóng %.8g @ %.8g, còn lại %.8g" % (fill.qty, fill.price, state["opened"])
        self.step("Lệnh: đóng MỘT PHẦN (reduce_only)", go)

    def _t_protect(self, base, state):
        b, sym = self.broker, self.symbol
        if not self.protect or not hasattr(b, "sync_protection") or state["opened"] <= 0:
            self.add("SL/TP native (bảo vệ trên sàn)", SKIP, "adapter không có sync_protection" if not hasattr(b, "sync_protection") else "tắt")
            return
        sup = getattr(b, "prot_supported", None)
        if callable(sup) and not sup():
            self.add("SL/TP native (bảo vệ trên sàn)", SKIP, "adapter báo chưa hỗ trợ cấu hình này (vd tài khoản MT netting)")
            return
        qty = state["opened"]
        px = self.feed.tick(sym).bid
        intents = [{"pid": 1, "ref": state.get("ref", ""), "side": "sell", "qty": qty, "sl": px * 0.9, "tp": px * 1.1}]    # giao diện CHUNG: một vị thế muốn SL+TP
        style = getattr(b, "PROT_STYLE", "ladder")
        steps = plan_steps(intents, style)                           # số lệnh kỳ vọng suy từ bộ lập kế hoạch dùng chung, không phân biệt sàn
        n = len(steps)
        if n == 0:
            self.add("SL/TP native (bảo vệ trên sàn)", SKIP, "phong cách %r cần Fill.ref (ticket vị thế) nhưng market_order không trả - không đặt được bảo vệ theo vị thế" % style)
            return
        what = "%d lệnh/mức theo phong cách %s" % (n, style)

        def place():
            r = b.sync_protection(sym, intents)
            ok, orders = self.poll(lambda: b.protection_orders(sym), lambda o: len(o) == n)
            bad = contract.check_protection_result(r, intents) + contract.check_protection_orders(orders)
            if not ok:
                return FAIL, "đặt %s nhưng protection_orders() báo %d (kỳ vọng %d): %s; kết quả %s" % (what, len(orders), n, orders, r)
            if bad:
                return FAIL, "; ".join(bad)
            if r.get("covered") != {1: ["sl", "tp"]}:
                return FAIL, "sàn không nhận đủ SL+TP: covered=%s errors=%s" % (r.get("covered"), r.get("errors"))
            return OK, "%d lệnh bảo vệ, covered=%s" % (len(orders), r.get("covered"))
        self.step("SL/TP native: đặt %s" % what, place)

        def clear():
            b.sync_protection(sym, [])
            ok, orders = self.poll(lambda: b.protection_orders(sym), lambda o: len(o) == 0)
            return (OK, "đã gỡ hết") if ok else (FAIL, "gỡ rồi nhưng còn %d lệnh bảo vệ: %s" % (len(orders), orders))
        self.step("SL/TP native: gỡ", clear)

    def _t_close(self, base, state):
        b, sym = self.broker, self.symbol

        def go():
            net = self._net()
            left = net - base
            if abs(left) <= 1e-12:
                return SKIP, "không còn gì để đóng"
            fill = b.market_order(sym, "sell" if left > 0 else "buy", abs(left), reduce_only=True)
            ok, net2 = self.poll(self._net, lambda v: abs(v - base) <= self._tol(left))
            state["opened"] = 0.0 if ok else max(0.0, net2 - base)
            if not ok:
                return FAIL, "đóng %.8g @ %.8g nhưng vị thế còn %+g (ban đầu %+g)" % (fill.qty, fill.price, net2, base)
            return OK, "đóng %.8g @ %.8g, vị thế về %+g%s" % (fill.qty, fill.price, net2, (" (còn bụi %.3g do phí bằng coin/bước khối lượng)" % (net2 - base)) if abs(net2 - base) > 1e-9 else "")
        self.step("Lệnh: đóng nốt (reduce_only) về vị thế ban đầu", go)

    def _cleanup(self, base, made):
        b, sym = self.broker, self.symbol
        notes, stuck = [], []
        try:
            alive = set(b.pending_orders())
        except Exception:                                               # noqa: BLE001
            alive = set(made)
        for nid in list(made):
            if nid not in alive:
                continue
            try:
                b.cancel_pending(nid, sym)
                notes.append("huỷ lệnh chờ sót %s" % nid)
            except Exception as e:                                      # noqa: BLE001
                stuck.append(nid)
                notes.append("KHÔNG huỷ được lệnh chờ %s (%s)" % (nid, clip(e, 80)))
        if hasattr(b, "sync_protection"):
            try:
                b.sync_protection(sym, [])
            except Exception:                                           # noqa: BLE001
                pass
        try:
            left = self._net() - base
            if abs(left) > self._tol(left):
                tol = self._tol(left)
                try:
                    b.market_order(sym, "sell" if left > 0 else "buy", abs(left), reduce_only=True)
                    ok2, net2 = self.poll(self._net, lambda v: abs(v - base) <= tol)
                    notes.append("đóng nốt phần dư %+g -> %+g" % (left, net2 - base))
                    left = net2 - base
                except Exception as e:                                  # noqa: BLE001
                    notes.append("KHÔNG đóng được phần dư %+g (%s)" % (left, clip(e, 80)))
            bad = abs(left) > self._tol(left)
            self.add("Dọn dẹp", FAIL if (bad or stuck) else OK,
                     ("CÒN VỊ THẾ DƯ %+g %s trên sàn - HÃY ĐÓNG TAY! " % (left, sym) if bad else "vị thế về mức ban đầu%s" % ("; " if notes else "")) + "; ".join(notes)
                     + (" - HÃY HUỶ TAY lệnh chờ %s trên sàn" % stuck if stuck else ""))
        except Exception as e:                                          # noqa: BLE001
            self.add("Dọn dẹp", FAIL, "không đọc được vị thế để dọn: %s - KIỂM TRA TÀI KHOẢN BẰNG TAY" % clip(e, 120))

    def _t_history(self, t0):
        rows = None

        def get():
            return self.broker.history(t0 - 60, [self.symbol])
        ok, rows = self.poll(get, lambda r: len([x for x in r if x.get("symbol") == self.symbol]) >= 1, self.poll_s * 1.5)
        bad = contract.check_history_rows(rows)
        if bad:
            return FAIL, "; ".join(bad)
        mine = [x for x in rows if x.get("symbol") == self.symbol]
        if not ok:
            return WARN, "chưa thấy lần khớp nào sau %.0fs (sàn có thể trễ lịch sử) - đồng bộ lịch sử của vỏ sẽ bắt kịp sau" % (self.poll_s * 1.5)
        return OK, "%d lần khớp mới của %s" % (len(mine), self.symbol)


# ------------------------------------------------------------------------------------------------ API
def run(settings, trade=False, qty=None, symbol=None, tfs=("1m", "5m", "15m", "1h", "4h"), protect=True, say=None, poll=10.0, feed=None, broker=None, deep=True):
    """Chạy toàn bộ kiểm tra. -> (rows, appendix, check). `trade=False` = CHỈ ĐỌC."""
    c = Check(settings, trade, qty, symbol, tfs, protect, say, poll, feed, broker, deep)
    feeds.HTTP_TAP = c._tap
    try:
        if c.build() and c.feed is not None:
            c.feed_checks()
            c.broker_read_checks()
            if trade:
                c.trade_checks()
    finally:
        feeds.HTTP_TAP = None
        try:
            if c.feed is not None:
                c.feed.close()
        except Exception:                                               # noqa: BLE001
            pass
    return c.rows, c.appendix, c


def summarize(rows):
    n = {OK: 0, WARN: 0, FAIL: 0, SKIP: 0}
    for r in rows:
        n[r["status"]] = n.get(r["status"], 0) + 1
    return n


def format_report(rows, appendix=(), header=""):
    mark = {OK: "[OK]    ", WARN: "[CHÚ Ý] ", FAIL: "[LỖI]   ", SKIP: "[BỎ QUA]"}
    out = [header or "PyEA selfcheck %s" % time.strftime("%Y-%m-%d %H:%M:%S")]
    for r in rows:
        out.append("%s %s%s" % (mark.get(r["status"], r["status"]), r["name"], (": " + r["detail"]) if r["detail"] else ""))
        if r["status"] in (FAIL, WARN):
            for x in r["raw"][-3:]:
                out.append("           ↳ %s %s -> %s %s%s" % (x["method"], x["url"], x["status"], x["resp"], ("  [gửi: %s]" % x["req"]) if x["req"] else ""))
    n = summarize(rows)
    out.append("")
    out.append("KẾT LUẬN: %d OK · %d chú ý · %d LỖI · %d bỏ qua" % (n[OK], n[WARN], n[FAIL], n[SKIP]))
    if appendix:
        out.append("")
        out.append("--- Phụ lục: mỗi loại yêu cầu một mẫu phản hồi THÔ của sàn (đã che khoá/chữ ký; xem lại trước khi dán) ---")
        for x in appendix:
            out.append("%s %s -> %s\\n    %s" % (x["method"], x["url"], x["status"], x["resp"]))
    return "\n".join(out)


def template(exchange):
    from .settings import default_settings
    d = default_settings()
    keep = KEY_PREFIXES.get(exchange, ())
    out = {"exchange": exchange}
    for k, v in d.items():
        if any(k == p or (p.endswith("_") and k.startswith(p)) for p in keep):
            out[k] = v
    return out


def load_settings(path=None, sets=(), exchange=None):
    from .settings import clean_settings
    raw = {}
    if path:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
    for kv in sets:
        k, _, v = kv.partition("=")
        raw[k.strip()] = v
    if exchange:
        raw["exchange"] = exchange
    for k, v in list(raw.items()):                                       # "@/đường/dẫn" = đọc nội dung file (khoá riêng PEM...)
        if isinstance(v, str) and v.startswith("@") and os.path.exists(os.path.expanduser(v[1:])):
            with open(os.path.expanduser(v[1:]), encoding="utf-8") as f:
                raw[k] = f.read()
    return clean_settings(raw)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m pyea.selfcheck", description=__doc__.split("Dùng:")[0].strip().splitlines()[0])
    ap.add_argument("--exchange", help="exness | oanda | binance_spot | binance_futures | metaapi | mt5gw | bridge | ccxt")
    ap.add_argument("--settings", help="file JSON cài đặt (cùng khoá với tab Cài đặt của app)")
    ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="ghi đè một cài đặt")
    ap.add_argument("--symbol", help="mã kiểm tra (mặc định: mã đầu của danh sách mẫu của sàn)")
    ap.add_argument("--tf", default="1m,5m,15m,1h,4h", help="các khung nến kiểm tra")
    ap.add_argument("--trade", action="store_true", help="GỬI LỆNH THẬT khối lượng nhỏ nhất (dùng tài khoản DEMO)")
    ap.add_argument("--yes", action="store_true", help="xác nhận --trade không hỏi lại")
    ap.add_argument("--qty", type=float, help="khối lượng đơn vị nhỏ nhất (mặc định theo sàn: exness 0.01 lô, oanda 1 đơn vị, binance 0.001/0.002)")
    ap.add_argument("--no-protect", action="store_true", help="bỏ qua bước SL/TP native")
    ap.add_argument("--template", metavar="EXCHANGE", help="in mẫu JSON cài đặt cho sàn rồi thoát")
    ap.add_argument("--out", help="ghi báo cáo ra file (ngoài màn hình)")
    a = ap.parse_args(argv)
    if a.template:
        print(json.dumps(template(a.template), ensure_ascii=False, indent=2))
        return 0
    if not (a.exchange or a.settings):
        ap.error("cần --exchange hoặc --settings (hoặc --template EXCHANGE để lấy mẫu)")
    s = load_settings(a.settings, a.set, a.exchange)
    if a.trade and not a.yes:
        print("Sẽ GỬI LỆNH THẬT lên %s (khối lượng nhỏ nhất, mua 2 lô -> đóng). Nên dùng tài khoản DEMO." % s.get("exchange"))
        if not sys.stdin.isatty() or input("Gõ YES để tiếp tục: ").strip() != "YES":
            print("Đã huỷ (thêm --yes để xác nhận không tương tác).")
            return 2
    rows, appendix, chk = run(s, trade=a.trade, qty=a.qty, symbol=a.symbol, tfs=tuple(x for x in a.tf.split(",") if x), protect=not a.no_protect,
                              say=lambda m: print(m, flush=True))
    rep = format_report(rows, appendix, "PyEA selfcheck %s · sàn=%s · mã=%s · %s" % (
        time.strftime("%Y-%m-%d %H:%M:%S"), s.get("exchange"), chk.symbol, ("GIAO DỊCH khối lượng %g" % chk.qty) if a.trade else "CHỈ ĐỌC"))
    print("\n" + rep)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(rep + "\n")
        print("\nĐã ghi %s" % a.out)
    return 1 if summarize(rows)[FAIL] else 0


if __name__ == "__main__":
    sys.exit(main())
