"""Lịch kinh tế: nạp tin (JSON/CSV từ URL hoặc file), tìm tin sắp tới, và hỏi «lúc này có tin quan trọng quanh mã X không».
Giống Economic Calendar của MT5 (https://www.mql5.com/en/docs/calendar: sự kiện có quốc gia/tiền tệ, mức quan trọng, giờ, dự báo/trước đó) nhưng nguồn dữ liệu do NGƯỜI DÙNG chọn
(`calendar_source`), không gắn cứng một nhà cung cấp: URL http(s) hoặc đường dẫn file; định dạng tự nhận JSON (list hoặc {"events": [...]}) / CSV có dòng tiêu đề.
Mẫu JSON đã đối chiếu: {"title","country" (mã tiền tệ),"date" (ISO có múi giờ),"impact" (Holiday|Low|Medium|High),"forecast","previous"}.

Không import Kivy. Mọi lỗi mạng/định dạng chỉ làm lịch KHÔNG cập nhật (giữ bản cũ) - tuyệt đối không làm chặn lệnh vì lịch hỏng (không có lịch = không chặn)."""
import csv
import io
import json
import os
import re
import threading
import time
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone

IMPACT = {"holiday": 0, "none": 0, "non-economic": 0, "low": 1, "l": 1, "1": 1, "medium": 2, "med": 2, "moderate": 2, "m": 2, "2": 2, "high": 3, "h": 3, "3": 3}
IMPACT_NAME = {0: "nghỉ lễ", 1: "thấp", 2: "vừa", 3: "CAO"}
MIN_IMPACT = {"low": 1, "medium": 2, "high": 3}
MAX_BYTES = 4 * 1024 * 1024


@dataclass
class EconEvent:
    ts: float                 # epoch giây UTC
    currency: str             # mã tiền tệ (USD, EUR...) - "ALL" nếu tin toàn cầu
    title: str
    impact: int               # 0 nghỉ lễ · 1 thấp · 2 vừa · 3 cao
    forecast: str = ""
    previous: str = ""
    actual: str = ""

    def key(self):
        return "%d|%s|%s" % (int(self.ts), self.currency, self.title)

    def as_dict(self):
        return {"ts": self.ts, "currency": self.currency, "title": self.title, "impact": self.impact, "forecast": self.forecast,
                "previous": self.previous, "actual": self.actual}


# ----------------------------------------------------------------------------------------------- phân tích
def _parse_time(v):
    """ISO (có/không múi giờ; không múi giờ = UTC), epoch giây hoặc mili giây -> epoch giây. Không hiểu -> None."""
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)) or re.fullmatch(r"\d{9,13}(\.\d+)?", str(v).strip()):
        x = float(v)
        return x / 1000.0 if x > 1e11 else x
    s = str(v).strip().replace("Z", "+00:00").replace("z", "+00:00")
    if " " in s and "T" not in s:
        s = s.replace(" ", "T", 1)
    try:
        d = datetime.fromisoformat(s)
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.timestamp()


def _impact(v):
    if isinstance(v, (int, float)):
        return max(0, min(3, int(v)))
    s = str(v or "").strip().lower()
    if s in IMPACT:
        return IMPACT[s]
    stars = s.count("★") or s.count("*")
    return min(3, stars) if stars else 1


def _pick(row, names):
    low = {str(k).strip().lower(): v for k, v in row.items()}
    for n in names:
        if n in low and low[n] not in (None, ""):
            return low[n]
    return None


def _event_from(row):
    ts = _parse_time(_pick(row, ("date", "time", "datetime", "timestamp", "ts", "start")))
    title = _pick(row, ("title", "event", "name", "headline"))
    if ts is None or not title:
        return None
    cur = str(_pick(row, ("country", "currency", "ccy", "cur")) or "ALL").strip().upper()
    return EconEvent(ts=ts, currency=cur[:8], title=str(title).strip()[:160], impact=_impact(_pick(row, ("impact", "importance", "volatility", "priority", "level"))),
                     forecast=str(_pick(row, ("forecast", "consensus")) or ""), previous=str(_pick(row, ("previous", "prev")) or ""),
                     actual=str(_pick(row, ("actual",)) or ""))


def parse(text):
    """Văn bản JSON hoặc CSV -> list EconEvent đã sắp xếp theo giờ. Dòng không hiểu bị bỏ qua. Không có dòng nào hiểu được -> ValueError."""
    txt = (text or "").lstrip("﻿").strip()
    if not txt:
        raise ValueError("lịch rỗng")
    rows = None
    if txt[0] in "[{":
        data = json.loads(txt)
        if isinstance(data, dict):
            for k in ("events", "data", "calendar", "result", "items"):
                if isinstance(data.get(k), list):
                    data = data[k]
                    break
        if not isinstance(data, list):
            raise ValueError("JSON lịch phải là danh sách sự kiện")
        rows = [r for r in data if isinstance(r, dict)]
    else:
        rows = list(csv.DictReader(io.StringIO(txt)))
    out = [e for e in (_event_from(r) for r in rows) if e is not None]
    if not out:
        raise ValueError("không hiểu được sự kiện nào (cần cột/khoá: giờ [date|time], tiêu đề [title|event], tiền tệ [country|currency], mức [impact])")
    out.sort(key=lambda e: (e.ts, e.currency, e.title))
    return out


# ----------------------------------------------------------------------------------------------- mã -> tiền tệ
FX = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "CNY", "CNH", "SEK", "NOK", "SGD", "HKD", "MXN", "ZAR", "TRY", "PLN"}
STABLE = ("USDT", "USDC", "BUSD", "FDUSD", "TUSD")
INDEX = {"US500": "USD", "US30": "USD", "USTEC": "USD", "NAS100": "USD", "SPX500": "USD", "SPX": "USD", "DJ30": "USD", "US100": "USD", "USOIL": "USD", "UKOIL": "USD",
         "GER40": "EUR", "DE40": "EUR", "DAX": "EUR", "FRA40": "EUR", "EU50": "EUR", "UK100": "GBP", "JP225": "JPY", "NIKKEI": "JPY", "AUS200": "AUD"}


def symbol_currencies(symbol, override=""):
    """Tiền tệ có thể làm giá `symbol` biến động theo tin. override (vd "USD,EUR") thay thế mọi suy luận. Mã lạ -> tập rỗng (không chặn)."""
    ov = {c.strip().upper() for c in re.split(r"[,\s;]+", str(override or "")) if c.strip()}
    if ov:
        return ov
    s = re.sub(r"[^A-Z0-9]", "", str(symbol or "").upper())
    if s in INDEX:
        return {INDEX[s]}
    for q in STABLE:                                              # BTCUSDT: tin USD ảnh hưởng crypto
        if s.endswith(q) and len(s) > len(q):
            return {"USD"}
    for sfx in ("USD",):
        if s.endswith(sfx) and len(s) > 3 and s[:-3] not in FX and s[:3] not in FX:
            return {"USD"}                                        # BTCUSD, ETHUSD, XAUUSD, XAGUSD...
    if len(s) == 6 and s[:3] in FX and s[3:] in FX:
        return {s[:3], s[3:]}
    if len(s) == 6 and s[3:] in FX:                               # XAUUSD, XAUEUR...
        return {s[3:]}
    return set()


# ----------------------------------------------------------------------------------------------- nạp nguồn
# Nguồn mẫu MIỄN PHÍ khi người dùng để trống ô «Nguồn lịch» hoặc gõ `auto`: lịch TUẦN NÀY dạng JSON (không chính thức, có thể bị đổi/giới hạn tần suất;
# vì vậy app chỉ nạp tối đa 1 lần/giờ cho nguồn này). Muốn nguồn khác: dán URL/đường dẫn file vào ô «Nguồn lịch».
PRESET_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"


def resolve_source(value):
    v = str(value or "").strip()
    return PRESET_URL if v.lower() in ("", "auto") else v


def fetch_text(source, timeout=10):
    """URL http(s) hoặc đường dẫn file (file:// cũng được) -> văn bản. Giới hạn kích thước. Lỗi -> ném Exception."""
    src = str(source or "").strip()
    if not src:
        raise ValueError("chưa cấu hình nguồn lịch")
    if re.match(r"^https?://", src, re.I):
        from .feeds import ssl_context
        req = urllib.request.Request(src, headers={"User-Agent": "PyEA-Runner/calendar", "Accept": "application/json,text/csv,*/*"})
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            raw = r.read(MAX_BYTES + 1)
    else:
        path = src[7:] if src.lower().startswith("file://") else src
        with open(path, "rb") as f:
            raw = f.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("lịch quá lớn (> %d MB)" % (MAX_BYTES // 1048576))
    return raw.decode("utf-8", "replace")


class EconCalendar:
    def __init__(self, source, cache_path=None, ttl=6 * 3600.0, fetch=None, clock=time.time):
        self.source = str(source or "").strip()
        self.cache_path = cache_path
        self.ttl = float(ttl)
        self._fetch = fetch or fetch_text
        self._clock = clock
        self.lock = threading.RLock()
        self.events = []
        self.loaded_at = 0.0          # lần nạp thành công gần nhất
        self.tried_at = 0.0
        self.error = ""
        self._busy = False
        self._load_cache()

    # ---- bộ đệm: lần mở sau vẫn có lịch dù chưa có mạng ----
    def _load_cache(self):
        if not self.cache_path or not os.path.exists(self.cache_path):
            return
        try:
            with open(self.cache_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("source") == self.source:
                self.events = [EconEvent(**e) for e in d.get("events", [])]
                self.loaded_at = float(d.get("loaded_at", 0.0))
        except Exception:                                          # noqa: BLE001
            self.events, self.loaded_at = [], 0.0

    def _save_cache(self):
        if not self.cache_path:
            return
        try:
            tmp = self.cache_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"source": self.source, "loaded_at": self.loaded_at, "events": [e.as_dict() for e in self.events]}, f, ensure_ascii=False)
            os.replace(tmp, self.cache_path)
        except OSError:
            pass

    def stale(self):
        now = self._clock()
        return now - self.loaded_at > self.ttl and now - self.tried_at > min(300.0, self.ttl)      # lỗi thì thử lại sau tối đa 5 phút

    def refresh(self, force=False):
        """Nạp lại nguồn nếu đã cũ. Trả (đã nạp mới?, thông báo). Lỗi: giữ bản cũ, ghi `error`."""
        with self.lock:
            if self._busy or not (force or self.stale()):
                return False, self.error
            self._busy = True
            self.tried_at = self._clock()
        try:
            evs = parse(self._fetch(self.source))
            with self.lock:
                self.events, self.loaded_at, self.error = evs, self._clock(), ""
            self._save_cache()
            return True, ""
        except Exception as e:                                     # noqa: BLE001 - mạng/định dạng hỏng: giữ lịch cũ
            with self.lock:
                self.error = str(e)[:200]
            return False, self.error
        finally:
            with self.lock:
                self._busy = False

    # ---- truy vấn ----
    def upcoming(self, now=None, horizon_s=86400.0, min_impact=2, currencies=None, past_s=0.0):
        now = self._clock() if now is None else now
        cur = {c.upper() for c in currencies} if currencies is not None else None
        with self.lock:
            return [e for e in self.events if now - past_s <= e.ts <= now + horizon_s and e.impact >= min_impact
                    and (cur is None or e.currency in cur or e.currency == "ALL")]

    def blocking(self, symbol, before_s, after_s, min_impact=3, override="", now=None):
        """Tin ĐANG chặn lệnh mới của `symbol` (trong [ts - before, ts + after], đủ mức quan trọng, đúng tiền tệ) hoặc None."""
        cur = symbol_currencies(symbol, override)
        if not cur:
            return None
        now = self._clock() if now is None else now
        with self.lock:
            for e in self.events:
                if e.impact >= min_impact and (e.currency in cur or e.currency == "ALL") and e.ts - before_s <= now <= e.ts + after_s:
                    return e
        return None
