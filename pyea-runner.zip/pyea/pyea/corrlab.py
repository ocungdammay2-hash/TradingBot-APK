"""Tương quan chỉ báo ↔ giá và tham số ↔ kết quả (không Kivy; chỉ thư viện chuẩn).
Số liệu do CODE tính (Spearman theo hạng, kiểm ý nghĩa có trừ chồng lấn); AI chỉ đọc bảng này (xem btanalysis.build_advice_messages).
Cảnh báo cố hữu: tương quan trong quá khứ ≠ nhân quả; quét nhiều thứ thì có cái «ý nghĩa» do ngẫu nhiên -> luôn kiểm lại ngoài mẫu."""
import math

HORIZONS = (1, 5, 20)
MIN_N = 30


def _ranks(xs):
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    rk = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            rk[order[k]] = avg
        i = j + 1
    return rk


def pearson(x, y):
    n = len(x)
    if n < 3 or n != len(y):
        return None
    mx, my = sum(x) / n, sum(y) / n
    sxx = sum((a - mx) ** 2 for a in x)
    syy = sum((b - my) ** 2 for b in y)
    if sxx <= 1e-18 or syy <= 1e-18:
        return None                                        # một bên hằng số: không có tương quan để nói
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / math.sqrt(sxx * syy)


def spearman(x, y):
    """Tương quan hạng (bền với giá trị ngoại lai). None nếu < 3 điểm hoặc một bên hằng số."""
    pairs = [(a, b) for a, b in zip(x, y) if a is not None and b is not None and math.isfinite(a) and math.isfinite(b)]
    if len(pairs) < 3:
        return None
    return pearson(_ranks([p[0] for p in pairs]), _ranks([p[1] for p in pairs]))


def t_stat(rho, n_eff):
    if rho is None or n_eff is None or n_eff <= 3:
        return None
    r = max(-0.999999, min(0.999999, rho))
    return r * math.sqrt((n_eff - 2) / (1.0 - r * r))


def align_plots(candles, plots):
    """{tên: [(t, v)]} -> {tên: [giá trị theo từng nến (None nếu chưa có)]}; giá trị gần nhất KHÔNG sau thời điểm nến (không nhìn trước)."""
    times = [c.time for c in candles]
    out = {}
    for name, pts in (plots or {}).items():
        pts = sorted((t, v) for t, v in pts if v is not None and isinstance(v, (int, float)) and math.isfinite(v))
        if len(pts) < MIN_N:
            continue
        col, j, cur = [], 0, None
        for t in times:
            while j < len(pts) and pts[j][0] <= t:
                cur = pts[j][1]
                j += 1
            col.append(cur)
        out[name] = col
    return out


def normalize(candles, series):
    """Chỉ báo cùng thang giá (MA, band...) -> khoảng cách tương đối so với giá đóng cửa ((close-v)/v); chỉ báo kiểu dao động (RSI...) giữ nguyên.
    -> {tên: (cột, ghi chú)}"""
    out = {}
    closes = [c.close for c in candles]
    for name, col in series.items():
        vals = [(v, c) for v, c in zip(col, closes) if v is not None]
        if len(vals) < MIN_N:
            continue
        ratios = sorted(abs(v) / c for v, c in vals if c)
        med = ratios[len(ratios) // 2] if ratios else 0
        if 0.5 <= med <= 2.0:
            out[name] = ([None if v is None or not v else (c - v) / v for v, c in zip(col, closes)], "khoảng cách tới giá (close-v)/v")
        else:
            out[name] = (list(col), "")
    return out


def forward_returns(closes, h):
    return [(closes[i + h] / closes[i] - 1.0) if i + h < len(closes) and closes[i] else None for i in range(len(closes))]


def indicator_vs_price(candles, plots, horizons=HORIZONS):
    """Tương quan hạng giữa giá trị chỉ báo tại nến i và lợi suất h nến SAU đó. Dòng: {name, h, rho, n, n_eff, t, significant, note}.
    n_eff = n/h vì lợi suất h nến chồng lấn nhau (không chia thì t phóng đại). significant = |t|>=3 (ngưỡng cao vì quét nhiều chỉ báo × khung)."""
    norm = normalize(candles, align_plots(candles, plots))
    closes = [c.close for c in candles]
    rows = []
    for name, (col, note) in norm.items():
        for h in horizons:
            fr = forward_returns(closes, h)
            pairs = [(a, b) for a, b in zip(col, fr) if a is not None and b is not None]
            if len(pairs) < MIN_N:
                continue
            rho = spearman([p[0] for p in pairs], [p[1] for p in pairs])
            n_eff = len(pairs) / float(h)
            t = t_stat(rho, n_eff)
            rows.append({"name": name, "h": h, "rho": rho, "n": len(pairs), "n_eff": round(n_eff, 1), "t": t, "note": note,
                         "significant": t is not None and abs(t) >= 3.0})
    rows.sort(key=lambda r: -(abs(r["t"]) if r["t"] is not None else 0))
    return rows


def indicator_redundancy(candles, plots, threshold=0.8):
    """Cặp chỉ báo TRÙNG thông tin: Spearman của THAY ĐỔI (hiệu bậc 1) - so mức thô thì hai chuỗi cùng xu hướng luôn «tương quan» giả. [{a, b, rho}]"""
    norm = normalize(candles, align_plots(candles, plots))
    diffs = {}
    for name, (col, _n) in norm.items():
        diffs[name] = [(col[i] - col[i - 1]) if col[i] is not None and col[i - 1] is not None else None for i in range(len(col))]
    names, out = list(diffs), []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            pairs = [(a, b) for a, b in zip(diffs[names[i]], diffs[names[j]]) if a is not None and b is not None]
            if len(pairs) < MIN_N:
                continue
            rho = spearman([p[0] for p in pairs], [p[1] for p in pairs])
            if rho is not None and abs(rho) >= threshold:
                out.append({"a": names[i], "b": names[j], "rho": rho})
    return sorted(out, key=lambda r: -abs(r["rho"]))


def _num(v):
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) else None


def param_effects(results, metric="Lợi nhuận ròng"):
    """Từ kết quả tối ưu: (1) hạng-tương quan GIỮA giá trị từng tham số số và `metric`; (2) tương quan giữa các tham số TRONG 25% lần chạy tốt nhất
    (nếu fast cao đi cùng slow cao ở nhóm tốt = tham số phụ thuộc nhau, không chỉnh riêng lẻ được). Lưới đầy đủ thì tham số độc lập nên (2) chỉ có nghĩa ở nhóm tốt.
    -> {"vs_metric": [{name, rho, n}], "pairs_top": [{a, b, rho, n}], "top_n": int}"""
    def rows(rs):
        return [(r.get("params") or {}, _num((r.get("report") or {}).get(metric))) for r in rs]
    allr = [(p, m) for p, m in rows(results) if m is not None]
    names = []
    for p, _m in allr:
        for k, v in p.items():
            if _num(v) is not None and k not in names:
                names.append(k)
    vs = []
    for k in names:
        xs = [(_num(p.get(k)), m) for p, m in allr if _num(p.get(k)) is not None]
        if len({x for x, _ in xs}) < 2:
            continue
        rho = spearman([x for x, _ in xs], [m for _, m in xs])
        if rho is not None:
            vs.append({"name": k, "rho": rho, "n": len(xs)})
    vs.sort(key=lambda r: -abs(r["rho"]))
    top = sorted(allr, key=lambda pm: -pm[1])[:max(8, len(allr) // 4)]
    pairs = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            xs = [(_num(p.get(names[i])), _num(p.get(names[j]))) for p, _m in top]
            xs = [(a, b) for a, b in xs if a is not None and b is not None]
            if len(xs) < 8 or len({a for a, _ in xs}) < 2 or len({b for _, b in xs}) < 2:
                continue
            rho = spearman([a for a, _ in xs], [b for _, b in xs])
            if rho is not None:
                pairs.append({"a": names[i], "b": names[j], "rho": rho, "n": len(xs)})
    pairs.sort(key=lambda r: -abs(r["rho"]))
    return {"vs_metric": vs, "pairs_top": pairs, "top_n": len(top)}


def _f(v, d=3):
    return "-" if v is None else ("%+.*f" % (d, v))


def indicator_text(rows, redundant, limit=14):
    """Văn bản gọn cho giao diện và cho AI."""
    out = []
    if not rows:
        out.append("Không có chuỗi chỉ báo nào đủ dài (>= %d điểm) - bot cần self.api.plot(...) để xuất chỉ báo." % MIN_N)
    else:
        out.append("Tương quan hạng: chỉ báo tại nến i ↔ lợi suất h nến sau (t đã trừ chồng lấn; * = |t|>=3):")
        for r in rows[:limit]:
            out.append("  %s h=%d: rho %s  t %s  n_eff %s %s%s" % (r["name"], r["h"], _f(r["rho"]), _f(r["t"], 1), r["n_eff"],
                                                                 "*" if r["significant"] else "", (" [" + r["note"] + "]") if r["note"] else ""))
        if not any(r["significant"] for r in rows):
            out.append("  -> KHÔNG chỉ báo nào có tương quan đủ mạnh với lợi suất sau đó (|t|<3): đừng kỳ vọng tham số «tối ưu» có cơ sở thống kê.")
    if redundant:
        out.append("Cặp chỉ báo trùng thông tin (Spearman của thay đổi >= 0.8):")
        for r in redundant[:8]:
            out.append("  %s ~ %s: %s" % (r["a"], r["b"], _f(r["rho"], 2)))
    return "\n".join(out)


def param_text(eff, metric):
    out = []
    if eff["vs_metric"]:
        out.append("Tham số ↔ %s (Spearman trên mọi lần chạy):" % metric)
        for r in eff["vs_metric"]:
            out.append("  %s: rho %s (n=%d)" % (r["name"], _f(r["rho"]), r["n"]))
    if eff["pairs_top"]:
        out.append("Phụ thuộc giữa tham số trong %d lần chạy tốt nhất:" % eff["top_n"])
        for r in eff["pairs_top"][:6]:
            out.append("  %s ~ %s: rho %s" % (r["a"], r["b"], _f(r["rho"], 2)))
    return "\n".join(out)
