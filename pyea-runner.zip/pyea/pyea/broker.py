"""
Broker giao dịch THẬT (thử nghiệm) - chỉ lệnh thị trường.

  BinanceBroker         : Spot, chỉ mua/bán (KHÔNG bán khống)
  BinanceFuturesBroker  : USDT-M Futures, mua + BÁN KHỐNG, đòn bẩy (One-way hoặc Hedge mode - tự nhận diện)

Giao diện chung (engine chỉ dùng các thành viên này):
    supports_short : bool
    prepare(symbol, leverage) -> số dư quote khả dụng (kiểm tra kết nối/chế độ tài khoản)
    market_order(symbol, side, qty, reduce_only=False) -> Fill
Muốn thêm sàn khác: viết class có cùng giao diện rồi đăng ký trong make_broker().
"""
import hashlib
import hmac
import math
import re
import time
import urllib.parse
import uuid
from dataclasses import dataclass
from urllib.parse import urlsplit

from .feeds import FeedError, HttpError, http_json, resolve_base
from .protection import PROT_PREFIX, ProtectionAPI, sync_ladder  # noqa: F401 - sync_ladder/PROT_PREFIX giữ ở đây cho code cũ
from .ratelimit import limiter_for


class BrokerError(Exception):
    pass


@dataclass
class Fill:
    price: float     # giá khớp trung bình
    qty: float       # số lượng thực tế (spot: đã trừ phí nếu phí tính bằng coin)
    ref: str = ""    # mã VỊ THẾ trên sàn (ticket MT...) nếu sàn có vị thế riêng cho lệnh này; "" = không có/không biết
    order_id: str = ""   # mã LỆNH trên sàn - khớp với `order_id` trong `history()` để đối soát biết lần khớp nào là của app; "" = sàn không trả


class _BinanceBase:
    supports_short = False
    netting = False            # True: sàn gộp vị thế 1 chiều/mã -> không giữ đồng thời mua+bán cùng mã
    api = "/api/v3"            # tiền tố REST

    _hedge = False             # Futures: tài khoản ở Hedge Mode -> mọi lệnh phải kèm positionSide (và KHÔNG được gửi reduceOnly)

    def _extra_order_params(self, side):
        """Tham số riêng của chế độ vị thế cho lệnh MỞ vị thế theo `side` (Spot: không có)."""
        return {}

    def __init__(self, api_key, api_secret, base_url):
        if not api_key or not api_secret:
            raise BrokerError("Thiếu API key / secret")
        self.key = api_key.strip()
        self.secret = api_secret.strip().encode()
        self.base = base_url.rstrip("/")
        self._offset = None
        self._info = {}
        self._lev_done = set()
        self._native = {}                 # mã lệnh chờ -> symbol (để hỏi/huỷ)
        self._watch = set()
        self._quote_asset = "USDT"
        self.limiter = limiter_for("binance_futures" if self.api.startswith("/fapi") else "binance_spot", self.base)

    # ---- HTTP có chữ ký ----
    def _server_time_ms(self):
        if self._offset is None:
            try:
                d = http_json(self.base + self.api + "/time", limiter=self.limiter, cost=1)
                self._offset = d["serverTime"] / 1000.0 - time.time()
            except Exception:
                self._offset = 0.0
        return int((time.time() + self._offset) * 1000)

    _COST = {"/account": 20, "/positionRisk": 5, "/balance": 5, "/myTrades": 20, "/userTrades": 5, "/openOrders": 6,
             "/order": 1, "/allOrders": 20, "/apiRestrictions": 1, "/accountConfig": 5, "/symbolConfig": 5, "/algoOrder": 1, "/openAlgoOrders": 1,
             "/orderList": 4, "/openOrderList": 6, "/income": 30}

    def _cost(self, path):
        for k, v in self._COST.items():
            if path.endswith(k):
                return v
        return 1

    def _signed(self, method, path, params, base=None):
        p = dict(params)
        p["timestamp"] = self._server_time_ms()
        p["recvWindow"] = 10000
        query = urllib.parse.urlencode(p)
        sig = hmac.new(self.secret, query.encode(), hashlib.sha256).hexdigest()
        url = "%s%s?%s&signature=%s" % (base or self.base, path, query, sig)
        try:
            return http_json(url, headers={"X-MBX-APIKEY": self.key}, method=method, timeout=15, limiter=self.limiter,
                             cost=self._cost(path))
        except FeedError as e:
            raise BrokerError(str(e))

    def check_permissions(self):
        """Kiểm tra quyền của API key (Binance: GET /sapi/v1/account/apiRestrictions - có ký). Trả về list cảnh báo (rỗng = ổn).
        An toàn nhất: key CHỈ bật 'đọc + giao dịch', TẮT rút tiền, và giới hạn theo IP. Lỗi mạng/Testnet (không có endpoint) -> bỏ qua."""
        host = None
        if self.api.startswith("/fapi"):
            # endpoint sapi nằm ở host SPOT. Key Futures thật cũng là key tài khoản Binance nên gọi được từ host Spot; host Testnet/Demo khác khoá
            # (hoặc không có endpoint) -> lỗi -> bỏ qua, không báo gì.
            if urlsplit(self.base).hostname != "fapi.binance.com":
                return []
            host = "https://api.binance.com"
        try:
            d = (self._signed("GET", "/sapi/v1/account/apiRestrictions", {}, base=host) if host
                 else self._signed("GET", "/sapi/v1/account/apiRestrictions", {}))
        except Exception:
            return []
        warns = []
        if not isinstance(d, dict):
            return warns
        if d.get("enableWithdrawals"):
            warns.append("API key đang BẬT quyền RÚT TIỀN - hãy tắt trên Binance, bot không cần quyền này")
        if d.get("enableInternalTransfer") or d.get("permitsUniversalTransfer"):
            warns.append("API key đang bật quyền chuyển nội bộ/universal transfer - nên tắt")
        if not d.get("ipRestrict"):
            warns.append("API key CHƯA giới hạn theo địa chỉ IP - nếu lộ key, ai cũng dùng được")
        if host is None and not d.get("enableSpotAndMarginTrading"):
            warns.append("API key CHƯA bật quyền giao dịch Spot")
        if host is not None and not d.get("enableFutures"):
            warns.append("API key CHƯA bật quyền giao dịch Futures")
        return warns

    def account_flags(self):
        """Cờ tài khoản đọc từ sàn: {"currency", "can_trade" (canTrade), "margin_mode" (cross|isolated|mixed, chỉ Futures)}.
        Mỗi trường chỉ có khi sàn trả về; lỗi mạng/endpoint thiếu -> bỏ qua trường đó (không ném lỗi)."""
        out = {"currency": self._quote_asset}
        fut = self.api.startswith("/fapi")
        try:
            d = None
            for path in (("/fapi/v2/account", "/fapi/v3/account") if fut else (self.api + "/account",)):
                try:
                    d = self._signed("GET", path, {})
                    break
                except BrokerError:
                    continue
            if isinstance(d, dict) and "canTrade" in d:
                out["can_trade"] = bool(d["canTrade"])
            elif fut:
                # Tài liệu: /fapi/v3/account KHÔNG còn canTrade; /fapi/v1/accountConfig trả canTrade (+ dualSidePosition).
                try:
                    cfg = self._signed("GET", "/fapi/v1/accountConfig", {})
                    if isinstance(cfg, dict) and "canTrade" in cfg:
                        out["can_trade"] = bool(cfg["canTrade"])
                except BrokerError:
                    pass
            if fut:
                rows = None
                for path in ("/fapi/v2/positionRisk", "/fapi/v3/positionRisk"):
                    try:
                        rows = self._signed("GET", path, {})
                        break
                    except BrokerError:
                        continue
                rows = rows if isinstance(rows, list) else []
                kinds, held, held_syms = set(), set(), set()
                for r in rows:
                    try:
                        has_pos = abs(float(r.get("positionAmt", 0))) > 0
                    except (TypeError, ValueError):
                        has_pos = False
                    if has_pos and r.get("symbol"):
                        held_syms.add(str(r["symbol"]))
                    mt = str(r.get("marginType") or "").lower()
                    if not mt:
                        continue
                    k = "isolated" if mt.startswith("isol") else "cross"
                    kinds.add(k)
                    if has_pos:
                        held.add(k)
                if not kinds:
                    # positionRisk v3 KHÔNG có marginType (tài liệu): hỏi /fapi/v1/symbolConfig (marginType = CROSSED|ISOLATED) cho các mã đang giữ vị thế
                    # (không có vị thế thì hỏi một mã đang theo dõi). Mỗi mã một lời gọi - giới hạn 5 mã.
                    for sy in (sorted(held_syms) or sorted(self._watch)[:1])[:5]:
                        try:
                            cfg = self._signed("GET", "/fapi/v1/symbolConfig", {"symbol": sy})
                        except BrokerError:
                            continue
                        for r in cfg if isinstance(cfg, list) else [cfg] if isinstance(cfg, dict) else []:
                            mt = str(r.get("marginType") or "").lower()
                            if mt:
                                kinds.add("isolated" if mt.startswith("isol") else "cross")
                                held.add("isolated" if mt.startswith("isol") else "cross")
                use = held or kinds
                if use:
                    out["margin_mode"] = next(iter(use)) if len(use) == 1 else "mixed"
        except Exception:                                   # noqa: BLE001 - cờ chỉ để hiển thị/chặn sớm, không được làm hỏng vòng poll
            pass
        return out

    # ---- tiện ích số lượng ----
    @staticmethod
    def _floor_step(qty, step):
        if step <= 0:
            return qty
        return math.floor(qty / step + 1e-9) * step

    @staticmethod
    def _fmt_qty(qty, step):
        decimals = max(0, int(round(-math.log10(step)))) if step > 0 else 8
        return ("%." + str(decimals) + "f") % qty

    def _check_qty(self, symbol, qty):
        info = self._symbol_info(symbol)
        q = self._floor_step(float(qty), info["step"])
        if q <= 0 or q < info["min_qty"]:
            raise BrokerError("Khối lượng %.8g nhỏ hơn mức tối thiểu %.8g của %s" % (q, info["min_qty"], symbol))
        return q, info

    # ---- lệnh chờ NATIVE trên sàn (limit / stop) ----
    native_pending = {"limit", "stop"}
    _PEND_TYPE = {"limit": "LIMIT", "stop": "STOP_LOSS"}           # Futures ghi đè: stop -> STOP_MARKET
    _STATE = {"NEW": "open", "PARTIALLY_FILLED": "open", "PENDING_NEW": "open", "FILLED": "filled", "CANCELED": "canceled",
              "EXPIRED": "expired", "EXPIRED_IN_MATCH": "expired", "REJECTED": "rejected"}

    def _fmt_price(self, symbol, price):
        tick = float(self._symbol_info(symbol).get("tick") or 0.0)
        if tick > 0:
            dec = max(0, int(round(-math.log10(tick))))
            return ("%." + str(dec) + "f") % (round(float(price) / tick) * tick)
        return ("%.8f" % float(price)).rstrip("0").rstrip(".")

    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        """Đặt lệnh chờ TRÊN SÀN. SL/TP không gắn vào lệnh (Binance không cho) - vỏ tự giữ SL/TP sau khi khớp. Trả mã lệnh (chuỗi)."""
        if kind not in self.native_pending:
            raise BrokerError("Binance không hỗ trợ lệnh chờ native loại '%s'" % kind)
        q, info = self._check_qty(symbol, volume)
        params = {"symbol": symbol, "side": side.upper(), "type": self._PEND_TYPE[kind], "quantity": self._fmt_qty(q, info["step"]),
                  "newOrderRespType": "ACK",
                  "newClientOrderId": (re.sub(r"[^A-Za-z0-9_-]", "", str(client_id or "pyea"))[:22] + uuid.uuid4().hex[:10])}
        if kind == "limit":
            params.update(price=self._fmt_price(symbol, price), timeInForce="GTC")
        else:
            params["stopPrice"] = self._fmt_price(symbol, price)
        params.update(self._extra_order_params(side))
        d = self._signed("POST", self.api + "/order", params)
        oid = d.get("orderId") if isinstance(d, dict) else None
        if oid is None:
            raise BrokerError("Phản hồi đặt lệnh chờ không có orderId: %s" % str(d)[:200])
        self._native[str(oid)] = symbol
        return str(oid)

    def cancel_pending(self, native_id, symbol=None):
        symbol = symbol or self._native.get(str(native_id))
        if not symbol:
            raise BrokerError("Thiếu mã giao dịch để huỷ lệnh %s" % native_id)
        self._signed("DELETE", self.api + "/order", {"symbol": symbol, "orderId": native_id})
        self._native.pop(str(native_id), None)
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        """Binance không có 'sửa' chung cho Spot/Futures -> huỷ lệnh cũ rồi đặt lệnh mới (mã lệnh ĐỔI, hàm trả mã mới)."""
        if price is None:
            return str(native_id)
        symbol = symbol or self._native.get(str(native_id))
        old = self._signed("GET", self.api + "/order", {"symbol": symbol, "orderId": native_id})
        kind = "limit" if str(old.get("type", "")).upper() == "LIMIT" else "stop"
        qty = float(old.get("origQty", 0)) - float(old.get("executedQty", 0) or 0)
        self.cancel_pending(native_id, symbol)
        try:
            return self.place_pending(symbol, str(old.get("side", "BUY")).lower(), kind, qty, price)
        except BrokerError as e:
            raise BrokerError("Đã huỷ lệnh cũ nhưng không đặt được lệnh mới: %s" % e)

    def pending_orders(self, known=None):
        """{mã lệnh: thông tin} của các lệnh chờ đang sống. `known` = [(mã lệnh, symbol)] mà vỏ đang theo dõi (để chạy được cả sau khi khởi động lại)."""
        syms = set(self._native.values()) | {sy for _, sy in (known or [])}
        out = {}
        for sy in sorted(syms):
            rows = self._signed("GET", self.api + "/openOrders", {"symbol": sy})
            for r in rows if isinstance(rows, list) else []:
                out[str(r.get("orderId"))] = {"symbol": sy, "side": str(r.get("side", "")).lower(), "price": float(r.get("price") or 0) or float(r.get("stopPrice") or 0),
                                              "qty": float(r.get("origQty") or 0), "type": str(r.get("type", ""))}
        for k in list(self._native):
            if k not in out and self._native[k] in syms:
                pass                                           # giữ lại tới khi order_result xác nhận
        return out

    def order_result(self, native_id, symbol=None):
        symbol = symbol or self._native.get(str(native_id))
        d = self._signed("GET", self.api + "/order", {"symbol": symbol, "orderId": native_id})
        st = self._STATE.get(str(d.get("status", "")).upper(), "unknown")
        ex = float(d.get("executedQty") or 0.0)
        if st in ("canceled", "expired") and ex > 0:
            st = "filled"                                      # khớp một phần rồi hết hạn/huỷ: phần đã khớp là thật
        out = {"state": st}
        if st == "filled" and ex > 0:
            quote = float(d.get("cummulativeQuoteQty") or d.get("cumQuote") or 0.0)
            px = float(d.get("avgPrice") or 0.0) or (quote / ex if quote else float(d.get("price") or 0.0))
            out.update(price=px, qty=self._net_fill_qty(symbol, native_id, d, ex))
        if st in ("filled", "canceled", "expired", "rejected"):
            self._native.pop(str(native_id), None)
        return out

    def _net_fill_qty(self, symbol, native_id, order, executed):
        return executed

    # ---- lịch sử giao dịch + số dư từ sàn ----
    def balance(self):
        raise NotImplementedError

    def history(self, since=0.0, symbols=None):
        raise NotImplementedError

    def set_watch(self, symbols):
        self._watch = set(symbols or ())

    def _symbol_info(self, symbol):
        raise NotImplementedError


class BinanceBroker(ProtectionAPI, _BinanceBase):
    """Spot."""
    supports_short = False
    api = "/api/v3"

    # ---- lịch sử giao dịch Spot qua bộ máy chung (pyea/histengine.py, hồ sơ BINANCE_SPOT: /api/v3/myTrades theo mã, cửa sổ 24 giờ) ----
    def history_call(self, method, path, params=None, body=None):
        if str(method).upper() != "GET":
            raise BrokerError("Lịch sử chỉ được đọc (GET)")
        return self._signed("GET", path, params or {})

    def history_ctx(self):
        return {"symbols": sorted(self._watch or []), "quote": self._quote_asset, "account": ""}

    def account_history(self, since, until=None):
        from . import histengine
        return histengine.run_for_broker(self, "binance_spot", since, until)

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", {"symbol": symbol}, limiter=self.limiter, cost=20)
            s = d["symbols"][0]
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = tick = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") == "LOT_SIZE":
                step, min_qty = float(f["stepSize"]), float(f["minQty"])
            elif f.get("filterType") == "PRICE_FILTER":
                tick = float(f.get("tickSize") or 0.0)
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty, "tick": tick}
        self._info[symbol] = info
        return info

    spot_like = True          # không có "vị thế": chỉ có số dư coin -> đối soát chỉ báo khi sàn có ÍT hơn sổ app (coin có sẵn ngoài app là bình thường)

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        self._quote_asset = info["quote"]
        acc = self._signed("GET", self.api + "/account", {})
        for b in acc.get("balances", []):
            if b["asset"] == info["quote"]:
                return float(b["free"])
        return 0.0

    def _balances(self):
        acc = self._signed("GET", self.api + "/account", {})
        return {b["asset"]: (float(b.get("free") or 0) + float(b.get("locked") or 0)) for b in acc.get("balances", [])}

    def balance(self):
        return self._balances().get(self._quote_asset, 0.0)

    def positions(self):
        """Spot: {symbol: {"qty": số dư coin cơ sở (free+locked), "price": 0}} cho các mã vỏ đang quan tâm (set_watch)."""
        if not self._watch:
            return {}
        bal = self._balances()
        out = {}
        for sy in sorted(self._watch):
            try:
                info = self._symbol_info(sy)
            except BrokerError:
                continue
            q = bal.get(info["base"], 0.0)
            if q > 0 and q >= max(info["min_qty"], 1e-12):
                out[sy] = {"qty": q, "price": 0.0}
        return out

    def _net_fill_qty(self, symbol, native_id, order, executed):
        """Phí mua tính bằng coin nhận về -> số lượng ròng = khớp - phí (giống market_order)."""
        try:
            info = self._symbol_info(symbol)
            tr = self._signed("GET", self.api + "/myTrades", {"symbol": symbol, "orderId": native_id})
            fee = sum(float(t.get("commission") or 0) for t in tr if t.get("commissionAsset") == info["base"]) if str(order.get("side")).upper() == "BUY" else 0.0
            return max(0.0, executed - fee)
        except BrokerError:
            return executed

    def history(self, since=0.0, symbols=None):
        out = []
        for sy in sorted(set(symbols or self._watch or [])):
            params = {"symbol": sy, "limit": 1000}
            if since:
                params["startTime"] = int(since * 1000)
            rows = self._signed("GET", self.api + "/myTrades", params)
            base = self._symbol_info(sy)["base"] if rows else ""
            for t in rows if isinstance(rows, list) else []:
                out.append({"id": str(t.get("id")), "time": float(t.get("time", 0)) / 1000.0, "symbol": sy, "side": "buy" if t.get("isBuyer") else "sell",
                            "qty": float(t.get("qty") or 0), "price": float(t.get("price") or 0), "fee": float(t.get("commission") or 0),
                            "fee_asset": t.get("commissionAsset", ""), "pnl": 0.0, "order_id": str(t.get("orderId"))})
        return sorted(out, key=lambda x: x["time"])

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        res = self._signed("POST", self.api + "/order", {
            "symbol": symbol, "side": side.upper(), "type": "MARKET",
            "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "FULL"})
        try:
            executed = float(res["executedQty"])
            quote = float(res["cummulativeQuoteQty"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        net = executed
        if side == "buy":     # phí tính bằng coin nhận về -> trừ ra
            for f in res.get("fills", []):
                if f.get("commissionAsset") == info["base"]:
                    net -= float(f.get("commission", 0))
        return Fill(price=quote / executed, qty=net, order_id=str(res.get("orderId") or ""))

    # ---- SL/TP NATIVE trên Spot qua lệnh OCO (pyea/protection.py, PROT_STYLE="pair": hàm nguyên thuỷ sync_steps + protection_orders) ----
    # Tài liệu Binance Spot (developers.binance.com/docs/binance-spot-api-docs/rest-api, trang Trading + Account endpoints):
    #   * Spot KHÔNG có reduceOnly; mọi lệnh BÁN đang chờ khoá coin đang giữ -> SL và TP của cùng vị thế phải đi chung MỘT lệnh OCO.
    #   * POST /api/v3/orderList/oco: bắt buộc symbol, side, quantity (chung cho cả hai lệnh), aboveType, belowType. Với BÁN: lệnh «trên» là
    #     LIMIT_MAKER (abovePrice = giá chốt lời) và lệnh «dưới» là STOP_LOSS (belowStopPrice = giá cắt lỗ, khớp thị trường khi chạm) hoặc
    #     STOP_LOSS_LIMIT. Điều kiện giá: giá TP > giá khớp gần nhất > giá SL. Trả orderListId + orders[{orderId, clientOrderId}].
    #   * DELETE /api/v3/orderList (symbol + orderListId): huỷ cả cặp. GET /api/v3/orderList (orderListId): orders[] của cặp.
    #   * GET /api/v3/openOrders trả từng chân kèm orderListId (-1 = lệnh đơn), clientOrderId, type, price, stopPrice, origQty, executedQty.
    #   * Lệnh đơn: STOP_LOSS cần quantity + stopPrice; LIMIT_MAKER cần quantity + price.
    # Chân nào khớp thì chân kia tự bị sàn huỷ -> vỏ hỏi từng chân (GET /order) để biết chân nào khớp và giá khớp thật.
    PROT = PROT_PREFIX
    PROT_STYLE = "pair"
    OCO = "oco:"
    PROT_LABEL = {"sl": "STOP_LOSS (Spot)", "tp": "LIMIT_MAKER (Spot)"}                    # chỉ để ghi nhật ký/lý do
    _SL_TYPES = ("STOP_LOSS", "STOP_LOSS_LIMIT")
    _TP_TYPES = ("LIMIT_MAKER", "TAKE_PROFIT", "TAKE_PROFIT_LIMIT")

    def _fmt_opt_price(self, symbol, price):
        return self._fmt_price(symbol, price) if price else ""

    def protection_orders(self, symbol):
        """Lệnh bảo vệ của vỏ (clientOrderId bắt đầu bằng 'pyeaP') đang sống: [{id, kind, side, trigger, qty}] - một cặp OCO đủ hai chân
        là MỘT phần tử `kind="oco"` (id "oco:<orderListId>", thêm `sl`/`tp`); lệnh đơn có id là orderId."""
        rows = self._signed("GET", self.api + "/openOrders", {"symbol": symbol})
        step = self._symbol_info(symbol)["step"]
        singles, lists = [], {}
        for r in rows if isinstance(rows, list) else []:
            if not str(r.get("clientOrderId") or "").startswith(self.PROT):
                continue
            ot = str(r.get("type") or "").upper()
            kind = "sl" if ot in self._SL_TYPES else "tp" if ot in self._TP_TYPES else None
            if kind is None:
                continue
            row = {"kind": kind, "side": str(r.get("side", "")).lower(),
                   "trigger": float((r.get("stopPrice") if kind == "sl" else r.get("price")) or 0.0), "qty": float(r.get("origQty") or 0.0)}
            try:
                lid = int(r.get("orderListId"))
            except (TypeError, ValueError):
                lid = -1
            if lid > 0:
                lists.setdefault(lid, {})[kind] = row
            else:
                row["id"] = str(r.get("orderId"))
                row["step"] = step
                singles.append(row)
        out = list(singles)
        for lid in sorted(lists):
            legs = lists[lid]
            if "sl" in legs and "tp" in legs:
                sl, tp = legs["sl"], legs["tp"]
                out.append({"id": self.OCO + str(lid), "kind": "oco", "side": sl["side"], "trigger": sl["trigger"], "sl": sl["trigger"],
                            "tp": tp["trigger"], "qty": min(sl["qty"], tp["qty"]), "step": step})
            else:                                                       # chỉ thấy một chân (bất thường): coi như lệnh đơn nhưng huỷ qua cả cặp
                kind, row = next(iter(legs.items()))
                row.update(id=self.OCO + str(lid), step=step)
                out.append(row)
        return out

    def sync_steps(self, symbol, desired):
        """Đưa lệnh bảo vệ trên Spot về ĐÚNG `desired`: [{kind: sl|tp|oco, side: chiều ĐÓNG (sell), trigger, qty, (oco: sl, tp)}].
        Huỷ cái thừa TRƯỚC (giải phóng coin bị khoá) rồi mới đặt cái thiếu. Thuật toán chung: `sync_ladder`.
        -> {"live": [...], "covered": [chỉ số trong desired đã có lệnh sống], "errors": [chuỗi lỗi]}"""
        info = self._symbol_info(symbol)

        def qty_of(q):
            return self._floor_step(float(q), info["step"])

        def key_fn(d):
            return (d["kind"], str(d["side"]).lower(), self._fmt_price(symbol, d["trigger"]), self._fmt_qty(qty_of(d["qty"]), info["step"]),
                    self._fmt_opt_price(symbol, d.get("tp")) if d["kind"] == "oco" else "")

        def place_fn(d):
            if str(d["side"]).lower() != "sell":
                raise BrokerError("Spot chỉ có vị thế mua - lệnh bảo vệ phải là chiều bán, nhận %r" % d["side"])
            q, _ = self._check_qty(symbol, d["qty"])
            qs = self._fmt_qty(q, info["step"])
            tag = uuid.uuid4().hex[:12]
            if d["kind"] == "oco":
                r = self._signed("POST", self.api + "/orderList/oco", {
                    "symbol": symbol, "side": "SELL", "quantity": qs, "listClientOrderId": self.PROT + "o" + tag,
                    "aboveType": "LIMIT_MAKER", "abovePrice": self._fmt_price(symbol, d["tp"]), "aboveClientOrderId": self.PROT + "t" + tag,
                    "belowType": "STOP_LOSS", "belowStopPrice": self._fmt_price(symbol, d["sl"]), "belowClientOrderId": self.PROT + "s" + tag,
                    "newOrderRespType": "ACK"})
                lid = r.get("orderListId") if isinstance(r, dict) else None
                if lid is None:
                    raise BrokerError("phản hồi OCO không có orderListId: %s" % str(r)[:160])
                nid = self.OCO + str(lid)
                self._native[nid] = symbol
                return {"id": nid, "kind": "oco", "side": "sell", "trigger": float(d["sl"]), "sl": float(d["sl"]), "tp": float(d["tp"]), "qty": float(q), "step": info["step"]}
            params = {"symbol": symbol, "side": "SELL", "quantity": qs, "newOrderRespType": "ACK", "newClientOrderId": self.PROT + d["kind"][0] + tag}
            if d["kind"] == "sl":
                params.update(type="STOP_LOSS", stopPrice=self._fmt_price(symbol, d["trigger"]))
            else:
                params.update(type="LIMIT_MAKER", price=self._fmt_price(symbol, d["trigger"]))
            r = self._signed("POST", self.api + "/order", params)
            oid = r.get("orderId") if isinstance(r, dict) else None
            if oid is None:
                raise BrokerError("phản hồi không có orderId: %s" % str(r)[:160])
            self._native[str(oid)] = symbol
            return {"id": str(oid), "kind": d["kind"], "side": "sell", "trigger": float(d["trigger"]), "qty": float(q), "step": info["step"]}

        return sync_ladder(desired, key_fn, lambda d: qty_of(d["qty"]) > 0, lambda: self.protection_orders(symbol),
                           lambda o: self.cancel_pending(o["id"], symbol), place_fn)

    def cancel_pending(self, native_id, symbol=None):
        if not str(native_id).startswith(self.OCO):
            return super().cancel_pending(native_id, symbol)
        symbol = symbol or self._native.get(str(native_id))
        if not symbol:
            raise BrokerError("Thiếu mã giao dịch để huỷ cặp OCO %s" % native_id)
        self._signed("DELETE", self.api + "/orderList", {"symbol": symbol, "orderListId": str(native_id)[len(self.OCO):]})
        self._native.pop(str(native_id), None)
        return True

    def order_result(self, native_id, symbol=None):
        if not str(native_id).startswith(self.OCO):
            return super().order_result(native_id, symbol)
        lid = str(native_id)[len(self.OCO):]
        lst = self._signed("GET", self.api + "/orderList", {"orderListId": lid})
        symbol = symbol or (lst.get("symbol") if isinstance(lst, dict) else None) or self._native.get(str(native_id))
        legs = []
        for leg in (lst.get("orders") if isinstance(lst, dict) else None) or []:
            d = self._signed("GET", self.api + "/order", {"symbol": symbol, "orderId": leg.get("orderId")})
            ot = str(d.get("type") or "").upper()
            cid = str(d.get("clientOrderId") or leg.get("clientOrderId") or "")
            kind = "sl" if ot in self._SL_TYPES else "tp" if ot in self._TP_TYPES else ("sl" if cid.startswith(self.PROT + "s") else "tp" if cid.startswith(self.PROT + "t") else None)
            legs.append({"kind": kind, "state": self._STATE.get(str(d.get("status", "")).upper(), "unknown"),
                         "ex": float(d.get("executedQty") or 0.0), "quote": float(d.get("cummulativeQuoteQty") or 0.0),
                         "price": float(d.get("price") or 0.0)})
        if not legs:
            return {"state": "unknown"}
        hit = [g for g in legs if g["ex"] > 0]
        if hit:
            g = max(hit, key=lambda x: x["ex"])
            if any(x["state"] == "open" for x in legs):                 # đang khớp dở: chờ xong rồi mới ghi sổ
                return {"state": "open"}
            self._native.pop(str(native_id), None)
            return {"state": "filled", "price": (g["quote"] / g["ex"]) if g["quote"] > 0 else g["price"], "qty": g["ex"], "leg": g["kind"]}
        states = {g["state"] for g in legs}
        if "open" in states:
            return {"state": "open"}
        if "unknown" in states:
            return {"state": "unknown"}
        self._native.pop(str(native_id), None)
        return {"state": "rejected" if "rejected" in states else "canceled" if "canceled" in states else "expired"}


class BinanceFuturesBroker(ProtectionAPI, _BinanceBase):
    """USDT-M Futures. One-way mode: positionAmt có dấu, lệnh đóng gửi reduceOnly. Hedge mode (tự nhận ở prepare): MỌI lệnh phải kèm
    positionSide=LONG/SHORT và KHÔNG được gửi reduceOnly (tài liệu Binance: New Order / New Algo Order). Vỏ vẫn coi tài khoản là NETTING
    (mỗi mã chỉ một chiều) nên chỉ dùng một chân tại một thời điểm: mở mua -> BUY+LONG; đóng mua -> SELL+LONG; mở bán -> SELL+SHORT; đóng bán -> BUY+SHORT."""
    supports_short = True
    netting = True
    api = "/fapi/v1"
    _lev = 0
    _PEND_TYPE = {"limit": "LIMIT", "stop": "STOP_MARKET"}

    @staticmethod
    def _leg(side, closing=False):
        """Chân (positionSide) của lệnh: mua mở / bán đóng -> LONG; bán mở / mua đóng -> SHORT."""
        return "LONG" if (str(side).lower() == "buy") != bool(closing) else "SHORT"

    def _extra_order_params(self, side, closing=False):
        return {"positionSide": self._leg(side, closing)} if self._hedge else {}

    # ---- Lệnh điều kiện (stop) qua ALGO ORDER ----
    # Từ 2025-12-09 USDⓈ-M Futures chuyển STOP_MARKET/TAKE_PROFIT_MARKET/STOP/TAKE_PROFIT/TRAILING_STOP_MARKET sang Algo Service:
    # POST /fapi/v1/order với các loại này bị từ chối (mã -4120 STOP_ORDER_SWITCH_ALGO). Dùng POST /fapi/v1/algoOrder
    # (algoType=CONDITIONAL, triggerPrice), huỷ DELETE /fapi/v1/algoOrder, tra GET /fapi/v1/algoOrder, liệt kê GET /fapi/v1/openAlgoOrders.
    # (nguồn: developers.binance.com/docs/derivatives - change-log 2025-11-06 + trang New Algo Order / Query Algo Order).
    # Mã lệnh trả về có tiền tố "algo:" để phân biệt với orderId thường.
    ALGO = "algo:"
    _ALGO_STATE = {"NEW": "open", "TRIGGERING": "open", "TRIGGERED": "open", "CANCELED": "canceled", "EXPIRED": "expired",
                   "REJECTED": "rejected"}

    def _is_algo(self, nid):
        return str(nid).startswith(self.ALGO)

    def _aid(self, nid):
        return str(nid)[len(self.ALGO):]

    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind != "stop":
            return super().place_pending(symbol, side, kind, volume, price, stop_price, sl, tp, expiry, client_id)
        q, info = self._check_qty(symbol, volume)
        params = {"algoType": "CONDITIONAL", "symbol": symbol, "side": side.upper(), "type": "STOP_MARKET",
                  "quantity": self._fmt_qty(q, info["step"]), "triggerPrice": self._fmt_price(symbol, price), "workingType": "CONTRACT_PRICE",
                  "clientAlgoId": (re.sub(r"[^A-Za-z0-9_-]", "", str(client_id or "pyea"))[:20] + uuid.uuid4().hex[:10])}
        params.update(self._extra_order_params(side))
        d = self._signed("POST", self.api + "/algoOrder", params)
        aid = d.get("algoId") if isinstance(d, dict) else None
        if aid is None:
            raise BrokerError("Phản hồi đặt lệnh điều kiện (algoOrder) không có algoId: %s" % str(d)[:200])
        nid = self.ALGO + str(aid)
        self._native[nid] = symbol
        return nid

    # ---- SL/TP NATIVE: lệnh bảo vệ reduceOnly (pyea/protection.py, PROT_STYLE="ladder": hàm nguyên thuỷ sync_steps + protection_orders) ----
    PROT = PROT_PREFIX
    _PROT_TYPE = {"sl": "STOP_MARKET", "tp": "TAKE_PROFIT_MARKET"}
    PROT_LABEL = {"sl": "STOP_MARKET reduceOnly", "tp": "TAKE_PROFIT_MARKET reduceOnly"}      # chỉ để ghi nhật ký/lý do

    def protection_orders(self, symbol):
        """Các lệnh bảo vệ của vỏ (clientAlgoId bắt đầu bằng 'pyeaP') đang sống trên sàn: [{id, kind, side, trigger, qty}]."""
        rows = self._signed("GET", self.api + "/openAlgoOrders", {"symbol": symbol})
        out = []
        for r in rows if isinstance(rows, list) else []:
            if not str(r.get("clientAlgoId") or "").startswith(self.PROT):
                continue
            ot = str(r.get("orderType") or r.get("type") or "")
            kind = "sl" if ot == "STOP_MARKET" else "tp" if ot == "TAKE_PROFIT_MARKET" else None
            if kind is None:
                continue
            out.append({"id": self.ALGO + str(r.get("algoId")), "kind": kind, "side": str(r.get("side", "")).lower(),
                        "trigger": float(r.get("triggerPrice") or 0.0), "qty": float(r.get("quantity") or 0.0)})
        return out

    def sync_steps(self, symbol, desired):
        """Đưa các lệnh bảo vệ trên sàn về ĐÚNG `desired` ([{kind: sl|tp, side: chiều ĐÓNG, trigger, qty}]): huỷ lệnh thừa, đặt lệnh thiếu,
        giữ nguyên lệnh đã khớp mô tả (idempotent - chạy lại sau khi app khởi động lại không đặt trùng). Thuật toán chung: `sync_ladder`.
        -> {"live": [lệnh đang sống sau đồng bộ], "covered": [chỉ số trong desired đã có lệnh sống], "errors": [chuỗi lỗi]}"""
        info = self._symbol_info(symbol)

        def qty_of(q):
            return self._floor_step(float(q), info["step"])

        def key_fn(d):
            return (d["kind"], str(d["side"]).lower(), self._fmt_price(symbol, d["trigger"]), self._fmt_qty(qty_of(d["qty"]), info["step"]))

        def place_fn(d):
            q, _ = self._check_qty(symbol, d["qty"])
            params = {"algoType": "CONDITIONAL", "symbol": symbol, "side": str(d["side"]).upper(), "type": self._PROT_TYPE[d["kind"]],
                      "quantity": self._fmt_qty(q, info["step"]), "triggerPrice": self._fmt_price(symbol, d["trigger"]),
                      "workingType": "CONTRACT_PRICE",
                      "clientAlgoId": self.PROT + d["kind"][0] + uuid.uuid4().hex[:14]}
            if self._hedge:                           # Hedge Mode: positionSide của chân ĐANG GIỮ (chiều đóng ngược lại), không có reduceOnly
                params.update(self._extra_order_params(d["side"], closing=True))
            else:
                params["reduceOnly"] = "true"
            r = self._signed("POST", self.api + "/algoOrder", params)
            aid = r.get("algoId") if isinstance(r, dict) else None
            if aid is None:
                raise BrokerError("phản hồi không có algoId: %s" % str(r)[:160])
            nid = self.ALGO + str(aid)
            self._native[nid] = symbol
            return {"id": nid, "kind": d["kind"], "side": str(d["side"]).lower(), "trigger": float(d["trigger"]), "qty": float(q)}

        return sync_ladder(desired, key_fn, lambda d: qty_of(d["qty"]) > 0, lambda: self.protection_orders(symbol),
                           lambda o: self.cancel_pending(o["id"], symbol), place_fn)

    def cancel_pending(self, native_id, symbol=None):
        if not self._is_algo(native_id):
            return super().cancel_pending(native_id, symbol)
        self._signed("DELETE", self.api + "/algoOrder", {"algoId": self._aid(native_id)})
        self._native.pop(str(native_id), None)
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        if not self._is_algo(native_id):
            return super().modify_pending(native_id, symbol, price, sl, tp)
        if price is None:
            return str(native_id)
        symbol = symbol or self._native.get(str(native_id))
        old = self._signed("GET", self.api + "/algoOrder", {"algoId": self._aid(native_id)})
        qty = float(old.get("quantity") or 0.0)
        self.cancel_pending(native_id, symbol)
        try:
            return self.place_pending(symbol, str(old.get("side", "BUY")).lower(), "stop", qty, price)
        except BrokerError as e:
            raise BrokerError("Đã huỷ lệnh điều kiện cũ nhưng không đặt được lệnh mới: %s" % e)

    def pending_orders(self, known=None):
        out = super().pending_orders(known)
        syms = set(self._native.values()) | {sy for _, sy in (known or [])}
        for sy in sorted(syms):
            rows = self._signed("GET", self.api + "/openAlgoOrders", {"symbol": sy})
            for r in rows if isinstance(rows, list) else []:
                out[self.ALGO + str(r.get("algoId"))] = {
                    "symbol": sy, "side": str(r.get("side", "")).lower(), "price": float(r.get("triggerPrice") or 0),
                    "qty": float(r.get("quantity") or 0), "type": str(r.get("orderType", ""))}
        return out

    def order_result(self, native_id, symbol=None):
        if not self._is_algo(native_id):
            return super().order_result(native_id, symbol)
        symbol = symbol or self._native.get(str(native_id))
        d = self._signed("GET", self.api + "/algoOrder", {"algoId": self._aid(native_id)})
        st = str(d.get("algoStatus", "")).upper()
        if st == "FINISHED":                                   # đã kích hoạt và xong ở sàn khớp lệnh: lấy kết quả của LỆNH THẬT sinh ra
            oid = d.get("actualOrderId")
            if oid not in (None, "", 0, "0"):
                out = super().order_result(oid, symbol)
                if out.get("state") in ("filled", "canceled", "expired", "rejected"):
                    self._native.pop(str(native_id), None)
                return out
            px = float(d.get("actualPrice") or 0.0)
            if px > 0:                                         # không có orderId nhưng có giá khớp: dùng khối lượng đã đặt
                self._native.pop(str(native_id), None)
                return {"state": "filled", "price": px, "qty": float(d.get("quantity") or 0.0)}
            return {"state": "unknown"}
        out = {"state": self._ALGO_STATE.get(st, "unknown")}
        if out["state"] in ("canceled", "expired", "rejected"):
            self._native.pop(str(native_id), None)
        return out

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", timeout=30, limiter=self.limiter, cost=20)
            s = next(x for x in d["symbols"] if x["symbol"] == symbol)
        except StopIteration:
            raise BrokerError("Không có cặp futures %s" % symbol)
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = tick = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") in ("MARKET_LOT_SIZE", "LOT_SIZE"):
                st, mq = float(f["stepSize"]), float(f["minQty"])
                if f["filterType"] == "MARKET_LOT_SIZE" or step == 0:
                    step, min_qty = st, mq
            elif f.get("filterType") == "PRICE_FILTER":
                tick = float(f.get("tickSize") or 0.0)
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty, "tick": tick}
        self._info[symbol] = info
        return info

    def _balance(self, quote):
        err = None
        for path in ("/fapi/v2/balance", "/fapi/v3/balance"):      # tuỳ phiên bản API của sàn
            try:
                rows = self._signed("GET", path, {})
                for r in rows:
                    if r.get("asset") == quote:
                        return float(r.get("availableBalance", r.get("balance", 0)))
                return 0.0
            except BrokerError as e:
                err = e
        raise err

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        mode = self._signed("GET", self.api + "/positionSide/dual", {})
        self._hedge = bool(isinstance(mode, dict) and mode.get("dualSidePosition") in (True, "true", "True"))
        self._lev = max(1, int(round(float(leverage))))
        self._set_leverage(symbol)
        self._quote_asset = info["quote"]
        return self._balance(info["quote"])

    def balance(self):
        """Số dư ví (walletBalance) của đồng quote - để đối chiếu với sổ app."""
        err = None
        for path in ("/fapi/v2/balance", "/fapi/v3/balance"):
            try:
                for r in self._signed("GET", path, {}):
                    if r.get("asset") == self._quote_asset:
                        return float(r.get("balance", r.get("availableBalance", 0)))
                return 0.0
            except BrokerError as e:
                err = e
        raise err

    def history(self, since=0.0, symbols=None):
        """userTrades theo từng mã; sàn giới hạn mỗi lần hỏi tối đa 7 ngày -> cắt khúc."""
        out, now = [], time.time()
        for sy in sorted(set(symbols or self._watch or [])):
            t0 = since or (now - 7 * 86400)
            while t0 < now + 5:
                t1 = min(t0 + 7 * 86400 - 1, now + 5)          # cửa sổ cuối kéo tới hiện tại (+đệm lệch đồng hồ) để không sót lệnh vừa khớp
                rows = self._signed("GET", self.api + "/userTrades", {"symbol": sy, "startTime": int(t0 * 1000), "endTime": int(t1 * 1000), "limit": 1000})
                for t in rows if isinstance(rows, list) else []:
                    out.append({"id": str(t.get("id")), "time": float(t.get("time", 0)) / 1000.0, "symbol": sy, "side": str(t.get("side", "")).lower(),
                                "qty": float(t.get("qty") or 0), "price": float(t.get("price") or 0), "fee": float(t.get("commission") or 0),
                                "fee_asset": t.get("commissionAsset", ""), "pnl": float(t.get("realizedPnl") or 0), "order_id": str(t.get("orderId"))})
                t0 = t1 + 0.001                                  # +1 MILI-giây (không phải 1 giây: tránh để hở khoảng giữa hai cửa sổ)
        return sorted(out, key=lambda x: x["time"])

    # ---- lịch sử tài khoản đầy đủ (giao dịch + funding + nạp/rút) qua bộ máy chung pyea/histengine.py, hồ sơ pyea/histprofiles.py ----
    def history_call(self, method, path, params=None, body=None):
        """Đường gọi THÔ cho bộ máy lịch sử (đã ký + giới hạn tốc độ). Chỉ GET."""
        if str(method).upper() != "GET":
            raise BrokerError("Lịch sử chỉ được đọc (GET)")
        return self._signed("GET", path, params or {})

    def history_ctx(self):
        return {"symbols": sorted(self._watch or []), "quote": self._quote_asset, "account": ""}

    def account_history(self, since, until=None):
        from . import histengine
        return histengine.run_for_broker(self, "binance_futures", since, until)

    def positions(self):
        """Vị thế ròng đang mở trên sàn: {symbol: {"qty": số có dấu (+mua/-bán), "price": giá vào TB}}. One-way mode: positionAmt có dấu."""
        err = None
        for path in ("/fapi/v2/positionRisk", "/fapi/v3/positionRisk"):         # tuỳ phiên bản API của sàn
            try:
                rows = self._signed("GET", path, {})
                break
            except BrokerError as e:
                err = e
        else:
            raise err
        out = {}
        for r in rows if isinstance(rows, list) else []:
            try:
                q = float(r.get("positionAmt", 0))
                ps = str(r.get("positionSide") or "BOTH").upper()
                if ps == "SHORT":                         # Hedge Mode: mỗi chân một dòng; chân SHORT -> số âm bất kể sàn ghi dấu thế nào
                    q = -abs(q)
                elif ps == "LONG":
                    q = abs(q)
                if abs(q) > 0:
                    px = float(r.get("entryPrice") or 0)
                    cur = out.get(r["symbol"])
                    if cur is None:
                        out[r["symbol"]] = {"qty": q, "price": px}
                    else:                                 # hai chân cùng mã: vị thế ròng, giá của chân lớn hơn
                        big = px if abs(q) > abs(cur["qty"]) else cur["price"]
                        out[r["symbol"]] = {"qty": cur["qty"] + q, "price": big}
            except (KeyError, ValueError, TypeError):
                continue
        return {k: v for k, v in out.items() if abs(v["qty"]) > 1e-12}

    def _set_leverage(self, symbol):
        if symbol not in self._lev_done:
            self._signed("POST", self.api + "/leverage", {"symbol": symbol, "leverage": self._lev})
            self._lev_done.add(symbol)

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        if self._lev and symbol not in self._lev_done:      # nhiều mã: đặt đòn bẩy lần đầu cho từng mã
            self._set_leverage(symbol)
        params = {"symbol": symbol, "side": side.upper(), "type": "MARKET",
                  "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "RESULT"}
        if self._hedge:
            params.update(self._extra_order_params(side, closing=reduce_only))      # Hedge Mode: positionSide, KHÔNG reduceOnly
        elif reduce_only:
            params["reduceOnly"] = "true"
        res = self._signed("POST", self.api + "/order", params)
        try:
            executed = float(res["executedQty"])
            price = float(res.get("avgPrice") or 0)
            if price <= 0:
                price = float(res["cumQuote"]) / executed
        except (KeyError, ValueError, TypeError, ZeroDivisionError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        return Fill(price=price, qty=executed, order_id=str(res.get("orderId") or ""))


class OandaBroker(ProtectionAPI):
    """OANDA v20 (forex/kim loại/chỉ số CFD). Lệnh thị trường FOK, volume = số units (làm tròn số nguyên).
    Tài khoản gộp vị thế theo mã (netting) -> engine không giữ đồng thời mua+bán cùng mã."""
    supports_short = True
    netting = True

    def __init__(self, token, account_id, base_url):
        if not token or not account_id:
            raise BrokerError("Thiếu OANDA token / account ID")
        self.h = {"Authorization": "Bearer " + token.strip(), "Content-Type": "application/json"}
        self.acc = account_id.strip()
        self.base = base_url.rstrip("/")
        self.limiter = limiter_for("oanda", self.base)

    def _call(self, method, path, body=None):
        try:
            return http_json(self.base + path, headers=self.h, method=method, body=body, timeout=15, limiter=self.limiter, cost=1)
        except FeedError as e:
            raise BrokerError(str(e))

    def prepare(self, symbol, leverage=1.0):
        d = self._call("GET", "/v3/accounts/%s/summary" % self.acc)
        try:
            return float(d["account"]["balance"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi tài khoản OANDA không hợp lệ: %s" % str(d)[:160])

    def positions(self):
        """{instrument: {"qty": long.units + short.units (bán là số âm), "price": giá vào TB}} - GET /v3/accounts/{id}/openPositions."""
        d = self._call("GET", "/v3/accounts/%s/openPositions" % self.acc)
        out = {}
        for p in d.get("positions", []) if isinstance(d, dict) else []:
            try:
                lg, sh = p.get("long") or {}, p.get("short") or {}
                lu, su = float(lg.get("units", 0) or 0), float(sh.get("units", 0) or 0)
                q = lu + su
                if abs(q) > 0:
                    side = lg if abs(lu) >= abs(su) else sh
                    out[p["instrument"]] = {"qty": q, "price": float(side.get("averagePrice") or 0)}
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def market_order(self, symbol, side, qty, reduce_only=False):
        units = int(round(float(qty)))
        if units < 1:
            raise BrokerError("Khối lượng phải >= 1 unit")
        order = {"type": "MARKET", "instrument": symbol, "units": str(units if side == "buy" else -units),
                 "timeInForce": "FOK", "positionFill": "REDUCE_ONLY" if reduce_only else "DEFAULT"}
        d = self._call("POST", "/v3/accounts/%s/orders" % self.acc, {"order": order})
        fill = d.get("orderFillTransaction")
        if not fill:
            raise BrokerError("Lệnh không khớp: %s" % str(d.get("orderCancelTransaction") or d)[:200])
        try:
            return Fill(price=float(fill["price"]), qty=abs(float(fill["units"])), order_id=str(fill.get("orderID") or ""))
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi lệnh OANDA không hợp lệ: %s" % str(fill)[:200])

    # ---- lệnh chờ NATIVE (LIMIT / STOP) + kết quả + lịch sử + số dư ----
    native_pending = {"limit", "stop"}

    def _prec(self, symbol):
        c = self.__dict__.setdefault("_prec_cache", {})
        if symbol not in c:
            try:
                d = self._call("GET", "/v3/accounts/%s/instruments?instruments=%s" % (self.acc, symbol))
                c[symbol] = int(d["instruments"][0]["displayPrecision"])
            except (BrokerError, KeyError, IndexError, ValueError, TypeError):
                c[symbol] = 5
        return c[symbol]

    def _px(self, symbol, price):
        return "%.*f" % (self._prec(symbol), float(price))

    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind not in self.native_pending:
            raise BrokerError("OANDA: vỏ chỉ dùng lệnh chờ native loại limit/stop (nhận '%s')" % kind)
        units = int(round(float(volume)))
        if units < 1:
            raise BrokerError("Khối lượng phải >= 1 unit")
        order = {"type": "LIMIT" if kind == "limit" else "STOP", "instrument": symbol, "units": str(units if side == "buy" else -units),
                 "price": self._px(symbol, price), "timeInForce": "GTC", "positionFill": "DEFAULT", "triggerCondition": "DEFAULT",
                 "clientExtensions": {"id": re.sub(r"[^A-Za-z0-9_-]", "", str(client_id or "pyea"))[:24] + uuid.uuid4().hex[:8], "tag": "pyea"}}
        if expiry:
            order.update(timeInForce="GTD", gtdTime=time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime(float(expiry))))
        d = self._call("POST", "/v3/accounts/%s/orders" % self.acc, {"order": order})
        tx = (d or {}).get("orderCreateTransaction") or {}
        if (d or {}).get("orderCancelTransaction") or (d or {}).get("orderRejectTransaction") or not tx.get("id"):
            why = ((d or {}).get("orderRejectTransaction") or (d or {}).get("orderCancelTransaction") or d or {})
            raise BrokerError("OANDA từ chối lệnh chờ: %s" % (why.get("rejectReason") or why.get("reason") or str(why)[:200]))
        return str(tx["id"])

    def cancel_pending(self, native_id, symbol=None):
        self._call("PUT", "/v3/accounts/%s/orders/%s/cancel" % (self.acc, native_id))
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        """OANDA 'replace': hủy lệnh cũ + tạo lệnh mới nguyên tử -> mã lệnh ĐỔI (trả mã mới)."""
        if price is None:
            return str(native_id)
        old = (self._call("GET", "/v3/accounts/%s/orders/%s" % (self.acc, native_id)) or {}).get("order") or {}
        sym = old.get("instrument") or symbol
        new = {k: old[k] for k in ("type", "instrument", "units", "timeInForce", "gtdTime", "positionFill", "triggerCondition", "clientExtensions") if k in old}
        new["price"] = self._px(sym, price)
        d = self._call("PUT", "/v3/accounts/%s/orders/%s" % (self.acc, native_id), {"order": new})
        tx = (d or {}).get("orderCreateTransaction") or {}
        if not tx.get("id"):
            raise BrokerError("OANDA không sửa được lệnh chờ: %s" % str(d)[:200])
        return str(tx["id"])

    def pending_orders(self, known=None):
        d = self._call("GET", "/v3/accounts/%s/pendingOrders" % self.acc)
        out = {}
        for o in (d or {}).get("orders", []):
            if o.get("type") in ("LIMIT", "STOP", "MARKET_IF_TOUCHED"):
                u = float(o.get("units") or 0)
                out[str(o.get("id"))] = {"symbol": o.get("instrument"), "side": "buy" if u > 0 else "sell", "price": float(o.get("price") or 0),
                                         "qty": abs(u), "type": o.get("type")}
        return out

    def order_result(self, native_id, symbol=None):
        o = (self._call("GET", "/v3/accounts/%s/orders/%s" % (self.acc, native_id)) or {}).get("order") or {}
        st = str(o.get("state", "")).upper()
        if st == "PENDING":
            return {"state": "open"}
        if st == "FILLED":
            tid = o.get("fillingTransactionID")
            out = {"state": "filled"}
            if tid:
                tx = (self._call("GET", "/v3/accounts/%s/transactions/%s" % (self.acc, tid)) or {}).get("transaction") or {}
                try:
                    out.update(price=float(tx["price"]), qty=abs(float(tx["units"])))
                except (KeyError, ValueError, TypeError):
                    pass
            return out
        if st == "CANCELLED":
            # Order chỉ có `cancellingTransactionID`; LÝ DO huỷ nằm trong giao dịch OrderCancelTransaction (trường `reason`) - tra thêm một lần.
            reason = str(o.get("cancellingTransactionReason") or "")
            tid = o.get("cancellingTransactionID")
            if not reason and tid:
                try:
                    tx = (self._call("GET", "/v3/accounts/%s/transactions/%s" % (self.acc, tid)) or {}).get("transaction") or {}
                    reason = str(tx.get("reason") or "")
                except BrokerError:
                    reason = ""
            return {"state": "expired" if "EXPIRED" in reason.upper() else "canceled", "reason": reason}
        return {"state": "unknown"}

    # ---- SL/TP NATIVE: lệnh bảo vệ REDUCE_ONLY (pyea/protection.py, PROT_STYLE="ladder": hàm nguyên thuỷ sync_steps + protection_orders) ----
    # SL = lệnh STOP, TP = lệnh LIMIT, cùng `positionFill=REDUCE_ONLY` (chỉ được GIẢM vị thế hiện có - tài liệu v20: OrderPositionFill),
    # `triggerCondition=DEFAULT` (so với ask cho lệnh mua / bid cho lệnh bán: đúng phía mà lệnh đóng sẽ khớp). Units âm = bán.
    # Mã lệnh khách `clientExtensions.id` bắt đầu bằng PROT_PREFIX để nhận ra lệnh của vỏ (không đụng lệnh của người dùng).
    PROT = PROT_PREFIX
    _PROT_TYPE = {"sl": "STOP", "tp": "LIMIT"}
    PROT_LABEL = {"sl": "STOP REDUCE_ONLY", "tp": "LIMIT REDUCE_ONLY"}

    def protection_orders(self, symbol):
        """Lệnh bảo vệ của vỏ đang chờ trên sàn: [{id, kind, side, trigger, qty}] (kind suy từ loại lệnh: STOP=sl, LIMIT=tp)."""
        d = self._call("GET", "/v3/accounts/%s/pendingOrders" % self.acc)
        out = []
        for o in (d or {}).get("orders", []):
            ce = o.get("clientExtensions") or {}
            if not str(ce.get("id") or "").startswith(self.PROT) or o.get("instrument") != symbol:
                continue
            kind = "sl" if o.get("type") == "STOP" else "tp" if o.get("type") == "LIMIT" else None
            try:
                u = float(o.get("units") or 0)
                if kind is None or u == 0:
                    continue
                out.append({"id": str(o.get("id")), "kind": kind, "side": "buy" if u > 0 else "sell", "trigger": float(o.get("price") or 0),
                            "qty": abs(u)})
            except (TypeError, ValueError):
                continue
        return out

    def sync_steps(self, symbol, desired):
        """Đưa lệnh bảo vệ trên sàn về ĐÚNG `desired` (xem `sync_ladder`). Khối lượng làm tròn XUỐNG số units nguyên."""
        def qty_of(q):
            return int(math.floor(float(q) + 1e-9))

        def key_fn(d):
            return (d["kind"], str(d["side"]).lower(), self._px(symbol, d["trigger"]), qty_of(d["qty"]))

        def place_fn(d):
            units = qty_of(d["qty"])
            order = {"type": self._PROT_TYPE[d["kind"]], "instrument": symbol, "units": str(units if str(d["side"]).lower() == "buy" else -units),
                     "price": self._px(symbol, d["trigger"]), "timeInForce": "GTC", "positionFill": "REDUCE_ONLY", "triggerCondition": "DEFAULT",
                     "clientExtensions": {"id": self.PROT + d["kind"][0] + uuid.uuid4().hex[:14], "tag": "pyea-prot"}}
            r = self._call("POST", "/v3/accounts/%s/orders" % self.acc, {"order": order})
            tx = (r or {}).get("orderCreateTransaction") or {}
            if (r or {}).get("orderCancelTransaction") or (r or {}).get("orderFillTransaction") or (r or {}).get("orderRejectTransaction") or not tx.get("id"):
                why = (r or {}).get("orderRejectTransaction") or (r or {}).get("orderCancelTransaction") or (r or {}).get("orderFillTransaction") or r or {}
                raise BrokerError("OANDA không giữ lệnh bảo vệ (đã khớp/huỷ/từ chối ngay): %s" % (why.get("rejectReason") or why.get("reason") or str(why)[:160]))
            return {"id": str(tx["id"]), "kind": d["kind"], "side": str(d["side"]).lower(), "trigger": float(d["trigger"]), "qty": float(units)}

        return sync_ladder(desired, key_fn, lambda d: qty_of(d["qty"]) >= 1, lambda: self.protection_orders(symbol),
                           lambda o: self.cancel_pending(o["id"], symbol), place_fn)

    def balance(self):
        d = self._call("GET", "/v3/accounts/%s/summary" % self.acc)
        try:
            return float(d["account"]["balance"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi tài khoản OANDA không hợp lệ: %s" % str(d)[:160])

    def account_flags(self):
        """Tiền tệ của tài khoản (OANDA có thể là EUR/JPY/...): {"currency": "EUR"}. Lỗi -> {}."""
        try:
            a = (self._call("GET", "/v3/accounts/%s/summary" % self.acc) or {}).get("account") or {}
        except BrokerError:
            return {}
        cur = str(a.get("currency") or "").upper()
        return {"currency": cur} if cur else {}

    def history(self, since=0.0, symbols=None):
        """Các lần KHỚP (ORDER_FILL) từ `since`. API trả danh sách trang (pages) -> tải từng trang (tối đa 10)."""
        q = "type=ORDER_FILL&pageSize=500"
        if since:
            q += "&from=" + time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime(since))
        d = self._call("GET", "/v3/accounts/%s/transactions?%s" % (self.acc, q)) or {}
        out = []
        for url in (d.get("pages") or [])[:10]:
            u = urlsplit(url)
            page = self._call("GET", u.path + ("?" + u.query if u.query else "")) or {}
            for t in page.get("transactions", []):
                if t.get("type") != "ORDER_FILL":
                    continue
                try:
                    units = float(t.get("units") or 0)
                    out.append({"id": str(t.get("id")), "time": _oanda_ts(t.get("time")), "symbol": t.get("instrument"),
                                "side": "buy" if units > 0 else "sell", "qty": abs(units), "price": float(t.get("price") or 0),
                                "fee": float(t.get("commission") or 0), "fee_asset": "", "pnl": float(t.get("pl") or 0) + float(t.get("financing") or 0),
                                "order_id": str(t.get("orderID") or "")})
                except (ValueError, TypeError):
                    continue
        return sorted(out, key=lambda x: x["time"])

    # ---- lịch sử tài khoản đầy đủ (vào/ra theo tradeID, financing, nạp/rút) qua bộ máy chung pyea/histengine.py ----
    def history_call(self, method, path, params=None, body=None):
        if str(method).upper() != "GET":
            raise BrokerError("Lịch sử chỉ được đọc (GET)")
        if params:
            path += ("&" if "?" in path else "?") + urllib.parse.urlencode(params)
        return self._call("GET", path)

    def history_ctx(self):
        return {"account": self.acc, "symbols": [], "quote": ""}

    def account_history(self, since, until=None):
        from . import histengine
        return histengine.run_for_broker(self, "oanda", since, until)


def _oanda_ts(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        pass
    import calendar
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(\.\d+)?", str(x or ""))
    if not m:
        return 0.0
    return calendar.timegm(tuple(int(g) for g in m.groups()[:6])) + (float(m.group(7)) if m.group(7) else 0.0)


def make_broker(settings):
    """Dựng broker theo cài đặt; nạp ghi đè ánh xạ trường tay (pyea/fieldmap.py) và gắn tên sàn để chúng áp đúng sàn."""
    from . import fieldmap
    fieldmap.configure(settings)
    b = _make_broker(settings)
    try:
        b.field_scope = settings.get("exchange")
        b.history_profiles = settings.get("history_profiles")        # hồ sơ lịch sử người dùng dán (pyea/histengine.py)
    except AttributeError:                      # adapter dùng __slots__ (không có): bỏ qua, ghi đè "*" vẫn áp dụng
        pass
    return b


def _make_broker(settings):
    ex = settings.get("exchange")
    if ex == "exness":
        from .exness import make_exness_broker
        return make_exness_broker(settings)
    if ex in ("metaapi", "mt5gw", "bridge", "ctrader", "mt5ws", "dnse"):
        from .bridges import make_bridge_broker
        return make_bridge_broker(settings)
    if ex == "capital":
        from .capital import make_capital_broker
        return make_capital_broker(settings)
    if ex == "ccxt":
        from .ccxt_adapter import make_ccxt_broker
        return make_ccxt_broker(settings)
    base = resolve_base(settings)
    if ex == "oanda":
        return OandaBroker(settings.get("oanda_token", ""), settings.get("oanda_account", ""), base)
    cls = BinanceFuturesBroker if ex == "binance_futures" else BinanceBroker
    return cls(settings.get("api_key", ""), settings.get("api_secret", ""), base)
