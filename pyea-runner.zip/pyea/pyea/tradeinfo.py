"""Thông tin CHI TIẾT một lệnh (đang mở / đã đóng) + chọn khung giờ & khoảng nến để nhảy tới biểu đồ tại điểm vào/ra. Thuần Python (không Kivy) để test được.

Nguồn dữ liệu, theo thứ tự tin cậy: (1) TradeEvent trong phiên (có LÝ DO vào/ra do bot ghi), (2) sổ app (Position/Trade), (3) hàng lịch sử của SÀN
(comment/magic -> nguồn gốc). Thiếu nguồn nào thì ghi rõ «không có» chứ không bịa lý do.
"""
import time

from . import ordertag
from .feeds import TIMEFRAMES

NO_REASON = "Không có ghi chép lý do (lý do chỉ lưu trong phiên chạy; lệnh mở tay hoặc mở từ trước khi app chạy thì không có)."


def _fmt_t(t):
    return time.strftime("%d/%m/%Y %H:%M:%S", time.localtime(t)) if t else "-"


def _dur(sec):
    sec = max(0, int(sec))
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return ("%dn " % d if d else "") + ("%dg " % h if h or d else "") + "%dp" % m


def _find_events(events, pos_id):
    op = cl = None
    for e in events or []:
        if pos_id and e.pos_id == pos_id:
            if e.kind == "open" and op is None:
                op = e
            elif e.kind == "close":
                cl = e
    return op, cl


def _owner_text(owner, instances):
    if not owner or owner == "manual":
        return "Thủ công"
    inst = (instances or {}).get(owner)
    nm = None
    if inst:
        nm = inst.get("name") or inst.get("bot") or inst.get("label") if isinstance(inst, dict) else getattr(inst, "name", None)
    return "%s (%s)" % (nm, owner) if nm else str(owner)


def build(kind, obj, events=(), instances=None, now=None):
    """kind: 'position' (Position) | 'trade' (Trade) | 'row' (hàng lịch sử dict của histview). -> dict thông tin; `chart` = (symbol, t_from, t_to)."""
    now = now or time.time()
    if kind == "position":
        sym, side, vol, op_, ot, cp, ct = obj.symbol, obj.side, obj.volume, obj.open_price, obj.open_time, None, None
        profit, swap, fee, owner, ticket, comment = obj.profit, obj.swap, obj.fee, obj.owner, obj.ref or str(obj.id), obj.comment
        origin, sl, tp, pid, state = getattr(obj, "origin", "") or "", obj.sl, obj.tp, obj.id, "Đang mở"
    elif kind == "trade":
        sym, side, vol, op_, ot, cp, ct = obj.symbol, obj.side, obj.volume, obj.open_price, obj.open_time, obj.close_price, obj.close_time
        profit, swap, fee, owner, ticket, comment = obj.profit, obj.swap, obj.fee, obj.owner, str(obj.id), obj.comment
        origin, sl, tp, pid, state = "app" if owner and owner != "manual" else "", 0.0, 0.0, obj.id, "Đã đóng (%s)" % (obj.reason or "-")
    else:
        sym, side, vol, op_, ot = obj.get("symbol", ""), obj.get("side", ""), obj.get("volume", 0.0), obj.get("price", 0.0), obj.get("open_time") or obj.get("time")
        cp, ct = obj.get("price2"), (obj.get("time") if obj.get("price2") else None)
        profit, swap, fee, owner, ticket = obj.get("profit", 0.0), obj.get("swap", 0.0), obj.get("commission", 0.0), "", str(obj.get("id", ""))
        comment, origin, sl, tp, pid, state = str(obj.get("owner", "")), "", 0.0, 0.0, 0, "Đã đóng"
        origin = ordertag.classify(comment, int(obj.get("magic") or 0)) if (comment or obj.get("magic")) else ""
    tag = ordertag.decode(comment)
    if not owner and tag["app"] and tag["code"]:
        owner = ordertag.match_owner(tag["code"], list(instances or {})) or ""
    if not origin:
        origin = ordertag.classify(comment, 0) if comment else ("app" if owner and owner != "manual" else "")
    op_ev, cl_ev = _find_events(events, pid if kind != "row" else 0)
    rows = [("Trạng thái", state), ("Nguồn gốc", ordertag.origin_name(origin) if origin else "Không rõ (sàn không trả comment/magic)"),
            ("Bot / chủ lệnh", _owner_text(owner, instances) if owner else ("Mã bot trong nhãn: %s" % tag["code"] if tag["code"] else "-")),
            ("Logic (nhãn)", tag["label"] or "-"), ("Mã lệnh (ticket)", ticket or "-"), ("Mã / chiều / KL", "%s · %s · %g" % (sym, str(side).upper(), vol)),
            ("Vào", "%s @ %s" % (_fmt_t(ot), op_))]
    if ct:
        rows.append(("Ra", "%s @ %s" % (_fmt_t(ct), cp)))
        rows.append(("Thời gian giữ", _dur(ct - (ot or ct))))
    if sl or tp:
        rows.append(("SL / TP hiện tại", "%s / %s" % (sl or "-", tp or "-")))
    rows.append(("Lãi/lỗ", "%+.4f" % profit))
    if swap or fee:
        rows.append(("Swap / phí", "%+.4f / %+.4f" % (swap, fee)))
    if comment:
        rows.append(("Comment sàn", comment))
    entry_logic = (op_ev.reason if op_ev and op_ev.reason else "") or NO_REASON
    exit_logic = (cl_ev.reason if cl_ev and cl_ev.reason else "") if ct else ""
    t0 = ot or now
    t1 = ct or now
    return {"title": "%s %s %s" % (str(side).upper(), sym, ticket), "symbol": sym, "side": side, "rows": rows, "entry_logic": entry_logic,
            "exit_logic": exit_logic, "open_event": op_ev, "close_event": cl_ev, "entry": (t0, op_), "exit": ((ct, cp) if ct else None),
            "sl": sl, "tp": tp, "origin": origin, "owner": owner, "closed": bool(ct), "span": (t0, t1)}


def pick_tf(t_from, t_to, want=90, tfs=None):
    """Khung nhỏ nhất sao cho khoảng [vào, ra] (+đệm 25% mỗi bên) chứa ≤ `want` nến - lệnh scalp thấy nến phút, lệnh swing thấy nến giờ/ngày."""
    span = max(60.0, float(t_to) - float(t_from)) * 1.5
    for name, sec in (tfs or TIMEFRAMES).items():
        if name == "1mo":
            continue
        if span / sec <= want:
            return name, sec
    return "1w", TIMEFRAMES["1w"]


def window(t_from, t_to, step, pad_bars=25):
    """(đầu, cuối) thời gian cần tải: đệm `pad_bars` nến mỗi bên quanh [vào, ra]."""
    return float(t_from) - pad_bars * step, float(t_to) + pad_bars * step


def bars_needed(t_from, t_to, step, pad_bars=25):
    a, b = window(t_from, t_to, step, pad_bars)
    return int((b - a) / step) + 2


def marker_events(info):
    """TradeEvent giả (để CandleChart vẽ chấm vào/ra + đường nối) khi không có TradeEvent thật (lệnh cũ/lịch sử sàn)."""
    from .sdk import TradeEvent
    evs = []
    t0, p0 = info["entry"]
    if info["open_event"] is not None:
        evs.append(info["open_event"])
    else:
        evs.append(TradeEvent(id=-1, kind="open", time=t0, price=p0, side=info["side"], pos_id=-1, reason=info["entry_logic"], symbol=info["symbol"]))
    if info["exit"]:
        if info["close_event"] is not None:
            evs.append(info["close_event"])
        else:
            t1, p1 = info["exit"]
            pr = 0.0
            evs.append(TradeEvent(id=-2, kind="close", time=t1, price=p1, side=info["side"], pos_id=-1, reason=info["exit_logic"] or "Thoát lệnh", symbol=info["symbol"], profit=pr))
    return evs
