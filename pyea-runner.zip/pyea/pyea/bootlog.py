"""NHẬT KÝ KHỞI ĐỘNG - để biết app chết Ở ĐÂU khi nó văng ra ngoài mà không kịp hiện lỗi (crash gốc/native, lỗi lúc import...).

Ghi từng «mốc» (crumb) vào boot.log trong thư mục riêng của app trên bộ nhớ ngoài (Android/data/<gói>/files/boot.log - lấy được bằng trình quản lý file/USB,
không cần quyền), rơi về thư mục dữ liệu nội bộ. Bật `faulthandler` vào cùng file: crash native (SIGSEGV...) in ra ngăn xếp Python lúc chết.
Không phụ thuộc Kivy; mọi hàm KHÔNG BAO GIỜ ném lỗi (ghi nhật ký không được làm hỏng app)."""
import os
import sys
import time

MAX_BYTES = 200000
PACKAGE = "org.pyea.pyearunner"
_path = None
_fh = None


def _candidates():
    try:
        from jnius import autoclass
        d = autoclass("org.kivy.android.PythonActivity").mActivity.getExternalFilesDir(None)
        if d is not None:
            yield str(d.getAbsolutePath())
    except Exception:                                        # noqa: BLE001
        pass
    yield os.path.join("/storage/emulated/0/Android/data", PACKAGE, "files")
    yield os.environ.get("ANDROID_PRIVATE") or os.getcwd()
    yield os.getcwd()


def path():
    """Đường dẫn boot.log (tạo thư mục nếu cần); None nếu không ghi được."""
    global _path
    if _path:
        return _path
    for d in _candidates():
        try:
            os.makedirs(d, exist_ok=True)
            p = os.path.join(d, "boot.log")
            if os.path.exists(p) and os.path.getsize(p) > MAX_BYTES:
                with open(p, "rb") as f:
                    f.seek(-MAX_BYTES // 2, 2)
                    tail = f.read()
                with open(p, "wb") as f:
                    f.write(tail)
            with open(p, "a", encoding="utf-8") as f:
                f.write("")
            _path = p
            return p
        except Exception:                                    # noqa: BLE001
            continue
    return None


def crumb(msg):
    try:
        p = path()
        if p:
            with open(p, "a", encoding="utf-8") as f:
                f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:                                        # noqa: BLE001
        pass


def enable_faulthandler():
    """Crash native -> ngăn xếp Python vào boot.log."""
    global _fh
    try:
        import faulthandler
        p = path()
        if p and _fh is None:
            _fh = open(p, "a", encoding="utf-8", buffering=1)
            faulthandler.enable(file=_fh, all_threads=True)
            return True
    except Exception:                                        # noqa: BLE001
        pass
    return False


def install_excepthook():
    old = sys.excepthook

    def hook(et, ev, tb):
        try:
            import traceback
            crumb("UNCAUGHT %s" % "".join(traceback.format_exception(et, ev, tb))[-3000:])
        except Exception:                                    # noqa: BLE001
            pass
        old(et, ev, tb)
    sys.excepthook = hook


RUN_MARK = "=== main.py bắt đầu"
DONE_MARK = "build: xong"
REPORTED_MARK = "=== đã báo cho người dùng ==="


def previous_unfinished():
    """Lần chạy TRƯỚC có chết giữa chừng không (chưa dựng xong giao diện, hoặc có lỗi)? Trả văn bản các mốc của lần đó (đuôi 4000 ký tự) hoặc None.
    Gọi TRƯỚC khi ghi mốc của lần chạy hiện tại. Lần đã báo cho người dùng rồi thì không báo lại."""
    try:
        p = path()
        if not p:
            return None
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            txt = f.read()
        i = txt.rfind(RUN_MARK)
        if i < 0:
            return None
        last = txt[i:]
        if REPORTED_MARK in last:
            return None
        if DONE_MARK in last and "LỖI" not in last and "UNCAUGHT" not in last:
            return None
        return last[-4000:]
    except Exception:                                        # noqa: BLE001
        return None


def mark_reported():
    crumb(REPORTED_MARK)
