"""
Đồng bộ LỊCH SỬ GIAO DỊCH + SỐ DƯ từ sàn (chỉ live, sàn nào có hàm history()/balance()):

  - history(since, symbols) -> các lần khớp THẬT trên sàn: lưu tăng dần vào `exchange_history.jsonl` (khử trùng theo id,
    nhớ mốc thời gian để lần sau chỉ hỏi phần mới, kể cả sau khi khởi động lại). Đây là nguồn sự thật để đối chiếu phí,
    funding, trượt giá, và các lệnh bạn bấm tay trên app của sàn.
  - balance() -> so với số dư sổ app. Lệch quá ngưỡng thì: alert (mặc định, báo động 1 lần cho mỗi mức lệch) |
    adopt (sổ app đổi theo sàn) | off.

Cài đặt: sync_interval (giây, 0 = tắt; mặc định 300) · balance_sync_policy · balance_drift_pct (mặc định 1%) ·
sync_lookback_days (lần đầu lấy lịch sử mấy ngày; mặc định 7).
"""
import json
import os
import time

from .broker import BrokerError
from .feeds import FeedError


class ExchangeSyncMixin:
    def _sync_init(self):
        self.exch = {"supported": False, "last": 0.0, "ok": None, "balance_remote": None, "balance_local": None, "drift": 0.0,
                     "drift_pct": 0.0, "new_trades": 0, "total_trades": 0, "pnl_exchange": 0.0, "pnl_local": 0.0, "error": "",
                     "policy": "alert", "history_error": ""}
        self._sync_next = 0.0
        self._sync_since = 0.0
        self._sync_ids = set()
        self._sync_alerted = None
        self._sync_warn_t = 0.0
        self._sync_started = time.time()
        self._sync_load()

    # ---- lưu bền ----
    def _sync_path(self):
        sf = getattr(self, "state_file", None)
        return os.path.join(os.path.dirname(os.path.abspath(sf)), "exchange_history.jsonl") if sf else None

    def _sync_load(self):
        p = self._sync_path()
        if not p or not os.path.exists(p):
            return
        try:
            with open(p, "r", encoding="utf-8") as f:
                lines = f.readlines()[-20000:]
            for ln in lines:
                try:
                    t = json.loads(ln)
                except ValueError:
                    continue
                self._sync_ids.add(str(t.get("id")))
                self._sync_since = max(self._sync_since, float(t.get("time", 0)))
            self.exch["total_trades"] = len(self._sync_ids)
        except OSError:
            pass

    def exchange_trades(self, limit=200):
        """Lịch sử khớp lệnh của sàn đã đồng bộ (mới nhất trước) - để hiển thị/xuất."""
        p = self._sync_path()
        out = []
        if p and os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    for ln in f.readlines()[-max(1, int(limit)):]:
                        try:
                            out.append(json.loads(ln))
                        except ValueError:
                            pass
            except OSError:
                pass
        return out[::-1]

    # ---- chạy ----
    def _check_exchange_sync(self):
        iv = float(self.settings.get("sync_interval", 300) or 0)
        b = self.broker
        if b is None or iv <= 0 or not (hasattr(b, "history") or hasattr(b, "balance")):
            return
        if time.time() < self._sync_next:
            return
        self._sync_next = time.time() + iv
        try:
            self.sync_exchange(force=True)
        except Exception as e:                                  # đồng bộ lỗi không được làm sập phiên
            self.log("Đồng bộ sàn lỗi: %s" % e, "WARN")

    def sync_exchange(self, force=False):
        """Một lượt đồng bộ. Trả về dict trạng thái (self.exch)."""
        b = self.broker
        if b is None:
            return dict(self.exch)
        if not force and time.time() < self._sync_next:
            return dict(self.exch)
        ex = self.exch
        ex["supported"] = True
        ex["policy"] = self.settings.get("balance_sync_policy", "alert")
        errs = []
        if hasattr(b, "balance") and ex["policy"] != "off":
            try:
                self._sync_balance(b)
            except (BrokerError, FeedError, NotImplementedError) as e:
                errs.append("số dư: %s" % e)
        if hasattr(b, "history"):
            try:
                self._sync_history(b)
                ex["history_error"] = ""
            except NotImplementedError:
                ex["history_error"] = ""
            except (BrokerError, FeedError) as e:
                ex["history_error"] = str(e)
                errs.append("lịch sử: %s" % e)
        ex["error"] = "; ".join(errs)
        ex["last"] = time.time()
        if errs and time.time() - self._sync_warn_t > 300:
            self._sync_warn_t = time.time()
            self.log("Đồng bộ với sàn: %s" % ex["error"], "WARN")
        return dict(ex)

    def _sync_balance(self, b):
        rb = float(b.balance())
        with self.lock:
            lb = float(self.account.balance)
        drift = rb - lb
        pct = abs(drift) / max(abs(lb), 1e-9) * 100.0
        thr = float(self.settings.get("balance_drift_pct", 1.0) or 0.0)
        bad = thr > 0 and pct > thr and abs(drift) > 1e-6
        ex = self.exch
        ex.update(balance_remote=rb, balance_local=lb, drift=drift, drift_pct=pct, ok=not bad)
        if not bad:
            self._sync_alerted = None
            return
        key = round(drift, 2)
        policy = ex["policy"]
        if key != self._sync_alerted:
            self._sync_alerted = key
            self.log("SỐ DƯ LỆCH: sàn %.4f · sổ app %.4f (lệch %+.4f = %.2f%%)%s" % (
                rb, lb, drift, pct, " -> sổ app sẽ đổi theo sàn" if policy == "adopt" else ""), "WARN")
            self.alarm("Số dư lệch với sàn", "Sàn %.4f · sổ app %.4f (lệch %+.4f, %.2f%%). Có thể do phí/funding, nạp/rút, hoặc lệnh ngoài app." % (rb, lb, drift, pct), critical=False)
        if policy == "adopt":
            with self.lock:
                self.account.balance = rb
            self._save_state()

    def _sync_history(self, b):
        since = self._sync_since - 120 if self._sync_since else time.time() - float(self.settings.get("sync_lookback_days", 7) or 7) * 86400
        with self.lock:
            syms = set(self._local_net()) | set(getattr(self, "watch", []) or [])
        try:
            syms |= set(self.needed_symbols())
        except Exception:                                        # noqa: BLE001
            pass
        if hasattr(b, "set_watch"):
            b.set_watch(syms)
        rows = b.history(since, sorted(syms))
        new = [t for t in rows if str(t.get("id")) not in self._sync_ids]
        p = self._sync_path()
        if new and p:
            try:
                with open(p, "a", encoding="utf-8") as f:
                    for t in new:
                        f.write(json.dumps(t, ensure_ascii=False) + "\n")
            except OSError as e:
                self.log("Không ghi được lịch sử sàn: %s" % e, "WARN")
        for t in new:
            self._sync_ids.add(str(t.get("id")))
            self._sync_since = max(self._sync_since, float(t.get("time", 0)))
        ex = self.exch
        ex["new_trades"] = len(new)
        ex["total_trades"] = len(self._sync_ids)
        with self.lock:
            ex["pnl_local"] = sum(t.profit for t in self.account.trades if t.close_time >= self._sync_started - 1)
        ex["pnl_exchange"] = ex.get("pnl_exchange", 0.0) + sum(float(t.get("pnl", 0.0)) for t in new if float(t.get("time", 0)) >= self._sync_started - 1)
        if new:
            self.log("Đồng bộ lịch sử sàn: +%d lần khớp mới (tổng %d)" % (len(new), len(self._sync_ids)))
