"""
HỒ SƠ LỊCH SỬ CÓ SẴN (chỉ là DỮ LIỆU cho pyea/histengine.py - không có logic riêng cho sàn nào).

Muốn sửa cách đọc lịch sử của một sàn (sàn đổi tên trường, thêm loại phí...) hoặc thêm sàn mới: dán hồ sơ cùng dạng ở Cài đặt → «Hồ sơ lịch sử sàn»
(JSON `{"tên_sàn": {...}}`); hồ sơ bạn dán thắng hồ sơ có sẵn. Định dạng đầy đủ: docstring đầu pyea/histengine.py.

Quy ước dấu: profit/commission/swap/fee của deal là ẢNH HƯỞNG LÊN SỐ DƯ (phí là số ÂM).
TẤT CẢ các hồ sơ này viết theo tài liệu công khai và chỉ được kiểm bằng sàn GIẢ - CHƯA chạy trên sàn thật (xem HANDOFF 5j).
"""

OANDA = {
    "name": "OANDA v20",
    "notes": [
        "OANDA ghi lãi/lỗ theo từng giao dịch (trade) bị đóng: mỗi lần khớp được tách thành deal VÀO/RA theo tradeID nên «vị thế đã đóng» đúng từng giao dịch như MT5.",
        "Phí qua đêm = tiền tài trợ (financing): khoản trừ hằng ngày (DAILY_FINANCING) + phần tính lúc đóng. Phí trung gian = hoa hồng (commission) + phí khớp bảo đảm. Spread không phải khoản thu riêng nên không có dòng nào.",
        "Nạp/rút lấy từ TRANSFER_FUNDS; điều chỉnh cổ tức (DIVIDEND_ADJUSTMENT) tính vào «khác». Khối lượng là units (không phải lot). Số tiền theo tiền tệ tài khoản.",
    ],
    "sources": [{
        "id": "transactions",
        "path": "/v3/accounts/{account}/transactions",
        "params": {"from": "{since:iso9}", "to": "{until_now:iso9}", "pageSize": 500,
                   "type": "ORDER_FILL,DAILY_FINANCING,TRANSFER_FUNDS,DIVIDEND_ADJUSTMENT"},
        "paging": {"type": "page_urls", "urls": "pages", "max": 50},
        "records": "transactions",
        "emit": [
            {"when": {"field": "type", "eq": "ORDER_FILL"}, "each": "tradeOpened", "kind": "trade", "entry": "IN",
             "map": {"id": {"path": "^id", "suffix": ":o"}, "time": "^time", "symbol": "^instrument",
                     "side": {"path": "^units", "sign": ["buy", "sell"]}, "qty": {"path": "units", "abs": True}, "price": ["price", "^price"],
                     "position_id": "tradeID", "order_id": "^orderID",
                     "commission": {"path": "^commission", "neg": True, "once": True},
                     "fee": {"path": "^guaranteedExecutionFee", "neg": True, "once": True}}},
            {"when": {"field": "type", "eq": "ORDER_FILL"}, "each": "tradesClosed", "kind": "trade", "entry": "OUT",
             "map": {"id": {"path": "^id", "suffix": ":c{i}"}, "time": "^time", "symbol": "^instrument",
                     "side": {"path": "^units", "sign": ["buy", "sell"]}, "qty": {"path": "units", "abs": True}, "price": ["price", "^price"],
                     "position_id": "tradeID", "order_id": "^orderID", "profit": "realizedPL", "swap": "financing",
                     "commission": {"path": "^commission", "neg": True, "once": True},
                     "fee": {"path": "^guaranteedExecutionFee", "neg": True, "once": True}}},
            {"when": {"field": "type", "eq": "ORDER_FILL"}, "each": "tradeReduced", "kind": "trade", "entry": "OUT",
             "map": {"id": {"path": "^id", "suffix": ":r"}, "time": "^time", "symbol": "^instrument",
                     "side": {"path": "^units", "sign": ["buy", "sell"]}, "qty": {"path": "units", "abs": True}, "price": ["price", "^price"],
                     "position_id": "tradeID", "order_id": "^orderID", "profit": "realizedPL", "swap": "financing",
                     "commission": {"path": "^commission", "neg": True, "once": True},
                     "fee": {"path": "^guaranteedExecutionFee", "neg": True, "once": True}}},
            {"when": {"field": "type", "eq": "ORDER_FILL"}, "fallback": True, "kind": "trade", "entry": "",
             "map": {"id": "id", "time": "time", "symbol": "instrument", "side": {"path": "units", "sign": ["buy", "sell"]},
                     "qty": {"path": "units", "abs": True}, "price": "price", "order_id": "orderID", "profit": "pl", "swap": "financing",
                     "commission": {"path": "commission", "neg": True}}},
            {"when": {"field": "type", "eq": "DAILY_FINANCING"}, "kind": "other",
             "map": {"id": "id", "time": "time", "swap": "financing", "comment": {"const": "Phí qua đêm hằng ngày"}}},
            {"when": {"field": "type", "eq": "TRANSFER_FUNDS"}, "kind": "balance",
             "map": {"id": "id", "time": "time", "profit": "amount", "comment": "fundingReason"}},
            {"when": {"field": "type", "eq": "DIVIDEND_ADJUSTMENT"}, "kind": "other",
             "map": {"id": "id", "time": "time", "symbol": "instrument", "profit": "dividendAdjustment", "comment": {"const": "Điều chỉnh cổ tức"}}},
        ],
    }],
}

_BN_BALANCE = ["TRANSFER", "INTERNAL_TRANSFER", "COIN_SWAP_DEPOSIT", "COIN_SWAP_WITHDRAW"]
_BN_REBATE = ["COMMISSION_REBATE", "API_REBATE", "REFERRAL_KICKBACK"]
_BN_CREDIT = ["WELCOME_BONUS", "CONTEST_REWARD"]
_BN_COVERED = ["REALIZED_PNL", "COMMISSION", "FUNDING_FEE"] + _BN_BALANCE + _BN_REBATE + _BN_CREDIT
_BN_INC = {"id": ["tranId", "tradeId"], "time": "time", "symbol": "symbol", "comment": "incomeType"}

BINANCE_FUTURES = {
    "name": "Binance USDⓈ-M Futures",
    "netting": {"key": ["symbol", "group"]},
    "notes": [
        "Binance Futures không có «phí qua đêm» kiểu MT5: tiền tài trợ (funding, FUNDING_FEE) được tính vào mục Phí qua đêm.",
        "Sàn KHÔNG báo mã vị thế: app dựng lại từ các lần khớp theo từng mã (số lượng ròng về 0 là đóng một vị thế). Vị thế mở trước kỳ có giá mở «?».",
        "Lợi nhuận = realizedPnl của các lần khớp (chưa trừ phí). Phí trả bằng đồng khác USDT (vd BNB) KHÔNG được cộng vì chưa quy đổi.",
        "Sàn hỏi lịch sử khớp theo từng mã: app đọc các mã có phát sinh trong kỳ (lấy từ sổ thu chi) và các mã trong Danh sách theo dõi; mã khác có thể thiếu. Mỗi lần hỏi tối đa 7 ngày, sàn chỉ giữ khoảng 3 tháng.",
    ],
    "sources": [
        {"id": "income", "path": "/fapi/v1/income", "params": {}, "required": False, "discover_symbols": "symbol",
         "note_fail": "kiểm tra khoá API có quyền đọc (Enable Reading) - không có sổ thu chi thì thiếu nạp/rút, funding và không tự biết mã nào có giao dịch",
         "paging": {"type": "window", "days": 7, "start": "startTime", "end": "endTime", "unit": "ms", "limit": 1000, "limit_param": "limit", "time": "time"},
         "records": "",
         "emit": [
             {"when": {"field": "incomeType", "eq": "FUNDING_FEE"}, "kind": "other",
              "map": dict(_BN_INC, swap="income")},
             {"when": {"field": "incomeType", "in": _BN_BALANCE}, "kind": "balance",
              "map": dict(_BN_INC, profit="income")},
             {"when": {"field": "incomeType", "in": _BN_REBATE}, "kind": "other",
              "map": dict(_BN_INC, commission="income")},
             {"when": {"field": "incomeType", "in": _BN_CREDIT}, "kind": "credit",
              "map": dict(_BN_INC, profit="income")},
             {"when": {"field": "incomeType", "nin": _BN_COVERED}, "kind": "other",
              "map": dict(_BN_INC, profit="income")},
         ]},
        {"id": "fills", "path": "/fapi/v1/userTrades", "params": {"symbol": "{symbol}"}, "per_symbol": {"var": "symbol", "from": ["discovered", "watch"], "max": 40},
         "paging": {"type": "window", "days": 7, "start": "startTime", "end": "endTime", "unit": "ms", "limit": 1000, "limit_param": "limit", "time": "time"},
         "records": "",
         "emit": [
             {"kind": "trade", "entry": {"out_if": {"field": "realizedPnl", "ne": 0}, "else": "IN"},
              "map": {"id": "id", "time": "time", "symbol": "symbol", "side": {"path": "side", "lower": True},
                      "qty": "qty", "price": "price", "order_id": "orderId", "profit": "realizedPnl", "group": "positionSide",
                      "commission": {"path": "commission", "neg": True, "only_if": {"field": "commissionAsset", "eq": "{quote}"}}}},
         ]},
    ],
}

CCXT = {
    "name": "ccxt (chuẩn hoá)",
    "notes": [
        "ccxt chỉ chuẩn hoá phần chung của các sàn: lãi/lỗ đã thực hiện CHỈ có khi sàn báo trong trường thô (info.realizedPnl / closedPnl / pnl). Không có thì Lợi nhuận = 0 và danh sách vị thế đã đóng trống - app KHÔNG tự bịa lãi/lỗ.",
        "Phí giao dịch chỉ cộng khi tính bằng đồng quote (thường USDT). Nạp/rút lấy từ fetchDeposits/fetchWithdrawals (chỉ giao dịch đã hoàn tất, chỉ đồng quote). Funding (nếu sàn có) tính vào Phí qua đêm.",
        "Mỗi sàn ccxt giới hạn khác nhau (số mã, tuổi dữ liệu); sàn không hỗ trợ một nguồn thì nguồn đó được bỏ qua kèm ghi chú.",
    ],
    "sources": [
        {"id": "fills", "method": "CCXT", "path": "fetch_my_trades", "params": {"symbol": "{symbol}", "since": "{since:ms}", "limit": 1000},
         "per_symbol": {"var": "symbol", "from": ["watch"], "max": 40}, "paging": {"type": "none"}, "records": "", "needs": "fetchMyTrades",
         "emit": [
             {"kind": "trade",
              "entry": {"out_if": {"field": ["info.realizedPnl", "info.closedPnl", "info.realisedPnl", "info.pnl"], "ne": 0}, "else": ""},
              "map": {"id": "id", "time": "timestamp", "symbol": "symbol", "side": {"path": "side", "lower": True}, "qty": "amount", "price": "price",
                      "order_id": "order", "profit": ["info.realizedPnl", "info.closedPnl", "info.realisedPnl", "info.pnl"],
                      "commission": {"path": "fee.cost", "neg": True, "only_if": {"field": "fee.currency", "eq": "{quote}"}}}},
         ]},
        {"id": "funding", "method": "CCXT", "path": "fetch_funding_history", "params": {"symbol": "{symbol}", "since": "{since:ms}", "limit": 1000}, "required": False,
         "per_symbol": {"var": "symbol", "from": ["watch"], "max": 40}, "paging": {"type": "none"}, "records": "", "needs": "fetchFundingHistory",
         "emit": [{"kind": "other", "map": {"id": "id", "time": "timestamp", "symbol": "symbol", "swap": "amount", "comment": {"const": "Funding"}}}]},
        {"id": "deposits", "method": "CCXT", "path": "fetch_deposits", "params": {"code": "{quote}", "since": "{since:ms}", "limit": 1000}, "required": False,
         "paging": {"type": "none"}, "records": "", "needs": "fetchDeposits",
         "emit": [{"when": [{"field": "status", "eq": "ok"}, {"field": "currency", "eq": "{quote}"}], "kind": "balance",
                   "map": {"id": "id", "time": "timestamp", "profit": {"path": "amount", "abs": True}, "comment": {"const": "Nạp tiền"}}}]},
        {"id": "withdrawals", "method": "CCXT", "path": "fetch_withdrawals", "params": {"code": "{quote}", "since": "{since:ms}", "limit": 1000}, "required": False,
         "paging": {"type": "none"}, "records": "", "needs": "fetchWithdrawals",
         "emit": [{"when": [{"field": "status", "eq": "ok"}, {"field": "currency", "eq": "{quote}"}], "kind": "balance",
                   "map": {"id": "id", "time": "timestamp", "profit": {"path": "amount", "abs": True, "neg": True}, "comment": {"const": "Rút tiền"},
                           "commission": {"path": "fee.cost", "neg": True}}}]},
    ],
}

BUILTIN = {"oanda": OANDA, "binance_futures": BINANCE_FUTURES, "ccxt": CCXT}
