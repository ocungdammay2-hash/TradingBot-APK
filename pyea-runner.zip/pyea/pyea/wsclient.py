"""
WebSocket client tối giản (RFC 6455) chỉ dùng thư viện chuẩn - không kéo thêm phụ thuộc vào bản dựng Android.

  ws = WebSocketClient("wss://host/path", headers={...}, subprotocols=["exness-ws-protocol"])
  ws.connect(); ws.send_text('{"a":1}'); msg = ws.recv(timeout=5)  # str | None (hết giờ) ; ném WsClosed khi đóng
Tự trả lời ping, ghép tin nhắn bị phân mảnh, che (mask) khung gửi đi theo đúng chuẩn.
"""
import base64
import hashlib
import os
import socket
import ssl
import struct
import time
from urllib.parse import urlsplit

_GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class WsError(Exception):
    def __init__(self, msg, status=0):
        Exception.__init__(self, msg)
        self.status = status


class WsClosed(WsError):
    pass


def accept_key(key):
    k = key.encode() if isinstance(key, str) else key
    return base64.b64encode(hashlib.sha1(k + _GUID).digest()).decode()


def encode_frame(opcode, payload=b"", mask=True, fin=True):
    """Dựng một khung WebSocket (dùng cả cho client và cho máy chủ giả trong test)."""
    if isinstance(payload, str):
        payload = payload.encode("utf-8")
    head = bytearray([(0x80 if fin else 0) | opcode])
    n = len(payload)
    m = 0x80 if mask else 0
    if n < 126:
        head.append(m | n)
    elif n < 65536:
        head.append(m | 126)
        head += struct.pack(">H", n)
    else:
        head.append(m | 127)
        head += struct.pack(">Q", n)
    if mask:
        key = os.urandom(4)
        head += key
        payload = bytes(b ^ key[i % 4] for i, b in enumerate(payload))
    return bytes(head) + payload


def parse_frame(buf):
    """Thử đọc một khung từ đầu bộ đệm. Trả (fin, opcode, payload, số byte đã dùng) hoặc None nếu chưa đủ dữ liệu."""
    if len(buf) < 2:
        return None
    b0, b1 = buf[0], buf[1]
    fin, opcode, masked, n = bool(b0 & 0x80), b0 & 0x0F, bool(b1 & 0x80), b1 & 0x7F
    pos = 2
    if n == 126:
        if len(buf) < pos + 2:
            return None
        n = struct.unpack(">H", bytes(buf[pos:pos + 2]))[0]
        pos += 2
    elif n == 127:
        if len(buf) < pos + 8:
            return None
        n = struct.unpack(">Q", bytes(buf[pos:pos + 8]))[0]
        pos += 8
    key = b""
    if masked:
        if len(buf) < pos + 4:
            return None
        key = bytes(buf[pos:pos + 4])
        pos += 4
    if len(buf) < pos + n:
        return None
    payload = bytes(buf[pos:pos + n])
    if masked:
        payload = bytes(b ^ key[i % 4] for i, b in enumerate(payload))
    return fin, opcode, payload, pos + n


class WebSocketClient:
    MAX_MESSAGE = 8 * 1024 * 1024

    def __init__(self, url, headers=None, subprotocols=None, timeout=10.0, ssl_ctx=None):
        self.url = url
        self.headers = dict(headers or {})
        self.subprotocols = list(subprotocols or [])
        self.timeout = timeout
        self.ssl_ctx = ssl_ctx
        self.sock = None
        self._buf = bytearray()
        self._frag = None
        self.closed = True
        self.subprotocol = ""

    # ---- kết nối ----
    def connect(self):
        u = urlsplit(self.url)
        if u.scheme not in ("ws", "wss"):
            raise WsError("URL WebSocket phải bắt đầu bằng ws:// hoặc wss:// (nhận '%s')" % self.url)
        host, tls = u.hostname, u.scheme == "wss"
        port = u.port or (443 if tls else 80)
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        try:
            raw = socket.create_connection((host, port), timeout=self.timeout)
            if tls:
                ctx = self.ssl_ctx
                if ctx is None:
                    from .feeds import ssl_context
                    ctx = ssl_context()
                raw = ctx.wrap_socket(raw, server_hostname=host)
        except (OSError, ssl.SSLError) as e:
            raise WsError("Không kết nối được WebSocket %s:%s (%s)" % (host, port, e))
        self.sock = raw
        key = base64.b64encode(os.urandom(16)).decode()
        lines = ["GET %s HTTP/1.1" % path, "Host: %s" % (host if not u.port else "%s:%d" % (host, port)),
                 "Upgrade: websocket", "Connection: Upgrade", "Sec-WebSocket-Key: %s" % key, "Sec-WebSocket-Version: 13"]
        if self.subprotocols:
            lines.append("Sec-WebSocket-Protocol: %s" % ", ".join(self.subprotocols))
        for k, v in self.headers.items():
            lines.append("%s: %s" % (k, v))
        try:
            self.sock.sendall(("\r\n".join(lines) + "\r\n\r\n").encode("utf-8"))
            head = self._read_http_head()
        except (OSError, ssl.SSLError) as e:
            self.close()
            raise WsError("Lỗi bắt tay WebSocket: %s" % e)
        status_line, _, rest = head.partition("\r\n")
        try:
            status = int(status_line.split()[1])
        except (IndexError, ValueError):
            self.close()
            raise WsError("Phản hồi bắt tay không hợp lệ: %r" % status_line[:80])
        hdrs = {}
        for ln in rest.split("\r\n"):
            if ":" in ln:
                k, v = ln.split(":", 1)
                hdrs[k.strip().lower()] = v.strip()
        if status != 101:
            body = self._buf.decode("utf-8", "ignore")[:200]
            self.close()
            raise WsError("Máy chủ từ chối WebSocket: HTTP %d %s" % (status, body), status)
        if hdrs.get("sec-websocket-accept") != accept_key(key):
            self.close()
            raise WsError("Sec-WebSocket-Accept sai - không phải máy chủ WebSocket hợp lệ")
        self.subprotocol = hdrs.get("sec-websocket-protocol", "")
        self.closed = False
        return self

    def _read_http_head(self):
        data = bytearray()
        self.sock.settimeout(self.timeout)
        while b"\r\n\r\n" not in data:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise WsError("Máy chủ đóng kết nối khi bắt tay")
            data += chunk
            if len(data) > 65536:
                raise WsError("Phản hồi bắt tay quá dài")
        head, _, rest = bytes(data).partition(b"\r\n\r\n")
        self._buf = bytearray(rest)                     # dữ liệu khung có thể đã tới cùng gói
        return head.decode("utf-8", "ignore")

    # ---- gửi ----
    def _send_frame(self, opcode, payload=b""):
        if self.closed or not self.sock:
            raise WsClosed("WebSocket đã đóng")
        try:
            self.sock.sendall(encode_frame(opcode, payload, mask=True))
        except (OSError, ssl.SSLError) as e:
            self.closed = True
            raise WsClosed("Gửi thất bại: %s" % e)

    def send_text(self, text):
        self._send_frame(0x1, text)

    def ping(self, data=b""):
        self._send_frame(0x9, data)

    # ---- nhận ----
    def recv(self, timeout=None):
        """Trả chuỗi (tin nhắn text) | None nếu hết giờ. Ném WsClosed khi máy chủ đóng."""
        deadline = time.monotonic() + (self.timeout if timeout is None else timeout)
        while True:
            fr = parse_frame(self._buf)
            if fr is not None:
                fin, op, payload, used = fr
                del self._buf[:used]
                msg = self._handle(fin, op, payload)
                if msg is not None:
                    return msg
                continue
            left = deadline - time.monotonic()
            if left <= 0:
                return None
            try:
                self.sock.settimeout(max(0.01, left))
                chunk = self.sock.recv(65536)
            except socket.timeout:
                return None
            except ssl.SSLError as e:
                if "timed out" in str(e):
                    return None
                self.closed = True
                raise WsClosed("Lỗi TLS: %s" % e)
            except OSError as e:
                self.closed = True
                raise WsClosed("Mất kết nối: %s" % e)
            if not chunk:
                self.closed = True
                raise WsClosed("Máy chủ đã đóng kết nối")
            self._buf += chunk

    def _handle(self, fin, op, payload):
        if op == 0x9:                                   # ping -> pong
            try:
                self._send_frame(0xA, payload)
            except WsClosed:
                pass
            return None
        if op == 0xA:
            return None
        if op == 0x8:
            try:
                self._send_frame(0x8, payload[:2])
            except WsClosed:
                pass
            self.closed = True
            raise WsClosed("Máy chủ gửi khung đóng")
        if op in (0x1, 0x2):
            if fin:
                return payload.decode("utf-8", "replace")
            self._frag = bytearray(payload)
            return None
        if op == 0x0 and self._frag is not None:        # khung tiếp nối
            self._frag += payload
            if len(self._frag) > self.MAX_MESSAGE:
                self.close()
                raise WsError("Tin nhắn WebSocket quá lớn")
            if fin:
                m, self._frag = bytes(self._frag), None
                return m.decode("utf-8", "replace")
        return None

    def close(self):
        if self.sock:
            try:
                if not self.closed:
                    self.sock.sendall(encode_frame(0x8, struct.pack(">H", 1000), mask=True))
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
        self.closed = True
        self.sock = None
