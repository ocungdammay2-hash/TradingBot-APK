"""ĐẶT LỆNH NGAY TRÊN BIỂU ĐỒ (như MT5 mobile): đường giá kéo được + loại lệnh tự suy ra theo vị trí so với giá thị trường. Thuần tính toán (không Kivy).

Quy tắc loại lệnh (giống MT5): đường vào gần giá thị trường (≤ MARKET_TOL) = lệnh THỊ TRƯỜNG;
  MUA  dưới ask = BUY LIMIT · trên ask = BUY STOP    ·    BÁN trên bid = SELL LIMIT · dưới bid = SELL STOP.
SL/TP là giá tuyệt đối: MUA SL < vào < TP · BÁN TP < vào < SL."""
MARKET_TOL = 0.0002          # 0,02% giá: gần hơn mức này coi là lệnh thị trường


def classify(side, price, bid, ask, tol=MARKET_TOL):
    """-> (kind, label): kind ∈ None (thị trường) | 'limit' | 'stop'; label dạng MT5: BUY / SELL LIMIT / ..."""
    side = "sell" if side == "sell" else "buy"
    ref = ask if side == "buy" else bid
    name = side.upper()
    if not ref or ref <= 0 or price is None or abs(price - ref) <= ref * tol:
        return None, name
    if side == "buy":
        kind = "limit" if price < ref else "stop"
    else:
        kind = "limit" if price > ref else "stop"
    return kind, "%s %s" % (name, kind.upper())


def entry_ref(side, price, bid, ask):
    """Giá tham chiếu để kiểm SL/TP: lệnh thị trường dùng ask (mua)/bid (bán); lệnh chờ dùng giá đặt."""
    kind, _ = classify(side, price, bid, ask)
    if kind is None:
        return ask if side == "buy" else bid
    return price


def default_levels(side, entry, span):
    """Mức SL/TP khởi tạo khi bấm chip: cách giá vào 12% bề rộng giá đang hiện (`span`) - luôn nằm trong vùng nhìn thấy."""
    d = max(span * 0.12, abs(entry) * 1e-6)
    if side == "buy":
        return entry - d, entry + d
    return entry + d, entry - d


def validate(side, entry, sl, tp, bid, ask):
    """Lỗi tiếng Việt hoặc '' nếu hợp lệ. sl/tp = 0 nghĩa là không đặt."""
    ref = entry_ref(side, entry, bid, ask)
    if not ref or ref <= 0:
        return "Chưa có giá thị trường - đợi giá về rồi đặt."
    if side == "buy":
        if sl and sl >= ref:
            return "MUA: Stop Loss phải DƯỚI giá vào."
        if tp and tp <= ref:
            return "MUA: Take Profit phải TRÊN giá vào."
    else:
        if sl and sl <= ref:
            return "BÁN: Stop Loss phải TRÊN giá vào."
        if tp and tp >= ref:
            return "BÁN: Take Profit phải DƯỚI giá vào."
    return ""


class PriceMap:
    """Ánh xạ giá <-> toạ độ y của vùng giá chính (cập nhật mỗi lần vẽ)."""

    def __init__(self, y0=0.0, h=1.0, lo=0.0, hi=1.0):
        self.y0, self.h, self.lo, self.hi = y0, max(h, 1e-9), lo, hi

    def y(self, price):
        return self.y0 + (price - self.lo) / ((self.hi - self.lo) or 1e-12) * self.h

    def price(self, y):
        y = max(self.y0, min(self.y0 + self.h, y))
        return self.lo + (y - self.y0) / self.h * (self.hi - self.lo)

    def span(self):
        return self.hi - self.lo


def nearest_line(lines, y, pm, reach):
    """Đường gần toạ độ y nhất trong tầm `reach` px. lines: {tên: giá}. Trả tên hoặc None."""
    best, bd = None, reach
    for name, price in lines.items():
        if not price:
            continue
        d = abs(pm.y(price) - y)
        if d <= bd:
            best, bd = name, d
    return best
