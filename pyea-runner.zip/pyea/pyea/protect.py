"""SL/TP NATIVE trên sàn (bảo vệ vị thế kể cả khi app/điện thoại chết) - phần VỎ, độc lập với sàn.

Vỏ làm giống MT5: SL/TP là thuộc tính của VỊ THẾ. Mỗi lần đồng bộ vỏ chỉ nói với broker «mỗi vị thế ảo muốn SL/TP nào» (`intents`, mỗi vị thế một phần tử:
pid, ref = ticket sàn nếu có, chiều đóng, khối lượng, sl, tp) qua MỘT hàm duy nhất `broker.sync_protection(symbol, intents)`; broker trả những (vị thế, mức) nào sàn
đã nhận canh (`covered`) và danh sách lệnh/mức đang sống (`live`). Sàn giữ mức bằng cơ chế gì (bậc thang reduceOnly gộp theo mức, lệnh OCO, sửa SL/TP ngay trên ticket
như MT5...) là việc của broker và nằm trong thư viện dùng chung `pyea/protection.py` - vỏ KHÔNG biết, nên thêm sàn mới không phải sửa file này.
Giao diện broker: `sync_protection`, `protection_orders(symbol)`, `order_result(id, symbol)`, tuỳ chọn `prot_supported()`, `PROT_LABEL` (xem protection.py).
Khi một lệnh/mức bảo vệ biến mất khỏi sàn, vỏ hỏi `order_result`: khớp -> GHI SỔ đóng đúng các vị thế ảo mà nó phủ (khớp theo `ref` nếu sàn có, ngược lại theo chiều + mức giá);
chân SL/TP lấy từ `leg` do broker báo, nếu không thì suy từ giá khớp (MT5 ghi thẳng DEAL_REASON_SL/TP); giá khớp không chạm mức nào của một vị thế gắn ticket = đóng
tay trên MT/EA khác/stop-out -> ghi sổ nguồn «manual».

Nguyên tắc an toàn (đây là tiền thật):
  * MẶC ĐỊNH TẮT (`native_sltp`). Chỉ chạy khi sàn có `sync_protection` và phiên không phải backtest.
  * MỖI MỨC SL/TP CHỈ CÓ MỘT NGƯỜI CANH: mức đã được sàn xác nhận (nằm trong `_prot_pos`) thì vỏ KHÔNG tự đóng bằng lệnh thị trường nữa
    (nếu cả hai cùng đóng, lệnh `reduceOnly` thứ hai sẽ đóng nhầm vị thế ảo khác). Mức chưa/không đặt được (lỗi, bị huỷ, mới mở) vẫn do vỏ canh như cũ.
  * Trước khi vỏ chủ động đóng/sửa một vị thế đã có bảo vệ native, lệnh bảo vệ của nó bị huỷ TRƯỚC (`_prot_release`).
  * Khi lệnh bảo vệ khớp trên sàn, vỏ chỉ GHI SỔ (đóng vị thế ảo tương ứng ở giá khớp thật), KHÔNG gửi thêm lệnh nào. Trạng thái theo dõi lưu ở
    `protect.json` nên lệnh khớp lúc app đang tắt vẫn được ghi sổ khi mở lại.
"""
import json
import os
import threading
import time

from .broker import BrokerError
from .protection import infer_leg, levels_of
from .sdk import Ret, TradeUpdate


class ProtectMixin:
    def _prot_init(self):
        self._prot_lock = threading.RLock()
        self._prot_io = threading.RLock()       # tuần tự hoá lời gọi sync_protection (vòng poll / đóng / sửa lệnh)
        self._prot_live = {}            # mã -> [{id, side, qty, sl/tp hoặc kind+trigger, (ref)}] lệnh/mức bảo vệ đang theo dõi trên sàn (broker trả)
        self._prot_pos = set()          # {(pos_id, "sl"|"tp")} mức SL/TP đã được sàn xác nhận (vỏ không tự canh mức này nữa)
        self._prot_sig = {}             # mã -> chữ ký bậc thang đã đồng bộ lần cuối (không đổi thì khỏi gọi sàn)
        self._prot_next = 0.0
        self._prot_warned = set()
        self._prot_err_t = {}
        self.prot = {"enabled": False, "orders": 0, "covered": 0, "last": 0.0, "error": ""}
        self._prot_load()
        # Vừa khởi động lại mà còn lệnh bảo vệ đang theo dõi: CHƯA biết chúng còn sống hay đã khớp lúc app tắt. Trong lúc chờ vòng đồng bộ đầu
        # tiên (tối đa 60 giây) vỏ KHÔNG tự đóng SL/TP của các mã đó - nếu không, vỏ có thể đóng đúp với lệnh bảo vệ đã khớp trên sàn.
        self._prot_hold = {s for s, v in self._prot_live.items() if v}
        self._prot_hold_until = time.time() + 60.0

    # ---- lưu bền (để ghi sổ cả những lệnh bảo vệ khớp lúc app tắt) ----
    def _prot_path(self):
        sf = getattr(self, "state_file", None)
        return os.path.join(os.path.dirname(os.path.abspath(sf)), "protect.json") if sf else None

    def _prot_load(self):
        p = self._prot_path()
        if not p or not os.path.exists(p):
            return
        try:
            with open(p, "r", encoding="utf-8") as f:
                d = json.load(f)
            self._prot_live = {str(k): [dict(o) for o in v] for k, v in (d.get("live") or {}).items()}
        except (OSError, ValueError, TypeError, AttributeError):
            self._prot_live = {}

    def _prot_save(self):
        p = self._prot_path()
        if not p:
            return
        tmp = p + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"live": self._prot_live}, f)
            os.replace(tmp, p)
        except OSError:
            pass

    # ---- điều kiện chạy ----
    def _prot_enabled(self):
        b = self.broker
        if not (bool(self.settings.get("native_sltp")) and b is not None and hasattr(b, "sync_protection") and not self.sync):
            return False
        sup = getattr(b, "prot_supported", None)                     # sàn có thể hỗ trợ tuỳ cấu hình (MT netting không đặt SL/TP riêng cho từng vị thế ảo)
        return bool(sup()) if callable(sup) else True

    def _prot_kick(self):
        """Buộc vòng poll kế tiếp đồng bộ ngay (không đợi `native_sync_s`) - dùng khi người dùng/bot vừa sửa SL/TP."""
        self._prot_next = 0.0

    def prot_covered(self, pos_id, kind):
        return (pos_id, kind) in self._prot_pos

    def prot_hold(self, symbol):
        """True: mã này còn lệnh bảo vệ chưa xác minh sau khi khởi động lại -> vỏ chưa được tự đóng SL/TP của nó."""
        return bool(self._prot_hold) and symbol in self._prot_hold and time.time() < self._prot_hold_until and self._prot_enabled()

    # ---- ý định bảo vệ (mỗi vị thế một phần tử; cách sàn giữ mức do broker lo) ----
    def _prot_desired(self, symbol, exclude=None):
        out = []
        with self.lock:
            plist = [p for p in self.account.positions.values() if p.symbol == symbol and p.id != exclude]
        for p in sorted(plist, key=lambda x: x.id):
            sl = float(p.sl) if p.sl and p.sl > 0 else 0.0
            tp = float(p.tp) if p.tp and p.tp > 0 else 0.0
            if sl or tp:
                out.append({"pid": p.id, "ref": p.ref or "", "side": "sell" if p.side == "buy" else "buy", "qty": float(p.volume), "sl": sl, "tp": tp,
                            "own": not getattr(p, "adopted", False)})
        return out

    @staticmethod
    def _prot_signature(desired):
        return repr([(d["pid"], d["ref"], d["side"], round(d["qty"], 10), d["sl"], d["tp"]) for d in desired])

    def _prot_apply(self, symbol, desired):
        """Đồng bộ lên sàn và cập nhật (vị thế, mức) nào đã được sàn xác nhận."""
        self._prot_seed(symbol)
        with self._prot_io:                                          # vòng poll và luồng đóng/sửa lệnh không được gọi sàn chồng nhau
            res = self.broker.sync_protection(symbol, [dict(d) for d in desired])
        with self._prot_lock:
            self._prot_live[symbol] = list(res.get("live") or [])
            ids = {p.id for p in self.account.positions.values() if p.symbol == symbol}
            self._prot_pos = {x for x in self._prot_pos if x[0] not in ids}
            for pid, legs in (res.get("covered") or {}).items():
                for k in legs:
                    if k in ("sl", "tp"):
                        self._prot_pos.add((int(pid), k))
            self._prot_sig[symbol] = self._prot_signature(desired)
            self._prot_save()
        for err in res.get("errors") or []:
            self._prot_warn(symbol, "Lệnh bảo vệ native %s không đặt/huỷ được: %s - vỏ vẫn tự canh mức này" % (symbol, err))
        return res

    def _prot_warn(self, key, text):
        now = time.time()
        if now - self._prot_err_t.get(key + text[:40], 0.0) > 300:
            self._prot_err_t[key + text[:40]] = now
            self.log(text, "WARN")

    # ---- vòng poll ----
    def _check_protection(self):
        if not self._prot_enabled():
            if self.settings.get("native_sltp") and self.broker is not None and not self.sync and "unsupported" not in self._prot_warned:
                self._prot_warned.add("unsupported")
                self.log("«SL/TP native» đang bật nhưng sàn hiện tại chưa hỗ trợ - vỏ vẫn tự canh SL/TP như thường.", "WARN")
            if self._prot_live or self._prot_pos:
                self._prot_disable()
            self.prot["enabled"] = False
            return
        now = time.time()
        if now < self._prot_next:
            return
        self._prot_next = now + max(1.0, float(self.settings.get("native_sync_s") or 2.0))
        with self.lock:
            syms = {p.symbol for p in self.account.positions.values()}
        for sym in sorted(syms | set(self._prot_live)):
            try:
                self._prot_symbol(sym)
            except BrokerError as e:
                self.prot["error"] = str(e)
                self._prot_warn(sym, "SL/TP native %s: %s" % (sym, e))
            except Exception as e:                                   # noqa: BLE001 - không để lỗi bảo vệ làm sập phiên
                self.prot["error"] = str(e)
                self._prot_warn(sym, "SL/TP native %s lỗi: %s" % (sym, e))
        with self._prot_lock:
            self.prot.update(enabled=True, orders=sum(len(v) for v in self._prot_live.values()), covered=len(self._prot_pos), last=now)

    def _prot_seed(self, sym):
        """Sau khởi động lại broker mới không nhớ gì: các ticket đã gắn SL/TP trước đó (theo dõi trong protect.json) vẫn là của app, để còn gỡ/sửa được."""
        note = getattr(self.broker, "note_own_ref", None)
        if callable(note):
            for o in self._prot_live.get(sym, []):
                note(o.get("ref"))

    def _prot_symbol(self, sym):
        b = self.broker
        self._prot_seed(sym)
        tracked = list(self._prot_live.get(sym) or [])
        changed = False
        if tracked:                                                  # 1) lệnh bảo vệ đã biến mất khỏi sàn: khớp? bị huỷ?
            try:
                live_ids = {o["id"] for o in b.protection_orders(sym)}
            except BrokerError as e:
                self.link_note("protect", False, e)
                raise
            self.link_note("protect", True)
            for o in tracked:
                if o["id"] in live_ids:
                    continue
                r = b.order_result(o["id"], sym) or {}
                st = r.get("state")
                if st == "filled":
                    self._prot_on_fill(sym, o, r)
                elif st in ("canceled", "expired", "rejected"):
                    self.log("Lệnh bảo vệ native %s %s bị sàn %s - vỏ sẽ đặt lại hoặc tự canh" % (
                        sym, self._prot_desc(o), {"canceled": "huỷ", "expired": "hết hạn", "rejected": "từ chối"}[st]), "WARN")
                elif st != "open":
                    continue                                         # unknown: hỏi lại vòng sau
                with self._prot_lock:
                    self._prot_live[sym] = [x for x in self._prot_live.get(sym, []) if x["id"] != o["id"]]
                    self._prot_sig.pop(sym, None)
                    self._prot_save()
                changed = True
        desired = self._prot_desired(sym)                           # 2) đưa sàn về đúng bậc thang hiện tại
        if not changed and self._prot_sig.get(sym) == self._prot_signature(desired):
            self._prot_hold.discard(sym)
            return
        self._prot_apply(sym, desired)
        self._prot_hold.discard(sym)                                # đã xác minh xong: trả quyền canh mức chưa đặt được cho vỏ

    @staticmethod
    def _prot_desc(o):
        """Mô tả ngắn một lệnh/mức bảo vệ để ghi nhật ký."""
        sl, tp = levels_of(o)
        head = "ticket #%s " % o["ref"] if o.get("ref") else ("OCO " if (sl and tp) else "")
        if sl and tp:
            return "%sSL @%.8g / TP @%.8g" % (head, sl, tp)
        return "%s%s @%.8g" % (head, "SL" if sl else "TP", sl or tp)

    # ---- lệnh bảo vệ khớp trên sàn -> ghi sổ ----
    def _prot_on_fill(self, sym, o, r):
        """Lệnh/mức bảo vệ `o` đã khớp (hoặc vị thế đã đóng) trên sàn -> ghi sổ đóng các vị thế ảo nó phủ. KHÔNG gửi lệnh nào."""
        sl, tp = levels_of(o)
        ref = str(o.get("ref") or "")
        self._book_order(o.get("id"))                                 # lần khớp của lệnh bảo vệ này đã được ghi sổ -> đối soát không tính lại
        pos_side = "buy" if o["side"] == "sell" else "sell"
        spec = self.spec(sym)
        half_tick = 0.5 * float(getattr(spec, "tick_size", 0.0) or 0.0)
        want = float(o.get("qty") or 0.0)
        price, qty = float(r.get("price") or 0.0) or (sl or tp), float(r.get("qty") or want)
        deals = [d for d in (r.get("deals") or []) if d.get("qty")]
        if deals:                                                    # sàn trả mọi deal đóng của ticket: lấy các deal CUỐI cho đủ khối lượng vỏ đang canh
            tot, take = 0.0, []
            for d in reversed(deals):
                take.append(d)
                tot += float(d["qty"])
                if tot >= want - 1e-9:
                    break
            tot = sum(float(d["qty"]) for d in take)
            price, qty = sum(float(d["price"]) * float(d["qty"]) for d in take) / tot, tot
        leg = r.get("leg") if r.get("leg") in ("sl", "tp", "manual") else infer_leg(pos_side, price, sl, tp, half_tick, allow_manual=bool(ref))
        trig = 0.0 if leg == "manual" else (sl if leg == "sl" else tp)
        other = 0.0 if leg == "manual" else (tp if leg == "sl" else sl)      # entry có cả hai mức (OCO/ticket): vị thế phải khớp cả hai mới đúng nhóm

        def near(a, b):
            return abs(a - b) <= max(abs(b) * 1e-9, half_tick, 1e-12)

        with self.lock:
            cands = sorted((p for p in self.account.positions.values()
                            if p.symbol == sym and p.side == pos_side
                            and ((p.ref == ref) if ref else (leg != "manual" and (p.sl if leg == "sl" else p.tp)
                                                                 and near(p.sl if leg == "sl" else p.tp, trig)
                                                                 and (not other or near((p.tp if leg == "sl" else p.sl) or 0.0, other)))))
                           , key=lambda p: p.id)
        todo, step_tol = qty, max(1e-9, 0.5 * float(getattr(spec, "volume_step", 0.0) or 0.0))
        # BỤI: sàn (Spot) làm tròn xuống theo bước khối lượng của SÀN (`o["step"]`), còn vị thế ảo giữ khối lượng ròng sau phí bằng coin
        # (vd 0.04995 -> lệnh bảo vệ 0.049). Lệnh đã khớp TRỌN thì phần dư nhỏ hơn một bước là bụi KHÔNG bán được -> coi vị thế đã đóng hết
        # (giống close_position: đóng toàn bộ khối lượng ảo dù sàn chỉ bán được phần làm tròn), thay vì để lại vị thế ảo vô hình có SL/TP.
        dust = float(o.get("step") or 0.0)
        full = dust > 0 and qty >= want - 1e-12
        if leg == "manual":
            label, ptype = "Đóng ngoài app", ""
        else:
            label = "Stop Loss" if leg == "sl" else "Take Profit"
            ptype = (getattr(self.broker, "PROT_LABEL", None) or {}).get(leg) or ("STOP_MARKET" if leg == "sl" else "TAKE_PROFIT_MARKET")
        done = 0
        for p in cands:
            if todo <= step_tol:
                break
            cut = min(p.volume, todo)
            if full and 0.0 < p.volume - cut < dust - 1e-12:
                cut = p.volume
            if leg == "manual":
                why = "Vị thế sàn #%s đã đóng NGOÀI app (đóng tay trên sàn/EA khác/stop-out), khớp @ %.8g" % (ref, price)
            else:
                why = "%s NATIVE khớp trên sàn: lệnh bảo vệ %s @ %.8g, khớp @ %.8g" % (label, ptype, trig, price)
            self._prot_book_close(p, cut, price, leg, why, trig)
            todo -= cut
            done += 1
        self.log("Lệnh bảo vệ native %s %s %s đã KHỚP trên sàn (%.8g @ %.8g)%s -> ghi sổ %d vị thế" % (
            sym, label, "@%.8g" % trig if trig else "", qty, price, " [của %s]" % self._prot_desc(o) if (sl and tp) or ref else "", done))
        if done == 0 and ref:
            self.log("Ticket #%s của %s đã đóng trên sàn nhưng sổ app không còn vị thế mang ticket này (đã ghi sổ trước đó)" % (ref, sym), "INFO")
        elif done == 0 or todo > step_tol:
            self.log("Lệnh bảo vệ %s khớp %.8g nhưng sổ app chỉ có %.8g vị thế đúng mức %.8g - sẽ đối soát với sàn" % (sym, qty, qty - todo, trig), "WARN")
            self.reconcile_due(1.0)

    def _prot_book_close(self, pos, vol, price, kind, reason, level):
        """Ghi sổ đóng (một phần) vị thế ảo theo lệnh đã khớp TRÊN SÀN - không gửi lệnh nào."""
        from .engine import SRC_LABEL
        partial = vol < pos.volume - 1e-12
        t = self._now()
        with self.lock:
            if pos.id not in self.account.positions:
                return
            tr = (self.account.reduce(pos.id, vol, price, t, kind) if partial else self.account.close(pos.id, price, t, kind))
            self._prot_pos = {x for x in self._prot_pos if x[0] != pos.id} if not partial else self._prot_pos
        label = SRC_LABEL.get(kind) or kind
        tr.reason = label
        d = {"mức đặt": level, "giá vào": pos.open_price, "giá ra": price, "nguồn": "lệnh bảo vệ native trên sàn"}
        if partial:
            d["đóng một phần"] = "%.8g / %.8g" % (vol, pos.volume)
        self.add_event("close", pos.symbol, price, pos.side, vol, pos.id, kind, reason, d, None, tr.profit, None, pos.owner)
        self.log("%s #%d %s %s %.8g @ %.8g | %s | P/L %+.4f | %s" % ("ĐÓNG MỘT PHẦN" if partial else "ĐÓNG", tr.id, tr.side.upper(), pos.symbol,
                                                                       vol, price, label, tr.profit, reason))
        self.notify("Đóng lệnh %s %s (%s native)" % (tr.side.upper(), pos.symbol, label), "P/L %+.4f @ %.8g" % (tr.profit, price))
        self._emit(TradeUpdate(kind="position_reduced" if partial else "position_closed", id=pos.id, symbol=pos.symbol, side=pos.side,
                               volume=vol, price=price, profit=tr.profit, source=kind, reason=reason, retcode=Ret.OK, time=t, owner=pos.owner))
        self._save_trade(tr)
        self._save_state()

    def _prot_edit_in_place(self):
        b = self.broker
        v = getattr(b, "PROT_EDIT_IN_PLACE", None)
        return bool(v) if v is not None else getattr(b, "PROT_STYLE", "") == "position"

    # ---- gỡ bảo vệ trước khi vỏ chủ động đóng/sửa ----
    def _prot_release(self, pos, edit=False):
        """Gọi TRƯỚC khi vỏ gửi lệnh đóng thị trường cho `pos` (hoặc sửa SL/TP): vỏ canh lại mức của vị thế này ngay, và nếu nó đang được bảo vệ native thì đồng bộ lại sàn
        KHÔNG kèm vị thế này (sàn gỡ mức của nó) để lệnh bảo vệ cũ không đóng nhầm vị thế ảo khác / đóng đúp. Lỗi gỡ -> ghi cảnh báo và vẫn tiếp tục (vòng poll cố lại)."""
        if not self._prot_enabled():
            return
        with self._prot_lock:
            had = any((pos.id, k) in self._prot_pos for k in ("sl", "tp"))
            # Vừa khởi động lại: lệnh bảo vệ còn theo dõi (`_prot_live`) nhưng CHƯA xác minh nên chưa có mức nào «đã canh». Vị thế có SL/TP vẫn có thể đang nằm trong
            # lệnh đó -> cũng gỡ trước khi đóng (nếu không: Spot bị khoá coin không bán được; Futures/OANDA để lại lệnh reduceOnly mồ côi có thể đóng nhầm vị thế khác).
            maybe = bool(self._prot_live.get(pos.symbol)) and bool(pos.sl or pos.tp)
            self._prot_pos.discard((pos.id, "sl"))
            self._prot_pos.discard((pos.id, "tp"))
            self._prot_sig.pop(pos.symbol, None)
        if not (had or maybe):
            return
        if edit and self._prot_edit_in_place():                      # SỬA (không đóng) trên sàn gắn mức lên chính vị thế: sàn sửa tại chỗ ở vòng poll kế (một lời gọi,
            self._prot_sig.pop(pos.symbol, None)                    # không huỷ rồi đặt); trong lúc đó vỏ tự canh mức mới (đã bỏ khỏi _prot_pos)
            self._prot_kick()
            return
        try:
            self._prot_apply(pos.symbol, self._prot_desired(pos.symbol, exclude=pos.id))
        except Exception as e:                                       # noqa: BLE001
            self.log("Không huỷ được lệnh bảo vệ native của #%d trước khi đóng/sửa: %s" % (pos.id, e), "WARN")
        self._prot_sig.pop(pos.symbol, None)                        # vẫn buộc vòng poll tính lại với bậc thang thật
        self._prot_kick()                                            # ... và chạy NGAY ở vòng kế tiếp (không đợi native_sync_s)

    def _prot_disable(self):
        """Người dùng tắt «SL/TP native» (hoặc đổi sàn không hỗ trợ): gỡ mọi lệnh bảo vệ đang sống rồi trả quyền canh cho vỏ."""
        b = self.broker
        with self._prot_lock:
            syms = list(self._prot_live)
            self._prot_pos.clear()
            self._prot_sig.clear()
        if b is not None and hasattr(b, "sync_protection"):
            for sym in syms:
                try:
                    b.sync_protection(sym, [])
                except Exception as e:                               # noqa: BLE001
                    self.log("Không gỡ được lệnh bảo vệ native %s: %s" % (sym, e), "WARN")
                    return
        with self._prot_lock:
            self._prot_live.clear()
            self._prot_save()
        if syms:
            self.log("Đã gỡ lệnh bảo vệ native trên sàn - vỏ tự canh SL/TP trở lại", "INFO")
