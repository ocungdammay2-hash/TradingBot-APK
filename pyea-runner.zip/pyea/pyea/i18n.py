"""ĐA NGÔN NGỮ cho giao diện. Chuỗi gốc trong code là TIẾNG VIỆT; `tr(text)` tra bảng CAT theo đúng chuỗi gốc, không có thì trả nguyên văn.
Nên chuỗi chưa có trong bảng (lời nhắn ghép số liệu, mô tả dài, tên tham số bot) vẫn hiện tiếng Việt - an toàn, không bao giờ mất chữ.
Chỉ có những ngôn ngữ mà phông DejaVuSans đi kèm app vẽ được (Latinh + Kirin). Trung/Nhật/Hàn/Thái/Hindi/Ả Rập cần nhúng thêm phông (vài chục MB) nên CHƯA có.
Ô chọn lưu dạng «Tên bản ngữ (mã)», `code_of` lấy mã trong ngoặc."""
import re

# mã, tên bản ngữ
LANGS = [("vi", "Tiếng Việt"), ("en", "English"), ("es", "Español"), ("fr", "Français"), ("de", "Deutsch"),
         ("pt", "Português"), ("id", "Bahasa Indonesia"), ("ru", "Русский"), ("tr", "Türkçe"), ("it", "Italiano")]
CODES = [c for c, _ in LANGS]
_ORDER = CODES[1:]                                    # thứ tự cột trong CAT (sau tiếng Việt)
DEFAULT = "vi"
_cur = DEFAULT


def choices():
    return ["%s (%s)" % (n, c) for c, n in LANGS]


def code_of(value):
    """'English (en)' | 'en' -> 'en'; không nhận ra -> 'vi'."""
    v = str(value or "").strip()
    m = re.search(r"\(([a-z]{2})\)\s*$", v)
    v = m.group(1) if m else v.lower()
    return v if v in CODES else DEFAULT


def label_of(code):
    return "%s (%s)" % (dict(LANGS).get(code, "Tiếng Việt"), code if code in CODES else DEFAULT)


def set_lang(value):
    global _cur
    _cur = code_of(value)
    return _cur


def lang():
    return _cur


def tr(text):
    if _cur == DEFAULT or not isinstance(text, str):
        return text
    row = _CAT.get(text)
    if row is None:
        return text
    return row[_ORDER.index(_cur)] or text


# vi: (en, es, fr, de, pt, id, ru, tr, it)
CAT = {
    "Thị trường": ("Market", "Mercado", "Marché", "Markt", "Mercado", "Pasar", "Рынок", "Piyasa", "Mercato"),
    "Giao dịch": ("Trades", "Operaciones", "Transactions", "Trades", "Operações", "Transaksi", "Сделки", "İşlemler", "Operazioni"),
    "Bot": ("Bots", "Bots", "Bots", "Bots", "Bots", "Bot", "Боты", "Botlar", "Bot"),
    "Biểu đồ": ("Chart", "Gráfico", "Graphique", "Chart", "Gráfico", "Grafik", "График", "Grafik", "Grafico"),
    "Backtest": ("Backtest", "Backtest", "Backtest", "Backtest", "Backtest", "Backtest", "Бэктест", "Geriye test", "Backtest"),
    "AI": ("AI", "IA", "IA", "KI", "IA", "AI", "ИИ", "YZ", "IA"),
    "Cài đặt": ("Settings", "Ajustes", "Paramètres", "Einstellungen", "Configurações", "Pengaturan", "Настройки", "Ayarlar", "Impostazioni"),
    "Nhật ký": ("Log", "Registro", "Journal", "Protokoll", "Registro", "Log", "Журнал", "Günlük", "Registro"),
    "Đóng": ("Close", "Cerrar", "Fermer", "Schließen", "Fechar", "Tutup", "Закрыть", "Kapat", "Chiudi"),
    "Huỷ": ("Cancel", "Cancelar", "Annuler", "Abbrechen", "Cancelar", "Batal", "Отмена", "İptal", "Annulla"),
    "Xoá": ("Delete", "Eliminar", "Supprimer", "Löschen", "Excluir", "Hapus", "Удалить", "Sil", "Elimina"),
    "Lưu": ("Save", "Guardar", "Enregistrer", "Speichern", "Salvar", "Simpan", "Сохранить", "Kaydet", "Salva"),
    "Sao chép": ("Copy", "Copiar", "Copier", "Kopieren", "Copiar", "Salin", "Копировать", "Kopyala", "Copia"),
    "Mặc định": ("Default", "Predeterminado", "Par défaut", "Standard", "Padrão", "Bawaan", "По умолчанию", "Varsayılan", "Predefinito"),
    "Sửa": ("Edit", "Editar", "Modifier", "Bearbeiten", "Editar", "Ubah", "Изменить", "Düzenle", "Modifica"),
    "Lệnh mới": ("New order", "Nueva orden", "Nouvel ordre", "Neue Order", "Nova ordem", "Order baru", "Новый ордер", "Yeni emir", "Nuovo ordine"),
    "Trợ lý": ("Assistant", "Asistente", "Assistant", "Assistent", "Assistente", "Asisten", "Помощник", "Asistan", "Assistente"),
    "Chạy": ("Run", "Ejecutar", "Lancer", "Starten", "Executar", "Jalankan", "Запуск", "Çalıştır", "Esegui"),
    "Hỏi AI tư vấn": ("Ask AI for advice", "Pedir consejo a la IA", "Demander conseil à l'IA", "KI um Rat fragen", "Pedir conselho à IA", "Tanya AI", "Спросить ИИ", "YZ'den tavsiye al", "Chiedi consiglio all'IA"),
    "Thêm": ("Add", "Añadir", "Ajouter", "Hinzufügen", "Adicionar", "Tambah", "Добавить", "Ekle", "Aggiungi"),
    "Gửi": ("Send", "Enviar", "Envoyer", "Senden", "Enviar", "Kirim", "Отправить", "Gönder", "Invia"),
    "Xong": ("Done", "Listo", "Terminé", "Fertig", "Concluído", "Selesai", "Готово", "Bitti", "Fatto"),
    "Áp dụng": ("Apply", "Aplicar", "Appliquer", "Anwenden", "Aplicar", "Terapkan", "Применить", "Uygula", "Applica"),
    "+ Chỉ báo": ("+ Indicator", "+ Indicador", "+ Indicateur", "+ Indikator", "+ Indicador", "+ Indikator", "+ Индикатор", "+ Gösterge", "+ Indicatore"),
    "Điểm vào/ra": ("Entry/exit", "Entrada/salida", "Entrée/sortie", "Ein-/Ausstieg", "Entrada/saída", "Masuk/keluar", "Вход/выход", "Giriş/çıkış", "Ingresso/uscita"),
    "Lệnh mở": ("Open orders", "Órdenes abiertas", "Ordres ouverts", "Offene Orders", "Ordens abertas", "Order terbuka", "Открытые ордера", "Açık emirler", "Ordini aperti"),
    "Lưới": ("Grid", "Cuadrícula", "Grille", "Raster", "Grade", "Grid", "Сетка", "Izgara", "Griglia"),
    "Chưa kết nối": ("Not connected", "Sin conexión", "Non connecté", "Nicht verbunden", "Não conectado", "Belum terhubung", "Нет подключения", "Bağlı değil", "Non connesso"),
    "KẾT NỐI": ("CONNECT", "CONECTAR", "CONNECTER", "VERBINDEN", "CONECTAR", "HUBUNGKAN", "ПОДКЛЮЧИТЬ", "BAĞLAN", "CONNETTI"),
    "▶  KẾT NỐI & CHẠY": ("▶  CONNECT & RUN", "▶  CONECTAR Y EJECUTAR", "▶  CONNECTER ET LANCER", "▶  VERBINDEN & STARTEN", "▶  CONECTAR E EXECUTAR", "▶  HUBUNGKAN & JALANKAN", "▶  ПОДКЛЮЧИТЬ И ЗАПУСТИТЬ", "▶  BAĞLAN VE ÇALIŞTIR", "▶  CONNETTI E AVVIA"),
    "■  NGẮT": ("■  DISCONNECT", "■  DESCONECTAR", "■  DÉCONNECTER", "■  TRENNEN", "■  DESCONECTAR", "■  PUTUSKAN", "■  ОТКЛЮЧИТЬ", "■  BAĞLANTIYI KES", "■  DISCONNETTI"),
    "Thêm mã": ("Add symbol", "Añadir símbolo", "Ajouter un symbole", "Symbol hinzufügen", "Adicionar símbolo", "Tambah simbol", "Добавить символ", "Sembol ekle", "Aggiungi simbolo"),
    "Đóng tất cả": ("Close all", "Cerrar todo", "Tout fermer", "Alle schließen", "Fechar tudo", "Tutup semua", "Закрыть все", "Tümünü kapat", "Chiudi tutto"),
    "Lịch sử & báo cáo": ("History & reports", "Historial e informes", "Historique et rapports", "Verlauf & Berichte", "Histórico e relatórios", "Riwayat & laporan", "История и отчёты", "Geçmiş ve raporlar", "Cronologia e report"),
    "Cảnh báo giá": ("Price alerts", "Alertas de precio", "Alertes de prix", "Preisalarme", "Alertas de preço", "Peringatan harga", "Ценовые оповещения", "Fiyat uyarıları", "Avvisi di prezzo"),
    "VỊ THẾ ĐANG MỞ (mọi tài sản)": ("OPEN POSITIONS (all assets)", "POSICIONES ABIERTAS (todos los activos)", "POSITIONS OUVERTES (tous actifs)", "OFFENE POSITIONEN (alle Werte)", "POSIÇÕES ABERTAS (todos os ativos)", "POSISI TERBUKA (semua aset)", "ОТКРЫТЫЕ ПОЗИЦИИ (все активы)", "AÇIK POZİSYONLAR (tüm varlıklar)", "POSIZIONI APERTE (tutti gli asset)"),
    "Không có lệnh chờ nào.": ("No pending orders.", "No hay órdenes pendientes.", "Aucun ordre en attente.", "Keine schwebenden Orders.", "Nenhuma ordem pendente.", "Tidak ada order tertunda.", "Нет отложенных ордеров.", "Bekleyen emir yok.", "Nessun ordine pendente."),
    "Chưa có lệnh nào đang mở.": ("No open positions.", "No hay posiciones abiertas.", "Aucune position ouverte.", "Keine offenen Positionen.", "Nenhuma posição aberta.", "Belum ada posisi terbuka.", "Нет открытых позиций.", "Açık pozisyon yok.", "Nessuna posizione aperta."),
    "BOT ĐÃ GẮN VÀO TÀI SẢN": ("BOTS ATTACHED TO ASSETS", "BOTS ASIGNADOS A ACTIVOS", "BOTS ATTACHÉS AUX ACTIFS", "BOTS AN WERTE GEBUNDEN", "BOTS ANEXADOS AOS ATIVOS", "BOT TERPASANG PADA ASET", "БОТЫ, ПРИВЯЗАННЫЕ К АКТИВАМ", "VARLIKLARA BAĞLI BOTLAR", "BOT ASSEGNATI AGLI ASSET"),
    "Gắn bot mới": ("Attach new bot", "Asignar nuevo bot", "Attacher un bot", "Neuen Bot anbinden", "Anexar novo bot", "Pasang bot baru", "Привязать бота", "Yeni bot bağla", "Assegna nuovo bot"),
    "THƯ VIỆN BOT (file .py)": ("BOT LIBRARY (.py files)", "BIBLIOTECA DE BOTS (.py)", "BIBLIOTHÈQUE DE BOTS (.py)", "BOT-BIBLIOTHEK (.py)", "BIBLIOTECA DE BOTS (.py)", "PUSTAKA BOT (file .py)", "БИБЛИОТЕКА БОТОВ (.py)", "BOT KÜTÜPHANESİ (.py)", "LIBRERIA BOT (.py)"),
    "Nạp file .py": ("Load .py file", "Cargar archivo .py", "Charger un fichier .py", ".py-Datei laden", "Carregar arquivo .py", "Muat file .py", "Загрузить .py", ".py dosyası yükle", "Carica file .py"),
    "Thoát ứng dụng": ("Quit app", "Salir de la app", "Quitter l'app", "App beenden", "Sair do app", "Keluar aplikasi", "Выйти из приложения", "Uygulamadan çık", "Esci dall'app"),
    "Tham số": ("Parameters", "Parámetros", "Paramètres", "Parameter", "Parâmetros", "Parameter", "Параметры", "Parametreler", "Parametri"),
    "CHẠY BACKTEST": ("RUN BACKTEST", "EJECUTAR BACKTEST", "LANCER LE BACKTEST", "BACKTEST STARTEN", "EXECUTAR BACKTEST", "JALANKAN BACKTEST", "ЗАПУСТИТЬ БЭКТЕСТ", "GERİYE TESTİ ÇALIŞTIR", "AVVIA BACKTEST"),
    "Tạm dừng": ("Pause", "Pausa", "Pause", "Pause", "Pausar", "Jeda", "Пауза", "Duraklat", "Pausa"),
    "Dừng": ("Stop", "Detener", "Arrêter", "Stopp", "Parar", "Berhenti", "Стоп", "Durdur", "Stop"),
    "KẾT QUẢ": ("RESULTS", "RESULTADOS", "RÉSULTATS", "ERGEBNISSE", "RESULTADOS", "HASIL", "РЕЗУЛЬТАТЫ", "SONUÇLAR", "RISULTATI"),
    "Báo cáo đầy đủ": ("Full report", "Informe completo", "Rapport complet", "Vollständiger Bericht", "Relatório completo", "Laporan lengkap", "Полный отчёт", "Tam rapor", "Report completo"),
    "Sao lưu": ("Backup", "Copia de seguridad", "Sauvegarde", "Sicherung", "Backup", "Cadangan", "Резервная копия", "Yedekle", "Backup"),
    "Khôi phục": ("Restore", "Restaurar", "Restaurer", "Wiederherstellen", "Restaurar", "Pulihkan", "Восстановить", "Geri yükle", "Ripristina"),
    "Gói chẩn đoán": ("Diagnostics pack", "Paquete de diagnóstico", "Pack de diagnostic", "Diagnosepaket", "Pacote de diagnóstico", "Paket diagnostik", "Пакет диагностики", "Tanılama paketi", "Pacchetto diagnostico"),
    "Đặt lại paper": ("Reset paper", "Reiniciar paper", "Réinitialiser paper", "Paper zurücksetzen", "Redefinir paper", "Reset paper", "Сбросить paper", "Paper'ı sıfırla", "Reimposta paper"),
    "Quản lý AI": ("Manage AI", "Gestionar IA", "Gérer l'IA", "KI verwalten", "Gerenciar IA", "Kelola AI", "Управление ИИ", "YZ yönetimi", "Gestisci IA"),
    "Kiểm tra hệ thống": ("System check", "Revisión del sistema", "Vérification du système", "Systemprüfung", "Verificação do sistema", "Cek sistem", "Проверка системы", "Sistem kontrolü", "Controllo sistema"),
    "Gửi báo lỗi": ("Send error report", "Enviar informe de error", "Envoyer le rapport d'erreur", "Fehlerbericht senden", "Enviar relatório de erro", "Kirim laporan error", "Отправить отчёт об ошибке", "Hata raporu gönder", "Invia segnalazione errore"),
    "Thoát": ("Exit", "Salir", "Quitter", "Beenden", "Sair", "Keluar", "Выход", "Çıkış", "Esci"),
    "Chọn": ("Select", "Elegir", "Choisir", "Auswählen", "Escolher", "Pilih", "Выбрать", "Seç", "Seleziona"),
    "Lưu & áp dụng": ("Save & apply", "Guardar y aplicar", "Enregistrer et appliquer", "Speichern & anwenden", "Salvar e aplicar", "Simpan & terapkan", "Сохранить и применить", "Kaydet ve uygula", "Salva e applica"),
    "Xem biểu đồ": ("View chart", "Ver gráfico", "Voir le graphique", "Chart ansehen", "Ver gráfico", "Lihat grafik", "Открыть график", "Grafiği gör", "Vedi grafico"),
    "Đặt lệnh thủ công": ("Place manual order", "Orden manual", "Ordre manuel", "Manuelle Order", "Ordem manual", "Order manual", "Ручной ордер", "Manuel emir", "Ordine manuale"),
    "BÁN": ("SELL", "VENDER", "VENDRE", "VERKAUFEN", "VENDER", "JUAL", "ПРОДАТЬ", "SAT", "VENDI"),
    "MUA": ("BUY", "COMPRAR", "ACHETER", "KAUFEN", "COMPRAR", "BELI", "КУПИТЬ", "AL", "COMPRA"),
    "Quay lại": ("Back", "Volver", "Retour", "Zurück", "Voltar", "Kembali", "Назад", "Geri", "Indietro"),
    "Gửi lệnh": ("Send order", "Enviar orden", "Envoyer l'ordre", "Order senden", "Enviar ordem", "Kirim order", "Отправить ордер", "Emri gönder", "Invia ordine"),
    "Gửi lệnh từ biểu đồ": ("Send order from chart", "Enviar orden desde el gráfico", "Envoyer l'ordre depuis le graphique", "Order aus dem Chart senden", "Enviar ordem do gráfico", "Kirim order dari grafik", "Отправить ордер с графика", "Emri grafikten gönder", "Invia ordine dal grafico"),
    "Khối lượng": ("Volume", "Volumen", "Volume", "Volumen", "Volume", "Volume", "Объём", "Hacim", "Volume"),
    "Đặt lệnh": ("Place order", "Colocar orden", "Passer l'ordre", "Order platzieren", "Colocar ordem", "Pasang order", "Разместить ордер", "Emir ver", "Invia ordine"),
    "Xác nhận lệnh": ("Confirm order", "Confirmar orden", "Confirmer l'ordre", "Order bestätigen", "Confirmar ordem", "Konfirmasi order", "Подтвердить ордер", "Emri onayla", "Conferma ordine"),
    "LỆNH THẬT": ("REAL ORDER", "ORDEN REAL", "ORDRE RÉEL", "ECHTE ORDER", "ORDEM REAL", "ORDER NYATA", "РЕАЛЬНЫЙ ОРДЕР", "GERÇEK EMİR", "ORDINE REALE"),
    "KILL SWITCH": ("KILL SWITCH", "KILL SWITCH", "KILL SWITCH", "KILL SWITCH", "KILL SWITCH", "KILL SWITCH", "АВАРИЙНЫЙ СТОП", "KILL SWITCH", "KILL SWITCH"),
    "Mở lại giao dịch": ("Resume trading", "Reanudar operaciones", "Reprendre le trading", "Handel fortsetzen", "Retomar negociação", "Lanjutkan trading", "Возобновить торговлю", "İşlemlere devam", "Riprendi il trading"),
    "Thêm cảnh báo": ("Add alert", "Añadir alerta", "Ajouter une alerte", "Alarm hinzufügen", "Adicionar alerta", "Tambah peringatan", "Добавить оповещение", "Uyarı ekle", "Aggiungi avviso"),
    "Chưa có cảnh báo nào.": ("No alerts yet.", "Aún no hay alertas.", "Aucune alerte.", "Noch keine Alarme.", "Nenhum alerta ainda.", "Belum ada peringatan.", "Оповещений пока нет.", "Henüz uyarı yok.", "Nessun avviso."),
    "TỔNG QUAN (mọi lệnh đã đóng)": ("OVERVIEW (all closed trades)", "RESUMEN (todas las operaciones cerradas)", "APERÇU (tous les trades clôturés)", "ÜBERSICHT (alle geschlossenen Trades)", "VISÃO GERAL (todas as operações fechadas)", "RINGKASAN (semua transaksi tertutup)", "ОБЗОР (все закрытые сделки)", "ÖZET (tüm kapalı işlemler)", "PANORAMICA (tutte le operazioni chiuse)"),
    "Tuỳ chọn": ("Custom", "Personalizado", "Personnalisé", "Benutzerdefiniert", "Personalizado", "Kustom", "Свой период", "Özel", "Personalizzato"),
    "Vị thế": ("Positions", "Posiciones", "Positions", "Positionen", "Posições", "Posisi", "Позиции", "Pozisyonlar", "Posizioni"),
    "Lệnh": ("Orders", "Órdenes", "Ordres", "Orders", "Ordens", "Order", "Ордера", "Emirler", "Ordini"),
    "Tắt": ("Off", "Apagar", "Désactiver", "Aus", "Desligar", "Matikan", "Выкл", "Kapat", "Disattiva"),
    "Xem": ("View", "Ver", "Voir", "Ansehen", "Ver", "Lihat", "Смотреть", "Gör", "Vedi"),
    "Hoàn tác": ("Undo", "Deshacer", "Annuler", "Rückgängig", "Desfazer", "Urungkan", "Отменить", "Geri al", "Annulla"),
    "Bỏ qua": ("Skip", "Omitir", "Ignorer", "Überspringen", "Ignorar", "Lewati", "Пропустить", "Atla", "Salta"),
    "Xoá hội thoại": ("Clear conversation", "Borrar conversación", "Effacer la conversation", "Unterhaltung löschen", "Limpar conversa", "Hapus percakapan", "Очистить чат", "Sohbeti sil", "Cancella conversazione"),
    "Nhật ký hoạt động": ("Activity log", "Registro de actividad", "Journal d'activité", "Aktivitätsprotokoll", "Registro de atividade", "Log aktivitas", "Журнал действий", "Etkinlik günlüğü", "Registro attività"),
    "Ngôn ngữ / Language": ("Language", "Idioma", "Langue", "Sprache", "Idioma", "Bahasa", "Язык", "Dil", "Lingua"),
}
_CAT = {k: v for k, v in CAT.items() if len(v) == len(_ORDER)}

# lời nhắn "khởi động lại để đổi ngôn ngữ" bằng chính ngôn ngữ vừa chọn
CAT_RESTART = {
    "en": "Restart the app to apply the language", "es": "Reinicia la app para aplicar el idioma", "fr": "Redémarrez l'app pour appliquer la langue",
    "de": "App neu starten, um die Sprache zu übernehmen", "pt": "Reinicie o app para aplicar o idioma", "id": "Mulai ulang aplikasi untuk menerapkan bahasa",
    "ru": "Перезапустите приложение, чтобы применить язык", "tr": "Dili uygulamak için uygulamayı yeniden başlatın", "it": "Riavvia l'app per applicare la lingua",
}
