"""Cầu nối MT5 qua EA MỎNG (`exchange = mt5ea`) - TUỲ CHỌN, KHÔNG BAO GIỜ tự bật: chỉ chạy khi người dùng chọn nguồn này trong Cài đặt.

Ý tưởng: dùng cho broker KHÔNG có web terminal MT5. MT5 bản đầy đủ chạy trong một trình giả lập Windows (xem docs/MT5_ON_PHONE.md, tools/mt5_phone/),
một EA nhỏ (xuất từ Cài đặt, hoặc pyea/assets/PyEABridge.mq5.txt) chỉ làm đúng một việc: nối socket tới MÁY CHỦ CỤC BỘ do module này mở (127.0.0.1) và chuyển giá / thực thi lệnh / báo sự kiện.
Toàn bộ logic bot, kiểm tra luật, đối soát, báo động nằm ở app (nhẹ vì chạy ở tốc độ ARM gốc); EA không có logic bot.

Giao thức "PyEA-EA v1": mỗi dòng UTF-8 kết thúc '\\n':  LOẠI|khoá=giá_trị|khoá=giá_trị ...   (giá trị mã hoá phần trăm cho % | = CR LF).
  EA -> app : HELLO (xác thực bằng token), HB (nhịp sống), TICK, EVT (có sự kiện giao dịch), ROW/RES (trả lời yêu cầu)
  app -> EA : WELCOME/DENY, PING (nhịp sống của app), SUB/UNSUB (đăng ký giá), CFG (công tắc người chết), REQ (yêu cầu: rid=...|op=...; ROW/RES trả về cùng rid)
CÔNG TẮC NGƯỜI CHẾT (ở EA): mất liên lạc với app quá N giây thì EA làm theo chính sách (hold | breakeven | close_all), CHỈ với vị thế do app mở (comment 'pyea...'),
và (nếu bật) gửi thông báo tới MT5 mobile; khi app nối lại HELLO báo `dead_fired=1` để app báo động.

Bảo mật: chỉ lắng nghe 127.0.0.1; kết nối đầu tiên phải gửi đúng token (so sánh thời gian hằng) trong 5 giây, nếu không bị ngắt và ghi báo động.
Mọi thứ ở đây CHƯA kiểm với MT5 thật (chỉ kiểm với EA giả trong tests/fake_ea.py). Không import Kivy."""
import base64
import collections
import hmac
import itertools
import os
import re
import socket
import threading
import time

from . import ordertag
from .bridges import BridgeError, MtBackend
from .feeds import TIMEFRAMES
from .mt5ws import Mt5WsBackend
from .sdk import Candle

PROTO = 1
DEFAULT_PORT = 18765
POLICIES = ("hold", "breakeven", "close_all")
EA_TF_MIN = {1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30, 60, 120, 180, 240, 360, 480, 720, 1440, 10080, 43200}
MAX_LINE = 1 << 20
AUTH_WAIT = 5.0


DEINIT_REASON = {0: ("EA tự dừng", True), 1: ("EA bị gỡ khỏi biểu đồ", False), 2: ("EA được biên dịch lại", True), 3: ("đổi mã/khung biểu đồ", True),
                 4: ("biểu đồ bị đóng", False), 5: ("đổi tham số EA", True), 6: ("MT5 đổi tài khoản", True), 7: ("áp mẫu biểu đồ", True),
                 8: ("EA khởi tạo lỗi (thường do token < 8 ký tự)", False), 9: ("MT5 đang đóng", False)}


def explain(cause, auto, need):
    """Mọi cảnh báo cầu nối theo MỘT khuôn: chuyện gì + app/EA/giám sát tự làm gì + bạn cần làm gì (để người dùng biết rõ trường hợp, không đoán)."""
    return "%s\n• Tự khắc phục: %s\n• Bạn cần: %s" % (cause, auto, need)


# ----------------------------------------------------------------------------------------------- mã hoá dòng
_ESC = (("%", "%25"), ("|", "%7C"), ("=", "%3D"), ("\r", "%0D"), ("\n", "%0A"))


def esc(v):
    s = "" if v is None else str(v)
    for a, b in _ESC:
        s = s.replace(a, b)
    return s


def unesc(s):
    for a, b in reversed(_ESC):
        s = s.replace(b, a)
    return s


def enc(typ, **kv):
    return (typ + "".join("|%s=%s" % (k, esc(_fmt(v))) for k, v in kv.items() if v is not None) + "\n").encode("utf-8")


def _fmt(v):
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, float):
        return repr(v)
    return v


def dec(line):
    """'LOẠI|k=v|...' -> (loại, {k: v}). Dòng hỏng -> (None, {})."""
    parts = line.rstrip("\r\n").split("|")
    if not parts or not parts[0]:
        return None, {}
    d = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            d[k] = unesc(v)
    return parts[0], d


def _f(d, k, default=0.0):
    try:
        return float(d.get(k, default))
    except (TypeError, ValueError):
        return float(default)


def _i(d, k, default=0):
    try:
        return int(float(d.get(k, default)))
    except (TypeError, ValueError):
        return int(default)


def classify_exit(code):
    """Mã thoát của MT5/giả lập (bash: 128+tín hiệu) -> (lý do dễ hiểu, có nên tự khởi động lại). Phân loại theo quy ước Linux, CHƯA gặp thật trên máy."""
    try:
        code = int(code)
    except (TypeError, ValueError):
        return "không rõ mã thoát", True
    table = {0: ("MT5 tự thoát bình thường (bị đóng từ MT5, hoặc MT5 tự cập nhật/khởi động lại)", True),
             137: ("bị SIGKILL (mã 137): thường là Android giết vì hết RAM hoặc «phantom process killer» (Android 12+)", True),
             143: ("bị SIGTERM (mã 143): có phần mềm/hệ thống yêu cầu dừng", True),
             139: ("sập SIGSEGV (mã 139): Box64/Wine/MT5 lỗi bộ nhớ - lỗi của giả lập, khởi động lại thường qua được", True),
             134: ("sập SIGABRT (mã 134): Wine/MT5 tự huỷ do lỗi nội bộ", True),
             132: ("sập SIGILL (mã 132): lệnh CPU không hợp lệ - thường do cài đặt Box64 dynarec/phiên bản không hợp CPU", True)}
    return table.get(code, ("thoát với mã %d (lỗi của Wine/MT5; xem dòng log ngay trước đó)" % code, True))


# Từ khoá trong log MT5 (Experts/Journal) -> báo động. Khớp TIẾNG ANH, theo trí nhớ về log MT5, CHƯA kiểm với log thật: MT5 đổi ngôn ngữ log theo ngôn ngữ giao diện.
LOG_RULES = (
    ("login_failed", re.compile(r"authoriz\w* .*failed|invalid account|invalid password|account disabled|wrong password", re.I), "MT5 đăng nhập tài khoản thất bại",
     "MT5 báo đăng nhập tài khoản không được (sai số tài khoản/mật khẩu/máy chủ, hoặc tài khoản bị khoá).", "không - MT5 sẽ không tự sửa sai thông tin.",
     "kiểm tra «Đăng nhập MT5»/«Máy chủ» trong Cài đặt (rồi «Tạo file cấu hình EA»), và mật khẩu đã lưu trong MT5; dòng log gốc xem trong «Xuất chẩn đoán»."),
    ("socket_blocked", re.compile(r"socketconnect.*(fail|error|\b4014\b)|\b4014\b|address .*not allowed|not allowed .*address|url .*not allowed", re.I), "MT5 chặn EA nối vào app",
     "MT5 không cho EA mở kết nối tới 127.0.0.1 (địa chỉ chưa nằm trong danh sách cho phép của MT5, hoặc cổng sai).", "không.",
     "cho phép địa chỉ 127.0.0.1 trong MT5 (Tools > Options > Expert Advisors > Allow WebRequest/socket); bước này chỉ làm 1 lần và là việc DUY NHẤT phải mở MT5 nếu startup.ini không tự đặt được."),
    ("ea_missing", re.compile(r"(cannot|can't|failed to) (load|open|find).*pyeabridge|pyeabridge.*(not found|cannot|failed to load)|expert.*pyeabridge.*(not found|cannot)", re.I), "MT5 không nạp được EA PyEABridge",
     "MT5 báo không tìm thấy hoặc không nạp được EA PyEABridge (chưa chép vào Experts hoặc chưa biên dịch ra .ex5).", "không.",
     "chạy `bash run_mt5_termux.sh setup` (tự chép + biên dịch EA, không cần mở MetaEditor) rồi khởi động lại MT5."),
)


# ----------------------------------------------------------------------------------------------- cài đặt
def problems(settings, require=False):
    out = []
    port = str(settings.get("mt5ea_port") or "").strip()
    if port:
        try:
            p = int(port)
            if not 1024 <= p <= 65535:
                out.append("Cổng EA phải từ 1024 tới 65535")
        except ValueError:
            out.append("Cổng EA phải là số")
    tok = str(settings.get("mt5ea_token") or "")
    if require or tok:
        if len(tok) < 8:
            out.append("Token cầu nối EA cần ít nhất 8 ký tự (EA và app phải dùng CÙNG token)")
        if any(c in tok for c in "|=\r\n\t "):
            out.append("Token không được chứa khoảng trắng và các ký tự | =")
    pol = str(settings.get("mt5ea_policy") or "hold")
    if pol not in POLICIES:
        out.append("Chính sách công tắc người chết phải là hold, breakeven hoặc close_all")
    ds = str(settings.get("mt5ea_deadman_s") or "").strip()
    if ds:
        try:
            if not 5 <= float(ds) <= 3600:
                out.append("Thời gian công tắc người chết phải từ 5 tới 3600 giây")
        except ValueError:
            out.append("Thời gian công tắc người chết phải là số")
    return out


def ea_source():
    """Mã nguồn EA (PyEABridge.mq5) đóng gói trong app dưới tên .mq5.txt (APK chỉ nhận một số đuôi file)."""
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "PyEABridge.mq5.txt")
    with open(p, encoding="utf-8") as f:
        return f.read()


def make_set_file(settings):
    """Nội dung file tham số EA (.set, đặt ở MQL5\\Profiles\\... hoặc MQL5\\presets). Định dạng/bảng mã .set của MT5 chưa kiểm: nếu EA không đọc được thì nhập tay 3 tham số."""
    return "; PyEA bridge - tạo tự động từ Cài đặt\nInpHost=127.0.0.1\nInpPort=%d\nInpToken=%s\nInpDeadmanNotify=true\n" % (
        int(str(settings.get("mt5ea_port") or DEFAULT_PORT)), str(settings.get("mt5ea_token") or ""))


def make_startup_ini(settings):
    """Mẫu startup.ini cho `terminal64.exe /portable /config:startup.ini`. Chỉ có Login/Server trong [Common] theo tài liệu MetaTrader; chỗ lưu mật khẩu CHƯA xác nhận
    (đăng nhập tay một lần để terminal nhớ). Khoá [Experts] bên dưới là theo trí nhớ, chưa kiểm: nếu terminal không nhận thì bật «Cho phép WebRequest/socket tới 127.0.0.1» bằng tay."""
    return ("[Common]\nLogin=%s\nServer=%s\n[Experts]\nEnabled=1\nAllowLiveTrading=1\nWebRequest=1\nWebRequestUrl=127.0.0.1\n"
            "[StartUp]\nExpert=PyEABridge\nSymbol=%s\nPeriod=H1\nExpertParameters=bridge.set\n") % (
        str(settings.get("mt5ea_login") or "").strip(), str(settings.get("mt5ea_server") or "").strip(),
        str(settings.get("mt5ea_symbol") or "EURUSD").strip() or "EURUSD")


# ----------------------------------------------------------------------------------------------- máy chủ cục bộ
class Mt5EaServer:
    """Nhận MỘT kết nối EA tại một thời điểm (kết nối mới thay kết nối cũ). Thread-safe."""

    def __init__(self, port, token, dead_s=20.0, policy="hold", host="127.0.0.1", hb_s=2.0, timeout=15.0):
        if len(str(token or "")) < 8:
            raise BridgeError("Token cầu nối EA quá ngắn (>= 8 ký tự)")
        self.host, self.port, self.token = host, int(port), str(token)
        self.dead_s, self.policy, self.hb_s, self.timeout = float(dead_s), policy, float(hb_s), float(timeout)
        self.push_seq = 0
        self.info = {}
        self.ticks = {}
        self.subs = set()
        self.alerts = []
        self.connects = 0
        self.last_rx = 0.0
        self._sock = None
        self._gen = 0
        self._lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._waiters = {}
        self._ids = itertools.count(1)
        self._stop = threading.Event()
        self._lsock = None
        self._stale_alerted = False
        self._ever = False
        self.broker_ok = True                       # MT5 <-> máy chủ broker (HB.conn)
        self.algo_ok = True                         # Algo Trading/EA được phép giao dịch (HB.ta)
        self._bye = None                            # lý do EA báo trước khi ngắt (BYE)
        self._down_since = None
        self._next_remind = 0.0
        self.remind_first, self.remind_every = 300.0, 1800.0
        self.supervised = False                     # người dùng có chạy script giám sát (chỉ để lời khuyên đúng)
        self._threads = []
        self.diag = collections.deque(maxlen=600)   # nhật ký chẩn đoán: log MT5/giám sát/EA đẩy ra app, để xuất không cần mở MT5
        self.sup = {}                               # trạng thái giám sát: state, restarts, last_exit, last_exit_why, t (đồng hồ monotonic)
        self.sup_seen = 0.0
        self.provision = {}                         # tên file -> nội dung, cấp cho script giám sát qua GET (không cần chép tay)
        self._rule_last = {}
        self._exit_seen = 0.0

    # ---- vòng đời ----
    def start(self):
        if self._lsock:
            return
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((self.host, self.port))
        except OSError as e:
            s.close()
            raise BridgeError("Không mở được cổng %d cho cầu nối EA: %s (cổng đang bị dùng? đổi «mt5ea_port»)" % (self.port, e))
        s.listen(2)
        s.settimeout(0.5)
        self._lsock = s
        if self.port == 0:
            self.port = s.getsockname()[1]
        for fn in (self._accept_loop, self._hb_loop):
            t = threading.Thread(target=fn, daemon=True)
            t.start()
            self._threads.append(t)

    def close(self):
        self._stop.set()
        self._drop(self._sock, "đóng")
        if self._lsock:
            try:
                self._lsock.close()
            except OSError:
                pass
            self._lsock = None

    # ---- trạng thái ----
    @property
    def connected(self):
        return self._sock is not None and bool(self.info)

    def alive(self):
        """Kết nối còn sống: nhận được gì đó từ EA trong 3 nhịp gần nhất."""
        return self.connected and (time.monotonic() - self.last_rx) <= max(3 * self.hb_s, 6.0)

    def alert(self, title, text, critical=True, kind="", auto=None):
        """auto: True = có cơ chế tự hồi phục đang chạy, False = KHÔNG tự hồi phục được (cần người), None = chỉ thông tin."""
        self.alerts.append({"title": title, "text": text, "critical": critical, "t": time.time(), "kind": kind, "auto": auto})
        del self.alerts[:-50]

    def pop_alerts(self):
        with self._lock:
            out, self.alerts = self.alerts, []
        return out

    # ---- nhận kết nối ----
    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._lsock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    def _serve(self, conn):
        conn.settimeout(AUTH_WAIT)
        buf = b""
        authed = False
        sup = False
        gen = None
        try:
            while not self._stop.is_set():
                try:
                    chunk = conn.recv(65536)
                except socket.timeout:
                    if sup:
                        return
                    if not authed:
                        self.alert("Cầu nối EA: kết nối lạ", explain("Có chương trình nối vào cổng %d nhưng không gửi HELLO trong %.0f giây (thường là chương trình khác trên máy dò cổng, hoặc EA treo giữa chừng)." % (self.port, AUTH_WAIT),
                                                                  "đã ngắt kết nối đó, cổng vẫn chờ EA thật.", "không cần làm gì nếu EA vẫn nối bình thường; nếu EA không nối được, đổi mt5ea_port."), critical=False, kind="intruder", auto=True)
                        return
                    if gen != self._gen:
                        return
                    continue
                if not chunk:
                    return
                buf += chunk
                if len(buf) > MAX_LINE and b"\n" not in buf:
                    return
                while b"\n" in buf:
                    raw, buf = buf.split(b"\n", 1)
                    typ, d = dec(raw.decode("utf-8", "replace"))
                    if typ is None:
                        continue
                    if sup:
                        self._handle_sup(conn, typ, d)
                        continue
                    if not authed:
                        if typ not in ("HELLO", "SUPHELLO") or not hmac.compare_digest(str(d.get("token", "")).encode(), self.token.encode()):
                            try:
                                conn.sendall(enc("DENY", err="token sai hoặc không phải HELLO"))
                            except OSError:
                                pass
                            self.alert("Cầu nối EA: token sai", explain("Một chương trình nối vào nhưng sai token (EA đặt sai InpToken, hoặc chương trình lạ).", "không - app từ chối vô thời hạn, EA thử lại 10 giây/lần.",
                                                                  "đặt InpToken của EA đúng bằng «mt5ea_token» trong Cài đặt (xuất lại file bridge.set)."), critical=False, kind="token", auto=False)
                            return
                        if typ == "SUPHELLO":                # kênh giám sát: ngắn hạn, KHÔNG thay kết nối EA
                            sup = True
                            conn.settimeout(10.0)
                            self.sup_seen = time.monotonic()
                            self._send_to(conn, "SUPWELCOME", v=PROTO)
                            continue
                        authed = True
                        conn.settimeout(1.0)
                        gen = self._accept(conn, d)
                        continue
                    if gen != self._gen:
                        return
                    self._handle(typ, d)
        except OSError:
            pass
        finally:
            if authed and gen == self._gen:
                self._lost(conn)
            else:
                try:
                    conn.close()
                except OSError:
                    pass

    def _accept(self, conn, hello):
        if int(hello.get("v", 0) or 0) != PROTO:
            try:
                conn.sendall(enc("DENY", err="phiên bản giao thức %s != %d" % (hello.get("v"), PROTO)))
            except OSError:
                pass
            self.alert("Cầu nối EA: sai phiên bản", explain("EA dùng giao thức v%s, app cần v%d (EA và app khác đời)." % (hello.get("v"), PROTO), "không.",
                                                                   "bấm «Tạo file cấu hình EA» để lấy PyEABridge.mq5 mới, chép vào MT5, biên dịch lại (F7), gắn lại EA."), kind="version", auto=False)
            conn.close()
            return -1
        with self._lock:
            old = self._sock
            self._gen += 1
            gen = self._gen
            self._sock = conn
            self.info = dict(hello)
            self.last_rx = time.monotonic()
            self.connects += 1
            self.push_seq += 1
            self._stale_alerted = False
            first = not self._ever
            self._ever = True
        if old is not None:
            try:
                old.close()
            except OSError:
                pass
        self._send("WELCOME", v=PROTO, dead_s=self.dead_s, policy=self.policy, hb_s=self.hb_s)
        if self.subs:
            self._send("SUB", s=",".join(sorted(self.subs)))
        down = self._down_since
        self._down_since = None
        if _i(hello, "dead_fired"):
            acted = _i(hello, "dead_acted")
            pol = hello.get("dead_policy", "?")
            what = {"hold": "giữ nguyên (không can thiệp, vị thế chỉ dựa vào SL/TP đặt sẵn trên sàn)", "breakeven": "dời SL về giá vào cho %d vị thế đang lời" % acted,
                    "close_all": "đóng/huỷ %d vị thế và lệnh chờ do app mở" % acted}.get(pol, pol)
            self.alert("Công tắc người chết đã chạy", explain(
                "EA mất liên lạc với app quá %.0f giây (lúc %s) nên đã %s (chính sách «%s»). Nguyên nhân app chết/đứng: Android giết app, hết pin/RAM hoặc app treo." % (
                    self.dead_s, time.strftime("%H:%M:%S", time.localtime(_f(hello, "dead_at", time.time()))), what, pol),
                "app đã chạy lại và đối soát với sàn; bot tiếp tục theo phiên đã lưu.", "KIỂM TRA vị thế/lệnh trên sàn rồi mới tin bot; xem vì sao app bị dừng (tối ưu pin, bộ nhớ)."), kind="deadman", auto=None)
        elif not first:
            mins = ("sau %.0f giây" % (time.monotonic() - down)) if down else ""
            self.alert("Cầu nối EA đã nối lại", explain("EA nối lại với app lần thứ %d %s." % (self.connects, mins), "đã nối lại; app đối soát vị thế với sàn.", "không cần."),
                       critical=False, kind="restored", auto=None)
        return gen

    def _lost(self, conn):
        with self._lock:
            if self._sock is conn:
                self._sock = None
                self.info = {}
                self.push_seq += 1
                dead = True
            else:
                dead = False
        try:
            conn.close()
        except OSError:
            pass
        if dead and not self._stop.is_set():
            self._down_since = time.monotonic()
            self._next_remind = self._down_since + self.remind_first
            bye, self._bye = self._bye, None
            self.broker_ok = self.algo_ok = True                  # trạng thái cũ vô nghĩa khi không còn nối
            keep = "Vị thế đang mở vẫn được canh bởi SL/TP trên sàn và công tắc người chết của EA (nếu EA còn sống). Bot KHÔNG đặt được lệnh mới cho tới khi nối lại."
            if bye is not None:
                why, auto_back = DEINIT_REASON.get(_i({"r": bye}, "r", -1), ("lý do %s" % bye, False))
                self.alert("EA đã dừng: " + why, explain("EA báo trước khi ngắt (%s). %s" % (why, keep),
                                                        "EA tự nối lại sau vài giây." if auto_back else "không - EA đã bị dừng/gỡ.",
                                                        "không cần." if auto_back else "gắn lại EA PyEABridge vào biểu đồ (hoặc mở lại MT5 nếu MT5 đã đóng) và bật Algo Trading."),
                           critical=not auto_back, kind="bye", auto=auto_back)
            elif self.sup_recent() and self.sup.get("state") == "running" and time.monotonic() - self._exit_seen > 10:
                self.alert("EA ngắt nhưng MT5 vẫn chạy", explain(
                    "Script giám sát cho biết MT5 vẫn đang chạy, nhưng EA đã ngắt khỏi app (EA bị gỡ/biểu đồ đóng, EA bị dừng, hoặc MT5 đang đóng/khởi động lại EA). " + keep,
                    "EA tự nối lại mỗi 2 giây nếu còn gắn trong biểu đồ.", "nếu vài phút chưa nối lại: chạy `bash run_mt5_termux.sh setup` để cấp lại EA/cấu hình, rồi khởi động lại MT5; xem «Xuất chẩn đoán»."),
                    kind="lost_mt5_up", auto=None)
            else:
                self.alert("MẤT cầu nối EA / MT5", explain(
                    "Ngắt đột ngột, EA không kịp báo: MT5/trình giả lập bị Android giết, hết RAM/pin, MT5 sập, hoặc giả lập tự thoát. " + keep,
                    ("script giám sát sẽ khởi động lại MT5 (nếu đang chạy run_mt5_termux.sh); EA tự nối lại mỗi 2 giây." if self.is_supervised() else
                     "EA tự nối lại mỗi 2 giây NẾU MT5 còn sống; nếu MT5 đã chết thì KHÔNG tự sống lại trừ khi bạn chạy script giám sát run_mt5_termux.sh."),
                    "nếu sau 2-3 phút chưa nối lại: mở Termux/giả lập xem MT5 còn chạy không (log ~/.pyea_mt5.log). App sẽ nhắc lại sau 5 phút nếu vẫn mất."),
                    kind="lost", auto=self.is_supervised() or None)
        for w in list(self._waiters.values()):
            w["err"] = "mất kết nối với EA"
            w["ev"].set()

    def _drop(self, conn, why):
        if conn is not None:
            try:
                conn.close()
            except OSError:
                pass

    # ---- xử lý thông điệp từ EA ----
    def _handle(self, typ, d):
        self.last_rx = time.monotonic()
        if typ == "TICK":
            try:
                self.ticks[d["s"]] = (float(d["b"]), float(d["a"]), float(d.get("t", time.time())), time.monotonic())
            except (KeyError, ValueError):
                pass
        elif typ == "EVT":
            self.push_seq += 1
        elif typ in ("ROW", "RES"):
            w = self._waiters.get(d.get("rid"))
            if w is None:
                return
            if typ == "ROW":
                w["rows"].append(d)
            else:
                w["res"] = d
                w["ev"].set()
        elif typ == "LOG":
            lvl = str(d.get("lvl", "I"))[:1].upper()
            self.diag_add("ea", lvl, d.get("m", ""))
            if lvl == "E":
                self._rate_alert("ea_error", 300.0, "EA báo lỗi", explain("EA PyEABridge báo lỗi: %s" % str(d.get("m", ""))[:300], "không (chỉ ghi nhận).", "xem «Xuất chẩn đoán»; nếu lặp lại, gửi file chẩn đoán cho người hỗ trợ."), False, None)
        elif typ == "BYE":
            self._bye = d.get("reason", "")
        elif typ == "HB":
            self.info["bal"], self.info["eq"] = d.get("bal"), d.get("eq")
            self._health(d)
            if self._stale_alerted:
                self._stale_alerted = False

    # ---- kênh giám sát + chẩn đoán (lỗi chảy ra app, người dùng không phải mở MT5) ----
    def _send_to(self, conn, typ, **kv):
        try:
            conn.sendall(enc(typ, **kv))
            return True
        except OSError:
            return False

    def diag_add(self, src, level, text):
        t = str(text)
        if self.token and self.token in t:
            t = t.replace(self.token, "***")
        self.diag.append((time.time(), src, str(level)[:1].upper() or "I", t[:600]))

    def _rate_alert(self, kind, every, title, text, critical, auto):
        now = time.monotonic()
        if now - self._rule_last.get(kind, -1e9) < every:
            return
        self._rule_last[kind] = now
        self.alert(title, text, critical=critical, kind=kind, auto=auto)

    def sup_recent(self, within=120.0):
        """Script giám sát có báo về gần đây không (tự phát hiện, khỏi phụ thuộc cài đặt «supervised»)."""
        return self.sup_seen > 0 and (time.monotonic() - self.sup_seen) <= within

    def is_supervised(self):
        return self.supervised or self.sup_recent()

    def _handle_sup(self, conn, typ, d):
        self.sup_seen = time.monotonic()
        if typ == "SLOG":
            self.diag_add("giám sát", d.get("lvl", "I"), d.get("m", ""))
        elif typ == "LOGLINE":
            line = str(d.get("text", ""))
            self.diag_add(str(d.get("src", "mt5")), "I", line)
            for kind, rx, title, cause, auto, need in LOG_RULES:
                if rx.search(line):
                    self._rate_alert(kind, 600.0, title, explain(cause + " Dòng log: «%s»" % line[:200], auto, need), True, False)
                    break
        elif typ == "SEVT":
            self._sup_event(d)
        elif typ == "GET":
            name = str(d.get("name", ""))
            body = self.provision.get(name)
            if body is None:
                self._send_to(conn, "FILE", name=name, err="không có file này")
            else:
                self._send_to(conn, "FILE", name=name, b64=base64.b64encode(body.encode("utf-8")).decode("ascii"))

    def _sup_event(self, d):
        kind = str(d.get("kind", ""))
        sup = self.sup
        sup["t"] = time.monotonic()
        self.diag_add("giám sát", "I", "sự kiện " + ", ".join("%s=%s" % (k, v) for k, v in d.items() if k != "token"))
        if kind == "started":
            sup.update(state="running", restarts=_i(d, "restarts"))
        elif kind == "mt5_exit":
            code = _i(d, "code", -1)
            why, _ = classify_exit(code)
            will = _i(d, "will_restart", 1) != 0
            sup.update(state="backoff" if will else "gave_up", last_exit=code, last_exit_why=why, restarts=_i(d, "restarts"))
            self._exit_seen = time.monotonic()
            self.alert("MT5 trong giả lập đã dừng (mã %d)" % code, explain(
                "Script giám sát báo MT5/giả lập thoát: %s. Chạy được %ss, lần dừng thứ %s." % (why, d.get("up", "?"), d.get("restarts", "?")),
                "script đang chờ %ss rồi khởi động lại MT5; EA tự nối lại sau khi MT5 lên." % d.get("wait", "?") if will else "không - script đã bỏ cuộc.",
                "không cần nếu MT5 lên lại; lặp lại nhiều lần thì xem «Xuất chẩn đoán» (có đuôi log giả lập) hoặc đo RAM bằng measure.sh."), kind="mt5_exit", auto=will)
        elif kind == "gave_up":
            sup.update(state="gave_up")
            self.alert("MT5 liên tục chết - script giám sát ĐÃ BỎ CUỘC", explain(
                "MT5 chết nhanh %s lần liên tiếp (mã cuối %s: %s). Bot không còn kết nối." % (d.get("fast", "?"), d.get("code", "?"), classify_exit(d.get("code"))[0]),
                "không - script dừng để khỏi đốt pin.", "xem «Xuất chẩn đoán» để biết lý do; sửa nguyên nhân rồi chạy lại run_mt5_termux.sh."), kind="gave_up", auto=False)
        elif kind == "compile":
            ok = _i(d, "ok") == 1
            self.alert("Biên dịch EA %s" % ("xong" if ok else "LỖI"), explain(
                ("EA PyEABridge biên dịch thành công (%s lỗi, %s cảnh báo)." % (d.get("errors", 0), d.get("warnings", 0))) if ok else
                ("EA PyEABridge biên dịch lỗi (%s lỗi): %s" % (d.get("errors", "?"), str(d.get("excerpt", ""))[:500])),
                "không." if not ok else "—", ("không cần." if ok else "lỗi đã nằm sẵn trong «Xuất chẩn đoán»; gửi file đó để sửa EA, không cần mở MetaEditor.")),
                critical=not ok, kind="compile_ok" if ok else "compile_fail", auto=None if ok else False)
        elif kind == "provision":
            ok = _i(d, "ok") == 1
            if not ok:
                self.alert("Không cấp được file cho MT5", explain("Script giám sát không lấy/ghi được «%s»: %s" % (d.get("name", "?"), d.get("detail", "")), "không.", "kiểm tra MT5_DIR của script và quyền ghi thư mục."),
                           kind="provision_fail", auto=False)
        elif kind == "setup":
            self.alert("Lỗi thiết lập giả lập", explain(str(d.get("msg", ""))[:400], "không.", "xem «Xuất chẩn đoán»."), kind="setup", auto=False)

    def diagnostics_text(self):
        """Báo cáo chẩn đoán dán/gửi được: trạng thái cầu nối + nhật ký log MT5/giám sát/EA. Token luôn bị che."""
        now = time.time()
        info = {k: v for k, v in self.info.items() if k != "token"}
        lines = ["PyEA - chẩn đoán cầu nối EA (%s)" % time.strftime("%F %T", time.localtime(now)),
                 "cổng=%d proto=v%d nối=%s đã_nối_lần=%d broker_ok=%s algo_ok=%s" % (self.port, PROTO, self.connected, self.connects, self.broker_ok, self.algo_ok),
                 "EA: %s" % (", ".join("%s=%s" % kv for kv in sorted(info.items())) or "chưa nối"),
                 "giám sát: %s" % (", ".join("%s=%s" % (k, v) for k, v in sorted(self.sup.items()) if k != "t") or ("chưa thấy" if not self.sup_recent() else "có")),
                 "token: ***", "--- nhật ký (%d dòng gần nhất) ---" % len(self.diag)]
        for t, src, lvl, txt in list(self.diag):
            lines.append("%s %-9s %s %s" % (time.strftime("%H:%M:%S", time.localtime(t)), src, lvl, txt))
        out = "\n".join(lines) + "\n"
        return out.replace(self.token, "***") if self.token else out

    def _health(self, d):
        """HB.conn (MT5 còn nối máy chủ broker?) và HB.ta (Algo Trading bật?): báo khi ĐỔI trạng thái, không báo lặp."""
        conn_ok = d.get("conn", "1") != "0"
        ta_ok = d.get("ta", "1") != "0"
        if conn_ok != self.broker_ok:
            self.broker_ok = conn_ok
            self.push_seq += 1
            if not conn_ok:
                self.alert("MT5 MẤT kết nối tới máy chủ broker", explain(
                    "MT5 vẫn chạy và EA vẫn nối app, nhưng MT5 không nối được máy chủ giao dịch (mạng điện thoại, sai/ngưng máy chủ, bảo trì broker, tài khoản bị khoá hoặc đổi mật khẩu). "
                    "Giá đứng, KHÔNG đặt/đóng lệnh được; SL/TP trên sàn vẫn hoạt động.", "MT5 tự thử nối lại liên tục.",
                    "nếu quá vài phút: kiểm tra mạng, mở MT5 xem tab Nhật ký (Journal) để biết lý do (sai mật khẩu? máy chủ?), kiểm tra tài khoản với broker."), kind="broker_down", auto=True)
            else:
                self.alert("MT5 đã nối lại máy chủ broker", explain("MT5 nối lại được máy chủ giao dịch.", "đã tự nối lại; app đối soát với sàn.", "không cần."), critical=False, kind="broker_up", auto=None)
        if ta_ok != self.algo_ok:
            self.algo_ok = ta_ok
            self.push_seq += 1
            if not ta_ok:
                self.alert("MT5 không cho EA giao dịch", explain(
                    "Algo Trading đang TẮT hoặc tài khoản không cho giao dịch (mật khẩu investor, tài khoản chỉ đọc). Lệnh sẽ bị MT5 từ chối.", "không.",
                    "bật nút «Algo Trading» của MT5, bật «Cho phép giao dịch thuật toán» trong thuộc tính EA, và dùng mật khẩu GIAO DỊCH (không phải investor)."), kind="algo_off", auto=False)
            else:
                self.alert("MT5 cho EA giao dịch lại", explain("Algo Trading đã bật lại.", "—", "không cần."), critical=False, kind="algo_on", auto=None)

    def _hb_loop(self):
        while not self._stop.wait(self.hb_s):
            if self._sock is None:
                if self._down_since and time.monotonic() >= self._next_remind and not self._stop.is_set():
                    mins = (time.monotonic() - self._down_since) / 60.0
                    self._next_remind = time.monotonic() + self.remind_every
                    self.alert("VẪN mất cầu nối EA (%.0f phút)" % mins, explain(
                        "EA/MT5 vẫn chưa nối lại sau %.0f phút; bot không đặt được lệnh." % mins, "không tự hồi phục được (đã quá thời gian bình thường).",
                        "mở MT5/giả lập kiểm tra; nếu giả lập đã bị Android đóng thì mở lại; xem log script giám sát."), kind="lost_long", auto=False)
                continue
            self._send("PING", t=time.time())
            if time.monotonic() - self.last_rx > max(3 * self.hb_s, 6.0) and not self._stale_alerted:
                self._stale_alerted = True
                self.alert("EA không phản hồi", explain("EA vẫn nối nhưng im lặng quá %.0f giây: MT5 đứng/treo, hoặc giả lập bị Android làm chậm/đóng băng (tiết kiệm pin, RAM thấp)." % max(3 * self.hb_s, 6.0),
                                                           "KHÔNG - app không tự sửa được MT5 đang treo (script giám sát chỉ thấy tiến trình còn sống nên không khởi động lại). Công tắc người chết của EA cũng không chạy vì EA đứng.",
                                                           "mở giả lập xem MT5 có treo không; thoát hẳn và mở lại. Bot không đặt được lệnh trong lúc này; SL/TP trên sàn vẫn hoạt động."), kind="frozen", auto=False)

    def _send(self, typ, **kv):
        s = self._sock
        if s is None:
            return False
        try:
            with self._send_lock:
                s.sendall(enc(typ, **kv))
            return True
        except OSError:
            return False

    # ---- gọi yêu cầu ----
    def configure(self, dead_s=None, policy=None):
        if dead_s is not None:
            self.dead_s = float(dead_s)
        if policy is not None:
            self.policy = policy
        self._send("CFG", dead_s=self.dead_s, policy=self.policy)

    def subscribe(self, symbols):
        new = set(symbols) - self.subs
        if new:
            self.subs |= new
            self._send("SUB", s=",".join(sorted(new)))

    def call(self, op, timeout=None, **params):
        """Gửi REQ và đợi RES. Trả (rows, res). Lỗi từ EA (ok=0) -> BridgeError với nội dung EA trả."""
        if self._sock is None:
            raise BridgeError("Cầu nối EA CHƯA nối. Hãy mở MT5 trong trình giả lập với EA PyEABridge (cổng %d, cùng token)%s." % (
                self.port, "" if not self._ever else " - đã từng nối nhưng đang mất kết nối"))
        rid = str(next(self._ids))
        w = {"ev": threading.Event(), "rows": [], "res": None, "err": None}
        self._waiters[rid] = w
        try:
            if not self._send("REQ", rid=rid, op=op, **params):
                raise BridgeError("Gửi tới EA lỗi (mất kết nối)")
            if not w["ev"].wait(timeout or self.timeout):
                raise BridgeError("EA không trả lời «%s» trong %.0f giây" % (op, timeout or self.timeout))
            if w["err"]:
                raise BridgeError("EA: " + w["err"])
            res = w["res"] or {}
            if not _i(res, "ok", 1):
                raise BridgeError("MT5 từ chối «%s»: %s%s" % (op, res.get("err", "không rõ lý do"), (" (mã %s)" % res["code"]) if res.get("code") else ""))
            return w["rows"], res
        finally:
            self._waiters.pop(rid, None)


# ----------------------------------------------------------------------------------------------- backend
class Mt5EaBackend(MtBackend):
    name = "mt5ea"
    limiter_kind = "generic"
    can_modify_position = True
    native_tfs = [k for k, v in TIMEFRAMES.items() if v // 60 in EA_TF_MIN]
    DEAL_REASON = Mt5WsBackend.DEAL_REASON
    VERIFY_GAP = 1.5

    def __init__(self, server, deviation=20, filling="auto"):
        self.c = server                                  # `MtBroker.change_seq` đọc c.push_seq -> đối soát sớm khi EA báo sự kiện
        self.deviation, self.filling = int(deviation), filling
        self._spec = {}
        self._syms = None
        self.c.start()

    # ---- đọc ----
    def pop_alerts(self):
        return self.c.pop_alerts()

    def ping(self):
        _, r = self.c.call("info", timeout=8)
        return r

    def symbols(self):
        if self._syms is None:
            rows, _ = self.c.call("symbols", timeout=30)
            self._syms = [r["s"] for r in rows]
        return list(self._syms)

    def tick(self, symbol):
        self.c.subscribe([symbol])
        end = time.monotonic() + 3.0
        while time.monotonic() < end:
            t = self.c.ticks.get(symbol)
            if t and time.monotonic() - t[3] < 5.0 and t[0] > 0 and t[1] > 0:
                return t[0], t[1], t[2]
            time.sleep(0.05)
        _, r = self.c.call("tick", s=symbol)
        b, a = _f(r, "b"), _f(r, "a")
        if b <= 0 or a <= 0:
            raise BridgeError("Chưa có giá %s từ MT5 (thị trường đóng cửa?)" % symbol)
        return b, a, _f(r, "t", time.time())

    def candles(self, symbol, tf, count, end=None):
        step = TIMEFRAMES.get(tf)
        if not step or step // 60 not in EA_TF_MIN:
            raise BridgeError("MT5 qua EA không có khung %s" % tf)
        rows, _ = self.c.call("candles", timeout=30, s=symbol, tf=step // 60, n=int(count), end=(int(end) if end is not None else None))
        out = [Candle(_f(r, "t"), _f(r, "o"), _f(r, "h"), _f(r, "l"), _f(r, "c"), _f(r, "v")) for r in rows]
        return sorted(out, key=lambda c: c.time)[-int(count):]

    def account(self):
        _, r = self.c.call("account")
        eq = _f(r, "equity")
        return {"balance": _f(r, "balance"), "equity": eq, "margin": _f(r, "margin"), "free_margin": _f(r, "free_margin"), "margin_level": _f(r, "margin_level") or None,
                "margin_estimated": False, "profit": _f(r, "profit"), "credit": _f(r, "credit"), "leverage": _f(r, "leverage", 1) or 1.0, "currency": r.get("currency", ""),
                "hedging": bool(_i(r, "hedging")), "platform": "MT5 (EA)", "demo": bool(_i(r, "demo")), "server": r.get("server", ""), "company": r.get("company", ""),
                "name": r.get("name", ""), "trade_allowed": bool(_i(r, "trade_allowed", 1))}

    def positions(self):
        rows, _ = self.c.call("positions")
        out = []
        for r in rows:
            magic, reason = _i(r, "magic"), _i(r, "reason", -1)
            out.append({"id": r["id"], "symbol": r["s"], "side": r["side"], "volume": _f(r, "vol"), "price": _f(r, "price"), "sl": _f(r, "sl"), "tp": _f(r, "tp"),
                        "time": _f(r, "t"), "comment": r.get("comment", ""), "profit": _f(r, "profit"), "swap": _f(r, "swap"), "commission": 0.0, "magic": magic,
                        "origin": ordertag.classify(r.get("comment", ""), magic, None if reason < 0 else reason), "reason_code": reason})
        return out

    def orders(self):
        rows, _ = self.c.call("orders")
        return [{"id": r["id"], "symbol": r["s"], "side": r["side"], "kind": r["kind"], "volume": _f(r, "vol"), "price": _f(r, "price"), "sl": _f(r, "sl"), "tp": _f(r, "tp"),
                 "stop_price": (_f(r, "stop") or None) if r["kind"] == "stop_limit" else None, "type_code": _i(r, "type"), "comment": r.get("comment", ""), "magic": _i(r, "magic"),
                 "origin": ordertag.classify(r.get("comment", ""), _i(r, "magic"))} for r in rows]

    def spec(self, symbol):
        if symbol not in self._spec:
            _, r = self.c.call("spec", s=symbol)
            vstep = _f(r, "volume_step")
            if vstep <= 0:
                raise BridgeError("MT5 trả bước khối lượng không hợp lệ cho %s" % symbol)
            self._spec[symbol] = {"volume_min": _f(r, "volume_min"), "volume_max": _f(r, "volume_max") or 1e9, "volume_step": vstep, "digits": _i(r, "digits"),
                                  "contract_size": _f(r, "contract_size"), "tick_size": _f(r, "tick_size"), "tick_value": _f(r, "tick_value"), "point": _f(r, "point"),
                                  "stops_level": _i(r, "stops_level"), "freeze_level": _i(r, "freeze_level"), "trade_mode": _i(r, "trade_mode"), "fill_flags": _i(r, "fill_flags"),
                                  "time_flags": _i(r, "time_flags"), "calc_mode": _i(r, "calc_mode"), "ccy_base": r.get("ccy_base", ""), "ccy_profit": r.get("ccy_profit", ""),
                                  "ccy_margin": r.get("ccy_margin", ""), "swap_long": _f(r, "swap_long"), "swap_short": _f(r, "swap_short"), "swap_mode": _i(r, "swap_mode"),
                                  "margin_initial": _f(r, "margin_initial")}
        return dict(self._spec[symbol])

    # ---- giao dịch ----
    @staticmethod
    def _nonce(base):
        n = "%08x" % (int.from_bytes(os.urandom(4), "big") | 1)
        return n, "%s~%s" % ((base or "pyea")[:22], n)

    def _trade(self, op, verify, what, **params):
        """EA trả kết quả đồng bộ. Nếu MẤT trả lời (hết giờ/ngắt) thì KHÔNG đoán: đọc lại sàn xem lệnh đã vào chưa (theo nhãn), không chắc thì báo lỗi rõ."""
        if not self.c.broker_ok:
            raise BridgeError("MT5 đang MẤT kết nối tới máy chủ broker nên chưa đặt được %s. Đợi MT5 nối lại (xem cảnh báo)." % what)
        if not self.c.algo_ok:
            raise BridgeError("MT5 không cho EA giao dịch (Algo Trading tắt?) nên chưa đặt được %s." % what)
        try:
            _, r = self.c.call(op, timeout=20, **params)
            return {"order_id": r.get("order", ""), "position_id": r.get("position", "") or r.get("order", ""), "price": _f(r, "price") or None, "volume": _f(r, "volume") or None}
        except BridgeError as e:
            lost = "không trả lời" in str(e) or "mất kết nối" in str(e) or "Gửi tới EA lỗi" in str(e)
            if not lost:
                raise
            time.sleep(self.VERIFY_GAP)
            try:
                v = verify()
            except BridgeError:
                v = None
            if v is not None:
                v["verified"] = True
                return v
            raise BridgeError("Không chắc %s đã được MT5 nhận hay chưa (mất liên lạc với EA). KIỂM TRA vị thế/lệnh trên MT5 trước khi gửi lại. (%s)" % (what, e))

    def market(self, symbol, side, volume, comment=""):
        nonce, tagged = self._nonce(comment)

        def verify():
            for p in self.positions():
                if nonce in p.get("comment", ""):
                    return {"order_id": "", "position_id": p["id"], "price": p["price"], "volume": p["volume"]}
            return None
        return self._trade("market", verify, "lệnh %s %s" % (side, symbol), s=symbol, side=side, vol=float(volume), comment=tagged, dev=self.deviation, fill=self.filling)

    def close_position(self, position_id, volume=None):
        v0 = next((p["volume"] for p in self.positions() if p["id"] == str(position_id)), None)
        if v0 is None:
            raise BridgeError("Không thấy vị thế #%s trên MT5" % position_id)

        def verify():
            now = next((p["volume"] for p in self.positions() if p["id"] == str(position_id)), 0.0)
            want = v0 if volume is None else min(v0, float(volume))
            return {"order_id": "", "position_id": str(position_id), "price": None, "volume": want} if now <= v0 - want + 1e-9 else None
        r = self._trade("close", verify, "lệnh đóng #%s" % position_id, id=position_id, vol=(float(volume) if volume is not None else None), comment="pyea", dev=self.deviation, fill=self.filling)
        r["position_id"] = str(position_id)
        return r

    def modify_position(self, position_id, sl, tp):
        self.c.call("modify_pos", timeout=15, id=position_id, sl=float(sl or 0), tp=float(tp or 0))
        return True

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        if kind not in ("limit", "stop", "stop_limit"):
            raise BridgeError("MT5: lệnh chờ '%s' chưa được hỗ trợ native" % kind)
        nonce, tagged = self._nonce(comment)

        def verify():
            for o in self.orders():
                if nonce in o.get("comment", ""):
                    return {"order_id": o["id"], "position_id": "", "price": o["price"], "volume": o["volume"]}
            return None
        r = self._trade("pending", verify, "lệnh chờ %s %s %s" % (kind, side, symbol), s=symbol, side=side, kind=kind, vol=float(volume), price=float(price),
                        stop=(float(stop_price) if stop_price else None), exp=(int(expiry) if expiry else None), comment=tagged, dev=self.deviation)
        r["position_id"] = ""
        return r

    def modify_pending(self, order_id, price=None, sl=None, tp=None, stop_price=None, expiry=None):
        self.c.call("modify_pending", timeout=15, id=order_id, price=price, sl=sl, tp=tp, stop=stop_price, exp=(int(expiry) if expiry else None))
        return True

    def cancel_pending(self, order_id):
        self.c.call("cancel", timeout=15, id=order_id)
        return True

    # ---- lịch sử ----
    def _deals(self, since, until):
        rows, _ = self.c.call("history", timeout=60, frm=int(since), to=int(until))
        out = []
        for d in rows:
            typ, ent = _i(d, "type", -1), _i(d, "entry", -1)
            kind = "trade" if typ in (0, 1) else "balance" if typ == 2 else "credit" if typ == 3 else "other"
            magic = _i(d, "magic")
            out.append({"id": d["id"], "time": _f(d, "t"), "symbol": d.get("s", ""), "side": "sell" if typ == 1 else "buy" if typ == 0 else "", "qty": _f(d, "vol"),
                        "price": _f(d, "price"), "fee": _f(d, "commission") + _f(d, "swap") + _f(d, "fee"), "pnl": _f(d, "profit") if kind == "trade" else 0.0,
                        "order_id": d.get("order", ""), "position_id": d.get("position", ""), "entry": {0: "IN", 1: "OUT", 2: "INOUT", 3: "OUT_BY"}.get(ent, "") if kind == "trade" else "",
                        "reason": self.DEAL_REASON.get(_i(d, "reason", -1), ""), "profit": _f(d, "profit"), "commission": _f(d, "commission"), "swap": _f(d, "swap"), "kind": kind,
                        "comment": d.get("comment", ""), "magic": magic, "origin": ordertag.classify(d.get("comment", ""), magic), "price_close": 0.0, "sl": 0.0, "tp": 0.0})
        return sorted(out, key=lambda x: x["time"])

    def deals(self, since):
        return [x for x in self._deals(since, time.time() + 3600) if x["kind"] == "trade" and x["qty"] > 0]

    def history(self, since, until=None):
        return self._deals(since, until or time.time() + 3600)

    def deals_by_position(self, position_id):
        pid = str(position_id)
        return [x for x in self._deals(time.time() - 90 * 86400, time.time() + 3600) if x["position_id"] == pid and x["kind"] == "trade"]

    # ---- tiện ích ----
    def notify_mobile(self, text):
        self.c.call("notify", text=str(text)[:128])
        return True

    def close(self):
        self.c.close()


_SERVERS = {}


def make_backend(settings):
    bad = problems(settings, require=True)
    if bad:
        raise BridgeError("Cài đặt cầu nối EA chưa đúng:\n- " + "\n- ".join(bad))
    port = int(str(settings.get("mt5ea_port") or DEFAULT_PORT))
    dead = float(str(settings.get("mt5ea_deadman_s") or 20))
    pol = str(settings.get("mt5ea_policy") or "hold")
    srv = _SERVERS.get(port)
    if srv is None or srv._stop.is_set() or srv.token != str(settings.get("mt5ea_token")):
        if srv is not None:
            srv.close()
        srv = Mt5EaServer(port, str(settings.get("mt5ea_token")), dead, pol)
        _SERVERS[port] = srv
        srv.supervised = str(settings.get("mt5ea_supervised") or "no") == "yes"
    else:
        srv.configure(dead, pol)
    srv.supervised = str(settings.get("mt5ea_supervised") or "no") == "yes"
    srv.provision = {"PyEABridge.mq5": ea_source(), "bridge.set": make_set_file(settings), "startup.ini": make_startup_ini(settings)}
    return Mt5EaBackend(srv, int(str(settings.get("mt5ea_deviation") or 20)), str(settings.get("mt5ea_filling") or "auto"))


def selftest(settings, trade=False, symbol=None, log=None, wait=20.0):
    """Từng bước: mở cổng -> đợi EA nối -> đọc tài khoản/giá/vị thế. Trả [(mức, nội dung)]. `trade` KHÔNG được hỗ trợ ở đây (dùng DEMO + nút thử lệnh của MT5 trực tiếp sau khi chạy ổn)."""
    out = []

    def add(level, text):
        out.append((level, text))
        if log:
            log(level, text)
    try:
        b = make_backend(settings)
    except BridgeError as e:
        add("LỖI", str(e))
        return out
    add("OK", "Đã mở cổng cục bộ 127.0.0.1:%d, đang đợi EA nối (tối đa %.0f giây)..." % (b.c.port, wait))
    end = time.monotonic() + wait
    while time.monotonic() < end and not b.c.alive():
        time.sleep(0.2)
    if not b.c.alive():
        add("LỖI", "EA chưa nối. Kiểm tra: MT5 đã chạy trong giả lập? EA PyEABridge đã gắn vào biểu đồ và bật «Algo Trading»? Địa chỉ 127.0.0.1:%d đã được cho phép trong "
                   "Tools > Options > Expert Advisors? Token EA khớp Cài đặt?" % b.c.port)
        for a in b.pop_alerts():
            add("CHÚ Ý", "%s: %s" % (a["title"], a["text"]))
        return out
    i = b.c.info
    add("OK", "EA đã nối: tài khoản %s @ %s (%s), build %s, EA v%s." % (i.get("login", "?"), i.get("server", "?"), i.get("company", "?"), i.get("build", "?"), i.get("ea", "?")))
    try:
        a = b.account()
        add("OK", "Tài khoản %s: số dư %.2f %s, vốn %.2f, %s, %s." % (a["name"] or a["server"], a["balance"], a["currency"], a["equity"], "hedging" if a["hedging"] else "netting",
                                                                    "DEMO" if a["demo"] else "THẬT"))
        if not a["trade_allowed"]:
            add("CHÚ Ý", "Tài khoản/EA không được phép giao dịch (bật «Algo Trading», tắt mật khẩu investor).")
        names = b.symbols()
        sym = symbol or next((n for n in ("EURUSD", "XAUUSD", "GBPUSD") if n in names), names[0] if names else None)
        if sym:
            bid, ask, _ = b.tick(sym)
            add("OK", "Giá %s: bid %s / ask %s." % (sym, bid, ask))
        add("OK", "Vị thế đang mở: %d, lệnh chờ: %d." % (len(b.positions()), len(b.orders())))
        add("OK", "Công tắc người chết: %.0f giây, chính sách «%s» (chỉ áp cho vị thế comment 'pyea')." % (b.c.dead_s, b.c.policy))
    except BridgeError as e:
        add("LỖI", str(e))
    return out
