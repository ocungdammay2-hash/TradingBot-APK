"""Hộp thoại «Dữ liệu nến đã lưu» của tab Backtest: xem kho, xuất CSV, nhập CSV, xoá. Logic nằm ở pyea/candlestore.py (kiểm thử được không cần Kivy)."""
import os
import time

from kivy.clock import mainthread
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserListView

from . import android_utils
from . import candlestore as cst
from .feeds import TIMEFRAMES
from .ui_widgets import (AMBER, BLUE, DOWN, GREEN, MIN_TOUCH, MUTED, PANEL2, StyledPopup, mk_input, mk_spinner, mkbtn, popup, vbox, vscroll,
                         wlabel)

SRC_LABEL = {cst.FILE_SOURCE: "file đã nhập"}


def _fmt_t(t):
    return time.strftime("%Y-%m-%d", time.gmtime(t))


def _size(b):
    return "%.1f MB" % (b / 1048576.0) if b >= 1048576 else "%d KB" % max(1, b // 1024)


def describe(e):
    return "%s · %s · %s\n%d nến · %s → %s · %s" % (SRC_LABEL.get(e["source"], e["source"]), e["symbol"], e["tf"], e["count"],
                                                 _fmt_t(e["first"]), _fmt_t(e["last"]), _size(e["bytes"]))


def open_data_dialog(tab):
    """tab: BacktestTab (cần tab.app, tab.candle_store(), tab.form)."""
    store = tab.candle_store()
    box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    body = vbox(spacing=dp(6))
    pop = StyledPopup(title="Dữ liệu nến đã lưu", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)

    def rebuild():
        body.clear_widgets()
        items = store.list()
        total = sum(e["bytes"] for e in items)
        body.add_widget(wlabel("Backtest tự lưu nến đã tải để lần sau chỉ tải phần còn thiếu (nến mới + khoảng cũ hơn nếu cần). "
                               "Xuất ra CSV để mang sang máy khác rồi «Nhập CSV». Tổng: %d chuỗi, %s." % (len(items), _size(total)), 12, MUTED))
        if not items:
            body.add_widget(wlabel("Chưa có dữ liệu nào. Chạy một backtest (nguồn «Sàn») hoặc nhập CSV.", 13, AMBER))
        for e in items:
            body.add_widget(wlabel(describe(e), 13))
            row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
            row.add_widget(mkbtn("Xuất CSV", BLUE, size=12, on_release=lambda *_, e=e: do_export(e)))
            row.add_widget(mkbtn("Xoá", PANEL2, size=12, on_release=lambda *_, e=e: do_delete(e)))
            body.add_widget(row)

    def do_export(e):
        try:
            path = cst.export_csv(store, e["source"], e["symbol"], e["tf"], tab.app.store.exports_dir)
        except (OSError, ValueError) as ex:
            tab.app.toast("Không xuất được: %s" % ex)
            return
        popup("Đã xuất CSV", "File:\n%s\n\nChép file này sang máy khác (cáp/Drive/Zalo...) rồi dùng «Nhập CSV». Giờ trong file là UTC." % path, size=(0.92, 0.5))

    def do_delete(e):
        store.delete(e["source"], e["symbol"], e["tf"])
        rebuild()

    def do_clear(*_):
        n = store.clear()
        tab.app.toast("Đã xoá %d chuỗi dữ liệu." % n)
        rebuild()

    def start_import(*_):
        if android_utils.IS_ANDROID:
            android_utils.pick_file(lambda name, text, err: on_text(name, text, err))
            return
        chooser = FileChooserListView(filters=["*.csv", "*.txt"], path=os.path.expanduser("~"))
        b2 = BoxLayout(orientation="vertical", spacing=dp(6))
        b2.add_widget(chooser)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        p2 = StyledPopup(title="Chọn file CSV nến", content=b2, size_hint=(0.95, 0.9))

        def ok(*_):
            if chooser.selection:
                p2.dismiss()
                try:
                    with open(chooser.selection[0], "r", encoding="utf-8-sig", errors="replace") as f:
                        on_text(os.path.basename(chooser.selection[0]), f.read(), None)
                except OSError as ex:
                    tab.app.toast("Không đọc được file: %s" % ex)
        r2.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: p2.dismiss()))
        r2.add_widget(mkbtn("Chọn", GREEN, on_release=ok))
        b2.add_widget(r2)
        p2.open()

    @mainthread
    def on_text(name, text, err):
        if err == "cancelled":
            return
        if err or text is None:
            tab.app.toast("Không đọc được file:\n%s" % (err or ""))
            return
        confirm_import(name, text.lstrip("﻿"))

    def confirm_import(name, text):
        try:
            candles, info = cst.parse_csv(text)
        except ValueError as ex:
            popup("File CSV không dùng được", str(ex), size=(0.9, 0.45), color=DOWN)
            return
        det = cst.detect_tf(candles)
        vals, _errs = tab.form.read()
        sym0 = (vals or {}).get("symbol", "") if isinstance(vals, dict) else ""
        guess = os.path.splitext(name or "")[0].upper().split("_")[0].split("-")[0] if name else ""
        c = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        c.add_widget(wlabel("%s\n%d nến · %s → %s · khung nhận ra: %s%s\nGiờ trong file được coi là UTC." % (
            name, len(candles), _fmt_t(candles[0].time), _fmt_t(candles[-1].time), det or "không nhận ra",
            (" · bỏ %d dòng lỗi/nến rác" % info["skipped"]) if info["skipped"] else ""), 12))
        sym = mk_input(sym0 or guess, "Tên mã (vd XAUUSD) - dùng đúng tên này ở ô «Tài sản» khi backtest")
        c.add_widget(sym)
        tfs = mk_spinner(det or "5m", list(TIMEFRAMES))
        c.add_widget(tfs)
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        p3 = StyledPopup(title="Nhập dữ liệu nến", content=c, size_hint=(0.95, 0.65), auto_dismiss=False)

        def go(*_):
            try:
                res = cst.import_csv_text(tab.candle_store(), text, sym.text, tfs.text)
            except ValueError as ex:
                tab.app.toast(str(ex))
                return
            p3.dismiss()
            tab.app.toast("Đã nhập %d nến %s %s. Backtest: chọn «Nguồn dữ liệu» = File đã nhập." % (res["count"], res["symbol"], res["tf"]))
            rebuild()
        r.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: p3.dismiss()))
        r.add_widget(mkbtn("Nhập", GREEN, on_release=go))
        c.add_widget(r)
        p3.open()

    rebuild()
    box.add_widget(vscroll(body))
    row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
    row.add_widget(mkbtn("Nhập CSV", GREEN, size=12, on_release=start_import))
    row.add_widget(mkbtn("Xoá hết", PANEL2, size=12, on_release=do_clear))
    row.add_widget(mkbtn("Đóng", BLUE, size=12, on_release=lambda *_: pop.dismiss()))
    box.add_widget(row)
    pop.open()
