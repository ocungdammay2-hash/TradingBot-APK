"""
Giới hạn tốc độ gọi API THEO TỪNG SÀN (vỏ lo, bot không phải quan tâm).

  RateLimiter   : cửa sổ trượt nhiều luật (vd 1000 điểm/60s VÀ 10 lần/giây), mỗi request có "trọng số" (cost),
                  chặn (sleep) tới khi còn chỗ; có backoff khi sàn trả 429/418/5xx; đọc header "đã dùng" của sàn.
  limiter_for   : kho dùng chung - feed và broker của CÙNG một sàn+URL chia nhau MỘT ngân sách.
  PRESETS       : mức mặc định THẬN TRỌNG (thấp hơn mức sàn công bố) - sàn nào công bố giới hạn qua API (Exness
                  /limits) thì adapter gọi set_rules() để ghi đè bằng số thật.

Nguyên tắc: không bao giờ retry vô hạn. Chờ quá `max_wait` thì ném RateLimitError để tầng trên báo lỗi rõ ràng
thay vì treo luồng giá/lệnh.
"""
import threading
import time
from collections import deque


class RateLimitError(Exception):
    """Phải chờ lâu hơn mức cho phép (hoặc sàn đang cấm tạm) - không gửi request."""

    def __init__(self, msg, wait=0.0):
        Exception.__init__(self, msg)
        self.wait = wait


# (số điểm, cửa sổ giây) - THẬN TRỌNG, thấp hơn mức công bố của sàn để còn dư cho các app khác dùng chung IP/key.
PRESETS = {
    "binance_spot": [(1000, 60.0)],                     # sàn công bố trần theo weight/phút/IP - giữ dư; 429/418 + header used-weight chỉnh tiếp
    "binance_futures": [(1800, 60.0)],                  # Futures: trần 2400 weight/phút/IP
    "oanda": [(100, 1.0)],                              # sàn: ~120 req/giây/kết nối
    "capital": [(8, 1.0)],                              # tài liệu: 10 yêu cầu/giây/người dùng; tạo vị thế/lệnh chờ 1 yêu cầu/0,1 giây; POST /session 1/giây
    "exness": [(8, 1.0), (300, 60.0)],                  # tạm thời, ghi đè bằng GET .../limits ngay khi kết nối
    "metaapi": [(30, 1.0), (1200, 60.0)],               # MetaApi tính theo "chi phí" mỗi request; 429 -> backoff
    "mt5gw": [(50, 1.0)],                               # cổng tự dựng của người dùng
    "ccxt": [(20, 1.0)],                                # ccxt tự có enableRateLimit; đây là lớp bảo hiểm thứ hai
    "generic": [(20, 1.0)],
}


class RateLimiter:
    def __init__(self, name="generic", rules=None, max_wait=30.0, clock=time.monotonic, sleep=time.sleep):
        self.name = name
        self.rules = [(float(a), float(b)) for a, b in (rules or PRESETS["generic"])]
        self.max_wait = float(max_wait)
        self._clock, self._sleep = clock, sleep
        self._lock = threading.Lock()
        self._log = deque()                 # (t, cost)
        self._blocked_until = 0.0
        self._observed = None               # (t, used, limit, window) do sàn báo qua header
        self.stats_ = {"calls": 0, "waits": 0, "waited_s": 0.0, "penalties": 0, "last_penalty": ""}

    # ---- cấu hình ----
    def set_rules(self, rules):
        with self._lock:
            self.rules = [(float(a), float(b)) for a, b in rules if float(a) > 0 and float(b) > 0] or self.rules

    # ---- tính chỗ trống ----
    def _prune(self, now):
        horizon = max(w for _, w in self.rules)
        while self._log and now - self._log[0][0] > horizon:
            self._log.popleft()

    def _need_wait(self, now, cost):
        """Số giây phải chờ để gửi được request `cost` (0 = gửi ngay). Gọi khi đang giữ lock."""
        wait = max(0.0, self._blocked_until - now)
        self._prune(now)
        for limit, window in self.rules:
            c = min(cost, limit)            # request nặng hơn cả hạn mức: coi như dùng hết 1 cửa sổ, không chặn vĩnh viễn
            used = sum(x for t, x in self._log if now - t < window)
            if used + c > limit + 1e-9:
                # chờ tới khi các mục cũ nhất trượt khỏi cửa sổ đủ để có chỗ
                over, acc = used + c - limit, 0.0
                for t, x in self._log:
                    if now - t >= window:
                        continue
                    acc += x
                    if acc >= over - 1e-9:
                        wait = max(wait, t + window - now)
                        break
        if self._observed:
            t0, used, limit, window = self._observed
            if now - t0 < window and used + cost > limit * 0.97:
                wait = max(wait, min(window - (now - t0), 10.0))
        return wait

    def acquire(self, cost=1.0, max_wait=None):
        """Chặn tới khi được phép gửi. Ném RateLimitError nếu phải chờ quá max_wait. Trả về số giây đã chờ."""
        cost = max(0.0, float(cost))
        limit_wait = self.max_wait if max_wait is None else float(max_wait)
        waited = 0.0
        while True:
            with self._lock:
                now = self._clock()
                w = self._need_wait(now, cost)
                if w <= 0:
                    self._log.append((now, cost))
                    self.stats_["calls"] += 1
                    if waited > 0:
                        self.stats_["waits"] += 1
                        self.stats_["waited_s"] += waited
                    return waited
            if waited + w > limit_wait + 1e-9:
                raise RateLimitError("%s: vượt giới hạn tốc độ API, phải chờ %.1fs (> %.0fs cho phép)" % (self.name, w, limit_wait), w)
            step = min(w, 0.25)
            self._sleep(step)
            waited += step

    def penalize(self, seconds, reason=""):
        """Sàn bảo chậm lại (429/418/5xx): chặn mọi request trong `seconds` giây."""
        seconds = max(0.0, min(float(seconds), 3600.0))
        with self._lock:
            self._blocked_until = max(self._blocked_until, self._clock() + seconds)
            self.stats_["penalties"] += 1
            self.stats_["last_penalty"] = "%s (%.0fs)" % (reason, seconds)

    def observe_used(self, used, limit=None, window=60.0):
        """Sàn báo 'đã dùng bao nhiêu' (Binance: X-MBX-USED-WEIGHT-1M) -> tôn trọng số thật của sàn."""
        try:
            used = float(used)
        except (TypeError, ValueError):
            return
        lim = float(limit) if limit else max((a for a, w in self.rules if w >= window - 1e-9), default=self.rules[0][0])
        with self._lock:
            self._observed = (self._clock(), used, lim, float(window))

    # ---- phản hồi HTTP ----
    def on_http(self, status, headers=None):
        """Gọi sau mỗi phản hồi (kể cả lỗi). status 429/418 -> chờ Retry-After; 5xx -> chờ ngắn; 2xx -> đọc used-weight."""
        h = {str(k).lower(): v for k, v in (headers.items() if hasattr(headers, "items") else (headers or []))}
        if "x-mbx-used-weight-1m" in h:
            self.observe_used(h["x-mbx-used-weight-1m"], window=60.0)
        if status in (429, 418):
            ra = 0.0
            try:
                ra = float(h.get("retry-after", 0) or 0)
            except (TypeError, ValueError):
                pass
            default = 120.0 if status == 418 else 10.0           # 418 = Binance đã cấm IP tạm thời
            self.penalize(ra if ra > 0 else default, "HTTP %d" % status)
        elif status in (500, 502, 503, 504):
            self.penalize(1.0, "HTTP %d" % status)

    def stats(self):
        with self._lock:
            now = self._clock()
            self._prune(now)
            used = [round(sum(x for t, x in self._log if now - t < w), 2) for _, w in self.rules]
            return dict(self.stats_, name=self.name, rules=list(self.rules), used=used,
                        blocked_for=round(max(0.0, self._blocked_until - now), 1))


_REG = {}
_REG_LOCK = threading.Lock()
_LOOPBACK = ("127.", "localhost", "[::1]", "0.0.0.0")


def _is_loopback(base):
    try:
        from urllib.parse import urlsplit
        host = (urlsplit(base).hostname or "").lower()
    except Exception:
        return False
    return host.startswith(_LOOPBACK) or host in ("localhost", "::1")


def limiter_for(kind, base="", rules=None):
    """Kho dùng chung theo (loại sàn, URL gốc): feed + broker cùng sàn chia một ngân sách."""
    key = "%s|%s" % (kind, (base or "").rstrip("/"))
    with _REG_LOCK:
        lim = _REG.get(key)
        if lim is None:
            if rules is None and _is_loopback(base):         # máy chủ cục bộ/giả lập: không phải sàn thật -> không giới hạn
                rules = [(1e9, 1.0)]
            lim = _REG[key] = RateLimiter(kind, rules or PRESETS.get(kind) or PRESETS["generic"])
        elif rules:
            lim.set_rules(rules)
        return lim


def all_stats():
    with _REG_LOCK:
        return {k: v.stats() for k, v in _REG.items()}


def reset_all():
    """Chủ yếu cho test."""
    with _REG_LOCK:
        _REG.clear()
