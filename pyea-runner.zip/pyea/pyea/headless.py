"""
Chạy KHÔNG GIAO DIỆN (VPS / Docker / Raspberry Pi): cùng động cơ, cùng dịch vụ nền (ipc.ServiceHost) như bản Android, nhưng không Kivy.
Dùng cùng thư mục dữ liệu với app: cài đặt (khoá API vẫn mã hoá), bot đã gắn, thông số - tạo/sửa bằng app rồi chép sang VPS (xem pyea/bundle.py),
hoặc `--init` để tạo thư mục mẫu rồi sửa settings.json / gắn bot bằng `--attach`.

  python -m pyea.headless --data-dir /var/lib/pyea                 # chạy theo cài đặt đã lưu (paper nếu chưa đổi)
  python -m pyea.headless --data-dir D --accept-risk               # BẮT BUỘC thêm khi settings mode=live (thay cho hộp thoại rủi ro của app)
  python -m pyea.headless --data-dir D --status                    # in trạng thái phiên đang chạy
  python -m pyea.headless --data-dir D --init                      # tạo thư mục + bot mẫu
  python -m pyea.headless --data-dir D --attach ma_cross.py BTCUSDT 1m

Mã thoát: 0 = dừng có chủ đích (SIGTERM/SIGINT hoặc phiên kết thúc bình thường) · 1 = phiên lỗi (supervisor như systemd/Docker nên khởi động lại; phiên
được khôi phục sổ lệnh nhờ auto_resume) · 2 = từ chối chạy (thiếu --accept-risk khi LIVE, cấu hình sai).
KHÔNG đã thử trên VPS thật ở bản này (chỉ có test tự động trong sandbox).
"""
import argparse
import json
import os
import signal
import sys
import threading
import time

from .storage import Store


def build_config(store, resume=None):
    st = store.load_settings()
    if resume is None:
        resume = bool(os.path.exists(store.state_path) and st.get("auto_resume", True))
    insts = [dict(c, running=bool(c.get("auto", True))) for c in store.load_instances() if (c.get("account") or "main") == "main"]
    return {"settings": dict(st), "resume": bool(resume), "ai_auto": False,
            "log_file": os.path.join(store.logs_dir, time.strftime("%Y%m%d") + ".log"), "trades_csv": store.trades_csv, "instances": insts}


def check(cfg, accept_risk):
    """None nếu được chạy, ngược lại lý do tiếng Việt."""
    s = cfg["settings"]
    if s.get("mode") == "live":
        if s.get("exchange") in ("simulated", "public"):
            return "mode=live nhưng exchange=simulated/public - chọn sàn thật trong settings."
        if not s.get("live_confirm"):
            return "mode=live cần live_confirm=true trong settings (xác nhận hiểu rủi ro tiền thật)."
        if not accept_risk:
            return "mode=live: thêm --accept-risk để xác nhận bạn đã đọc cảnh báo rủi ro (README / LICENSE.md). Tiền thật có thể mất hết."
    return None


def run(data_dir, stop_event=None, accept_risk=False, resume=None, log=print, host_kwargs=None):
    from .ipc import ServiceClient, ServiceHandle, ServiceHost
    os.makedirs(data_dir, exist_ok=True)
    store = Store(data_dir)
    cfg = build_config(store, resume)
    why = check(cfg, accept_risk)
    if why:
        log("TỪ CHỐI CHẠY: " + why)
        return 2
    stop_event = stop_event or threading.Event()
    client = ServiceClient(data_dir)
    handle = ServiceHandle(client, store.events_path, pending=True)
    handle.start(cfg)
    kw = dict(idle_exit=1e9, exit_grace=3.0)
    kw.update(host_kwargs or {})
    host = ServiceHost(data_dir, alarm=lambda t, x, **k: log("[CẢNH BÁO] %s: %s" % (t, x)), set_notification=lambda *a, **k: None, **kw)
    done = threading.Event()

    def stopper():
        while not done.is_set():
            if stop_event.wait(0.2):
                try:
                    handle.stop()
                except Exception:                              # noqa: BLE001
                    pass
                return
    threading.Thread(target=stopper, daemon=True).start()
    log("PyEA headless chạy: sàn=%s chế độ=%s bot=%d (dữ liệu: %s)" % (cfg["settings"].get("exchange"), cfg["settings"].get("mode"),
                                                                       len(cfg["instances"]), data_dir))
    try:
        host.run()
    finally:
        done.set()
    st = client.read_state() or {}
    if stop_event.is_set():
        return 0
    crashed = any(str(a.get("title", "")).startswith("Lỗi dịch vụ nền") for a in (st.get("alarms") or []))
    return 1 if (st.get("status") == "error" or crashed) else 0


def status_text(data_dir):
    from .ipc import ServiceClient
    c = ServiceClient(data_dir)
    st = c.read_state()
    if not st:
        return "Chưa có trạng thái (chưa chạy)."
    return "host %s · phiên %s · %s" % ("SỐNG" if c.host_alive() else "không phản hồi", "đang chạy" if st.get("session_alive") else "đã dừng",
                                        json.dumps({k: st.get(k) for k in ("status", "message", "balance", "equity") if k in st}, ensure_ascii=False))


def init_dir(data_dir):
    store = Store(data_dir)
    store.seed_examples()
    p = os.path.join(data_dir, "README_headless.txt")
    if not os.path.exists(p):
        with open(p, "w", encoding="utf-8") as f:
            f.write("Thư mục dữ liệu PyEA headless. Bot nằm trong bots/. Gắn bot: python -m pyea.headless --data-dir . --attach ma_cross.py BTCUSDT 1m\n"
                    "Cài đặt: chép settings từ app qua pyea/bundle.py hoặc sửa bằng Store.\n")
    return store


def attach(data_dir, bot, symbol, tf):
    store = Store(data_dir)
    path = bot if os.path.isabs(bot) else os.path.join(store.bots_dir, bot)
    if not os.path.exists(path):
        raise FileNotFoundError("Không thấy bot: %s" % path)
    items = store.load_instances()
    base = os.path.splitext(os.path.basename(path))[0]
    n = 1 + sum(1 for c in items if c.get("symbol") == symbol.upper() and os.path.basename(c.get("bot_path", "")) == os.path.basename(path))
    items.append({"iid": "%s-%s-%d" % (base, symbol.upper(), n), "bot_path": path, "symbol": symbol.upper(), "tf": tf,
                  "params": store.load_params(path), "auto": True})
    store.save_instances(items)
    return len(items)


def main(argv=None):
    ap = argparse.ArgumentParser(description="PyEA Runner - chạy không giao diện")
    ap.add_argument("--data-dir", default=os.environ.get("PYEA_DATA", os.path.expanduser("~/.pyea")))
    ap.add_argument("--accept-risk", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--init", action="store_true")
    ap.add_argument("--attach", nargs=3, metavar=("BOT", "SYMBOL", "TF"))
    ap.add_argument("--fresh", action="store_true", help="không khôi phục sổ lệnh phiên trước")
    a = ap.parse_args(argv)
    if a.status:
        print(status_text(a.data_dir))
        return 0
    if a.init:
        init_dir(a.data_dir)
        print("Đã tạo", a.data_dir)
        return 0
    if a.attach:
        print("Đã gắn, tổng %d bot." % attach(a.data_dir, *a.attach))
        return 0
    stop = threading.Event()
    for sg in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sg, lambda *_: stop.set())
        except (ValueError, OSError):
            pass
    return run(a.data_dir, stop, a.accept_risk, resume=False if a.fresh else None)


if __name__ == "__main__":
    sys.exit(main())
