"""Theo dõi KẾT NỐI (giá + sàn) và cảnh báo mất mạng - phần VỎ, độc lập với sàn.

Hai tín hiệu, không phụ thuộc loại sàn:
  * giá  : `connection_health` (mọi mã đang theo dõi đều mất/cũ giá) - có sẵn từ trước.
  * sàn  : kết quả các lần gọi API sàn định kỳ mà vỏ đã làm (đối soát vị thế, hỏi lệnh chờ native, hỏi lệnh bảo vệ native) qua `link_note(nguồn, ok)`.
           Một nguồn lỗi liên tiếp >= 2 lần thì coi là «sàn mất kết nối/lỗi API» (lỗi quyền/giới hạn tốc độ của sàn cũng hiện ở đây kèm nội dung lỗi).

Một «đợt mất kết nối» bắt đầu khi một trong hai tín hiệu xấu và kết thúc khi cả hai tốt:
  * sau `link_alarm_s` giây: báo động NGHIÊM TRỌNG, nói rõ đang có bao nhiêu vị thế và cái nào KHÔNG có ai canh lúc này
    (SL/TP do app canh thì không chạy khi mất mạng; SL/TP native đã nằm trên sàn thì vẫn hoạt động);
  * cứ mỗi `link_repeat_min` phút mà vẫn mất: nhắc lại (0 = không nhắc);
  * khi có lại kết nối: thông báo + ĐỒNG BỘ NGAY (đối soát vị thế, lệnh chờ native, lệnh bảo vệ native, lịch sử + số dư) thay vì chờ tới chu kỳ kế tiếp.

Không import Kivy; không bao giờ ném lỗi ra vòng poll."""
import time


class LinkMixin:
    PROBE_FAILS = 2                  # số lần lỗi liên tiếp của MỘT nguồn thì coi sàn là mất kết nối

    def _link_init(self):
        self._link = {"down_since": 0.0, "alerted_at": 0.0, "alerts": 0, "reason": "", "episodes": 0, "last_down_s": 0.0, "last_up": 0.0}
        self._link_probe = {}                    # nguồn -> {"fail": số lần lỗi liên tiếp, "since": giờ lỗi đầu, "err": lỗi cuối}
        self._link_t = 0.0
        self._unprotected_warned = False

    # ---- tín hiệu từ các lần gọi sàn định kỳ ----
    def link_note(self, src, ok, err=""):
        with self.lock:
            p = self._link_probe.setdefault(src, {"fail": 0, "since": 0.0, "err": ""})
            if ok:
                p["fail"], p["since"], p["err"] = 0, 0.0, ""
            else:
                if not p["fail"]:
                    p["since"] = time.time()
                p["fail"] += 1
                p["err"] = str(err)[:160]

    def broker_link(self):
        """(mất kết nối sàn?, lỗi cuối, giờ bắt đầu) theo các nguồn đang lỗi liên tiếp."""
        with self.lock:
            bad = [p for p in self._link_probe.values() if p["fail"] >= self.PROBE_FAILS]
        if not bad:
            return False, "", 0.0
        first = min(bad, key=lambda p: p["since"])
        return True, first["err"], first["since"]

    def link_state(self):
        L = self._link
        now = time.time()
        return {"down": bool(L["down_since"]), "since": L["down_since"], "down_s": (now - L["down_since"]) if L["down_since"] else 0.0,
                "reason": L["reason"], "episodes": L["episodes"], "last_down_s": L["last_down_s"], "alerts": L["alerts"]}

    # ---- mô tả phần đang có nguy cơ ----
    def link_exposure(self):
        """Đếm vị thế theo người canh SL/TP: native (sàn canh), app (chỉ app canh), none (không có SL/TP). + lệnh chờ do app giữ."""
        with self.lock:
            pos = list(self.account.positions.values()) if self.account is not None else []
            pend = sum(1 for o in (self.account.pending.values() if self.account is not None else []) if not o.native_id)
        covered = getattr(self, "_prot_pos", set())
        native = app = none = 0
        for p in pos:
            levels = [k for k, v in (("sl", p.sl), ("tp", p.tp)) if v and v > 0]
            if not levels:
                none += 1
            elif all((p.id, k) in covered for k in levels):
                native += 1
            else:
                app += 1
        return {"positions": len(pos), "native": native, "app": app, "none": none, "app_pending": pend}

    @staticmethod
    def _exposure_text(e):
        if not e["positions"] and not e["app_pending"]:
            return "Hiện không có vị thế/lệnh chờ nào cần canh."
        parts = []
        if e["positions"]:
            parts.append("%d vị thế đang mở" % e["positions"])
            if e["native"]:
                parts.append("%d được SÀN canh SL/TP (native, vẫn hoạt động)" % e["native"])
            if e["app"]:
                parts.append("%d chỉ do APP canh SL/TP (KHÔNG hoạt động lúc này)" % e["app"])
            if e["none"]:
                parts.append("%d không đặt SL/TP" % e["none"])
        if e["app_pending"]:
            parts.append("%d lệnh chờ do app giữ sẽ không khớp lúc này" % e["app_pending"])
        return "; ".join(parts) + "."

    # ---- vòng poll ----
    def _check_link(self):
        try:
            self._check_link_inner()
        except Exception as e:                                       # noqa: BLE001 - giám sát không được làm sập phiên
            self._link_err = str(e)

    def _check_link_inner(self):
        if self.account is None:
            return
        now = time.time()
        if now - self._link_t < 1.0:
            return
        self._link_t = now
        self._warn_unprotected_once()
        h = self.health()
        feed_down = h.get("state") == "disconnected"
        bro_down, bro_err, bro_since = self.broker_link()
        L = self._link
        if feed_down or bro_down:
            why = "giá + sàn" if (feed_down and bro_down) else ("giá" if feed_down else "sàn")
            if not L["down_since"]:
                L["down_since"] = min(now, bro_since) if (bro_down and bro_since) else now
                L["episodes"] += 1
                self.log("MẤT KẾT NỐI %s (bắt đầu đợt thứ %d)%s" % (why, L["episodes"], (": " + bro_err) if (bro_down and bro_err) else ""), "WARN")
            L["reason"] = why
            dur = now - L["down_since"]
            first_after = float(self.settings.get("link_alarm_s", 30.0) or 0.0)
            repeat = float(self.settings.get("link_repeat_min", 10.0) or 0.0) * 60.0
            if first_after <= 0:
                return
            if (not L["alerted_at"] and dur >= first_after) or (L["alerted_at"] and repeat > 0 and now - L["alerted_at"] >= repeat):
                again = bool(L["alerted_at"])
                L["alerted_at"] = now
                L["alerts"] += 1
                head = ("VẪN mất kết nối %s (%s)" % (why, self._fmt_dur(dur))) if again else ("Mất kết nối %s" % why)
                detail = (" Lỗi sàn: %s." % bro_err) if (bro_down and bro_err) else ""
                self.alarm(head, "Mất kết nối %s đã %s.%s %s" % (why, self._fmt_dur(dur), detail, self._exposure_text(self.link_exposure())), critical=True)
        elif L["down_since"]:
            dur = now - L["down_since"]
            alerted = bool(L["alerted_at"])
            L.update(down_since=0.0, alerted_at=0.0, last_down_s=dur, last_up=now, reason="")
            self._link_restored(dur, alerted)

    @staticmethod
    def _fmt_dur(s):
        return "%.0f giây" % s if s < 120 else ("%.0f phút" % (s / 60.0) if s < 7200 else "%.1f giờ" % (s / 3600.0))

    def _link_restored(self, dur, alerted):
        """Có lại kết nối: đồng bộ NGAY mọi thứ phụ thuộc sàn (đừng chờ chu kỳ)."""
        self.reconcile_due(0.0)
        self._sync_next = 0.0
        self._native_sync_due = 0.0
        self._prot_kick()
        msg = "Đã có lại kết nối sau %s - đang đối soát vị thế/lệnh với sàn." % self._fmt_dur(dur)
        self.log(msg, "WARN")
        if alerted or dur >= 60.0:
            self.alarm("Đã có lại kết nối", msg, critical=False)

    def _warn_unprotected_once(self):
        """LIVE: có vị thế mà SL/TP chỉ do app canh (hoặc không có) và sàn không giữ SL/TP -> nói rõ MỘT lần mỗi phiên."""
        if self._unprotected_warned or self.broker is None or self.sync:
            return
        e = self.link_exposure()
        if not e["positions"] or self._prot_enabled():
            return
        self._unprotected_warned = True
        text = ("Đang có %d vị thế (%d chỉ do app canh SL/TP, %d không có SL/TP). SL/TP do app canh chỉ chạy khi app còn sống và có mạng; "
                "bật «SL/TP native» để sàn tự giữ khi app/điện thoại chết." % (e["positions"], e["app"], e["none"]))
        self.log("LƯU Ý: " + text, "WARN")
        self.alarm("Vị thế chưa được sàn bảo vệ", text, critical=False)
