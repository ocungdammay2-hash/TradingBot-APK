"""
OrderMixin - toàn bộ xử lý LỆNH của vỏ (gắn vào TradingSession). Bot/giao diện chỉ thấy một giao diện thống nhất,
còn mọi khác biệt giữa các sàn (SL/TP có sẵn hay giả lập, lệnh chờ, bán khống, gộp vị thế...) được vỏ che đi:

  send_order      lệnh thị trường: kiểm tra TRƯỚC khi gửi (chỉ-xem, kill switch, chế độ mã, khối lượng, SL/TP, giá cũ, ký quỹ...)
                  rồi gửi sàn (tuần tự qua một "trade context" như MT5) -> OrderResult có retcode chuẩn hoá
  place_pending   lệnh chờ limit/stop/stop_limit: vỏ tự theo dõi giá (giả lập trong vỏ nên chạy giống nhau trên MỌI sàn)
  close_position  đóng toàn bộ hoặc MỘT PHẦN · modify_position / modify_order / cancel_order
  kill_switch     dừng mọi bot -> huỷ lệnh chờ -> đóng mọi vị thế -> chặn lệnh mới
  cảnh báo giá, margin call / stop-out, sự kiện on_trade cho bot
Quy ước id: lệnh chờ và vị thế dùng CHUNG bộ đếm; khi lệnh chờ khớp, vị thế GIỮ id của lệnh chờ.
"""
import math
import time
import traceback
from dataclasses import replace

from .broker import BrokerError, Fill
from .feeds import FeedError
from .sdk import (AccountInfo, OrderResult, PendingOrder, Position, Ret, SymbolInfo, Tick, TradeUpdate)
from .shell import (freeze_error_order, freeze_error_position, mode_allows, resolve_spec, validate_stops, validate_volume)

SRC_EXTRA = {"kill": "Kill switch", "stopout": "Stop-out", "expired": "Hết hạn", "exchange": "Sàn", "oco": "OCO"}
FREEZE_EXEMPT = frozenset(("expired", "exchange", "oco", "kill", "stopout", "stop", "risk"))      # huỷ do hệ thống: freeze không chặn


class OrderMixin:
    # ------------------------------------------------------------------ tra cứu (bot và giao diện dùng chung)
    def spec(self, symbol):
        return resolve_spec(self.settings, symbol, self.feed, self.broker)

    def _ui_contracts(self):
        """{mã: contract_size} cho UI hiển thị lot/đơn vị (chỉ mã có hợp đồng ≠ 1). Cache 5 phút/mã để snapshot không gọi sàn liên tục."""
        cache = self.__dict__.setdefault("_contract_cache", {})
        with self.lock:
            syms = set(self.watch) | {p.symbol for p in self.account.positions.values()} | {o.symbol for o in self.account.pending.values()} \
                | {t.symbol for t in list(self.account.trades)[-40:]} if self.account is not None else set()
        now, out = time.time(), {}
        for s in syms:
            hit = cache.get(s)
            if hit is None or now - hit[0] > 300.0:
                try:
                    cs = float(self.spec(s).contract_size or 1.0)
                except Exception:                                  # noqa: BLE001
                    cs = hit[1] if hit else 1.0
                hit = cache[s] = (now, cs)
            if hit[1] != 1.0:
                out[s] = hit[1]
        return out

    def symbol_info(self, symbol):
        sym = symbol.strip().upper()
        spec = self.spec(sym)
        t = self.ticks.get(sym)
        if t is None:
            try:
                t = self.get_tick(sym)
            except (FeedError, KeyError, AttributeError):
                t = None
        bid, ask = (t.bid, t.ask) if t else (0.0, 0.0)
        px = (bid + ask) / 2.0 if t else 0.0
        lev = self.account.leverage if self.account else 1.0
        return SymbolInfo(symbol=sym, bid=bid, ask=ask, spread=(ask - bid), digits=spec.digits, tick_size=spec.tick_size,
                          contract_size=spec.contract_size, volume_min=spec.volume_min, volume_max=spec.volume_max,
                          volume_step=spec.volume_step, stops_level=spec.stops_level(px), freeze_level=spec.freeze_level(px),
                          trade_mode=spec.trade_mode,
                          market_open=bool(t.tradeable) if t else True,
                          leverage=lev, margin_per_unit=(px / lev) if lev else px)

    def account_info(self):
        acc = self.account
        if acc is None:
            return AccountInfo()
        with self.lock:
            eq, used, res = acc.equity(), acc.margin_used(), acc.reserved_margin()
            lvl = acc.margin_level()
            s = self.settings
            fl = getattr(self, "_flags", None) or {}
            ba = self.broker_account() or {}
            return AccountInfo(balance=acc.balance, equity=eq, margin=used, reserved=res, free_margin=eq - used - res,
                               broker_synced=bool(ba), broker_balance=ba.get("balance") or 0.0, broker_equity=ba.get("equity") or 0.0,
                               broker_margin=ba.get("margin") or 0.0, broker_free_margin=ba.get("free_margin") or 0.0,
                               broker_margin_level=ba.get("margin_level") or 0.0, broker_profit=ba.get("profit") or 0.0,
                               margin_level=lvl or 0.0, leverage=acc.leverage, currency=fl.get("currency") or ba.get("currency") or "USD", mode=s["mode"],
                               demo=(s["mode"] != "live") or bool(s.get("testnet")),
                               netting=bool(getattr(self.broker, "netting", False)),
                               trade_allowed=not (self.halted or s.get("read_only")) and fl.get("can_trade") is not False,
                               read_only=bool(s.get("read_only")), halted=self.halted, server_time=self._now(),
                               margin_mode=str(fl.get("margin_mode") or ""))

    FLAGS_EVERY = 120.0
    ACCT_BACKOFF_MAX = 120.0

    def _check_account_state(self):
        """Đọc tài khoản do SÀN báo (broker.account_state(): tài sản, ký quỹ, ký quỹ còn dư, mức ký quỹ) mỗi `account_state_interval` giây ở luồng poll.
        Chỉ để HIỂN THỊ và cho bot đọc (AccountInfo.broker_*): sổ riêng của app tự tính nên không khớp số của sàn (xem pyea/acctstate.py). Lỗi -> giãn nhịp, không sập."""
        b = self.broker
        fn = getattr(b, "account_state", None) if b is not None else None
        iv = float(self.settings.get("account_state_interval", 15.0) or 0.0)
        if fn is None or iv <= 0 or self.settings.get("mode") != "live":
            return
        now = time.time()
        if now < getattr(self, "_bacct_next", 0.0):
            return
        from .acctstate import normalize
        try:
            st = normalize(fn(), scope=self.settings.get("exchange"))
            if st is None:
                raise ValueError("sàn không trả số dư/tài sản")
        except Exception as e:                              # noqa: BLE001 - mất mạng/sàn lỗi không được làm sập vòng poll
            n = getattr(self, "_bacct_fail", 0) + 1
            self._bacct_fail = n
            self._bacct_next = now + min(iv * (2 ** min(n, 6)), self.ACCT_BACKOFF_MAX)
            if n == 1 or now - getattr(self, "_bacct_warn", 0.0) > 300:
                self._bacct_warn = now
                self.log("Không đọc được tài khoản từ sàn (%s) - số Tài sản/Ký quỹ hiển thị là số tự tính của app" % e, "WARN")
            return
        self._bacct_fail = 0
        self._bacct_next = now + iv
        st["t"] = now
        self._bacct = st

    def broker_account(self):
        """Tài khoản do sàn báo (đã chuẩn hoá) kèm `age` (giây) hoặc None khi chưa có/đã cũ quá 4 chu kỳ (số cũ còn nguy hiểm hơn không có số)."""
        st = getattr(self, "_bacct", None)
        if not st:
            return None
        iv = float(self.settings.get("account_state_interval", 15.0) or 0.0)
        age = time.time() - st["t"]
        if iv <= 0 or age > max(60.0, iv * 4):
            return None
        return dict(st, age=age)

    def _check_position_stats(self):
        """Lãi/lỗ, swap, hoa hồng TỪNG VỊ THẾ do sàn tính (broker.position_stats() -> {ticket: {...}}) cùng nhịp `account_state_interval` với tài khoản.
        Sổ riêng của app chỉ có «chênh giá × khối lượng» (không contract size, không quy đổi tiền tệ, không swap/hoa hồng) nên với sàn kiểu MT không khớp số của sàn;
        giao diện dùng số này (nhãn «sàn») khi có. Không có vị thế nào thì không gọi sàn. Lỗi -> giãn nhịp, không sập."""
        b = self.broker
        fn = getattr(b, "position_stats", None) if b is not None else None
        iv = float(self.settings.get("account_state_interval", 15.0) or 0.0)
        if fn is None or iv <= 0 or self.settings.get("mode") != "live" or self.account is None:
            return
        now = time.time()
        if now < getattr(self, "_bpos_next", 0.0):
            return
        if not self.account.positions:
            self._bpos = {"t": now, "rows": {}}
            self._bpos_next = now + min(iv, 5.0)                 # có vị thế mới xuất hiện thì lấy số của sàn sớm
            return
        try:
            rows = fn() or {}
        except Exception as e:                                   # noqa: BLE001
            n = getattr(self, "_bpos_fail", 0) + 1
            self._bpos_fail = n
            self._bpos_next = now + min(iv * (2 ** min(n, 6)), self.ACCT_BACKOFF_MAX)
            if n == 1 or now - getattr(self, "_bpos_warn", 0.0) > 300:
                self._bpos_warn = now
                self.log("Không đọc được lãi/lỗ vị thế từ sàn (%s) - lãi/lỗ hiển thị là số tự tính của app" % e, "WARN")
            return
        self._bpos_fail = 0
        self._bpos_next = now + iv
        self._bpos = {"t": now, "rows": {str(k): dict(v) for k, v in rows.items()}}

    def broker_positions(self):
        """{ticket: {profit, swap, commission, price}} do sàn báo, hoặc None khi chưa có / đã cũ quá 4 chu kỳ (số cũ nguy hiểm hơn không có số)."""
        st = getattr(self, "_bpos", None)
        if not st:
            return None
        iv = float(self.settings.get("account_state_interval", 15.0) or 0.0)
        if iv <= 0 or time.time() - st["t"] > max(60.0, iv * 4):
            return None
        return dict(st["rows"])

    def _check_account_flags(self):
        """Làm mới cờ tài khoản từ sàn (loại ký quỹ, được phép giao dịch, tiền tệ) mỗi FLAGS_EVERY giây ở luồng poll;
        account_info() chỉ đọc bản đã lưu nên bot gọi liên tục cũng không tốn request."""
        b = self.broker
        fn = getattr(b, "account_flags", None) if b is not None else None
        if fn is None:
            return
        now = time.time()
        if now - getattr(self, "_flags_t", 0.0) < self.FLAGS_EVERY:
            return
        self._flags_t = now
        try:
            fl = fn() or {}
        except Exception as e:                              # noqa: BLE001
            self.log("Không đọc được cờ tài khoản từ sàn: %s" % e, "WARN")
            return
        if not isinstance(fl, dict):
            return
        old = getattr(self, "_flags", None) or {}
        self._flags = fl
        if fl.get("can_trade") is False and old.get("can_trade") is not False:
            self.alarm("Tài khoản không được phép giao dịch", "Sàn báo canTrade=false: vỏ chặn lệnh MỚI (lệnh đóng vẫn cho phép).")
        elif fl.get("can_trade") is True and old.get("can_trade") is False:
            self.log("Sàn đã cho phép giao dịch lại (canTrade=true)", "INFO")
        if fl.get("margin_mode") and fl.get("margin_mode") != old.get("margin_mode"):
            self.log("Loại ký quỹ trên sàn: %s" % fl["margin_mode"], "INFO")

    def _now(self):
        """Giờ 'server' = giờ của tick gần nhất (giờ thị trường); chưa có tick thì giờ máy."""
        if self.ticks:
            return max(t.time for t in self.ticks.values())
        return time.time()

    def time_info(self):
        now = time.time()
        server = self._now()
        return {"utc": now, "server": server, "skew_s": server - now, "local_offset_s": -time.timezone}

    # ------------------------------------------------------------------ kiểm tra chung
    def _gate(self, symbol, side, closing=False, owner=""):
        """Điều kiện chặn chung trước khi gửi/đặt lệnh MỚI. -> (retcode, message) hoặc None."""
        s = self.settings
        if self.halted:
            return Ret.TRADE_DISABLED, "Kill switch đang bật - mọi lệnh mới bị chặn (bấm 'Mở lại giao dịch' để tiếp tục)"
        if s.get("read_only") and not closing:
            return Ret.TRADE_DISABLED, "Chế độ CHỈ-XEM (read-only): vỏ không gửi lệnh mới"
        if not closing and (getattr(self, "_flags", None) or {}).get("can_trade") is False:
            return Ret.TRADE_DISABLED, "Sàn báo tài khoản KHÔNG được phép giao dịch (canTrade=false) - kiểm tra quyền API key / trạng thái tài khoản"
        err = mode_allows(self.spec(symbol), side, closing)
        if err:
            return Ret.SYMBOL_MODE, err
        return self._cal_gate(symbol, closing, owner)                 # lịch kinh tế: chỉ chặn lệnh MỚI của bot/AI, và chỉ khi người dùng bật

    def _quote(self, symbol):
        """Giá để đặt lệnh. -> (tick, retcode|None, message)."""
        try:
            tick = self.get_tick(symbol)
        except (FeedError, KeyError, AttributeError) as e:
            return None, Ret.NO_QUOTES, "Chưa có giá %s: %s" % (symbol, e)
        if not self.sync:
            stale = float(self.settings.get("stale_after") or 0)
            w = self._tick_wall.get(symbol)
            if stale > 0 and w is not None and time.time() - w > stale:
                return tick, Ret.NO_QUOTES, "Giá %s đã cũ %.0f giây (> %.0f giây) - có thể mất kết nối giá" % (symbol, time.time() - w, stale)
        return tick, None, ""

    def _fail(self, retcode, msg, owner="", symbol="", side="", volume=0.0, price=0.0, request_id="", log=True):
        res = OrderResult(ok=False, retcode=retcode, message=msg, requested_volume=float(volume or 0.0), request_id=request_id)
        if log:
            self.log("Từ chối lệnh %s %s: %s [%s]" % (side or "?", symbol or "?", msg, retcode), "WARN")
        if owner and owner != "manual":
            self._emit(TradeUpdate(kind="order_rejected", symbol=symbol, side=side, volume=float(volume or 0.0), price=price,
                                   source="bot", reason=msg, retcode=retcode, time=self._now(), owner=owner))
        return res

    def _emit(self, upd):
        """Gửi sự kiện cho on_trade của bot chủ lệnh."""
        inst = self.instances.get(upd.owner) if upd.owner else None
        if inst is not None:
            try:
                inst.notify_trade(upd)
            except Exception:
                pass

    # ------------------------------------------------------------------ lệnh thị trường
    def send_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", owner="manual", reason="", details=None, ai=None,
                   ctx=None, request_id="", _pos_id=None, _validate=True, _pending=None):
        symbol = str(symbol).strip().upper()
        side = "buy" if str(side).lower() == "buy" else "sell"
        rid = str(request_id or "")
        if rid:
            hit = self._req_cache.get((owner, rid))
            if hit is not None and time.time() - hit[0] < 120:
                res = replace(hit[1])
                res.message = (res.message + " (request_id trùng - trả lại kết quả cũ, không gửi lại)").strip()
                return res
        res = self._send_market(symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx, rid, _pos_id, _validate, _pending)
        if rid:
            self._req_cache[(owner, rid)] = (time.time(), res)
            for k in [k for k, v in self._req_cache.items() if time.time() - v[0] > 300]:
                self._req_cache.pop(k, None)
        return res

    def _send_market(self, symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx, rid, pos_id, validate, pending):
        try:
            sl, tp = float(sl or 0.0), float(tp or 0.0)
            req_vol = float(volume)
        except (TypeError, ValueError):
            return self._fail(Ret.INVALID_VOLUME, "Khối lượng/SL/TP không phải số", owner, symbol, side, 0.0, 0.0, rid)
        if validate:
            g = self._gate(symbol, side, owner=owner)
            if g:
                return self._fail(g[0], g[1], owner, symbol, side, req_vol, 0.0, rid)
        spec = self.spec(symbol)
        nf = getattr(pending, "_native_fill", None) if pending is not None else None      # đã khớp TRÊN SÀN -> chỉ ghi sổ
        if nf is not None:
            volume, err = float(nf.qty), None
        else:
            volume, err = validate_volume(spec, req_vol)
        if err:
            return self._fail(Ret.INVALID_VOLUME, err, owner, symbol, side, req_vol, 0.0, rid)
        tick, rc, msg = self._quote(symbol)
        if nf is not None and (rc or tick is None):
            tick, rc = Tick(symbol, self._now(), nf.price, nf.price), None
        if rc:
            return self._fail(rc, msg, owner, symbol, side, volume, 0.0, rid)
        if not tick.tradeable and nf is None:
            return self._fail(Ret.MARKET_CLOSED, "Thị trường %s đang đóng cửa (sàn báo không giao dịch được)" % symbol, owner, symbol, side, volume, 0.0, rid)
        ref = tick.ask if side == "buy" else tick.bid
        if validate:
            err = validate_stops(spec, side, ref, sl, tp)
            if err:
                return self._fail(Ret.INVALID_STOPS, err, owner, symbol, side, volume, ref, rid)
        with self.lock:
            free = self.account.equity() - self.account.margin_used() - self.account.reserved_margin()
            need = volume * ref / self.account.leverage
            if need > free + 1e-9 and nf is None:
                return self._fail(Ret.INSUFFICIENT_MARGIN, "Không đủ ký quỹ: cần %.4f, khả dụng %.4f (đòn bẩy x%g)" % (
                    need, free, self.account.leverage), owner, symbol, side, volume, ref, rid)
            opposite = any(p.symbol == symbol and p.side != side for p in self.account.positions.values())
        b = self.broker
        if b is not None and nf is None:
            if side == "sell" and not b.supports_short:
                return self._fail(Ret.NOT_SUPPORTED, "LIVE spot không hỗ trợ bán khống (dùng binance_futures hoặc oanda)", owner, symbol, side, volume, ref, rid)
            if getattr(b, "netting", False) and opposite:
                return self._fail(Ret.HEDGE_NOT_ALLOWED, "Sàn gộp vị thế 1 chiều/mã: không giữ đồng thời mua và bán %s" % symbol,
                                  owner, symbol, side, volume, ref, rid)
        price = ref
        sent_vol = None
        xref = ""                                               # mã vị thế trên sàn (nếu sàn trả) - lưu vào vị thế ảo
        with self._trade_lock:                                  # 1 "trade context": mọi lệnh gửi sàn xếp hàng tuần tự
            if nf is not None:
                price, volume = nf.price, nf.qty
                xref = str(getattr(nf, "ref", "") or "")
            elif b is not None:
                try:
                    b.tag_ctx = (owner, comment or reason)           # nhãn gọn «pyea<mã bot>:<logic>» (pyea/ordertag.py)
                    fill = b.market_order(symbol, side, volume)
                    self._book_order(getattr(fill, "order_id", ""))
                    self._order_fail = 0
                except BrokerError as e:
                    self.reconcile_due(2.0)                          # kết quả có thể không rõ (timeout) -> đối chiếu với sàn sớm
                    self._order_failed("Đặt lệnh %s %s thất bại: %s" % (side, symbol, e))
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối/lỗi: %s" % e, requested_volume=volume,
                                       request_id=rid)
                sent_vol = volume
                price, volume = fill.price, fill.qty
                xref = str(getattr(fill, "ref", "") or "")
            with self.lock:
                pos = self.account.open(symbol, side, volume, price, sl, tp, comment, tick.time, owner, pos_id=pos_id, ref=xref)
                pos.origin = "app"
        slip = abs(price - ref) / ref * 100.0 if ref else 0.0
        # Khớp một phần: sàn trả về ít hơn đã gửi (> 2%: dung sai cho phí trừ bằng coin ở Spot). Vỏ GHI SỔ đúng phần đã khớp,
        # KHÔNG tự gửi tiếp phần còn lại (bot biết ý đồ của nó) - chỉ báo qua OrderResult.partial/remaining + nhật ký + cảnh báo.
        partial = sent_vol is not None and sent_vol > 0 and volume < sent_vol * 0.98
        remaining = (sent_vol - volume) if partial else 0.0
        if partial:
            self.alarm("Khớp một phần %s" % symbol, "Gửi %.8g, sàn chỉ khớp %.8g (còn %.8g chưa khớp)" % (sent_vol, volume, remaining), critical=False)
        mx = float(self.settings.get("max_slippage_pct") or 0.0)
        if b is not None and mx > 0 and slip > mx:
            self.alarm("Trượt giá lớn %s" % symbol, "Khớp %.8g so với giá lúc gửi %.8g (%.3f%% > %.3f%%)" % (price, ref, slip, mx), critical=False)
        src = "manual" if owner == "manual" else ("ai" if ai else "bot")
        auto = reason or (comment and "Vào lệnh: %s" % comment) or (
            "Đặt lệnh thủ công" if owner == "manual" else "Bot gửi lệnh %s (bot không ghi lý do)" % side)
        d = dict(details or {})
        d.setdefault("SL", sl or "không đặt")
        d.setdefault("TP", tp or "không đặt")
        if pending is not None:
            d.setdefault("lệnh chờ", "%s #%d @ %.8g" % (pending.kind, pending.id, pending.price))
        if slip:
            d.setdefault("trượt giá %", round(slip, 5))
        if partial:
            d.setdefault("khớp một phần", "%.8g / %.8g" % (volume, sent_vol))
        self.add_event("open", symbol, price, side, volume, pos.id, src, auto, d, ai, 0.0, ctx, owner)
        self.log("MỞ #%d %s %s %.8g @ %.8g | SL=%.8g TP=%.8g | %s [%s]" % (pos.id, side.upper(), symbol, volume, price, sl, tp, auto, owner))
        self.notify("Mở lệnh %s %s" % (side.upper(), symbol), "%.8g @ %.8g · %s" % (volume, price, auto))
        self._emit(TradeUpdate(kind="position_opened", id=pos.id, symbol=symbol, side=side, volume=volume, price=price, sl=sl, tp=tp,
                               source=src, reason=auto, retcode=Ret.OK, time=tick.time, owner=owner))
        self._save_state()
        msg = "Đã khớp %s %.8g %s @ %.8g" % (side, volume, symbol, price)
        if partial:
            msg += " - CHỈ KHỚP MỘT PHẦN (còn %.8g chưa khớp)" % remaining
        return OrderResult(ok=True, retcode=Ret.OK, message=msg, position=replace(pos), price=price, volume=volume,
                           requested_volume=req_vol, slippage=slip, request_id=rid, partial=partial, remaining=remaining)

    def open_position(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", owner="manual", reason="", details=None, ai=None, ctx=None):
        """Tương thích cũ: trả về OrderResult (đúng = khớp; dùng như Position nhờ __getattr__)."""
        return self.send_order(symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx)

    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", request_id=""):
        """Đặt lệnh THỦ CÔNG từ giao diện (thị trường)."""
        return self.send_order(symbol, side, volume, sl, tp, comment, "manual", "Đặt lệnh thủ công từ ứng dụng",
                               {"nguồn": "người dùng"}, None, None, request_id)

    # ------------------------------------------------------------------ lệnh chờ
    def _validate_pending(self, symbol, side, kind, price, stop_price, tick):
        ask, bid = tick.ask, tick.bid
        if kind == "limit":
            if side == "buy" and price >= ask:
                return "Buy limit phải ĐẶT DƯỚI giá ask %.8g (đang đặt %.8g)" % (ask, price)
            if side == "sell" and price <= bid:
                return "Sell limit phải ĐẶT TRÊN giá bid %.8g (đang đặt %.8g)" % (bid, price)
        elif kind == "stop":
            if side == "buy" and price <= ask:
                return "Buy stop phải ĐẶT TRÊN giá ask %.8g (đang đặt %.8g)" % (ask, price)
            if side == "sell" and price >= bid:
                return "Sell stop phải ĐẶT DƯỚI giá bid %.8g (đang đặt %.8g)" % (bid, price)
        elif kind == "stop_limit":
            if stop_price <= 0:
                return "Stop-limit cần giá kích hoạt (stop_price)"
            if side == "buy":
                if stop_price <= ask:
                    return "Buy stop-limit: giá kích hoạt %.8g phải TRÊN ask %.8g" % (stop_price, ask)
                if price > stop_price:
                    return "Buy stop-limit: giá limit %.8g không được cao hơn giá kích hoạt %.8g" % (price, stop_price)
            else:
                if stop_price >= bid:
                    return "Sell stop-limit: giá kích hoạt %.8g phải DƯỚI bid %.8g" % (stop_price, bid)
                if price < stop_price:
                    return "Sell stop-limit: giá limit %.8g không được thấp hơn giá kích hoạt %.8g" % (price, stop_price)
        else:
            return "Loại lệnh chờ không hợp lệ: %s" % kind
        return None

    def place_pending(self, symbol, side, kind, volume, price, stop_price=0.0, sl=0.0, tp=0.0, comment="", owner="manual",
                      expiration=0.0, reason="", details=None, ai=None, ctx=None):
        symbol = str(symbol).strip().upper()
        side = "buy" if str(side).lower() == "buy" else "sell"
        try:
            price, stop_price = float(price), float(stop_price or 0.0)
            sl, tp, expiration = float(sl or 0.0), float(tp or 0.0), float(expiration or 0.0)
            req_vol = float(volume)
        except (TypeError, ValueError):
            return self._fail(Ret.INVALID_PRICE, "Giá/khối lượng không phải số", owner, symbol, side, 0.0)
        g = self._gate(symbol, side, owner=owner)
        if g:
            return self._fail(g[0], g[1], owner, symbol, side, req_vol, price)
        spec = self.spec(symbol)
        vol, err = validate_volume(spec, req_vol)
        if err:
            return self._fail(Ret.INVALID_VOLUME, err, owner, symbol, side, req_vol, price)
        if not math.isfinite(price) or price <= 0:
            return self._fail(Ret.INVALID_PRICE, "Giá đặt phải > 0", owner, symbol, side, vol, price)
        tick, rc, msg = self._quote(symbol)
        if tick is None:
            return self._fail(rc, msg, owner, symbol, side, vol, price)
        err = self._validate_pending(symbol, side, kind, price, stop_price, tick)
        if err:
            return self._fail(Ret.INVALID_PRICE, err, owner, symbol, side, vol, price)
        if expiration and expiration <= tick.time:
            return self._fail(Ret.INVALID_EXPIRATION, "Thời hạn lệnh chờ đã qua", owner, symbol, side, vol, price)
        err = validate_stops(spec, side, price, sl, tp)
        if err:
            return self._fail(Ret.INVALID_STOPS, err, owner, symbol, side, vol, price)
        native = self._native_wanted(kind)
        if native == "unsupported":
            return self._fail(Ret.NOT_SUPPORTED, "Sàn này không hỗ trợ lệnh chờ native loại '%s' (đặt Cài đặt > Lệnh chờ = auto để vỏ tự theo dõi)" % kind,
                              owner, symbol, side, vol, price)
        with self.lock:
            acc = self.account
            free = acc.equity() - acc.margin_used() - acc.reserved_margin()
            need = vol * price / acc.leverage
            if need > free + 1e-9:
                return self._fail(Ret.INSUFFICIENT_MARGIN, "Không đủ ký quỹ để giữ chỗ cho lệnh chờ: cần %.4f, khả dụng %.4f" % (need, free),
                                  owner, symbol, side, vol, price)
        nid = ""
        if native == "native":
            with self._trade_lock:
                try:
                    nid = str(self.broker.place_pending(symbol, side, kind, vol, price, stop_price, sl, tp, expiration or None,
                                                        "pyea-%s" % owner) or "")
                    self._order_fail = 0
                except BrokerError as e:
                    self._order_failed("Đặt lệnh chờ %s %s thất bại: %s" % (side, symbol, e))
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối lệnh chờ: %s" % e, requested_volume=vol)
            if not nid:
                return self._fail(Ret.REJECTED, "Sàn nhận lệnh chờ nhưng không trả mã lệnh - kiểm tra trên sàn", owner, symbol, side, vol, price)
        with self.lock:
            order = acc.add_pending(PendingOrder(id=0, symbol=symbol, side=side, kind=kind, volume=vol, price=price,
                                                 stop_price=stop_price, sl=sl, tp=tp, comment=comment, owner=owner,
                                                 created=tick.time, expiration=expiration, reason=reason, native_id=nid))
        label = {"limit": "Limit", "stop": "Stop", "stop_limit": "Stop-limit"}[kind]
        txt = reason or "Đặt lệnh chờ %s %s" % (side.upper(), label)
        d = dict(details or {})
        d.update({"loại": "%s %s" % (side, kind), "giá đặt": price, "SL": sl or "không đặt", "TP": tp or "không đặt",
                  "nơi giữ lệnh": ("trên sàn (native) #%s" % nid) if nid else "trong vỏ (giả lập)",
                  "hết hạn": ("%s" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(expiration))) if expiration else "đến khi huỷ"})
        if kind == "stop_limit":
            d["giá kích hoạt"] = stop_price
        self.add_event("pending", symbol, price, side, vol, order.id, "manual" if owner == "manual" else ("ai" if ai else "bot"),
                       txt, d, ai, 0.0, ctx, owner)
        self.log("LỆNH CHỜ #%d %s %s %s %.8g @ %.8g%s | %s [%s]" % (order.id, side.upper(), label, symbol, vol, price,
                 (" (kích hoạt %.8g)" % stop_price) if kind == "stop_limit" else "", txt, owner))
        self._emit(TradeUpdate(kind="order_placed", id=order.id, symbol=symbol, side=side, volume=vol, price=price, sl=sl, tp=tp,
                               source="bot" if owner != "manual" else "manual", reason=txt, retcode=Ret.PLACED, time=tick.time, owner=owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.PLACED, message="Đã đặt lệnh chờ #%d" % order.id, order=replace(order), price=price,
                           volume=vol, requested_volume=req_vol)

    def cancel_order(self, order_id, source="manual", reason="", ctx=None, _remote=False):
        with self.lock:
            o0 = self.account.pending.get(int(order_id))
        if o0 is not None and source not in FREEZE_EXEMPT:
            err = freeze_error_order(self.spec(o0.symbol), o0, self.ticks.get(o0.symbol))
            if err:
                self.log("Từ chối huỷ lệnh chờ #%d: %s" % (o0.id, err), "WARN")
                return OrderResult(ok=False, retcode=Ret.FROZEN, message=err)
        if o0 is not None and o0.native_id and not _remote and self.broker is not None:
            with self._trade_lock:
                try:
                    self.broker.cancel_pending(o0.native_id, o0.symbol)
                except BrokerError as e:
                    # lệnh có thể vừa khớp/đã bị huỷ trên sàn: đồng bộ rồi mới kết luận (không xoá bừa lệnh còn sống)
                    self._sync_native_pending(force=True)
                    with self.lock:
                        still = int(order_id) in self.account.pending
                    if still:
                        return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối huỷ lệnh chờ: %s" % e)
                    return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Lệnh chờ #%s đã khớp/huỷ trên sàn" % order_id)
        with self.lock:
            o = self.account.pending.pop(int(order_id), None)
        if o is None:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s" % order_id)
        label = SRC_EXTRA.get(source) or {"manual": "Thủ công", "bot": "Bot"}.get(source, source)
        why = reason or "Huỷ lệnh chờ (%s)" % label
        self.add_event("cancel", o.symbol, o.price, o.side, o.volume, o.id, source if source in ("manual", "bot", "ai") else "manual",
                       why, {"loại": "%s %s" % (o.side, o.kind), "giá đặt": o.price}, None, 0.0, ctx, o.owner)
        self.log("HUỶ lệnh chờ #%d %s %s %s | %s" % (o.id, o.side.upper(), o.kind, o.symbol, why))
        self._emit(TradeUpdate(kind="order_expired" if source == "expired" else "order_cancelled", id=o.id, symbol=o.symbol, side=o.side,
                               volume=o.volume, price=o.price, source=source, reason=why, time=self._now(), owner=o.owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã huỷ lệnh chờ #%d" % o.id, order=o, price=o.price, volume=o.volume)

    def cancel_all_orders(self, source="manual", reason="", owner=None, symbol=None):
        with self.lock:
            ids = [o.id for o in self.account.pending.values()
                   if (owner is None or o.owner == owner) and (symbol is None or o.symbol == symbol)]
        return sum(1 for i in ids if self.cancel_order(i, source, reason).ok)

    def modify_order(self, order_id, price=None, sl=None, tp=None, expiration=None, stop_price=None):
        with self.lock:
            o = self.account.pending.get(int(order_id))
            if o is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s" % order_id)
            o2 = replace(o)
        try:
            if price is not None:
                o2.price = float(price)
            if stop_price is not None:
                o2.stop_price = float(stop_price)
            if sl is not None:
                o2.sl = float(sl or 0.0)
            if tp is not None:
                o2.tp = float(tp or 0.0)
            if expiration is not None:
                o2.expiration = float(expiration or 0.0)
        except (TypeError, ValueError):
            return OrderResult(ok=False, retcode=Ret.INVALID_PRICE, message="Giá trị không phải số")
        tick, rc, msg = self._quote(o.symbol)
        if tick is None:
            return OrderResult(ok=False, retcode=rc, message=msg)
        ferr = freeze_error_order(self.spec(o.symbol), o, tick)
        if ferr:
            self.log("Từ chối sửa lệnh chờ #%d: %s" % (o.id, ferr), "WARN")
            return OrderResult(ok=False, retcode=Ret.FROZEN, message=ferr)
        err = None if o2.armed else self._validate_pending(o.symbol, o.side, o.kind, o2.price, o2.stop_price, tick)
        rc = Ret.INVALID_PRICE
        if err is None:
            err = validate_stops(self.spec(o.symbol), o.side, o2.price, o2.sl, o2.tp)
            rc = Ret.INVALID_STOPS
        if err is None and o2.expiration and o2.expiration <= tick.time:
            err, rc = "Thời hạn lệnh chờ đã qua", Ret.INVALID_EXPIRATION
        if err:
            self.log("Từ chối sửa lệnh chờ #%d: %s" % (o.id, err), "WARN")
            return OrderResult(ok=False, retcode=rc, message=err)
        if o.native_id and self.broker is not None and (o2.price != o.price or o2.sl != o.sl or o2.tp != o.tp):
            with self._trade_lock:
                try:
                    new_id = self.broker.modify_pending(o.native_id, o.symbol, price=o2.price if o2.price != o.price else None,
                                                        sl=o2.sl if o2.sl != o.sl else None, tp=o2.tp if o2.tp != o.tp else None)
                    if isinstance(new_id, str) and new_id:
                        o2.native_id = new_id                # một số sàn (Binance/OANDA) sửa = huỷ + đặt lại -> mã lệnh đổi
                except BrokerError as e:
                    self.log("Sàn từ chối sửa lệnh chờ #%d: %s" % (o.id, e), "WARN")
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối sửa lệnh chờ: %s" % e)
        with self.lock:
            cur = self.account.pending.get(o.id)
            if cur is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Lệnh chờ #%d vừa khớp/bị huỷ" % o.id)
            cur.price, cur.stop_price, cur.sl, cur.tp, cur.expiration = o2.price, o2.stop_price, o2.sl, o2.tp, o2.expiration
            cur.native_id = o2.native_id or cur.native_id
        self.log("Sửa lệnh chờ #%d: giá=%.8g SL=%.8g TP=%.8g" % (o.id, o2.price, o2.sl, o2.tp))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã sửa lệnh chờ #%d" % o.id, order=replace(o2), price=o2.price, volume=o2.volume)

    def _check_pending(self, tick):
        """Gọi mỗi tick (sau khi mark): hết hạn -> huỷ; chạm giá -> khớp (limit/stop) hoặc kích hoạt (stop_limit)."""
        with self.lock:
            orders = [o for o in self.account.pending.values() if o.symbol == tick.symbol]
        for o in orders:
            with self.lock:
                if o.id not in self.account.pending:
                    continue                                # vừa bị OCO huỷ (anh em khớp trước trong cùng tick) hoặc đã khớp
            if o.expiration and tick.time >= o.expiration:
                self.cancel_order(o.id, "expired", "Lệnh chờ hết hạn (hết hạn lúc %s)" % time.strftime("%H:%M:%S %d/%m", time.gmtime(o.expiration)))
                continue
            if o.native_id:
                continue                                    # lệnh nằm trên sàn: khớp do SÀN quyết định, vỏ chỉ đồng bộ (xem _sync_native_pending)
            ask, bid = tick.ask, tick.bid
            if o.kind == "stop_limit" and not o.armed:
                if (o.side == "buy" and ask >= o.stop_price) or (o.side == "sell" and bid <= o.stop_price):
                    with self.lock:
                        o.armed = True
                    self.log("Lệnh chờ #%d: giá kích hoạt %.8g đã chạm -> chuyển thành limit @ %.8g" % (o.id, o.stop_price, o.price))
                continue
            if o.kind in ("limit", "stop_limit"):
                hit = (o.side == "buy" and ask <= o.price) or (o.side == "sell" and bid >= o.price)
            else:
                hit = (o.side == "buy" and ask >= o.price) or (o.side == "sell" and bid <= o.price)
            if hit:
                self._fill_pending(o, tick)

    # ------------------------------------------------------------------ lệnh chờ native: chọn nơi giữ + đồng bộ với sàn
    def _native_wanted(self, kind):
        """'native' | 'emulated' | 'unsupported' (cài đặt pending_mode = auto|native|emulated)."""
        b = self.broker
        mode = str(self.settings.get("pending_mode") or "auto")
        if b is None or mode == "emulated":
            return "emulated"
        ok = kind in (getattr(b, "native_pending", None) or ())
        if ok:
            return "native"
        return "unsupported" if mode == "native" else "emulated"

    def _sync_native_pending(self, force=False):
        """Hỏi sàn danh sách lệnh chờ đang sống; lệnh nào của ta biến mất -> đã khớp hay đã huỷ? (chỉ live, chỉ khi có lệnh native)."""
        b = self.broker
        if b is None or not hasattr(b, "pending_orders"):
            return
        with self.lock:
            nat = [o for o in self.account.pending.values() if o.native_id]
        if not nat:
            return
        now = time.time()
        if not force and now < getattr(self, "_native_sync_due", 0.0):
            return
        self._native_sync_due = now + max(0.5, float(self.settings.get("native_sync_s") or 2.0))
        try:
            remote = b.pending_orders([(o.native_id, o.symbol) for o in nat])
            self.link_note("native", True)
        except BrokerError as e:
            self.link_note("native", False, e)
            if now - getattr(self, "_native_warn", 0.0) > 60:
                self._native_warn = now
                self.log("Không đồng bộ được lệnh chờ với sàn: %s" % e, "WARN")
            return
        for o in nat:
            if o.native_id not in remote:
                self._resolve_native_gone(o)

    def _resolve_native_gone(self, o):
        """Lệnh chờ native không còn trên sàn. Ưu tiên kết quả CHÍNH XÁC của sàn; nếu sàn không cho biết thì suy ra từ chênh lệch vị thế."""
        b = self.broker
        res = None
        if hasattr(b, "order_result"):
            try:
                res = b.order_result(o.native_id, o.symbol)
            except BrokerError:
                res = None
        state = (res or {}).get("state")
        if state == "open":
            return                                           # sàn nói lệnh vẫn sống (danh sách lệnh chờ chưa kịp phản ánh)
        fill_px, fill_qty = (res or {}).get("price"), (res or {}).get("qty")
        if state not in ("filled", "canceled", "expired", "rejected") and hasattr(b, "positions"):
            try:
                rp = b.positions()
            except BrokerError:
                rp = None
            if rp is not None:
                ex = float((rp.get(o.symbol) or {}).get("qty", 0.0))
                with self.lock:
                    local = sum((p.volume if p.side == "buy" else -p.volume) for p in self.account.positions.values() if p.symbol == o.symbol)
                diff = ex - local
                want = o.volume if o.side == "buy" else -o.volume
                if want * diff >= abs(want) * 0.5 - 1e-12 and diff != 0:
                    state, fill_qty = "filled", min(abs(diff), o.volume)
                    fill_px = float((rp.get(o.symbol) or {}).get("price") or 0.0) or None
                else:
                    state = "canceled"
        if state == "filled":
            qty = float(fill_qty or o.volume)
            try:
                px = float(fill_px or 0.0) or self.get_tick(o.symbol).mid
            except (FeedError, KeyError, AttributeError):
                px = float(fill_px or o.price)
            o._native_fill = Fill(px, qty, str((res or {}).get("ref") or ""))
            self._book_order(o.native_id)
            self.log("Lệnh chờ #%d đã KHỚP trên sàn: %.8g @ %.8g" % (o.id, qty, px))
            self._fill_pending(o, Tick(o.symbol, self._now(), px, px))
        elif state in ("canceled", "expired", "rejected"):
            self.cancel_order(o.id, "exchange", "Lệnh chờ không còn trên sàn (%s)" % state, _remote=True)
        # state None: chưa đủ thông tin (lỗi mạng khi hỏi vị thế) -> giữ nguyên, vòng sau thử lại

    def _fill_pending(self, o, tick):
        with self.lock:
            if self.account.pending.pop(o.id, None) is None:
                return
        inst = self.instances.get(o.owner)
        ctx = inst._context() if inst is not None else None
        why = o.reason or "Lệnh chờ %s %s #%d khớp" % (o.side, o.kind, o.id)
        px = tick.ask if o.side == "buy" else tick.bid
        res = self.send_order(o.symbol, o.side, o.volume, o.sl, o.tp, o.comment, o.owner,
                              "%s (giá %.8g, đặt @ %.8g)" % (why, px, o.price),
                              {"lệnh chờ": "%s #%d" % (o.kind, o.id), "giá đặt": o.price}, None, ctx, _pos_id=o.id, _validate=False,
                              _pending=o)
        if not res.ok:
            self.add_event("cancel", o.symbol, o.price, o.side, o.volume, o.id, "manual" if o.owner == "manual" else "bot",
                           "Lệnh chờ không khớp được: %s" % res.message, {"retcode": res.retcode}, None, 0.0, ctx, o.owner)
            self.log("Lệnh chờ #%d bị huỷ khi khớp: %s" % (o.id, res.message), "WARN")
            return
        self._emit(TradeUpdate(kind="order_filled", id=o.id, symbol=o.symbol, side=o.side, volume=res.volume, price=res.price,
                               sl=o.sl, tp=o.tp, source="bot" if o.owner != "manual" else "manual", reason=why, retcode=Ret.OK,
                               time=tick.time, owner=o.owner))
        self._oco_cancel_siblings(o)

    # ------------------------------------------------------------------ OCO (one-cancels-other) - do VỎ quản
    def link_oco(self, order_ids, owner=None):
        """Nối các lệnh chờ thành một nhóm OCO: khi MỘT lệnh khớp, vỏ huỷ các lệnh còn lại của nhóm. Chỉ cần ≥ 2 lệnh còn sống.
        `owner` != None: chỉ nối lệnh của chủ đó. -> OrderResult (ok: message chứa mã nhóm)."""
        try:
            ids = sorted({int(i) for i in order_ids})
        except (TypeError, ValueError):
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Mã lệnh chờ không hợp lệ")
        if len(ids) < 2:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="OCO cần ít nhất 2 lệnh chờ khác nhau")
        with self.lock:
            orders = [self.account.pending.get(i) for i in ids]
            missing = [i for i, o in zip(ids, orders) if o is None or (owner is not None and o.owner != owner)]
            if missing:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s (hoặc không phải của bạn)" % ", #".join(map(str, missing)))
            gid = "oco-%d" % ids[0]
            for o in orders:
                o.oco = gid
        self.log("OCO %s: nối các lệnh chờ %s" % (gid, ", ".join("#%d" % i for i in ids)))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message=gid)

    def _oco_cancel_siblings(self, filled):
        """Lệnh `filled` vừa khớp: huỷ mọi lệnh còn lại cùng nhóm OCO (cùng chủ)."""
        if not getattr(filled, "oco", ""):
            return
        with self.lock:
            sib = [o.id for o in self.account.pending.values() if o.oco == filled.oco and o.id != filled.id and o.owner == filled.owner]
        for sid in sib:
            r = self.cancel_order(sid, "oco", "OCO: lệnh chờ #%d cùng nhóm đã khớp" % filled.id)
            if not r.ok:
                self.log("OCO: không huỷ được lệnh chờ #%d (%s) - kiểm tra trên sàn" % (sid, r.message), "WARN")

    # ------------------------------------------------------------------ đóng / sửa vị thế
    def close_position(self, pos_id, source="bot", reason="", details=None, ai=None, ctx=None, volume=None):
        """Đóng toàn bộ hoặc MỘT PHẦN (volume < khối lượng vị thế). Trả về OrderResult (đúng = đã đóng)."""
        with self.lock:
            pos = self.account.positions.get(pos_id)
        if pos is None:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s" % pos_id)
        g = self._gate(pos.symbol, "sell" if pos.side == "buy" else "buy", closing=True)
        if g and g[0] == Ret.SYMBOL_MODE and self.spec(pos.symbol).trade_mode == "disabled":
            return OrderResult(ok=False, retcode=g[0], message=g[1])
        try:
            tick = self.get_tick(pos.symbol)
        except (FeedError, KeyError):
            return OrderResult(ok=False, retcode=Ret.NO_QUOTES, message="Chưa có giá %s" % pos.symbol)
        if time.time() < self._close_retry.get(pos_id, 0):
            return OrderResult(ok=False, retcode=Ret.REJECTED, message="Đang chờ thử lại sau lỗi đóng lệnh trước")
        vol = pos.volume
        if volume is not None:
            vol, err = validate_volume(self.spec(pos.symbol), volume)
            if err and vol <= 0:
                return OrderResult(ok=False, retcode=Ret.INVALID_VOLUME, message=err)
            vol = min(vol, pos.volume)
        partial = vol < pos.volume - 1e-12
        price = tick.bid if pos.side == "buy" else tick.ask
        self._prot_release(pos)                                  # SL/TP native: huỷ lệnh bảo vệ của vị thế này TRƯỚC khi đóng (tránh đóng đúp)
        with self._trade_lock:
            if self.broker is not None:
                try:
                    kw = {"ref": pos.ref} if (pos.ref and getattr(self.broker, "CLOSE_BY_REF", False)) else {}   # đóng ĐÚNG ticket của vị thế này (không FIFO)
                    fill = self.broker.market_order(pos.symbol, "sell" if pos.side == "buy" else "buy", vol, reduce_only=True, **kw)
                    price = fill.price
                    self._book_order(getattr(fill, "order_id", ""))
                    self._order_fail = 0
                except BrokerError as e:
                    self.reconcile_due(2.0)
                    self._close_retry[pos_id] = time.time() + 10
                    self._order_failed("Đóng lệnh #%d thất bại: %s (thử lại sau 10s)" % (pos_id, e))
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối/lỗi: %s" % e)
            with self.lock:
                if pos_id not in self.account.positions:          # luồng khác đã đóng
                    return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Vị thế #%s vừa được đóng" % pos_id)
                tr = self.account.reduce(pos_id, vol, price, tick.time, source) if partial else self.account.close(pos_id, price, tick.time, source)
        from .engine import SRC_LABEL
        label = SRC_LABEL.get(source) or SRC_EXTRA.get(source) or source
        tr.reason = label
        d = dict(details or {})
        d.setdefault("giá vào", pos.open_price)
        d.setdefault("giá ra", price)
        if partial:
            d.setdefault("đóng một phần", "%.8g / %.8g" % (vol, pos.volume))
        self.add_event("close", pos.symbol, price, pos.side, vol, pos.id, "ai" if (ai and source == "bot") else source,
                       reason or ("Bot đóng lệnh (bot không ghi lý do)" if source == "bot" else label), d, ai, tr.profit, ctx, pos.owner)
        self.log("%s #%d %s %s %.8g @ %.8g | %s | P/L %+.4f | %s" % ("ĐÓNG MỘT PHẦN" if partial else "ĐÓNG", tr.id, tr.side.upper(), pos.symbol,
                                                                       vol, price, label, tr.profit, reason or "-"))
        self.notify("Đóng lệnh %s %s (%s)" % (tr.side.upper(), pos.symbol, label), "P/L %+.4f @ %.8g" % (tr.profit, price))
        self._emit(TradeUpdate(kind="position_reduced" if partial else "position_closed", id=pos.id, symbol=pos.symbol, side=pos.side,
                               volume=vol, price=price, profit=tr.profit, source=source, reason=reason or label, retcode=Ret.OK,
                               time=tick.time, owner=pos.owner))
        self._save_trade(tr)
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã đóng %s%.8g @ %.8g" % ("một phần " if partial else "", vol, price),
                           price=price, volume=vol, profit=tr.profit)

    def close_by(self, pos_id, other_id, source="bot", reason=""):
        """Đóng vị thế `pos_id` bằng vị thế ngược chiều `other_id` cùng mã (MT5 hedging; tiết kiệm spread). Cần broker có close_by + ticket sàn (`ref`) của cả hai.
        Sổ app KHÔNG tự tính lãi/lỗ kiểu này: sau khi sàn xác nhận, đối soát theo ticket (đọc lịch sử giao dịch của sàn) sẽ ghi nhận hai vị thế đã đóng."""
        with self.lock:
            a, b = self.account.positions.get(pos_id), self.account.positions.get(other_id)
        if a is None or b is None:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s hoặc #%s" % (pos_id, other_id))
        if a.symbol != b.symbol or a.side == b.side:
            return OrderResult(ok=False, retcode=Ret.REJECTED, message="Đóng-bằng-đối-ứng cần hai vị thế CÙNG mã và NGƯỢC chiều")
        fn = getattr(self.broker, "close_by", None)
        if not callable(fn) or not (a.ref and b.ref):
            return OrderResult(ok=False, retcode=Ret.NOT_SUPPORTED, message="Sàn/cầu nối này không hỗ trợ đóng bằng lệnh đối ứng (cần MT5 hedging và ticket sàn của cả hai vị thế)")
        try:
            with self._trade_lock:
                fn(a.ref, b.ref)
        except BrokerError as e:
            return OrderResult(ok=False, retcode=Ret.REJECTED, message=str(e))
        except Exception as e:                                  # noqa: BLE001 - BridgeError của cầu nối
            return OrderResult(ok=False, retcode=Ret.REJECTED, message=str(e))
        self.add_event("close", a.symbol, 0.0, a.side, min(a.volume, b.volume), a.id, source, "Đóng bằng lệnh đối ứng #%s ↔ #%s%s" % (a.id, b.id, (": " + reason) if reason else ""),
                       {"đối ứng": b.id, "ticket": a.ref, "ticket đối ứng": b.ref}, None, 0.0, None, a.owner)
        self.reconcile_due(0.0)
        try:
            self.reconcile_now()
        except Exception as e:                                  # noqa: BLE001
            self.log("Đối soát sau đóng-bằng-đối-ứng lỗi: %s" % e, "WARN")
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã gửi lệnh đóng #%s bằng #%s; sổ app cập nhật theo đối soát với sàn" % (a.id, b.id))

    def close_all(self, source, reason, symbol=None, owner=None):
        with self.lock:
            ids = [p.id for p in self.account.positions.values()
                   if (symbol is None or p.symbol == symbol) and (owner is None or p.owner == owner)]
        return sum(1 for pid in ids if self.close_position(pid, source, reason).ok)

    def modify_position(self, pos_id, sl=None, tp=None):
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s" % pos_id)
            t = self.ticks.get(p.symbol)
            price = (t.bid if p.side == "buy" else t.ask) if t else p.open_price
            try:
                nsl = p.sl if sl is None else float(sl or 0.0)
                ntp = p.tp if tp is None else float(tp or 0.0)
            except (TypeError, ValueError):
                return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message="SL/TP không phải số")
            side = p.side
        if nsl != p.sl or ntp != p.tp:
            ferr = freeze_error_position(self.spec(p.symbol), p, self.ticks.get(p.symbol))
            if ferr:
                self.log("Từ chối sửa #%d: %s" % (pos_id, ferr), "WARN")
                return OrderResult(ok=False, retcode=Ret.FROZEN, message=ferr)
        err = validate_stops(self.spec(p.symbol), side, price, nsl, ntp)
        if err:
            self.log("Từ chối sửa #%d: %s" % (pos_id, err), "WARN")
            return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message=err)
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Vị thế #%s vừa đóng" % pos_id)
            covered, changed = p, (nsl != p.sl or ntp != p.tp)
        if changed:                                              # SL/TP native: gỡ lệnh bảo vệ mức cũ, vòng poll đặt lại mức mới (không đổi -> không đụng)
            self._prot_release(covered, edit=True)
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Vị thế #%s vừa đóng" % pos_id)
            p.sl, p.tp = nsl, ntp
        self.log("Sửa #%d: SL=%.8g TP=%.8g" % (pos_id, nsl, ntp))
        self._emit(TradeUpdate(kind="position_modified", id=pos_id, symbol=p.symbol, side=p.side, volume=p.volume, price=price,
                               sl=nsl, tp=ntp, source="bot" if p.owner != "manual" else "manual", retcode=Ret.OK, time=self._now(),
                               owner=p.owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã sửa SL/TP", price=price, volume=p.volume)

    # ------------------------------------------------------------------ an toàn
    def request_kill(self, reason="Người dùng bấm Kill switch"):
        self._cmds.put(("kill", reason))

    def kill_switch(self, reason="Kill switch"):
        """Thoát hiểm: chặn lệnh mới -> dừng mọi bot (để không mở lại) -> huỷ lệnh chờ -> đóng mọi vị thế."""
        self.halted = True
        self.log("KILL SWITCH: %s" % reason, "ERROR")
        for inst in list(self.instances.values()):
            inst.request_stop()
        n_o = self.cancel_all_orders("kill", "Kill switch: " + reason)
        n_p = self.close_all("kill", "Kill switch: " + reason)
        self.alarm("KILL SWITCH đã chạy", "Đã dừng mọi bot, huỷ %d lệnh chờ, đóng %d vị thế. Giao dịch bị khoá tới khi bạn mở lại." % (n_o, n_p))
        self._save_state()
        return n_p, n_o

    def resume_trading(self):
        if self.halted:
            self.halted = False
            self.log("Đã MỞ LẠI giao dịch sau Kill switch (các bot đã dừng cần bật lại thủ công)", "WARN")
        return True

    def reset_paper(self, balance=None):
        """Đặt lại tài khoản GIẢ LẬP về số dư ban đầu (xoá vị thế, lệnh chờ, lịch sử). Không dùng cho live."""
        if self.settings["mode"] == "live":
            return False
        from .engine import Account
        s = self.settings
        with self.lock:
            self.account = Account(float(balance or s["initial_balance"]), s["commission_pct"], s["leverage"])
            self.equity_hist.clear()
        self.log("ĐẶT LẠI tài khoản giả lập: số dư %.2f" % self.account.balance, "WARN")
        self._save_state()
        return True

    def _check_margin(self):
        """Margin call (cảnh báo) và stop-out (tự đóng vị thế lỗ nặng nhất)."""
        acc = self.account
        if acc is None:
            return
        with self.lock:
            lvl = acc.margin_level()
        if lvl is None:
            self._margin_alerted = False
            return
        s = self.settings
        mc, so = float(s.get("margin_call_level") or 0), float(s.get("stop_out_level") or 0)
        if so > 0 and lvl <= so:
            with self.lock:
                worst = min(acc.positions.values(), key=lambda p: p.profit, default=None)
            if worst is not None:
                self.close_position(worst.id, "stopout", "Stop-out: mức ký quỹ %.1f%% ≤ %.1f%% - đóng vị thế lỗ nặng nhất (#%d, %+.4f)" % (
                    lvl, so, worst.id, worst.profit))
            return
        if mc > 0 and lvl <= mc:
            if not self._margin_alerted:
                self._margin_alerted = True
                self.alarm("Margin call", "Mức ký quỹ %.1f%% ≤ %.1f%%. Hãy giảm vị thế hoặc nạp thêm vốn." % (lvl, mc))
        elif lvl > mc * 1.1:
            self._margin_alerted = False

    # ------------------------------------------------------------------ cảnh báo giá (tab Alerts của MT5)
    def _check_alerts(self, tick):
        if self.alerts is None:
            return
        for al, text in self.alerts.check(tick):
            self.log(text, "WARN")
            self.add_event("note", tick.symbol, tick.mid, "", 0.0, 0, "manual", text,
                           {"cảnh báo": al.describe(), "giá": tick.mid}, None, 0.0, None, "alert")
            self.alarm("Cảnh báo giá %s" % tick.symbol, text, critical=False)

    def _check_candle_alerts(self, symbol, tf):
        """Một nến (symbol, tf) vừa đóng: tính các cảnh báo chỉ báo (RSI/EMA) trên chuỗi nến ĐÃ ĐÓNG."""
        if self.alerts is None or (symbol, tf) not in self.alerts.ind_needs():
            return
        b = self.builders.get((symbol, tf))
        if b is None:
            return
        with self.lock:
            closes = [c.close for c in b.closed]
        for al, text in self.alerts.check_candles(symbol, tf, closes):
            self.log(text, "WARN")
            self.add_event("note", symbol, closes[-1], "", 0.0, 0, "manual", text,
                           {"cảnh báo": al.describe(), "giá": closes[-1]}, None, 0.0, None, "alert")
            self.alarm("Cảnh báo chỉ báo %s" % symbol, text, critical=False)

    def _ensure_alert_builders(self):
        """Cảnh báo chỉ báo đã lưu cần nến: tạo builder (nạp lịch sử) cho (mã, khung) còn thiếu - thử lại ở vòng poll sau nếu lỗi."""
        if self.alerts is None or self.sync:
            return
        for sym, tf in sorted(self.alerts.ind_needs()):
            if (sym, tf) in self.builders:
                continue
            try:
                self.get_builder(sym, tf)
            except (FeedError, KeyError, AttributeError) as e:
                self._prot_warn("alert" + sym + tf, "Chưa nạp được nến %s %s cho cảnh báo chỉ báo: %s" % (sym, tf, e))

    def alert_add(self, symbol, kind, value, note="", repeat=False, tf="", period=14, period2=0):
        sym = symbol.strip().upper()
        ref = 0.0
        if kind == "pct":
            try:
                ref = self.get_tick(sym).mid
            except (FeedError, KeyError, AttributeError):
                raise ValueError("Cảnh báo %% cần có giá hiện tại của %s" % sym)
        a = self.alerts.add(sym, kind, value, ref, note, repeat, tf, period, period2)
        if kind in ("rsi_above", "rsi_below", "ma_up", "ma_down"):
            try:
                self.get_builder(sym, tf)                              # cần nến để tính; lỗi -> gỡ cảnh báo vừa thêm và báo rõ
            except (FeedError, KeyError, AttributeError) as e:
                self.alerts.remove(a.id)
                raise ValueError("Không nạp được nến %s %s để tính chỉ báo: %s" % (sym, tf, e))
        self.log("Đặt cảnh báo giá #%d: %s" % (a.id, a.describe()))
        return a

    def alert_remove(self, alert_id):
        return self.alerts.remove(alert_id)

    # ------------------------------------------------------------------ chống treo / sức khoẻ
    def _check_hung(self):
        lim = float(self.settings.get("bot_callback_timeout") or 0)
        if lim <= 0:
            return
        now = time.monotonic()
        for inst in list(self.instances.values()):
            if inst.status == "running" and inst.cb_started and not inst.hung and now - inst.cb_started > lim:
                inst.mark_hung(now - inst.cb_started)

    def health(self):
        from .shell import connection_health
        h = connection_health(self.needed_symbols() if self.account is not None else [], self._feed_fail, self._tick_wall,
                              float(self.settings.get("stale_after") or 0))
        h["failing_total"] = sum(1 for v in self._feed_fail.values() if v > 0)
        bd, berr, _ = self.broker_link()                          # kết nối SÀN (khác kết nối giá): các lần gọi API sàn định kỳ lỗi liên tiếp
        h["broker_down"], h["broker_error"] = bd, berr
        return h
