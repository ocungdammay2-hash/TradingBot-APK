"""
Che bí mật khỏi văn bản TRƯỚC KHI ghi ra đĩa / hiện trong chat / gửi cho AI.

Vì sao: người dùng hay dán API key vào chat để nhờ AI «sửa lỗi kết nối»; bot in key ra nhật ký bằng `api.log(...)`;
nhật ký/chat lại được đưa vào gói chẩn đoán. Che ở một chỗ (chung cho mọi nơi ghi) thay vì dặn từng chỗ tự nhớ.

Che 4 loại (đều là heuristic - KHÔNG phải bảo đảm tuyệt đối, nên các gói xuất ra ngoài vẫn xoá khoá theo tên trường):
  1. giá trị ĐÃ BIẾT: mọi secret trong settings/agents (`learn()` gọi từ prefs.apply) - khớp chính xác, mạnh nhất;
  2. khối PEM (khoá riêng), `Authorization: Bearer ...`, cặp `tên_khoá = giá_trị` / `"tên_khoá": "giá_trị"`;
  3. tiền tố khoá nhà cung cấp quen thuộc (sk-..., AIza..., nvapi-..., gsk_..., csk-..., exnsk_...);
  4. (chế độ `aggressive`) mọi chuỗi ≥ 40 ký tự liền nhau; chế độ thường chỉ che chuỗi dài có CẢ chữ lẫn số
     để không làm hỏng mã nguồn/tên hàm dài trong chat.
"""
import re
import threading

MASK = "***"
MIN_KNOWN = 8                                   # secret ngắn hơn thế quá dễ trùng chữ thường -> không che theo giá trị

_NAME = r"(?:secret|token|password|passphrase|private[_-]?key|api[_-]?key|apikey|signature|authorization|access[_-]?key|client[_-]?secret)"
_PEM = re.compile(r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?(?:-----END [A-Z0-9 ]*PRIVATE KEY-----|\Z)", re.S)
_BEARER = re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=\-]{12,}")
_JSON_PAIR = re.compile(r'("[^"\\]*' + _NAME + r'[^"\\]*"\s*:\s*)"[^"]*"', re.I)
_KV_PAIR = re.compile(r"(?i)\b([A-Za-z0-9_\-]*" + _NAME + r"[A-Za-z0-9_\-]*)(\s*[=:]\s*)(['\"]?)((?=[A-Za-z0-9_\-+/=]*\d)[A-Za-z0-9_\-+/=]{12,})\3")
_PREFIXED = re.compile(r"(?<![A-Za-z0-9_\-])(?:sk-[A-Za-z0-9_\-]{16,}|AIza[0-9A-Za-z_\-]{30,}|nvapi-[A-Za-z0-9_\-]{16,}|gsk_[A-Za-z0-9]{16,}"
                       r"|csk-[A-Za-z0-9]{16,}|exnsk_[A-Za-z0-9_\-]{8,}|xox[bpsa]-[A-Za-z0-9\-]{10,}|ghp_[A-Za-z0-9]{20,})")
_LONG_ANY = re.compile(r"(?<![A-Za-z0-9])[A-Za-z0-9_\-+/=]{40,}(?![A-Za-z0-9])")
_LONG_MIXED = re.compile(r"(?<![A-Za-z0-9_])(?=[A-Za-z0-9+/=_\-]*[A-Za-z])(?=[A-Za-z0-9+/=_\-]*\d)[A-Za-z0-9+/=_\-]{40,}(?![A-Za-z0-9_])")

_lock = threading.Lock()
_known = []                                     # secret đã biết, dài trước (để che chuỗi dài trước chuỗi con)


def learn(values):
    """Ghi nhớ các giá trị bí mật (iterable chuỗi) - thay thế danh sách cũ."""
    out = set()
    for v in values or ():
        if isinstance(v, str):
            v = v.strip()
            if len(v) >= MIN_KNOWN and not v.startswith("enc:v1:"):
                out.add(v)
                for line in v.splitlines():     # khoá PEM nhiều dòng: che cả từng dòng nội dung
                    line = line.strip()
                    if len(line) >= 24 and not line.startswith("-----"):
                        out.add(line)
    with _lock:
        _known[:] = sorted(out, key=len, reverse=True)


def learn_settings(settings):
    """Học mọi giá trị secret trong settings (theo SECRET_SETTING_KEYS) + khoá AI nếu truyền kèm."""
    from .keystore import SECRET_SETTING_KEYS
    learn([(settings or {}).get(k) for k in SECRET_SETTING_KEYS])


def add_known(values):
    """Thêm (không thay) giá trị bí mật, vd khoá của các AI agent."""
    with _lock:
        cur = set(_known)
    for v in values or ():
        if isinstance(v, str) and len(v.strip()) >= MIN_KNOWN and not v.startswith("enc:v1:"):
            cur.add(v.strip())
    with _lock:
        _known[:] = sorted(cur, key=len, reverse=True)


def known_count():
    with _lock:
        return len(_known)


def redact(text, aggressive=False):
    """Trả về `text` đã che bí mật. Không bao giờ ném lỗi; không phải chuỗi -> str()."""
    if text is None:
        return text
    t = text if isinstance(text, str) else str(text)
    if len(t) < 6:
        return t
    with _lock:
        known = list(_known)
    for k in known:
        if k in t:
            t = t.replace(k, MASK)
    if "PRIVATE KEY" in t:
        t = _PEM.sub(MASK, t)
    t = _BEARER.sub(lambda m: m.group(1) + " " + MASK, t)
    t = _JSON_PAIR.sub(r'\1"' + MASK + '"', t)
    t = _KV_PAIR.sub(lambda m: m.group(1) + m.group(2) + m.group(3) + MASK + m.group(3), t)
    t = _PREFIXED.sub(MASK, t)
    t = (_LONG_ANY if aggressive else _LONG_MIXED).sub(MASK, t)
    return t


def redact_obj(obj, aggressive=False, _depth=0):
    """Che đệ quy mọi chuỗi trong dict/list (dùng cho sự kiện/ngữ cảnh trước khi ghi)."""
    if _depth > 8:
        return obj
    if isinstance(obj, str):
        return redact(obj, aggressive)
    if isinstance(obj, dict):
        return {k: redact_obj(v, aggressive, _depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [redact_obj(v, aggressive, _depth + 1) for v in obj]
    return obj
