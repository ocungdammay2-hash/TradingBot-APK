"""THỬ TẢI / RÒ RỈ BỘ NHỚ trong sandbox (không cần Kivy/thiết bị): N bot × M mã chạy liên tục trên phiên giả lập + hàng loạt backtest nối tiếp.
Kiểm tra: không ngoại lệ/bot tự tắt bất thường, SỔ SÁCH NHẤT QUÁN (số dư = vốn đầu + tổng lãi lệnh đã đóng khi hết vị thế), RAM không tăng đều (so nửa sau với nửa đầu).
KHÔNG thay thế thử 24/7 trên máy thật (mạng, pin, hệ điều hành giết app...). Chạy: python -m pyea.stress [--bots 8] [--symbols 8] [--ticks 20000] [--backtests 100]"""
import argparse
import gc
import json
import os
import random
import shutil
import tempfile
import time

from .backtest import _ReplayFeed, run_backtest
from .engine import Account, CandleBuilder, TradingSession
from .loadprobe import read_proc
from .sdk import Candle, Tick
from .settings import default_settings

BOTS = ["ma_cross", "rsi_reversion", "breakout", "dca"]
TF_S = 60


def _candles(rnd, n, p=100.0, t0=1.7e9):
    out = []
    for i in range(n):
        o = p
        p *= 1 + rnd.gauss(0, 0.002)
        out.append(Candle(t0 + i * TF_S, o, max(o, p) * 1.001, min(o, p) * 0.999, p, 10.0))
    return out


def _rss():
    gc.collect()
    return read_proc(os.getpid()).get("rss_mb") or 0.0


def _slope(xs):
    """RAM nửa sau - nửa đầu (MB): dương lớn = tăng đều = nghi rò rỉ."""
    if len(xs) < 4:
        return 0.0
    h = len(xs) // 2
    return sum(xs[h:]) / (len(xs) - h) - sum(xs[:h]) / h


def live(n_bots=8, n_syms=8, ticks=20000, seed=11, samples=10, plot_cap=2000):
    rnd = random.Random(seed)
    tmp = tempfile.mkdtemp(prefix="pyea-stress-")
    from .storage import Store
    store = Store(tmp)
    store.seed_examples()
    st = default_settings()
    st.update(mode="paper", exchange="simulated", initial_balance=1_000_000.0, leverage=10.0, commission_pct=0.02, spread_pct=0.01, max_loss_pct=0.0, state_file=None)
    sess = TradingSession(st, sync=True, feed=_ReplayFeed())
    sess.account = Account(st["initial_balance"], 0.02, 10.0)           # sổ sự kiện giữ mặc định của phiên chạy thật (deque 800), KHÔNG nới như backtest
    sess.status = "running"
    sess.ready.set()
    syms = ["SYM%d" % i for i in range(n_syms)]
    price, t0 = {}, 1.7e9
    for k, sy in enumerate(syms):
        cs = _candles(rnd, 300, 50.0 + 10 * k, t0)
        b = CandleBuilder(TF_S, max_len=1500, tf="1m")
        b.seed(cs[:-1], cs[-1].time)
        sess.builders[(sy, "1m")] = b
        price[sy] = cs[-1].close
    insts = []
    for i in range(n_bots):
        for sy in syms:
            name = BOTS[i % len(BOTS)]
            path = os.path.join(store.bots_dir, name + ".py")
            inst = sess.attach(path, sy, "1m", {}, iid="%s-%d" % (sy, i))
            inst.plot_cap = plot_cap
            inst.start()
            insts.append(inst)
    t, rss, cpu0, errors = t0 + 300 * TF_S, [], time.process_time(), 0
    per = max(1, ticks // samples)
    start = time.time()
    for n in range(ticks):
        sy = syms[n % n_syms]
        price[sy] *= 1 + rnd.gauss(0, 0.0015)
        t += 10.0 / n_syms                                    # 10 giây thị trường mỗi vòng quét hết các mã: ~6 nến/giờ-mô-phỏng, nhiều lần đóng nến
        sess.process_tick(Tick(sy, t, price[sy] * 0.9999, price[sy] * 1.0001))
        if (n + 1) % per == 0:
            rss.append(_rss())
    wall, cpu = time.time() - start, time.process_time() - cpu0
    halted = [i.iid for i in insts if i.status not in ("running", "starting")]
    acct = sess.account
    with sess.lock:
        open_n = len(acct.positions)
        closed = list(acct.trades)
        realized = sum(x.profit for x in closed)
        bal, start_bal = acct.balance, acct.start_balance
    out = {"bots": n_bots, "symbols": n_syms, "instances": len(insts), "ticks": ticks, "wall_s": wall, "cpu_s": cpu, "ticks_per_s": ticks / max(wall, 1e-9),
           "trades_closed": len(closed), "open_positions": open_n, "bots_not_running": halted, "rss_mb": rss, "rss_growth_mb": _slope(rss),
           "events": len(sess.events), "errors": sum(i.cbstats.errors for i in insts),
           "balance_check": {"balance": bal, "start": start_bal, "realized": realized, "diff_when_flat": (bal - (start_bal + realized)) if open_n == 0 else None}}
    shutil.rmtree(tmp, ignore_errors=True)
    return out


def backtests(n=100, bars=1500, seed=5, samples=10):
    rnd = random.Random(seed)
    tmp = tempfile.mkdtemp(prefix="pyea-stress-bt-")
    from .storage import Store
    store = Store(tmp)
    store.seed_examples()
    st = default_settings()
    st.update(initial_balance=10000.0, leverage=10.0, commission_pct=0.02, spread_pct=0.01, max_loss_pct=0.0, close_on_stop=True)
    rss, fails, trades, t0 = [], 0, 0, time.time()
    per = max(1, n // samples)
    for i in range(n):
        path = os.path.join(store.bots_dir, BOTS[i % len(BOTS)] + ".py")
        r = run_backtest(path, {}, st, "SYM", "1m", _candles(rnd, bars), warmup=100, mode="ohlc")
        fails += 0 if r.ok else 1
        trades += len(r.trades)
        if (i + 1) % per == 0:
            rss.append(_rss())
    out = {"backtests": n, "bars": bars, "failed": fails, "trades": trades, "wall_s": time.time() - t0, "rss_mb": rss, "rss_growth_mb": _slope(rss)}
    shutil.rmtree(tmp, ignore_errors=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bots", type=int, default=8)
    ap.add_argument("--symbols", type=int, default=8)
    ap.add_argument("--ticks", type=int, default=20000)
    ap.add_argument("--backtests", type=int, default=100)
    a = ap.parse_args()
    res = {"live": live(a.bots, a.symbols, a.ticks), "backtests": backtests(a.backtests)}
    print(json.dumps(res, indent=1, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
