"""
Kiểu thanh giá khác nến thời gian (như MT5/TradingView): Renko, Range, và GỘP N nến (khung tuỳ chỉnh, vd 7 × M5 = 35 phút).
Thuần Python, chỉ dùng để VẼ/PHÂN TÍCH - bot và backtest vẫn chạy trên nến thời gian thật.
Nến OHLC không có tick bên trong nên đường đi giá trong nến được giả định (nến tăng: O→L→H→C, nến giảm: O→H→L→C) - cùng quy ước với backtest.
Hệ quả: Renko/Range dựng từ nến M1 gần với dữ liệu tick thật hơn dựng từ H1; kết quả chỉ là xấp xỉ.
"""
from .sdk import Candle

KINDS = ("candle", "renko", "range", "agg")
NAMES = {"candle": "Nến thời gian", "renko": "Renko", "range": "Range", "agg": "Gộp N nến"}


def atr(candles, n=14):
    """Trung bình true range n nến cuối (0 nếu thiếu dữ liệu)."""
    if len(candles) < 2:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i - 1]
        trs.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
    trs = trs[-n:]
    return sum(trs) / len(trs) if trs else 0.0


def auto_size(candles, kind):
    """Kích thước gạch/biên độ mặc định theo ATR(14): Renko = 1 ATR, Range = 0.5 ATR."""
    a = atr(candles)
    return a if kind == "renko" else a * 0.5


def path(c):
    return [c.open, c.low, c.high, c.close] if c.close >= c.open else [c.open, c.high, c.low, c.close]


def aggregate(candles, n):
    """Gộp mỗi n nến liên tiếp thành 1 (tính từ nến đầu tiên). Nến cuối chưa đủ n vẫn giữ (đang hình thành)."""
    n = int(n)
    if n <= 1:
        return list(candles)
    out = []
    for i in range(0, len(candles), n):
        g = candles[i:i + n]
        out.append(Candle(g[0].time, g[0].open, max(c.high for c in g), min(c.low for c in g), g[-1].close, sum(c.volume for c in g)))
    return out


def _stamp(raw, step):
    """raw: [(candle_index, candle, o, h, l, c)] -> Candle có thời gian tăng dần và KHÔNG trùng nhau; khối lượng chia đều theo nến nguồn."""
    per, out = {}, []
    for ci, *_ in raw:
        per[ci] = per.get(ci, 0) + 1
    seen = {}
    for ci, src, o, h, l, c in raw:
        k = seen.get(ci, 0)
        seen[ci] = k + 1
        t = src.time + (step * k / (per[ci] + 1.0) if step else k * 1e-3)
        out.append(Candle(t, o, h, l, c, src.volume / per[ci]))
    return out


def renko(candles, brick, step=0):
    """Renko: gạch mới khi giá đi thêm `brick` theo xu hướng; đảo chiều cần 2 gạch (đi ngược `2*brick` so với đỉnh/đáy gạch cuối)."""
    if brick <= 0 or not candles:
        return []
    raw = []
    base = candles[0].open
    top = bot = None                                    # biên của gạch cuối: gạch tăng [bot, top], giảm [bot, top]
    direction = 0
    for ci, c in enumerate(candles):
        for p in path(c):
            if direction == 0:
                if p >= base + brick:
                    direction, bot, top = 1, base, base + brick
                    raw.append((ci, c, bot, top, bot, top))
                elif p <= base - brick:
                    direction, bot, top = -1, base - brick, base
                    raw.append((ci, c, top, top, bot, bot))
                else:
                    continue
            while True:
                if direction == 1:
                    if p >= top + brick:
                        bot, top = top, top + brick
                        raw.append((ci, c, bot, top, bot, top))
                    elif p <= bot - brick:
                        direction = -1
                        top, bot = bot, bot - brick
                        raw.append((ci, c, top, top, bot, bot))
                    else:
                        break
                else:
                    if p <= bot - brick:
                        top, bot = bot, bot - brick
                        raw.append((ci, c, top, top, bot, bot))
                    elif p >= top + brick:
                        direction = 1
                        bot, top = top, top + brick
                        raw.append((ci, c, bot, top, bot, top))
                    else:
                        break
    return _stamp(raw, step)


def range_bars(candles, rng, step=0):
    """Range: mỗi thanh có biên độ (cao-thấp) đúng `rng`; thanh sau mở tại giá đóng thanh trước."""
    if rng <= 0 or not candles:
        return []
    raw = []
    o = h = l = candles[0].open
    for ci, c in enumerate(candles):
        for p in path(c):
            h, l = max(h, p), min(l, p)
            guard = 0
            while h - l >= rng - 1e-12 and guard < 10000:
                guard += 1
                if p >= h:                              # phá lên: đóng ở đáy + rng
                    close = l + rng
                    raw.append((ci, c, o, close, l, close))
                    o = h = l = close
                    h = max(h, p)
                else:                                   # phá xuống
                    close = h - rng
                    raw.append((ci, c, o, h, close, close))
                    o = h = l = close
                    l = min(l, p)
    return _stamp(raw, step)


def transform(candles, kind, param=None, step=0):
    """Điểm vào chung cho UI. kind: candle | renko | range | agg. param: kích thước gạch/biên độ (None = tự động theo ATR) hoặc N (agg)."""
    if kind == "agg":
        return aggregate(candles, int(param or 2))
    if kind in ("renko", "range"):
        size = float(param) if param else auto_size(candles, kind)
        return (renko if kind == "renko" else range_bars)(candles, size, step)
    return list(candles)
