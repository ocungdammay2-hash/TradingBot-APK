"""
PyEA SDK - những gì người viết bot (file .py) cần dùng.

    from pyea import BaseBot, Input, ta

    class MyBot(BaseBot):
        name = "Bot của tôi"
        inputs = {"lot": Input(0.01, "Khối lượng", min=0)}

        def on_tick(self, tick):
            ...

Tương đương MT5:  OnInit -> on_init | OnTick -> on_tick | OnDeinit -> on_deinit
                  `input double Lot=0.01;` -> inputs = {"lot": Input(0.01, ...)}
"""
import math
import re
from dataclasses import dataclass, field
from typing import Optional


# --------------------------------------------------------------------------
# Dữ liệu thị trường / lệnh
# --------------------------------------------------------------------------
@dataclass
class Tick:
    symbol: str
    time: float          # epoch giây (UTC)
    bid: float
    ask: float
    tradeable: bool = True   # False = sàn báo thị trường đang đóng/không giao dịch được (OANDA: cờ "tradeable" của API pricing)

    @property
    def mid(self):
        return (self.bid + self.ask) / 2.0

    @property
    def price(self):
        return self.mid


@dataclass
class Candle:
    time: float          # thời điểm MỞ nến (epoch giây, UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class AIAnswer:
    """Kết quả của `self.api.ask_ai(...)`. Luôn trả về (không ném lỗi): kiểm `status`.
    status: ok · pending (đang hỏi nền, gọi lại cùng `key` sau) · error · disabled (người dùng chưa bật / backtest) · limited (hết hạn mức) · no_replay (backtest không có câu trả lời đã ghi).
    `data` = dict đã kiểm theo `schema` (rỗng nếu không có schema hoặc lỗi); `text` = nguyên văn trả lời."""
    status: str = "error"
    ok: bool = False
    pending: bool = False
    text: str = ""
    data: dict = field(default_factory=dict)
    error: str = ""
    key: str = ""
    agent: str = ""
    model: str = ""
    web: bool = False
    cached: bool = False
    age_s: float = 0.0
    retry_after_s: float = 0.0

    def get(self, name, default=None):
        return self.data.get(name, default) if isinstance(self.data, dict) else default


@dataclass
class Position:
    id: int
    symbol: str
    side: str            # "buy" | "sell"
    volume: float
    open_price: float
    open_time: float
    sl: float = 0.0      # 0 = không đặt
    tp: float = 0.0      # 0 = không đặt
    comment: str = ""
    fee: float = 0.0     # phí đã trả khi mở
    profit: float = 0.0  # lãi/lỗ thả nổi (đã trừ phí mở)
    owner: str = ""      # id bot (instance) đã mở lệnh; "manual" = đặt tay
    swap: float = 0.0    # swap/funding đã dồn tích (dương = đã trả); chỉ backtest/sàn có swap mới khác 0
    ref: str = ""        # mã vị thế TRÊN SÀN (ticket MT...) khi sàn có; "" = không biết -> vỏ không gắn SL/TP native và đóng theo cách cũ
    adopted: bool = False  # True: vị thế do vỏ NHẬN TỪ SÀN khi đối soát (không phải app mở) -> SL/TP native không tự động đụng vào vị thế gốc


@dataclass
class Trade:
    """Một lệnh đã đóng."""
    id: int
    symbol: str
    side: str
    volume: float
    open_price: float
    close_price: float
    open_time: float
    close_time: float
    profit: float        # đã trừ phí
    reason: str          # "SL" | "TP" | "Bot" | "Thủ công" | "Dừng bot" ...
    comment: str = ""
    owner: str = ""
    swap: float = 0.0    # phần swap/funding đã trừ trong `profit`
    fee: float = 0.0     # tổng phí mở+đóng đã trừ trong `profit`


@dataclass
class TradeEvent:
    """Một điểm trên biểu đồ: vào lệnh / thoát lệnh / ghi chú tín hiệu - kèm LÝ DO."""
    id: int
    kind: str                 # "open" | "close" | "note"
    time: float               # thời gian thị trường (epoch giây)
    price: float
    side: str = ""            # "buy" | "sell"
    volume: float = 0.0
    pos_id: int = 0
    source: str = "bot"       # bot | ai | sl | tp | manual | risk | stop
    reason: str = ""          # lý do dạng văn bản
    details: dict = field(default_factory=dict)   # điều kiện/thông số kích hoạt (bot ghi)
    context: dict = field(default_factory=dict)   # ảnh chụp tự động: chỉ báo, tham số, nến...
    ai: Optional[dict] = None                     # nếu quyết định dựa trên tín hiệu AI
    profit: float = 0.0       # chỉ có ở "close"
    wall_time: float = 0.0
    symbol: str = ""
    owner: str = ""


# --------------------------------------------------------------------------
# Hợp đồng giữa VỎ (app) và BOT: phiên bản API, mã kết quả lệnh, kết quả có cấu trúc, lệnh chờ, sự kiện giao dịch
# --------------------------------------------------------------------------
API_VERSION = "1.6"     # 1.0: on_init/on_tick/on_bar/on_deinit · 1.1: +on_trade/on_timer, lệnh chờ, OrderResult, *_info(), đóng một phần
                        # 1.2: +api.trace(), OrderResult.partial/remaining (khớp một phần), AccountInfo.margin_mode, `param_aliases` (đổi tên tham số)
                        # 1.3: +api.store/api.shared, api.oco(), api.stats(), on_tester(), Ret.FROZEN + SymbolInfo.freeze_level, `# @permission: network(host)`
                        # 1.4: +api.calendar() (lịch kinh tế), Ret.NEWS_BLOCK (người dùng bật chặn lệnh mới quanh tin)
                        # 1.5: +AccountInfo.broker_* (tài sản/ký quỹ/mức ký quỹ do SÀN báo), Position.adopted (vị thế nhập từ sàn qua đối soát)
                        # 1.6: +api.ask_ai()/api.ask_ai_info() (bot gọi AI, AIAnswer), `# @permission: ai_ask`


class Ret:
    """Mã kết quả lệnh chuẩn hoá (giống retcode của MT5; mọi sàn đều quy về bộ mã này để bot xử lý đồng nhất)."""
    OK = "OK"                                   # lệnh thị trường đã khớp
    PLACED = "PLACED"                           # lệnh chờ đã được nhận
    INVALID_VOLUME = "INVALID_VOLUME"           # khối lượng sai (<=0, dưới min, trên max)
    INVALID_PRICE = "INVALID_PRICE"             # giá lệnh chờ sai phía so với thị trường
    INVALID_STOPS = "INVALID_STOPS"             # SL/TP sai phía hoặc sát giá hơn mức tối thiểu của sàn
    INVALID_EXPIRATION = "INVALID_EXPIRATION"   # thời hạn lệnh chờ đã qua
    INSUFFICIENT_MARGIN = "INSUFFICIENT_MARGIN"  # không đủ ký quỹ khả dụng (đã tính ký quỹ giữ cho lệnh chờ)
    TRADE_DISABLED = "TRADE_DISABLED"           # chế độ chỉ-xem (read-only) hoặc đã bấm Kill switch
    SYMBOL_MODE = "SYMBOL_MODE"                 # mã đang ở chế độ close-only/long-only/short-only/disabled
    MARKET_CLOSED = "MARKET_CLOSED"             # thị trường đóng cửa
    NO_QUOTES = "NO_QUOTES"                     # chưa có giá hoặc giá đã cũ quá ngưỡng
    NOT_SUPPORTED = "NOT_SUPPORTED"             # vd bán khống trên Binance spot
    HEDGE_NOT_ALLOWED = "HEDGE_NOT_ALLOWED"     # sàn gộp vị thế: không giữ đồng thời mua và bán cùng mã
    REJECTED = "REJECTED"                       # sàn từ chối / lỗi gửi lệnh
    NOT_FOUND = "NOT_FOUND"                     # không có vị thế/lệnh chờ này (hoặc không phải của bot)
    FROZEN = "FROZEN"                           # giá đang trong vùng freeze level: không sửa/huỷ được lệnh chờ hoặc SL/TP lúc này (thử lại sau)
    NEWS_BLOCK = "NEWS_BLOCK"                   # đang trong cửa sổ quanh tin kinh tế quan trọng mà người dùng đã bật «chặn lệnh mới»: thử lại sau khi hết cửa sổ
    ERROR = "ERROR"


@dataclass
class PendingOrder:
    """Lệnh chờ (limit / stop / stop_limit). Id dùng CHUNG bộ đếm với vị thế: khi khớp, vị thế GIỮ NGUYÊN id của lệnh chờ."""
    id: int
    symbol: str
    side: str                 # "buy" | "sell"
    kind: str                 # "limit" | "stop" | "stop_limit"
    volume: float
    price: float              # limit: giá chờ khớp · stop: giá kích hoạt · stop_limit: giá LIMIT sau khi kích hoạt
    stop_price: float = 0.0   # chỉ stop_limit: giá kích hoạt (sau đó thành lệnh limit tại `price`)
    sl: float = 0.0
    tp: float = 0.0
    comment: str = ""
    owner: str = ""
    created: float = 0.0
    expiration: float = 0.0   # epoch giây UTC; 0 = đến khi huỷ (GTC)
    reason: str = ""
    armed: bool = False       # stop_limit đã kích hoạt, đang chờ khớp limit
    native_id: str = ""       # != "": lệnh đang nằm TRÊN SÀN (native); vỏ không tự theo dõi giá mà đồng bộ trạng thái với sàn
    oco: str = ""             # != "": nhóm OCO (one-cancels-other) - khi một lệnh trong nhóm KHỚP, vỏ huỷ các lệnh còn lại (xem api.oco)


@dataclass
class OrderResult:
    """Kết quả CÓ CẤU TRÚC của buy/sell/buy_limit/.../close/modify (như OrderSend của MT5).
    `if res:` đúng khi thành công. Tương thích bot cũ: `res.id`, `res.open_price`... đọc từ vị thế/lệnh chờ."""
    ok: bool = False
    retcode: str = Ret.ERROR
    message: str = ""
    position: Optional[Position] = None
    order: Optional[PendingOrder] = None
    price: float = 0.0              # giá khớp (lệnh thị trường) hoặc giá đặt (lệnh chờ)
    volume: float = 0.0             # khối lượng thực tế (đã chuẩn hoá theo step của sàn)
    requested_volume: float = 0.0
    slippage: float = 0.0           # |giá khớp - giá lúc gửi| / giá lúc gửi (%)
    request_id: str = ""
    profit: float = 0.0             # lệnh đóng: lãi/lỗ đã chốt
    partial: bool = False           # sàn chỉ khớp MỘT PHẦN (ok vẫn True; `volume` = phần đã khớp)
    remaining: float = 0.0          # phần chưa khớp (chỉ khi partial) - bot tự quyết có gửi tiếp hay không

    def __bool__(self):
        return bool(self.ok)

    @property
    def ticket(self):
        o = self.position or self.order
        return o.id if o is not None else 0

    def __getattr__(self, name):
        if name.startswith("_") or name in ("position", "order"):
            raise AttributeError(name)
        o = self.__dict__.get("position") or self.__dict__.get("order")
        if o is not None:
            return getattr(o, name)
        raise AttributeError(name)


@dataclass
class TradeUpdate:
    """Tham số của bot.on_trade(update) - như OnTradeTransaction của MT5. kind:
    order_placed | order_filled | order_cancelled | order_expired | order_rejected |
    position_opened | position_closed | position_reduced | position_modified (source: sl/tp/manual/bot/risk/stop...)."""
    kind: str
    id: int = 0
    symbol: str = ""
    side: str = ""
    volume: float = 0.0
    price: float = 0.0
    sl: float = 0.0
    tp: float = 0.0
    profit: float = 0.0
    source: str = ""
    reason: str = ""
    retcode: str = ""
    time: float = 0.0
    owner: str = ""


@dataclass
class SymbolInfo:
    symbol: str
    bid: float = 0.0
    ask: float = 0.0
    spread: float = 0.0
    digits: int = 5
    tick_size: float = 0.0          # 0 = không ràng buộc
    contract_size: float = 1.0
    volume_min: float = 0.0
    volume_max: float = 0.0         # 0 = không giới hạn
    volume_step: float = 0.0
    stops_level: float = 0.0        # khoảng cách tối thiểu SL/TP so với giá (đơn vị giá)
    freeze_level: float = 0.0       # trong khoảng này quanh giá KHÔNG sửa/huỷ được lệnh chờ / sửa SL-TP (đơn vị giá, như MT5); 0 = không có
    trade_mode: str = "full"        # full | long_only | short_only | close_only | disabled
    market_open: bool = True
    leverage: float = 1.0
    margin_per_unit: float = 0.0    # ký quỹ cho 1 đơn vị khối lượng ở giá hiện tại


@dataclass
class AccountInfo:
    balance: float = 0.0
    equity: float = 0.0
    margin: float = 0.0             # ký quỹ đang dùng
    reserved: float = 0.0           # ký quỹ giữ cho lệnh chờ
    free_margin: float = 0.0
    margin_level: float = 0.0       # equity/margin*100 (0 nếu chưa có vị thế)
    leverage: float = 1.0
    currency: str = "USD"
    mode: str = "paper"             # paper | live
    demo: bool = True               # paper hoặc testnet/practice
    netting: bool = False           # sàn gộp vị thế 1 chiều/mã
    trade_allowed: bool = True
    read_only: bool = False
    halted: bool = False            # Kill switch đang bật
    server_time: float = 0.0
    margin_mode: str = ""           # cross | isolated | "" (sàn không có khái niệm này / chưa biết)
    # Số do SÀN báo (giống khung «Giao dịch» của MT5), làm mới mỗi `account_state_interval` giây khi chạy live. Các trường trên (balance/equity/margin/...)
    # là SỔ RIÊNG của app tự tính - với sàn kiểu MT chúng không khớp số của sàn; muốn quyết định theo số thật của sàn thì đọc broker_* khi broker_synced=True.
    broker_synced: bool = False     # True: broker_* là số sàn vừa báo (chưa cũ); False: sàn không báo/chưa lấy được -> broker_* = 0 (KHÔNG có nghĩa là bằng 0 thật)
    broker_balance: float = 0.0
    broker_equity: float = 0.0
    broker_margin: float = 0.0
    broker_free_margin: float = 0.0
    broker_margin_level: float = 0.0  # equity/margin*100 theo sàn (0 nếu chưa có ký quỹ)
    broker_profit: float = 0.0        # lãi/lỗ thả nổi của TOÀN tài khoản (kể cả vị thế đặt tay/EA khác) = equity - balance - credit


def jsonable(obj, depth=0):
    """Chuyển bất kỳ giá trị nào thành dạng JSON an toàn (NaN/inf -> None, lạ -> str)."""
    if depth > 6:
        return str(obj)
    if obj is None or isinstance(obj, (bool, int, str)):
        return obj
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {str(k): jsonable(v, depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [jsonable(v, depth + 1) for v in obj]
    if hasattr(obj, "__dataclass_fields__"):
        return {k: jsonable(getattr(obj, k), depth + 1) for k in obj.__dataclass_fields__}
    return str(obj)


# --------------------------------------------------------------------------
# Khai báo tham số (giống `input` của MQ5)
# --------------------------------------------------------------------------
_TRUE = {"1", "true", "yes", "on", "co", "có", "y"}
_FALSE = {"0", "false", "no", "off", "khong", "không", "n", ""}


class Group:
    """Đặt tiêu đề nhóm cho các `Input` khai báo SAU nó trong thân lớp (như `input group "..."` của MQL5):

        class MyBot(BaseBot):
            g1 = Group("Tín hiệu")
            fast = Input(10, "SMA nhanh", min=2, max=200)
            g2 = Group("Quản lý vốn")
            lot = Input(0.01, "Khối lượng", min=0.01, step=0.01)
    """

    def __init__(self, name):
        self.name = str(name)


_HEX6 = re.compile(r"^#?([0-9a-fA-F]{6})$")
_HHMM = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
_DT = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[ T]([01]?\d|2[0-3]):([0-5]\d))?$")
SUBTYPES = {"color": "#RRGGBB (vd #FF8800)", "time": "HH:MM (vd 09:30)", "datetime": "YYYY-MM-DD HH:MM (vd 2026-12-31 23:59)", "text": ""}


class Input:
    """
    Khai báo 1 tham số để app tự sinh ô nhập trên giao diện (CHUẨN THAM SỐ CỦA PYEA - xem docs/BOT_INPUTS.md).

    Input(default, label=None, min=None, max=None, step=None,
          choices=None, help="", group=None, secret=False, subtype=None)

    Kiểu dữ liệu suy ra từ `default`: bool / int / float / str.
    `choices` (ô chọn xổ xuống, như `enum` của MQL5) nhận: danh sách [..] · dict {giá_trị: "Nhãn hiển thị"} · lớp `enum.Enum`.
    `subtype` cho chuỗi: "color" (#RRGGBB) · "time" (HH:MM) · "datetime" (YYYY-MM-DD HH:MM) · "text" (chuỗi dài) - app kiểm định dạng khi nhập.
    """

    def __init__(self, default, label=None, min=None, max=None, step=None,
                 choices=None, help="", group=None, secret=False, subtype=None):
        import enum as _enum
        self.choice_labels = {}
        if isinstance(choices, type) and issubclass(choices, _enum.Enum):
            choices = {m.value: m.name.replace("_", " ") for m in choices}
            if isinstance(default, _enum.Enum):
                default = default.value
        if isinstance(choices, dict):
            self.choice_labels = {str(k): str(v) for k, v in choices.items()}
            choices = list(choices)
        if subtype is not None and subtype not in SUBTYPES:
            raise ValueError("subtype phải là một trong %s" % sorted(SUBTYPES))
        self.default = default
        self.label = label
        self.min = min
        self.max = max
        self.step = step
        self.choices = list(choices) if choices else None
        self.help = help
        self.group = group
        self.secret = secret
        self.subtype = subtype
        if self.choices:
            self.kind = "choice"
        elif isinstance(default, bool):
            self.kind = "bool"
        elif isinstance(default, int):
            self.kind = "int"
        elif isinstance(default, float):
            self.kind = "float"
        else:
            self.kind = "str"

    def coerce(self, raw):
        """Ép giá trị người dùng nhập về đúng kiểu; sai thì raise ValueError."""
        k = self.kind
        if k == "bool":
            if isinstance(raw, bool):
                return raw
            s = str(raw).strip().lower()
            if s in _TRUE:
                return True
            if s in _FALSE:
                return False
            raise ValueError("phải là bật/tắt")
        if k == "choice":
            for c in self.choices:
                if str(c) == str(raw) or self.choice_labels.get(str(c)) == str(raw):
                    return c
            raise ValueError("giá trị không nằm trong danh sách")
        if k == "str":
            v = str(raw)
            st = self.subtype
            if st == "color":
                m = _HEX6.match(v.strip())
                if not m:
                    raise ValueError("phải là màu dạng #RRGGBB")
                return "#" + m.group(1).upper()
            if st == "time":
                m = _HHMM.match(v.strip())
                if not m:
                    raise ValueError("phải là giờ dạng HH:MM")
                return "%02d:%s" % (int(m.group(1)), m.group(2))
            if st == "datetime":
                m = _DT.match(v.strip())
                if not m:
                    raise ValueError("phải là ngày-giờ dạng YYYY-MM-DD HH:MM")
                return "%s-%s-%s %02d:%s" % (m.group(1), m.group(2), m.group(3), int(m.group(4) or 0), m.group(5) or "00")
            return v
        # số
        try:
            s = str(raw).strip().replace(",", ".")
            f = float(s)
        except (TypeError, ValueError):
            raise ValueError("phải là số")
        if f != f or f in (float("inf"), float("-inf")):
            raise ValueError("phải là số hợp lệ")
        if k == "int":
            if f != int(f):
                raise ValueError("phải là số nguyên")
            val = int(f)
        else:
            val = f
        if self.min is not None and val < self.min:
            raise ValueError("phải ≥ %s" % self.min)
        if self.max is not None and val > self.max:
            raise ValueError("phải ≤ %s" % self.max)
        return val

    def label_of(self, value):
        """Nhãn hiển thị của một giá trị trong ô chọn (mặc định chính giá trị)."""
        return self.choice_labels.get(str(value), str(value))

    def display(self, value):
        """Chuỗi hiển thị trong ô nhập."""
        if self.kind == "bool":
            return bool(value)
        if self.kind == "float":
            return ("%.10g" % float(value))
        return str(value)


class Params(dict):
    """dict nhưng truy cập được bằng dấu chấm: self.p.fast"""

    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError:
            raise AttributeError(key)


# --------------------------------------------------------------------------
# Lớp cha của mọi bot
# --------------------------------------------------------------------------
class BaseBot:
    name = None            # tên hiển thị (mặc định: tên class)
    version = "1.0"
    author = ""
    description = ""
    inputs = {}            # {"tên_tham_số": Input(...)}

    _RESERVED = {"api", "params", "p", "name", "version", "author", "description", "inputs", "log"}

    def __init__(self, api, params):
        self.api = api                 # đối tượng giao dịch (xem README)
        self.params = Params(params)
        self.p = self.params           # viết tắt: self.p.fast
        self._sync_attrs()

    def _sync_attrs(self):
        """Mỗi tham số còn là thuộc tính của bot (self.fast == self.p.fast) - giống biến `input` của MQ5."""
        for k, v in self.params.items():
            if k.startswith("_") or k in self._RESERVED or callable(getattr(type(self), k, None)):
                continue
            try:
                setattr(self, k, v)
            except AttributeError:
                pass

    def _set_params(self, new):
        """Engine gọi khi người dùng đổi tham số lúc bot đang chạy (sau on_deinit('params'), trước on_init)."""
        self.params.clear()
        self.params.update(new)
        self._sync_attrs()

    # ---- các hàm sự kiện: ghi đè trong bot của bạn ----
    def on_init(self):
        """Gọi 1 lần khi bot khởi động. Trả về False để huỷ chạy (INIT_FAILED)."""

    def on_tick(self, tick):
        """Gọi mỗi khi có giá mới."""

    def on_bar(self, candle):
        """Gọi khi 1 nến vừa ĐÓNG (candle = nến đã đóng)."""

    def on_trade(self, update):
        """Gọi (sau khi on_tick/on_bar hiện tại chạy xong) mỗi khi có biến động lệnh CỦA BOT NÀY: lệnh chờ khớp/bị huỷ/hết hạn,
        vị thế mở/đóng/đóng một phần, chạm SL/TP... `update` là TradeUpdate (xem sdk.TradeUpdate). Không cần polling positions()."""

    def on_timer(self):
        """Gọi định kỳ sau self.api.set_timer(giây) - kể cả khi không có tick (cuối tuần, mất giá)."""

    def on_tester(self):
        """Chỉ gọi ở BACKTEST/TỐI ƯU (như OnTester() của MT5): sau khi lệnh còn mở đã được đóng, trước on_deinit. Trả về một SỐ (fitness
        tuỳ chọn) - chọn «Fitness (on_tester)» ở ô «Xếp theo» của Tối ưu hoá/Walk-forward để xếp theo tiêu chí của riêng bot, vd
        `s = self.api.stats(); return s["profit"] / (1 + s["max_drawdown"])`. Không trả số hữu hạn -> bỏ qua. Live không bao giờ gọi."""

    def on_deinit(self, reason):
        """Gọi khi bot dừng HOẶC trước khi đổi tham số. reason: 'user' | 'error' | 'max_loss' | 'params' (đổi tham số,
        ngay sau đó on_init được gọi lại với tham số mới - giống MT5 REASON_PARAMETERS) ..."""

    # ---- tiện ích ----
    def log(self, *args):
        self.api.log(*args)
