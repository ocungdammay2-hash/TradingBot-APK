"""
Chat AI nhiều model (API kiểu OpenAI /chat/completions):
  - Chat 1 AI           : trò chuyện riêng với 1 model
  - Nhóm AI + người dùng: các model lần lượt trả lời, thấy lời của nhau
  - Nhóm AI tự thảo luận: các model tự bàn về thị trường theo chu kỳ, 1 model "chốt"
                          ra tín hiệu (JSON) -> bot đọc qua `self.api.ai_signal`

Bot luôn là bên quyết định cuối: AI chỉ đưa tín hiệu, bot tự áp dụng khối lượng/SL/TP.
"""
import json
import re
import threading
import time
import traceback
from collections import OrderedDict

from . import airec
from . import indicators as ta
from . import redact
from .feeds import FeedError, http_json
from .sdk import Input

# --------------------------------------------------------------------------
# Nhà cung cấp (đều dùng chuẩn OpenAI-compatible). Tên model thay đổi thường xuyên
# -> "example" chỉ là gợi ý, hãy kiểm tra danh sách model hiện hành của nhà cung cấp.
# --------------------------------------------------------------------------
# "doc": trang tài liệu chính thức đã đối chiếu URL; "checked": ngày đối chiếu (YYYY-MM-DD) - "" = CHƯA xác minh được.
# URL gốc đối chiếu với tài liệu của từng nhà cung cấp; `example` (model gợi ý) đổi nhanh hơn nhiều - lỗi 404/"model not found" nghĩa là hãy chọn model khác.
PRESETS = OrderedDict([
    ("OpenRouter", {"url": "https://openrouter.ai/api/v1", "example": "openai/gpt-oss-120b:free",
                    "note": "Model có đuôi :free là miễn phí (giới hạn lượt/ngày) - danh sách :free đổi thường xuyên, "
                            "xem GET /api/v1/models; nếu lỗi 404 hãy chọn model khác",
                    "doc": "https://openrouter.ai/docs/quickstart", "checked": "2026-10-27", "model_checked": ""}),
    ("Groq", {"url": "https://api.groq.com/openai/v1", "example": "llama-3.3-70b-versatile",
              "note": "Tốc độ cao; có gói miễn phí giới hạn lượt (xem console.groq.com)",
              "doc": "https://console.groq.com/docs/openai", "checked": "2026-10-27", "model_checked": "2026-10-27"}),
    ("Google Gemini", {"url": "https://generativelanguage.googleapis.com/v1beta/openai",
                       "example": "gemini-3.8-flash",
                       "note": "Lấy key ở Google AI Studio. Tài liệu hiện khuyên model 3.x cho dự án mới; "
                               "gemini-2.5-flash chỉ còn cho tài khoản đã dùng trước đây",
                       "doc": "https://ai.google.dev/gemini-api/docs/openai", "checked": "2026-10-27", "model_checked": "2026-10-27"}),
    ("Cerebras", {"url": "https://api.cerebras.ai/v1", "example": "",
                  "note": "Tự nhập model (xem tài liệu). Gói miễn phí KHÔNG xác minh được - trang giá ghi tín dụng thử "
                          "có thời hạn, cần thẻ: xem cerebras.ai/pricing",
                  "doc": "https://inference-docs.cerebras.ai/resources/openai", "checked": "2026-10-27", "model_checked": ""}),
    ("Mistral", {"url": "https://api.mistral.ai/v1", "example": "mistral-small-latest",
                 "note": "Model gợi ý chưa xác minh với tài liệu hiện hành - nếu lỗi hãy nhập model khác (vd mistral-large-latest có trong tài liệu)",
                 "doc": "https://docs.mistral.ai/api/", "checked": "2026-10-27", "model_checked": ""}),
    ("NVIDIA NIM", {"url": "https://integrate.api.nvidia.com/v1", "example": "",
                    "note": "Tự nhập model theo bảng model của NVIDIA (dạng nhà-phát-hành/tên-model)",
                    "doc": "https://docs.api.nvidia.com/nim/reference/llm-apis", "checked": "2026-10-27", "model_checked": ""}),
    ("Máy chủ riêng", {"url": "http://192.168.1.10:11434/v1", "example": "",
                       "note": "Ollama/vLLM/LM Studio tự host - dùng cho model tài chính chuyên biệt "
                               "(vd Fin-R1, FinGPT). Đổi IP cho đúng máy chủ của bạn",
                       "doc": "", "checked": "", "model_checked": ""}),
    ("Tuỳ chỉnh", {"url": "", "example": "", "note": "Nhập Base URL của bất kỳ API OpenAI-compatible",
                   "doc": "", "checked": "", "model_checked": ""}),
])

AGENT_INPUTS = OrderedDict([
    ("name", Input("AI 1", "Tên hiển thị")),
    ("preset", Input("OpenRouter", "Nhà cung cấp", choices=list(PRESETS))),
    ("base_url", Input("", "Base URL", help="Để trống = dùng theo nhà cung cấp")),
    ("model", Input("", "Model", help="Bắt buộc nhập (hoặc dùng model gợi ý của nhà cung cấp nếu để trống)")),
    ("api_key", Input("", "API key", secret=True)),
    ("role", Input("Nhà phân tích kỹ thuật", "Vai trò",
                   help="Vd: Phân tích kỹ thuật / Quản lý rủi ro / Trader chốt lệnh")),
    ("temperature", Input(0.4, "Temperature", min=0.0, max=2.0)),
    ("decider", Input(False, "AI chốt quyết định (chế độ tự thảo luận)")),
    ("enabled", Input(True, "Bật")),
])


def default_agent(n=1):
    d = {k: v.default for k, v in AGENT_INPUTS.items()}
    d["name"] = "AI %d" % n
    return d


class AIError(Exception):
    pass


def resolve_agent(agent):
    preset = PRESETS.get(agent.get("preset"), PRESETS["Tuỳ chỉnh"])
    url = (agent.get("base_url") or "").strip() or preset["url"]
    model = (agent.get("model") or "").strip() or preset["example"]
    return url.rstrip("/"), model, (agent.get("api_key") or "").strip()


_THINK = re.compile(r"<think>.*?</think>", re.S | re.I)


def chat_completion(agent, messages, max_tokens=800, timeout=90):
    url, model, key = resolve_agent(agent)
    if not url:
        raise AIError("Chưa có Base URL")
    if not model:
        raise AIError("Chưa nhập model")
    headers = {"X-Title": "PyEA Runner"}
    if key:
        headers["Authorization"] = "Bearer " + key
    body = {"model": model, "messages": messages, "max_tokens": int(max_tokens),
            "temperature": float(agent.get("temperature", 0.4))}
    try:
        res = http_json(url + "/chat/completions", headers=headers, method="POST",
                        body=body, timeout=timeout)
    except FeedError as e:
        raise AIError(str(e))
    if isinstance(res, dict) and res.get("error"):
        err = res["error"]
        raise AIError(str(err.get("message", err)) if isinstance(err, dict) else str(err))
    try:
        content = res["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise AIError("Phản hồi không hợp lệ: %s" % str(res)[:200])
    if isinstance(content, list):
        content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
    content = _THINK.sub("", content or "").strip()
    if not content:
        raise AIError("Model trả về nội dung rỗng")
    return content


# --------------------------------------------------------------------------
# Prompt
# --------------------------------------------------------------------------
SDK_CHEATSHEET = """\
=== SDK PyEA (để viết/sửa bot) ===
from pyea import BaseBot, Input, ta
class MyBot(BaseBot):
    name = "Tên"; version = "1.0"; description = "Mô tả"
    inputs = {"lot": Input(0.01, "Khối lượng", min=0, help="...", group="Nhóm"),   # float/int/bool/str
              "mode": Input("a", "Chế độ", choices=["a", "b"])}                    # ô chọn
    def on_init(self): ...                 # trả False để huỷ chạy
    def on_tick(self, tick): ...           # tick.bid, tick.ask, tick.mid, tick.time
    def on_bar(self, candle): ...          # nến vừa đóng: open, high, low, close, volume, time
    def on_deinit(self, reason): ...
Dùng tham số: self.p.lot  | ghi log: self.log("...")
self.api: symbol, timeframe (mỗi lần GẮN bot vào 1 tài sản = 1 instance riêng, tham số riêng), tick, balance, equity, ai_signal (dict hoặc None)
  Bot chỉ thấy và đóng/sửa được LỆNH CỦA CHÍNH NÓ (không đụng lệnh thủ công / bot khác)
  candles(count, include_current=False) -> list Candle | closes(count)
  candles(count, include_current=False, timeframe=None)  # timeframe='1h' = đa khung giờ (khung lớn hơn, chia hết khung bot)
  buy(volume, sl=0, tp=0, comment="", request_id="") / sell(...) -> OrderResult  (sl/tp là GIÁ, 0 = không đặt)
    `if res:` đúng khi khớp; res.retcode (OK, INVALID_VOLUME, INVALID_STOPS, INSUFFICIENT_MARGIN, TRADE_DISABLED, SYMBOL_MODE,
    MARKET_CLOSED, NO_QUOTES, NOT_SUPPORTED, HEDGE_NOT_ALLOWED, REJECTED, NOT_FOUND, FROZEN, NEWS_BLOCK) + res.message + res.position/res.price/res.volume
    request_id: bot retry cùng id trong 2 phút -> không gửi lệnh trùng. Vỏ tự làm tròn khối lượng theo step của sàn.
    res.partial=True khi sàn chỉ khớp MỘT PHẦN (ok vẫn True; res.volume = phần đã khớp, res.remaining = phần chưa khớp; vỏ KHÔNG tự gửi tiếp - bot tự quyết).
  Lệnh chờ (vỏ tự theo dõi giá nên giống nhau trên mọi sàn; khi khớp, vị thế giữ id của lệnh chờ; có giữ chỗ ký quỹ):
    buy_limit/sell_limit/buy_stop/sell_stop(volume, price, sl=0, tp=0, comment="", expiration=0)  # expiration = epoch giờ thị trường (tick.time + giây)
    buy_stop_limit/sell_stop_limit(volume, stop_price, price, ...) | orders(side=None) | cancel_order(order) | modify_order(order, price=None, sl=None, tp=None, expiration=None)
  positions(side=None) | close(pos, reason="", volume=None)  # volume nhỏ hơn = đóng MỘT PHẦN | close_all(side=None) | modify(pos, sl=None, tp=None)
  Thông tin vỏ: version, account_info() (balance, equity, margin, free_margin, margin_level, leverage, demo, netting, trade_allowed, margin_mode='cross'|'isolated'|'', currency...; balance/equity/margin là SỔ APP tự tính - số của SÀN ở broker_synced + broker_equity/broker_margin/broker_free_margin/broker_margin_level/broker_profit),
    symbol_info(symbol=None) (volume_min/max/step, stops_level, freeze_level, trade_mode, spread, market_open...), time_info(), data_dir (thư mục riêng của bot)
  Trạng thái bền: self.api.store (riêng của bot, sống qua khởi động lại) và self.api.shared (chung mọi bot, như GlobalVariable của MT5):
    get(key, default=None) | set(key, value) | incr(key, delta=1) | delete(key) | has(key) | keys() | items() | clear() | size()
    value phải là JSON (số/chuỗi/list/dict; không NaN/set); giới hạn ~500 khoá, 64KB/giá trị. Đừng lưu khoá API ở đây.
  oco(a, b, ...)  # nối các lệnh chờ của bot thành nhóm OCO: một lệnh khớp thì vỏ huỷ các lệnh còn lại
  stats() -> dict thống kê lệnh ĐÃ ĐÓNG của bot (trades, win_rate, profit, profit_factor, expectancy, max_drawdown, ...)
  Retcode FROZEN: lệnh chờ/SL/TP nằm trong vùng đóng băng (freeze level) nên không sửa/huỷ được lúc này - thử lại sau.
  calendar(hours=24, min_impact="medium") -> list dict tin kinh tế sắp ra liên quan mã của bot (ts, currency, title, impact 0-3, forecast, previous); rỗng nếu chưa bật lịch.
  Retcode NEWS_BLOCK: người dùng bật «chặn lệnh mới quanh tin» và đang trong cửa sổ tin - lệnh MỚI bị từ chối (đóng lệnh vẫn được); thử lại sau khi hết cửa sổ.
  Mạng: bot mặc định KHÔNG gọi được mạng. Khai báo đầu file `# @permission: network(api.example.com)`; người dùng phải cho phép, và chỉ cưỡng chế
    khi bot chạy ở tiến trình riêng. Đừng dùng mạng nếu không thật sự cần (backtest không có mạng).
  def on_tester(self): ...  # chỉ ở backtest/tối ưu (như OnTester của MT5): trả MỘT SỐ làm fitness để tối ưu xếp theo «Fitness (on_tester)»
  api.ai_signal có thêm model, prompt_hash; trong backtest chỉ có khi người dùng bật «Phát lại tín hiệu AI đã ghi», nếu không luôn là None
    -> bot phải chạy đúng cả khi ai_signal là None.
  Sự kiện: def on_trade(self, u): ...  # u.kind: order_placed/order_filled/order_cancelled/order_expired/order_rejected/position_opened/
                                       #   position_reduced/position_closed/position_modified; u.id, u.symbol, u.side, u.volume, u.price, u.profit, u.source, u.reason, u.retcode
            def on_timer(self): ...    # sau self.api.set_timer(giây); set_timer(0) = tắt
  Khai báo đầu file: `# @api_min: 1.1` (vỏ cũ hơn sẽ từ chối nạp). Vỏ CHẶN bot dùng subprocess/ctypes/eval/exec/os.system (trừ khi bật Chế độ nhà phát triển).
  plot(name, value, time=None)  # vẽ đường chỉ báo lên biểu đồ
  trace(text, **values)  # ghi vết quyết định (chỉ khi người dùng bật «Trace» trên thẻ bot); api.trace_enabled = True nếu đang bật
  Đổi tên tham số giữa các phiên bản bot: khai báo trong lớp `param_aliases = {"tên_cũ": "tên_mới"}` để giá trị người dùng đã lưu không mất.
Position: id, side('buy'/'sell'), volume, open_price, sl, tp, profit
ta: sma, ema, rsi, atr(candles, n), stdev, bollinger -> (mid, up, low), macd -> (macd, signal, hist),
    highest, lowest, sma_series, ema_series, rsi_series, crossed_up(a0,b0,a1,b1), crossed_down(...)
  Kiểu MT5 (trả list cùng độ dài nến, None = chưa đủ dữ liệu; đúng công thức MT5): ma_series(values, n, 'sma|ema|smma|lwma'),
    macd_series(values) -> (macd, signal, hist) [tín hiệu = SMA như MT5], stoch_series(candles) -> (%K, %D), adx_series(candles) -> (adx, +di, -di),
    atr_series, cci_series, wpr_series, momentum_series, bollinger_series(values) -> (mid, up, low), sar_series(candles),
    ichimoku_series(candles), mfi_series, obv_series, ao_series, applied_price(candles, 'close|open|high|low|median|typical|weighted')
Không dùng thư viện ngoài (numpy/pandas không có sẵn)."""

DECISION_PROMPT = (
    "Dựa trên dữ liệu thị trường và cuộc thảo luận ở trên, hãy đưa ra QUYẾT ĐỊNH CUỐI CÙNG. "
    "Chỉ trả về DUY NHẤT một đối tượng JSON, không thêm chữ nào khác:\n"
    '{"action":"buy|sell|hold|close_all","confidence":0.0-1.0,"sl_pct":số,"tp_pct":số,"reason":"lý do ngắn"}\n'
    "sl_pct/tp_pct là % cách giá hiện tại (0 nếu không đề xuất). Nếu không chắc chắn hãy chọn hold."
)


def build_system(agent, others, bot_name, bot_source, params, market_text, include_source=True):
    parts = [
        "Bạn là «%s» - %s. Bạn là thành viên trong ứng dụng PyEA Runner (chạy bot giao dịch Python "
        "trên điện thoại, kiểu MT5 + file EA)." % (agent.get("name"), agent.get("role") or "trợ lý giao dịch"),
        "Quy tắc: trả lời bằng tiếng Việt, ngắn gọn, đi thẳng vào ý; KHÔNG bịa số liệu - chỉ dùng dữ liệu "
        "được cung cấp; nhắc rủi ro khi cần (giao dịch có thể mất vốn, không có gì chắc chắn).",
    ]
    if others:
        parts.append("Các thành viên khác trong nhóm: %s. Tin nhắn của họ hiện dạng [Tên]: nội dung. "
                     "Đừng lặp lại ý đã có; đồng ý thì nói ngắn; phản biện khi thấy sai." % ", ".join(others))
    if bot_name:
        parts.append("Bot đang chọn: %s | tham số hiện tại: %s" % (bot_name, json.dumps(params, ensure_ascii=False)))
    if include_source and bot_source:
        src = bot_source if len(bot_source) <= 14000 else bot_source[:14000] + "\n# ... (cắt bớt)"
        parts.append("Mã nguồn bot hiện tại:\n```python\n%s\n```" % src)
        parts.append(SDK_CHEATSHEET)
        parts.append("Khi người dùng muốn SỬA bot: giải thích ngắn thay đổi, rồi trả về TOÀN BỘ file mới trong "
                     "MỘT khối ```python ... ``` (giữ cấu trúc BaseBot, khai báo inputs cho mọi tham số mới). "
                     "Không tự ý đổi code khi người dùng chưa yêu cầu. Khi được nhờ giải thích: nêu thuật toán, "
                     "điều kiện vào/ra lệnh, quản lý vốn, các tham số và điểm yếu/rủi ro.")
    parts.append("DỮ LIỆU THỊ TRƯỜNG HIỆN TẠI:\n" + (market_text or "(chưa có)"))
    return "\n\n".join(parts)


def _g(x):
    return "%.6g" % x


def market_context(snap):
    """Tóm tắt thị trường + tài khoản từ BotRunner.snapshot() thành văn bản ngắn."""
    if not snap or not snap.get("ready"):
        return "Chưa có dữ liệu thị trường (hãy chạy bot ở chế độ paper để có giá và nến)."
    candles = snap["candles"]
    closed = candles[:-1] if len(candles) > 1 else candles
    closes = [c.close for c in closed]
    lines = ["%s | khung %s | chế độ %s | bid %s ask %s" % (snap["symbol"], snap["timeframe"], snap["mode"],
                                                          _g(snap["bid"]), _g(snap["ask"]))]
    last = closed[-20:]
    if last:
        lines.append("20 nến đã đóng gần nhất (cũ→mới, O/H/L/C): " +
                     "; ".join("%s/%s/%s/%s" % (_g(c.open), _g(c.high), _g(c.low), _g(c.close)) for c in last))
    ind = []
    for label, val in (("SMA20", ta.sma(closes, 20)), ("SMA50", ta.sma(closes, 50)),
                       ("EMA20", ta.ema(closes, 20)), ("RSI14", ta.rsi(closes, 14)),
                       ("ATR14", ta.atr(closed, 14)), ("Cao50", ta.highest([c.high for c in closed], 50)),
                       ("Thấp50", ta.lowest([c.low for c in closed], 50))):
        if val is not None:
            ind.append("%s=%s" % (label, _g(val)))
    if ind:
        lines.append("Chỉ báo: " + ", ".join(ind))
    lines.append("Tài khoản: balance %.2f, equity %.2f, lãi/lỗ %+.2f%% , drawdown tối đa %.2f%%, %d lệnh đã đóng "
                 "(thắng %.0f%%)" % (snap["balance"], snap["equity"], snap["pnl_pct"], snap["max_dd"],
                                      snap["n_trades"], snap["win_rate"]))
    if snap["positions"]:
        lines.append("Lệnh đang mở: " + "; ".join(
            "#%d %s %s @%s SL=%s TP=%s P/L %+.2f" % (p.id, p.side, _g(p.volume), _g(p.open_price),
                                                      _g(p.sl), _g(p.tp), p.profit) for p in snap["positions"][:6]))
    else:
        lines.append("Không có lệnh đang mở.")
    if snap["trades"]:
        lines.append("5 lệnh đóng gần nhất: " + "; ".join(
            "%s %+.2f (%s)" % (t.side, t.profit, t.reason) for t in snap["trades"][:5]))
    for name, pts in list(snap.get("plots", {}).items())[:6]:
        if pts:
            lines.append("Đường bot vẽ %s (mới nhất) = %s" % (name, _g(pts[-1][1])))
    return "\n".join(lines)


_JSON = re.compile(r"\{.*\}", re.S)


def parse_decision(text):
    m = _JSON.search(text or "")
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return None
    if not isinstance(d, dict):
        return None
    action = str(d.get("action", "")).strip().lower()
    if action not in ("buy", "sell", "hold", "close_all"):
        return None

    def num(key, lo, hi):
        try:
            v = float(d.get(key, 0) or 0)
        except (TypeError, ValueError):
            v = 0.0
        return max(lo, min(hi, v))
    return {"action": action, "confidence": num("confidence", 0.0, 1.0),
            "sl_pct": num("sl_pct", 0.0, 50.0), "tp_pct": num("tp_pct", 0.0, 100.0),
            "reason": str(d.get("reason", ""))[:300]}


def build_messages(system, transcript, me, group, instruction=None, limit=30):
    """Chuyển lịch sử chat thành messages OpenAI; gộp các tin liên tiếp cùng role."""
    msgs = [{"role": "system", "content": system}]

    def add(role, text):
        if msgs[-1]["role"] == role:
            msgs[-1]["content"] += "\n\n" + text
        else:
            msgs.append({"role": role, "content": text})
    for m in [x for x in transcript if x.get("kind") != "notice"][-limit:]:
        who, text = m["who"], m["text"]
        if who == me:
            add("assistant", text)
        elif who == "user":
            add("user", ("[Người dùng]: " + text) if group else text)
        else:
            add("user", "[%s]: %s" % (who, text))
    if instruction:
        add("user", instruction)
    if msgs[-1]["role"] != "user":
        add("user", "Hãy tiếp tục.")
    return msgs


def d_to_vote(d):
    v = {"agent": d["agent"], "model": d.get("model", "?"), "action": d["action"],
         "confidence": d["confidence"], "reason": d["reason"]}
    if d.get("prompt_hash"):
        v["prompt_hash"] = d["prompt_hash"]
    return v


def tally_votes(votes):
    """Gộp phiếu: hành động thắng phải có > 1/2 số phiếu hợp lệ (và >= 2 phiếu khi có >= 2 AI),
    nếu không -> hold. Độ tin cậy = trung bình các phiếu thắng; SL/TP = trung bình giá trị khác 0."""
    if not votes:
        return None
    n = len(votes)
    counts = {}
    for v in votes:
        counts[v["action"]] = counts.get(v["action"], 0) + 1
    best, cnt = max(counts.items(), key=lambda kv: (kv[1], kv[0] == "hold"))
    need = n // 2 + 1
    if cnt < need or (n >= 2 and cnt < 2):
        best, win = "hold", []
        reason = "Không đủ đồng thuận (%s) -> giữ nguyên" % ", ".join("%s=%d" % kv for kv in sorted(counts.items()))
        conf, sl, tp = 0.0, 0.0, 0.0
    else:
        win = [v for v in votes if v["action"] == best]
        conf = sum(v["confidence"] for v in win) / len(win)
        slv = [v["sl_pct"] for v in win if v["sl_pct"] > 0]
        tpv = [v["tp_pct"] for v in win if v["tp_pct"] > 0]
        sl = sum(slv) / len(slv) if slv else 0.0
        tp = sum(tpv) / len(tpv) if tpv else 0.0
        reason = "%d/%d AI đồng ý %s: %s" % (cnt, n, best, "; ".join(v["reason"] for v in win)[:220])
    return {"action": best, "confidence": conf, "sl_pct": sl, "tp_pct": tp, "reason": reason,
            "by": "Biểu quyết", "model": ", ".join(sorted({v["model"] for v in votes})), "mode": "đa số",
            "votes": [d_to_vote(v) for v in votes]}


# --------------------------------------------------------------------------
# Hub: điều phối chat nhiều AI + tín hiệu cho bot
# --------------------------------------------------------------------------
class AIHub:
    def __init__(self, store, get_snapshot, get_bot, get_settings):
        """
        get_snapshot() -> dict snapshot của runner (hoặc None)
        get_bot()      -> (tên, mã nguồn, params) hoặc None
        get_settings() -> dict cài đặt chung
        """
        self.store = store
        self.get_snapshot = get_snapshot
        self.get_bot = get_bot
        self.get_settings = get_settings
        self.lock = threading.RLock()
        self.agents = store.load_agents()
        self._learn_keys()
        self.chat = store.chat
        self.signal = None
        self._sig_id = 0
        sp = getattr(store, "signals_path", None)
        self.sigs = airec.SignalLog(sp) if sp else None            # nhật ký tín hiệu để PHÁT LẠI trong backtest (airec)
        self._phash = {}                                           # tên AI -> hash prompt của lượt gần nhất
        self.busy = False
        self.auto_on = False
        self._cancel = threading.Event()
        self.on_message = None
        self.on_status = None
        self.status_text = ""

    # ---------- agents ----------
    def reload_agents(self):
        self.agents = self.store.load_agents()
        self._learn_keys()

    def _learn_keys(self):
        redact.add_known([a.get(k) for a in self.agents if isinstance(a, dict) for k in ("api_key", "key", "token", "secret")])

    def set_agents(self, agents):
        with self.lock:
            self.agents = agents
        self.store.save_agents(agents)

    def enabled(self):
        return [a for a in self.agents if a.get("enabled", True)]

    def agent_by_name(self, name):
        for a in self.agents:
            if a.get("name") == name:
                return a
        return None

    # ---------- tín hiệu cho bot ----------
    def get_signal(self):
        with self.lock:
            s = self.signal
        if s is None:
            return None
        ttl = float(self.get_settings().get("ai_signal_ttl", 30)) * 60.0
        age = time.time() - s["time"]
        if age > ttl:
            return None
        out = dict(s)
        out["age"] = age
        return out

    # ---------- tin nhắn ----------
    def _status(self, text):
        self.status_text = text
        if self.on_status:
            try:
                self.on_status(text)
            except Exception:
                pass

    def add_message(self, who, text, kind="chat"):
        m = {"id": self.chat.new_id(), "who": who, "text": redact.redact(text), "ts": time.time(), "kind": kind}
        try:
            self.chat.append(m)
        except OSError:
            pass
        if self.on_message:
            try:
                self.on_message(m)
            except Exception:
                pass
        return m

    def clear_chat(self):
        self.chat.clear()

    # ---------- chạy 1 lượt của 1 agent ----------
    def _turn(self, agent, group, others, include_source, instruction=None):
        st = self.get_settings()
        bot = self.get_bot()
        name, src, params = bot if bot else (None, "", {})
        src = redact.redact(src)                      # file bot lỡ chứa khoá thì KHÔNG gửi cho nhà cung cấp AI
        system = build_system(agent, others, name, src, params, market_context(self.get_snapshot()),
                              include_source=include_source)
        hist = self.chat.tail(40)
        msgs = build_messages(system, hist, agent["name"], group, instruction)
        self._phash[agent["name"]] = airec.prompt_hash(msgs)         # đúng thứ đã gửi đi (đã che bí mật) - để đối chiếu/kiểm toán
        self._status("Đang chờ %s trả lời..." % agent["name"])
        try:
            return chat_completion(agent, msgs, st.get("ai_max_tokens", 800))
        except AIError as e:
            self.add_message("hệ thống", "%s lỗi: %s" % (agent["name"], e), "notice")
            return None

    def _run_bg(self, fn):
        with self.lock:
            if self.busy:
                return False
            self.busy = True
        self._cancel.clear()

        def work():
            try:
                fn()
            except Exception:
                self.add_message("hệ thống", "Lỗi: " + traceback.format_exc(limit=3), "notice")
            finally:
                with self.lock:
                    self.busy = False
                self._status("")
        threading.Thread(target=work, name="pyea-ai", daemon=True).start()
        return True

    # ---------- chế độ 1: chat 1 AI ----------
    def ask_single(self, agent_name, text):
        agent = self.agent_by_name(agent_name)
        if agent is None:
            self.add_message("hệ thống", "Chưa chọn AI nào. Hãy thêm AI ở 'Quản lý AI'.", "notice")
            return False

        def fn():
            self.add_message("user", text)
            reply = self._turn(agent, False, [], True)
            if reply:
                self.add_message(agent["name"], reply)
        return self._run_bg(fn)

    # ---------- chế độ 2: nhóm AI + người dùng ----------
    def ask_group(self, text, rounds=None):
        agents = self.enabled()
        if not agents:
            self.add_message("hệ thống", "Chưa có AI nào được bật. Hãy thêm ở 'Quản lý AI'.", "notice")
            return False
        rounds = int(rounds or self.get_settings().get("ai_rounds", 2))

        def fn():
            self.add_message("user", text)
            self._discuss(agents, rounds, include_source=True)
        return self._run_bg(fn)

    def _discuss(self, agents, rounds, include_source, auto_note=None):
        """Chạy các vòng thảo luận; trả về list {"agent","text"} (lời phát biểu)."""
        said = []
        names = [a["name"] for a in agents]
        for r in range(rounds):
            for a in agents:
                if self._cancel.is_set():
                    return said
                reply = self._turn(a, True, [n for n in names if n != a["name"]], include_source, auto_note)
                if reply:
                    self.add_message(a["name"], reply)
                    said.append({"agent": a["name"], "text": reply[:500]})
        return said

    # ---------- chế độ 3: tự thảo luận ----------
    def _auto_session(self):
        self.reload_agents()
        agents = self.enabled()
        if not agents:
            self.add_message("hệ thống", "Chưa có AI nào được bật.", "notice")
            return
        snap = self.get_snapshot()
        if not snap or not snap.get("ready"):
            self.add_message("hệ thống", "Chưa có dữ liệu thị trường: hãy chạy bot (tab Bot) rồi bật tự thảo luận.",
                             "notice")
            return
        st = self.get_settings()
        rounds = int(st.get("ai_rounds", 2))
        self.add_message("hệ thống", "— Phiên thảo luận mới —", "notice")
        said = self._discuss(agents, rounds, include_source=False,
                             auto_note="Không có người dùng trong phiên này. Hãy cùng nhau phân tích thị trường "
                                       "và bàn xem nên mua, bán, giữ hay đóng lệnh. Mỗi người nêu quan điểm ngắn gọn.")
        if self._cancel.is_set():
            return
        mode = st.get("ai_decision_mode", "decider")
        if mode == "majority" and len(agents) >= 2:
            d = self._decide_majority(agents)
        else:
            d = self._decide_single(agents)
        if d is None:
            return
        d["discussion"] = said[-8:]
        with self.lock:
            self._sig_id += 1
            d["id"] = self._sig_id
            d["time"] = time.time()
            self.signal = d
        if self.sigs is not None:                                  # ghi để backtest phát lại được (LLM không tái lập được nếu hỏi lại)
            self.sigs.append(airec.to_record(d, symbol=snap.get("symbol", ""), timeframe=snap.get("timeframe", ""), provider=d.get("provider", "")))
        lines = ["QUYẾT ĐỊNH: %s | tin cậy %.0f%% | SL %.2f%% | TP %.2f%% | cách chốt: %s" % (
            d["action"].upper(), d["confidence"] * 100, d["sl_pct"], d["tp_pct"], d["mode"]), d["reason"]]
        for v in d.get("votes", []):
            lines.append("  • %s (%s): %s %.0f%% - %s" % (v["agent"], v.get("model", "?"), v["action"],
                                                        v["confidence"] * 100, v["reason"]))
        self.add_message(d["by"], "\n".join(lines), "decision")

    def _vote(self, agent, others):
        reply = self._turn(agent, True, others, False, DECISION_PROMPT)
        if not reply:
            return None
        d = parse_decision(reply)
        if d is None:
            self.add_message("hệ thống", "%s không trả về JSON hợp lệ." % agent["name"], "notice")
            return None
        d["agent"] = agent["name"]
        d["model"] = resolve_agent(agent)[1]
        d["provider"] = agent.get("preset", "")
        d["prompt_hash"] = self._phash.get(agent["name"], "")
        return d

    def _decide_single(self, agents):
        decider = next((a for a in agents if a.get("decider")), agents[-1])
        d = self._vote(decider, [a["name"] for a in agents if a is not decider])
        if d is None:
            return None
        out = {k: d[k] for k in ("action", "confidence", "sl_pct", "tp_pct", "reason")}
        out.update({"by": decider["name"], "model": d["model"], "mode": "1 AI chốt", "votes": [d_to_vote(d)],
                    "provider": d.get("provider", ""), "prompt_hash": d.get("prompt_hash", "")})
        return out

    def _decide_majority(self, agents):
        votes = []
        for a in agents:
            if self._cancel.is_set():
                return None
            v = self._vote(a, [x["name"] for x in agents if x is not a])
            if v:
                votes.append(v)
        out = tally_votes(votes)
        if out is None:
            self.add_message("hệ thống", "Không có phiếu hợp lệ -> bỏ qua phiên này.", "notice")
        else:
            out["prompt_hash"] = airec.combine_hashes(v.get("prompt_hash") for v in votes)
            out["provider"] = ",".join(sorted({v.get("provider", "") for v in votes if v.get("provider")}))
        return out

    def start_auto(self):
        if self.auto_on:
            return False
        self.auto_on = True
        self._cancel.clear()

        def loop():
            fails_guard = 0
            while self.auto_on and not self._cancel.is_set():
                with self.lock:
                    already = self.busy
                    self.busy = True
                if already:
                    time.sleep(2)
                    continue
                try:
                    self._auto_session()
                except Exception:
                    fails_guard += 1
                    self.add_message("hệ thống", "Lỗi phiên tự thảo luận: " + traceback.format_exc(limit=3), "notice")
                    if fails_guard >= 5:
                        self.add_message("hệ thống", "Lỗi liên tiếp 5 lần -> tắt tự thảo luận.", "notice")
                        self.auto_on = False
                finally:
                    with self.lock:
                        self.busy = False
                    self._status("")
                wait = float(self.get_settings().get("ai_auto_interval", 15)) * 60.0
                end = time.time() + wait
                while self.auto_on and time.time() < end and not self._cancel.is_set():
                    time.sleep(1)
        threading.Thread(target=loop, name="pyea-ai-auto", daemon=True).start()
        return True

    def stop_auto(self):
        self.auto_on = False
        self._cancel.set()

    def cancel(self):
        self._cancel.set()

    def test_agent(self, agent):
        """Thử kết nối 1 agent (chạy đồng bộ, gọi trong thread riêng ở UI)."""
        try:
            out = chat_completion(agent, [{"role": "user", "content": "Trả lời đúng 1 từ: OK"}],
                                  max_tokens=20, timeout=40)
            return True, out[:80]
        except AIError as e:
            return False, str(e)
