"""
Bản quyền: DÙNG THỬ ĐẦY ĐỦ 90 NGÀY chỉ khi app được cài từ Google Play (người dùng = tester); khoá kích hoạt ký offline Ed25519.
Không Kivy, không mạng.

Quy tắc (đổi ở hằng số cuối phần cấu hình):
  * Cài ngoài Play (APK tải về / adb / GitHub Releases) -> trạng thái "sideload": KHÔNG giới hạn gì (bản cho tester ngoài Play).
  * Cài từ Play (installer == com.android.vending) -> "trial" 90 ngày kể từ lần mở đầu, đủ tính năng.
  * Hết hạn và chưa có khoá -> "expired": chặn MỞ PHIÊN LIVE MỚI. Paper, backtest, xem lịch sử, đóng lệnh đang có, bot đang chạy: vẫn dùng.
  * Có khoá hợp lệ (chữ ký đúng, đúng thiết bị hoặc khoá chung "*", chưa quá hạn) -> "licensed".
Giới hạn trung thực: không có máy chủ nên không chống được xoá dữ liệu app/cài lại để làm mới dùng thử; chống được sửa tay file và lùi đồng hồ.
Muốn chặn triệt để cần Play Integrity + máy chủ hoặc Google Play Billing (ngoài phạm vi bản này).
"""
import base64
import hashlib
import json
import os
import re
import time
import uuid

from . import ed25519

TRIAL_DAYS = 90
PLAY_INSTALLER = "com.android.vending"
KEY_PREFIX = "PYEA1"
# Khoá CÔNG KHAI để xác minh khoá kích hoạt. Khoá riêng nằm ở máy của chủ dự án (tools/license_keygen.py), KHÔNG nằm trong app.
PUBLIC_KEY = "QDLIh_Rn6Y-Qkh8lRuUWhn9F9MDX3ryLmlV3caJpZug"
DAY = 86400
ROLLBACK_SLACK = 300                                    # cho phép đồng hồ lệch nhẹ (giây) trước khi coi là lùi đồng hồ

STATES = ("sideload", "trial", "expired", "licensed")


def _b64u_dec(s):
    s = re.sub(r"\s+", "", s).replace("-", "+").replace("_", "/")
    return base64.b64decode(s + "=" * (-len(s) % 4), validate=True)


def _sum(d):
    body = "|".join("%s=%s" % (k, d.get(k)) for k in ("iid", "first", "seen", "key"))
    return hashlib.sha256(("pyea-lic|" + body).encode("utf-8")).hexdigest()[:20]


class Store:
    """license.json trong thư mục dữ liệu: id cài đặt, ngày mở đầu, mốc thời gian lớn nhất từng thấy, khoá đã nhập."""

    def __init__(self, base):
        self.path = os.path.join(base, "license.json")

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict) and d.get("sum") == _sum(d):
                return d
        except (OSError, ValueError):
            pass
        return None                                     # không có / hỏng / bị sửa tay -> coi như chưa có (xử lý ở evaluate)

    def save(self, d):
        d = dict(d)
        d["sum"] = _sum(d)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, self.path)


def make_key(seed, expires=0, iid="*", plan="full", note=""):
    """Tạo khoá kích hoạt (chạy ở máy chủ dự án). expires: epoch giây, 0 = vĩnh viễn. iid: id cài đặt hoặc "*" = dùng chung."""
    payload = json.dumps({"iid": iid, "exp": int(expires), "plan": plan, "note": note}, sort_keys=True, separators=(",", ":"))
    pb = payload.encode("utf-8")
    return "%s-%s.%s" % (KEY_PREFIX, ed25519.b64u(pb), ed25519.b64u(ed25519.sign(seed, pb)))


def parse_key(text, iid, now=None, public_key=None):
    """-> (payload dict, None) nếu hợp lệ, ngược lại (None, lý do tiếng Việt)."""
    now = time.time() if now is None else now
    t = re.sub(r"\s+", "", str(text or ""))
    if not t.startswith(KEY_PREFIX + "-") or t.count(".") != 1:
        return None, "Khoá sai định dạng (phải bắt đầu bằng %s-)." % KEY_PREFIX
    body, sig = t[len(KEY_PREFIX) + 1:].split(".")
    try:
        pb, sg = _b64u_dec(body), _b64u_dec(sig)
        pub = _b64u_dec(public_key or PUBLIC_KEY)
    except (ValueError, TypeError):
        return None, "Khoá không giải mã được."
    if not ed25519.verify(pub, pb, sg):
        return None, "Chữ ký khoá không hợp lệ."
    try:
        d = json.loads(pb.decode("utf-8"))
        exp = int(d.get("exp", 0))
    except (ValueError, TypeError, AttributeError):
        return None, "Nội dung khoá hỏng."
    if d.get("iid") not in ("*", iid):
        return None, "Khoá này cấp cho thiết bị khác (ID của bạn: %s)." % iid
    if exp and exp < now:
        return None, "Khoá đã hết hạn."
    d["exp"] = exp
    return d, None


def evaluate(store, installer, now=None, public_key=None):
    """Cập nhật file (mốc đầu, mốc thời gian lớn nhất) và trả về trạng thái.
    -> dict(state, days_left, trial_end, iid, installer, plan, key_exp, rolled_back)"""
    now = time.time() if now is None else float(now)
    d = store.load()
    fresh = d is None
    if fresh:
        d = {"iid": uuid.uuid4().hex[:12], "first": now, "seen": now, "key": ""}
        old = None
        try:                                            # file có nhưng bị sửa/hỏng: giữ id cũ nếu đọc được, mốc đầu = bây giờ KHÔNG đúng
            with open(store.path, "r", encoding="utf-8") as f:
                old = json.load(f)
        except (OSError, ValueError):
            pass
        if isinstance(old, dict):                       # bị sửa tay: phạt bằng cách coi trial đã dùng hết (chỉ ảnh hưởng bản Play)
            d["iid"] = str(old.get("iid") or d["iid"])[:12]
            d["first"] = now - TRIAL_DAYS * DAY - DAY
            d["tampered"] = True
    first, seen = float(d["first"]), float(d["seen"])
    rolled = now < seen - ROLLBACK_SLACK
    eff = max(now, seen)                                # lùi đồng hồ không kéo dài thêm thời gian dùng thử
    d["seen"] = eff
    d.pop("tampered", None)
    store.save(d)
    trial_end = first + TRIAL_DAYS * DAY
    out = {"iid": d["iid"], "installer": installer or "", "trial_end": trial_end, "rolled_back": rolled,
           "days_left": None, "plan": "", "key_exp": 0, "reason": ""}
    if d.get("key"):
        k, why = parse_key(d["key"], d["iid"], eff, public_key)
        if k:
            out.update(state="licensed", plan=k.get("plan", ""), key_exp=k["exp"])
            if k["exp"]:
                out["days_left"] = max(0, int((k["exp"] - eff) // DAY))
            return out
        out["reason"] = why
    if installer != PLAY_INSTALLER:
        out["state"] = "sideload"
        return out
    left = trial_end - eff
    out["days_left"] = max(0, int(left // DAY) + (1 if left % DAY else 0)) if left > 0 else 0
    out["state"] = "trial" if left > 0 else "expired"
    return out


def activate(store, text, installer, now=None, public_key=None):
    """Nhập khoá. -> (ok, thông báo)."""
    st = evaluate(store, installer, now, public_key)
    k, why = parse_key(text, st["iid"], now, public_key)
    if not k:
        return False, why
    d = store.load() or {}
    d["key"] = re.sub(r"\s+", "", text)
    store.save(d)
    return True, "Đã kích hoạt (%s)%s." % (k.get("plan") or "full", ", hết hạn " + time.strftime("%d/%m/%Y", time.localtime(k["exp"])) if k["exp"] else ", vĩnh viễn")


def blocks_live(status):
    """Chỉ chặn MỞ phiên LIVE mới khi hết dùng thử và chưa có khoá. Mọi thứ khác (paper, backtest, đóng lệnh) vẫn chạy."""
    return (status or {}).get("state") == "expired"


def describe(status):
    s = status or {}
    st = s.get("state")
    if st == "sideload":
        return "Bản cài ngoài Google Play: dùng đầy đủ, không giới hạn thời gian."
    if st == "trial":
        return "Dùng thử đầy đủ: còn %s ngày (tối đa %d ngày kể từ lần mở đầu)." % (s.get("days_left"), TRIAL_DAYS)
    if st == "licensed":
        if s.get("key_exp"):
            return "Đã kích hoạt (%s), còn %s ngày." % (s.get("plan") or "full", s.get("days_left"))
        return "Đã kích hoạt (%s), vĩnh viễn." % (s.get("plan") or "full")
    return ("Hết 90 ngày dùng thử. Vẫn dùng được paper, backtest, xem lịch sử và quản lý/đóng lệnh đang có; "
            "để mở phiên LIVE mới hãy nhập khoá kích hoạt.")
