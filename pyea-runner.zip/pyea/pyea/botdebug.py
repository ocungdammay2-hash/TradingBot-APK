"""Debugger đơn giản cho bot (khi BACKTEST): ghi từng dòng code bot đã chạy trong on_tick/on_bar/... và «điểm dừng» chụp giá trị biến cục bộ.
KHÔNG import Kivy. Không dừng tương tác (điện thoại không có trình gỡ lỗi) - thay vào đó ghi lại để đọc sau: giống `Print` + breakpoint-log.

  Tracer(bot_path, mode="lines"|"breakpoints", breakpoints={42: "", 57: "rsi < 30"}, callbacks=("on_bar",), max_events=3000, skip_calls=0, max_calls=5)
  tracer.run(name, fn, *args)   # engine gọi thay cho fn(*args) khi phiên có `debugger`
  tracer.report(max_lines=400)  # văn bản để hiện/gửi

Giới hạn an toàn: tối đa `max_events` sự kiện, chỉ theo dõi `max_calls` lần gọi callback (sau `skip_calls` lần đầu) rồi TẮT hẳn (không làm chậm backtest còn lại).
"""
import os
import sys
import types


def parse_breakpoints(text):
    """«42, 57:rsi < 30» -> {42: "", 57: "rsi < 30"}. Dòng sai bị bỏ; trả (dict, [cảnh báo])."""
    out, warn = {}, []
    for part in str(text or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        num, _, cond = part.partition(":")
        try:
            n = int(num.strip())
            if n < 1:
                raise ValueError
        except ValueError:
            warn.append("Bỏ qua «%s» (cần số dòng, vd 42 hoặc 57:rsi < 30)" % part)
            continue
        out[n] = cond.strip()
    return out, warn


def _short(v, n=70):
    try:
        r = repr(v)
    except Exception:                                       # noqa: BLE001 - repr của đối tượng lạ có thể ném lỗi
        r = "<không in được>"
    return r if len(r) <= n else r[:n - 1] + "…"


def snapshot(frame_locals, limit=14):
    out = {}
    for k, v in list(frame_locals.items())[:60]:
        if k.startswith("__") or isinstance(v, (types.ModuleType, types.FunctionType, type)):
            continue
        out[k] = _short(v)
        if len(out) >= limit:
            break
    return out


class Tracer:
    def __init__(self, bot_path, mode="lines", breakpoints=None, callbacks=("on_bar",), max_events=3000, skip_calls=0, max_calls=5):
        self.path = bot_path
        self.mode = mode if mode in ("lines", "breakpoints") else "lines"
        self.breakpoints = dict(breakpoints or {})
        self.callbacks = tuple(callbacks)
        self.max_events, self.skip_calls, self.max_calls = int(max_events), int(skip_calls), int(max_calls)
        self.events = []                                     # (callback, lần gọi, dòng, loại, dữ liệu)
        self.calls_seen = 0
        self.calls_traced = 0
        self.truncated = False
        self.done = False
        self._src = None
        self._cur = ("", 0)

    # ---- nguồn ----
    def source_line(self, n):
        if self._src is None:
            try:
                with open(self.path, encoding="utf-8", errors="replace") as f:
                    self._src = f.read().splitlines()
            except OSError:
                self._src = []
        return self._src[n - 1].strip() if 0 < n <= len(self._src) else ""

    # ---- chạy ----
    def run(self, name, fn, *args):
        if self.done or name not in self.callbacks:
            return fn(*args)
        self.calls_seen += 1
        if self.calls_seen <= self.skip_calls:
            return fn(*args)
        if self.calls_traced >= self.max_calls:
            self.done = True
            return fn(*args)
        self.calls_traced += 1
        self._cur = (name, self.calls_traced)
        prev = sys.gettrace()
        sys.settrace(self._global)
        try:
            return fn(*args)
        finally:
            sys.settrace(prev)

    def _add(self, line, kind, data):
        if len(self.events) >= self.max_events:
            self.truncated = True
            self.done = True
            sys.settrace(None)
            return
        self.events.append((self._cur[0], self._cur[1], line, kind, data))

    def _global(self, frame, event, arg):
        if event == "call" and frame.f_code.co_filename == self.path:
            return self._local
        return None

    def _local(self, frame, event, arg):
        if self.done:
            return None
        if event == "line":
            n = frame.f_lineno
            if self.mode == "lines":
                self._add(n, "line", None)
            if n in self.breakpoints:
                cond = self.breakpoints[n]
                hit = True
                if cond:
                    try:
                        hit = bool(eval(cond, frame.f_globals, frame.f_locals))     # noqa: S307 - điều kiện do chính người dùng nhập, code bot cũng do họ nạp
                    except Exception as e:                                          # noqa: BLE001
                        self._add(n, "condfail", "%s: %s" % (type(e).__name__, e))
                        hit = False
                if hit:
                    self._add(n, "break", snapshot(frame.f_locals))
        elif event == "exception":
            self._add(frame.f_lineno, "exc", "%s: %s" % (arg[0].__name__, _short(arg[1], 120)))
        return self._local

    # ---- báo cáo ----
    def report(self, max_lines=400):
        head = ["DEBUG BOT  (%s) - theo dõi %d/%d lần gọi %s%s" % (os.path.basename(self.path), self.calls_traced, self.calls_seen, "/".join(self.callbacks),
                                                                  "  · chế độ " + ("từng dòng" if self.mode == "lines" else "chỉ điểm dừng"))]
        if self.breakpoints:
            head.append("Điểm dừng: " + ", ".join("%d%s" % (k, (" nếu " + v) if v else "") for k, v in sorted(self.breakpoints.items())))
        if self.truncated:
            head.append("CHÚ Ý: đã dừng ghi ở %d sự kiện (giới hạn an toàn) - có thể thiếu phần sau." % self.max_events)
        if not self.events:
            head.append("Không có sự kiện nào (callback chưa được gọi, hoặc điểm dừng chưa bị chạm).")
        lines, last = [], None
        for cb, k, n, kind, data in self.events:
            if (cb, k) != last:
                lines.append("── %s #%d ──" % (cb, k))
                last = (cb, k)
            if kind == "line":
                lines.append("L%-4d %s" % (n, self.source_line(n)))
            elif kind == "break":
                vals = "  ".join("%s=%s" % kv for kv in data.items())
                lines.append("● L%-4d %s\n        %s" % (n, self.source_line(n), vals or "(không có biến)"))
            elif kind == "exc":
                lines.append("✖ L%-4d LỖI %s" % (n, data))
            else:
                lines.append("? L%-4d điều kiện lỗi: %s" % (n, data))
        if len(lines) > max_lines:
            lines = lines[:max_lines // 2] + ["… (%d dòng bị lược) …" % (len(lines) - max_lines)] + lines[-max_lines // 2:]
        return "\n".join(head + lines)
