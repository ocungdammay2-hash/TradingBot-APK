"""MQTT 5 tối giản chạy trên WebSocket (chỉ thư viện chuẩn, không paho) - đủ để NHẬN giá realtime từ DNSE (wss://datafeed-lts.dnse.com.vn/wss).
Chỉ hỗ trợ: CONNECT (user/pass), SUBSCRIBE (QoS 0-2), nhận PUBLISH (trả PUBACK/PUBREC/PUBCOMP), PINGREQ, DISCONNECT.
Không hỗ trợ gửi PUBLISH, will, retain xử lý đặc biệt, topic alias (DNSE không dùng)."""
import struct
import time

from .wsclient import WebSocketClient, WsClosed, WsError


class MqttError(Exception):
    pass


def enc_varint(n):
    out = bytearray()
    while True:
        b = n % 128
        n //= 128
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def dec_varint(buf, i=0):
    """-> (giá trị, vị trí sau) hoặc None nếu chưa đủ byte."""
    mul, val = 1, 0
    for k in range(4):
        if i + k >= len(buf):
            return None
        b = buf[i + k]
        val += (b & 0x7F) * mul
        if not b & 0x80:
            return val, i + k + 1
        mul *= 128
    raise MqttError("Độ dài MQTT không hợp lệ")


def _s(text):
    b = text.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def packet(first, body):
    return bytes([first]) + enc_varint(len(body)) + body


def build_connect(client_id, username, password, keepalive=60):
    flags = 0x02 | (0x80 if username else 0) | (0x40 if password else 0)
    body = _s("MQTT") + bytes([5, flags]) + struct.pack(">H", keepalive) + b"\x00" + _s(client_id)
    if username:
        body += _s(username)
    if password:
        body += _s(password)
    return packet(0x10, body)


def build_subscribe(pid, topics, qos=0):
    body = struct.pack(">H", pid) + b"\x00" + b"".join(_s(t) + bytes([qos]) for t in topics)
    return packet(0x82, body)


class MqttWs:
    def __init__(self, url, client_id, username, password, keepalive=60, timeout=10.0):
        self.url, self.cid, self.user, self.pw, self.keepalive, self.timeout = url, client_id, username, password, keepalive, timeout
        self.ws = None
        self.buf = bytearray()
        self.pid = 0
        self.last_tx = 0.0
        self.connected = False

    def _tx(self, data):
        self.ws.send_binary(data)
        self.last_tx = time.monotonic()

    def connect(self):
        self.ws = WebSocketClient(self.url, subprotocols=["mqtt"], timeout=self.timeout)
        self.ws.binary = True
        self.ws.connect()
        self._tx(build_connect(self.cid, self.user, self.pw, self.keepalive))
        end = time.monotonic() + self.timeout
        while time.monotonic() < end:
            for typ, flags, body in self._packets(0.5):
                if typ == 2:                                   # CONNACK
                    rc = body[1] if len(body) > 1 else 255
                    if rc != 0:
                        raise MqttError("MQTT từ chối kết nối (mã %d) - kiểm tra investorId/token" % rc)
                    self.connected = True
                    return
        raise MqttError("MQTT không phản hồi CONNACK")

    def subscribe(self, topics, qos=0):
        self.pid = (self.pid % 65535) + 1
        self._tx(build_subscribe(self.pid, list(topics), qos))

    def _packets(self, timeout):
        """Đọc từ WebSocket, trả list (type, flags, body) các gói đầy đủ."""
        msg = self.ws.recv(timeout=timeout)
        if msg:
            self.buf += msg
        out = []
        while True:
            if len(self.buf) < 2:
                break
            v = dec_varint(self.buf, 1)
            if v is None:
                break
            ln, pos = v
            if len(self.buf) < pos + ln:
                break
            out.append((self.buf[0] >> 4, self.buf[0] & 0x0F, bytes(self.buf[pos:pos + ln])))
            del self.buf[:pos + ln]
        return out

    def poll(self, timeout=1.0):
        """-> list (topic, payload bytes) nhận được; tự ping giữ kết nối; ném WsClosed/MqttError khi mất kết nối."""
        res = []
        for typ, flags, body in self._packets(timeout):
            if typ == 3:                                       # PUBLISH
                qos = (flags >> 1) & 3
                (tl,) = struct.unpack(">H", body[:2])
                topic = body[2:2 + tl].decode("utf-8", "replace")
                i = 2 + tl
                pid = 0
                if qos:
                    (pid,) = struct.unpack(">H", body[i:i + 2])
                    i += 2
                v = dec_varint(body, i)
                if v is None:
                    continue
                i = v[1] + v[0]                                # bỏ qua properties
                res.append((topic, body[i:]))
                if qos == 1:
                    self._tx(packet(0x40, struct.pack(">H", pid)))
                elif qos == 2:
                    self._tx(packet(0x50, struct.pack(">H", pid)))
            elif typ == 6:                                     # PUBREL -> PUBCOMP
                self._tx(packet(0x70, body[:2]))
            elif typ == 14:                                    # DISCONNECT
                raise MqttError("Broker ngắt kết nối")
        if time.monotonic() - self.last_tx > self.keepalive * 0.5:
            self._tx(b"\xc0\x00")                              # PINGREQ
        return res

    def close(self):
        try:
            if self.ws is not None:
                try:
                    self._tx(b"\xe0\x00")
                except (WsClosed, WsError):
                    pass
                self.ws.close()
        finally:
            self.connected = False
