"""
Mã hoá API key / secret / token khi LƯU TRÊN ĐĨA (settings.json, agents.json, ipc/cmd/*.json, ipc/desired.json).

Backend (tự chọn, có dự phòng - KHÔNG BAO GIỜ làm mất khoá của người dùng vì lỗi Keystore):
  AndroidKeystoreBackend : AES-256-GCM, khoá nằm trong Android Keystore (không trích xuất được ra file/backup;
                           dịch vụ nền cùng UID nên dùng chung khoá). Gọi qua pyjnius.
  FileKeyBackend         : máy tính/khi Keystore lỗi. HMAC-SHA256 chạy chế độ CTR + thẻ HMAC (encrypt-then-MAC),
                           khoá chủ 32 byte trong `<data>/.pyea_key` (chmod 600) - chỉ dùng thư viện chuẩn.

Định dạng giá trị đã mã hoá:  enc:v1:<backend>:<base64url>      (backend = 'ks' | 'file')
Giá trị KHÔNG có tiền tố 'enc:v1:' được coi là bản rõ (tương thích dữ liệu cũ) và sẽ được mã hoá ở lần lưu kế tiếp.

LƯU Ý BẢO MẬT (nói thẳng): mã hoá at-rest chống lộ qua backup/ADB/ứng dụng khác/đọc file. Nó KHÔNG ngăn một file bot
chạy chung tiến trình tự gọi lại API của app - muốn cách ly thật phải chạy bot ở tiến trình riêng (xem botproc.py)
và không đưa khoá cho tiến trình đó (đã làm: tiến trình bot chỉ nhận dữ liệu thị trường, không nhận settings).
"""
import base64
import hashlib
import hmac
import os
import threading

PREFIX = "enc:v1:"

# Tên khoá trong settings/config coi là bí mật (khớp với Input(secret=True) trong settings.py)
SECRET_SETTING_KEYS = (
    "api_key", "api_secret", "oanda_token",
    "exness_api_key", "exness_private_key",
    "metaapi_token", "mt5gw_token", "bridge_token",
    "ctrader_client_secret", "ctrader_access_token", "ctrader_refresh_token", "mt5ws_password", "mt5ws_otp", "mt5ea_token", "dnse_password", "dnse_otp", "dnse_trading_token",
    "ccxt_api_key", "ccxt_secret", "ccxt_password", "twelvedata_key",
)
_AGENT_SECRET_KEYS = ("api_key", "key", "token", "secret")


def _b64e(b):
    return base64.urlsafe_b64encode(b).decode("ascii")


def _b64d(s):
    s = str(s)
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


class SecretError(Exception):
    pass


# ---------------------------------------------------------------------------------------------
class FileKeyBackend:
    id = "file"

    def __init__(self, data_dir):
        self.path = os.path.join(data_dir, ".pyea_key")
        os.makedirs(data_dir, exist_ok=True)
        self._master = self._load_or_create()
        self._ek = hmac.new(self._master, b"pyea-enc-v1", hashlib.sha256).digest()
        self._mk = hmac.new(self._master, b"pyea-mac-v1", hashlib.sha256).digest()

    def _load_or_create(self):
        try:
            with open(self.path, "rb") as f:
                k = f.read()
            if len(k) == 32:
                return k
        except OSError:
            pass
        k = os.urandom(32)
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(k)
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
        return k

    def _stream(self, nonce, n):
        out, ctr = bytearray(), 0
        while len(out) < n:
            out += hmac.new(self._ek, nonce + ctr.to_bytes(8, "big"), hashlib.sha256).digest()
            ctr += 1
        return bytes(out[:n])

    def encrypt(self, data):
        nonce = os.urandom(16)
        ks = self._stream(nonce, len(data))
        ct = bytes(a ^ b for a, b in zip(data, ks))
        tag = hmac.new(self._mk, nonce + ct, hashlib.sha256).digest()
        return nonce + ct + tag

    def decrypt(self, blob):
        if len(blob) < 48:
            raise SecretError("dữ liệu mã hoá quá ngắn")
        nonce, ct, tag = blob[:16], blob[16:-32], blob[-32:]
        if not hmac.compare_digest(tag, hmac.new(self._mk, nonce + ct, hashlib.sha256).digest()):
            raise SecretError("sai khoá hoặc dữ liệu bị sửa")
        ks = self._stream(nonce, len(ct))
        return bytes(a ^ b for a, b in zip(ct, ks))


class AndroidKeystoreBackend:
    """AES/GCM/NoPadding với khoá trong AndroidKeyStore. Chỉ chạy trên Android thật (cần pyjnius)."""
    id = "ks"
    ALIAS = "pyea_runner_secrets_v1"

    def __init__(self):
        from jnius import autoclass                                   # ImportError ngoài Android -> tầng trên dự phòng
        self._J = autoclass
        KeyStore = autoclass("java.security.KeyStore")
        self._ks = KeyStore.getInstance("AndroidKeyStore")
        self._ks.load(None)
        if not self._ks.containsAlias(self.ALIAS):
            KeyProperties = autoclass("android.security.keystore.KeyProperties")
            Builder = autoclass("android.security.keystore.KeyGenParameterSpec$Builder")
            spec = (Builder(self.ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(["GCM"]).setEncryptionPaddings(["NoPadding"]).setKeySize(256).build())
            gen = autoclass("javax.crypto.KeyGenerator").getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            gen.init(spec)
            gen.generateKey()
        self._key = self._ks.getKey(self.ALIAS, None)
        self._Cipher = autoclass("javax.crypto.Cipher")
        self._Spec = autoclass("javax.crypto.spec.GCMParameterSpec")
        self.encrypt(b"selftest")                                     # lỗi sớm nếu Keystore hỏng

    @staticmethod
    def _to_java(b):
        return [x - 256 if x > 127 else x for x in b]

    @staticmethod
    def _from_java(arr):
        return bytes((x & 0xFF) for x in arr)

    def encrypt(self, data):
        c = self._Cipher.getInstance("AES/GCM/NoPadding")
        c.init(self._Cipher.ENCRYPT_MODE, self._key)
        iv = self._from_java(c.getIV())
        return iv + self._from_java(c.doFinal(self._to_java(data)))

    def decrypt(self, blob):
        iv, ct = blob[:12], blob[12:]
        c = self._Cipher.getInstance("AES/GCM/NoPadding")
        c.init(self._Cipher.DECRYPT_MODE, self._key, self._Spec(128, self._to_java(iv)))
        return self._from_java(c.doFinal(self._to_java(ct)))


# ---------------------------------------------------------------------------------------------
class SecretBox:
    def __init__(self, data_dir, backend=None, prefer_keystore=None):
        self.data_dir = data_dir
        self.backends = {}
        self.note = ""
        self._file = None
        if backend is not None:                                       # test/tiêm tay
            self.backends[backend.id] = backend
            self.default = backend
        else:
            ks = None
            probe = None
            if prefer_keystore is None:
                # Android Keystore qua pyjnius đã làm app SẬP NATIVE («Fatal Python error: Aborted» tại KeyGenParameterSpec.setBlockModes trên máy thật):
                # lỗi native KHÔNG bắt được bằng try/except. Nên MẶC ĐỊNH dùng khoá file (thư mục riêng của app); Keystore chỉ chạy khi người dùng
                # bật tay (tạo file `.ks_enable` trong thư mục dữ liệu) và có CHỐT CHẶN: mốc `.ks_probe` còn sót = lần thử trước chết native -> tự tắt.
                prefer_keystore = False
                if _on_android() and os.path.exists(os.path.join(data_dir, ".ks_enable")):
                    probe = os.path.join(data_dir, ".ks_probe")
                    if os.path.exists(probe):
                        self.note = "Android Keystore làm app chết lần trước - tự tắt, dùng khoá file"
                    else:
                        prefer_keystore = True
            if prefer_keystore:
                try:
                    if probe:
                        open(probe, "w").close()
                    ks = AndroidKeystoreBackend()
                    self.backends["ks"] = ks
                    if probe:
                        os.remove(probe)
                except Exception as e:                                # Keystore lỗi -> dùng file, KHÔNG làm app chết
                    self.note = "Android Keystore không dùng được (%s) - dùng khoá file" % e
                    if probe and os.path.exists(probe):
                        os.remove(probe)
            self.default = ks or self._file_backend()

    def _file_backend(self):
        if self._file is None:
            self._file = FileKeyBackend(self.data_dir)
            self.backends["file"] = self._file
        return self._file

    def seal(self, text):
        """Bản rõ -> 'enc:v1:...'. Rỗng/đã mã hoá -> giữ nguyên."""
        if not isinstance(text, str) or not text or text.startswith(PREFIX):
            return text
        blob = self.default.encrypt(text.encode("utf-8"))
        return "%s%s:%s" % (PREFIX, self.default.id, _b64e(blob))

    def open(self, text):
        """'enc:v1:...' -> bản rõ. Không có tiền tố -> trả nguyên (bản rõ cũ). Giải mã lỗi -> '' (và ghi nhận)."""
        if not isinstance(text, str) or not text.startswith(PREFIX):
            return text
        try:
            _, _, bid, payload = text.split(":", 3)
            be = self.backends.get(bid) or (self._file_backend() if bid == "file" else None)
            if be is None:
                raise SecretError("backend '%s' không khả dụng trên máy này" % bid)
            return be.decrypt(_b64d(payload)).decode("utf-8")
        except Exception as e:
            self.failed = getattr(self, "failed", [])
            self.failed.append(str(e))
            return ""

    @staticmethod
    def is_sealed(text):
        return isinstance(text, str) and text.startswith(PREFIX)

    # ---- tiện ích theo cấu trúc ----
    def _map(self, d, keys, fn):
        if not isinstance(d, dict):
            return d
        return {k: (fn(v) if (k in keys and isinstance(v, str)) else v) for k, v in d.items()}

    def seal_settings(self, d):
        return self._map(d, SECRET_SETTING_KEYS, self.seal)

    def open_settings(self, d):
        return self._map(d, SECRET_SETTING_KEYS, self.open)

    def has_plain_secret(self, d):
        return isinstance(d, dict) and any(isinstance(d.get(k), str) and d.get(k) and not d[k].startswith(PREFIX)
                                           for k in SECRET_SETTING_KEYS)

    def seal_config(self, cfg):
        """config của session_start/desired (có khoá 'settings')."""
        if isinstance(cfg, dict) and isinstance(cfg.get("settings"), dict):
            cfg = dict(cfg, settings=self.seal_settings(cfg["settings"]))
        return cfg

    def open_config(self, cfg):
        if isinstance(cfg, dict) and isinstance(cfg.get("settings"), dict):
            cfg = dict(cfg, settings=self.open_settings(cfg["settings"]))
        return cfg

    def seal_agents(self, agents):
        return [self._map(a, _AGENT_SECRET_KEYS, self.seal) for a in agents] if isinstance(agents, list) else agents

    def open_agents(self, agents):
        return [self._map(a, _AGENT_SECRET_KEYS, self.open) for a in agents] if isinstance(agents, list) else agents


def _on_android():
    return "ANDROID_ARGUMENT" in os.environ or "ANDROID_ROOT" in os.environ and "ANDROID_DATA" in os.environ


_BOXES = {}
_LOCK = threading.Lock()


def box_for(data_dir):
    """Một SecretBox cho mỗi thư mục dữ liệu (UI và dịch vụ nền mở cùng thư mục => cùng khoá)."""
    key = os.path.abspath(data_dir)
    with _LOCK:
        b = _BOXES.get(key)
        if b is None:
            b = _BOXES[key] = SecretBox(key)
        return b
