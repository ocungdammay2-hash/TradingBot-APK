"""
Luật giao dịch bằng BIỂU THỨC (kiểu Pine Script rút gọn) - viết chiến lược KHÔNG cần viết code Python.
Ví dụ:  cross_above(sma(close, 10), sma(close, 30)) and rsi(close, 14) < 70
Chỉ dùng thư viện chuẩn. Biểu thức được kiểm bằng `ast` với DANH SÁCH TRẮNG (không gọi hàm tuỳ ý, không thuộc tính, không import) nên an toàn
để người dùng/AI/TradingView gửi vào. Giá trị chưa đủ dữ liệu = None -> điều kiện coi là SAI (không vào lệnh).

Chuỗi giá: open high low close volume hl2 hlc3 ohlc4 · price = close
Hàm:  sma ema rsi stdev highest lowest (nguồn, chu kỳ) · atr(chu kỳ) · bb_upper/bb_lower/bb_mid(nguồn, chu kỳ, hệ số) · macd/macd_signal(nguồn, nhanh, chậm, tín hiệu)
      prev(biểu thức, n=1) (giá trị ở n nến trước) · cross_above(a, b) · cross_below(a, b) · abs min max
Toán tử: + - * /  so sánh  and or not  số, true/false.
"""
import ast

from . import indicators as ta

SERIES = ("open", "high", "low", "close", "volume", "hl2", "hlc3", "ohlc4", "price")
MAX_LEN = 400                                  # độ dài tối đa của biểu thức
MAX_NODES = 120


class RuleError(ValueError):
    pass


def _series(candles, name):
    if name in ("close", "price"):
        return [c.close for c in candles]
    if name == "hl2":
        return [(c.high + c.low) / 2.0 for c in candles]
    if name == "hlc3":
        return [(c.high + c.low + c.close) / 3.0 for c in candles]
    if name == "ohlc4":
        return [(c.open + c.high + c.low + c.close) / 4.0 for c in candles]
    return [getattr(c, name) for c in candles]


def _as_int(v, what):
    if not isinstance(v, (int, float)) or isinstance(v, bool) or v != int(v) or v <= 0:
        raise RuleError("%s phải là số nguyên dương" % what)
    return int(v)


class Rule:
    """Biểu thức đã kiểm tra. `evaluate(candles)` -> giá trị (số/bool/None)."""

    def __init__(self, text):
        self.text = (text or "").strip()
        if not self.text:
            raise RuleError("biểu thức rỗng")
        if len(self.text) > MAX_LEN:
            raise RuleError("biểu thức quá dài (> %d ký tự)" % MAX_LEN)
        try:
            self.tree = ast.parse(self.text.replace("true", "True").replace("false", "False"), mode="eval").body
        except SyntaxError as e:
            raise RuleError("sai cú pháp: %s" % (e.msg,))
        self._check(self.tree)

    # ---- kiểm tra tĩnh ----
    def _check(self, root):
        n = 0
        for node in ast.walk(root):
            n += 1
            if n > MAX_NODES:
                raise RuleError("biểu thức quá phức tạp")
            if isinstance(node, (ast.BoolOp, ast.UnaryOp, ast.BinOp, ast.Compare, ast.Load, ast.And, ast.Or, ast.Not, ast.USub, ast.UAdd,
                                 ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.Eq, ast.NotEq)):
                continue
            if isinstance(node, ast.Constant):
                if not isinstance(node.value, (int, float, bool)):
                    raise RuleError("chỉ cho phép số và true/false")
                continue
            if isinstance(node, ast.Name):
                if node.id not in SERIES and node.id not in _FUNCS and node.id not in ("True", "False"):
                    raise RuleError("tên không hợp lệ: %s" % node.id)
                continue
            if isinstance(node, ast.Call):
                if not isinstance(node.func, ast.Name) or node.func.id not in _FUNCS or node.keywords:
                    raise RuleError("chỉ gọi được hàm: %s" % ", ".join(sorted(_FUNCS)))
                continue
            raise RuleError("thành phần không được phép: %s" % type(node).__name__)

    # ---- đánh giá ----
    def evaluate(self, candles):
        try:
            return self._ev(self.tree, list(candles), 0)
        except ZeroDivisionError:
            return None

    def truth(self, candles):
        v = self.evaluate(candles)
        return bool(v) if v is not None else False

    def _ev(self, n, c, shift):
        end = len(c) - shift
        if end <= 0:
            return None
        if isinstance(n, ast.Constant):
            return n.value
        if isinstance(n, ast.Name):
            if n.id in SERIES:
                s = _series(c[:end], n.id)
                return s[-1] if s else None
            raise RuleError("hàm %s cần ngoặc ()" % n.id)
        if isinstance(n, ast.UnaryOp):
            v = self._ev(n.operand, c, shift)
            if isinstance(n.op, ast.Not):
                return None if v is None else (not v)
            if v is None:
                return None
            return -v if isinstance(n.op, ast.USub) else +v
        if isinstance(n, ast.BoolOp):
            vals = [self._ev(x, c, shift) for x in n.values]
            if isinstance(n.op, ast.And):
                return all(v is not None and bool(v) for v in vals)
            return any(v is not None and bool(v) for v in vals)
        if isinstance(n, ast.BinOp):
            a, b = self._ev(n.left, c, shift), self._ev(n.right, c, shift)
            if a is None or b is None:
                return None
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            return a / b
        if isinstance(n, ast.Compare):
            left = self._ev(n.left, c, shift)
            for op, comp in zip(n.ops, n.comparators):
                right = self._ev(comp, c, shift)
                if left is None or right is None:
                    return None
                ok = {ast.Lt: left < right, ast.LtE: left <= right, ast.Gt: left > right, ast.GtE: left >= right,
                      ast.Eq: left == right, ast.NotEq: left != right}[type(op)]
                if not ok:
                    return False
                left = right
            return True
        if isinstance(n, ast.Call):
            return _FUNCS[n.func.id](self, n.args, c, shift)
        raise RuleError("không đánh giá được")


# ---- hàm ----
def _src(rule, node, c, shift):
    if not isinstance(node, ast.Name) or node.id not in SERIES:
        raise RuleError("tham số đầu phải là chuỗi giá: %s" % ", ".join(SERIES))
    end = len(c) - shift
    return _series(c[:max(0, end)], node.id)


def _num(rule, node, c, shift, what):
    v = rule._ev(node, c, shift)
    return _as_int(v, what) if v is not None else None


def _f_ma(fn):
    def f(rule, args, c, shift):
        if len(args) != 2:
            raise RuleError("cần (nguồn, chu kỳ)")
        p = _num(rule, args[1], c, 0, "chu kỳ")
        return fn(_src(rule, args[0], c, shift), p)
    return f


def _f_atr(rule, args, c, shift):
    if len(args) != 1:
        raise RuleError("atr cần (chu kỳ)")
    return ta.atr(c[:len(c) - shift], _num(rule, args[0], c, 0, "chu kỳ"))


def _f_bb(idx):
    def f(rule, args, c, shift):
        if len(args) not in (2, 3):
            raise RuleError("cần (nguồn, chu kỳ[, hệ số])")
        p = _num(rule, args[1], c, 0, "chu kỳ")
        mult = float(rule._ev(args[2], c, 0)) if len(args) == 3 else 2.0
        b = ta.bollinger(_src(rule, args[0], c, shift), p, mult)
        return None if b is None else b[idx]
    return f


def _f_macd(which):
    def f(rule, args, c, shift):
        if len(args) != 4:
            raise RuleError("cần (nguồn, nhanh, chậm, tín hiệu)")
        fa, sl, sg = (_num(rule, a, c, 0, "chu kỳ") for a in args[1:])
        r = ta.macd(_src(rule, args[0], c, shift), fa, sl, sg)
        if r is None:
            return None
        return r[0] if which == "line" else r[1]
    return f


def _f_prev(rule, args, c, shift):
    if len(args) not in (1, 2):
        raise RuleError("prev cần (biểu thức[, n])")
    n = _num(rule, args[1], c, 0, "n") if len(args) == 2 else 1
    return rule._ev(args[0], c, shift + n)


def _f_cross(up):
    def f(rule, args, c, shift):
        if len(args) != 2:
            raise RuleError("cần (a, b)")
        a1, b1 = rule._ev(args[0], c, shift), rule._ev(args[1], c, shift)
        a0, b0 = rule._ev(args[0], c, shift + 1), rule._ev(args[1], c, shift + 1)
        if None in (a0, b0, a1, b1):
            return False
        return (a0 <= b0 and a1 > b1) if up else (a0 >= b0 and a1 < b1)
    return f


def _f_math(fn):
    def f(rule, args, c, shift):
        vals = [rule._ev(a, c, shift) for a in args]
        if not vals or any(v is None for v in vals):
            return None
        return fn(*vals)
    return f


_FUNCS = {
    "sma": _f_ma(ta.sma), "ema": _f_ma(ta.ema), "rsi": _f_ma(ta.rsi), "stdev": _f_ma(ta.stdev),
    "highest": _f_ma(ta.highest), "lowest": _f_ma(ta.lowest), "atr": _f_atr,
    "bb_mid": _f_bb(0), "bb_upper": _f_bb(1), "bb_lower": _f_bb(2),
    "macd": _f_macd("line"), "macd_signal": _f_macd("signal"),
    "prev": _f_prev, "cross_above": _f_cross(True), "cross_below": _f_cross(False),
    "abs": _f_math(abs), "min": _f_math(min), "max": _f_math(max),
}


def compile_rule(text):
    """Biên dịch + kiểm tra. Ném RuleError nếu sai."""
    return Rule(text)


def check(text):
    """Trả (True, '') hoặc (False, lý do) - dùng cho ô nhập trên giao diện."""
    try:
        Rule(text)
        return True, ""
    except RuleError as e:
        return False, str(e)
