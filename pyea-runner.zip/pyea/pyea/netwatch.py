"""Theo dõi mạng của THIẾT BỊ (không phụ thuộc sàn): thử mở kết nối TCP tới vài máy chủ công cộng.
Dùng để cảnh báo «mất mạng» cả khi đang chọn sàn giả lập (giả lập không cần mạng nên engine không tự phát hiện)."""
import socket
import threading
import time

PROBES = (("1.1.1.1", 443), ("8.8.8.8", 53), ("9.9.9.9", 443))


def probe(timeout=2.5, targets=PROBES, connect=None):
    """True nếu mở được ít nhất một kết nối."""
    connect = connect or socket.create_connection
    for host, port in targets:
        try:
            s = connect((host, port), timeout)
            try:
                s.close()
            except Exception:                                   # noqa: BLE001
                pass
            return True
        except OSError:
            continue
    return False


class NetWatch:
    """check() gọi từ vòng UI: tự chạy thăm dò ở luồng nền (không chặn UI). Mất mạng khi `fails` lần liên tiếp thất bại (tránh báo nhầm do rớt gói)."""

    def __init__(self, fn=probe, interval=8.0, fails=2, clock=time.time):
        self.fn, self.interval, self.fails, self.clock = fn, interval, fails, clock
        self.online = True
        self.since = clock()                 # thời điểm đổi trạng thái gần nhất
        self._bad = 0
        self._next = 0.0
        self._busy = False
        self._last = None
        self._lock = threading.Lock()

    def _run(self):
        try:
            ok = bool(self.fn())
        except Exception:                                       # noqa: BLE001
            ok = False
        with self._lock:
            self._last = ok
            self._busy = False

    def check(self, wait=False):
        """Trả về (online, đổi_trạng_thái). Gọi nhiều lần cũng được."""
        now = self.clock()
        if not self._busy and now >= self._next:
            self._busy, self._next = True, now + self.interval
            if wait:
                self._run()
            else:
                threading.Thread(target=self._run, daemon=True).start()
        changed = False
        with self._lock:
            ok, self._last = self._last, None
        if ok is not None:
            self._bad = 0 if ok else self._bad + 1
            new = ok or self._bad < self.fails
            if new != self.online:
                self.online, self.since, changed = new, now, True
        return self.online, changed
