"""Báo cáo giao dịch dạng HTML kiểu MT5 (một file tự chứa, không JavaScript, mở bằng trình duyệt/in ra PDF được). KHÔNG import Kivy.

Đầu vào: list Trade đã đóng (sổ app hoặc kết quả backtest) + vốn ban đầu. Đường vốn dựng từ các lệnh ĐÃ ĐÓNG (số dư sau mỗi lệnh) nên sụt vốn ở đây
là sụt vốn theo số dư, KHÔNG gồm lãi/lỗ đang treo; báo cáo ghi rõ điều này.
Gồm: bảng chỉ số (profit factor, Sharpe xấp xỉ, kỳ vọng, chuỗi thắng/thua, recovery), biểu đồ tăng trưởng, biểu đồ sụt vốn, phân tích theo mã/bot/chiều/phiên/giờ/thứ.
"""
import html
import time

from .backtest import compute_report

SESSIONS = (("Á (00-07 UTC)", 0, 7), ("Âu (07-13 UTC)", 7, 13), ("Âu-Mỹ chồng (13-16 UTC)", 13, 16), ("Mỹ (16-22 UTC)", 16, 22), ("Ngoài giờ (22-24 UTC)", 22, 24))
DAYS = ("Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "CN")


def session_of(t):
    h = time.gmtime(t).tm_hour
    for name, a, b in SESSIONS:
        if a <= h < b:
            return name
    return SESSIONS[-1][0]


def equity_curve(trades, start_balance):
    """[(thời gian đóng, số dư, số dư)] sau từng lệnh, có điểm đầu."""
    ts = sorted(trades, key=lambda t: (t.close_time, t.id))
    bal = float(start_balance)
    first = ts[0].open_time if ts and ts[0].open_time else (ts[0].close_time if ts else 0.0)
    out = [(first, bal, bal)]
    for t in ts:
        bal += t.profit
        out.append((t.close_time, bal, bal))
    return out


def drawdown_series(curve):
    """[(thời gian, % sụt so với đỉnh trước đó)] (>= 0)."""
    peak, out = None, []
    for t, _b, eq in curve:
        peak = eq if peak is None else max(peak, eq)
        out.append((t, ((peak - eq) / peak * 100.0) if peak and peak > 0 else 0.0))
    return out


def breakdown(trades, keyfn, order=None):
    g = {}
    for t in trades:
        g.setdefault(keyfn(t), []).append(t)
    keys = order if order else sorted(g, key=lambda k: -sum(x.profit for x in g[k]))
    rows = []
    for k in keys:
        ts = g.get(k)
        if not ts:
            continue
        gp = sum(x.profit for x in ts if x.profit > 0)
        gl = -sum(x.profit for x in ts if x.profit < 0)
        rows.append({"key": k, "n": len(ts), "net": sum(x.profit for x in ts), "win": 100.0 * sum(1 for x in ts if x.profit > 0) / len(ts),
                     "pf": (gp / gl) if gl > 0 else (float("inf") if gp > 0 else None)})
    return rows


def analysis(trades):
    return {
        "Theo mã": breakdown(trades, lambda t: t.symbol or "?"),
        "Theo bot": breakdown(trades, lambda t: t.owner or "thủ công"),
        "Theo chiều": breakdown(trades, lambda t: {"buy": "MUA", "sell": "BÁN"}.get(t.side, t.side)),
        "Theo phiên giao dịch (giờ mở, UTC)": breakdown(trades, lambda t: session_of(t.open_time), [s[0] for s in SESSIONS]),
        "Theo giờ mở (UTC)": breakdown(trades, lambda t: "%02dh" % time.gmtime(t.open_time).tm_hour, ["%02dh" % h for h in range(24)]),
        "Theo thứ mở (UTC)": breakdown(trades, lambda t: DAYS[time.gmtime(t.open_time).tm_wday], list(DAYS)),
        "Theo lý do thoát": breakdown(trades, lambda t: t.reason or "?"),
        "Theo tháng đóng lệnh (UTC)": breakdown(trades, lambda t: time.strftime("%Y-%m", time.gmtime(t.close_time or 0))),
    }


def _fmt(v, d=2):
    if v is None:
        return "-"
    if v == float("inf"):
        return "∞"
    if isinstance(v, int):
        return str(v)
    return "%.*f" % (d, v)


def _svg_line(points, w, h, area_zero=None, cls="line"):
    """points: [(x, y)] giá trị thật; trả chuỗi SVG path đã co giãn vào khung w×h."""
    if len(points) < 2:
        return ""
    xs, ys = [p[0] for p in points], [p[1] for p in points]
    x0, x1 = min(xs), max(xs)
    lo, hi = min(ys), max(ys)
    if area_zero is not None:
        lo, hi = min(lo, area_zero), max(hi, area_zero)
    if hi - lo < 1e-12:
        hi, lo = hi + 1.0, lo - 1.0
    dx = (x1 - x0) or 1.0

    def sx(x):
        return 6 + (x - x0) / dx * (w - 12)

    def sy(y):
        return h - 6 - (y - lo) / (hi - lo) * (h - 12)
    d = " ".join("%s%.1f,%.1f" % ("M" if i == 0 else "L", sx(x), sy(y)) for i, (x, y) in enumerate(points))
    out = ""
    if area_zero is not None:
        z = sy(area_zero)
        out += '<path class="area" d="%s L%.1f,%.1f L%.1f,%.1f Z"/>' % (d, sx(points[-1][0]), z, sx(points[0][0]), z)
    out += '<path class="%s" d="%s"/>' % (cls, d)
    out += '<text x="8" y="14" class="ax">%s</text><text x="8" y="%d" class="ax">%s</text>' % (_fmt(hi), h - 8, _fmt(lo))
    return out


def _table(rows, head):
    th = "".join("<th>%s</th>" % html.escape(h) for h in head)
    body = ""
    for r in rows:
        cls = ""
        if len(r) > 2 and isinstance(r[2], (int, float)):
            cls = ' class="up"' if r[2] > 0 else ' class="down"' if r[2] < 0 else ""
        body += "<tr%s>%s</tr>" % (cls, "".join("<td>%s</td>" % html.escape(str(c)) for c in r))
    return "<table><tr>%s</tr>%s</table>" % (th, body)


CSS = """
:root{--bg:#fff;--fg:#1c2230;--mut:#667085;--card:#f4f6fa;--up:#0e8a55;--down:#c93b3b;--line:#2f6fed;--bd:#d9dee8}
@media (prefers-color-scheme:dark){:root{--bg:#0d1017;--fg:#e6e9f0;--mut:#98a2b3;--card:#171b25;--up:#38c98a;--down:#f06a6a;--line:#6ea2ff;--bd:#2a3142}}
body{background:var(--bg);color:var(--fg);font:14px/1.5 system-ui,Segoe UI,Roboto,sans-serif;margin:0;padding:16px;max-width:960px;margin-inline:auto}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 8px}.mut{color:var(--mut);font-size:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:8px}.box{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:8px 10px}
.box b{display:block;font-size:17px}table{border-collapse:collapse;width:100%;margin:6px 0}th,td{padding:4px 8px;border-bottom:1px solid var(--bd);text-align:right;font-size:13px}
th:first-child,td:first-child{text-align:left}tr.up td:nth-child(3){color:var(--up)}tr.down td:nth-child(3){color:var(--down)}
svg{width:100%;height:auto;background:var(--card);border:1px solid var(--bd);border-radius:8px}.line{fill:none;stroke:var(--line);stroke-width:2}
.area{fill:var(--down);opacity:.25;stroke:none}.ax{fill:var(--mut);font-size:11px}.warn{border-left:3px solid #d99a00;padding:4px 10px;margin:8px 0;background:var(--card)}
"""


def build_html(trades, start_balance, title="Báo cáo giao dịch PyEA", notes=None, now=None):
    """-> chuỗi HTML hoàn chỉnh. `trades` rỗng vẫn trả về trang hợp lệ có ghi chú «chưa có lệnh»."""
    trades = sorted(list(trades or []), key=lambda t: (t.close_time, t.id))
    now = time.time() if now is None else now
    curve = equity_curve(trades, start_balance)
    rep = compute_report(trades, float(start_balance), curve, 0)
    e = html.escape
    parts = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
             "<title>%s</title><style>%s</style></head><body>" % (e(title), CSS),
             "<h1>%s</h1><div class='mut'>Tạo lúc %s UTC · %d lệnh đã đóng · vốn ban đầu %s</div>" % (
                 e(title), time.strftime("%Y-%m-%d %H:%M", time.gmtime(now)), len(trades), _fmt(float(start_balance)))]
    for n in notes or []:
        parts.append("<div class='warn'>%s</div>" % e(str(n)))
    parts.append("<div class='warn'>Đường vốn và sụt vốn tính theo SỐ DƯ sau từng lệnh đã đóng (không gồm lãi/lỗ đang treo). Sharpe chỉ là xấp xỉ theo lệnh, "
                 "không quy ra năm. Giờ/phiên/thứ theo UTC.</div>")
    if not trades:
        parts.append("<p>Chưa có lệnh đã đóng nào.</p></body></html>")
        return "".join(parts)
    keys = ("Lợi nhuận ròng", "Số dư cuối", "Profit factor", "Sụt vốn tối đa (%)", "Sụt vốn tối đa (tuyệt đối)", "Recovery factor", "Sharpe (xấp xỉ)",
            "Kỳ vọng / lệnh", "Tổng số lệnh", "Thắng (%)", "Lãi trung bình", "Lỗ trung bình", "Lãi lớn nhất", "Lỗ lớn nhất",
            "Chuỗi thắng dài nhất (lệnh)", "Chuỗi thua dài nhất (lệnh)")
    parts.append("<h2>Chỉ số</h2><div class='grid'>%s</div>" % "".join(
        "<div class='box'><span class='mut'>%s</span><b>%s</b></div>" % (e(k), _fmt(rep.get(k))) for k in keys))
    from . import mcarlo
    ex = mcarlo.extra_stats(trades, float(start_balance))
    parts.append("<h2>Chỉ số nâng cao</h2><div class='grid'>%s</div>" % "".join(
        "<div class='box'><span class='mut'>%s</span><b>%s</b></div>" % (e(k), e(_fmt(ex[k]) if not isinstance(ex[k], str) else ex[k]))
        for k in ("Sortino (theo lệnh)", "Calmar", "Kỳ vọng (R)", "1R (nguồn)")))
    parts.append("<div class='warn'>%s</div>" % e(mcarlo.monte_carlo_text(mcarlo.monte_carlo(trades, float(start_balance), 500, "shuffle", seed=1))))
    parts.append("<h2>Tăng trưởng số dư</h2><svg viewBox='0 0 640 200'>%s</svg>" % _svg_line([(c[0], c[1]) for c in curve], 640, 200))
    dd = drawdown_series(curve)
    parts.append("<h2>Sụt vốn (%% so với đỉnh)</h2><svg viewBox='0 0 640 140'>%s</svg>" % _svg_line([(t, -v) for t, v in dd], 640, 140, area_zero=0.0))
    for name, rows in analysis(trades).items():
        parts.append("<h2>%s</h2>%s" % (e(name), _table([[r["key"], r["n"], round(r["net"], 2), "%.1f%%" % r["win"], _fmt(r["pf"])] for r in rows],
                                                        [name.split(" (")[0].replace("Theo ", "").capitalize(), "Lệnh", "Lãi/lỗ", "Thắng", "PF"])))
    parts.append("<h2>Danh sách lệnh (200 lệnh gần nhất)</h2>")
    parts.append(_table([[t.id, t.symbol, {"buy": "MUA", "sell": "BÁN"}.get(t.side, t.side), "%.8g" % t.volume, "%.8g" % t.open_price, "%.8g" % t.close_price,
                          time.strftime("%Y-%m-%d %H:%M", time.gmtime(t.close_time)), round(t.profit, 2), t.reason] for t in trades[-200:]],
                        ["#", "Mã", "Chiều", "KL", "Vào", "Ra", "Giờ ra", "Lãi/lỗ", "Lý do"]))
    parts.append("</body></html>")
    return "".join(parts)
