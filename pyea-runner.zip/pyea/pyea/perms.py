"""
Quyền của bot kiểu «capability» (như AndroidManifest), không phải «cấm cứng»:

  # @permission: network(api.my-model.com, *.example.org)     bot xin kết nối tới các host này
  # @permission: file(read:data/*.csv)                         (khai báo để người dùng thấy; chưa cưỡng chế)
  # @permission: ai_signal                                      (khai báo; chưa cưỡng chế)
  # @permission: ai_ask                                         (khai báo bot gọi AI qua api.ask_ai; chưa cưỡng chế)

Mặc định bot chỉ có `self.api` + thư mục riêng + stdlib. Người dùng được hỏi «Cho phép / Từ chối» (lưu ở bot_perms.json theo TÊN FILE bot);
cấp quyền gắn với CHÍNH danh sách host đã khai báo - bot đổi/thêm host thì phần mới phải được cho phép lại. Từ chối: bot vẫn chạy, chỉ bị
PermissionError khi gọi mạng.

CƯỠNG CHẾ (nói thẳng): chỉ có tác dụng khi bot chạy ở TIẾN TRÌNH RIÊNG (Cài đặt → «Bot chạy ở» = process), nơi tiến trình con cài «rào»
lên socket/DNS trước khi nạp mã bot. Ở chế độ luồng (mặc định, và Android) bot chạy chung tiến trình với app nên KHÔNG chặn được - khai báo chỉ
để hiển thị. Rào này chặn lỗi vô ý và bot «tự tiện», KHÔNG phải ranh giới an ninh trước mã cố tình phá (mã độc có thể tìm cách vượt;
loader đã chặn `_socket`, `ctypes`, `subprocess`, `eval/exec`... nhưng đó vẫn là kiểm tra tĩnh). Muốn cách ly thật cần cô lập ở mức hệ điều hành.
"""
import ipaddress
import json
import os
import re
import threading
import time

PERM_FILE = "bot_perms.json"
_DECL = re.compile(r"^\s*#\s*@permission\s*:\s*(\w+)\s*(?:\((.*)\))?\s*$", re.I)
_LEGACY = re.compile(r"^\s*#\s*@permissions\s*:\s*(.+?)\s*$", re.I)
_HOST = re.compile(r"^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$")


def _norm_host(h):
    h = str(h).strip().lower().rstrip(".")
    if h in ("*", "localhost"):
        return h
    try:
        return str(ipaddress.ip_address(h.strip("[]")))
    except ValueError:
        pass
    return h if _HOST.match(h) and len(h) <= 253 else ""


def parse_declared(source):
    """-> {"network": [host...], "file": [mẫu...], "ai_signal": bool, "legacy": [...], "errors": [...]} từ 60 dòng đầu của file bot.
    `# @permissions: network` (kiểu cũ, không nêu host) = xin mạng tới MỌI host ('*')."""
    out = {"network": [], "file": [], "ai_signal": False, "ai_ask": False, "legacy": [], "errors": []}
    for line in source.splitlines()[:60]:
        m = _DECL.match(line)
        if m:
            kind, arg = m.group(1).lower(), (m.group(2) or "").strip()
            items = [x.strip() for x in arg.split(",") if x.strip()]
            if kind == "network":
                for x in items or ["*"]:
                    h = _norm_host(x)
                    if h:
                        if h not in out["network"]:
                            out["network"].append(h)
                    else:
                        out["errors"].append("host không hợp lệ trong @permission network: %r" % x)
            elif kind == "file":
                out["file"].extend(i for i in items if i not in out["file"])
            elif kind == "ai_signal":
                out["ai_signal"] = True
            elif kind == "ai_ask":
                out["ai_ask"] = True
            else:
                out["errors"].append("quyền không biết: %s" % kind)
            continue
        m = _LEGACY.match(line)
        if m:
            for x in (y.strip().lower() for y in m.group(1).split(",") if y.strip()):
                out["legacy"].append(x)
                if x == "network" and "*" not in out["network"]:
                    out["network"].append("*")
    return out


def host_matches(host, patterns):
    """host có khớp một mẫu trong `patterns` ('*' = mọi host; '*.x.com' = mọi host con của x.com, KHÔNG gồm x.com)."""
    h = _norm_host(host)
    if not h:
        return False
    for p in patterns or ():
        p = str(p).lower()
        if p == "*" or p == h:
            return True
        if p.startswith("*.") and h.endswith(p[1:]) and len(h) > len(p) - 1:
            return True
    return False


def describe(declared):
    """Danh sách dòng người đọc được cho hộp thoại xin quyền."""
    lines = []
    if declared.get("network"):
        hosts = declared["network"]
        lines.append("kết nối mạng tới: " + ("MỌI địa chỉ (không nêu host cụ thể)" if "*" in hosts else ", ".join(hosts)))
    if declared.get("file"):
        lines.append("đọc/ghi tệp: " + ", ".join(declared["file"]) + " (chưa cưỡng chế)")
    if declared.get("ai_signal"):
        lines.append("dùng tín hiệu AI (chưa cưỡng chế)")
    if declared.get("ai_ask"):
        lines.append("gọi AI bằng api.ask_ai - dữ liệu bot chọn sẽ gửi tới nhà cung cấp AI (chưa cưỡng chế; người dùng còn phải bật ở Cài đặt → Bot gọi AI)")
    return lines


class PermStore:
    """bot_perms.json: {tên_file_bot: {"network": [host đã cho phép], "at": "..."}}. base=None -> không có quyền nào được cấp."""

    def __init__(self, base):
        self.path = os.path.join(base, PERM_FILE) if base else None
        self._lock = threading.Lock()

    def _read(self):
        if not self.path:
            return {}
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _write(self, d):
        if not self.path:
            return
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    @staticmethod
    def _key(bot_file):
        return os.path.basename(str(bot_file))

    def granted(self, bot_file):
        g = self._read().get(self._key(bot_file))
        return dict(g) if isinstance(g, dict) else {}

    def grant(self, bot_file, kind, values):
        with self._lock:
            d = self._read()
            g = d.setdefault(self._key(bot_file), {})
            cur = list(g.get(kind, []))
            cur += [v for v in values if v not in cur]
            g[kind] = cur
            g["at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self._write(d)

    def grant_declared(self, bot_file, declared):
        if declared.get("network"):
            self.grant(bot_file, "network", declared["network"])

    def revoke(self, bot_file, kind=None):
        with self._lock:
            d = self._read()
            k = self._key(bot_file)
            if k in d:
                if kind:
                    d[k].pop(kind, None)
                    if not [x for x in d[k] if x != "at"]:
                        d.pop(k)
                else:
                    d.pop(k)
                self._write(d)

    def pending(self, bot_file, declared):
        """Phần ĐÃ KHAI BÁO mà CHƯA được cho phép: {"network": [host...]}. Rỗng = không cần hỏi."""
        out = {}
        g = self.granted(bot_file)
        nets = [h for h in declared.get("network", []) if not host_matches(h, g.get("network", [])) or (h == "*" and "*" not in g.get("network", []))]
        if nets:
            out["network"] = nets
        return out

    def effective_hosts(self, bot_file, declared):
        """Host bot ĐƯỢC PHÉP kết nối = khai báo ∩ đã cấp. ('*' khai báo cần '*' được cấp)."""
        g = self.granted(bot_file).get("network", [])
        res = []
        for h in declared.get("network", []):
            if h == "*":
                if "*" in g:
                    res.append("*")
            elif host_matches(h, g):
                res.append(h)
        return res


# ------------------------------------------------------------------------------------------------ rào mạng (chạy TRONG tiến trình bot)
_guard = {"on": False}


def install_network_guard(allowed):
    """Cài rào lên socket/DNS của tiến trình HIỆN TẠI: chỉ cho host trong `allowed` (danh sách mẫu; [] = chặn hết kết nối IP).
    Chỉ gọi trong tiến trình con của bot (botproc.child_main) - gọi ở tiến trình app sẽ chặn luôn mạng của app. Gọi lại = thay danh sách."""
    import socket
    allowed = [str(a).lower() for a in allowed]
    _guard["allowed"] = allowed
    if _guard["on"]:
        return
    _guard["on"] = True
    ok_ips = _guard.setdefault("ips", set())
    orig_gai, orig_connect, orig_connect_ex, orig_sendto = (socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex, socket.socket.sendto)

    def deny(host):
        raise PermissionError("Bot không được phép kết nối tới '%s'. Khai báo ở đầu file bot dòng `# @permission: network(%s)` rồi bấm «Cho phép» "
                              "khi app hỏi (hoặc Cài đặt → «Quyền mạng của bot» = off)." % (host, host))

    def check_name(host):
        if host is None or host == "" or isinstance(host, int):
            return
        h = host.decode("ascii", "ignore") if isinstance(host, (bytes, bytearray)) else str(host)
        if not host_matches(h, _guard["allowed"]):
            deny(h)

    def gai(host, *a, **k):
        check_name(host)
        res = orig_gai(host, *a, **k)
        for r in res:
            ok_ips.add(r[4][0])
        return res

    def check_addr(self, addr):
        if self.family in (socket.AF_INET, socket.AF_INET6) and isinstance(addr, tuple) and addr:
            ip = str(addr[0])
            if ip not in ok_ips and not host_matches(ip, _guard["allowed"]):
                deny(ip)

    def connect(self, addr):
        check_addr(self, addr)
        return orig_connect(self, addr)

    def connect_ex(self, addr):
        check_addr(self, addr)
        return orig_connect_ex(self, addr)

    def sendto(self, data, *args):
        if args:
            check_addr(self, args[-1])
        return orig_sendto(self, data, *args)

    def gethostbyname(host):
        check_name(host)
        return socket.getaddrinfo(host, None, socket.AF_INET)[0][4][0]

    def gethostbyname_ex(host):
        check_name(host)
        ips = sorted({r[4][0] for r in socket.getaddrinfo(host, None, socket.AF_INET)})
        return (host, [], ips)

    socket.getaddrinfo = gai
    socket.socket.connect = connect
    socket.socket.connect_ex = connect_ex
    socket.socket.sendto = sendto
    socket.gethostbyname = gethostbyname
    socket.gethostbyname_ex = gethostbyname_ex
