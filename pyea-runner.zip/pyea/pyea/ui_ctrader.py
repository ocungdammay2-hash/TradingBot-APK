"""Giao diện cTrader: «Đăng nhập cTrader» (OAuth ngay trên điện thoại) và «Chọn tài khoản cTrader». Logic nằm ở pyea/ctrader.py (không Kivy)."""
import threading

from kivy.clock import mainthread

from . import ctrader
from .ui_widgets import AMBER, BLUE, PANEL2, popup


def open_url(url):
    """Mở trình duyệt của điện thoại (Android: Intent ACTION_VIEW; nơi khác: webbrowser)."""
    try:
        from jnius import autoclass
        intent_cls, uri_cls, act = autoclass("android.content.Intent"), autoclass("android.net.Uri"), autoclass("org.kivy.android.PythonActivity")
        act.mActivity.startActivity(intent_cls(intent_cls.ACTION_VIEW, uri_cls.parse(url)))
        return
    except Exception:                                                    # noqa: BLE001
        pass
    import webbrowser
    webbrowser.open(url)


def _vals(app):
    form = app.settings_tab.gform
    vals, _ = form.read()
    return form, vals


def ctrader_login(app, opener=None, port=ctrader.OAUTH_PORT):
    form, vals = _vals(app)
    cid, sec = str(vals.get("ctrader_client_id", "")).strip(), str(vals.get("ctrader_client_secret", "")).strip()
    if not cid or not sec:
        popup("Thiếu thông tin ứng dụng", "Nhập «cTrader Client ID» và «cTrader Client Secret» trước.\n\nCách lấy (làm trên điện thoại được): mở openapi.ctrader.com → đăng nhập "
              "bằng cTrader ID → Applications → tạo ứng dụng → ghi Client ID/Secret, và thêm Redirect URI:\n\nhttp://localhost:%d/callback" % port, size=(0.92, 0.6), color=AMBER)
        return False
    redirect = "http://localhost:%d/callback" % port

    def go(_p):
        app.toast("Đang mở trình duyệt để đăng nhập cTrader...")

        def work():
            try:
                tok = ctrader.oauth_login(cid, sec, opener or open_url, port=port, scope="trading")
                done(tok, None)
            except Exception as e:                                       # noqa: BLE001
                done(None, str(e))

        @mainthread
        def done(tok, err):
            if err:
                popup("Đăng nhập cTrader chưa xong", err, size=(0.9, 0.5), color=AMBER)
                return
            new = dict(vals, ctrader_access_token=tok["access"], ctrader_refresh_token=tok["refresh"])
            form.set_values(new)
            app.save_forms(False)
            app.toast("Đã lấy token cTrader và lưu. Bấm «Chọn tài khoản cTrader» để kiểm tra.")

        threading.Thread(target=work, daemon=True).start()
        return True

    popup("Đăng nhập cTrader", "Trình duyệt sẽ mở trang đăng nhập cTrader ID chính thức (id.ctrader.com). Đăng nhập và cho phép quyền «trading». "
          "Mã đăng nhập quay về ĐIỆN THOẠI NÀY qua địa chỉ cục bộ %s - không qua máy chủ nào của chúng tôi.\n\n"
          "Cần: ứng dụng của bạn ở openapi.ctrader.com đã thêm đúng Redirect URI trên. Giữ app mở tới khi xong (tối đa 3 phút)." % redirect,
          [("Mở trình duyệt", BLUE, go), ("Huỷ", PANEL2, None)], size=(0.92, 0.6))
    return True


def ctrader_accounts(app):
    form, vals = _vals(app)

    def work():
        try:
            b = ctrader.make_backend(vals)
            accs = b.c.discover()
            done(accs, None)
        except Exception as e:                                           # noqa: BLE001
            done(None, str(e))

    @mainthread
    def done(accs, err):
        if err:
            popup("Không đọc được tài khoản cTrader", err, size=(0.9, 0.5), color=AMBER)
            return
        if not accs:
            popup("Token không có tài khoản", "Token này chưa có tài khoản cTrader nào được cấp quyền.", size=(0.9, 0.4), color=AMBER)
            return
        lines = ["%s  #%s  (%s)  %s" % ("LIVE" if a["live"] else "DEMO", a["login"] or "-", a["id"], a["broker"]) for a in accs]
        btns = []
        for a in accs[:3]:
            def pick(_p, a=a):
                form.set_values(dict(vals, ctrader_account=str(a["id"]), ctrader_env="live" if a["live"] else "demo"))
                app.save_forms(False)
                app.toast("Đã chọn tài khoản %s %s" % ("LIVE" if a["live"] else "DEMO", a["login"] or a["id"]))
                return True
            btns.append(("Dùng %s %s" % ("LIVE" if a["live"] else "DEMO", a["login"] or a["id"]), BLUE, pick))
        btns.append(("Đóng", PANEL2, None))
        popup("Tài khoản cTrader của token", "\n".join(lines) + "\n\nLuôn thử tài khoản DEMO trước.", btns, size=(0.92, 0.6))

    app.toast("Đang đọc tài khoản cTrader...")
    threading.Thread(target=work, daemon=True).start()
