"""Hộp thoại «Bot hỏi AI»: lịch sử MỌI lần bot gọi api.ask_ai (kể cả lỗi/hết hạn mức), hạn mức đã dùng, xem chi tiết, xoá. Logic ở pyea/aiask.py."""
import time

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout

from . import aiask
from .ui_widgets import AMBER, BLUE, MIN_TOUCH, MUTED, PANEL2, StyledPopup, mkbtn, popup, vbox, vscroll, wlabel


def open_ask_history(app):
    base = app.store.base
    st = app.settings
    box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    body = vbox(spacing=dp(4))
    pop = StyledPopup(title="Bot hỏi AI", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)

    def rebuild():
        body.clear_widgets()
        h, d = aiask.usage_counts(base, time.time())
        lh, ld = int(st.get("bot_ai_max_per_hour", 20) or 0), int(st.get("bot_ai_max_per_day", 200) or 0)
        body.add_widget(wlabel("Trạng thái: %s · đã gọi %d/%s lần trong 1 giờ, %d/%s lần trong 24 giờ%s" % (
            "ĐANG BẬT" if st.get("bot_ai_enabled") else "ĐANG TẮT (Cài đặt → Bot gọi AI)", h, lh or "∞", d, ld or "∞",
            " · cho tra web" if st.get("bot_ai_allow_web") else ""), 12, AMBER if not st.get("bot_ai_enabled") else MUTED))
        recs = aiask.load_history(base, 60)
        if not recs:
            body.add_widget(wlabel("Chưa có bot nào hỏi AI. Bot gọi self.api.ask_ai(...) thì mỗi lần sẽ hiện ở đây (✔ ok · ✖ lỗi · ⏳ hết hạn mức).", 13))
        for r in recs:
            body.add_widget(mkbtn(aiask.hist_line(r), PANEL2, size=11, h=MIN_TOUCH - 6, on_release=lambda *_, r=r: popup("Chi tiết", aiask.hist_detail(r), size=(0.95, 0.8))))

    def clear(*_):
        aiask.clear_history(base)
        rebuild()

    rebuild()
    box.add_widget(vscroll(body))
    row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
    row.add_widget(mkbtn("Làm mới", BLUE, size=12, on_release=lambda *_: rebuild()))
    row.add_widget(mkbtn("Xoá lịch sử", PANEL2, size=12, on_release=clear))
    row.add_widget(mkbtn("Đóng", BLUE, size=12, on_release=lambda *_: pop.dismiss()))
    box.add_widget(row)
    pop.open()
