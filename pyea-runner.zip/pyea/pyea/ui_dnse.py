"""Giao diện DNSE: «Gửi Email OTP» và «Lấy trading token» (đổi OTP trong ô nhập thành trading token 8 giờ). Logic ở pyea/dnse.py."""
import threading

from kivy.clock import mainthread

from .ui_widgets import AMBER, popup


def _dnse_api(vals):
    from . import dnse
    return dnse.DnseV1(vals.get("dnse_username", ""), vals.get("dnse_password", ""), vals.get("dnse_api_base") or dnse.API_V1)


def dnse_send_email_otp(app, api_factory=_dnse_api):
    form = app.settings_tab.gform
    vals, _ = form.read()

    def work():
        try:
            api_factory(vals).email_otp()
            done(None)
        except Exception as e:                                           # noqa: BLE001
            done(str(e))

    @mainthread
    def done(err):
        if err:
            popup("Không gửi được Email OTP", err, size=(0.9, 0.5), color=AMBER)
        else:
            app.toast("Đã gửi Email OTP (hiệu lực 2 phút). Nhập mã vào ô «DNSE OTP», chọn loại OTP = email rồi bấm «Lấy trading token».")

    app.toast("Đang gửi Email OTP DNSE...")
    threading.Thread(target=work, daemon=True).start()


def dnse_get_token(app, api_factory=_dnse_api):
    form = app.settings_tab.gform
    vals, _ = form.read()
    otp = str(vals.get("dnse_otp", "")).strip()
    if not otp:
        popup("Thiếu OTP", "Nhập mã vào ô «DNSE OTP» (Smart OTP trong app Entrade X, hoặc bấm «Gửi Email OTP» rồi nhập mã trong email).", size=(0.9, 0.45), color=AMBER)
        return False

    def work():
        try:
            tok = api_factory(vals).trading_token(otp, vals.get("dnse_otp_kind", "smart") != "email")
            done(tok, None)
        except Exception as e:                                           # noqa: BLE001
            done(None, str(e))

    @mainthread
    def done(tok, err):
        if err:
            popup("Không lấy được trading token", err + "\n\nOTP chỉ dùng 1 lần và hết hạn nhanh; lấy mã mới rồi thử lại.", size=(0.9, 0.5), color=AMBER)
            return
        form.set_values(dict(vals, dnse_trading_token=tok, dnse_otp=""))
        app.save_forms(False)
        app.toast("Đã lấy trading token DNSE (hiệu lực 8 giờ).")

    app.toast("Đang đổi OTP lấy trading token...")
    threading.Thread(target=work, daemon=True).start()
    return True
