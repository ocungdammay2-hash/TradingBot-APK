"""
Tối ưu DI TRUYỀN (như «Genetic algorithm» của Strategy Tester MT5) - thay vì quét lưới đầy đủ.
Gen = giá trị từ danh sách `grid` (cùng định dạng với backtest.optimize). Tất định khi cho `seed`. Có bộ nhớ đệm: mỗi tổ hợp chạy 1 lần.
`evaluate(params) -> số` có thể tiêm vào (test); mặc định chạy backtest.run_backtest và lấy `report[sort_key]`.
"""
import random


def search_space_size(grid):
    n = 1
    for v in grid.values():
        n *= max(1, len(v))
    return n


def genetic_search(grid, evaluate, population=20, generations=8, mutation=0.15, elite=2, seed=None, max_evals=200,
                   progress=None, stop_event=None):
    """Trả list {'params','score'} giảm dần theo score. Dừng khi hết thế hệ, hết `max_evals` lần đánh giá khác nhau hoặc stop_event."""
    names = list(grid)
    if not names:
        return []
    rng = random.Random(seed)
    cache = {}
    stats = {"evals": 0}

    def score(g):
        key = tuple(g)
        if key not in cache:
            if stats["evals"] >= max_evals:
                return None
            p = dict(zip(names, g))
            try:
                v = evaluate(p)
            except Exception:                                    # noqa: BLE001 - tổ hợp lỗi = điểm rất thấp, không làm sập cả lượt tối ưu
                v = None
            cache[key] = -1e30 if v is None else (1e30 if v == float("inf") else float(v))
            stats["evals"] += 1
            if progress:
                progress(stats["evals"], max_evals)
        return cache[key]

    def rand_gene():
        return [rng.choice(grid[n]) for n in names]
    size = search_space_size(grid)
    pop = []
    while len(pop) < min(population, size):
        g = rand_gene()
        if g not in pop:
            pop.append(g)
    for _ in range(max(1, generations)):
        if stop_event is not None and stop_event.is_set():
            break
        scored = [(score(g), g) for g in pop]
        scored = [(s, g) for s, g in scored if s is not None]
        if not scored:
            break
        scored.sort(key=lambda x: x[0], reverse=True)
        if stats["evals"] >= max_evals or len(cache) >= size:
            break
        parents = [g for _, g in scored[:max(2, len(scored) // 2)]]
        nxt = [g for _, g in scored[:max(0, elite)]]
        guard = 0
        while len(nxt) < population and guard < population * 20:
            guard += 1
            a, b = rng.choice(parents), rng.choice(parents)
            child = [a[i] if rng.random() < 0.5 else b[i] for i in range(len(names))]
            for i, n in enumerate(names):
                if rng.random() < mutation:
                    child[i] = rng.choice(grid[n])
            if child not in nxt:
                nxt.append(child)
        pop = nxt
    for g in pop:
        score(g)
    out = [{"params": dict(zip(names, k)), "score": v} for k, v in cache.items()]
    out.sort(key=lambda x: x["score"], reverse=True)
    return out


def optimize_genetic(bot_path, base_params, grid, settings, symbol, tf, candles, warmup=100, mode="open", sort_key="Lợi nhuận ròng",
                     population=20, generations=8, seed=None, max_evals=120, progress=None, stop_event=None, costs=None, ai_signals=None, htf=None, top=20):
    """Cùng dạng kết quả với backtest.optimize: list {'params','report'} giảm dần theo sort_key."""
    from .backtest import run_backtest
    reports = {}

    def ev(p):
        full = dict(base_params or {})
        full.update(p)
        r = run_backtest(bot_path, full, settings, symbol, tf, candles, warmup, mode, costs=costs, ai_signals=ai_signals, htf=htf)
        if not (r.ok or r.trades):
            return None
        reports[tuple(sorted(p.items()))] = (full, r.report)
        return r.report.get(sort_key)
    res = genetic_search(grid, ev, population, generations, seed=seed, max_evals=max_evals, progress=progress, stop_event=stop_event)
    out = []
    for x in res:
        hit = reports.get(tuple(sorted(x["params"].items())))
        if hit:
            out.append({"params": hit[0], "report": hit[1]})
    return out[:top] if top else out
