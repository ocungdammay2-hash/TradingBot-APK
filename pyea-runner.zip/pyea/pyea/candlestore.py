"""Kho nến cho BACKTEST (không import Kivy): lưu trên đĩa, lần sau chỉ tải phần còn thiếu; xuất/nhập CSV để chuyển sang máy khác.

Thiết kế nhẹ máy:
  - Mỗi (nguồn, mã, khung) một file nhị phân: 8 byte đầu (magic + số nến) rồi các dòng 48 byte (6 số double: giờ mở, O, H, L, C, khối lượng), tăng dần theo giờ.
    100.000 nến ≈ 4,8 MB. Đọc bằng seek: chỉ đọc đoạn cần (tìm nhị phân theo giờ), không nạp cả file.
  - Chỉ lưu nến ĐÃ ĐÓNG. Thêm nến mới = GHI NỐI (không ghi lại cả file); chỉ ghi lại khi nối thêm phía trước (nến cũ hơn) hoặc cắt bớt khi quá MAX_STORED.
  - Tải mạng chỉ phần thiếu (đuôi mới + phần cũ hơn nếu cần), luôn kèm 1 nến CHỒNG LÊN nến đã lưu để chắc chắn liền mạch; không chồng được (nguồn bị cắt/phân trang đứt)
    thì bỏ dữ liệu đã lưu của chuỗi đó và tải lại đầy đủ -> không bao giờ để «lỗ» ngầm giữa dữ liệu.
  - Ghi nguyên tử (tệp tạm + os.replace) khi ghi lại cả file; ghi nối cập nhật số nến SAU cùng nên mất điện giữa chừng vẫn đọc được đúng.
CSV nhập: tự nhận dấu phân cách (, ; tab), có/không dòng tiêu đề, giờ dạng epoch giây/mili-giây hoặc `YYYY-MM-DD HH:MM[:SS]`, `YYYY.MM.DD`, `DD/MM/YYYY`
(cột Date + Time tách riêng như xuất của MT5 `<DATE> <TIME> <OPEN> ...` cũng được). Giờ trong file coi là UTC. Dữ liệu qua `clean_candles` (bỏ nến rác)."""
import calendar
import os
import re
import struct
import time

from .datacache import merge_candles
from .feeds import TIMEFRAMES, tf_seconds
from .sdk import Candle

MAGIC = b"PYC1"
ROW = struct.Struct("<6d")
HEAD = 8
MAX_STORED = 300000                 # ≈ 14 MB/chuỗi; vượt thì cắt bớt nến cũ nhất
FILE_SOURCE = "file"                # nguồn dành cho dữ liệu nhập từ CSV


def source_key(settings):
    """Tên nguồn để phân biệt kho: sàn đang chọn (ccxt kèm tên sàn). «simulated» -> None (dữ liệu giả, không lưu)."""
    ex = str((settings or {}).get("exchange", "") or "")
    if ex in ("", "simulated"):
        return None
    if ex == "ccxt":
        return "ccxt-" + (str(settings.get("ccxt_id", "") or "x").lower())
    return ex


def _safe(s):
    return re.sub(r"[^A-Za-z0-9.-]", "-", str(s))


class CandleStore:
    def __init__(self, directory):
        self.dir = directory

    # ---- đường dẫn / liệt kê ----
    def path(self, source, symbol, tf):
        return os.path.join(self.dir, "%s__%s__%s.bin" % (_safe(source), _safe(str(symbol).upper()), _safe(tf)))

    def _count(self, f):
        f.seek(0)
        h = f.read(HEAD)
        if len(h) < HEAD or h[:4] != MAGIC:
            return 0
        n = struct.unpack("<I", h[4:8])[0]
        f.seek(0, 2)
        return max(0, min(n, (f.tell() - HEAD) // ROW.size))

    def _row(self, f, i):
        f.seek(HEAD + i * ROW.size)
        return ROW.unpack(f.read(ROW.size))

    def info(self, source, symbol, tf):
        """{'count','first','last','bytes'} hoặc None nếu chưa có / hỏng."""
        p = self.path(source, symbol, tf)
        try:
            with open(p, "rb") as f:
                n = self._count(f)
                if n <= 0:
                    return None
                return {"count": n, "first": self._row(f, 0)[0], "last": self._row(f, n - 1)[0], "bytes": os.path.getsize(p)}
        except (OSError, struct.error):
            return None

    def list(self):
        """[{'source','symbol','tf', + info}] sắp theo nguồn/mã/khung."""
        out = []
        try:
            names = sorted(os.listdir(self.dir))
        except OSError:
            return out
        for n in names:
            if not n.endswith(".bin"):
                continue
            parts = n[:-4].split("__")
            if len(parts) != 3:
                continue
            inf = self.info(parts[0], parts[1], parts[2])
            if inf:
                inf.update(source=parts[0], symbol=parts[1], tf=parts[2])
                out.append(inf)
        return out

    def delete(self, source, symbol, tf):
        try:
            os.remove(self.path(source, symbol, tf))
            return True
        except OSError:
            return False

    def clear(self, source=None):
        n = 0
        for e in self.list():
            if source is None or e["source"] == source:
                n += int(self.delete(e["source"], e["symbol"], e["tf"]))
        return n

    # ---- đọc ----
    def _bisect(self, f, n, t):
        """Chỉ số nhỏ nhất i sao cho giờ[i] >= t (n nếu không có)."""
        lo, hi = 0, n
        while lo < hi:
            mid = (lo + hi) // 2
            if self._row(f, mid)[0] < t:
                lo = mid + 1
            else:
                hi = mid
        return lo

    def read(self, source, symbol, tf, since=None, before=None, last=None):
        """Nến trong [since, before) (None = không giới hạn), rồi lấy `last` nến CUỐI nếu có. Chỉ đọc đoạn cần."""
        try:
            with open(self.path(source, symbol, tf), "rb") as f:
                n = self._count(f)
                i0 = 0 if since is None else self._bisect(f, n, since)
                i1 = n if before is None else self._bisect(f, n, before)
                if last is not None:
                    i0 = max(i0, i1 - int(last))
                if i1 <= i0:
                    return []
                f.seek(HEAD + i0 * ROW.size)
                buf = f.read((i1 - i0) * ROW.size)
        except (OSError, struct.error):
            return []
        return [Candle(*r) for r in ROW.iter_unpack(buf[:len(buf) // ROW.size * ROW.size])]

    def read_index(self, source, symbol, tf, i0, i1):
        """Nến theo chỉ số [i0, i1) (để xuất từng khúc)."""
        try:
            with open(self.path(source, symbol, tf), "rb") as f:
                n = self._count(f)
                i0, i1 = max(0, i0), min(n, i1)
                if i1 <= i0:
                    return []
                f.seek(HEAD + i0 * ROW.size)
                buf = f.read((i1 - i0) * ROW.size)
        except (OSError, struct.error):
            return []
        return [Candle(*r) for r in ROW.iter_unpack(buf[:len(buf) // ROW.size * ROW.size])]

    def count_before(self, source, symbol, tf, before):
        try:
            with open(self.path(source, symbol, tf), "rb") as f:
                n = self._count(f)
                return self._bisect(f, n, before) if before is not None else n
        except (OSError, struct.error):
            return 0

    # ---- ghi ----
    @staticmethod
    def _pack(cs):
        return b"".join(ROW.pack(c.time, c.open, c.high, c.low, c.close, c.volume or 0.0) for c in cs)

    def _rewrite(self, p, body, n):
        os.makedirs(self.dir, exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "wb") as f:
            f.write(MAGIC + struct.pack("<I", n))
            f.write(body)
        os.replace(tmp, p)

    def put(self, source, symbol, tf, candles):
        """Gộp `candles` (đã đóng) vào chuỗi. Trả về True nếu ghi được. Trùng giờ -> bản mới thắng."""
        new = sorted({c.time: c for c in candles}.values(), key=lambda c: c.time)
        if not new:
            return True
        p = self.path(source, symbol, tf)
        try:
            inf = self.info(source, symbol, tf)
            if inf is None:
                new = new[-MAX_STORED:]
                self._rewrite(p, self._pack(new), len(new))
                return True
            if new[0].time > inf["last"]:                                   # nối đuôi: chỉ ghi phần mới
                n = inf["count"]
                if n + len(new) > MAX_STORED * 1.1:
                    old = self.read(source, symbol, tf, last=MAX_STORED - len(new))
                    allc = (old + new)[-MAX_STORED:]
                    self._rewrite(p, self._pack(allc), len(allc))
                    return True
                with open(p, "r+b") as f:
                    f.seek(HEAD + n * ROW.size)
                    f.write(self._pack(new))
                    f.truncate()
                    f.flush()
                    f.seek(4)
                    f.write(struct.pack("<I", n + len(new)))
                return True
            if new[-1].time < inf["first"]:                                 # nối đầu: ghi lại (byte thô của phần cũ, không tạo đối tượng)
                with open(p, "rb") as f:
                    f.seek(HEAD)
                    old_raw = f.read(inf["count"] * ROW.size)
                body = self._pack(new) + old_raw
                n = len(new) + inf["count"]
                if n > MAX_STORED:
                    body = body[(n - MAX_STORED) * ROW.size:]
                    n = MAX_STORED
                self._rewrite(p, body, n)
                return True
            merged = merge_candles(self.read(source, symbol, tf), new)[-MAX_STORED:]   # chồng lấn: gộp đầy đủ
            self._rewrite(p, self._pack(merged), len(merged))
            return True
        except (OSError, struct.error):
            return False


def closed_only(candles, tf, now):
    step = tf_seconds(tf)
    return [c for c in candles if c.time + step <= now]


def get_candles(store, source, feed, symbol, tf, bars, end=None, progress=None, now=None, fetch=None):
    """`bars` nến ĐÃ ĐÓNG kết thúc trước `end` (None = mới nhất), cũ -> mới. Dùng kho; chỉ tải phần thiếu. source None (dữ liệu giả) -> không lưu.
    Trả về (nến, thông tin) với thông tin {'cached': số nến lấy từ kho, 'fetched': số nến tải mới, 'refetch': đã bỏ kho vì không liền mạch}."""
    if fetch is None:
        from .feeds import fetch_history as fetch
    now = time.time() if now is None else now
    step = tf_seconds(tf)
    stat = {"cached": 0, "fetched": 0, "refetch": False}
    want_end = now if end is None else min(end, now)
    if store is None or source is None:
        cs = fetch(feed, symbol, tf, bars, end=end, progress=progress)
        stat["fetched"] = len(cs)
        return cs, stat

    def pull(n, e):
        got = closed_only(fetch(feed, symbol, tf, n + 1, end=e, progress=progress), tf, now)       # +1: nến đang chạy dở bị loại
        stat["fetched"] += len(got)
        return got

    def fresh():
        stat["refetch"] = True
        store.delete(source, symbol, tf)
        cs = pull(bars, end)
        if cs:
            store.put(source, symbol, tf, cs)

    inf = store.info(source, symbol, tf)
    if inf is None:
        cs = pull(bars, end)
        if cs:
            store.put(source, symbol, tf, cs)
    else:
        # 1) đuôi: nến đóng mới hơn nến đã lưu
        if want_end - (inf["last"] + step) >= step:
            need = int((want_end - inf["last"]) / step) + 2
            new = pull(need, end)
            if new:
                if new[0].time <= inf["last"]:                              # có chồng lấn -> liền mạch
                    store.put(source, symbol, tf, [c for c in new if c.time > inf["last"]])
                else:
                    fresh()
                    inf = None
        # 2) đầu: chưa đủ `bars` nến trước want_end -> tải thêm nến cũ hơn
        cur = store.info(source, symbol, tf)
        if cur:
            have = store.count_before(source, symbol, tf, want_end)
            first = cur["first"]
            if have < bars:
                old = pull(bars - have + 2, first + step)
                if old and old[-1].time >= first:
                    store.put(source, symbol, tf, [c for c in old if c.time < first])
                # không chồng lấn/không có nến cũ hơn: giữ phần đã có (nguồn không có xa hơn)
    out = store.read(source, symbol, tf, before=want_end, last=bars)
    stat["cached"] = max(0, len(out) - stat["fetched"]) if not stat["refetch"] else 0
    return out, stat


# ---------------------------------------------------------------- CSV
def _num(s):
    return float(s.strip().replace(",", ".") if s.count(",") == 1 and "." not in s else s.strip())


_DATE_RES = [
    (re.compile(r"^(\d{4})[-./](\d{1,2})[-./](\d{1,2})$"), (0, 1, 2)),
    (re.compile(r"^(\d{1,2})[-./](\d{1,2})[-./](\d{4})$"), (2, 1, 0)),
]


def _parse_time(s):
    s = s.strip().strip('"')
    if re.fullmatch(r"\d{9,13}(\.\d+)?", s):
        v = float(s)
        return v / 1000.0 if v > 1e11 else v
    m = re.match(r"^(\S+)(?:[ T]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?", s)
    if not m:
        raise ValueError("giờ không hiểu: %r" % s)
    d = m.group(1)
    for rx, (iy, im, idd) in _DATE_RES:
        mm = rx.match(d)
        if mm:
            y, mo, dd = int(mm.group(iy + 1)), int(mm.group(im + 1)), int(mm.group(idd + 1))
            break
    else:
        raise ValueError("ngày không hiểu: %r" % s)
    hh, mi, ss = int(m.group(2) or 0), int(m.group(3) or 0), int(m.group(4) or 0)
    return float(calendar.timegm((y, mo, dd, hh, mi, ss)))


_COLS = {"time": "t", "timestamp": "t", "datetime": "t", "date": "d", "open": "o", "high": "h", "low": "l", "close": "c",
         "volume": "v", "vol": "v", "tickvol": "v", "tick_volume": "v", "tickvolume": "v", "o": "o", "h": "h", "l": "l", "c": "c", "v": "v"}


def parse_csv(text):
    """(nến tăng dần đã làm sạch, thông tin) từ văn bản CSV. Lỗi định dạng -> ValueError (kèm số dòng). thông tin: {'rows','skipped'}."""
    from .publicfeed import clean_candles
    lines = [ln for ln in text.replace("\r", "").split("\n") if ln.strip()]
    if not lines:
        raise ValueError("File rỗng")
    first = lines[0]
    delim = max((",", ";", "\t"), key=lambda d: first.count(d))
    if first.count(delim) == 0:
        delim = ","
    head = [x.strip().strip('"').strip("<>").lower() for x in first.split(delim)]
    has_head = any(h in _COLS for h in head)
    if has_head:
        idx = {}
        for i, h in enumerate(head):
            k = _COLS.get(h)
            if k and k not in idx:
                idx[k] = i
        body = lines[1:]
        if not all(k in idx for k in "ohlc") or ("t" not in idx and "d" not in idx):
            raise ValueError("Thiếu cột (cần giờ/ngày, open, high, low, close)")
    else:
        idx = {"t": 0, "o": 1, "h": 2, "l": 3, "c": 4, "v": 5}
        body = lines
    out, skipped = [], 0
    for ln_no, ln in enumerate(body, 2 if has_head else 1):
        cells = ln.split(delim)
        try:
            if "d" in idx and "t" in idx and idx["d"] != idx["t"]:
                t = _parse_time(cells[idx["d"]] + " " + cells[idx["t"]])
            else:
                t = _parse_time(cells[idx.get("t", idx.get("d"))])
            v = _num(cells[idx["v"]]) if "v" in idx and idx["v"] < len(cells) and cells[idx["v"]].strip() else 0.0
            out.append(Candle(t, _num(cells[idx["o"]]), _num(cells[idx["h"]]), _num(cells[idx["l"]]), _num(cells[idx["c"]]), v))
        except (ValueError, IndexError):
            skipped += 1
            if skipped > 20 and skipped > len(out):
                raise ValueError("Quá nhiều dòng sai định dạng (ví dụ dòng %d). Kiểm tra cột/giờ trong file." % ln_no)
    if not out:
        raise ValueError("Không đọc được dòng nến nào (kiểm tra định dạng giờ và các cột OHLC)")
    out = merge_candles([], out)
    before = len(out)
    out = clean_candles(out)
    return out, {"rows": len(out), "skipped": skipped + (before - len(out))}


def detect_tf(candles):
    """Khung thời gian (khoá TIMEFRAMES) suy từ khoảng cách nến phổ biến nhất; None nếu không khớp khung nào."""
    ts = [c.time for c in candles]
    if len(ts) < 3:
        return None
    diffs = {}
    for a, b in zip(ts, ts[1:]):
        d = int(round(b - a))
        if d > 0:
            diffs[d] = diffs.get(d, 0) + 1
    if not diffs:
        return None
    mode = max(diffs, key=lambda d: (diffs[d], -d))
    for k, v in TIMEFRAMES.items():
        if v == mode:
            return k
    return None


def to_csv(candles):
    rows = ["time,open,high,low,close,volume"]
    for c in candles:
        rows.append("%s,%r,%r,%r,%r,%r" % (time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(c.time)), c.open, c.high, c.low, c.close, c.volume or 0.0))
    return "\n".join(rows) + "\n"


# ---------------------------------------------------------------- thao tác cấp cao cho giao diện (kiểm thử được không cần Kivy)
def import_csv_text(store, text, symbol, tf=None):
    """Nhập CSV vào nguồn «file». tf None -> tự nhận từ dữ liệu (không nhận được -> ValueError). Trả về {'count','tf','symbol','first','last','skipped'}."""
    symbol = str(symbol or "").strip().upper()
    if not symbol:
        raise ValueError("Cần nhập tên mã (vd XAUUSD)")
    candles, info = parse_csv(text)
    det = detect_tf(candles)
    use = tf or det
    if use is None or use not in TIMEFRAMES:
        raise ValueError("Không nhận ra khung thời gian từ khoảng cách giữa các nến - hãy chọn khung thủ công")
    if tf and det and det != tf:
        raise ValueError("Khung bạn chọn (%s) khác khung nhận ra từ dữ liệu (%s)" % (tf, det))
    if not store.put(FILE_SOURCE, symbol, use, candles):
        raise ValueError("Không ghi được vào bộ nhớ của app")
    return {"count": len(candles), "tf": use, "symbol": symbol, "first": candles[0].time, "last": candles[-1].time, "skipped": info["skipped"]}


def export_csv(store, source, symbol, tf, exports_dir, now=None):
    """Ghi toàn bộ chuỗi ra CSV trong exports_dir, từng khúc 20.000 nến (RAM không phình với chuỗi dài). Trả về đường dẫn."""
    inf = store.info(source, symbol, tf)
    if not inf:
        raise ValueError("Chuỗi dữ liệu không còn")
    os.makedirs(exports_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime(time.time() if now is None else now))
    path = os.path.join(exports_dir, "candles-%s-%s-%s-%s.csv" % (_safe(source), _safe(symbol), _safe(tf), stamp))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write("time,open,high,low,close,volume\n")
        for i0 in range(0, inf["count"], 20000):
            chunk = store.read_index(source, symbol, tf, i0, min(inf["count"], i0 + 20000))
            f.write(to_csv(chunk).split("\n", 1)[1])
    os.replace(tmp, path)
    return path
