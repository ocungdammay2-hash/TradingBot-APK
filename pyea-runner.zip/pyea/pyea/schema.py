"""
Phiên bản định dạng DỮ LIỆU trên đĩa (settings.json, session_state.json, ui_prefs.json, ...), để cập nhật app không làm hỏng
dữ liệu cũ và hạ cấp app không ghi đè dữ liệu của bản mới hơn.

  data_version.json : {"schema": N, "app": "x.y.z"}  - một dấu duy nhất cho cả thư mục dữ liệu
  "_schema": N       : đóng dấu trong từng file JSON dạng dict do app ghi (settings, session_state, ui_prefs)

Quy tắc (không bao giờ làm mất dữ liệu):
  - thiếu dấu (thư mục mới hoặc dữ liệu của bản ≤1.5.0)  -> coi là schema 0, chạy các bước MIGRATIONS 0→1→..., ghi dấu mới.
    Trước khi chạy bước nào, SAO CHÉP các file JSON sang migrate_backup/v<N>/ (một lần cho mỗi bước).
  - dấu > CURRENT (app bị hạ cấp)                         -> KHÔNG ghi, KHÔNG migrate; `too_new` = True. Nơi nạp file từng loại
    gặp `_schema` > CURRENT thì đổi tên file sang *.v<N>.bak (giữ nguyên) rồi bắt đầu lại từ mặc định - không ghi đè lên dữ liệu lạ.
  - thêm một bước migrate: tăng CURRENT, thêm MIGRATIONS[N-1] = hàm(base) -> ghi chú; viết test trong tests/test_schema_logs.py.
"""
import json
import os
import shutil
import time

CURRENT = 1
MARKER = "data_version.json"
STAMPED_FILES = ("settings.json", "session_state.json", "ui_prefs.json", "alerts.json", "instances.json", "agents.json")

# MIGRATIONS[n] nâng dữ liệu từ schema n lên n+1; hàm nhận thư mục dữ liệu, trả về chuỗi ghi chú (hoặc ""). 0→1: không đổi gì
# (v1 chỉ bắt đầu đóng dấu), nên là no-op có chủ ý.
MIGRATIONS = {0: lambda base: ""}


def read_marker(base):
    try:
        with open(os.path.join(base, MARKER), "r", encoding="utf-8") as f:
            return int(json.load(f).get("schema", 0))
    except Exception:                                   # noqa: BLE001
        return 0


def _write_marker(base, schema):
    from . import __version__
    p = os.path.join(base, MARKER)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"schema": schema, "app": __version__, "at": time.strftime("%Y-%m-%d %H:%M:%S")}, f)
    os.replace(tmp, p)


def _backup(base, frm):
    dst = os.path.join(base, "migrate_backup", "v%d" % frm)
    if os.path.isdir(dst):
        return
    os.makedirs(dst, exist_ok=True)
    for n in STAMPED_FILES:
        p = os.path.join(base, n)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(dst, n))


def migrate(base, current=None, migrations=None):
    """Đưa thư mục dữ liệu lên schema hiện tại. -> dict(found, current, status, notes) với status: new|ok|migrated|too_new|failed."""
    current = CURRENT if current is None else current
    migrations = MIGRATIONS if migrations is None else migrations
    marker = os.path.join(base, MARKER)
    fresh = not os.path.exists(marker)
    found = read_marker(base)
    out = {"found": found, "current": current, "status": "ok", "notes": []}
    if found > current:
        out["status"] = "too_new"
        out["notes"].append("Dữ liệu ở định dạng v%d mới hơn app này (v%d): app KHÔNG ghi đè, file lạ sẽ được giữ nguyên làm bản .bak" % (found, current))
        return out
    if found == current and not fresh:
        return out
    has_data = any(os.path.isfile(os.path.join(base, n)) for n in STAMPED_FILES)
    try:
        v = found
        while v < current:
            fn = migrations.get(v)
            if fn is not None:
                if has_data:
                    _backup(base, v)
                note = fn(base)
                if note:
                    out["notes"].append(note)
            v += 1
        _write_marker(base, current)
        out["status"] = "migrated" if (found < current and has_data) else "new"
    except Exception as e:                              # noqa: BLE001 - migrate hỏng: giữ marker cũ, dữ liệu gốc còn nguyên + có bản sao
        out["status"] = "failed"
        out["notes"].append("Migrate lỗi: %s (dữ liệu gốc còn nguyên, có bản sao trong migrate_backup/)" % e)
    return out


def stamp(d, current=None):
    """Thêm `_schema` vào dict sắp ghi (trả bản sao)."""
    out = dict(d)
    out["_schema"] = CURRENT if current is None else current
    return out


def newer(d, current=None):
    """Số schema của dict nếu MỚI hơn app hiểu được, ngược lại 0."""
    try:
        n = int((d or {}).get("_schema", 0))
    except (TypeError, ValueError, AttributeError):
        return 0
    return n if n > (CURRENT if current is None else current) else 0


def set_aside(path, version):
    """Đổi tên file dữ liệu của bản mới hơn sang <file>.v<N>.bak (không ghi đè bản .bak đã có). -> đường dẫn .bak hoặc None."""
    bak = "%s.v%d.bak" % (path, version)
    n = 0
    while os.path.exists(bak):
        n += 1
        bak = "%s.v%d.%d.bak" % (path, version, n)
    try:
        os.replace(path, bak)
        return bak
    except OSError:
        return None
