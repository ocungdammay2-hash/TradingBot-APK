"""Công cụ vẽ trên biểu đồ (như MT5): đường ngang, xu hướng, chữ nhật, Fibonacci, chữ + Danh sách đối tượng. KHÔNG import Kivy.

Mỗi đối tượng neo vào (THỜI GIAN nến, GIÁ) nên giữ nguyên khi thu/phóng/lướt; lưu theo từng mã trong prefs["drawings"][mã].
Đối tượng chỉ để VẼ/GHI CHÚ - không bao giờ tự đặt lệnh.
"""
import bisect
import math
import time
import uuid

KINDS = ("hline", "trend", "rect", "fib", "text")
NAMES = {"hline": "Đường ngang", "trend": "Đường xu hướng", "rect": "Hình chữ nhật", "fib": "Fibonacci", "text": "Chữ"}
POINTS = {"hline": 1, "trend": 2, "rect": 2, "fib": 2, "text": 1}
FIB_LEVELS = (0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)
MAX_PER_SYMBOL = 60
MAX_TEXT = 60
COLORS = ((0.95, 0.80, 0.20, 1), (0.30, 0.65, 0.95, 1), (0.85, 0.40, 0.85, 1), (0.30, 0.85, 0.55, 1), (0.95, 0.55, 0.25, 1))


def _num(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def new_object(kind, pts, text="", color=0):
    """-> dict hoặc None nếu thiếu/sai điểm. pts = [(time, price), ...]."""
    if kind not in KINDS or len(pts) < POINTS[kind]:
        return None
    clean = []
    for t, p in list(pts)[:POINTS[kind]]:
        t, p = _num(t), _num(p)
        if t is None or p is None:
            return None
        clean.append([t, p])
    if kind in ("trend", "rect", "fib") and clean[0] == clean[1]:
        return None
    return {"id": uuid.uuid4().hex[:8], "kind": kind, "pts": clean, "text": str(text or "")[:MAX_TEXT], "color": int(color) % len(COLORS),
            "created": time.time()}


def clean_list(raw):
    """Đọc từ prefs: bỏ phần tử hỏng, giới hạn số lượng."""
    out, seen = [], set()
    for o in raw if isinstance(raw, list) else []:
        if not isinstance(o, dict) or o.get("kind") not in KINDS:
            continue
        n = new_object(o["kind"], [tuple(p) for p in o.get("pts") or [] if isinstance(p, (list, tuple)) and len(p) == 2],
                       o.get("text", ""), o.get("color", 0) if isinstance(o.get("color", 0), int) else 0)
        if n is None:
            continue
        n["id"] = str(o.get("id") or n["id"])[:16]
        n["created"] = _num(o.get("created")) or 0.0
        if n["id"] in seen:
            continue
        seen.add(n["id"])
        out.append(n)
    return out[-MAX_PER_SYMBOL:]


def get(prefs, symbol):
    return clean_list(((prefs or {}).get("drawings") or {}).get(symbol))


def put(prefs, symbol, objs):
    d = prefs.setdefault("drawings", {})
    if objs:
        d[symbol] = clean_list(objs)
    else:
        d.pop(symbol, None)
    return prefs


def add(objs, obj):
    out = list(objs) + [obj]
    return out[-MAX_PER_SYMBOL:]


def remove(objs, oid):
    return [o for o in objs if o["id"] != oid]


def fib_prices(p1, p2):
    """Mức Fibonacci giữa giá p1 (mốc 0%) và p2 (mốc 100%): [(tỉ lệ, giá)]."""
    return [(r, p1 + (p2 - p1) * r) for r in FIB_LEVELS]


def frac_index(times, t, step=60.0):
    """Thời gian -> chỉ số nến (số thực, 0 = nến đầu). Ngoài phạm vi: ngoại suy theo độ dài nến `step`."""
    if not times:
        return 0.0
    step = step if step and step > 0 else 60.0
    if t <= times[0]:
        return (t - times[0]) / step
    if t >= times[-1]:
        return len(times) - 1 + (t - times[-1]) / step
    i = bisect.bisect_right(times, t) - 1
    span = times[i + 1] - times[i]
    return i + ((t - times[i]) / span if span > 0 else 0.0)


def time_at(times, g, step=60.0):
    """Ngược lại của frac_index: chỉ số nến (số thực) -> thời gian."""
    if not times:
        return 0.0
    step = step if step and step > 0 else 60.0
    if g <= 0:
        return times[0] + g * step
    if g >= len(times) - 1:
        return times[-1] + (g - (len(times) - 1)) * step
    i = int(g)
    return times[i] + (g - i) * (times[i + 1] - times[i])


def _seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    u = 0.0 if L == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L))
    return math.hypot(px - (ax + u * dx), py - (ay + u * dy))


def hit_distance(obj, px, py, xy, width):
    """Khoảng cách (pixel) từ điểm chạm tới đối tượng; `xy(time, price) -> (x, y)`, `width` = bề rộng vùng vẽ."""
    pts = [xy(t, p) for t, p in obj["pts"]]
    k = obj["kind"]
    if k == "hline":
        return abs(py - pts[0][1])
    if k == "text":
        return math.hypot(px - pts[0][0], py - pts[0][1])
    (ax, ay), (bx, by) = pts
    if k == "trend":
        return _seg_dist(px, py, ax, ay, bx, by)
    if k == "rect":
        x0, x1, y0, y1 = min(ax, bx), max(ax, bx), min(ay, by), max(ay, by)
        if x0 <= px <= x1 and y0 <= py <= y1:
            return 0.0
        return min(_seg_dist(px, py, x0, y0, x1, y0), _seg_dist(px, py, x1, y0, x1, y1), _seg_dist(px, py, x1, y1, x0, y1), _seg_dist(px, py, x0, y1, x0, y0))
    best = 1e18                                       # fib: gần mức nào cũng tính (các mức kéo dài giữa hai mốc thời gian)
    x0, x1 = min(ax, bx), max(ax, bx)
    for _r, price in fib_prices(obj["pts"][0][1], obj["pts"][1][1]):
        y = xy(obj["pts"][0][0], price)[1]
        best = min(best, _seg_dist(px, py, x0, y, x1, y))
    return best


def nearest(objs, px, py, xy, width, radius):
    """Đối tượng gần điểm chạm nhất trong bán kính `radius` pixel, hoặc None."""
    best, bd = None, radius
    for o in objs:
        d = hit_distance(o, px, py, xy, width)
        if d <= bd:
            best, bd = o, d
    return best


def describe(obj):
    """Một dòng cho Danh sách đối tượng."""
    k, pts = obj["kind"], obj["pts"]
    name = NAMES.get(k, k)
    if k == "hline":
        return "%s @ %.8g" % (name, pts[0][1])
    if k == "text":
        return "%s «%s» @ %.8g" % (name, obj.get("text", ""), pts[0][1])
    return "%s  %.8g → %.8g" % (name, pts[0][1], pts[1][1])


def list_text(objs):
    if not objs:
        return "Chưa có đối tượng nào trên mã này."
    return "\n".join("%d. %s" % (i + 1, describe(o)) for i, o in enumerate(objs))


def clip_segment(x0, y0, x1, y1, xmin, ymin, xmax, ymax):
    """Cắt đoạn thẳng theo hình chữ nhật (Liang-Barsky) -> (x0,y0,x1,y1) hoặc None nếu nằm ngoài. Vì chart không dùng ScissorPush."""
    dx, dy = x1 - x0, y1 - y0
    t0, t1 = 0.0, 1.0
    for p, q in ((-dx, x0 - xmin), (dx, xmax - x0), (-dy, y0 - ymin), (dy, ymax - y0)):
        if p == 0:
            if q < 0:
                return None
            continue
        r = q / p
        if p < 0:
            if r > t1:
                return None
            t0 = max(t0, r)
        else:
            if r < t0:
                return None
            t1 = min(t1, r)
    return (x0 + t0 * dx, y0 + t0 * dy, x0 + t1 * dx, y0 + t1 * dy)
