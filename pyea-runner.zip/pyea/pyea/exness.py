"""
Exness Trading API (https://www.exness-api.com) - CHỈ tài khoản "Exness trading account" ở khu vực được mở (hiện VN/TH),
không phải tài khoản MetaTrader (MT4/MT5 đi qua cầu nối: xem bridges.py).

ĐÃ XÁC MINH từ tài liệu + mã mẫu chính thức: ký Ed25519 (header EXN-*), host discovery, đường dẫn REST (positions, orders,
operations, instruments, conditions, limits, snapshot), WebSocket (subprotocol exness-ws-protocol; /ws/ticks, /ws/events; mẫu
tin đăng ký), vòng đời ACK -> transaction_event/operations (confirmed|rejected|failed), body {instrument, side, volume}.
Đối chiếu tài liệu (25/10/2026): nến BẮT BUỘC có `from` (from+to hoặc from+count; from gồm, to không gồm; tăng dần; khung
M1..M30/H1+ viết kiểu MT; |count| <= limits.max_candles_per_request); lịch sử là /v1/history/accounts/{id}/deals|orders với
from/to/limit(1..200)/cursor; sửa lệnh chờ = PATCH (price/stop_loss_price/take_profit_price, null = bỏ SL/TP); đóng vị thế =
DELETE /positions/{id}; lệnh chờ type limit|stop|sltp; giá chỉ được có tối đa `point_digits` chữ số lẻ; mã lỗi cuối (bảng
FINAL_ERRORS); giới hạn nằm ở limits.rest.methods[].rate_limit{limit,window_seconds} + .limits{max_candles_per_request,...}.
CHƯA XÁC MINH (tài liệu ẩn schema): hình dạng JSON của snapshot/nến/lịch sử, vị trí tham số `volume` của DELETE (body hay query),
tên tham số thời gian (ISO hay ms), máy chủ nào phục vụ /v1/history, host WebSocket. Cách xử lý: phân tích linh hoạt (_dig), thử
các biến thể rồi NHỚ cái chạy được, kiểm tra lại kết quả đóng một phần, và `python -m pyea.selfcheck` (chung mọi sàn) chạy trên tài
khoản thật/demo cho ra báo cáo kèm phản hồi thô (dán lại để chỉnh).

Lưu ý bảo mật (tài liệu Exness khuyên chỉ dùng secret key ở môi trường server tin cậy): app Android giữ khoá riêng trong
Android Keystore (mã hoá, xem keystore.py); hãy tạo khoá API CHỈ cho app này, quyền tối thiểu, bật giới hạn IP nếu có.
"""
import json
import re
import threading
import time
import uuid
from collections import deque
from datetime import datetime
from urllib.parse import urlencode, urlsplit

from . import ed25519
from .broker import BrokerError, Fill
from . import fieldmap
from .protection import POS_PREFIX, ProtectionAPI, close_from_deals
from .feeds import FeedError, HttpError, TIMEFRAMES, history_resampled, http_json, tf_seconds
from .ratelimit import limiter_for
from .sdk import Candle, Tick
from .wsclient import WebSocketClient, WsClosed, WsError

HOSTS = {"main": "https://api.exness.com", "alt": "https://api.exness-api.com"}
WS_PROTOCOL = "exness-ws-protocol"
TERMINAL_OK = ("confirmed", "success", "succeeded", "completed", "filled", "done", "executed")
TERMINAL_BAD = ("rejected", "failed", "error", "cancelled", "canceled", "expired")


class ExnError(BrokerError):
    def __init__(self, msg, status=0, code=0, name="", retryable=False):
        BrokerError.__init__(self, msg)
        self.status, self.code, self.name, self.retryable = status, code, name, retryable


# Mã lỗi CUỐI của lệnh (transaction_event / operations): tên chữ theo trang open-position & place-pending-order,
# mã số theo bảng 'Error handling' của hướng dẫn place-first-trade. (tên -> (gợi ý tiếng Việt, thử lại được?))
FINAL_ERRORS = {
    "ACCOUNT_DISABLED": ("Tài khoản bị vô hiệu hoá", False),
    "ACCOUNT_CLOSE_ONLY": ("Tài khoản chỉ cho đóng lệnh (close-only): không mở lệnh mới / đặt lệnh chờ được", False),
    "REQUEST_INVALID": ("Yêu cầu không hợp lệ", False),
    "REQUEST_INVALID_PRICE": ("Giá không hợp lệ (quá số chữ số lẻ cho phép hoặc sai phía thị trường)", False),
    "MARKET_INSTRUMENT_NOT_FOUND": ("Sàn không có mã này", False),
    "MARKET_TRADE_DISABLED": ("Mã này đang tắt giao dịch - kiểm tra trade mode của tài khoản/mã", False),
    "MARKET_CLOSE_ONLY": ("Mã này chỉ cho đóng lệnh", False),
    "MARKET_SESSION_CLOSED": ("Thị trường đang đóng phiên - thử lại khi mở cửa", True),
    "MARKET_NO_QUOTES": ("Sàn chưa có giá để khớp lệnh - thử lại khi có giá", True),
    "TRADING_RULE_VOLUME_TOO_SMALL": ("Khối lượng nhỏ hơn tối thiểu (volume_min)", False),
    "TRADING_RULE_VOLUME_TOO_LARGE": ("Khối lượng lớn hơn tối đa (volume_max)", False),
    "TRADING_RULE_INVALID_VOLUME_STEP": ("Khối lượng không đúng bước (volume_step)", False),
    "TRADING_RULE_INVALID_VOLUME": ("Khối lượng không hợp lệ - xem volume_min/volume_max/volume_step", False),
    "TRADING_RULE_INVALID_PRICE_LEVELS": ("SL/TP/giá đặt sai mức tối thiểu (stop level) hoặc sai phía giá", False),
    "TRADING_RULE_INSUFFICIENT_MARGIN": ("Không đủ ký quỹ", False),
    "TRADING_RULE_MARGIN_LEVEL_TOO_LOW": ("Mức ký quỹ quá thấp để mở thêm", False),
    "TRADING_RULE_OPERATION_RESTRICTED": ("Thao tác bị hạn chế theo luật giao dịch của tài khoản/mã", False),
    "TRADING_RULE_TOO_MANY_PENDING_ORDERS": ("Quá nhiều lệnh chờ", False),
    "TRADING_RULE_TOO_MANY_OPEN_POSITIONS": ("Quá nhiều vị thế đang mở", False),
    "EXECUTION_REQUOTE": ("Sàn requote (giá đã đổi) - thử lại khi có giá mới", True),
    "EXECUTION_REJECTED": ("Sàn từ chối khớp - chờ tick mới rồi thử lại nếu vẫn muốn", True),
    "SYSTEM_RATE_LIMIT": ("Vượt giới hạn tốc độ - app tự giãn nhịp", True),
    "SYSTEM_TEMPORARY_UNAVAILABLE": ("Dịch vụ Exness tạm thời không khả dụng", True),
}
FINAL_CODES = {4001: "MARKET_TRADE_DISABLED", 4002: "MARKET_CLOSE_ONLY", 5000: "TRADING_RULE_INVALID_VOLUME",
               5005: "TRADING_RULE_INVALID_PRICE_LEVELS", 6000: "EXECUTION_REQUOTE", 6001: "EXECUTION_REJECTED"}


def describe_final_error(code, message=""):
    """(tên mã chuẩn, gợi ý tiếng Việt, thử lại được?) từ error_code (số hoặc chữ) và error_message của kết quả cuối."""
    name = ""
    for cand in (str(message or ""), str(code or "")):                    # tên chữ chính xác (ưu tiên thông điệp) thắng mã số
        c = cand.strip().upper()
        if c in FINAL_ERRORS:
            name = c
            break
    if not name:
        try:
            name = FINAL_CODES.get(int(str(code).strip()), "")
        except (TypeError, ValueError):
            pass
    if not name:
        m = re.search(r"\b(?:ACCOUNT|REQUEST|MARKET|TRADING_RULE|EXECUTION|SYSTEM)_[A-Z_]+\b", "%s %s" % (code, message))
        name = m.group(0) if m and m.group(0) in FINAL_ERRORS else ""
    hint, retry = FINAL_ERRORS.get(name, ("", False))
    return name, hint, retry


# ---------------------------------------------------------------------------------------------
# tiện ích phân tích linh hoạt
# ---------------------------------------------------------------------------------------------
def _num(x, default=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _dig(obj, names, depth=3):
    """Giá trị đầu tiên có khoá thuộc `names` (không phân biệt hoa thường), tìm lồng tới `depth` cấp."""
    names = [n.lower() for n in names]
    if isinstance(obj, dict):
        low = {str(k).lower(): v for k, v in obj.items()}
        for n in names:
            if n in low and low[n] not in (None, ""):
                return low[n]
        if depth > 0:
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    r = _dig(v, names, depth - 1)
                    if r is not None:
                        return r
    elif isinstance(obj, list) and depth > 0:
        for v in obj[:5]:
            r = _dig(v, names, depth - 1)
            if r is not None:
                return r
    return None


def _find_list(obj, keys, need=("instrument", "symbol")):
    """Danh sách dict đầu tiên dưới khoá thuộc `keys` (hoặc toàn bộ obj nếu đã là list)."""
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    if not isinstance(obj, dict):
        return []
    low = {str(k).lower(): v for k, v in obj.items()}
    for k in keys:
        if isinstance(low.get(k), list):
            return [x for x in low[k] if isinstance(x, dict)]
    for v in obj.values():
        if isinstance(v, dict):
            r = _find_list(v, keys, need)
            if r:
                return r
    return []


_FRAC = re.compile(r"(\.\d{6})\d+")


def _ts(x):
    if x is None or x == "":
        return time.time()
    if isinstance(x, (int, float)):
        v = float(x)
        return v / 1000.0 if v > 1e11 else v
    s = str(x).strip()
    try:
        v = float(s)
        return v / 1000.0 if v > 1e11 else v
    except ValueError:
        pass
    s = _FRAC.sub(r"\1", s.replace("Z", "+00:00").replace(" ", "T", 1) if "T" not in s else s.replace("Z", "+00:00"))
    try:
        d = datetime.fromisoformat(s)
        if d.tzinfo is None:
            return d.replace(tzinfo=__import__("datetime").timezone.utc).timestamp()
        return d.timestamp()
    except ValueError:
        return time.time()


def _iso(t):
    return datetime.fromtimestamp(float(t), __import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _side(x):
    s = str(x or "").lower()
    if s in ("buy", "long", "b", "0", "position_type_buy", "order_type_buy"):
        return "buy"
    if s in ("sell", "short", "s", "1", "position_type_sell", "order_type_sell"):
        return "sell"
    return "buy" if "buy" in s else ("sell" if "sell" in s else "")


def _dec(x, digits=8):
    """Số -> chuỗi thập phân gọn (API Exness nhận khối lượng/giá dạng chuỗi)."""
    s = ("%." + str(digits) + "f") % float(x)
    return s.rstrip("0").rstrip(".") if "." in s else s


def to_ws_base(base):
    return re.sub(r"^http", "ws", base)


# ---------------------------------------------------------------------------------------------
class ExnClient:
    def __init__(self, api_key, private_key, account_id, host="main", ws_url="", clock=time.time, timeout=15, limiter=None):
        if not str(api_key or "").strip():
            raise ExnError("Thiếu Exness API key (exnsk_...)")
        if not str(account_id or "").strip():
            raise ExnError("Thiếu số tài khoản Exness (account id)")
        try:
            self.seed = ed25519.load_private_seed(private_key)
        except ValueError as e:
            raise ExnError("Khoá riêng Exness không hợp lệ: %s" % e)
        self.api_key = str(api_key).strip()
        self.account_id = str(account_id).strip()
        h = str(host or "main").strip()
        self.disc = HOSTS.get(h, h).rstrip("/")
        if not re.match(r"^https?://", self.disc):
            self.disc = "https://" + self.disc
        self.ws_url = (ws_url or "").strip().rstrip("/")
        self.clock, self.timeout = clock, timeout
        self.read_lim = limiter or limiter_for("exness", self.disc)
        self.trade_lim = limiter_for("exness_trade", self.disc, rules=[(5, 1.0), (120, 60.0)])
        self._ap = None
        self._lock = threading.Lock()
        self.tf_style = None            # kiểu tên timeframe đã chạy được
        self.time_style = None          # 'ms' | 'iso' (tham số from/to của nến)
        self.hist_time_style = None     # như trên, cho /v1/history
        self.limit_consts = {}          # max_candles_per_request, history_range_days, history_age_days (từ /limits)
        self.fam_base = {}              # họ endpoint (configuration|market-data|history) -> host đã chạy được
        self.close_style = "body"       # volume của DELETE /positions/{id} đi trong 'body' hay 'query' (tài liệu không nói rõ)
        self.ws_ok = None
        self.stream = None

    # ---- ký ----
    def sign_headers(self, method, path_q, body=b"", idem=""):
        ts = int(self.clock() * 1000)
        payload = {"api_key": self.api_key, "idempotency_key": idem, "timestamp": ts, "sign_version": 1,
                   "method": method.upper(), "path": path_q, "body_hash": ed25519.b64u(__import__("hashlib").sha256(body).digest())}
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        return {"EXN-API-KEY": self.api_key, "EXN-IDEMPOTENCY-KEY": idem, "EXN-TIMESTAMP": str(ts), "EXN-SIGN-VERSION": "1",
                "EXN-DATA": ed25519.b64u(data), "EXN-SIGN": ed25519.b64u(ed25519.sign(self.seed, data))}

    # ---- gọi REST ----
    def request(self, method, path, params=None, body=None, base=None, idem=None, trade=False):
        q = urlencode(params) if params else ""
        path_q = path + ("?" + q if q else "")
        raw = json.dumps(body, separators=(",", ":")) if body is not None else None
        method = method.upper()
        if idem is None:
            idem = "" if method == "GET" else uuid.uuid4().hex
        hdrs = self.sign_headers(method, path_q, (raw or "").encode("utf-8"), idem)
        url = (base or self.disc) + path_q
        try:
            return http_json(url, headers=hdrs, method=method, timeout=self.timeout, raw_body=raw,
                             limiter=self.trade_lim if trade else self.read_lim)
        except HttpError as e:
            raise self._wrap(e)
        except FeedError as e:
            raise ExnError(str(e))

    @staticmethod
    def _wrap(e):
        code, name, msg = 0, "", ""
        try:
            j = json.loads(e.body)
            code = int(_dig(j, ("error_code", "code")) or 0)
            name = str(_dig(j, ("error_message", "message", "error")) or "")
            msg = str(_dig(j, ("detail", "description")) or "")
        except (ValueError, TypeError):
            pass
        hint = ""
        std, fhint, retry = describe_final_error(code, name)
        if code in (1000, 1001) or e.status == 401:
            hint = " - kiểm tra API key, khoá riêng Ed25519 và đồng hồ máy (lệch giờ làm chữ ký sai)"
        elif code == 1002 or e.status == 403:
            hint = " - kiểm tra quyền của khoá và danh sách IP được phép"
        elif e.status == 429:
            hint = " - vượt giới hạn tốc độ, app sẽ tự giãn nhịp"
            retry = True
        elif e.status in (500, 502, 503, 504):
            hint = " - lỗi phía Exness, thử lại sau"
            retry = True
        elif fhint:
            hint = " - " + fhint
        return ExnError("Exness HTTP %s [%s] %s%s%s" % (e.status, code or "-", name or (e.body or "")[:120], (" " + msg) if msg else "", hint),
                        e.status, code, std or name, retry)

    # ---- host ----
    def access_base(self):
        with self._lock:
            if self._ap:
                return self._ap
        d = self.request("GET", "/v1/trading/access-point", {"account_id": self.account_id})
        host = self._extract_host(d)
        if not host:
            raise ExnError("Không đọc được access_point từ phản hồi Exness: %s" % str(d)[:160])
        if not re.match(r"^https?://", host):
            host = urlsplit(self.disc).scheme + "://" + host
        with self._lock:
            self._ap = host.rstrip("/")
        return self._ap

    @staticmethod
    def _extract_host(d, depth=2):
        if isinstance(d, str):
            return d.strip() or None
        if isinstance(d, dict):
            low = {str(k).lower(): v for k, v in d.items()}
            for k in ("access_point", "accesspoint", "host", "url", "endpoint", "base_url", "address"):
                v = low.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()
                if isinstance(v, dict) and depth > 0:
                    r = ExnClient._extract_host(v, depth - 1)
                    if r:
                        return r
            if depth > 0:
                for v in d.values():
                    if isinstance(v, dict):
                        r = ExnClient._extract_host(v, depth - 1)
                        if r:
                            return r
        return None

    def ws_bases(self):
        out = []
        for b in (self.ws_ok, self.ws_url, self.disc, self._ap):
            if b and b not in out:
                out.append(b)
        return out

    # ---- cấu hình / dữ liệu ----
    def _cfg(self, tail=""):
        return "/v1/configuration/accounts/%s%s" % (self.account_id, tail)

    def get_family(self, path, params=None):
        """GET cho họ endpoint không-giao-dịch (configuration | market-data | history). Tài liệu không nói máy chủ nào phục vụ họ nào
        (host chính hay access point) -> thử theo thứ tự ưa thích, 404/lỗi mạng thì sang host kia, NHỚ host chạy được cho lần sau."""
        fam = path.split("/")[2] if path.startswith("/v1/") else ""
        known = self.fam_base.get(fam)
        order = [known] if known else (["ap", "disc"] if fam == "history" else ["disc", "ap"])
        last = None
        for i, which in enumerate(order):
            try:
                base = self.access_base() if which == "ap" else self.disc
            except ExnError as e:
                last = e
                continue
            try:
                d = self.request("GET", path, params, base=base)
            except ExnError as e:
                last = e
                if known or e.status not in (0, 404):
                    raise
                continue
            self.fam_base[fam] = which
            return d
        if known:                                   # host đã nhớ nay hỏng -> quên để lần sau dò lại
            self.fam_base.pop(fam, None)
        raise last or ExnError("Không gọi được %s" % path)

    def account(self):
        return self.get_family(self._cfg("/account"))

    def instruments(self):
        d = self.get_family(self._cfg("/instruments"))
        items = d.get("instruments") if isinstance(d, dict) else d
        out = []
        for x in items or []:
            out.append(x if isinstance(x, str) else str(_dig(x, ("instrument", "symbol", "name")) or ""))
        return [s for s in out if s]

    def conditions(self, instrument):
        return self.get_family(self._cfg("/instruments/%s/conditions" % instrument))

    def limits(self):
        return self.get_family(self._cfg("/limits"))

    def apply_limits(self, d=None):
        """Đọc giới hạn thật từ sàn (nếu parse được) -> đặt cho bộ giới hạn + nhớ hằng số (max nến/lần, tuổi/độ dài lịch sử).
        Trả về mô tả những gì đã áp dụng."""
        try:
            d = d if d is not None else self.limits()
        except ExnError:
            return None
        rules = rules_from_limits(d)
        consts = consts_from_limits(d)
        if consts:
            self.limit_consts = consts
        applied = {}
        for k, lim in (("read", self.read_lim), ("trade", self.trade_lim)):
            if rules.get(k):
                lim.set_rules(rules[k])
                applied[k] = rules[k]
        if consts:
            applied["consts"] = consts
        return applied or None

    def snapshot(self):
        return self.request("GET", "/v1/trading/accounts/%s/snapshot" % self.account_id, base=self.access_base())

    def operation(self, op_id):
        return self.request("GET", "/v1/trading/accounts/%s/operations/%s" % (self.account_id, op_id), base=self.access_base())

    def trade_post(self, path, body):
        return self.request("POST", "/v1/trading/accounts/%s%s" % (self.account_id, path), body=body, base=self.access_base(), trade=True)

    def trade_call(self, method, path, params=None, body=None):
        return self.request(method, "/v1/trading/accounts/%s%s" % (self.account_id, path), params=params, body=body,
                            base=self.access_base(), trade=True)

    # ---- nến ----
    @staticmethod
    def tf_names(tf):
        mt = {"1m": "M1", "2m": "M2", "3m": "M3", "4m": "M4", "5m": "M5", "6m": "M6", "10m": "M10", "12m": "M12", "15m": "M15",
              "20m": "M20", "30m": "M30", "1h": "H1", "2h": "H2", "3h": "H3", "4h": "H4", "6h": "H6", "8h": "H8", "12h": "H12",
              "1d": "D1", "1w": "W1", "1mo": "MN1"}
        low = {"1mo": "1M"}
        a = mt.get(tf, tf.upper())
        b = low.get(tf, tf)
        return {"mt": a, "compact": b, "lower": a.lower(), "seconds": str(tf_seconds(tf))}

    def max_candles(self):
        n = int(_num(self.limit_consts.get("max_candles_per_request"), 0))
        return n if n > 0 else 500

    @staticmethod
    def _tparam(t, style):
        return str(int(float(t) * 1000)) if style == "ms" else _iso(t)

    @staticmethod
    def _is_range_error(e):
        return e.status in (400, 422) and bool(re.search(r"TIME_RANGE|COUNT|RANGE", "%s %s" % (e.name, e), re.I))

    @staticmethod
    def _is_tf_error(e):
        return e.status in (400, 422) and bool(re.search(r"TIMEFRAME", "%s %s" % (e.name, e), re.I))

    def _candle_window(self, instrument, tf, from_t, to_t, price_type=None):
        """Một cửa sổ [from_t, to_t) -> list Candle (tăng dần). Dò kiểu tên khung + kiểu thời gian, nhớ cái chạy được."""
        styles = [self.tf_style] if self.tf_style else ["mt", "compact", "lower", "seconds"]
        tstyles = [self.time_style] if self.time_style else ["iso", "ms"]
        last = None
        for st in styles:
            for ts_style in tstyles:
                params = {"instrument": instrument, "timeframe": self.tf_names(tf)[st], "from": self._tparam(from_t, ts_style),
                          "to": self._tparam(to_t, ts_style)}
                if price_type:
                    params["price_type"] = price_type
                try:
                    d = self.get_family("/v1/market-data/accounts/%s/candles" % self.account_id, params)
                except ExnError as e:
                    last = e
                    if self._is_range_error(e):
                        raise
                    if e.status in (400, 422):                       # sai enum/định dạng -> thử biến thể kế
                        if self._is_tf_error(e):
                            break                                    # lỗi do tên khung: đổi kiểu tên, không cần thử kiểu thời gian khác
                        continue
                    raise
                self.tf_style, self.time_style = st, ts_style
                return parse_candles(d)
        raise last or ExnError("Exness không nhận timeframe %s" % tf)

    def candles(self, instrument, tf, count, end=None, price_type=None, max_windows=10):
        """`count` nến cuối cùng TRƯỚC `end` (None = tới hiện tại), cũ -> mới.
        Tài liệu: `from` BẮT BUỘC; from+to (from gồm, to không gồm) hoặc from+count; |count| và số nến của khoảng <= max_candles_per_request;
        trả tăng dần. Ta dùng cửa sổ from+to rồi lùi dần cửa sổ (qua khoảng nghỉ cuối tuần) tới khi đủ `count`."""
        step = tf_seconds(tf)
        want = max(1, int(count))
        cap = self.max_candles()
        to_t = float(end) if end is not None else float(self.clock())
        got = {}
        win_n = min(cap, want + 5)
        for _ in range(max_windows):
            from_t = to_t - win_n * step
            try:
                chunk = self._candle_window(instrument, tf, from_t, to_t, price_type)
            except ExnError as e:
                if self._is_range_error(e):
                    if win_n > 20:                                   # khoảng quá lớn theo cách sàn đếm -> thu nhỏ
                        win_n = max(10, win_n // 2)
                        continue
                    if got:
                        break                                        # chạm giới hạn độ sâu lịch sử
                raise
            for c in chunk:
                if from_t - 1e-6 <= c.time < to_t - 1e-6:
                    got[c.time] = c
            if len(got) >= want:
                break
            if not chunk and from_t < self.clock() - 3 * 366 * 86400:
                break
            win_n = cap
            to_t = from_t
        return sorted(got.values(), key=lambda c: c.time)[-want:]

    # ---- lịch sử giao dịch (/v1/history) ----
    HIST_LIMIT = 200

    def _history_window(self, kind, from_t, to_t=None):
        """Tải hết các trang của một cửa sổ thời gian. Trả list dict thô."""
        out, seen, cursor, pages = [], set(), None, 0
        tstyles = [self.hist_time_style] if self.hist_time_style else ["iso", "ms"]
        cur_from = from_t
        while pages < 60:
            pages += 1
            d = None
            last = None
            for ts_style in tstyles:
                if cursor:
                    params = {"cursor": cursor, "limit": self.HIST_LIMIT}          # tài liệu: cursor không đi chung bộ lọc khác ngoài limit
                else:
                    params = {"from": self._tparam(cur_from, ts_style), "limit": self.HIST_LIMIT}
                    if to_t is not None:
                        params["to"] = self._tparam(to_t, ts_style)
                try:
                    d = self.get_family("/v1/history/accounts/%s/%s" % (self.account_id, kind), params)
                except ExnError as e:
                    last = e
                    if e.status in (400, 422) and not cursor and not self._is_range_error(e):
                        continue
                    raise
                self.hist_time_style = ts_style
                break
            if d is None:
                raise last
            items = _find_list(d, (kind, "items", "data", "history", "result"), ())
            fresh = 0
            for r in items:
                k = str(_dig(r, ("deal_id", "order_id", "id", "ticket"), 0) or id(r))
                if k not in seen:
                    seen.add(k)
                    out.append(r)
                    fresh += 1
            nxt = _dig(d, ("next_cursor", "cursor", "next", "next_page_token"), 1) if isinstance(d, dict) else None
            if nxt and items and nxt != cursor:
                cursor = str(nxt)
                continue
            if not nxt and len(items) >= self.HIST_LIMIT and fresh:               # không có cursor mà trang đầy -> nhảy `from` tới mục cuối
                cursor = None
                cur_from = _ts(_dig(items[-1], ("event_time", "time", "executed_at", "created_at", "timestamp"), 0)) or cur_from
                continue
            break
        return out

    def history_rows(self, kind, since, until=None):
        """Các dòng lịch sử (`deals` | `orders`) từ `since` tới `until`/hiện tại, tự chia cửa sổ theo history_range_days và giới hạn
        history_age_days của sàn (đọc từ /limits)."""
        now = float(self.clock())
        age = _num(self.limit_consts.get("history_age_days"), 0.0)
        rng = _num(self.limit_consts.get("history_range_days"), 0.0)
        end = min(float(until), now) if until else now
        lo = float(since or 0) or now - 7 * 86400
        if age > 0:
            lo = max(lo, now - age * 86400 + 3600)
        lo = min(lo, now - 1)                                                        # tài liệu: from phải sớm hơn giờ hiện tại
        win = rng * 86400 - 60 if rng > 0 else 30 * 86400
        rows, t = [], lo
        while t < end:
            t2 = min(t + win, end)
            rows += self._history_window(kind, t, t2 if t2 < end else None)
            t = t2
        return rows


def consts_from_limits(d):
    """Hằng số hình dạng yêu cầu trong limits.rest.methods[].limits (tài liệu): lấy giá trị nhỏ nhất tìm được cho mỗi hằng số."""
    out = {}
    names = ("max_candles_per_request", "history_range_days", "history_age_days")

    def walk(o, depth=0):
        if isinstance(o, dict):
            for k, v in o.items():
                if str(k).lower() in names and isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
                    out[str(k).lower()] = min(out.get(str(k).lower(), v), v)
                elif depth < 6 and isinstance(v, (dict, list)):
                    walk(v, depth + 1)
        elif isinstance(o, list) and depth < 6:
            for v in o:
                walk(v, depth + 1)
    walk(d)
    return out


def _rules_documented(d):
    """Theo tài liệu: limits.rest.global_account_rate + limits.rest.methods[].rate_limit{limit, window_seconds}. Phương thức ghi (POST/PUT/
    PATCH/DELETE) -> 'trade', còn lại -> 'read'; global_account_rate áp cho cả hai. Mỗi cửa sổ lấy luật chặt nhất, nhân 0.8 cho dư.
    Trả {} nếu phản hồi không có cấu trúc này (-> dò linh hoạt bên dưới)."""
    rest = _dig(d, ("rest",), 2) if isinstance(d, (dict, list)) else None
    if not isinstance(rest, dict):
        return {}
    found = {"read": [], "trade": []}

    def pair(o):
        if not isinstance(o, dict):
            return None
        n, w = _num(o.get("limit"), 0.0), _num(o.get("window_seconds"), 0.0)
        return (n, w) if n > 0 and w > 0 else None
    g = pair(rest.get("global_account_rate"))
    methods = rest.get("methods")
    for m in methods if isinstance(methods, list) else []:
        r = pair(m.get("rate_limit")) if isinstance(m, dict) else None
        if r:
            kind = "trade" if str(m.get("http_method") or "").upper() in ("POST", "PUT", "PATCH", "DELETE") else "read"
            found[kind].append(r)
    out = {}
    for k in ("read", "trade"):
        rs = found[k] + ([g] if g else [])
        if found[k] or g:
            by_w = {}
            for n, w in rs:
                by_w[w] = min(by_w.get(w, n), n)
            out[k] = [(max(1.0, n * 0.8), w) for w, n in sorted(by_w.items())]
    return out


def rules_from_limits(d):
    """Luật tốc độ từ phản hồi /limits: ưu tiên cấu trúc đã được tài liệu mô tả; không có thì dò mọi cặp (số lượng, cửa sổ).
    Phân loại 'trade' nếu đường dẫn khoá chứa trade/order/position/operation."""
    doc = _rules_documented(d)
    if doc:
        return doc
    found = {"read": [], "trade": []}

    def walk(o, path):
        if isinstance(o, dict):
            low = {str(k).lower(): v for k, v in o.items()}
            n = None
            for k in ("limit", "requests", "max_requests", "rate", "rps", "per_second", "max", "capacity", "burst"):
                if k in low and isinstance(low[k], (int, float)) and not isinstance(low[k], bool) and low[k] > 0:
                    n = float(low[k])
                    break
            w = None
            for k, mul in (("window_ms", 0.001), ("period_ms", 0.001), ("interval_ms", 0.001), ("window_seconds", 1), ("window_sec", 1),
                           ("window", 1), ("period", 1), ("interval", 1), ("per", 1)):
                if k in low and isinstance(low[k], (int, float)) and low[k] > 0:
                    w = float(low[k]) * mul
                    break
            if n is None and "per_second" in low:
                n, w = _num(low["per_second"]), 1.0
            if "per_minute" in low and _num(low["per_minute"]) > 0:
                n, w = _num(low["per_minute"]), 60.0
            if "rps" in low and _num(low["rps"]) > 0:
                n, w = _num(low["rps"]), 1.0
            if n and w:
                label = "/".join(path) + " " + " ".join(str(v) for v in o.values() if isinstance(v, str))
                kind = "trade" if re.search(r"trad|order|position|operation|post|delete|patch", label, re.I) else "read"
                found[kind].append((n, w))
            for k, v in o.items():
                walk(v, path + [str(k)])
        elif isinstance(o, list):
            for v in o:
                walk(v, path)
    walk(d, [])
    out = {}
    for k, rs in found.items():
        if rs:
            # giữ phần thận trọng: lấy luật chặt nhất cho mỗi cửa sổ, nhân 0.8 để còn dư
            by_w = {}
            for n, w in rs:
                by_w[w] = min(by_w.get(w, n), n)
            out[k] = [(max(1.0, n * 0.8), w) for w, n in by_w.items()]
    return out


def parse_candles(d):
    items = _find_list(d, ("candles", "data", "items", "result", "bars", "ohlc"), ())
    out = []
    for it in items:
        o = it
        if not any(k in {str(x).lower() for x in it} for k in ("open", "o")):
            for sub in ("bid", "mid", "ask"):
                if isinstance(it.get(sub), dict):
                    o = dict(it.get(sub), **{k: v for k, v in it.items() if not isinstance(v, dict)})
                    break
        g = lambda *ks: _dig(o, ks, 0)  # noqa: E731
        op, hi, lo, cl = _num(g("open", "o"), None), _num(g("high", "h"), None), _num(g("low", "l"), None), _num(g("close", "c"), None)
        if None in (op, hi, lo, cl):
            continue
        out.append(Candle(_ts(g("time", "timestamp", "t", "open_time", "start", "datetime")), op, hi, lo, cl,
                          _num(g("volume", "v", "tick_volume", "ticks"))))
    out.sort(key=lambda c: c.time)
    return out


# ---------------------------------------------------------------------------------------------
class ExnStream:
    """Hai kết nối WebSocket nền: ticks (giá) và events (transaction/account_state). Tự nối lại, tự đăng ký lại."""

    def __init__(self, client):
        self.c = client
        self.ticks, self.want, self.tx, self.state = {}, set(), {}, {}
        self.errors = deque(maxlen=20)
        self.cv = threading.Condition()
        self.stop_ev = threading.Event()
        self._threads = {}
        self.connected = {"ticks": False, "events": False}

    def ensure(self, kind):
        t = self._threads.get(kind)
        if t is None or not t.is_alive():
            self.stop_ev.clear()
            t = threading.Thread(target=self._run, args=(kind,), name="exn-ws-" + kind, daemon=True)
            self._threads[kind] = t
            t.start()

    def subscribe_ticks(self, instruments):
        with self.cv:
            self.want.update(instruments)
        self.ensure("ticks")

    def _connect(self, kind):
        path = "/v1/server-events/accounts/%s/ws/%s" % (self.c.account_id, kind)
        last = None
        for base in self.c.ws_bases():
            ws = WebSocketClient(to_ws_base(base) + path, headers=self.c.sign_headers("GET", path, b"", ""),
                                 subprotocols=[WS_PROTOCOL], timeout=10)
            try:
                ws.connect()
                self.c.ws_ok = base
                return ws
            except WsError as e:
                last = e
                if e.status in (401, 403):
                    break
        raise last or WsError("Không có host WebSocket")

    def _run(self, kind):
        backoff = 1.0
        while not self.stop_ev.is_set():
            ws, subscribed = None, set()
            try:
                ws = self._connect(kind)
                self.connected[kind] = True
                backoff = 1.0
                if kind == "events":
                    for ev in ("transactions", "account_state"):
                        ws.send_text(json.dumps({"id": "sub-" + ev, "subscribe": {"event": ev}}))
                while not self.stop_ev.is_set():
                    if kind == "ticks":
                        with self.cv:
                            new = sorted(self.want - subscribed)
                        if new:
                            ws.send_text(json.dumps({"id": "ticks-%d" % len(subscribed), "subscribe": {"event": "ticks", "instruments": new}}))
                            subscribed.update(new)
                    m = ws.recv(1.0)
                    if m is None:
                        continue
                    try:
                        j = json.loads(m)
                    except ValueError:
                        continue
                    (self._on_tick if kind == "ticks" else self._on_event)(j)
            except (WsError, WsClosed, OSError) as e:
                self.errors.append("%s: %s" % (kind, e))
            finally:
                self.connected[kind] = False
                if ws:
                    ws.close()
            if self.stop_ev.wait(backoff):
                return
            backoff = min(backoff * 2, 30.0)

    def _on_tick(self, j):
        sym = j.get("instrument") or j.get("symbol")
        bid, ask = _num(j.get("bid"), None), _num(j.get("ask"), None)
        if sym and bid is not None and ask is not None and bid > 0 and ask > 0:
            with self.cv:
                self.ticks[sym] = Tick(sym, _ts(j.get("timestamp") or j.get("time")), bid, ask)
                self.cv.notify_all()

    def _on_event(self, j):
        et = j.get("event_type")
        if et == "transaction_event":
            with self.cv:
                for k in (j.get("operation_id"), j.get("client_request_id")):
                    if k:
                        self.tx[k] = j
                if len(self.tx) > 2000:
                    for k in list(self.tx)[:1000]:
                        self.tx.pop(k, None)
                self.cv.notify_all()
        elif et == "account_state_event":
            st = _dig(j, ("account_state",), 2)
            if isinstance(st, dict):
                with self.cv:
                    self.state = dict(st, _t=time.time())

    def wait_tx(self, keys, timeout):
        end = time.monotonic() + timeout
        with self.cv:
            while True:
                for k in keys:
                    if k and k in self.tx:
                        return self.tx[k]
                left = end - time.monotonic()
                if left <= 0:
                    return None
                self.cv.wait(min(left, 0.5))

    def wait_tick(self, sym, timeout):
        end = time.monotonic() + timeout
        with self.cv:
            while sym not in self.ticks:
                left = end - time.monotonic()
                if left <= 0:
                    return None
                self.cv.wait(min(left, 0.5))
            return self.ticks[sym]

    def close(self):
        self.stop_ev.set()


# ---------------------------------------------------------------------------------------------
class ExnFeed:
    name = "exness"
    NATIVE_TF = ["1m", "3m", "5m", "10m", "15m", "30m", "1h"]      # tài liệu candles: M1, M3, M5, M10, M15, M30, H1+
    TRY_NATIVE_TF = ("2h", "4h", "1d", "1w")                        # 'H1+' chưa liệt kê rõ -> thử gốc, 400 thì ghép từ nến 1h và nhớ

    def __init__(self, client, stream=None):
        self.c = client
        self.stream = stream or client_stream(client)
        self._syms, self._syms_t = None, 0.0
        self._rest_tick = {}
        self._tf_bad = set()

    @property
    def max_chunk(self):
        return self.c.max_candles()

    def symbols(self):
        if self._syms is None or time.time() - self._syms_t > 600:
            try:
                self._syms = sorted(self.c.instruments())
            except ExnError as e:
                raise FeedError(str(e))
            self._syms_t = time.time()
        return list(self._syms)

    def tick(self, symbol):
        t = self.stream.ticks.get(symbol)
        if t is None:
            self.stream.subscribe_ticks([symbol])
            t = self.stream.wait_tick(symbol, 3.0)
        if t is not None and time.time() - t.time < 60:
            return t
        return self._tick_from_rest(symbol, t)

    def _tick_from_rest(self, symbol, stale):
        """WS chưa có giá (thị trường đóng/ngắt nối): lấy nến 1m gần nhất. Không có spread -> bid=ask, tradeable chỉ khi nến còn mới."""
        now = time.time()
        c = self._rest_tick.get(symbol)
        if c is None or now - c[0] > 5:
            try:
                cs = self.c.candles(symbol, "1m", 2, max_windows=1) or self.c.candles(symbol, "1h", 1, max_windows=2)   # đóng cửa: 1h phủ 20 ngày/1 request
            except ExnError as e:
                if stale is not None:
                    return Tick(symbol, stale.time, stale.bid, stale.ask, False)
                raise FeedError("Exness chưa có giá %s (%s)" % (symbol, e))
            if not cs:
                raise FeedError("Exness chưa có giá %s" % symbol)
            c = self._rest_tick[symbol] = (now, cs[-1])
        k = c[1]
        return Tick(symbol, k.time + 60, k.close, k.close, tradeable=(now - k.time) < 180)

    def history(self, symbol, tf, n, end=None):
        from .feeds import utc_guard
        return utc_guard(self, lambda: self._native_history(symbol, tf, n, end), symbol, tf, n, end)

    def _native_history(self, symbol, tf, n, end=None):
        """`n` nến cuối trước `end`. Khung gốc của sàn gọi thẳng; khung khác thử gốc (nếu nằm trong TRY_NATIVE_TF) rồi ghép từ nến 1h."""
        if tf in self.NATIVE_TF or (tf in self.TRY_NATIVE_TF and tf not in self._tf_bad):
            try:
                return self.c.candles(symbol, tf, min(int(n), self.max_chunk), end)
            except ExnError as e:
                if tf in self.NATIVE_TF:
                    raise FeedError(str(e))
                if e.status in (400, 422):
                    self._tf_bad.add(tf)
                else:
                    raise FeedError(str(e))
        try:
            return history_resampled(self, self.NATIVE_TF, symbol, tf, n, end)
        except ExnError as e:
            raise FeedError(str(e))

    def close(self):
        pass


_STREAMS = {}


def client_stream(client):
    s = getattr(client, "stream", None)
    if s is None:
        s = client.stream = ExnStream(client)
    return s


# ---------------------------------------------------------------------------------------------
class ExnBroker(ProtectionAPI):
    supports_short = True
    netting = False                         # tài khoản cho phép nhiều vị thế/mã -> đóng THEO vị thế (close_market)
    native_pending = {"limit", "stop"}
    OP_TIMEOUT = 20.0
    CLOSE_BY_REF = True                     # vỏ đóng đúng vị thế (position_id) đã lưu thay vì cũ-nhất-trước
    PROT_STYLE = "position"                 # SL/TP native: mỗi vị thế một lệnh SLTP (pyea/protection.py) - sửa/gỡ bằng PATCH/DELETE /orders/{id}
    PROT_LABEL = {"sl": "SL của vị thế Exness", "tp": "TP của vị thế Exness"}
    # Dạng thân yêu cầu TẠO lệnh SLTP: tài liệu công khai nói «type sltp, đặt SL/TP cho MỘT vị thế bằng lệnh SLTP mới» với stop_loss_price/take_profit_price nhưng
    # KHÔNG nêu tên trường mã vị thế (schema chỉ có trong OpenAPI YAML, không đọc được). Thử lần lượt các dạng sau (lệnh bị từ chối thì không có tác dụng phụ),
    # nhớ dạng chạy được. (khoá mã vị thế, kèm instrument/side/volume?)
    SLTP_SHAPES = (("position_id", False), ("position", False), ("position_id", True), ("position", True))
    SLTP_RETRY_S = 300.0                    # sau khi MỌI dạng bị từ chối: nghỉ chừng này giây rồi mới thử lại (tránh dội lỗi mỗi vòng)

    def __init__(self, client, stream=None):
        self.c = client
        self.stream = stream or client_stream(client)
        self._cond = {}
        self._block = None                  # (tên mã lỗi, giờ) khi sàn vừa báo tài khoản/mã chỉ-đóng-lệnh hoặc bị vô hiệu hoá
        self._lv = {}                       # ticket -> dòng position_levels gần nhất (để set_position_levels biết lệnh SLTP đang có)
        self._sltp_fail = None              # (giờ thử lại, thông báo lỗi) khi mọi dạng tạo lệnh SLTP đều bị từ chối

    # ---- chuẩn bị / số dư ----
    def prepare(self, symbol, leverage=1.0):
        self.c.access_base()
        self.c.apply_limits()
        self.stream.ensure("events")
        return self.balance()

    def balance(self):
        st = self.stream.state
        if st and time.time() - st.get("_t", 0) < 30 and _num(st.get("balance"), None) is not None:
            return _num(st["balance"])
        d = None
        try:
            d = self.c.snapshot()
            b = _dig(d, ("balance",), 3)
        except ExnError:
            b = None
        if b is None:
            b = _dig(self.c.account(), ("balance",), 3)
        if b is None:
            raise ExnError("Không đọc được số dư từ Exness (schema account/snapshot khác dự kiến) - chạy Kiểm tra hệ thống")
        return _num(b)

    def account_state(self):
        try:
            d = self.c.snapshot()
        except ExnError:
            return dict(self.stream.state)
        st = _dig(d, ("account_state",), 3)
        return st if isinstance(st, dict) else {k: _dig(d, (k,), 3) for k in ("balance", "equity", "used_margin")}

    # ---- khối lượng ----
    def _conditions(self, symbol):
        c = self._cond.get(symbol)
        if c is None:
            try:
                d = self.c.conditions(symbol)
            except ExnError:
                d = {}
            pd = _dig(d, ("point_digits", "digits"), 2)
            c = self._cond[symbol] = {"min": _num(_dig(d, ("volume_min", "min_volume"), 2), 0.0),
                                      "max": _num(_dig(d, ("volume_max", "max_volume"), 2), 0.0),
                                      "step": _num(_dig(d, ("volume_step", "step_volume"), 2), 0.0),
                                      "digits": int(_num(pd, -1)) if pd is not None and _num(pd, -1) >= 0 else None}
        return c

    def _price(self, symbol, p):
        """Giá -> chuỗi với TỐI ĐA `point_digits` chữ số lẻ (tài liệu: nhiều hơn là bị REQUEST_INVALID_PRICE)."""
        digits = self._conditions(symbol)["digits"] if symbol else None
        return _dec(p, digits if digits is not None else 10)

    def _volume(self, symbol, qty):
        c = self._conditions(symbol)
        q = float(qty)
        if c["step"] > 0:
            q = int(q / c["step"] + 1e-9) * c["step"]
        digits = 8
        if c["step"] > 0:
            s = ("%.8f" % c["step"]).rstrip("0")
            digits = len(s.split(".")[1]) if "." in s else 0
        q = round(q, digits)
        if q <= 0 or (c["min"] and q < c["min"] - 1e-12):
            raise BrokerError("Khối lượng %s nhỏ hơn mức tối thiểu %s của %s" % (_dec(qty), _dec(c["min"] or 0), symbol))
        if c["max"] and q > c["max"]:
            raise BrokerError("Khối lượng %s lớn hơn mức tối đa %s của %s" % (_dec(q), _dec(c["max"]), symbol))
        return _dec(q, digits)

    # ---- đọc trạng thái ----
    def _snap_positions(self, d=None):
        d = d if d is not None else self.c.snapshot()
        out = []
        for p in _find_list(d, ("positions", "open_positions")):
            sym = p.get("instrument") or p.get("symbol")
            side = _side(p.get("side") or p.get("type") or p.get("direction"))
            vol = _num(_dig(p, ("volume", "qty", "quantity", "lots"), 0))
            if not (sym and side and vol > 0):
                continue
            out.append({"id": str(_dig(p, ("position_id", "id", "ticket"), 0) or ""), "symbol": sym, "side": side, "volume": vol,
                        "price": _num(_dig(p, ("open_price", "price", "entry_price", "price_open", "avg_price"), 0)),
                        "time": _ts(_dig(p, ("open_time", "time", "opened_at", "created_at"), 0)),
                        "sl": _num(_dig(p, ("stop_loss_price", "stop_loss", "sl"), 0)), "tp": _num(_dig(p, ("take_profit_price", "take_profit", "tp"), 0))})
        return out

    @staticmethod
    def _is_sltp(o):
        return str(o.get("type") or o.get("order_type") or "").lower() == "sltp"

    def _sltp_orders(self, d=None):
        """Các lệnh SLTP đang sống trong snapshot: [{id, ref (mã vị thế nó gắn), sl, tp}]. Tên trường liên kết không có trong tài liệu công khai -> dò vài tên."""
        d = d if d is not None else self.c.snapshot()
        out = []
        for o in _find_list(d, ("orders", "pending_orders", "open_orders")):
            if not self._is_sltp(o):
                continue
            fieldmap.remember(SCOPE, "order", o)
            out.append({"id": str(_fm("order", o, "id") or ""), "ref": str(_fm("order", o, "position_ref") or ""),
                        "sl": _num(_fm("order", o, "sl")), "tp": _num(_fm("order", o, "tp"))})
        return out

    def _snap_orders(self, d=None):
        d = d if d is not None else self.c.snapshot()
        out = []
        for o in _find_list(d, ("orders", "pending_orders", "open_orders")):
            sym = o.get("instrument") or o.get("symbol")
            vol = _num(_dig(o, ("volume", "qty", "quantity", "lots"), 0))
            if not (sym and vol > 0) or self._is_sltp(o):              # lệnh SLTP không phải lệnh chờ (nó là SL/TP của một vị thế)
                continue
            out.append({"id": str(_dig(o, ("order_id", "id", "ticket"), 0) or ""), "symbol": sym, "side": _side(o.get("side") or o.get("direction")),
                        "type": str(o.get("type") or o.get("order_type") or "").lower(), "volume": vol, "qty": vol,
                        "price": _num(_dig(o, ("price", "open_price", "trigger_price"), 0))})
        return out

    def positions(self):
        net = {}
        for p in self._snap_positions():
            n = net.setdefault(p["symbol"], {"buy": 0.0, "sell": 0.0, "bp": 0.0, "sp": 0.0})
            n[p["side"]] += p["volume"]
            n[("bp" if p["side"] == "buy" else "sp")] += p["volume"] * p["price"]
        out = {}
        for sym, n in net.items():
            q = n["buy"] - n["sell"]
            if abs(q) > 1e-12:
                side, tot = ("buy", n["bp"] / n["buy"] if n["buy"] else 0.0) if q > 0 else ("sell", n["sp"] / n["sell"] if n["sell"] else 0.0)
                out[sym] = {"qty": q, "price": tot}
        return out

    def hedged_positions(self):
        """Chi tiết từng vị thế trên sàn (đối soát theo ticket + SL/TP): SL/TP lấy từ chính vị thế nếu snapshot có, không thì từ lệnh SLTP gắn với nó."""
        d = self.c.snapshot()
        rows = self._snap_positions(d)
        links = {o["ref"]: o for o in self._sltp_orders(d) if o["ref"]}
        for r in rows:
            o = links.get(r["id"])
            if o is not None:                                       # có lệnh SLTP: mức của nó là mức đang hiệu lực
                r["sl"], r["tp"] = o["sl"], o["tp"]
        return rows

    # ---- thực thi ----
    def _await(self, ack, timeout=None):
        """ACK -> kết quả cuối (dict). Dùng sự kiện WS nếu có, không thì hỏi /operations/{id}."""
        timeout = timeout or self.OP_TIMEOUT
        op = str(_dig(ack, ("operation_id",), 1) or "")
        cid = str(_dig(ack, ("client_request_id",), 1) or "")
        end = time.monotonic() + timeout
        delay, n = 0.25, 0
        while time.monotonic() < end:
            ev = self.stream.wait_tx([op, cid], 0.4 if self.stream.connected.get("events") else 0.0)
            res = ev
            if res is None and op:
                try:
                    res = self.c.operation(op)
                except ExnError as e:
                    if e.status not in (404, 429):
                        raise
            if res is not None:
                st = str(res.get("status", "")).lower()
                if st in TERMINAL_OK:
                    return res
                if st in TERMINAL_BAD:
                    raise self._final_error(st, res)
            n += 1
            time.sleep(delay)
            delay = min(delay * 1.5, 1.0)
        raise ExnError("Hết %.0fs mà Exness chưa xác nhận lệnh (operation %s). Kiểm tra vị thế trước khi gửi lại." % (timeout, op or "?"))

    def _final_error(self, st, res):
        code, msg = res.get("error_code", ""), res.get("error_message", "")
        name, hint, retry = describe_final_error(code, msg)
        if name in ("ACCOUNT_CLOSE_ONLY", "ACCOUNT_DISABLED"):
            self._block = (name, time.time())
        detail = " ".join(x for x in ("[%s%s]" % (code, (" " + name) if name and name != str(code) else "") if (code or name) else "",
                                      str(msg) if msg and str(msg) != name else "") if x)
        return ExnError("Lệnh Exness bị %s: %s%s" % (st, detail, (" - " + hint) if hint else ""), 0, code if isinstance(code, int) else 0, name, retry)

    def _fill_from(self, res, symbol, side, vol, before_ids=None):
        """Fill từ kết quả cuối. `before_ids` != None nghĩa là lệnh MỞ vị thế: đọc thêm mã vị thế mới (Fill.ref) để vỏ đóng/gắn SL-TP đúng vị thế đó."""
        price = _dig(res, ("price", "fill_price", "executed_price", "avg_price", "open_price", "deal_price", "close_price"), 3)
        qty = _dig(res, ("filled_volume", "executed_volume", "volume", "qty"), 3)
        oid = str(_dig(res, ("order_id", "orderid"), 3) or "")
        pid = str(_dig(res, ("position_id", "positionid"), 3) or "") if before_ids is not None else ""
        fresh = None
        if before_ids is not None and (price is None or not pid):          # đọc giá/mã từ vị thế mới xuất hiện
            try:
                for p in self._snap_positions():
                    if p["id"] not in before_ids and p["symbol"] == symbol and p["side"] == side:
                        fresh = p
                        break
            except ExnError:
                fresh = None
        if fresh is not None and not pid:
            pid = fresh["id"]
        self.note_own_ref(pid)
        if price is None and fresh is not None:
            return Fill(fresh["price"], fresh["volume"], pid, oid)
        if price is None:
            t = self.stream.ticks.get(symbol)
            if t:
                return Fill(t.ask if side == "buy" else t.bid, float(vol), pid, oid)
            raise ExnError("Lệnh đã xác nhận nhưng không đọc được giá khớp từ phản hồi Exness - chạy Kiểm tra hệ thống")
        return Fill(_num(price), _num(qty, float(vol)) or float(vol), pid, oid)

    def market_order(self, symbol, side, qty, reduce_only=False, ref=None):
        if reduce_only:
            return self.close_market(symbol, "sell" if side == "buy" else "buy", qty, ref=ref)
        vol = self._volume(symbol, qty)
        try:
            before = {p["id"] for p in self._snap_positions()}
        except ExnError:
            before = None
        ack = self.c.trade_post("/positions", {"instrument": symbol, "side": side, "volume": vol})
        res = self._await(ack)
        return self._fill_from(res, symbol, side, vol, before)

    def _close_call(self, pid, vol=None):
        """DELETE /positions/{id}: không có volume = đóng hết. Tài liệu liệt kê volume/price/deviation/close_by_position_id nhưng không nói đi
        trong body hay query -> mặc định body (chữ ký có body_hash), `_verify_partial_close` phát hiện nếu sàn bỏ qua và đổi sang query."""
        path = "/positions/%s" % pid
        if vol is None:
            return self.c.trade_call("DELETE", path)
        if self.c.close_style == "query":
            return self.c.trade_call("DELETE", path, params={"volume": vol})
        return self.c.trade_call("DELETE", path, body={"volume": vol})

    def _verify_partial_close(self, p, take, res):
        """Đóng MỘT PHẦN mà sàn lại đóng HẾT (bỏ qua volume) là lỗi nguy hiểm trên tiền thật -> kiểm tra lại và đổi kiểu gửi cho lần sau."""
        closed = _num(_dig(res, ("filled_volume", "executed_volume", "volume", "qty"), 3), 0.0)
        gone = False
        for attempt in range(2):
            try:
                cur = next((x for x in self._snap_positions() if x["id"] == p["id"]), None)
            except ExnError:
                return                                                             # không kiểm tra được thì thôi (đối soát sẽ bắt lệch)
            gone = cur is None
            if not gone:
                break
            time.sleep(0.4)                                                        # có thể snapshot chưa kịp cập nhật
        if gone or (closed and closed > take * 1.001 + 1e-9):
            old = self.c.close_style
            self.c.close_style = "query" if old == "body" else "body"
            raise ExnError("Yêu cầu đóng MỘT PHẦN %.8g/%.8g %s nhưng sàn đã đóng HẾT vị thế: sàn không hiểu volume gửi kiểu '%s' "
                           "(đã đổi sang '%s' cho các lần sau). Kiểm tra vị thế trên sàn rồi chạy `python -m pyea.selfcheck --trade`."
                           % (take, p["volume"], p["symbol"], old, self.c.close_style))

    def close_market(self, symbol, pos_side, qty, ref=None):
        """Đóng `qty` của vị thế phía `pos_side` trên `symbol`. Có `ref` (mã vị thế do vỏ lưu lúc mở): đóng ĐÚNG vị thế đó, nếu nó không còn thì BÁO LỖI chứ
        KHÔNG đóng nhầm vị thế khác. Không có `ref`: cũ nhất trước."""
        todo, total, notional, oids = float(qty), 0.0, 0.0, []
        snap = self._snap_positions()
        if ref:
            cands = [p for p in snap if p["id"] == str(ref)]
            if not cands or cands[0]["symbol"] != symbol or cands[0]["side"] != pos_side:
                raise ExnError("Vị thế sàn #%s (%s %s) không còn trên sàn - có thể vừa bị SL/TP hoặc đóng tay; app KHÔNG đóng vị thế khác thay thế" % (ref, pos_side, symbol))
        else:
            cands = sorted((p for p in snap if p["symbol"] == symbol and p["side"] == pos_side), key=lambda p: p["time"])
        if not cands:
            raise ExnError("Không có vị thế %s %s trên Exness để đóng" % (pos_side, symbol))
        for p in cands:
            if todo <= 1e-12:
                break
            take = min(todo, p["volume"])
            partial = take < p["volume"] - 1e-12
            ack = self._close_call(p["id"], self._volume(symbol, take) if partial else None)
            res = self._await(ack)
            if partial:
                self._verify_partial_close(p, take, res)
            f = self._fill_from(res, symbol, "sell" if pos_side == "buy" else "buy", take)
            if f.order_id:
                oids.append(f.order_id)
            total += min(f.qty, take)
            notional += f.price * min(f.qty, take)
            todo -= take
        if total <= 0:
            raise ExnError("Đóng vị thế Exness không khớp khối lượng nào")
        return Fill(notional / total, total, "", ",".join(oids))

    # ---- lệnh chờ native ----
    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind not in self.native_pending:
            raise ExnError("Exness không hỗ trợ lệnh chờ loại '%s' (có: %s)" % (kind, ", ".join(sorted(self.native_pending))))
        body = {"type": kind, "instrument": symbol, "side": side, "volume": self._volume(symbol, volume), "price": self._price(symbol, price)}
        if sl:
            body["stop_loss_price"] = self._price(symbol, sl)
        if tp:
            body["take_profit_price"] = self._price(symbol, tp)
        before = {o["id"] for o in self._snap_orders()}
        ack = self.c.trade_post("/orders", body)
        res = self._await(ack)
        oid = _dig(res, ("order_id", "orderId"), 3)
        if oid is None:
            for o in self._snap_orders():
                if o["id"] not in before and o["symbol"] == symbol:
                    oid = o["id"]
                    break
        if oid is None:
            oid = _dig(ack, ("order_id", "operation_id"), 2)
        if oid is None:
            raise ExnError("Lệnh chờ đã được nhận nhưng không đọc được mã lệnh - kiểm tra trên sàn")
        return str(oid)

    def cancel_pending(self, native_id, symbol=None):
        ack = self.c.trade_call("DELETE", "/orders/%s" % native_id)
        self._await(ack)
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        """PATCH /orders/{id} (tài liệu: price / stop_loss_price / take_profit_price; bỏ khoá = giữ nguyên, null = gỡ SL/TP)."""
        if symbol is None:
            symbol = next((o["symbol"] for o in self._snap_orders() if o["id"] == str(native_id)), None)
        body = {}
        if price:
            body["price"] = self._price(symbol, price)
        if sl is not None:
            body["stop_loss_price"] = self._price(symbol, sl) if sl else None
        if tp is not None:
            body["take_profit_price"] = self._price(symbol, tp) if tp else None
        if not body:
            return True
        self._await(self.c.trade_call("PATCH", "/orders/%s" % native_id, body=body))
        return True

    def pending_orders(self, known=None):
        return {o["id"]: o for o in self._snap_orders()}

    # ---- SL/TP NATIVE (pyea/protection.py, phong cách "position"): mỗi vị thế một lệnh SLTP trên sàn ----
    def prot_supported(self):
        return True

    def position_levels(self, symbol):
        """Hàm nguyên thuỷ #1: vị thế sàn của mã [{ref, side, qty, sl, tp, owned, sltp_order}]. Sàn không có nhãn (comment) nên `owned=False` và vỏ quyết định
        theo ticket do chính nó mở (protection.ProtectionAPI._row_owned)."""
        d = self.c.snapshot()
        links = {o["ref"]: o for o in self._sltp_orders(d) if o["ref"]}
        rows = []
        for p in self._snap_positions(d):
            if p["symbol"] != symbol:
                continue
            o = links.get(p["id"])
            rows.append({"ref": p["id"], "side": p["side"], "qty": p["volume"], "sl": o["sl"] if o else p["sl"], "tp": o["tp"] if o else p["tp"],
                         "owned": False, "sltp_order": o["id"] if o else "", "symbol": symbol})
        self._lv = {r["ref"]: r for r in rows}
        return rows

    def set_position_levels(self, ref, sl, tp):
        """Hàm nguyên thuỷ #2: đặt SL/TP của MỘT vị thế (0 = bỏ mức). Đã có lệnh SLTP: PATCH (tài liệu: bỏ khoá = giữ, null = gỡ; gỡ cả hai thì DELETE);
        chưa có: tạo lệnh SLTP mới."""
        ref = str(ref)
        row = self._lv.get(ref)
        if row is None:
            self.position_levels(next((p["symbol"] for p in self._snap_positions() if p["id"] == ref), ""))
            row = self._lv.get(ref)
        if row is None:
            raise ExnError("Vị thế #%s không còn trên Exness" % ref)
        sym = row["symbol"]
        oid = row.get("sltp_order") or ""
        if oid:
            if not sl and not tp:
                self._await(self.c.trade_call("DELETE", "/orders/%s" % oid))
                return
            body = {"stop_loss_price": self._price(sym, sl) if sl else None, "take_profit_price": self._price(sym, tp) if tp else None}
            self._await(self.c.trade_call("PATCH", "/orders/%s" % oid, body=body))
            return
        if not sl and not tp:
            return
        self._create_sltp(row, sl, tp)

    @staticmethod
    def _shape_error(e):
        """Lỗi cho thấy THÂN yêu cầu sai dạng (thử dạng khác), khác với lỗi nghiệp vụ (giá sai mức, không đủ quyền, tài khoản đóng...)."""
        name = str(getattr(e, "name", "") or "")
        if name.startswith(("TRADING_RULE", "MARKET_", "ACCOUNT_", "EXECUTION_", "SYSTEM_")) or name == "REQUEST_INVALID_PRICE" or getattr(e, "retryable", False):
            return False
        if "POSITION_NOT_FOUND" in str(e).upper():
            return False
        return getattr(e, "status", 0) in (400, 422) or name == "REQUEST_INVALID"

    def _create_sltp(self, row, sl, tp):
        now = time.time()
        if self._sltp_fail and now < self._sltp_fail[0]:
            raise ExnError(self._sltp_fail[1])
        sym = row["symbol"]
        levels = {}
        if sl:
            levels["stop_loss_price"] = self._price(sym, sl)
        if tp:
            levels["take_profit_price"] = self._price(sym, tp)
        forced = fieldmap.override("request", "sltp_position", SCOPE)          # người dùng/Trợ lý đã chốt tên khoá mã vị thế -> chỉ dùng khoá đó
        shapes = ((forced, False), (forced, True)) if forced else self.SLTP_SHAPES
        order = list(range(len(shapes)))
        pick = getattr(self.c, "sltp_shape", None) if not forced else None
        if pick is not None and pick < len(order):
            order.remove(pick)
            order.insert(0, pick)
        errs = []
        for i in order:
            key, full = shapes[i]
            body = {"type": "sltp", key: row["ref"]}
            if full:
                body.update({"instrument": sym, "side": row["side"], "volume": self._volume(sym, row["qty"])})
            body.update(levels)
            try:
                self._await(self.c.trade_post("/orders", body))
            except ExnError as e:
                if self._shape_error(e):
                    errs.append("%s%s: %s" % (key, "+instrument/side/volume" if full else "", e))
                    continue
                raise
            self.c.sltp_shape = i
            return
        msg = ("Exness từ chối mọi dạng tạo lệnh SLTP đã thử (tài liệu công khai không nêu tên trường mã vị thế): " + " | ".join(errs)
               + " - SL/TP của vị thế vẫn do app canh. Chạy `python -m pyea.selfcheck --trade` để lấy phản hồi thô rồi báo lại tên trường đúng.")
        self._sltp_fail = (time.time() + self.SLTP_RETRY_S, msg)
        raise ExnError(msg)

    def _prot_result(self, ref):
        if any(p["id"] == ref for p in self._snap_positions()):
            return {"state": "canceled"}                                 # vị thế còn nhưng lệnh SLTP không còn (gỡ/sửa tay)
        res = self.position_close(ref, raising=False)
        return res if res is not None else {"state": "unknown"}          # đã mất nhưng lịch sử chưa có deal đóng: hỏi lại vòng sau

    def position_close(self, ref, raising=True):
        """Kết quả đóng của MỘT vị thế từ deal của chính nó (lịch sử /history/.../deals, deal có position_id): {state, price, qty, time, deals} hoặc None."""
        try:
            rows = self.history(time.time() - 3 * 86400)
        except BrokerError:
            if raising:
                raise
            return None
        return close_from_deals([r for r in rows if r.get("position_id") == str(ref)])

    def order_result(self, native_id, symbol=None):
        """None = không biết (engine suy luận từ chênh lệch vị thế)."""
        if str(native_id).startswith(POS_PREFIX):
            return self._prot_result(str(native_id)[len(POS_PREFIX):])
        ev = self.stream.tx.get(native_id)
        if ev:
            st = str(ev.get("status", "")).lower()
            if st in TERMINAL_BAD:
                return {"state": "canceled"}
        return None

    # ---- lịch sử ----
    def history(self, since=0.0, symbols=None):
        """Các lần khớp (deal loại open/close) từ `since`, chuẩn hoá, cũ -> mới. GET /v1/history/accounts/{id}/deals (from/to/limit/cursor).
        `symbols` bị bỏ qua (lịch sử theo cả tài khoản, như OANDA)."""
        try:
            rows = self.c.history_rows("deals", since)
        except ExnError as e:
            if e.status == 404:
                raise ExnError("Exness không có endpoint /v1/history/.../deals ở host này (%s) - chạy `python -m pyea.selfcheck`. "
                               "Sổ lệnh vẫn đồng bộ qua snapshot." % e)
            raise
        return sorted(normalize_deals(rows), key=lambda x: x["time"])

    def account_history(self, since, until=None):
        """Lịch sử ĐẦY ĐỦ (giao dịch + nạp/rút + phí) theo hợp đồng pyea/brokerhist.py. Sàn giới hạn tuổi/độ rộng cửa sổ lịch sử (đọc từ /limits)."""
        return sorted(normalize_history(self.c.history_rows("deals", since, until)), key=lambda x: x["time"])

    def position_stats(self):
        """{ticket: {profit, swap, commission, price}} từ snapshot nếu sàn có báo các trường này (tên trường không có trong tài liệu -> dò bí danh; không thấy thì rỗng)."""
        from .acctstate import normalize_position_stats
        rows = []
        for p in _find_list(self.c.snapshot(), ("positions", "open_positions")):
            pid = str(_fm("position", p, "id") or "")
            if pid:
                rows.append(dict(p, id=pid))
        return normalize_position_stats(rows, SCOPE)

    def account_flags(self):
        """{currency, can_trade}: can_trade=False khi tài khoản trade_mode=trading_disabled / account_status=close_only (tài liệu runtime-semantics)
        hoặc sàn vừa từ chối lệnh vì chỉ-đóng-lệnh/vô hiệu hoá (nhớ 5 phút). Trường nào sàn không trả thì bỏ qua."""
        out = {}
        a = self.c.account()
        cur = _dig(a, ("currency", "account_currency", "base_currency"), 3)
        if isinstance(cur, str) and cur:
            out["currency"] = cur.upper()
        mode = str(_dig(a, ("trade_mode",), 3) or "").lower()
        status = str(_dig(a, ("account_status",), 3) or "").lower()
        if mode or status:
            out["can_trade"] = not (mode == "trading_disabled" or status in ("close_only", "disabled", "blocked"))
            out["trade_mode"], out["account_status"] = mode, status
        if self._block and time.time() - self._block[1] < 300:
            out["can_trade"] = False
            out["blocked_by"] = self._block[0]
        return out


NON_TRADE_DEALS = ("balance", "null_compensation", "admin_fee", "swap_fee", "dividend", "exness_dollar")    # tài liệu: loại deal tài chính


SCOPE = "exness"        # khoá ghi đè tay trong Cài đặt («Ánh xạ trường tuỳ chỉnh»): {"exness": {"deal": {"amount": "..."}}}


def _fm(kind, rec, field, extra=()):
    return fieldmap.pick(kind, rec, field, SCOPE, 0, extra)


def normalize_history(d):
    """Mọi dòng lịch sử deal (kể cả deal tài chính: balance = nạp/rút, swap_fee, admin_fee, dividend...) -> hợp đồng pyea/brokerhist.py.
    Tên loại deal tài chính theo tài liệu (NON_TRADE_DEALS); tên trường theo bảng chung pyea/fieldmap.py (+ ghi đè tay) - không viết riêng cho sàn."""
    out = []
    for r in _find_list(d, ("deals", "orders", "items", "data", "history", "result")):
        fieldmap.remember(SCOPE, "deal", r)
        raw = str(_fm("deal", r, "type") or "").lower()
        sym = _fm("deal", r, "symbol") or ""
        row = {"id": str(_fm("deal", r, "id") or ""), "time": _ts(_fm("deal", r, "time")), "symbol": sym, "side": "", "qty": 0.0, "price": 0.0,
               "entry": "", "position_id": str(_fm("deal", r, "position_id") or ""), "order_id": str(_fm("deal", r, "order_id") or ""), "profit": 0.0,
               "commission": 0.0, "swap": 0.0, "fee": 0.0, "comment": str(_fm("deal", r, "comment") or "")}
        if raw in NON_TRADE_DEALS:
            amount = _num(_fm("deal", r, "amount"), 0)
            if raw == "balance":
                row.update(kind="balance", profit=amount)
            elif raw == "swap_fee":
                row.update(kind="other", swap=amount)                 # phí qua đêm ghi thành deal riêng -> vào «Phí qua đêm»
            elif raw == "admin_fee":
                row.update(kind="other", commission=amount)
            else:
                row.update(kind="other", profit=amount)
        else:
            t = raw if raw in ("open", "close") else ""
            side = _side(_fm("deal", r, "side") or "")
            if not sym or not side:
                continue
            row.update(kind="trade", side=side, qty=_num(_fm("deal", r, "qty"), 0), price=_num(_fm("deal", r, "price"), 0),
                       entry="OUT" if t == "close" else ("IN" if t == "open" else ""), profit=_num(_fm("deal", r, "profit"), 0),
                       commission=_num(_fm("deal", r, "commission"), 0), swap=_num(_fm("deal", r, "swap"), 0), fee=_num(_fm("deal", r, "fee"), 0))
        out.append(row)
    return out


def normalize_deals(d):
    out = []
    for r in _find_list(d, ("deals", "orders", "items", "data", "history", "result")):
        fieldmap.remember(SCOPE, "deal", r)
        sym = _fm("deal", r, "symbol")
        kind = str(_fm("deal", r, "type") or "").lower()
        side = _side(_fm("deal", r, "side") or ("" if kind in ("open", "close") or kind in NON_TRADE_DEALS else kind))
        vol = _num(_fm("deal", r, "qty"), 0)
        if not sym or kind in NON_TRADE_DEALS:
            continue
        out.append({"id": str(_fm("deal", r, "id") or ""), "time": _ts(_fm("deal", r, "time")),
                    "symbol": sym, "side": side, "qty": vol, "price": _num(_fm("deal", r, "price"), 0),
                    "fee": _num(_fm("deal", r, "commission") if _fm("deal", r, "commission") is not None else _fm("deal", r, "fee"), 0), "fee_asset": "",
                    "pnl": _num(_fm("deal", r, "profit"), 0),
                    "order_id": str(_fm("deal", r, "order_id") or _fm("deal", r, "position_id") or ""), "position_id": str(_fm("deal", r, "position_id") or ""),
                    "entry": "OUT" if kind == "close" else ("IN" if kind == "open" else ""), "reason": str(_dig(r, ("reason", "close_reason"), 0) or "").lower()})
    return out


# ---------------------------------------------------------------------------------------------
_CLIENTS = {}
_CLIENTS_LOCK = threading.Lock()


def client_for(settings):
    """Một ExnClient (và stream) cho mỗi tài khoản: feed và broker dùng chung."""
    key = (str(settings.get("exness_account", "")), str(settings.get("exness_api_key", "")), str(settings.get("exness_host", "main")),
           str(settings.get("exness_ws_url", "")),
           __import__("hashlib").sha256(str(settings.get("exness_private_key", "")).encode()).hexdigest()[:16])   # đổi khoá riêng => client mới
    with _CLIENTS_LOCK:
        c = _CLIENTS.get(key)
        if c is None:
            c = _CLIENTS[key] = ExnClient(settings.get("exness_api_key", ""), settings.get("exness_private_key", ""),
                                          settings.get("exness_account", ""), settings.get("exness_host") or "main",
                                          settings.get("exness_ws_url", ""))
        return c


def make_exness_feed(settings):
    return ExnFeed(client_for(settings))


def make_exness_broker(settings):
    return ExnBroker(client_for(settings))
