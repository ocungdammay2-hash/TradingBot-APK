"""Lịch sử tab cho nút Back (không phụ thuộc Kivy -> kiểm thử được).
Back = đóng popup trên cùng -> huỷ lệnh đang soạn -> về TAB TRƯỚC ĐÓ -> (hết lịch sử) mới đưa app xuống nền."""


class TabHistory:
    def __init__(self, limit=12):
        self.limit = limit
        self.stack = []
        self.cur = None

    def visit(self, key):
        """Gọi mỗi khi tab hiện tại đổi. Đổi sang chính tab đang ở = bỏ qua."""
        if key is None or key == self.cur:
            return
        if self.cur is not None:
            if self.cur in self.stack:
                self.stack.remove(self.cur)              # tránh vòng lặp A->B->A->B làm lịch sử phình ra
            self.stack.append(self.cur)
            del self.stack[:-self.limit]
        self.cur = key

    def back(self):
        """Tab cần quay về (đã cập nhật cur để lần visit do switch_to gây ra bị bỏ qua); None nếu hết lịch sử."""
        while self.stack:
            k = self.stack.pop()
            if k != self.cur:
                self.cur = k
                return k
        return None
