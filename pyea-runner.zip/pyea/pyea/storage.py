"""Lưu trữ: thư mục bot, cài đặt chung, tham số theo từng bot (JSON)."""
import json
import os
import platform
import re
import shutil
import sys
import threading
import time
import zipfile

from . import logrot, schema
from .keystore import SECRET_SETTING_KEYS
from .settings import clean_settings, default_settings

_HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES_DIR = os.path.join(_HERE, "examples")


class ChatLog:
    """Lịch sử chat dạng JSON-lines, nhiều tiến trình (UI + dịch vụ nền) cùng ghi nối tiếp được."""

    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()
        self._last_id = 0

    def new_id(self):
        with self._lock:
            now = int(time.time() * 1000000)
            self._last_id = max(self._last_id + 1, now)
            return self._last_id

    def append(self, msg):
        line = json.dumps(msg, ensure_ascii=False) + "\n"
        with self._lock:
            with open(self.path, "ab") as f:
                f.write(line.encode("utf-8"))

    def size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def read_from(self, pos):
        """Đọc các tin mới từ byte offset `pos`. Trả về (list, offset_mới)."""
        try:
            with open(self.path, "rb") as f:
                f.seek(0, 2)
                end = f.tell()
                if pos > end:
                    pos = 0                      # file bị xoá/cắt -> đọc lại từ đầu
                f.seek(pos)
                data = f.read()
        except OSError:
            return [], 0
        out, used = [], 0
        for raw in data.splitlines(True):
            if not raw.endswith(b"\n"):
                break                             # dòng chưa ghi xong
            used += len(raw)
            try:
                out.append(json.loads(raw.decode("utf-8")))
            except ValueError:
                pass
        return out, pos + used

    def tail(self, n=40):
        msgs, _ = self.read_from(0)
        return msgs[-n:]

    def clear(self):
        with self._lock:
            try:
                open(self.path, "wb").close()
            except OSError:
                pass


class Store:
    def __init__(self, base_dir):
        self.base = base_dir
        self.bots_dir = os.path.join(base_dir, "bots")
        self.params_dir = os.path.join(base_dir, "params")
        self.logs_dir = os.path.join(base_dir, "logs")
        for d in (self.bots_dir, self.params_dir, self.logs_dir):
            os.makedirs(d, exist_ok=True)
        self.settings_path = os.path.join(base_dir, "settings.json")
        self.trades_csv = os.path.join(base_dir, "trades.csv")
        self.agents_path = os.path.join(base_dir, "agents.json")
        self.chat = ChatLog(os.path.join(base_dir, "chat.jsonl"))
        self.signals_path = os.path.join(base_dir, "ai_signals.jsonl")      # tín hiệu AI đã ghi (airec) - backtest phát lại
        self.state_path = os.path.join(base_dir, "session_state.json")
        self.events_path = os.path.join(base_dir, "events.jsonl")
        self.prefs_path = os.path.join(base_dir, "ui_prefs.json")
        self.crash_path = os.path.join(base_dir, "crash.log")
        self.alerts_path = os.path.join(base_dir, "alerts.json")
        self.exports_dir = os.path.join(base_dir, "exports")
        self.schema_info = schema.migrate(base_dir)          # đóng dấu/nâng định dạng dữ liệu; too_new -> không ghi đè dữ liệu lạ
        self.schema_notes = []

    def maintain(self, trim=True):
        """Bảo trì khi khởi động (xoay vòng/cắt nhật ký). UI gọi trim=True; dịch vụ nền trim=False (UI đang đọc chat/events theo offset)."""
        try:
            return logrot.maintain(self.base, self.logs_dir, trim=trim)
        except Exception:                                    # noqa: BLE001
            return {}

    def _read_stamped(self, path, default):
        """Đọc file dict có dấu `_schema`: bản MỚI hơn app hiểu -> đổi tên .bak (giữ nguyên) và trả `default`; luôn bỏ khoá `_schema`."""
        d = self._read(path, default)
        if isinstance(d, dict):
            n = schema.newer(d)
            if n:
                bak = schema.set_aside(path, n)
                self.schema_notes.append("%s thuộc định dạng v%d mới hơn app -> đã giữ nguyên tại %s, dùng mặc định" % (os.path.basename(path), n, bak))
                return default
            d.pop("_schema", None)
        return d

    # ---- JSON helpers ----
    @staticmethod
    def _read(path, default):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default

    @staticmethod
    def _write(path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    # ---- cài đặt chung ----
    @property
    def secrets(self):
        """SecretBox của thư mục dữ liệu (Android Keystore nếu có, không thì khoá file)."""
        from .keystore import box_for
        return box_for(self.base)

    def load_settings(self):
        raw = self._read_stamped(self.settings_path, default_settings())
        box = self.secrets
        if box.has_plain_secret(raw):                       # dữ liệu cũ còn bản rõ -> mã hoá tại chỗ (một lần)
            try:
                self._write(self.settings_path, schema.stamp(box.seal_settings(raw)))
            except OSError:
                pass
        return clean_settings(box.open_settings(raw))

    def save_settings(self, settings):
        self._write(self.settings_path, schema.stamp(self.secrets.seal_settings(settings)))

    # ---- AI agents / lịch sử chat ----
    def load_agents(self):
        data = self._read(self.agents_path, [])
        if not isinstance(data, list):
            return []
        box = self.secrets
        if any(isinstance(a, dict) and any(isinstance(a.get(k), str) and a.get(k) and not box.is_sealed(a[k])
                                           for k in ("api_key", "key", "token", "secret")) for a in data):
            try:
                self._write(self.agents_path, box.seal_agents(data))
            except OSError:
                pass
        return box.open_agents(data)

    def save_agents(self, agents):
        self._write(self.agents_path, self.secrets.seal_agents(agents))

    def load_prefs(self):
        d = self._read_stamped(self.prefs_path, {})
        return d if isinstance(d, dict) else {}

    def save_prefs(self, prefs):
        self._write(self.prefs_path, schema.stamp(prefs))

    # ---- bot đã gắn vào tài sản ----
    def load_instances(self):
        d = self._read(os.path.join(self.base, "instances.json"), [])
        return d if isinstance(d, list) else []

    def save_instances(self, items):
        self._write(os.path.join(self.base, "instances.json"), items)

    # ---- tham số bot ----
    def _params_path(self, bot_file):
        return os.path.join(self.params_dir, os.path.basename(bot_file) + ".json")

    def load_params(self, bot_file):
        return self._read(self._params_path(bot_file), {})

    def save_params(self, bot_file, params):
        self._write(self._params_path(bot_file), params)

    # ---- bộ tham số có tên (như file .set của MT5) ----
    def _presets_path(self, bot_file):
        d = os.path.join(self.base, "presets")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, os.path.basename(bot_file) + ".json")

    def load_presets(self, bot_file):
        d = self._read(self._presets_path(bot_file), {})
        return d if isinstance(d, dict) else {}

    def save_preset(self, bot_file, name, params):
        d = self.load_presets(bot_file)
        d[name.strip()] = params
        self._write(self._presets_path(bot_file), d)

    def delete_preset(self, bot_file, name):
        d = self.load_presets(bot_file)
        d.pop(name, None)
        self._write(self._presets_path(bot_file), d)

    # ---- sao lưu / khôi phục / chẩn đoán / sao kê ----
    _BACKUP_FILES = ("settings.json", "agents.json", "ui_prefs.json", "alerts.json", "instances.json")
    _BACKUP_DIRS = ("bots", "params", "presets")
    _SECRET_KEYS = ("api_key", "api_secret", "oanda_token", "token", "secret", "key")

    def _mask(self, name, data):
        """Xoá khoá bí mật khỏi settings.json / agents.json trước khi đưa ra ngoài (mặc định)."""
        if name == "settings.json" and isinstance(data, dict):
            return {k: ("" if k in SECRET_SETTING_KEYS else v) for k, v in data.items()}
        if name == "agents.json" and isinstance(data, list):
            return [{k: ("" if k.lower() in self._SECRET_KEYS or "key" in k.lower() or "secret" in k.lower() else v)
                     for k, v in (a.items() if isinstance(a, dict) else [])} for a in data]
        return data

    def _new_export_path(self, prefix):
        os.makedirs(self.exports_dir, exist_ok=True)
        stamp, n = time.strftime("%Y%m%d-%H%M%S"), 0
        while True:                                   # không ghi đè file cùng giây
            path = os.path.join(self.exports_dir, "%s-%s%s.zip" % (prefix, stamp, ("-%d" % n) if n else ""))
            if not os.path.exists(path):
                return path
            n += 1

    def export_backup(self, out_path=None, include_secrets=False):
        """Sao lưu bot + tham số + cài đặt + chỉ báo/layout + cảnh báo giá vào 1 file zip. KHÔNG gồm sổ lệnh/log.
        Mặc định XOÁ API key/secret/token (an toàn khi gửi đi); include_secrets=True để giữ."""
        out_path = out_path or self._new_export_path("pyea-backup")
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
            for n in self._BACKUP_FILES:
                p = os.path.join(self.base, n)
                if not os.path.isfile(p):
                    continue
                if include_secrets:
                    if n == "settings.json":                # bản mã hoá gắn với khoá của MÁY NÀY -> ghi bản rõ (người dùng đã chọn giữ khoá)
                        z.writestr(n, json.dumps(self.secrets.open_settings(self._read(p, {})), ensure_ascii=False, indent=2))
                    elif n == "agents.json":
                        z.writestr(n, json.dumps(self.secrets.open_agents(self._read(p, [])), ensure_ascii=False, indent=2))
                    else:
                        z.write(p, n)
                else:
                    z.writestr(n, json.dumps(self._mask(n, self._read(p, {})), ensure_ascii=False, indent=2))
            for d in self._BACKUP_DIRS:
                root = os.path.join(self.base, d)
                for dp, _, files in os.walk(root):
                    for f in files:
                        full = os.path.join(dp, f)
                        z.write(full, os.path.relpath(full, self.base).replace(os.sep, "/"))
            z.writestr("BACKUP_INFO.txt", "PyEA Runner backup\n%s\nsecrets=%s\nschema=%d\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), include_secrets, schema.CURRENT))
        return out_path

    def import_backup(self, zip_path):
        """Khôi phục từ file zip của export_backup. Chỉ nhận đường dẫn hợp lệ trong danh sách cho phép (chống path traversal);
        khoá bí mật rỗng trong bản sao lưu KHÔNG ghi đè khoá hiện có. -> (số file, danh sách cảnh báo)."""
        count, warns = 0, []
        with zipfile.ZipFile(zip_path) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            if sum(i.file_size for i in infos) > 80 * 1024 * 1024:
                raise ValueError("File sao lưu quá lớn")
            try:
                info = z.read("BACKUP_INFO.txt").decode("utf-8", "replace")
                m = re.search(r"^schema=(\d+)", info, re.M)
                if m and int(m.group(1)) > schema.CURRENT:
                    raise ValueError("Bản sao lưu thuộc định dạng v%s mới hơn app này (v%d) - hãy cập nhật app trước khi khôi phục" % (m.group(1), schema.CURRENT))
            except KeyError:
                pass
            for i in infos:
                name = i.filename.replace("\\", "/")
                parts = name.split("/")
                top_ok = (len(parts) == 1 and name in self._BACKUP_FILES) or (len(parts) >= 2 and parts[0] in self._BACKUP_DIRS)
                if not top_ok or ".." in parts or name.startswith("/") or ":" in parts[0]:
                    if name != "BACKUP_INFO.txt":
                        warns.append("Bỏ qua mục không hợp lệ: %s" % name)
                    continue
                dst = os.path.normpath(os.path.join(self.base, *parts))
                if not dst.startswith(os.path.normpath(self.base) + os.sep):
                    warns.append("Bỏ qua mục ngoài thư mục dữ liệu: %s" % name)
                    continue
                data = z.read(i)
                if name in ("settings.json", "agents.json"):
                    try:
                        new = json.loads(data.decode("utf-8"))
                        old = self._read(dst, {} if name == "settings.json" else [])
                        if name == "settings.json" and isinstance(new, dict) and isinstance(old, dict):
                            for k in SECRET_SETTING_KEYS:
                                if not new.get(k) and old.get(k):
                                    new[k] = old[k]
                        elif name == "agents.json" and isinstance(new, list) and isinstance(old, list):
                            for a in new:
                                prev = next((o for o in self.secrets.open_agents(old) if isinstance(o, dict) and o.get("name") == a.get("name")), None)
                                for k, v in list(a.items()):
                                    if ("key" in k.lower() or "secret" in k.lower()) and not v and prev and prev.get(k):
                                        a[k] = prev[k]
                        data = json.dumps(new, ensure_ascii=False, indent=2).encode("utf-8")
                    except (ValueError, UnicodeDecodeError):
                        warns.append("%s hỏng - bỏ qua" % name)
                        continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, "wb") as f:
                    f.write(data)
                count += 1
        return count, warns

    def export_diagnostics(self, extra_text=""):
        """Gói chẩn đoán để gửi cho người hỗ trợ/AI: log gần nhất, cài đặt (đã xoá khoá), lỗi crash, trạng thái - KHÔNG có API key."""
        out = self._new_export_path("pyea-diag")
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for n in ("settings.json", "agents.json", "instances.json", "ui_prefs.json", "alerts.json"):
                p = os.path.join(self.base, n)
                if os.path.isfile(p):
                    z.writestr(n, json.dumps(self._mask(n, self._read(p, {})), ensure_ascii=False, indent=2))
            for n in ("crash.log", "crash.log.old", "service_crash.log", "session_state.json", "trades.csv"):
                p = os.path.join(self.base, n)
                if os.path.isfile(p):
                    with open(p, "rb") as f:
                        f.seek(0, 2)
                        size = f.tell()
                        f.seek(max(0, size - 200_000))
                        z.writestr(n, f.read())
            try:
                for n in sorted(os.listdir(self.logs_dir))[-3:]:
                    with open(os.path.join(self.logs_dir, n), "rb") as f:
                        f.seek(0, 2)
                        size = f.tell()
                        f.seek(max(0, size - 300_000))
                        z.writestr("logs/" + n, f.read())
            except OSError:
                pass
            try:
                from . import bootlog
                bp = bootlog.path()
                if bp and os.path.isfile(bp):
                    with open(bp, "rb") as f:
                        f.seek(0, 2)
                        size = f.tell()
                        f.seek(max(0, size - 60_000))
                        z.writestr("boot.log", f.read())                    # mốc khởi động + ngăn xếp crash gốc (faulthandler): để biết app chết ở đâu
            except Exception:                                               # noqa: BLE001
                pass
            z.writestr("system.txt", "PyEA Runner\n%s\npython %s\n%s\n%s\n" % (
                time.strftime("%Y-%m-%d %H:%M:%S"), sys.version.split()[0], platform.platform(), extra_text))
        return out

    def save_statement(self, trades, summary=None):
        """Ghi sao kê CSV (các lệnh đã đóng + tóm tắt) vào thư mục exports; trả về đường dẫn."""
        from .shell import statement_csv
        os.makedirs(self.exports_dir, exist_ok=True)
        path = os.path.join(self.exports_dir, "pyea-statement-%s.csv" % time.strftime("%Y%m%d-%H%M%S"))
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(statement_csv(trades, summary))
        return path

    def save_report_html(self, html_text, prefix="pyea-report"):
        """Ghi báo cáo HTML (pyea/report.py) vào thư mục exports; trả về đường dẫn."""
        os.makedirs(self.exports_dir, exist_ok=True)
        path = os.path.join(self.exports_dir, "%s-%s.html" % (prefix, time.strftime("%Y%m%d-%H%M%S")))
        with open(path, "w", encoding="utf-8") as f:
            f.write(html_text)
        return path

    # ---- bot ----
    def list_bots(self):
        try:
            names = sorted(n for n in os.listdir(self.bots_dir) if n.lower().endswith(".py"))
        except OSError:
            names = []
        return [os.path.join(self.bots_dir, n) for n in names]

    @staticmethod
    def safe_name(name):
        name = os.path.basename(name or "bot.py")
        stem, ext = os.path.splitext(name)
        stem = re.sub(r"[^\w\-]+", "_", stem, flags=re.UNICODE).strip("_") or "bot"
        return stem + ".py"

    def install_bot_text(self, filename, text):
        """Lưu nội dung file .py vào thư mục bot. Trả về đường dẫn."""
        path = os.path.join(self.bots_dir, self.safe_name(filename))
        if os.path.exists(path):
            from . import botversions
            botversions.snapshot(path, "nap")                     # nạp lại file cùng tên: giữ bản cũ để hoàn tác
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        return path

    def install_bot_file(self, src):
        with open(src, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
        return self.install_bot_text(os.path.basename(src), text)

    def delete_bot(self, path):
        from . import botversions
        botversions.snapshot(path, "xoa")                        # xoá nhầm vẫn khôi phục được từ «Phiên bản»
        try:
            os.remove(path)
        except OSError:
            pass
        try:
            os.remove(self._params_path(path))
        except OSError:
            pass

    def seed_examples(self, overwrite=False):
        """Chép bot mẫu vào thư mục bot (lần đầu chạy, hoặc khi bấm 'Cài lại mẫu')."""
        if not os.path.isdir(EXAMPLES_DIR):
            return
        # Ví dụ lưu dạng *.py.txt trong gói app (python-for-android có thể bỏ file .py gốc);
        # khi chép ra thư mục bot sẽ đổi lại thành *.py
        for n in sorted(os.listdir(EXAMPLES_DIR)):
            if not n.endswith(".py.txt"):
                continue
            dst = os.path.join(self.bots_dir, n[:-4])
            if overwrite or not os.path.exists(dst):
                if os.path.exists(dst):
                    from . import botversions
                    botversions.snapshot(dst, "nap")              # «Cài lại bot mẫu» không làm mất bản bạn đã sửa
                shutil.copyfile(os.path.join(EXAMPLES_DIR, n), dst)

    def template_text(self):
        p = os.path.join(EXAMPLES_DIR, "template_bot.py.txt")
        try:
            with open(p, "r", encoding="utf-8") as f:
                return f.read()
        except OSError:
            return ""


def migrate_defaults(store):
    """Chạy MỘT lần mỗi thư mục dữ liệu. 1.9.17: bản cũ đặt secure_screen="sensitive" mặc định (chặn chụp màn hình ở tab Cài đặt) -> "off".
    Người dùng đã chủ động chọn "always" thì giữ nguyên. Trả True nếu đã đổi."""
    pr = store.load_prefs()
    if pr.get("secure_default_v2"):
        return False
    changed = False
    st = store.load_settings()
    if st.get("secure_screen") == "sensitive":
        st["secure_screen"] = "off"
        store.save_settings(st)
        changed = True
    pr["secure_default_v2"] = True
    store.save_prefs(pr)
    return changed
