"""Giao diện chính (Kivy) kiểu MT5: Thị trường | Giao dịch | Bot | Biểu đồ | Backtest | AI | Cài đặt | Nhật ký."""
import json
import os
import re
import threading
import time
import traceback

from . import bootlog
from collections import OrderedDict

from kivy.app import App
from kivy.base import ExceptionHandler, ExceptionManager
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.gridlayout import GridLayout
from . import bars as barkinds
from . import botversions, market, specs, tickdata
from .storage import migrate_defaults
from . import botdebug
from . import chartorder
from . import drawings
from . import i18n
from .loadprobe import LoadMeter
from .i18n import tr
from .ui_widgets import StyledPopup, mk_input, mk_spinner
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelHeader
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.utils import escape_markup, platform

from . import android_native as native
from . import airec, btanalysis, dnd, fieldmap, histengine
from . import android_utils, diagnostics, explain
from .ai import AGENT_INPUTS, PRESETS, AIHub, default_agent
from .backtest import MODES as BT_MODES
from .backtest import FITNESS_KEY, WORST_NOTE, BacktestResult, intrabar_sensitivity, optimize, run_backtest, run_portfolio, walk_forward
from .codeedit import (check_bot_code, extract_bot_code, make_diff, overwrite_with_backup,
                       save_new_version)
from .controller import LocalController
from .engine import STATUS_TEXT, TradingSession, parse_watchlist
from .feeds import SIM_UNIVERSE, TIMEFRAMES, fetch_history, make_feed, tf_seconds
from .ipc import ServiceClient, ServiceHandle
from . import perms as botperms
from . import prefs
from .loader import build_params, inspect_bot
from .prefs import fmt_time, fmt_vol
from .shell import LOG_WINDOWS, default_stops, deploy_cfg, log_match, portfolio_entries, portfolio_summary
from .sdk import Input
from .settings import API_GROUPS, EXCHANGE_WATCH, GLOBAL_INPUTS, api_keys_for, api_note
from .storage import Store
from . import chart_indicators as chind
from .ui_accounts import AccountsUIMixin
from .ui_assistant import AssistantUIMixin
from .ui_shell import SafetyBar, ShellUIMixin
from .ui_widgets import (AMBER, BG, BG2, BLUE, BUBBLE_DECISION, BUBBLE_USER, DOWN, GREEN, LOG_BOT, LOG_TRACE, MIN_TOUCH, MUTED, PALETTE, PANEL, PANEL2,
                         apply_theme, resolve_theme,
                         RED, TEXT, UP, CandleChart, LineChart, Panel, ParamForm, StatBox, Table,
                         confirm, flabel, fm, fp, gscroll, hexc, mkbtn, mkchip, popup, section, setup_fonts,
                         tf_picker, vbox, vscroll, wlabel)

STATUS_COLOR = {"running": UP, "starting": AMBER, "stopping": AMBER, "stopped": MUTED,
                "idle": MUTED, "error": DOWN}
LOG_COLOR = {"ERROR": DOWN, "WARN": AMBER, "BOT": LOG_BOT, "INFO": TEXT, "TRACE": LOG_TRACE}
MAX_LOG_LINES = 250
MAX_BUBBLES = 60
MODES = ["Chat 1 AI", "Nhóm AI + tôi", "Nhóm AI tự thảo luận"]
SIDE_VN = {"buy": "MUA", "sell": "BÁN"}


def add_text_block(box, text, size=12, color=TEXT, chunk=28):
    """Thêm văn bản dài vào box theo từng cụm dòng (tránh giới hạn texture của Label)."""
    lines = str(text).split("\n")
    for i in range(0, len(lines), chunk):
        box.add_widget(wlabel(escape_markup("\n".join(lines[i:i + chunk])), size, color))


def default_volume(symbol):
    s = symbol.upper()
    if "_" in s or s in ("EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD"):
        return 1000
    if s.endswith("USDT") or s.endswith("USD") and s[:3] in ("BTC", "ETH", "SOL", "BNB", "XRP", "LTC"):
        return 0.01 if s.startswith(("BTC",)) else 0.1
    if s.startswith(("XAU", "XAG")):
        return 0.1
    return 1


def num(text, default=0.0):
    try:
        return float(str(text).strip().replace(",", ".")) if str(text).strip() else default
    except ValueError:
        raise ValueError("'%s' không phải số" % text)




def labeled(title, widget):
    row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
    row.add_widget(flabel(title, 12, MUTED, size_hint_x=0.38))
    widget.size_hint_x = 0.62
    row.add_widget(widget)
    return row


# ============================================================== Biểu đồ dùng chung (Biểu đồ + Backtest)
class ChartPanel(BoxLayout):
    """Chip ẩn/hiện + nút Chỉ báo + biểu đồ nến cảm ứng (kéo/chụm/chạm). Chỉ báo MT5 được lưu theo từng biểu đồ (prefs)."""
    CHIP_H = 42

    def __init__(self, app, key, height=300, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(4), **kw)
        self.app, self.key, self.base_h = app, key, height
        self._events = []
        prefs = app.store.load_prefs().get(key, {})
        self.chip_sv = ScrollView(do_scroll_y=False, size_hint_y=None, height=dp(self.CHIP_H), bar_width=0)
        self.chip_box = BoxLayout(orientation="horizontal", size_hint=(None, 1), spacing=dp(6))
        self.chip_box.bind(minimum_width=self.chip_box.setter("width"))
        self.chip_sv.add_widget(self.chip_box)
        self.add_widget(self.chip_sv)
        self.chart = CandleChart(on_tap=self._tap, on_change=self._save, size_hint_y=None, height=dp(height))
        ch = self.chart
        ch.on_toast = app.toast
        ch.bars = int(prefs.get("bars", CandleChart.DEFAULT_BARS))
        ch.hidden = set(prefs.get("hidden_plots", []))
        ch.show_markers = bool(prefs.get("show_markers", True))
        ch.show_lines = bool(prefs.get("show_lines", True))
        ch.show_grid = bool(prefs.get("show_grid", True))
        ch.indicators = chind.clean_cfgs(prefs.get("indicators"))
        self.kind = prefs.get("bar_kind") if prefs.get("bar_kind") in barkinds.KINDS else "candle"      # Renko/Range/gộp N nến (chỉ để xem)
        self.kind_param = prefs.get("bar_param")
        self.add_widget(ch)
        self.draft_bar = BoxLayout(size_hint_y=None, height=0, spacing=dp(6), opacity=0)
        self.add_widget(self.draft_bar)
        self._bid = self._ask = None
        self._draft_sym = None
        ch.on_draft = self._draft_refresh
        self._draw_sym = None
        ch.on_object = self._object_made
        ch.on_object_tap = self._object_tapped
        self._chip_sig = None
        self._build_chips([])
        self._relayout()

    def _relayout(self):
        ch = self.chart
        ch.height = dp(ch.wanted_height(self.base_h))
        self.height = dp(self.CHIP_H) + ch.height + self.draft_bar.height + dp(8)

    # ---------------------------------------------------------- đặt lệnh trên biểu đồ (như dấu «+» của MT5 mobile)
    def start_draft(self, sym, side="buy"):
        """Hiện đường vào kéo được tại giá thị trường + thanh chip [✕] [BUY…] [SL] [TP] [→]."""
        if self._bid is None or not self._ask:
            self.app.toast("Chưa có giá thị trường cho %s - đợi giá về rồi bấm lại." % sym)
            return False
        self._draft_sym = sym
        price = self._ask if side == "buy" else self._bid
        self.chart.draft = {"side": side, "price": price, "sl": 0.0, "tp": 0.0, "bid": self._bid, "ask": self._ask}
        self._show_bar(True)
        self._draft_refresh()
        self.chart.request_redraw()
        return True

    def cancel_draft(self, *_):
        self.chart.draft = None
        self._draft_sym = None
        self._show_bar(False)
        self.chart.request_redraw()

    def has_draft(self):
        return bool(self.chart.draft)

    def _show_bar(self, on):
        self.draft_bar.height = dp(44) if on else 0
        self.draft_bar.opacity = 1 if on else 0
        if not on:
            self.draft_bar.clear_widgets()
        self._relayout()

    def set_prices(self, bid, ask):
        self._bid, self._ask = bid, ask
        d = self.chart.draft
        if d:
            d["bid"], d["ask"] = bid, ask
            self._draft_refresh()

    def toggle_side(self, *_):
        d = self.chart.draft
        if d:
            d["side"] = "sell" if d["side"] == "buy" else "buy"
            ref = self._ask if d["side"] == "buy" else self._bid
            if d["price"] and ref and abs(d["price"] - ref) <= ref * chartorder.MARKET_TOL * 3:
                d["price"] = ref
            for k in ("sl", "tp"):
                d[k] = 0.0                                   # đổi chiều thì SL/TP cũ vô nghĩa
            self._draft_refresh()
            self.chart.request_redraw()

    def toggle_level(self, name):
        d = self.chart.draft
        if not d:
            return
        if d[name]:
            d[name] = 0.0
        else:
            ref = chartorder.entry_ref(d["side"], d["price"], d["bid"], d["ask"])
            sl, tp = chartorder.default_levels(d["side"], ref, self.chart._pm.span())
            d[name] = sl if name == "sl" else tp
        self._draft_refresh()
        self.chart.request_redraw()

    def send_draft(self, *_):
        d = self.chart.draft
        if not d:
            return
        err = chartorder.validate(d["side"], d["price"], d["sl"], d["tp"], d["bid"], d["ask"])
        if err:
            self.app.toast(err)
            return
        kind, _lbl = chartorder.classify(d["side"], d["price"], d["bid"], d["ask"])
        self.app.chart_order_send(self._draft_sym, d["side"], kind, d["price"], d["sl"], d["tp"], on_done=self.cancel_draft)

    def _draft_refresh(self):
        d = self.chart.draft
        if not d:
            return
        kind, label = chartorder.classify(d["side"], d["price"], d["bid"], d["ask"])
        sig = (label, bool(d["sl"]), bool(d["tp"]))
        if sig == getattr(self, "_bar_sig", None) and self.draft_bar.children:
            return
        self._bar_sig = sig
        bar = self.draft_bar
        bar.clear_widgets()
        bar.add_widget(mkbtn("✕", PANEL2, h=40, size=14, size_hint_x=0.14, on_release=self.cancel_draft))
        bar.add_widget(mkbtn(label, GREEN if d["side"] == "buy" else RED, h=40, size=12, size_hint_x=0.38, on_release=self.toggle_side))
        bar.add_widget(mkbtn("SL ✓" if d["sl"] else "SL", AMBER if d["sl"] else PANEL2, h=40, size=12, size_hint_x=0.17, on_release=lambda *_: self.toggle_level("sl")))
        bar.add_widget(mkbtn("TP ✓" if d["tp"] else "TP", GREEN if d["tp"] else PANEL2, h=40, size=12, size_hint_x=0.17, on_release=lambda *_: self.toggle_level("tp")))
        bar.add_widget(mkbtn("→", BLUE, h=40, size=16, size_hint_x=0.14, on_release=self.send_draft))

    def _tap(self, ev):
        self.app.show_event(ev, self._events)

    # ---------------------------------------------------------- công cụ vẽ + danh sách đối tượng (pyea/drawings.py)
    def set_draw_symbol(self, sym):
        """Nạp đối tượng đã vẽ của mã đang xem (lưu theo mã trong prefs)."""
        if sym == self._draw_sym:
            return
        self._draw_sym = sym
        self.chart.objects = drawings.get(self.app.store.load_prefs(), sym) if sym and sym != "-" else []
        self.chart.set_tool(None)
        self.chart.selected = ""
        self.chart.request_redraw()

    def _save_objects(self):
        if not self._draw_sym:
            return
        try:
            prefs = self.app.store.load_prefs()
            drawings.put(prefs, self._draw_sym, self.chart.objects)
            self.app.store.save_prefs(prefs)
        except (OSError, TypeError, ValueError):
            self.app.toast("Không lưu được đối tượng vẽ (bộ nhớ đầy?)")

    def _object_made(self, kind, pts):
        if kind == "text":
            def ok(txt):
                self._add_object(kind, pts, txt)
            self.app.ask_text("Nội dung chữ", "Ghi chú trên biểu đồ", ok)
            return
        self._add_object(kind, pts)

    def _add_object(self, kind, pts, text=""):
        o = drawings.new_object(kind, pts, text, len(self.chart.objects))
        if o is None:
            self.app.toast("Hai điểm trùng nhau - hãy chạm hai vị trí khác nhau.")
        else:
            self.chart.objects = drawings.add(self.chart.objects, o)
            self._save_objects()
        self.chart.request_redraw()

    def _object_tapped(self, o):
        def drop():
            self.delete_object(o["id"])
        confirm("Đối tượng vẽ", "%s\n\nXoá đối tượng này?" % drawings.describe(o), drop, "Xoá")

    def delete_object(self, oid):
        self.chart.objects = drawings.remove(self.chart.objects, oid)
        if self.chart.selected == oid:
            self.chart.selected = ""
        self._save_objects()
        self.chart.request_redraw()

    def clear_objects(self):
        self.chart.objects = []
        self.chart.selected = ""
        self._save_objects()
        self.chart.request_redraw()

    def set_kind(self, kind, param=None):
        self.kind, self.kind_param = kind, param
        self._save()
        self.app.toast("Kiểu biểu đồ: %s%s%s" % (barkinds.NAMES[kind], " " + str(param) if param else "", "" if kind == "candle" else
                                                  " (chỉ để xem; bot/backtest vẫn dùng nến thời gian)"))

    def kind_menu(self):
        """Chọn kiểu thanh giá: nến thời gian, Renko, Range, hoặc gộp N nến (khung tuỳ chỉnh)."""
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        pop = StyledPopup(title="Kiểu biểu đồ (hiện: %s)" % barkinds.NAMES[self.kind], content=box, size_hint=(0.92, 0.85), auto_dismiss=False)

        def pick(kind, param=None):
            pop.dismiss()
            self.set_kind(kind, param)

        def ask(kind, title):
            pop.dismiss()

            def ok(txt):
                try:
                    v = float(txt.replace(",", "."))
                    if v <= 0:
                        raise ValueError
                except ValueError:
                    self.app.toast("Cần một số dương.")
                    return
                self.set_kind(kind, int(v) if kind == "agg" else v)
            self.app.ask_text(title, "số", ok)
        rows = [("Nến thời gian (mặc định)", lambda: pick("candle")),
                ("Renko - gạch = 1 ATR(14) tự động", lambda: pick("renko")),
                ("Renko - nhập cỡ gạch (đơn vị giá)", lambda: ask("renko", "Cỡ gạch Renko")),
                ("Range - biên độ = 0.5 ATR(14) tự động", lambda: pick("range")),
                ("Range - nhập biên độ (đơn vị giá)", lambda: ask("range", "Biên độ Range")),
                ("Gộp 2 nến", lambda: pick("agg", 2)), ("Gộp 3 nến", lambda: pick("agg", 3)),
                ("Gộp 5 nến", lambda: pick("agg", 5)), ("Gộp 10 nến", lambda: pick("agg", 10)),
                ("Gộp N nến (nhập)", lambda: ask("agg", "Gộp bao nhiêu nến thành 1?"))]
        for text, fn in rows:
            box.add_widget(mkbtn(text, PANEL2, h=42, size=13, on_release=lambda *_, f=fn: f()))
        box.add_widget(mkbtn("Đóng", BLUE, h=42, size=13, on_release=lambda *_: pop.dismiss()))
        pop.open()

    def draw_menu(self):
        """Hộp chọn công cụ vẽ (như thanh công cụ MT5) + Danh sách đối tượng."""
        if not self._draw_sym or self._draw_sym == "-":
            self.app.toast("Chọn mã trước.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box.add_widget(wlabel("Chọn công cụ rồi chạm lên biểu đồ (%d điểm cho mỗi hình). Chạm vào một đường đã vẽ để xoá. "
                              "Đối tượng chỉ để vẽ/ghi chú, không tự đặt lệnh." % 2, 11, MUTED))
        pop = StyledPopup(title="Công cụ vẽ - %s" % self._draw_sym, content=box, size_hint=(0.92, 0.8), auto_dismiss=False)

        def pick(kind):
            pop.dismiss()
            self.chart.set_tool(kind)
            self.app.toast("%s: chạm %d điểm trên biểu đồ." % (drawings.NAMES[kind], drawings.POINTS[kind]))
        for kind in drawings.KINDS:
            box.add_widget(mkbtn("%s  (%d điểm)" % (drawings.NAMES[kind], drawings.POINTS[kind]), PANEL2, h=44, size=13,
                                 on_release=lambda *_, k=kind: pick(k)))
        box.add_widget(mkbtn("Danh sách đối tượng (%d)" % len(self.chart.objects), BLUE, h=44, size=13,
                             on_release=lambda *_: (pop.dismiss(), self.objects_dialog())))
        box.add_widget(mkbtn("Đóng", PANEL2, h=44, size=13, on_release=lambda *_: pop.dismiss()))
        pop.open()

    def objects_dialog(self):
        """Danh sách đối tượng (Object List của MT5): mỗi dòng một nút xoá."""
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Danh sách đối tượng - %s" % self._draw_sym, content=box, size_hint=(0.95, 0.85), auto_dismiss=False)

        def fill():
            body.clear_widgets()
            if not self.chart.objects:
                body.add_widget(wlabel(drawings.list_text([]), 12, MUTED))
            for o in self.chart.objects:
                row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
                row.add_widget(wlabel(drawings.describe(o), 12, TEXT))
                row.add_widget(mkbtn("Xoá", RED, h=40, size=12, size_hint_x=0.25, on_release=lambda *_, i=o["id"]: (self.delete_object(i), fill())))
                body.add_widget(row)
        fill()
        box.add_widget(vscroll(body))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Xoá tất cả", RED, on_release=lambda *_: (self.clear_objects(), fill())))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        box.add_widget(row)
        pop.open()

    def _save(self):
        ch = self.chart
        prefs = self.app.store.load_prefs()
        prefs[self.key] = {"bars": ch.bars, "hidden_plots": sorted(ch.hidden), "show_markers": ch.show_markers,
                           "show_lines": ch.show_lines, "show_grid": ch.show_grid, "indicators": ch.indicators,
                           "bar_kind": self.kind, "bar_param": self.kind_param}
        try:
            self.app.store.save_prefs(prefs)
        except (OSError, TypeError, ValueError):
            pass

    def _flag(self, attr):
        def cb(active):
            setattr(self.chart, attr, active)
            self._save()
            self.chart.redraw()
        return cb

    def _plot_toggle(self, name):
        def cb(active):
            (self.chart.hidden.discard if active else self.chart.hidden.add)(name)
            self._save()
            self.chart.redraw()
        return cb

    def _ind_toggle(self, cfg):
        def cb(active):
            cfg["visible"] = active
            self._relayout()
            self._save()
            self.chart.redraw()
        return cb

    def _build_chips(self, names):
        ch = self.chart
        sig = (tuple(names), tuple((c["uid"], c.get("visible", True), chind.describe(c)) for c in ch.indicators))
        if sig == self._chip_sig:
            return
        self._chip_sig = sig
        self.chip_box.clear_widgets()
        b = mkbtn("+ Chỉ báo", BLUE, h=36, size=12, on_release=self.open_manager)
        b.size_hint_x = None
        b.width = dp(96)
        self.chip_box.add_widget(b)
        self.chip_box.add_widget(mkchip("Điểm vào/ra", AMBER, ch.show_markers, self._flag("show_markers")))
        self.chip_box.add_widget(mkchip("Lệnh mở", AMBER, ch.show_lines, self._flag("show_lines")))
        self.chip_box.add_widget(mkchip("Lưới", AMBER, ch.show_grid, self._flag("show_grid")))
        for cfg in ch.indicators:
            col = chind.PALETTE8[chind.base_color_index(cfg)]
            self.chip_box.add_widget(mkchip("ƒ " + chind.describe(cfg), col, cfg.get("visible", True), self._ind_toggle(cfg)))
        for i, n in enumerate(names):
            self.chip_box.add_widget(mkchip("■ " + n, PALETTE[i % len(PALETTE)], n not in ch.hidden, self._plot_toggle(n)))

    # ---------------------------------------------------------- quản lý chỉ báo (như Insert → Indicators của MT5)
    def apply_indicators(self):
        self.chart.set_indicators(self.chart.indicators)
        self._relayout()
        self._chip_sig = None
        self._build_chips(list(self.chart.plots))
        self._save()

    def open_manager(self, *_):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Chỉ báo trên biểu đồ", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)
        box.add_widget(vscroll(body))
        box.add_widget(mkbtn("Xong", BLUE, on_release=lambda *_: pop.dismiss()))

        def tpl_view():
            ch = self.chart
            return {"bars": ch.bars, "show_markers": ch.show_markers, "show_lines": ch.show_lines, "show_grid": ch.show_grid,
                    "indicators": ch.indicators}

        def tpl_save(name):
            prefs = self.app.store.load_prefs()
            try:
                n = chind.save_template(prefs, name, tpl_view())
                self.app.store.save_prefs(prefs)
            except (ValueError, OSError, TypeError) as e:
                popup("Không lưu được mẫu", str(e), size=(0.9, 0.4), color=DOWN)
                return
            self.app.toast("Đã lưu mẫu «%s» (%d chỉ báo)" % (n, len(self.chart.indicators)))
            rebuild()

        def tpl_apply(name):
            tpl = chind.templates(self.app.store.load_prefs()).get(name)
            if tpl is None:
                return
            ch, f = self.chart, chind.fresh(tpl)
            ch.bars, ch.show_markers, ch.show_lines, ch.show_grid = f["bars"], f["show_markers"], f["show_lines"], f["show_grid"]
            ch.indicators = f["indicators"]
            self.apply_indicators()
            ch.redraw()
            self.app.toast("Đã áp mẫu «%s»" % name)
            rebuild()

        def tpl_delete(name):
            prefs = self.app.store.load_prefs()
            if chind.delete_template(prefs, name):
                self.app.store.save_prefs(prefs)
            rebuild()

        def rebuild():
            body.clear_widgets()
            tpls = chind.templates(self.app.store.load_prefs())
            body.add_widget(section("MẪU BIỂU ĐỒ (%d)" % len(tpls)))
            if tpls:
                sp = mk_spinner(next(iter(tpls)), list(tpls))
                trow = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
                trow.add_widget(sp)
                trow.add_widget(mkbtn("Áp", GREEN, h=MIN_TOUCH, size=12, size_hint_x=0.2, on_release=lambda *_: tpl_apply(sp.text)))
                trow.add_widget(mkbtn("Xoá", RED, h=MIN_TOUCH, size=12, size_hint_x=0.2, on_release=lambda *_: tpl_delete(sp.text)))
                body.add_widget(trow)
            nrow = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
            tname = mk_input("", "tên mẫu (vd Xu hướng)")
            nrow.add_widget(tname)
            nrow.add_widget(mkbtn("Lưu mẫu", BLUE, h=MIN_TOUCH, size=12, size_hint_x=0.3, on_release=lambda *_: tpl_save(tname.text)))
            body.add_widget(nrow)
            inds = self.chart.indicators
            body.add_widget(section("ĐANG DÙNG (%d)" % len(inds)))
            if not inds:
                body.add_widget(wlabel("Chưa có chỉ báo. Chọn bên dưới để thêm; chạm chip 'ƒ ...' trên biểu đồ để ẩn/hiện nhanh.", 12, MUTED))
            for cfg in list(inds):
                row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
                row.add_widget(flabel(escape_markup(chind.title(cfg)), 11, TEXT, size_hint_x=0.46, shorten=True, shorten_from="right"))
                row.add_widget(mkbtn("Sửa", PANEL2, h=MIN_TOUCH, size=12, size_hint_x=0.18,
                                     on_release=lambda *_, c=cfg: self.edit_indicator(c, False, rebuild)))
                row.add_widget(mkbtn("Xoá", RED, h=MIN_TOUCH, size=12, size_hint_x=0.18,
                                     on_release=lambda *_, c=cfg: (self.chart.indicators.remove(c), self.apply_indicators(), rebuild())))
                body.add_widget(row)
            body.add_widget(section("THÊM CHỈ BÁO (như MT5)"))
            for g in chind.GROUPS:
                items = [i for i in chind.INDICATORS.values() if i.group == g]
                if not items:
                    continue
                body.add_widget(flabel(g, 12, MUTED, bold=True, size_hint_y=None, height=dp(28)))
                grid = GridLayout(cols=2, size_hint_y=None, spacing=dp(4), row_default_height=dp(MIN_TOUCH), row_force_default=True)
                grid.bind(minimum_height=grid.setter("height"))
                for ind in items:
                    grid.add_widget(mkbtn(ind.name, PANEL2, h=MIN_TOUCH, size=11,
                                          on_release=lambda *_, k=ind.key: self.add_indicator(k, rebuild)))
                body.add_widget(grid)
        rebuild()
        pop.open()

    def add_indicator(self, key, after):
        cfg = chind.new_cfg(key, len(self.chart.indicators))
        if len(chind.INDICATORS[key].inputs) <= 1:          # chỉ có ô Màu -> thêm luôn
            self.chart.indicators.append(cfg)
            self.apply_indicators()
            after()
        else:
            self.edit_indicator(cfg, True, after)

    def edit_indicator(self, cfg, is_new, after):
        ind = chind.INDICATORS[cfg["key"]]
        form = ParamForm(ind.inputs, cfg["params"])
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        if ind.desc:
            box.add_widget(wlabel(ind.desc, 11, MUTED))
        box.add_widget(vscroll(form))
        pop = StyledPopup(title=ind.name, content=box, size_hint=(0.95, 0.85), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def save(*_):
            vals, errs = form.read()
            if errs:
                popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
                return
            cfg["params"] = vals
            if is_new:
                self.chart.indicators.append(cfg)
            self.apply_indicators()
            pop.dismiss()
            after()
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Mặc định", PANEL2, on_release=lambda *_: form.reset()))
        row.add_widget(mkbtn("Thêm" if is_new else "Lưu", GREEN, on_release=save))
        box.add_widget(row)
        pop.open()

    def update(self, candles, plots, events, hlines=None):
        self._events = events
        if self.kind != "candle" and candles:
            try:
                step = tf_seconds(self.app.chart_tf)
            except Exception:                                  # noqa: BLE001 - khung lạ: để thanh giá tự đặt khoảng cách thời gian
                step = 0
            candles = barkinds.transform(candles, self.kind, self.kind_param, step)
            plots = {}                                         # đường vẽ của bot gắn theo nến thời gian, không khớp thanh Renko/Range/gộp
        self._build_chips(list(plots))
        self.chart.update(candles, plots, events, hlines or [])



# ============================================================== Tab: Thị trường (Market Watch)
class MarketTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(8), spacing=dp(6), **kw)
        self.app = app
        self.stat = Panel(orientation="vertical", size_hint_y=None, height=dp(62), padding=dp(8))
        self.st_label = flabel("Chưa kết nối", 16, MUTED, bold=True)
        self.st_info = flabel("", 11, MUTED)
        self.stat.add_widget(self.st_label)
        self.stat.add_widget(self.st_info)
        self.add_widget(self.stat)
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        self.conn_btn = mkbtn("KẾT NỐI", GREEN, on_release=lambda *_: app.toggle_session())
        r.add_widget(self.conn_btn)
        r.add_widget(mkbtn("Thêm mã", PANEL2, on_release=lambda *_: app.add_symbol_dialog()))
        r.add_widget(mkbtn("Lệnh mới", BLUE, on_release=lambda *_: app.open_order_dialog()))
        self.add_widget(r)
        self.add_widget(flabel("KẾT NỐI chỉ lấy giá + biểu đồ + đặt lệnh tay; bot KHÔNG tự chạy (chạy ở tab Bot)", 11, MUTED, size_hint_y=None, height=dp(20)))
        self.box = vbox(spacing=dp(4))
        self.add_widget(vscroll(self.box))
        self.rows, self._sig, self._base = {}, None, {}

    def update(self, snap):
        s = self.app.settings
        alive = self.app.is_connected()
        txt = (snap or {}).get("status_text", "Chưa kết nối") if alive else "Chưa kết nối"
        self.st_label.text = txt
        self.st_label.color = STATUS_COLOR.get((snap or {}).get("status", "idle"), MUTED) if alive else MUTED
        h = ((snap or {}).get("health") or {}) if alive else {}
        hs = {"connected": "giá OK", "degraded": "MỘT SỐ MÃ MẤT GIÁ", "disconnected": "MẤT KẾT NỐI GIÁ"}.get(h.get("state"), "")
        self.st_info.text = "%s · %s%s%s" % (s["exchange"], s["mode"].upper(), " · TESTNET/DEMO" if s["testnet"] and s["mode"] == "live" else "",
                                             (" · " + hs) if hs else "")
        fx = self.app.feed_exchange()
        if fx == "simulated":
            self.st_info.text += " · GIÁ GIẢ LẬP (không phải thị trường thật)"
        self.st_info.color = DOWN if h.get("state") in ("degraded", "disconnected") else (AMBER if fx == "simulated" else MUTED)
        self.conn_btn.text = "NGẮT KẾT NỐI" if alive else "KẾT NỐI"
        watch = parse_watchlist(s["watchlist"])
        if tuple(watch) != self._sig:
            self._sig = tuple(watch)
            self.box.clear_widgets()
            self.rows = {}
            for sym in watch:
                b = mkbtn(sym, PANEL, h=56, size=14, on_release=lambda *_, x=sym: self.app.symbol_menu(x), markup=True)
                b.halign = "left"
                b.bind(size=lambda w, sz: setattr(w, "text_size", (sz[0] - dp(14), sz[1])))
                self.rows[sym] = b
                self.box.add_widget(b)
        ticks = (snap or {}).get("watch", {}) if alive else {}
        for sym, b in self.rows.items():
            t = ticks.get(sym)
            if t is None:
                b.text = "[b]%s[/b]   [color=%s]-[/color]" % (escape_markup(sym), hexc(MUTED))
                continue
            base = self._base.setdefault(sym, t["bid"])
            chg = (t["bid"] / base - 1.0) * 100.0 if base else 0.0
            col = UP if chg >= 0 else DOWN
            b.text = "[b]%s[/b]    %s / %s    [color=%s]%+.2f%%[/color]" % (escape_markup(sym), fp(t["bid"]), fp(t["ask"]), hexc(col), chg)


# ============================================================== Tab: Giao dịch (vị thế + lệnh thủ công)
class TradeTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", **kw)
        self.app = app
        c = vbox(padding=dp(6), spacing=dp(6))
        self.bar = SafetyBar(app)
        c.add_widget(self.bar)
        grid = GridLayout(cols=2, size_hint_y=None, height=dp(4 * 58 + 3 * 6), spacing=dp(6))
        self.s = {}
        # 6 ô đầu giống khung «Giao dịch» của MT5; có số do SÀN báo thì hiện số của sàn (nhãn «SÀN»), không thì sổ tự tính của app (nhãn «sổ app»)
        for key, title in (("balance", "Số dư"), ("equity", "Tài sản (Equity)"), ("floating", "Lãi/lỗ thả nổi"), ("margin", "Ký quỹ"),
                           ("free", "Ký quỹ còn dư"), ("level", "Mức ký quỹ"),
                           ("pnl", "Tổng lãi/lỗ (sổ app)"), ("winrate", "Thắng / số lệnh (sổ app)")):
            self.s[key] = StatBox(title, size_hint_y=None, height=dp(58))
            grid.add_widget(self.s[key])
        c.add_widget(grid)
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r.add_widget(mkbtn("Lệnh mới", BLUE, on_release=lambda *_: app.open_order_dialog()))
        r.add_widget(mkbtn("Đóng tất cả", RED, on_release=app.close_all_positions))
        c.add_widget(r)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Lịch sử & báo cáo", PANEL2, on_release=app.open_history_dialog))
        r2.add_widget(mkbtn("Cảnh báo giá", PANEL2, on_release=app.open_alerts_dialog))
        r2.add_widget(mkbtn("Trợ lý", GREEN, on_release=app.open_assistant_dialog))
        c.add_widget(r2)
        c.add_widget(section("VỊ THẾ ĐANG MỞ (mọi tài sản)"))
        self.pos_box = vbox(spacing=dp(6))
        c.add_widget(self.pos_box)
        c.add_widget(section("LỆNH CHỜ (limit / stop / stop-limit)"))
        self.pend_box = vbox(spacing=dp(6))
        c.add_widget(self.pend_box)
        self._prows = {}
        c.add_widget(section("LỊCH SỬ LỆNH (40 gần nhất)"))
        c.add_widget(mkbtn("Xem lịch sử CHI TIẾT kiểu MT5 (Vị thế / Lệnh / Giao dịch · lọc kỳ, mã, chiều, kết quả)", BLUE, h=46, size=12,
                           on_release=app.open_history_dialog))
        self.tr_table = Table(["Mã", "Loại", "KL", "Vào", "Ra", "P/L", "Nguồn"], [1.2, 0.7, 0.9, 1.1, 1.1, 1.0, 1.1])
        c.add_widget(self.tr_table)
        self._rows, self._tr_sig = {}, None
        self.add_widget(vscroll(c))

    def _make_row(self, p):
        row = Panel(orientation="vertical", size_hint_y=None, height=dp(98), padding=dp(6), spacing=dp(2))
        l1 = flabel("", 13, TEXT, bold=True, size_hint_y=None, height=dp(22))
        l2 = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        btns = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        pl = flabel("", 15, TEXT, bold=True)
        btns.add_widget(pl)
        btns.add_widget(mkbtn("Sửa", PANEL2, h=40, size=12, size_hint_x=0.32, on_release=lambda *_, i=p.id: self.app.open_modify_dialog(i)))
        btns.add_widget(mkbtn("Đóng", RED, h=40, size=12, size_hint_x=0.32, on_release=lambda *_, i=p.id: self.app.close_one(i)))
        for w in (l1, l2, btns):
            row.add_widget(w)
        return row, l1, l2, pl

    def _make_prow(self, o):
        row = Panel(orientation="vertical", size_hint_y=None, height=dp(98), padding=dp(6), spacing=dp(2))
        l1 = flabel("", 13, TEXT, bold=True, size_hint_y=None, height=dp(22))
        l2 = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        btns = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        btns.add_widget(flabel("", 12, MUTED))
        btns.add_widget(mkbtn("Sửa", PANEL2, h=40, size=12, size_hint_x=0.32, on_release=lambda *_, i=o.id: self.app.open_pending_dialog(i)))
        btns.add_widget(mkbtn("Huỷ", RED, h=40, size=12, size_hint_x=0.32, on_release=lambda *_, i=o.id: self.app.cancel_pending(i)))
        for w in (l1, l2, btns):
            row.add_widget(w)
        return row, l1, l2

    def _account_boxes(self, snap):
        """Sáu ô như khung «Giao dịch» của MT5. Số của SÀN (broker_account) nếu có và còn mới; thiếu thì dùng sổ tự tính và NÓI RÕ nhãn."""
        s, ba = self.s, snap.get("broker_account")
        if ba:
            cur = ba.get("currency") or ""
            tag = "SÀN%s" % ((", " + cur) if cur else "")
            lvl = ba.get("margin_level")
            vals = {"balance": ba.get("balance"), "equity": ba.get("equity"), "floating": ba.get("profit"), "margin": ba.get("margin"),
                    "free": ba.get("free_margin"), "level": lvl}
        else:
            tag = "sổ app"
            lvl = snap.get("margin_level")
            vals = {"balance": snap["balance"], "equity": snap["equity"], "floating": snap["floating"], "margin": snap["margin"],
                    "free": snap.get("free_margin"), "level": lvl}
        names = {"balance": "Số dư", "equity": "Tài sản", "floating": "Lãi/lỗ thả nổi", "margin": "Ký quỹ", "free": "Ký quỹ còn dư", "level": "Mức ký quỹ (%)"}
        for k, title in names.items():
            s[k].t.text = "%s (%s)" % (title, tag)
            v = vals[k]
            if v is None or (k == "level" and not v):
                s[k].set("-")                                        # sàn không báo / chưa có ký quỹ: KHÔNG bịa số
            elif k == "floating":
                s[k].set(fm(v), UP if v >= 0 else DOWN)
            elif k == "level":
                s[k].set("%.0f%%" % v, DOWN if v < 100 else TEXT)
            else:
                s[k].set(fp(v))

    def update(self, snap):
        self.bar.update(snap)
        if not snap or not snap.get("ready"):
            for k in self.s.values():
                k.set("-")
            return
        pend = snap.get("pending", [])
        pids = [o.id for o in pend]
        if pids != list(self._prows):
            self.pend_box.clear_widgets()
            self._prows = {}
            if not pend:
                self.pend_box.add_widget(wlabel("Không có lệnh chờ nào.", 12, MUTED))
            for o in reversed(pend):
                row, l1, l2 = self._make_prow(o)
                self._prows[o.id] = (l1, l2)
                self.pend_box.add_widget(row)
        for o in pend:
            l1, l2 = self._prows[o.id]
            l1.text = "%s  %s %s %s @ %s%s" % (o.symbol, SIDE_VN.get(o.side, o.side), o.kind, fmt_vol(o.volume, o.symbol), fp(o.price),
                                                  (" (kích hoạt %s)" % fp(o.stop_price)) if o.kind == "stop_limit" else "")
            l2.text = "SL %s · TP %s · %s · %s" % (fp(o.sl) if o.sl else "-", fp(o.tp) if o.tp else "-",
                                                    "thủ công" if o.owner == "manual" else o.owner or "?",
                                                    ("hết hạn %s" % fmt_time("%d/%m %H:%M", o.expiration)) if o.expiration else "đến khi huỷ")
        s = self.s
        self._account_boxes(snap)
        s["pnl"].set("%s (%+.2f%%)" % (fm(snap["pnl"]), snap["pnl_pct"]), UP if snap["pnl"] >= 0 else DOWN)
        s["winrate"].set("%.0f%% / %d" % (snap["win_rate"], snap["n_trades"]) if snap["n_trades"] else "- / 0")
        pos = snap["positions"]
        ids = [p.id for p in pos]
        if ids != list(self._rows):
            self.pos_box.clear_widgets()
            self._rows = {}
            if not pos:
                self.pos_box.add_widget(wlabel("Chưa có lệnh nào đang mở.", 12, MUTED))
            for p in reversed(pos):
                row, l1, l2, pl = self._make_row(p)
                self._rows[p.id] = (l1, l2, pl)
                self.pos_box.add_widget(row)
        bpos = snap.get("broker_positions") or {}
        for p in pos:
            l1, l2, pl = self._rows[p.id]
            bp = bpos.get(p.ref) if p.ref else None                  # số do SÀN tính cho đúng ticket này (contract size, quy đổi tiền, swap, hoa hồng)
            cur = (bp or {}).get("price")
            if cur is None:
                w = (snap.get("watch") or {}).get(p.symbol)
                cur = (w["bid"] if p.side == "buy" else w["ask"]) if w else None
            l1.text = "%s  %s %s @ %s%s" % (p.symbol, SIDE_VN.get(p.side, p.side), fmt_vol(p.volume, p.symbol), fp(p.open_price),
                                            (" → %s" % fp(cur)) if cur else "")
            l2.text = "SL %s · TP %s · %s" % (fp(p.sl) if p.sl else "-", fp(p.tp) if p.tp else "-", "thủ công" if p.owner == "manual" else p.owner or "?")
            if bp and bp.get("profit") is not None:
                extra = [("swap %s" % fm(bp["swap"])) if bp.get("swap") else "", ("hoa hồng %s" % fm(bp["commission"])) if bp.get("commission") else ""]
                l2.text += " · sàn" + "".join(" · " + x for x in extra if x)
                val = bp["profit"]
            else:
                val = p.profit
            pl.text = fm(val)
            pl.color = UP if val >= 0 else DOWN
        sig = (snap["n_trades"], snap["trades"][0].id if snap["trades"] else 0)
        if sig != self._tr_sig:
            self._tr_sig = sig
            rows = []
            for t in snap["trades"]:
                rows.append([t.symbol, (SIDE_VN.get(t.side, t.side), UP if t.side == "buy" else DOWN), fmt_vol(t.volume, t.symbol),
                             fp(t.open_price), fp(t.close_price), (fm(t.profit), UP if t.profit >= 0 else DOWN),
                             "thủ công" if t.owner == "manual" else (t.reason or t.owner)])
            self.tr_table.set_rows(rows)


# ============================================================== Tab: Bot (gắn bot vào tài sản)
class AttachTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", **kw)
        self.app = app
        top = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(6), padding=[dp(6), dp(4)])
        self.run_btn = mkbtn("▶  KẾT NỐI & CHẠY BOT", GREEN, h=48, on_release=lambda *_: app.run_bots_or_connect(), size=14)
        self.stop_btn = mkbtn("■  NGẮT", RED, h=48, on_release=lambda *_: app.stop_session(), size=14)
        top.add_widget(self.run_btn)
        top.add_widget(self.stop_btn)
        self.add_widget(top)
        c = vbox(padding=dp(6), spacing=dp(6))
        hdr = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        hdr.add_widget(section("BOT ĐÃ GẮN VÀO TÀI SẢN"))
        hdr.add_widget(mkbtn("Gắn bot mới", BLUE, h=44, size=12, size_hint_x=0.55, on_release=lambda *_: app.open_attach_dialog()))
        c.add_widget(hdr)
        self.att_box = vbox(spacing=dp(6))
        c.add_widget(self.att_box)
        c.add_widget(section("THƯ VIỆN BOT (file .py)"))
        self.list_box = vbox(spacing=dp(4))
        c.add_widget(self.list_box)
        self.info = Panel(orientation="vertical", size_hint_y=None, height=dp(96), padding=dp(8))
        self.info_text = wlabel("", 12)
        ib = vbox()
        ib.add_widget(self.info_text)
        self.info.add_widget(vscroll(ib))
        c.add_widget(self.info)
        r1 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r1.add_widget(mkbtn("Nạp file .py", BLUE, on_release=app.pick_bot_file))
        r1.add_widget(mkbtn("Sao chép mẫu", PANEL2, on_release=app.copy_template))
        c.add_widget(r1)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Cài lại bot mẫu", PANEL2, on_release=app.reseed))
        r2.add_widget(mkbtn("Xoá file bot", PANEL2, on_release=app.delete_selected))
        c.add_widget(r2)
        c.add_widget(mkbtn("Nhờ AI chuyển bot sang chuẩn tham số", PANEL2, h=40, on_release=app.ai_convert_inputs, size=12))
        c.add_widget(mkbtn("Phiên bản bot (hoàn tác / khôi phục)", PANEL2, h=40, on_release=app.versions_dialog, size=12))
        c.add_widget(mkbtn("Chợ bot (gói có chữ ký)", PANEL2, h=40, on_release=app.market_dialog, size=12))
        c.add_widget(mkbtn("Quyền bot (mạng...)", PANEL2, h=40, on_release=app.bot_perms_dialog, size=12))
        c.add_widget(mkbtn("Thoát ứng dụng", PANEL, h=40, on_release=app.quit_app, size=12))
        self.add_widget(vscroll(c))
        self._att_sig, self._att, self._trace_btn, self._reload_btn = None, {}, {}, {}

    # ---- thư viện ----
    def rebuild_library(self, paths, selected, infos):
        self.list_box.clear_widgets()
        for p in paths:
            info = infos[p]
            title = escape_markup(info.name or info.file) if info.ok else "[color=%s]%s (lỗi)[/color]" % (hexc(DOWN), escape_markup(info.file))
            b = ToggleButton(text="%s\n[size=11sp][color=%s]%s[/color][/size]" % (title, hexc(MUTED), escape_markup(info.file)),
                             markup=True, group="bots", allow_no_selection=False, size_hint_y=None, height=dp(56),
                             halign="left", valign="middle", background_normal="", background_down="",
                             background_color=BLUE if p == selected else PANEL2, color=TEXT, font_size=sp(14),
                             state="down" if p == selected else "normal")
            b.bind(size=lambda w, s: setattr(w, "text_size", (s[0] - dp(16), s[1])))
            b.bind(state=lambda w, st: setattr(w, "background_color", BLUE if st == "down" else PANEL2))
            b.bind(on_release=lambda w, p=p: self.app.select_bot(p))
            self.list_box.add_widget(b)

    def show_info(self, info):
        if info is None:
            self.info_text.text = "Chưa chọn file bot. Hãy nạp file .py hoặc chọn bot mẫu."
        elif not info.ok:
            self.info_text.text = "[color=%s]Không nạp được:\n%s[/color]" % (hexc(DOWN), escape_markup(info.error))
        else:
            warn = ("\n[color=%s]Lưu ý: %s[/color]" % (hexc(AMBER), escape_markup("; ".join(info.warnings)))) if info.warnings else ""
            pn = botperms.describe(info.perms or {})
            permtxt = ("\n[color=%s]Xin quyền: %s[/color]" % (hexc(AMBER), escape_markup("; ".join(pn)))) if pn else ""
            self.info_text.text = "[b]%s[/b]  v%s %s\n%s\nSố tham số: %d%s%s%s" % (
                escape_markup(info.name), escape_markup(info.version), escape_markup(info.author),
                escape_markup(info.description or "(không có mô tả)"), len(info.inputs),
                (" · cần API ≥ %s" % escape_markup(info.api_min)) if info.api_min else "", warn, permtxt)

    # ---- bot đã gắn ----
    def set_running(self, alive):
        stopping = bool(alive and getattr(self.app, "_stop_t", None))
        self.run_btn.text = "▶  CHẠY TẤT CẢ BOT" if alive else "▶  KẾT NỐI & CHẠY BOT"
        self.run_btn.disabled = bool(alive and stopping)
        self.stop_btn.disabled = (not alive) or stopping
        self.stop_btn.text = "ĐANG NGẮT…" if stopping else "■  NGẮT"

    def update(self, snap, alive):
        cfgs = self.app.attach_cfgs
        sig = tuple((c["iid"], c["symbol"], c["tf"]) for c in cfgs)
        if sig != self._att_sig:
            self._att_sig = sig
            self.att_box.clear_widgets()
            self._att, self._trace_btn, self._reload_btn = {}, {}, {}
            if not cfgs:
                self.att_box.add_widget(wlabel("Chưa gắn bot nào. Bấm 'Gắn bot mới' rồi chọn bot + tài sản + khung giờ.", 12, MUTED))
            for c in cfgs:
                row = Panel(orientation="vertical", size_hint_y=None, height=dp(146), padding=dp(6), spacing=dp(2))
                l1 = flabel("", 13, TEXT, bold=True, size_hint_y=None, height=dp(22))
                l2 = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
                l4 = flabel("", 10, MUTED, size_hint_y=None, height=dp(20))
                l3 = flabel("", 11, AMBER, size_hint_y=None, height=dp(20))
                btns = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
                tog = mkbtn("Chạy", GREEN, h=40, size=12, on_release=lambda *_, i=c["iid"]: self.app.toggle_instance(i))
                btns.add_widget(tog)
                btns.add_widget(mkbtn("Tham số", PANEL2, h=40, size=12, on_release=lambda *_, i=c["iid"]: self.app.edit_params_dialog(i)))
                btns.add_widget(mkbtn("Biểu đồ", PANEL2, h=40, size=12, on_release=lambda *_, i=c["iid"]: self.app.show_instance_chart(i)))
                trb = mkbtn("Trace", PANEL2, h=40, size=12, on_release=lambda *_, i=c["iid"]: self.app.toggle_trace(i))
                btns.add_widget(trb)
                self._trace_btn[c["iid"]] = trb
                rlb = mkbtn("Nạp lại", PANEL2, h=40, size=11, on_release=lambda *_, i=c["iid"]: self.app.reload_bot(i))
                btns.add_widget(rlb)
                self._reload_btn[c["iid"]] = rlb
                btns.add_widget(mkbtn("Gỡ", RED, h=40, size=12, on_release=lambda *_, i=c["iid"]: self.app.remove_attachment(i)))
                for w in (l1, l2, l4, l3, btns):
                    row.add_widget(w)
                self._att[c["iid"]] = (l1, l2, l3, tog, l4)
                self.att_box.add_widget(row)
        live = {i["iid"]: i for i in (snap or {}).get("instances", [])} if alive else {}
        for c in cfgs:
            l1, l2, l3, tog, l4 = self._att[c["iid"]]
            i = live.get(c["iid"])
            rlb = self._reload_btn.get(c["iid"])
            if rlb is not None:                                    # file bot trên đĩa mới hơn bản đang chạy -> nổi bật nút Nạp lại
                stale = bool(i and i.get("code_stale"))
                rlb.text = "Nạp lại ●" if stale else "Nạp lại"
                rlb.background_color = AMBER if stale else PANEL2
            trb = self._trace_btn.get(c["iid"])
            if trb is not None:
                t_on = bool(i.get("trace")) if i else bool(c.get("trace"))
                trb.text = "Trace ●" if t_on else "Trace"
                trb.background_color = BLUE if t_on else PANEL2
            name = os.path.basename(c["bot_path"])
            l1.text = "%s  →  %s %s" % (name, c["symbol"], c["tf"])
            if i:
                l2.text = "%s · lệnh mở %d%s · lãi/lỗ %s · %d lệnh đã đóng" % (
                    i["status_text"], i["open"], (" · chờ %d" % i["pending"]) if i.get("pending") else "", fm(i["profit"]), i["trades"])
                m = i.get("metrics") or {}
                cb = (m.get("callbacks") or {}).get("on_tick") or {}
                pf = m.get("profit_factor")
                l4.text = ("Thắng %.0f%% · PF %s · sụt vốn %s · on_tick %.1f/%.0f ms (TB/max) · lỗi %d" % (
                    m.get("win_rate", 0), "-" if pf is None else "%.2f" % pf, fp(m.get("max_drawdown", 0)), cb.get("avg_ms", 0),
                    cb.get("max_ms", 0), m.get("errors", 0))) if m.get("trades") or cb else ""
                l4.color = DOWN if i.get("hung") else MUTED
                l3.text = (i.get("params_msg") or "")[:90] or (("Bot nghĩ: " + i["bot_status"]) if i["bot_status"] else (i["message"][:90] if i["status"] == "error" else ""))
                l2.color = STATUS_COLOR.get(i["status"], MUTED)
                running = i["status"] in ("running", "starting")
                tog.text = tr("Dừng") if running else tr("Chạy")
                tog.background_color = RED if running else GREEN
            else:
                l2.text = "Chưa kết nối (sẽ chạy khi bấm «KẾT NỐI & CHẠY BOT»)" if c.get("auto", True) else "Đang tắt (không tự chạy)"
                l2.color = MUTED
                l3.text = ""
                l4.text = ""
                tog.text = "Tắt" if c.get("auto", True) else "Bật"
                tog.background_color = PANEL2


# ============================================================== Tab: Biểu đồ
class ChartTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", **kw)
        self.app = app
        top = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6), padding=[dp(6), dp(4)])
        self.sym = Spinner(text="-", values=[], font_size=sp(13), background_normal="", background_color=PANEL2, color=TEXT)
        self.tf = tf_picker("1m", size_hint_x=0.45)
        self.sym.bind(text=self._changed)
        self.tf.bind(text=self._changed)
        top.add_widget(self.sym)
        top.add_widget(self.tf)
        self.add_widget(top)
        # Hàng công cụ riêng, 4 nút chia đều: trước đây 6 widget dồn một hàng khiến nút «＋» / «Lệnh mới» bị ép nhỏ gần như không bấm được trên điện thoại.
        tools = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6), padding=[dp(6), dp(0), dp(6), dp(4)])
        tools.add_widget(mkbtn("＋ Đặt lệnh\ntrên biểu đồ", GREEN, h=44, size=11, on_release=self.toggle_draft))
        tools.add_widget(mkbtn("Lệnh mới\n(hộp thoại)", BLUE, h=44, size=11, on_release=lambda *_: app.open_order_dialog(app.chart_sym)))
        tools.add_widget(mkbtn("Vẽ", PANEL2, h=44, size=12, on_release=lambda *_: self.panel.draw_menu()))
        tools.add_widget(mkbtn("Kiểu", PANEL2, h=44, size=12, on_release=lambda *_: self.panel.kind_menu()))
        self.add_widget(tools)
        c = vbox(padding=dp(6), spacing=dp(6))
        self.price = flabel("", 15, TEXT, bold=True, size_hint_y=None, height=dp(28))
        c.add_widget(self.price)
        self.thinking = wlabel("", 12, AMBER)
        c.add_widget(self.thinking)
        self.msg = wlabel("", 12, MUTED)
        c.add_widget(self.msg)
        row2 = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        row2.add_widget(mkbtn("Sổ lệnh (DOM)", PANEL2, h=38, size=12, on_release=lambda *_: self.dom_dialog()))
        row2.add_widget(mkbtn("Thông số mã", PANEL2, h=38, size=12, on_release=lambda *_: self.spec_dialog()))
        row2.add_widget(mkbtn("Lịch sử lệnh", BLUE, h=38, size=12, on_release=lambda *_: app.open_history_dialog()))
        c.add_widget(row2)
        c.add_widget(section("BIỂU ĐỒ - chạm vào chấm ▲ ▼ ● để xem lý do"))
        c.add_widget(wlabel("Kéo ngang = lướt · chụm 2 ngón = thu/phóng · chạm nến = xem giá & chỉ báo · chạm 2 lần = về mặc định · kéo lên/xuống ở CỘT GIÁ (bên phải) = dời khung giá · nút ✚ (góc biểu đồ): bật = kéo để dời tiêu điểm", 10, MUTED))
        self.panel = ChartPanel(app, "chart", 300)
        c.add_widget(self.panel)
        c.add_widget(section("ĐIỂM VÀO / RA GẦN ĐÂY (chạm để xem lý do)"))
        self.ev_box = vbox(spacing=dp(4))
        c.add_widget(self.ev_box)
        c.add_widget(section("LỆNH ĐANG MỞ TRÊN MÃ NÀY"))
        self.pos_table = Table(["#", "Loại", "KL", "Giá vào", "SL", "TP", "P/L"], [0.5, 0.8, 1, 1.3, 1.2, 1.2, 1.1])
        c.add_widget(self.pos_table)
        self.add_widget(gscroll(c, [self.panel.chart]))
        self._ev_sig, self._vals, self._silent = None, None, False

    def _changed(self, *_):
        if not self._silent and self.sym.text not in ("-", ""):
            if self.panel.has_draft():
                self.panel.cancel_draft()                    # đổi mã/khung thì bỏ lệnh đang soạn
            self.app.set_chart(self.sym.text, self.tf.text)

    def _public_feed(self, need):
        """Feed công khai của sàn đang chọn nếu có hàm `need` (depth/symbol_info/agg_trades); None + toast nếu sàn không hỗ trợ."""
        sym = self.app.chart_sym
        if not sym or sym == "-":
            self.app.toast("Chọn mã trước.")
            return None, None
        try:
            feed = make_feed(self.app.settings["exchange"], self.app.settings)
        except Exception as e:                                 # noqa: BLE001 - cấu hình sàn thiếu/sai
            self.app.toast("Không tạo được kết nối dữ liệu: %s" % e)
            return None, None
        if not hasattr(feed, need):
            self.app.toast("Tính năng này hiện chỉ có với Binance Spot/Futures (sàn «%s» chưa hỗ trợ)." % self.app.settings["exchange"])
            return None, None
        return feed, sym

    def dom_dialog(self):
        """Sổ lệnh (Depth of Market) Binance: 10 mức mỗi phía, tự làm mới 3 giây/lần khi đang mở."""
        feed, sym = self._public_feed("depth")
        if feed is None:
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        head = wlabel("Đang tải...", 12, TEXT)
        tbl = Table(["KL mua", "Giá mua", "Giá bán", "KL bán"], [1, 1, 1, 1], row_h=26)
        box.add_widget(head)
        box.add_widget(vscroll(tbl))
        pop = StyledPopup(title="Sổ lệnh %s" % sym, content=box, size_hint=(0.94, 0.8), auto_dismiss=False)
        state = {"open": True, "busy": False}

        @mainthread
        def show(book, err):
            state["busy"] = False
            if not state["open"]:
                return
            if err:
                head.text = "Lỗi tải sổ lệnh: %s" % escape_markup(str(err))
                return
            sm = specs.depth_summary(book, 10)
            if not sm:
                head.text = "Sổ lệnh trống."
                return
            head.text = "Spread %s (%.4f%%) · mất cân bằng %+.2f (>0: bên MUA dày hơn)" % (fp(sm["spread"]), sm["spread_pct"], sm["imbalance"])
            rows = []
            for i in range(10):
                b = sm["bids"][i] if i < len(sm["bids"]) else None
                a = sm["asks"][i] if i < len(sm["asks"]) else None
                rows.append([("%.6g" % b[1], UP) if b else "", (fp(b[0]), UP) if b else "", (fp(a[0]), DOWN) if a else "", ("%.6g" % a[1], DOWN) if a else ""])
            tbl.set_rows(rows)

        def load(*_):
            if state["busy"] or not state["open"]:
                return
            state["busy"] = True

            def work():
                try:
                    show(feed.depth(sym, 20), None)
                except Exception as e:                         # noqa: BLE001 - mạng/sàn lỗi: hiện lên hộp thoại
                    show(None, e)
            threading.Thread(target=work, daemon=True).start()
        ev = Clock.schedule_interval(load, 3.0)

        def close(*_):
            state["open"] = False
            try:
                ev.cancel()
            except Exception:                                  # noqa: BLE001
                pass
            pop.dismiss()
        box.add_widget(mkbtn("Đóng", BLUE, h=44, size=13, on_release=close))
        pop.open()
        load()

    def spec_dialog(self):
        """Thông số mã (tick, bước KL, KL tối thiểu, giá trị lệnh tối thiểu...) - như Symbol Specification của MT5."""
        feed, sym = self._public_feed("symbol_info")
        if feed is None:
            return
        pop = popup("Thông số %s" % sym, "Đang tải...", size=(0.92, 0.6))

        @mainthread
        def show(text):
            pop.dismiss()
            popup("Thông số %s" % sym, text, size=(0.92, 0.6))

        def work():
            try:
                info = specs.parse_symbol_info(feed.symbol_info(sym))
                show(specs.spec_text(info))
            except Exception as e:                             # noqa: BLE001
                show("Không tải được thông số: %s" % e)
        threading.Thread(target=work, daemon=True).start()

    def toggle_draft(self, *_):
        """«＋» như MT5: bật/tắt đường đặt lệnh kéo được ngay trên biểu đồ."""
        if self.panel.has_draft():
            self.panel.cancel_draft()
            return
        if not self.app.is_connected():
            confirm("Chưa kết nối", "Đặt lệnh trên biểu đồ cần phiên đang chạy (để có giá và gửi lệnh). Kết nối ngay theo cài đặt hiện tại "
                    "(chế độ %s, sàn %s)? Sau khi giá về, bấm «＋ Đặt lệnh trên biểu đồ» lại." % (self.app.settings.get("mode"), self.app.settings.get("exchange")),
                    lambda: self.app.start_session(run_bots=False), "Kết nối")
            return
        sym = self.app.chart_sym
        if not sym or sym == "-":
            self.app.toast("Chọn mã trước.")
            return
        self.panel.start_draft(sym)

    def set_choices(self, symbols, sym, tf):
        self._silent = True
        if tuple(symbols) != self._vals:
            self._vals = tuple(symbols)
            self.sym.values = list(symbols)
        if sym and self.sym.text != sym:
            self.sym.text = sym
        if self.tf.text != tf:
            self.tf.text = tf
        self._silent = False

    def update(self, snap, chart, events):
        if chart is None:
            self.msg.text = "Chưa có dữ liệu - hãy KẾT NỐI (tab Bot / Thị trường) và chọn mã." if not self.app.is_connected() \
                else "Đang tải dữ liệu nến cho %s %s ..." % (self.app.chart_sym or "-", self.app.chart_tf)
            self.panel.update([], {}, [], [])
            return
        fx = self.app.feed_exchange()
        sim = (fx == "simulated")
        self.msg.text = "⚠ DỮ LIỆU GIẢ LẬP (sàn «simulated» tự sinh giá ngẫu nhiên, KHÔNG phải giá thị trường thật). Chọn sàn thật ở Cài đặt để xem giá thật." if sim else ""
        if not sim and fx == "public":
            self.msg.text = "Giá tham chiếu công khai (Binance / Yahoo Finance) - có thể lệch giá khớp thật của sàn bạn giao dịch; dùng để xem/paper/backtest."
        self.msg.color = AMBER if sim else MUTED
        sym = chart["symbol"]
        if chart.get("bid") is not None:
            self.price.text = "%s   Bid %s   Ask %s" % (sym, fp(chart["bid"]), fp(chart["ask"]))
        bs = chart.get("bot_status") or {}
        self.thinking.text = "\n".join("Bot %s: %s" % (escape_markup(k), escape_markup(v)) for k, v in bs.items())
        evs = [e for e in events if e.symbol == sym or not e.symbol][-300:]
        pos = chart.get("positions") or []
        hl = []
        for p in pos:
            col = UP if p.side == "buy" else DOWN
            hl.append((p.open_price, col, "%s %s %+.2f" % (p.side.upper(), fmt_vol(p.volume, p.symbol), p.profit)))
            if p.sl:
                hl.append((p.sl, DOWN, "SL #%d" % p.id))
            if p.tp:
                hl.append((p.tp, UP, "TP #%d" % p.id))
        for o in (chart.get("pending") or []):
            hl.append((o.price, AMBER, "%s %s %s" % (o.side.upper(), o.kind.upper().replace("_", "-"), fmt_vol(o.volume, o.symbol))))
        self.panel.set_prices(chart.get("bid"), chart.get("ask"))
        self.panel.set_draw_symbol(sym)
        self.panel.update(chart["candles"], chart["plots"], evs, hl)
        sig = (len(evs), evs[-1].id if evs else 0)
        if sig != self._ev_sig:
            self._ev_sig = sig
            self.ev_box.clear_widgets()
            if not evs:
                self.ev_box.add_widget(wlabel("Chưa có lệnh/tín hiệu nào trên mã này.", 12, MUTED))
            for ev in reversed(evs[-8:]):
                kind = {"open": "VÀO", "close": "RA", "note": "TÍN HIỆU", "pending": "LỆNH CHỜ", "cancel": "HUỶ CHỜ"}.get(ev.kind, ev.kind.upper())
                txt = "%s  %s %s @ %s%s\n%s" % (fmt_time("%H:%M:%S", ev.time), kind, SIDE_VN.get(ev.side, ""),
                                               fp(ev.price), ("  (%+.2f)" % ev.profit) if ev.kind == "close" else "", (ev.reason or "")[:80])
                b = mkbtn(txt, PANEL2, h=52, size=11, on_release=lambda *_, e=ev, ls=evs: self.app.show_event(e, ls))
                b.halign = "left"
                b.bind(size=lambda w, sz: setattr(w, "text_size", (sz[0] - dp(14), sz[1])))
                self.ev_box.add_widget(b)
        self.pos_table.set_rows([[str(p.id), (SIDE_VN.get(p.side, p.side), UP if p.side == "buy" else DOWN), fmt_vol(p.volume, p.symbol),
                                  fp(p.open_price), fp(p.sl) if p.sl else "-", fp(p.tp) if p.tp else "-",
                                  (fm(p.profit), UP if p.profit >= 0 else DOWN)] for p in pos[:15]])
# ============================================================== Tab: Backtest (Strategy Tester)
MAX_OPT = 200                                                        # số lần chạy tối đa của một lượt tối ưu
BT_INPUTS = OrderedDict([
    ("symbol", Input("BTCUSD", "Tài sản (mã)", help="Theo nguồn thị trường đang chọn ở Cài đặt")),
    ("timeframe", Input("5m", "Khung thời gian", choices=list(TIMEFRAMES))),
    ("data_source", Input("Sàn (tự lưu)", "Nguồn dữ liệu", choices=["Sàn (tự lưu)", "File đã nhập"],
                          help="Sàn (tự lưu): tải từ nguồn đang chọn ở Cài đặt, LƯU lại trên máy; lần sau chỉ tải phần còn thiếu nên nhẹ và nhanh hơn nhiều. "
                               "File đã nhập: chỉ dùng dữ liệu bạn nhập từ CSV (không dùng mạng) - nhập ở nút «Dữ liệu nến đã lưu». Nguồn «simulated» (giả) không được lưu")),
    ("bars", Input(3000, "Số nến test", min=300, max=30000, help="Binance/OANDA tải nhiều lần (có phân trang)")),
    ("date_from", Input("", "Từ ngày (YYYY-MM-DD, trống = dùng số nến ở trên)",
                        help="Chọn giai đoạn kiểm thử như MT5: nhập cả «Từ ngày» (và «Đến ngày» nếu muốn). Khi có «Từ ngày» thì «Số nến test» bị bỏ qua; "
                             "nguồn dữ liệu phải đủ xa (khung nhỏ + khoảng dài có thể vượt 30000 nến)")),
    ("date_to", Input("", "Đến ngày (gồm cả ngày đó, trống = mới nhất)")),
    ("speed", Input("Tối đa", "Tốc độ chạy (nến/giây)", choices=["Tối đa", "1000", "300", "100", "30", "10", "3"],
                    help="Như thanh tốc độ của Visual mode ở MT5: chọn số nến mỗi giây để XEM bot chạy từng nến (đường vốn + tiến độ cập nhật liền). "
                         "«Tối đa» chạy nhanh nhất. Có nút «Tạm dừng». Tốc độ không đổi kết quả")),
    ("warmup", Input(100, "Nến khởi động (warm-up)", min=0, max=1000)),
    ("debug", Input("Tắt", "Debug bot", choices=["Tắt", "Chỉ điểm dừng", "Từng dòng"],
                    help="Ghi lại những dòng code bot đã chạy trong on_bar/on_tick (5 lần gọi đầu, tối đa 3000 sự kiện) để xem bot «nghĩ» gì. "
                         "«Chỉ điểm dừng»: chỉ chụp giá trị biến tại các dòng ở ô bên dưới. Không đổi kết quả backtest; chạy chậm hơn một chút. Xem bằng nút «Nhật ký debug»")),
    ("debug_lines", Input("", "Điểm dừng (số dòng, vd 42, 57:rsi < 30)",
                          help="Số dòng trong file bot; thêm «:điều kiện» để chỉ chụp khi điều kiện đúng (viết bằng Python, dùng biến cục bộ của dòng đó, vd self.n == 3)")),
    ("mode", Input("ohlc", "Mô phỏng tick", choices=list(BT_MODES),
                   help="ohlc: 4 tick/nến theo hướng nến · ohlc_hl: luôn O→H→L→C · ohlc_lh: luôn O→L→H→C · ohlc_worst: thứ tự bất lợi cho lệnh đang mở · "
                        "open: chỉ giá mở cửa (nhanh). Nến OHLC không cho biết đỉnh hay đáy đến trước - dùng «So sánh thứ tự giá trong nến» để đo độ nhạy")),
    ("ai_replay", Input(False, "Phát lại tín hiệu AI đã ghi",
                        help="Bot dùng api.ai_signal: bật để phát lại ĐÚNG các tín hiệu đã ghi (chạy nhóm AI trước, rồi backtest cùng giai đoạn). "
                             "Tắt = bot luôn nhận None. Không sinh lại câu trả lời của AI; danh mục nhiều mã chưa hỗ trợ")),
    ("initial_balance", Input(10000.0, "Vốn ban đầu", min=1.0)),
    ("leverage", Input(1.0, "Đòn bẩy", min=1.0, max=125.0)),
    ("spread_pct", Input(0.01, "Spread (% giá)", min=0.0, max=5.0)),
    ("commission_pct", Input(0.1, "Phí mỗi chiều (%)", min=0.0, max=5.0)),
    ("max_loss_pct", Input(0.0, "Dừng nếu lỗ quá (%)", min=0.0, max=100.0, help="0 = chạy hết giai đoạn")),
])
KEY_STATS = (("Lợi nhuận ròng", "money"), ("Profit factor", "x"), ("Sụt vốn tối đa (%)", "pct"), ("Tổng số lệnh", "int"),
             ("Thắng (%)", "pct"), ("Kỳ vọng / lệnh", "money"), ("Sharpe (xấp xỉ)", "x"), ("Recovery factor", "x"))


def fmt_stat(v, kind):
    if v is None:
        return "-"
    if v == float("inf"):
        return "∞"
    return {"money": fm(v), "pct": "%.2f%%" % v, "int": "%d" % v, "x": "%.2f" % v}.get(kind, str(v))


class BacktestTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", **kw)
        self.app = app
        self.res, self.bt_params, self._stop = None, {}, threading.Event()
        self.debug_text = ""
        self._pause = threading.Event()
        self._busy = False
        self._opt_all = []
        self._live_curve, self._live_t = [], 0.0
        c = vbox(padding=dp(6), spacing=dp(6))
        c.add_widget(wlabel("Chạy thử bot trên dữ liệu lịch sử bằng đúng engine giao dịch (SL/TP, phí, ký quỹ). "
                            "Kết quả có biểu đồ với chấm vào/ra - chạm vào để xem lý do.", 11, MUTED))
        self.bot = mk_spinner("-", [])
        c.add_widget(labeled("Bot (EA)", self.bot))
        c.add_widget(mkbtn("Tham số bot", PANEL2, h=40, size=12, on_release=lambda *_: self.edit_params()))
        sv = self.app.store.load_prefs().get("bt_form", {})
        self.form = ParamForm(BT_INPUTS, sv)
        c.add_widget(self.form)
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        self.run_btn = mkbtn("CHẠY BACKTEST", GREEN, on_release=lambda *_: self.run())
        self.pause_btn = mkbtn("Tạm dừng", AMBER, size_hint_x=0.5, size=12, on_release=lambda *_: self.toggle_pause())
        self.stop_btn = mkbtn("Dừng", RED, size_hint_x=0.4, on_release=lambda *_: (self._pause.clear(), self._stop.set()))
        r.add_widget(self.run_btn)
        r.add_widget(self.pause_btn)
        r.add_widget(self.stop_btn)
        c.add_widget(r)
        c.add_widget(mkbtn("Dữ liệu nến đã lưu (xem · nhập/xuất CSV · xoá)", PANEL2, h=40, size=12, on_release=lambda *_: self.data_dialog()))
        c.add_widget(mkbtn("So sánh thứ tự giá trong nến (độ nhạy)", PANEL2, h=40, size=12, on_release=lambda *_: self.sensitivity()))
        c.add_widget(mkbtn("Tối ưu hoá (tới 3 tham số) + so sánh từng tham số + AI", PANEL2, h=40, size=12, on_release=lambda *_: self.optimize_dialog()))
        c.add_widget(mkbtn("Thống kê lời/lỗ lần chạy này (theo lý do · chiều · giờ · thứ) + AI", PANEL2, h=40, size=12, on_release=lambda *_: self.trade_stats_dialog()))
        c.add_widget(mkbtn("Walk-forward (tối ưu IS → kiểm OOS)", PANEL2, h=40, size=12, on_release=lambda *_: self.walk_forward_dialog()))
        c.add_widget(mkbtn("Backtest DANH MỤC (các bot đã gắn, dùng chung vốn)", PANEL2, h=40, size=12, on_release=lambda *_: self.portfolio_dialog()))
        self.prog = flabel("", 12, AMBER, size_hint_y=None, height=dp(24))
        c.add_widget(self.prog)
        c.add_widget(section("KẾT QUẢ"))
        grid = GridLayout(cols=2, size_hint_y=None, height=dp(4 * 58 + 3 * 6), spacing=dp(6))
        self.s = {}
        for k, kind in KEY_STATS:
            self.s[k] = StatBox(k, size_hint_y=None, height=dp(58))
            grid.add_widget(self.s[k])
        c.add_widget(grid)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Báo cáo đầy đủ", BLUE, size=12, on_release=lambda *_: self.full_report()))
        r2.add_widget(mkbtn("Sao chép báo cáo", PANEL2, size=12, on_release=lambda *_: self.copy_report()))
        r2.add_widget(mkbtn("Báo cáo HTML", PANEL2, size=12, on_release=lambda *_: self.save_report_html()))
        r2.add_widget(mkbtn("Nhật ký debug", PANEL2, size=12, on_release=lambda *_: self.debug_dialog()))
        c.add_widget(r2)
        c.add_widget(mkbtn("TRIỂN KHAI bot này (cùng mã, khung, tham số)", AMBER, h=44, size=12,
                           on_release=lambda *_: self.app.deploy_from_backtest(self.res, self.bot_path())))
        c.add_widget(section("BIỂU ĐỒ BACKTEST - chạm vào chấm để xem lý do"))
        self.panel = ChartPanel(app, "bt", 300)
        c.add_widget(self.panel)
        c.add_widget(section("ĐƯỜNG EQUITY"))
        self.eq = LineChart(size_hint_y=None, height=dp(110))
        c.add_widget(self.eq)
        c.add_widget(section("DANH SÁCH LỆNH (40 đầu)"))
        self.tr = Table(["#", "Loại", "KL", "Vào", "Ra", "P/L", "Lý do ra"], [0.5, 0.7, 0.9, 1.1, 1.1, 1.0, 1.1])
        c.add_widget(self.tr)
        self.add_widget(gscroll(c, [self.panel.chart]))

    # ---- chọn bot / tham số ----
    def set_bots(self, paths):
        names = [os.path.basename(p) for p in paths]
        self._paths = dict(zip(names, paths))
        self.bot.values = names
        if names and self.bot.text not in names:
            self.bot.text = "ma_cross.py" if "ma_cross.py" in names else names[0]

    def bot_path(self):
        return getattr(self, "_paths", {}).get(self.bot.text)

    def edit_params(self, then=None):
        path = self.bot_path()
        info = inspect_bot(path) if path else None
        if info is None or not info.ok or not info.inputs:
            self.app.toast("Bot không có tham số (hoặc chưa chọn bot).")
            return
        cur = self.bt_params.get(path) or self.app.store.load_params(path)
        self.app.params_popup("Tham số backtest: " + info.name, info.inputs, build_params(info.inputs, cur), path,
                              lambda v: self.bt_params.__setitem__(path, v))

    def _params(self, path):
        info = inspect_bot(path)
        return build_params(info.inputs, self.bt_params.get(path) or self.app.store.load_params(path)) if info.ok else {}

    # ---- chạy ----
    def _setup(self):
        vals, errs = self.form.read()
        if errs:
            popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
            return None
        path = self.bot_path()
        if not path:
            self.app.toast("Chưa chọn bot.")
            return None
        prefs = self.app.store.load_prefs()
        prefs["bt_form"] = vals
        self.app.store.save_prefs(prefs)
        return vals, path

    @mainthread
    def _progress(self, text):
        self.prog.text = text

    def _ai_replay(self, vals, candles, sym):
        """None = không phát lại; list = bản ghi tín hiệu AI nằm trong khoảng dữ liệu (kèm đoạn TTL phía trước)."""
        if not vals.get("ai_replay"):
            return None
        cs = [c for c in candles if c is not None]
        if not cs:
            return airec.SignalList()
        ttl = float(self.app.settings.get("ai_signal_ttl", 30)) * 60.0
        out = airec.SignalList(airec.load_dir(self.app.store.base, since=cs[0].time - ttl, until=cs[-1].time + 86400.0, symbol=sym))
        from . import aiask
        out.asks = aiask.load_asks(self.app.store.base, since=cs[0].time - 86400.0, until=cs[-1].time + 86400.0)
        return out

    def run(self):
        if self._busy:
            return
        got = self._setup()
        if not got:
            return
        vals, path = got
        st = dict(self.app.settings)
        for k in ("initial_balance", "leverage", "spread_pct", "commission_pct", "max_loss_pct"):
            st[k] = vals[k]
        params = self._params(path)
        self._stop.clear()
        self._busy = True
        self.run_btn.disabled = True

        speed = self._speed(vals)
        self._pause.clear()
        self._live_curve, self._live_t, self._live_init = [], 0.0, float(vals["initial_balance"])

        def work():
            try:
                sym = vals["symbol"].strip().upper()
                candles, warm = self._load(vals, st, lambda a, b: self._progress("Tải dữ liệu %d/%d nến..." % (a, b)))
                self._progress("Đang chạy backtest (%d nến)..." % len(candles))
                dbg = self._make_debugger(vals, path)
                real = self._real_ticks(vals, st, sym, candles, warm) if vals["mode"] == "real" else None
                res = run_backtest(path, params, st, sym, vals["timeframe"], candles, warm, vals["mode"], ticks=real,
                                   progress=lambda a, b: self._progress("Backtest %d/%d nến" % (a, b)), stop_event=self._stop,
                                   ai_signals=self._ai_replay(vals, candles, sym), speed=speed, pause_event=self._pause,
                                   on_step=self._live_step if speed else None, debugger=dbg)
                self.debug_text = dbg.report() if dbg is not None else ""
            except Exception as e:
                res = BacktestResult(ok=False, error="%s" % e)
            self._done(res, vals)
        threading.Thread(target=work, daemon=True).start()

    def _real_ticks(self, vals, st, sym, candles, warm):
        """Tải tick thật (Binance aggTrades) cho đúng khoảng backtest. Sàn khác -> lỗi rõ ràng (không âm thầm dùng OHLC)."""
        feed = make_feed(st["exchange"], st)
        if not hasattr(feed, "agg_trades"):
            raise ValueError("Tick thật chỉ có với Binance Spot/Futures (sàn «%s» không cung cấp aggTrades)." % st["exchange"])
        step = tf_seconds(vals["timeframe"])
        r = tickdata.fetch(feed, sym, candles[warm].time, candles[-1].time + step, progress=lambda a, b: self._progress("Tải tick thật %d/%d..." % (a, b)),
                           stop=self._stop)
        if r["truncated"]:
            self._progress("Đã tải %d tick (đạt giới hạn) - nến còn lại dùng đường OHLC" % len(r["ticks"]))
        return r["ticks"]

    @staticmethod
    def _make_debugger(vals, path):
        """Tracer (pyea/botdebug.py) theo ô «Debug bot»; None khi tắt."""
        mode = vals.get("debug")
        if mode not in ("Chỉ điểm dừng", "Từng dòng"):
            return None
        bp, _warn = botdebug.parse_breakpoints(vals.get("debug_lines"))
        return botdebug.Tracer(path, "lines" if mode == "Từng dòng" else "breakpoints", bp, callbacks=("on_bar", "on_tick"), max_calls=5)

    def debug_dialog(self):
        txt = self.debug_text
        if not txt:
            self.app.toast("Chưa có nhật ký debug - đặt «Debug bot» khác «Tắt» rồi chạy backtest.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(2))
        add_text_block(body, txt, 11, TEXT)
        box.add_widget(vscroll(body))
        pop = StyledPopup(title="Nhật ký debug bot", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: (Clipboard.copy(txt), self.app.toast("Đã sao chép nhật ký debug."))))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        box.add_widget(row)
        pop.open()

    # ---- tải dữ liệu theo số nến HOẶC khoảng ngày; tốc độ; tạm dừng ----
    def _load(self, vals, st, progress=None):
        """(nến, warm-up thực). «Từ ngày» có thì dùng khoảng ngày (cắt theo [từ, đến) + lùi warm-up); không thì lấy `bars` nến mới nhất."""
        sym, tf = vals["symbol"].strip().upper(), vals["timeframe"]
        a, b = btanalysis.date_range(vals.get("date_from"), vals.get("date_to"))
        if a is None:
            if b is not None:
                raise ValueError("Có «Đến ngày» thì cần cả «Từ ngày»")
            return self._candles(vals, st, sym, tf, vals["bars"] + vals["warmup"], None, progress), vals["warmup"]
        n = btanalysis.bars_for_range(a, b, tf_seconds(tf), vals["warmup"])
        cs = self._candles(vals, st, sym, tf, n, b, progress)
        return btanalysis.window(cs, a, b, vals["warmup"])

    def data_dialog(self):
        from .ui_candles import open_data_dialog
        open_data_dialog(self)

    def candle_store(self):
        from .candlestore import CandleStore
        if getattr(self, "_cstore", None) is None:
            self._cstore = CandleStore(os.path.join(self.app.data_dir, "candles"))
        return self._cstore

    def _candles(self, vals, st, sym, tf, n, end, progress=None):
        """Nến cho backtest qua kho nến: «File đã nhập» -> chỉ đọc kho; «Sàn» -> tải phần thiếu rồi lưu (nguồn giả không lưu)."""
        from . import candlestore as cst
        store = self.candle_store()
        if vals.get("data_source") == "File đã nhập":
            out = store.read(cst.FILE_SOURCE, sym, tf, before=end, last=n)
            if not out:
                raise ValueError("Chưa có dữ liệu file cho %s %s. Bấm «Dữ liệu nến đã lưu» → «Nhập CSV» (tên mã phải trùng ô «Tài sản»)." % (sym, tf))
            return out
        feed = make_feed(st["exchange"], st)
        out, _stat = cst.get_candles(store, cst.source_key(st), feed, sym, tf, n, end=end, progress=progress)
        return out

    @staticmethod
    def _speed(vals):
        try:
            return max(0.0, float(vals.get("speed")))
        except (TypeError, ValueError):
            return 0.0                                           # «Tối đa»

    def toggle_pause(self):
        if self._pause.is_set():
            self._pause.clear()
            self.pause_btn.text = "Tạm dừng"
        else:
            self._pause.set()
            self.pause_btn.text = "Tiếp tục"

    def _live_step(self, i, n, c, pt):
        """Gọi mỗi nến khi chạy có tốc độ (luồng nền): gom đường vốn, cập nhật giao diện tối đa ~5 lần/giây."""
        self._live_curve.append(pt[2])
        now = time.time()
        if now - self._live_t >= 0.2 or i == n:
            self._live_t = now
            self._live_ui(i, n, pt, list(self._live_curve[-600:]))

    @mainthread
    def _live_ui(self, i, n, pt, curve):
        self.prog.text = "Chạy %d/%d nến · %s · vốn %s · tài sản %s" % (i, n, fmt_time("%d/%m/%Y %H:%M", pt[0]), fp(pt[1]), fp(pt[2]))
        self.eq.update(curve[::max(1, len(curve) // 280)], self._live_init)

    @mainthread
    def _done(self, res, vals):
        self._busy = False
        self._pause.clear()
        self.pause_btn.text = "Tạm dừng"
        self.run_btn.disabled = False
        self.prog.text = ("Xong." if res.ok else "Lỗi.") + ((" " + res.error) if res.error else "")
        self.prog.color = UP if res.ok and not res.error else (AMBER if res.ok else DOWN)
        for k, kind in KEY_STATS:
            v = res.report.get(k)
            self.s[k].set(fmt_stat(v, kind), (UP if (v or 0) >= 0 else DOWN) if k == "Lợi nhuận ròng" else TEXT)
        self.panel.chart.set_offset(0)
        self.panel.update(res.candles, res.plots, res.events, [])
        step = max(1, len(res.curve) // 280)
        self.eq.update([e for _, _, e in res.curve][::step], vals["initial_balance"])
        self.tr.set_rows([[str(t.id), (SIDE_VN.get(t.side, t.side), UP if t.side == "buy" else DOWN), fmt_vol(t.volume, t.symbol),
                           fp(t.open_price), fp(t.close_price), (fm(t.profit), UP if t.profit >= 0 else DOWN), t.reason]
                          for t in res.trades[:40]])
        self.res = res                    # gán SAU CÙNG: ai đọc `res` thì giao diện đã cập nhật xong
        if not res.ok:
            popup("Backtest thất bại", res.error, size=(0.92, 0.5), color=DOWN)

    # ---- báo cáo ----
    def _report_text(self):
        if not self.res or not self.res.report:
            return ""
        r = self.res
        lines = ["BÁO CÁO BACKTEST  %s %s  (%s)" % (r.symbol, r.timeframe, os.path.basename(self.bot_path() or "")),
                 "Tham số: %s" % json.dumps(r.params, ensure_ascii=False)]
        for k, v in r.report.items():
            lines.append("%s: %s" % (k, "∞" if v == float("inf") else ("-" if v is None else ("%.4f" % v if isinstance(v, float) else v))))
        if "OHLC" in str(r.report.get("Mô phỏng tick", "")):
            lines.append("Lưu ý: " + WORST_NOTE + " Kết quả có thể lệch so với chạy thật.")
        return "\n".join(lines)

    def full_report(self):
        txt = self._report_text()
        if not txt:
            self.app.toast("Chưa có kết quả. Hãy chạy backtest.")
            return
        popup("Báo cáo đầy đủ", txt, [("Sao chép", PANEL2, lambda p: (Clipboard.copy(txt), False)[1]), ("Đóng", BLUE, None)], size=(0.95, 0.85))

    def save_report_html(self):
        if self.res is None:
            self.app.toast("Chưa có kết quả backtest.")
            return
        from . import report
        try:
            start = float(self.res.report.get("Số dư ban đầu") or 0.0)
            path = self.app.store.save_report_html(report.build_html(self.res.trades, start, "Báo cáo backtest PyEA"), "pyea-backtest")
        except (OSError, ValueError, AttributeError) as e:
            self.app.toast("Không lưu được báo cáo: %s" % e)
            return
        popup("Đã lưu báo cáo HTML", "File:\n%s\n\nMở bằng trình duyệt." % path, size=(0.92, 0.45))

    def copy_report(self):
        txt = self._report_text()
        if txt:
            Clipboard.copy(txt)
            self.app.toast("Đã sao chép báo cáo.")

    # ---- danh mục: nhiều bot/nhiều mã cùng một tài khoản (số dư, ký quỹ dùng chung) ----
    def portfolio_dialog(self):
        cfgs = list(self.app.attach_cfgs)
        if not cfgs:
            self.app.toast("Chưa có bot nào được gắn. Gắn bot vào mã (tab Thị trường) rồi quay lại - danh mục lấy từ các bot đã gắn.")
            return
        vals, errs = self.form.read()
        if errs:
            popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
            return
        chosen = {c["iid"] for c in cfgs}
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box.add_widget(wlabel("Chọn các bot đưa vào danh mục. Mỗi bot dùng mã, khung và THAM SỐ đang gắn; vốn, đòn bẩy, spread, phí lấy ở form phía trên.", 11, MUTED))
        body = vbox(spacing=dp(4))
        for c in cfgs:
            row = BoxLayout(size_hint_y=None, height=dp(40))
            row.add_widget(mkchip("%s · %s %s" % (os.path.basename(c["bot_path"]), c["symbol"], c["tf"]), BLUE, True,
                                  lambda a, i=c["iid"]: (chosen.add if a else chosen.discard)(i)))
            body.add_widget(row)
        box.add_widget(vscroll(body))
        pop = StyledPopup(title="Backtest danh mục", content=box, size_hint=(0.95, 0.8), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def go(*_):
            if not chosen:
                self.app.toast("Chưa chọn bot nào.")
                return
            pop.dismiss()
            self._portfolio(vals, [c for c in cfgs if c["iid"] in chosen])
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Chạy danh mục", GREEN, on_release=go))
        box.add_widget(row)
        pop.open()

    def _portfolio(self, vals, cfgs):
        if self._busy:
            return
        st = dict(self.app.settings)
        for k in ("initial_balance", "leverage", "spread_pct", "commission_pct", "max_loss_pct"):
            st[k] = vals[k]
        self._stop.clear()
        self._busy = True
        self.run_btn.disabled = True

        def work():
            try:
                keys = sorted({(str(c["symbol"]).upper(), c["tf"]) for c in cfgs})
                cache = {}
                for n, (sym, tf) in enumerate(keys, 1):
                    cache[(sym, tf)] = self._candles(vals, st, sym, tf, vals["bars"] + vals["warmup"], None,
                                                     lambda a, b, n=n, sym=sym, tf=tf: self._progress(
                                                         "Tải dữ liệu %d/%d %s %s (%d/%d nến)..." % (n, len(keys), sym, tf, a, b)))
                entries = portfolio_entries(cfgs, {c["iid"] for c in cfgs}, cache, vals["warmup"])
                syms = {s for s, _tf in keys}
                if vals.get("ai_replay") and len(syms) > 1:
                    raise ValueError("Phát lại tín hiệu AI chỉ hỗ trợ danh mục 1 mã (tín hiệu ghi theo mã đang chạy) - tắt ô này hoặc bớt mã.")
                sigs = self._ai_replay(vals, [c for lst in cache.values() for c in lst], next(iter(syms)) if syms else None)
                self._progress("Đang chạy backtest danh mục (%d bot)..." % len(entries))
                res = run_portfolio(entries, st, vals["warmup"], vals["mode"],
                                    progress=lambda a, b: self._progress("Danh mục %d/%d nến" % (a, b)), stop_event=self._stop, ai_signals=sigs)
            except Exception as e:
                res = BacktestResult(ok=False, error="%s" % e)
            self._done_portfolio(res, vals)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _done_portfolio(self, res, vals):
        self._done(res, vals)
        if res.ok:
            txt = portfolio_summary(res)
            popup("Kết quả danh mục", txt, [("Sao chép", PANEL2, lambda p: (Clipboard.copy(txt), False)[1]), ("Đóng", BLUE, None)], size=(0.95, 0.8))

    # ---- độ nhạy với thứ tự giá trong nến ----
    def sensitivity(self):
        if self._busy:
            return
        got = self._setup()
        if not got:
            return
        vals, path = got
        st = dict(self.app.settings)
        for k in ("initial_balance", "leverage", "spread_pct", "commission_pct", "max_loss_pct"):
            st[k] = vals[k]
        params = self._params(path)
        self._stop.clear()
        self._busy = True
        self.run_btn.disabled = True

        def work():
            try:
                sym = vals["symbol"].strip().upper()
                candles, warm = self._load(vals, st, lambda a, b: self._progress("Tải dữ liệu %d/%d nến..." % (a, b)))
                out = intrabar_sensitivity(path, params, st, sym, vals["timeframe"], candles, warm,
                                           progress=lambda a, b: self._progress("Độ nhạy %d/%d thứ tự" % (a, b)), stop_event=self._stop,
                                           ai_signals=self._ai_replay(vals, candles, sym))
            except Exception as e:
                out = {"ok": False, "error": str(e), "results": {}}
            self._sens_done(out)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _sens_done(self, out):
        self._busy = False
        self.run_btn.disabled = False
        self.prog.text = "Xong." if out.get("ok") else "Lỗi."
        if not out.get("ok"):
            popup("Không so sánh được", out.get("error") or "lỗi", size=(0.92, 0.5), color=DOWN)
            return
        lines = ["Cùng bot + tham số, chỉ đổi thứ tự giá TRONG nến (%s):" % out["key"], ""]
        for m, r in out["results"].items():
            v = r["value"]
            lines.append("• %s: %s (%s lệnh, sụt vốn %.2f%%)" % (r["label"], "-" if v is None else "%.2f" % v, r["trades"], r["dd_pct"] or 0.0))
        lines += ["", out.get("note") or ""]
        txt = "\n".join(lines)
        popup("Độ nhạy thứ tự trong nến", txt, [("Sao chép", PANEL2, lambda p: (Clipboard.copy(txt), False)[1]), ("Đóng", BLUE, None)],
              size=(0.95, 0.7), color=DOWN if out.get("fragile") else TEXT)

    # ---- tối ưu hoá ----
    def optimize_dialog(self):
        """Tối ưu như Optimization của MT5, tới 3 tham số (lưới = tích các khoảng), tối đa MAX_OPT lần chạy, mô phỏng 'open' cho nhanh.
        Xong: xếp hạng + «So sánh từng tham số» (lời/lỗ trung bình theo từng giá trị) + «Hỏi AI tư vấn»."""
        got = self._setup()
        if not got:
            return
        vals, path = got
        info = inspect_bot(path)
        nums = [k for k, i in info.inputs.items() if i.kind in ("int", "float")] if info.ok else []
        if not nums:
            self.app.toast("Bot không có tham số số để tối ưu.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(4), padding=dp(8))
        rows = []
        for n in range(3):
            sp = mk_spinner(nums[n] if n < len(nums) and n < 1 else "(không dùng)", ["(không dùng)"] + nums)
            if n == 1 and len(nums) > 1:
                sp.text = nums[1]
            lo, hi, st = mk_input("5", "từ"), mk_input("20", "đến"), mk_input("5", "bước")
            line = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
            for w in (sp, lo, hi, st):
                line.add_widget(w)
            box.add_widget(wlabel("Tham số %d: chọn · từ · đến · bước" % (n + 1), 11, MUTED))
            box.add_widget(line)
            rows.append((sp, lo, hi, st))
        key = mk_spinner("Lợi nhuận ròng", ["Lợi nhuận ròng", "Profit factor", "Recovery factor", "Sharpe (xấp xỉ)", FITNESS_KEY])
        box.add_widget(labeled("Xếp theo", key))
        res_lbl = wlabel("Tối đa %d lần chạy. Đặt «(không dùng)» để bỏ một tham số." % MAX_OPT, 11, MUTED)
        box.add_widget(res_lbl)
        pop = StyledPopup(title="Tối ưu hoá tham số", content=box, size_hint=(0.97, 0.9), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def go(*_):
            grid, total = {}, 1
            try:
                for sp, lo, hi, st in rows:
                    if sp.text == "(không dùng)":
                        continue
                    if sp.text in grid:
                        raise ValueError("Tham số «%s» chọn hai lần" % sp.text)
                    a, b, s_ = num(lo.text), num(hi.text), num(st.text)
                    if s_ <= 0 or b < a:
                        raise ValueError("Khoảng của «%s» không hợp lệ" % sp.text)
                    kind = info.inputs[sp.text].kind
                    vs, v = [], a
                    while v <= b + 1e-9 and len(vs) < MAX_OPT:
                        vs.append(int(round(v)) if kind == "int" else round(v, 8))
                        v += s_
                    grid[sp.text] = vs
                    total *= len(vs)
                if not grid:
                    raise ValueError("Chọn ít nhất một tham số")
                if total > MAX_OPT:
                    raise ValueError("%d lần chạy > %d. Giảm khoảng hoặc tăng bước." % (total, MAX_OPT))
            except ValueError as e:
                res_lbl.text = str(e)
                return
            if key.text == FITNESS_KEY and not info.has_tester:
                res_lbl.text = "Bot này chưa định nghĩa on_tester() - chọn tiêu chí khác hoặc thêm hàm on_tester vào bot."
                return
            pop.dismiss()
            self._optimize(path, vals, grid, key.text)
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Chạy", GREEN, on_release=go))
        box.add_widget(row)
        pop.open()

    def _optimize(self, path, vals, grid, sort_key):
        st = dict(self.app.settings)
        for k in ("initial_balance", "leverage", "spread_pct", "commission_pct", "max_loss_pct"):
            st[k] = vals[k]
        base = self._params(path)
        self._stop.clear()
        self._pause.clear()
        self._busy = True
        self.run_btn.disabled = True

        def work():
            try:
                sym = vals["symbol"].strip().upper()
                candles, warm = self._load(vals, st)
                out = optimize(path, base, grid, st, sym, vals["timeframe"], candles, warm, "open", top=None, max_runs=MAX_OPT,
                               sort_key=sort_key, progress=lambda a, b: self._progress("Tối ưu %d/%d" % (a, b)), stop_event=self._stop,
                               ai_signals=self._ai_replay(vals, candles, sym))
            except Exception as e:
                out = str(e)
            self._opt_done(path, out, sort_key)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _opt_done(self, path, out, sort_key):
        self._busy = False
        self.run_btn.disabled = False
        self.prog.text = "Tối ưu xong."
        if isinstance(out, str) or not out:
            self.app.toast("Tối ưu thất bại: %s" % (out or "không có kết quả"))
            return
        self._opt_all = out
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(4))
        pop = StyledPopup(title="Kết quả tối ưu (%d lần chạy) - chạm để áp dụng tham số" % len(out), content=content, size_hint=(0.97, 0.9), auto_dismiss=False)
        names = list(out[0]["params"])
        for r in out[:12]:
            rp = r["report"]
            txt = "%s\nLN %s · PF %s · DD %s · %s lệnh" % (
                ", ".join("%s=%s" % (k, r["params"][k]) for k in names if k in r["params"]),
                fm(rp["Lợi nhuận ròng"]), fmt_stat(rp["Profit factor"], "x"), fmt_stat(rp["Sụt vốn tối đa (%)"], "pct"), rp["Tổng số lệnh"])

            def apply(_w, p=r["params"]):
                self.bt_params[path] = dict(p)
                pop.dismiss()
                self.app.toast("Đã áp dụng tham số vào backtest. Bấm CHẠY BACKTEST để xem chi tiết.")
            b = mkbtn(txt, PANEL2, h=56, size=11, on_release=apply)
            b.halign = "left"
            b.bind(size=lambda w, sz: setattr(w, "text_size", (sz[0] - dp(14), sz[1])))
            box.add_widget(b)
        content.add_widget(vscroll(box))
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("So sánh từng tham số", BLUE, size=12, on_release=lambda *_: self.opt_stats_dialog(path, out, sort_key)))
        r2.add_widget(mkbtn("Hỏi AI tư vấn", AMBER, size=12, on_release=lambda *_: self.advice_from_optimization(path, out, sort_key)))
        content.add_widget(r2)
        content.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        pop.open()

    # ---- thống kê so sánh lời/lỗ từng tham số ----
    def opt_stats_dialog(self, path, results, sort_key):
        bd = btanalysis.param_breakdown(results, sort_key)
        if not bd:
            self.app.toast("Chỉ có một tổ hợp - không có gì để so sánh.")
            return
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="So sánh từng tham số (%s)" % sort_key, content=content, size_hint=(0.98, 0.92), auto_dismiss=False)
        imp = btanalysis.param_importance(bd)
        if imp:
            body.add_widget(section("THAM SỐ NÀO ĐỔI KẾT QUẢ NHIỀU NHẤT"))
            for i in imp:
                body.add_widget(wlabel("%s: chênh %s giữa giá trị tốt nhất (%s) và tệ nhất (%s) · %.0f%% tổng ảnh hưởng" % (
                    i["name"], btanalysis.fmt_num(i["spread"]), i["best_value"], i["worst_value"], i["share"] * 100), 12, TEXT))
        for name, rws in bd.items():
            body.add_widget(section("%s - mỗi dòng gộp mọi lần chạy có giá trị đó" % name))
            tb = Table([name, "Lần", "TB", "Tốt nhất", "Tệ nhất", "% có lãi", "PF TB", "DD TB"], [1.0, 0.6, 1.0, 1.0, 1.0, 0.9, 0.8, 0.8])
            tb.set_rows([[str(r["value"]), str(r["runs"]), (btanalysis.fmt_num(r["mean"]), UP if (r["mean"] or 0) >= 0 else DOWN),
                          btanalysis.fmt_num(r["best"]), btanalysis.fmt_num(r["worst"]), "%.0f%%" % r["profitable_pct"],
                          btanalysis.fmt_num(r["mean_pf"]), btanalysis.fmt_num(r["mean_dd"], 1)] for r in rws])
            body.add_widget(tb)
        names = list(bd)
        if len(names) >= 2:
            xs, ys, mat = btanalysis.heatmap(results, names[0], names[1], sort_key)
            body.add_widget(section("BẢN ĐỒ NHIỆT: %s (cột) × %s (hàng), TB %s" % (names[0], names[1], sort_key)))
            hm = Table([names[1] + "\\" + names[0]] + [str(x) for x in xs], [1.0] + [1.0] * len(xs))
            hm.set_rows([[str(y)] + [(btanalysis.fmt_num(v, 1), UP if (v or 0) >= 0 else DOWN) if v is not None else "-" for v in rw] for y, rw in zip(ys, mat)])
            body.add_widget(hm)
        best = results[0]["params"]
        rb = btanalysis.robustness(results, best, sort_key)
        body.add_widget(section("ĐỘ VỮNG CỦA KẾT QUẢ TỐT NHẤT"))
        body.add_widget(wlabel(rb["message"], 12, DOWN if rb["spiky"] else TEXT))
        content.add_widget(vscroll(body))
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Hỏi AI tư vấn", AMBER, size=12, on_release=lambda *_: (pop.dismiss(), self.advice_from_optimization(path, results, sort_key))))
        r2.add_widget(mkbtn("Đóng", PANEL2, size=12, on_release=lambda *_: pop.dismiss()))
        content.add_widget(r2)
        pop.open()

    def trade_stats_dialog(self):
        res = self.res
        if not res or not res.trades:
            self.app.toast("Chưa có lần chạy nào có lệnh. Chạy backtest trước.")
            return
        bd = btanalysis.trade_breakdown(res.trades)
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Thống kê lời/lỗ lần chạy này", content=content, size_hint=(0.98, 0.92), auto_dismiss=False)
        for name, rws in bd.items():
            rws = [r for r in rws if r["trades"]]
            if not rws:
                continue
            body.add_widget(section(name))
            tb = Table(["", "Lệnh", "Lãi/lỗ", "Thắng", "TB/lệnh", "PF"], [1.0, 0.7, 1.1, 0.8, 1.0, 0.8])
            tb.set_rows([[str(r["key"]), str(r["trades"]), (fm(r["net"]), UP if r["net"] >= 0 else DOWN), "%.0f%%" % r["win_pct"], fm(r["avg"]),
                          btanalysis.fmt_num(r["pf"])] for r in rws])
            body.add_widget(tb)
        content.add_widget(vscroll(body))
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Hỏi AI tư vấn", AMBER, size=12, on_release=lambda *_: (pop.dismiss(), self.advice_from_run())))
        r2.add_widget(mkbtn("Đóng", PANEL2, size=12, on_release=lambda *_: pop.dismiss()))
        content.add_widget(r2)
        pop.open()

    # ---- AI tư vấn (CHỈ đề xuất; người dùng bấm «Áp dụng» - chỉ đặt tham số cho backtest kế tiếp) ----
    def advice_from_run(self):
        res, path = self.res, self.bot_path()
        if not res or not path or not res.report:
            self.app.toast("Chạy backtest trước rồi mới hỏi AI.")
            return
        extra = btanalysis.trade_breakdown_text(btanalysis.trade_breakdown(res.trades))
        self._advise(path, res.report, extra)

    def advice_from_optimization(self, path, results, sort_key):
        bd = btanalysis.param_breakdown(results, sort_key)
        rb = btanalysis.robustness(results, results[0]["params"], sort_key)
        top = "\n".join("%s -> %s" % (json.dumps(r["params"], ensure_ascii=False), json.dumps({k: r["report"].get(k) for k in ("Lợi nhuận ròng", "Profit factor", "Sụt vốn tối đa (%)", "Tổng số lệnh")}, ensure_ascii=False, default=str))
                         for r in results[:8])
        extra = "Tiêu chí xếp: %s\n%s\nẢnh hưởng: %s\nĐộ vững: %s\n8 tổ hợp tốt nhất:\n%s" % (
            sort_key, btanalysis.breakdown_text(bd, sort_key), json.dumps(btanalysis.param_importance(bd), ensure_ascii=False, default=str), rb["message"], top)
        self._advise(path, results[0]["report"], extra)

    def _advise(self, path, report, extra):
        from .assistant import pick_agent
        agent = pick_agent(list(self.app.hub.agents), self.app.settings.get("assistant_agent"))
        if not agent:
            self.app.toast("Chưa có model AI nào bật. Thêm ở tab AI (khoá API của bạn) rồi thử lại.")
            return
        info = inspect_bot(path)
        if not info.ok:
            self.app.toast("Không nạp được bot: %s" % info.error)
            return
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                src = f.read()
        except OSError:
            src = ""
        params = self._params(path)
        msgs = btanalysis.build_advice_messages(os.path.basename(path), src, btanalysis.inputs_spec(info.inputs), params, report, extra)
        self.prog.text = "Đang hỏi AI «%s»..." % agent.get("name")

        def work():
            try:
                adv = btanalysis.ask_advice(agent, msgs, info.inputs, params)
                err = ""
            except Exception as e:                               # noqa: BLE001 - mạng/model lỗi: báo, không sập
                adv, err = None, str(e)
            self._advice_done(path, adv, err)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _advice_done(self, path, adv, err):
        self.prog.text = ""
        if err or adv is None:
            popup("AI không trả lời được", err or "không rõ lỗi", size=(0.92, 0.5), color=DOWN)
            return
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(5))
        pop = StyledPopup(title="AI tư vấn (chỉ là gợi ý - hãy kiểm chứng)", content=content, size_hint=(0.98, 0.92), auto_dismiss=False)
        if adv["summary"]:
            body.add_widget(wlabel(adv["summary"], 13, TEXT))
        elif adv["text"]:
            body.add_widget(wlabel(adv["text"][:1500], 12, TEXT))
        if adv["params"]:
            body.add_widget(section("ĐỀ XUẤT THAM SỐ (bấm Áp dụng = đặt cho backtest kế tiếp, KHÔNG đổi bot đang chạy)"))
        for it in adv["params"]:
            body.add_widget(wlabel("%s: %s → %s\n%s" % (it["name"], it["old"], it["value"], it["reason"]), 12, TEXT))

            def apply(_w, it=it):
                cur = dict(self._params(path))
                cur[it["name"]] = it["value"]
                self.bt_params[path] = cur
                self.app.toast("Đã đặt %s = %s cho backtest kế tiếp. Bấm CHẠY BACKTEST để kiểm chứng." % (it["name"], it["value"]))
            body.add_widget(mkbtn("Áp dụng %s = %s" % (it["name"], it["value"]), GREEN, h=40, size=12, on_release=apply))
        if adv["params"]:
            def apply_all(*_):
                cur = dict(self._params(path))
                cur.update({it["name"]: it["value"] for it in adv["params"]})
                self.bt_params[path] = cur
                self.app.toast("Đã đặt %d tham số cho backtest kế tiếp." % len(adv["params"]))
            body.add_widget(mkbtn("Áp dụng TẤT CẢ đề xuất tham số", AMBER, h=40, size=12, on_release=apply_all))
        if adv["logic"]:
            body.add_widget(section("GỢI Ý LOGIC (chỉ là chữ - bạn tự sửa bot hoặc nhờ Chat AI viết lại rồi backtest)"))
            for it in adv["logic"]:
                body.add_widget(wlabel("%s\n%s" % (it["title"], it["detail"]), 12, TEXT))
        if adv["tests"]:
            body.add_widget(section("CÁCH KIỂM CHỨNG"))
            for t in adv["tests"]:
                body.add_widget(wlabel("- " + t, 12, MUTED))
        for d in adv["dropped"]:
            body.add_widget(wlabel("Bỏ qua: " + d, 11, AMBER))
        body.add_widget(wlabel("AI có thể sai và số liệu quá khứ không đảm bảo tương lai. Luôn kiểm bằng walk-forward / giai đoạn khác trước khi dùng tiền thật.", 11, MUTED))
        content.add_widget(vscroll(body))
        content.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        pop.open()


    # ---- walk-forward ----
    def walk_forward_dialog(self):
        got = self._setup()
        if not got:
            return
        vals, path = got
        info = inspect_bot(path)
        nums = [k for k, i in info.inputs.items() if i.kind in ("int", "float")] if info.ok else []
        if not nums:
            self.app.toast("Bot không có tham số số để tối ưu.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        sp1 = mk_spinner(nums[0], nums)
        lo, hi, st = mk_input("5", "từ"), mk_input("20", "đến"), mk_input("5", "bước")
        is_n, oos_n = mk_input("500", "nến IN-SAMPLE"), mk_input("125", "nến OUT-OF-SAMPLE")
        kind = mk_spinner("cửa sổ cố định", ["cửa sổ cố định", "mở rộng (anchored)"])
        key = mk_spinner("Lợi nhuận ròng", ["Lợi nhuận ròng", "Profit factor", "Recovery factor", "Sharpe (xấp xỉ)", FITNESS_KEY])
        for t, w in (("Tham số", sp1), ("Từ", lo), ("Đến", hi), ("Bước", st), ("Nến IS (tối ưu)", is_n), ("Nến OOS (kiểm)", oos_n), ("Kiểu IS", kind), ("Xếp theo", key)):
            box.add_widget(labeled(t, w))
        res_lbl = wlabel("Mỗi cửa sổ: tối ưu trên IS rồi kiểm trên OOS kế tiếp (dữ liệu chưa thấy). Cần đủ nến: 'Số nến' ở trên phải > IS + OOS.", 11, MUTED)
        box.add_widget(res_lbl)
        pop = StyledPopup(title="Walk-forward", content=box, size_hint=(0.95, 0.9), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def go(*_):
            try:
                a, b, s_ = num(lo.text), num(hi.text), num(st.text)
                i_n, o_n = int(num(is_n.text)), int(num(oos_n.text))
                if s_ <= 0 or b < a:
                    raise ValueError("Khoảng tham số không hợp lệ")
                if i_n < 20 or o_n < 5:
                    raise ValueError("IS >= 20 nến, OOS >= 5 nến")
            except ValueError as e:
                res_lbl.text = str(e)
                return
            if key.text == FITNESS_KEY and not info.has_tester:
                res_lbl.text = "Bot này chưa định nghĩa on_tester() - chọn tiêu chí khác hoặc thêm hàm on_tester vào bot."
                return
            k = info.inputs[sp1.text].kind
            grid, v = [], a
            while v <= b + 1e-9 and len(grid) < 40:
                grid.append(int(round(v)) if k == "int" else round(v, 8))
                v += s_
            pop.dismiss()
            self._walk_forward(path, vals, {sp1.text: grid}, key.text, i_n, o_n, kind.text.startswith("mở rộng"))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Chạy", GREEN, on_release=go))
        box.add_widget(row)
        pop.open()

    def _walk_forward(self, path, vals, grid, sort_key, is_bars, oos_bars, anchored):
        st = dict(self.app.settings)
        for k in ("initial_balance", "leverage", "spread_pct", "commission_pct", "max_loss_pct"):
            st[k] = vals[k]
        base = self._params(path)
        self._stop.clear()
        self._busy = True
        self.run_btn.disabled = True

        def work():
            try:
                sym = vals["symbol"].strip().upper()
                candles, warm = self._load(vals, st)
                out = walk_forward(path, base, grid, st, sym, vals["timeframe"], candles, warm, is_bars, oos_bars, anchored, "open",
                                   sort_key, 40, progress=lambda a, b: self._progress("Walk-forward %d/%d" % (a, b)), stop_event=self._stop,
                                   ai_signals=self._ai_replay(vals, candles, sym))
            except Exception as e:
                out = {"ok": False, "error": str(e), "windows": []}
            self._wf_done(out, sort_key)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _wf_done(self, out, sort_key):
        self._busy = False
        self.run_btn.disabled = False
        self.prog.text = "Walk-forward xong."
        if not out.get("ok") or not out.get("windows"):
            self.app.toast("Walk-forward thất bại: %s" % (out.get("error") or "không có cửa sổ nào"))
            return
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(4))
        rp = out["report"] or {}
        wfe = out.get("wfe")
        box.add_widget(wlabel("TỔNG HỢP CÁC ĐOẠN OOS (dữ liệu chưa từng dùng để chọn tham số)", 12, AMBER))
        box.add_widget(wlabel("Lợi nhuận ròng %s · %s lệnh · PF %s · DD %s" % (
            fm(rp.get("Lợi nhuận ròng", 0.0)), rp.get("Tổng số lệnh", 0), fmt_stat(rp.get("Profit factor"), "x"), fmt_stat(rp.get("Sụt vốn tối đa (%)"), "pct")), 12, TEXT))
        box.add_widget(wlabel("Cửa sổ lãi: %.0f%% · Hiệu suất walk-forward (WFE): %s  (≈1 tốt, ≪1 = quá khớp dữ liệu quá khứ)" % (
            out.get("positive_windows_pct") or 0.0, "%.2f" % wfe if wfe is not None else "n/a"), 11, MUTED))
        for w in out["windows"]:
            ps = ", ".join("%s=%s" % (k, v) for k, v in w["params"].items() if k not in ("lot",))
            box.add_widget(wlabel("#%d  %s\nIS %s → OOS %s · %d lệnh%s" % (
                w["index"], ps or "(tham số mặc định)", fm(w["is_value"]) if w["is_value"] is not None else "n/a", fm(w["oos_net"]), w["oos_trades"],
                " · LỖI: " + w["oos_error"] if w.get("oos_error") else ""), 11, UP if (w["oos_net"] or 0) > 0 else DOWN))
        content.add_widget(vscroll(box))
        content.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        pop = StyledPopup(title="Kết quả walk-forward", content=content, size_hint=(0.97, 0.9), auto_dismiss=False)
        pop.open()


# ============================================================== Tab: Cài đặt
class SettingsTab(BoxLayout):
    """Toàn bộ nội dung (form + các nút thao tác) nằm TRONG MỘT vùng cuộn: trước đây ~8 hàng nút cố định ở đáy chiếm gần nửa màn hình,
    chỉ chừa một khe nhỏ để cuộn nên rất khó kéo chọn mục khác."""

    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(6), **kw)
        self.app = app
        self.content = vbox(spacing=dp(6))
        self.gform = None
        self.dnd_lbl = wlabel("", 11, MUTED)
        self.form_box = vbox(spacing=dp(6))
        self.content.add_widget(self.form_box)
        # --- nút Lưu ngay đầu trang (không phải cuộn xuống cuối mới lưu được) ---
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=lambda *_: app.save_forms(True)))
        row.add_widget(mkbtn("Mặc định", PANEL2, on_release=lambda *_: self.gform and self.gform.reset()))
        self.top_row = row
        self.content.add_widget(section("KHÔNG LÀM PHIỀN (tạm tắt âm/rung cảnh báo)"))
        self.content.add_widget(self.dnd_lbl)
        r0 = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(4))
        for lbl, hrs in (("Tắt", 0), ("1 giờ", 1), ("4 giờ", 4), ("8 giờ", 8), ("24 giờ", 24)):
            r0.add_widget(mkbtn(lbl, PANEL2, h=40, size=11, on_release=lambda *_, h=hrs: self.set_dnd(h)))
        self.content.add_widget(r0)
        self.refresh_dnd(True)
        self.content.add_widget(section("SAO LƯU · CHẨN ĐOÁN · TRỢ GIÚP"))
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Sao lưu", PANEL2, size=12, on_release=app.backup_dialog))
        r2.add_widget(mkbtn("Khôi phục", PANEL2, size=12, on_release=app.restore_dialog))
        self.content.add_widget(r2)
        r2b = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2b.add_widget(mkbtn("Gói chẩn đoán", PANEL2, size=12, on_release=app.diag_bundle_dialog))
        r2b.add_widget(mkbtn("Đặt lại paper", RED, size=12, on_release=app.reset_paper_dialog))
        self.content.add_widget(r2b)
        self.content.add_widget(mkbtn("Tải thiết bị (CPU/RAM/ghi đĩa)", PANEL2, h=44, size=12, on_release=app.load_dialog))
        self.content.add_widget(mkbtn("Có gì mới (phiên bản + API bot)", PANEL2, h=44, size=12, on_release=app.changelog_dialog))
        self.content.add_widget(mkbtn("Hướng dẫn · điều khoản · riêng tư · cập nhật", PANEL2, h=44, size=12, on_release=app.legal_menu))
        r3 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r3.add_widget(mkbtn("Tài khoản (chạy song song)…", BLUE, size=12, on_release=app.accounts_dialog))
        r3.add_widget(mkbtn("Trợ lý", GREEN, size=12, on_release=app.open_assistant_dialog))
        self.content.add_widget(r3)
        self.add_widget(self.top_row)                          # Lưu / Mặc định: luôn thấy ở đầu tab, ngoài vùng cuộn
        self.add_widget(vscroll(self.content))
        self.build(app.settings)

    def set_dnd(self, hours):
        """Tạm hoãn âm/rung cảnh báo `hours` giờ (0 = tắt). Cảnh báo vẫn được ghi và hiện thông báo im lặng."""
        dnd.apply(self.app.settings)
        dnd.snooze(hours)
        self.refresh_dnd(True)
        self.app.toast("Đã tắt «Không làm phiền»." if not hours else "Tạm tắt âm/rung cảnh báo %g giờ." % hours)

    def refresh_dnd(self, force=False):
        now = time.time()
        if not force and now - getattr(self, "_dnd_at", 0.0) < 5.0:
            return
        self._dnd_at = now
        self.dnd_lbl.text = dnd.describe(now)

    def build(self, settings):
        self.form_box.clear_widgets()
        self.form_box.add_widget(wlabel("Cài đặt chung của phiên giao dịch. Thay đổi áp dụng khi KẾT NỐI lại (danh sách theo dõi áp dụng ngay). "
                                       "Bấm Lưu để ghi nhớ.", 11, MUTED))
        self.gform = ParamForm(GLOBAL_INPUTS, settings, section={
            "title": "KẾT NỐI SÀN / API (khoá API, token, tài khoản)", "groups": API_GROUPS, "watch": "exchange",
            "visible": lambda v: api_keys_for(v.get("exchange")), "note": lambda v: api_note(v.get("exchange"))})
        self.form_box.add_widget(self.gform)


# ============================================================== Tab: AI
class AITab(BoxLayout):
    def ask_history(self):
        from .ui_askhist import open_ask_history
        open_ask_history(self.app)

    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(5), **kw)
        self.app = app
        top = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        self.mode = Spinner(text=MODES[0], values=MODES, font_size=sp(12), background_normal="",
                            background_color=PANEL2, color=TEXT)
        self.mode.bind(text=self._on_mode)
        self.agent = Spinner(text="(chưa có AI)", values=[], font_size=sp(12), background_normal="",
                             background_color=PANEL2, color=TEXT)
        top.add_widget(self.mode)
        top.add_widget(self.agent)
        self.add_widget(top)
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        r.add_widget(mkbtn("Quản lý AI", BLUE, h=44, on_release=lambda *_: app.open_agents(), size=12))
        r.add_widget(mkbtn("Giải thích bot", PANEL2, h=44, on_release=lambda *_: self.explain(), size=12))
        r.add_widget(mkbtn("Bot hỏi AI", PANEL2, h=44, on_release=lambda *_: self.ask_history(), size=12))
        r.add_widget(mkbtn("Xoá chat", PANEL2, h=44, on_release=lambda *_: self.clear(), size=12))
        self.add_widget(r)
        self.auto_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        self.auto_btn = mkbtn("Bắt đầu tự thảo luận", GREEN, h=44, on_release=lambda *_: app.toggle_ai_auto(), size=12)
        self.sig_label = flabel("Tín hiệu: chưa có", 11, MUTED)
        self.auto_row.add_widget(self.auto_btn)
        self.auto_row.add_widget(self.sig_label)
        self.chat_box = vbox(spacing=dp(6), padding=dp(2))
        self.sv = vscroll(self.chat_box)
        self.add_widget(self.sv)
        self.status = flabel("", 11, AMBER, size_hint_y=None, height=dp(20))
        self.add_widget(self.status)
        self.inp_row = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(6))
        self.inp = TextInput(hint_text="Nhắn cho AI (vd: giải thích thuật toán / sửa bot để ...)", multiline=True,
                             font_size=sp(13), background_color=PANEL2, foreground_color=TEXT,
                             cursor_color=TEXT, hint_text_color=MUTED)
        self.inp_row.add_widget(self.inp)
        self.send_btn = mkbtn("Gửi", BLUE, h=56, on_release=lambda *_: self.send(), size_hint_x=0.25)
        self.inp_row.add_widget(self.send_btn)
        self.add_widget(self.inp_row)
        self._colors = {}
        self.refresh_agents()
        for m in app.store.chat.tail(30):
            self.add_bubble(m)
        self._pos = app.store.chat.size()

    # ---- trạng thái ----
    def refresh_agents(self):
        names = [a["name"] for a in self.app.hub.agents]
        self.agent.values = names
        if names and self.agent.text not in names:
            self.agent.text = names[0]
        if not names:
            self.agent.text = "(chưa có AI)"

    def _on_mode(self, _w, text):
        auto = text == MODES[2]
        if auto and self.auto_row.parent is None:
            self.add_widget(self.auto_row, index=self.children.index(self.sv) + 1)
        elif not auto and self.auto_row.parent is not None:
            self.remove_widget(self.auto_row)
        self.inp_row.opacity = 0.35 if auto else 1
        self.send_btn.disabled = auto
        self.agent.disabled = text != MODES[0]

    def update(self):
        """Gọi mỗi chu kỳ làm mới: nhận tin mới (từ UI hoặc dịch vụ nền) + cập nhật tín hiệu."""
        msgs, self._pos = self.app.store.chat.read_from(self._pos)
        for m in msgs:
            self.add_bubble(m)
        info = self.app.ai_info()
        s = info.get("signal")
        if s:
            self.sig_label.text = "Tín hiệu: %s %.0f%% (%d phút trước)" % (s["action"].upper(), s["confidence"] * 100, s.get("age", 0) // 60)
            self.sig_label.color = UP if s["action"] == "buy" else DOWN if s["action"] == "sell" else AMBER
        else:
            self.sig_label.text = "Tín hiệu: chưa có / đã hết hạn"
            self.sig_label.color = MUTED
        self.auto_btn.text = "Dừng tự thảo luận" if info.get("auto_on") else "Bắt đầu tự thảo luận"
        self.status.text = info.get("status") or ""

    # ---- hành động ----
    def send(self):
        text = self.inp.text.strip()
        if not text:
            return
        if self._dispatch(text):
            self.inp.text = ""
        else:
            self.status.text = "AI đang bận, vui lòng chờ..."

    def _dispatch(self, text):
        hub = self.app.hub
        if self.mode.text == MODES[0]:
            return hub.ask_single(self.agent.text, text)
        return hub.ask_group(text)

    def explain(self):
        prompt = ("Hãy đọc mã nguồn bot hiện tại và giải thích bằng tiếng Việt: (1) ý tưởng chiến lược, "
                  "(2) điều kiện vào/ra lệnh, (3) quản lý vốn, SL/TP, (4) ý nghĩa từng tham số, "
                  "(5) điểm yếu và rủi ro cần lưu ý.")
        if self.app.selected is None:
            self.status.text = "Hãy chọn bot ở tab Bot trước."
            return
        if not self._dispatch(prompt):
            self.status.text = "AI đang bận, vui lòng chờ..."

    def clear(self):
        self.app.hub.clear_chat()
        self.chat_box.clear_widgets()
        self._pos = 0

    # ---- hiển thị tin nhắn ----
    def _color_for(self, who):
        if who not in self._colors:
            self._colors[who] = PALETTE[len(self._colors) % len(PALETTE)]
        return self._colors[who]

    @staticmethod
    def _display(text):
        """Rút gọn khối code dài + cắt tin quá dài (tránh giới hạn texture)."""
        out, pos = [], 0
        for m in re.finditer(r"```[ \t]*(?:python|py)?[ \t]*\r?\n(.*?)```", text, re.S | re.I):
            out.append(text[pos:m.start()])
            n = m.group(1).count("\n") + 1
            body = m.group(1) if n <= 14 else "[Mã nguồn %d dòng - nhấn 'Xem & áp dụng code']" % n
            out.append("\n" + body + "\n")
            pos = m.end()
        out.append(text[pos:])
        s = "".join(out).strip()
        return s if len(s) <= 3000 else s[:3000] + "\n… (cắt bớt - nhấn Sao chép để lấy đầy đủ)"

    def add_bubble(self, m):
        who, kind = m["who"], m.get("kind", "chat")
        if kind == "notice":
            b = vbox(padding=[dp(6), 0])
            b.add_widget(wlabel("[i]%s[/i]" % escape_markup(m["text"][:600]), 11, MUTED))
        else:
            bg = BUBBLE_USER if who == "user" else (BUBBLE_DECISION if kind == "decision" else PANEL)
            b = Panel(bg=bg, orientation="vertical", size_hint_y=None, padding=dp(8), spacing=dp(4))
            b.bind(minimum_height=b.setter("height"))
            col = AMBER if who == "user" else self._color_for(who)
            b.add_widget(flabel("[b]%s[/b]  [size=10sp][color=%s]%s[/color][/size]" % (
                escape_markup("Bạn" if who == "user" else who), hexc(MUTED),
                fmt_time("%H:%M", m["ts"])), 12, col, size_hint_y=None, height=dp(20)))
            b.add_widget(wlabel(escape_markup(self._display(m["text"])), 13))
            if who != "user":
                row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
                row.add_widget(mkbtn("Sao chép", PANEL2, h=40, size=11,
                                     on_release=lambda *_, t=m["text"]: Clipboard.copy(t)))
                if extract_bot_code(m["text"]):
                    row.add_widget(mkbtn("Xem & áp dụng code", GREEN, h=40, size=11,
                                         on_release=lambda *_, mm=m: self.app.review_code(mm)))
                b.add_widget(row)
        self.chat_box.add_widget(b)
        while len(self.chat_box.children) > MAX_BUBBLES:
            self.chat_box.remove_widget(self.chat_box.children[-1])
        Clock.schedule_once(lambda dt: setattr(self.sv, "scroll_y", 0), 0.1)


# ============================================================== Tab: Nhật ký
class LogTab(BoxLayout):
    LEVELS = OrderedDict([("Tất cả", 0), ("Cảnh báo trở lên", 1), ("Chỉ lỗi", 2)])
    RANK = {"TRACE": 0, "DEBUG": 0, "INFO": 0, "WARN": 1, "ERROR": 2}

    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(6), **kw)
        self.app = app
        flt = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        self.sp_level = mk_spinner("Tất cả", list(self.LEVELS), size_hint_x=0.34)
        self.sp_time = mk_spinner("Mọi lúc", list(LOG_WINDOWS), size_hint_x=0.24)
        self.f_text = mk_input("", "lọc theo chữ / tên bot (vd ma_cross)")
        flt.add_widget(self.sp_level)
        flt.add_widget(self.sp_time)
        flt.add_widget(self.f_text)
        self.add_widget(flt)
        self.sp_level.bind(text=lambda *_: self.refilter())
        self.sp_time.bind(text=lambda *_: self.refilter())
        self.f_text.bind(text=lambda *_: self.refilter())
        self.box = vbox(spacing=dp(1))
        self.sv = vscroll(self.box)
        self.add_widget(self.sv)
        self.entries = []                      # (dòng, mức, epoch)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Xoá", PANEL2, on_release=lambda *_: self.clear()))
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy("\n".join(self.lines))))
        row.add_widget(mkbtn("Kiểm tra hệ thống", BLUE, on_release=lambda *_: app.run_diagnostics()))
        row.add_widget(mkbtn("Trợ lý", GREEN, on_release=app.open_assistant_dialog))
        self.add_widget(row)
        self.add_widget(mkbtn("Xuất gói chẩn đoán (zip, không chứa API key)", PANEL2, h=40, size=12, on_release=app.diag_bundle_dialog))

    @property
    def lines(self):
        """Các dòng ĐANG HIỆN theo bộ lọc (dùng cho 'Sao chép')."""
        now = time.time()
        return [ln for ln, lv, ts in self.entries if self._match(ln, lv, ts, now)]

    def _match(self, line, level, ts=None, now=None):
        return log_match(line, self.RANK.get(level, 0), self.LEVELS.get(self.sp_level.text, 0), self.f_text.text, ts,
                         LOG_WINDOWS.get(self.sp_time.text, 0.0), time.time() if now is None else now)

    def clear(self):
        self.box.clear_widgets()
        self.entries = []

    def refilter(self):
        self.box.clear_widgets()
        now = time.time()
        for ln, lv, ts in self.entries:
            if self._match(ln, lv, ts, now):
                self.box.add_widget(wlabel(escape_markup(ln), 11, LOG_COLOR.get(lv, TEXT)))
        Clock.schedule_once(lambda dt: setattr(self.sv, "scroll_y", 0), 0.1)

    def append(self, entries):
        for _id, ts, level, msg in entries:
            line = "%s [%s] %s" % (fmt_time("%H:%M:%S", ts), level, msg)
            self.entries.append((line, level, ts))
            if self._match(line, level, ts):
                self.box.add_widget(wlabel(escape_markup(line), 11, LOG_COLOR.get(level, TEXT)))
        while len(self.entries) > MAX_LOG_LINES:
            self.entries.pop(0)
        while len(self.box.children) > MAX_LOG_LINES:
            self.box.remove_widget(self.box.children[-1])
        if entries:
            Clock.schedule_once(lambda dt: setattr(self.sv, "scroll_y", 0), 0.1)


class CrashHandler(ExceptionHandler):
    """Lỗi bất ngờ trong callback giao diện: ghi nhật ký + giữ app sống (bot nền không bị ảnh hưởng)."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.times = []

    def handle_exception(self, inst):
        try:
            self.app.note_ui_error("".join(traceback.format_exception(type(inst), inst, inst.__traceback__)))
        except Exception:
            pass
        return ExceptionManager.PASS


# ============================================================== App
class _BrokenTab(BoxLayout):
    """Thay cho một tab dựng lỗi: hiện lỗi; mọi thuộc tính/hàm khác (refresh, append...) là no-op để vòng cập nhật không sập."""

    def __init__(self, inner, **kw):
        super().__init__(**kw)
        self.add_widget(inner)

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return lambda *a, **k: None


class PyEAApp(AccountsUIMixin, AssistantUIMixin, ShellUIMixin, App):
    title = "PyEA Runner"

    def build(self):
        """Khởi động AN TOÀN: lỗi lúc dựng giao diện KHÔNG làm app văng ra ngoài mà hiện lỗi ngay trên màn hình (chụp màn hình gửi để sửa)."""
        try:
            return self._build_main()
        except Exception:                                    # noqa: BLE001
            tb = traceback.format_exc()
            bootlog.crumb("build LỖI\n" + tb)
            self._boot_failed(tb)
            return self._crash_screen(tb, fatal=True)

    def share_report(self, text, subject="PyEA - báo lỗi"):
        """Gửi báo lỗi: bảng Chia sẻ của Android; không được thì sao chép vào clipboard (dán vào Zalo/Telegram...)."""
        if android_utils.share_text(text, subject):
            return True
        try:
            Clipboard.copy(str(text))
            self.toast("Đã sao chép báo lỗi - hãy dán vào tin nhắn gửi người phát triển.")
        except Exception:                                    # noqa: BLE001
            self.toast("Không chia sẻ/sao chép được báo lỗi.")
        return False

    def _boot_failed(self, tb):
        try:
            path = getattr(getattr(self, "store", None), "crash_path", None) or os.path.join(self.user_data_dir, "crash.log")
            with open(path, "a", encoding="utf-8") as f:
                f.write("%s [BOOT]\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
        except Exception:                                    # noqa: BLE001
            pass

    def _crash_screen(self, tb, fatal=False):
        """Màn hình lỗi: toàn bộ traceback trong ô chữ chọn/sao chép được."""
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box.add_widget(wlabel("PyEA KHÔNG KHỞI ĐỘNG ĐƯỢC - chụp màn hình này gửi cho người phát triển" if fatal else "TAB NÀY LỖI - chụp màn hình gửi người phát triển",
                              13, AMBER, height=dp(44)))
        body = vbox(padding=dp(6))
        body.add_widget(wlabel(escape_markup(tb), 11, TEXT))          # Label chữ sáng trên nền Panel tối (TextInput mặc định hiện ô trống trên máy thật)
        pnl = Panel(orientation="vertical", padding=dp(4))
        pnl.add_widget(vscroll(body))
        box.add_widget(pnl)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Gửi báo lỗi", GREEN, on_release=lambda *_: self.share_report(tb)))
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(tb)))
        if fatal:
            row.add_widget(mkbtn("Thoát", PANEL2, on_release=lambda *_: self.stop()))
        box.add_widget(row)
        return box

    def _safe_tab(self, name, factory):
        """Dựng một tab; lỗi thì thay bằng tab báo lỗi (mọi lời gọi vào nó thành no-op) để PHẦN CÒN LẠI của app vẫn chạy được."""
        try:
            w = factory()
            bootlog.crumb("build: tab «%s» OK" % name)
            return w
        except Exception:                                    # noqa: BLE001
            bootlog.crumb("build: tab «%s» LỖI" % name)
            tb = "Tab «%s» lỗi khi dựng:\n%s" % (name, traceback.format_exc())
            self._boot_failed(tb)
            return _BrokenTab(self._crash_screen(tb))

    def _build_main(self):
        bootlog.crumb("build: bắt đầu")
        setup_fonts()
        bootlog.crumb("build: fonts OK")
        if platform == "android":
            Window.softinput_mode = "below_target"
        self.data_dir = (native.files_dir() if native.IS_ANDROID else None) or self.user_data_dir
        self.store = Store(self.data_dir)
        try:
            migrate_defaults(self.store)                       # 1.9.17: mặc định cũ «sensitive» chặn chụp màn hình -> «off» MỘT lần
        except Exception:                                      # noqa: BLE001 - không được chặn khởi động
            pass
        try:                                                   # giao diện sáng/tối: phải đặt TRƯỚC khi dựng bất kỳ widget nào
            apply_theme(resolve_theme(self.store.load_settings().get("theme", "dark"), native.is_night_mode() if native.IS_ANDROID else None))
        except Exception:                                      # noqa: BLE001 - lỗi đọc cài đặt không được chặn khởi động; giữ tối
            apply_theme("dark")
        Window.clearcolor = BG
        ext = android_utils.external_files_dir()
        if ext:
            self.store.exports_dir = os.path.join(ext, "exports")
        bootlog.crumb("build: Store OK (%s)" % self.data_dir)
        self.store.seed_examples()
        self.store.maintain(trim=True)
        bootlog.crumb("build: seed/maintain OK")
        dnd.configure(os.path.join(self.store.base, dnd.FILE))
        self.client = ServiceClient(self.data_dir)
        self.meter = LoadMeter()
        self._fps_init()
        self.settings = self.store.load_settings()
        i18n.set_lang(self.settings.get("language"))
        prefs.apply(self.settings)
        self.attach_cfgs = self.store.load_instances()
        self.ctl = None
        self.main_ctl = None                 # handle của tài khoản CHÍNH (self.ctl có thể đang trỏ tài khoản khác khi 'Xem')
        self.extra_handles = {}              # id tài khoản phụ -> ServiceHandle
        self.viewed = "main"
        self.last_snap = None
        self.log_cursor = 0
        self.selected = None
        self._info_cache = {}
        self._was_alive = False
        self._last_config = None
        self._restarts = []
        self._alarm_seen = 0.0
        self._ui_errors = []
        wl = parse_watchlist(self.settings["watchlist"])
        ws = self.store.load_prefs().get("workspace", {})
        self.chart_sym = ws.get("chart_sym") if ws.get("chart_sym") in wl else (wl[0] if wl else None)
        self.chart_tf = ws.get("chart_tf") if ws.get("chart_tf") in TIMEFRAMES else "1m"
        self.hub = AIHub(self.store, self._hub_snapshot, self._hub_bot, lambda: self.settings)
        ExceptionManager.add_handler(CrashHandler(self))
        bootlog.crumb("build: AIHub OK, dựng tab...")

        self.market_tab = self._safe_tab("Thị trường", lambda: MarketTab(self))
        self.trade_tab = self._safe_tab("Giao dịch", lambda: TradeTab(self))
        self.attach_tab = self._safe_tab("Bot", lambda: AttachTab(self))
        self.chart_tab = self._safe_tab("Biểu đồ", lambda: ChartTab(self))
        self.bt_tab = self._safe_tab("Backtest", lambda: BacktestTab(self))
        self.ai_tab = self._safe_tab("AI", lambda: AITab(self))
        self.settings_tab = self._safe_tab("Cài đặt", lambda: SettingsTab(self))
        self.log_tab = self._safe_tab("Nhật ký", lambda: LogTab(self))

        root = TabbedPanel(do_default_tab=False, tab_pos="bottom_mid", tab_height=dp(46),
                           tab_width=max(Window.width / 5.0, dp(78)), background_color=BG, background_image="")
        self.tabs = {}
        for key, title, widget in (("market", "Thị trường", self.market_tab), ("trade", "Giao dịch", self.trade_tab),
                                   ("bots", "Bot", self.attach_tab), ("chart", "Biểu đồ", self.chart_tab),
                                   ("bt", "Backtest", self.bt_tab), ("ai", "AI", self.ai_tab),
                                   ("settings", "Cài đặt", self.settings_tab), ("log", "Nhật ký", self.log_tab)):
            h = TabbedPanelHeader(text=tr(title), font_size=sp(12))
            h.content = widget
            root.add_widget(h)
            self.tabs[key] = h
        Window.bind(width=lambda w, v: setattr(root, "tab_width", max(v / 5.0, dp(78))))
        Window.bind(on_keyboard=self._on_key)
        self.root_panel = root
        last = self.store.load_prefs().get("workspace", {}).get("tab")
        root.switch_to(self.tabs[last if last in self.tabs else "market"])
        root.bind(current_tab=lambda *_: (self._save_workspace(), self.apply_secure(), Clock.schedule_once(self._catch_up, 0)))
        self.apply_secure()

        self.refresh_bots()
        names = [os.path.basename(p) for p in self.store.list_bots()]
        self.select_bot(os.path.join(self.store.bots_dir, "ma_cross.py") if "ma_cross.py" in names
                        else (self.store.list_bots()[0] if self.store.list_bots() else None))
        bootlog.crumb("build: root + chọn bot OK")
        self._seed_first_attachment()

        h = ServiceHandle.attach_running(self.client, self.store.events_path)
        if h is not None:                       # mở lại app khi phiên vẫn chạy nền
            self.ctl = h
            self.reattach_extra_accounts(h)
            self._alarm_seen = max([a["t"] for a in h.alarms()] + [0.0])
            self.log_tab.append([(0, time.time(), "INFO", "Đã gắn lại vào phiên đang chạy nền.")])
        self._ev = Clock.schedule_interval(self.refresh, float(self.settings["ui_refresh"]))
        Clock.schedule_once(self._after_start, 1.5)
        bootlog.crumb("build: xong (trả root)")
        try:                                                   # 1.9.19: dải cảnh báo MẤT MẠNG của thiết bị (đỏ, trên cùng) - hiện cả khi chọn sàn giả lập
            from .netwatch import NetWatch
            self._net = NetWatch()
            self.net_banner = Panel(bg=DOWN, size_hint_y=None, height=0, padding=[dp(8), dp(2)], opacity=0)
            self.net_lbl = flabel("", 12, TEXT, bold=True)
            self.net_banner.add_widget(self.net_lbl)
            self.net_banner.bind(on_touch_down=self._net_banner_touch)
            box = BoxLayout(orientation="vertical")
            box.add_widget(self.net_banner)
            box.add_widget(root)
            return box
        except Exception:                                      # noqa: BLE001 - tiện ích, không được chặn khởi động
            self._net = None
        return root

    def _save_workspace(self):
        """Nhớ tab đang xem + mã/khung của biểu đồ để lần mở sau vào đúng chỗ đang làm việc."""
        try:
            prefs = self.store.load_prefs()
            ws = prefs.setdefault("workspace", {})
            try:
                cur = self.root_panel.current_tab
                key = next((k for k, h in self.tabs.items() if h is cur), None)
                if key:
                    ws["tab"] = key
            except AttributeError:
                pass
            ws["chart_sym"], ws["chart_tf"] = self.chart_sym, self.chart_tf
            self.store.save_prefs(prefs)
        except (OSError, TypeError, ValueError):
            pass

    def _seed_first_attachment(self):
        prefs = self.store.load_prefs()
        if prefs.get("seeded_attach") or self.attach_cfgs:
            return
        path = os.path.join(self.store.bots_dir, "ma_cross.py")
        wl = parse_watchlist(self.settings["watchlist"])
        if os.path.exists(path) and wl:
            self.attach_cfgs.append({"iid": "ma_cross-%s-1" % wl[0], "bot_path": path, "symbol": wl[0], "tf": "5m",
                                     "params": self.store.load_params(path), "auto": True})
            self.store.save_instances(self.attach_cfgs)
        prefs["seeded_attach"] = True
        self.store.save_prefs(prefs)

    def _after_start(self, dt):
        bootlog.crumb("_after_start")
        native.request_notification_permission()
        self.startup_tasks()                                   # điều khoản lần đầu (nằm dưới) ...
        if self.risk_needed():
            self.risk_dialog()                                 # ... rồi cảnh báo rủi ro nằm trên cùng
        crash = self.store.crash_path
        if os.path.exists(crash):
            try:
                with open(crash, "r", encoding="utf-8") as f:
                    full = f.read()
                text = full[-1800:]
                os.replace(crash, crash + ".old")
                self.send_crash_async(full)
            except OSError:
                return
            popup("Lần chạy trước ứng dụng bị lỗi",
                  "Phiên chạy nền (nếu đang bật) vẫn hoạt động bình thường.\n\nChi tiết lỗi:\n" + text,
                  [("Sao chép", PANEL2, lambda p: (Clipboard.copy(text), False)[1]),
                   ("Gửi báo lỗi", BLUE, lambda p: (self.share_report(text), False)[1]),
                   ("Hỏi Trợ lý", GREEN, lambda p: self.open_assistant_dialog(question="Lần chạy trước app bị lỗi (chi tiết đính kèm). Nguyên nhân có thể là gì và tôi nên làm gì?",
                                                                           data=text, autosend=True)),
                   ("Đóng", BLUE, None)], size=(0.95, 0.8), color=DOWN)

    # ---------------------------------------------------------- hệ thống
    def on_pause(self):
        return True            # giữ app sống khi xuống nền

    def on_resume(self):
        pass

    def on_stop(self):
        c = self.ctl
        if c is not None and not isinstance(c, ServiceHandle):
            c.stop()           # chạy trực tiếp trong app -> dừng theo app; chạy nền (dịch vụ) -> để chạy tiếp
        self.hub.stop_auto()
        android_utils.set_keep_awake(False)

    def _on_key(self, window, key, *args):
        if key == 27 and platform == "android":      # nút Back
            android_utils.move_to_background()
            return True
        return False

    def quit_app(self, *_):
        c = self.ctl
        svc_alive = isinstance(c, ServiceHandle) and c.is_alive()

        def leave(stop_bot):
            def go(_p):
                if stop_bot and c is not None:
                    c.stop()
                self.on_stop()
                self.stop()
            return go
        if svc_alive:
            popup("Thoát ứng dụng", "Phiên giao dịch đang chạy NỀN (có thông báo trên thanh trạng thái). Bạn muốn:",
                  [("Huỷ", PANEL2, None), ("Thoát, bot chạy tiếp", BLUE, leave(False)), ("Ngắt phiên & thoát", RED, leave(True))],
                  size=(0.95, 0.5))
        else:
            confirm("Thoát ứng dụng", "Phiên đang chạy trực tiếp trong app (nếu có) sẽ bị dừng. Thoát?",
                    lambda: leave(True)(None), "Thoát")

    def toast(self, msg):
        popup("Thông báo", msg, size=(0.88, 0.35))

    # ---------------------------------------------------------- lỗi UI / crash
    def note_ui_error(self, tb):
        now = time.time()
        self._ui_errors = [t for t in self._ui_errors if now - t < 60] + [now]
        try:
            with open(self.store.crash_path, "a", encoding="utf-8") as f:
                f.write("%s [UI]\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
        except OSError:
            pass
        if len(self._ui_errors) <= 3:
            self.log_tab.append([(0, now, "ERROR", "Lỗi giao diện (app vẫn chạy): " + tb.strip().splitlines()[-1])])
        if len(self._ui_errors) == 30:
            native.notify_alarm("PyEA: giao diện lỗi liên tục", "Phiên chạy nền (nếu có) vẫn hoạt động. Hãy mở lại app.")

    def report_fatal(self, tb):
        """main.py gọi khi app sắp crash: ghi log + báo động (phiên nền, nếu đang chạy, vẫn sống)."""
        try:
            with open(self.store.crash_path, "a", encoding="utf-8") as f:
                f.write("%s [FATAL]\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
        except Exception:
            pass
        native.notify_alarm("PyEA: ứng dụng bị crash", "Phiên chạy nền (nếu đang bật) vẫn hoạt động. Chạm để mở lại. " + tb.strip().splitlines()[-1][:120])

    # ---------------------------------------------------------- thư viện bot (file .py)
    def get_info(self, path):
        if path is None:
            return None
        try:
            mt = os.path.getmtime(path)
        except OSError:
            return None
        c = self._info_cache.get(path)
        if c and c[0] == mt:
            return c[1]
        info = inspect_bot(path)
        self._info_cache[path] = (mt, info)
        return info

    def refresh_bots(self, select=None):
        paths = self.store.list_bots()
        infos = {p: self.get_info(p) for p in paths}
        if select:
            self.selected = select
        if self.selected not in paths:
            self.selected = paths[0] if paths else None
        self.attach_tab.rebuild_library(paths, self.selected, infos)
        self.bt_tab.set_bots(paths)

    def select_bot(self, path):
        self.selected = path
        self.attach_tab.show_info(self.get_info(path))
        self.refresh_bots()

    def _bot_in_use(self, path):
        return self.is_connected() and any(c["bot_path"] == path for c in self.attach_cfgs)

    def pick_bot_file(self, *_):
        if android_utils.IS_ANDROID:
            android_utils.pick_file(self._on_picked)
            return
        chooser = FileChooserListView(filters=["*.py"], path=os.path.expanduser("~"))
        box = BoxLayout(orientation="vertical", spacing=dp(6))
        box.add_widget(chooser)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = StyledPopup(title="Chọn file bot (.py)", content=box, size_hint=(0.95, 0.9))

        def ok(*_):
            if chooser.selection:
                pop.dismiss()
                self._install_path(chooser.selection[0])
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Chọn", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def _install_path(self, src):
        try:
            self.refresh_bots(select=self.store.install_bot_file(src))
            self.select_bot(self.selected)
        except Exception as e:
            self.toast("Không nạp được file: %s" % e)

    @mainthread
    def _on_picked(self, name, text, err):
        if err == "cancelled":
            return
        if err or text is None:
            self.toast("Không đọc được file:\n%s" % (err or ""))
            return
        if not name.lower().endswith(".py"):
            name += ".py"
        path = self.store.install_bot_text(name, text)
        self.refresh_bots(select=path)
        self.select_bot(path)

    def ai_convert_inputs(self, *_):
        """Soạn sẵn yêu cầu «chuyển tham số bot đang chọn sang chuẩn PyEA Inputs» vào khung chat AI (người dùng xem lại rồi mới gửi)."""
        path = self.selected
        if not path or not os.path.isfile(path):
            self.toast("Hãy chọn một bot trong thư viện trước.")
            return
        try:
            code = open(path, "r", encoding="utf-8", errors="replace").read()
        except OSError as e:
            self.toast("Không đọc được file bot: %s" % e)
            return
        if len(code) > 24000:
            self.toast("File bot quá dài (>24.000 ký tự) để gửi kèm; hãy dán phần khai báo tham số.")
            return
        rules = ("CHUẨN THAM SỐ PYEA: khai báo trong thân lớp bot bằng `from pyea import BaseBot, Group, Input`. "
                 "`Group(\"Tên nhóm\")` đặt nhóm cho các Input phía sau. `Input(mặc_định, \"Nhãn\", min=, max=, step=, help=, choices=, subtype=)`: "
                 "kiểu suy ra từ mặc định (bool/int/float/str); `choices` = danh sách, dict {giá_trị: nhãn} hoặc lớp enum.Enum -> ô chọn; "
                 "subtype = color (#RRGGBB) | time (HH:MM) | datetime (YYYY-MM-DD HH:MM) | text. Trong code dùng self.tên. "
                 "on_init trả False nếu tham số sai. Đổi tên tham số thì thêm param_aliases = {\"tên_cũ\": \"tên_mới\"}.")
        box = getattr(self.ai_tab, "inp", None)
        if box is None:
            self.toast("Tab AI chưa sẵn sàng.")
            return
        box.text = ("Hãy chuyển phần tham số của bot dưới đây sang CHUẨN THAM SỐ PYEA. Gom mọi hằng số người dùng nên chỉnh (chu kỳ, ngưỡng, lot, SL/TP, "
                                "giờ giao dịch, hướng...) thành Input có nhãn tiếng Việt, giới hạn hợp lý và Group; giữ nguyên logic giao dịch.\n"
                                "%s\nTrả về TOÀN BỘ file bot đã sửa trong một khối ```python.\n\n--- %s ---\n```python\n%s\n```" % (rules, os.path.basename(path), code))
        self.root_panel.switch_to(self.tabs["ai"])
        self.toast("Đã soạn yêu cầu trong tab AI. Xem lại rồi bấm Gửi.")

    def copy_template(self, *_):
        Clipboard.copy(self.store.template_text())
        self.toast("Đã sao chép mẫu bot vào clipboard.\nDán vào ứng dụng ghi chú, sửa lại, lưu thành file .py "
                   "rồi nạp bằng nút 'Nạp file .py'. Hoặc nhờ AI viết bot ở tab AI.")

    def reseed(self, *_):
        def go():
            self.store.seed_examples(overwrite=True)
            self._info_cache.clear()
            self.refresh_bots()
            self.select_bot(self.selected)
        confirm("Cài lại bot mẫu", "Các bot mẫu cùng tên sẽ bị ghi đè bằng bản gốc. Tiếp tục?", go, "Cài lại", BLUE)

    def market_dialog(self, *_):
        """Danh mục bot (index.json https) hoặc gói .pyeabot trực tiếp: tải → xác minh chữ ký → hiện nhà phát hành + quyền → cài (không cấp quyền)."""
        prefs = self.store.load_prefs()
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        pop = StyledPopup(title="Chợ bot", content=box, size_hint=(0.95, 0.88), auto_dismiss=False)
        box.add_widget(wlabel("Dán địa chỉ https của danh mục (index.json) hoặc của một gói .pyeabot. Chữ ký chỉ chứng minh gói nguyên vẹn của nhà phát hành, "
                              "KHÔNG chứng minh bot an toàn hay có lãi - hãy thử ở paper trước. Cài xong bot chưa có quyền mạng nào.", 11, MUTED))
        url = mk_input(prefs.get("market_url", ""), "https://.../index.json hoặc .../bot.pyeabot")
        box.add_widget(url)
        body = vbox(spacing=dp(4))
        box.add_widget(vscroll(body))
        info = wlabel("", 12, TEXT)
        body.add_widget(info)

        @mainthread
        def render(rows, err=None):
            body.clear_widgets()
            body.add_widget(info)
            info.text = escape_markup(err) if err else ("%d bot trong danh mục." % len(rows) if rows else "")
            for r in rows or []:
                row = BoxLayout(size_hint_y=None, height=dp(64), spacing=dp(6))
                row.add_widget(wlabel("%s %s\n%s · %s" % (escape_markup(r["name"]), escape_markup(r.get("version", "")), escape_markup(r.get("author", "")),
                                                          escape_markup(r.get("description", ""))[:80]), 11, TEXT))
                row.add_widget(mkbtn("Xem & cài", GREEN, h=44, size=12, size_hint_x=0.3, on_release=lambda *_, e=r: open_pkg(e)))
                body.add_widget(row)

        def open_pkg(target):
            info.text = "Đang tải và xác minh..."

            def work():
                try:
                    pkg = market.fetch_package(target)
                except Exception as e:                          # noqa: BLE001 - hiện lý do cho người dùng
                    render([], "Không cài được: %s" % e)
                    return
                self._market_confirm(pkg, lambda: render([], "Đã cài %s." % pkg["filename"]))
            threading.Thread(target=work, daemon=True).start()

        def load(*_):
            u = url.text.strip()
            p = self.store.load_prefs()
            p["market_url"] = u
            self.store.save_prefs(p)
            info.text = "Đang tải..."

            def work():
                try:
                    if u.lower().split("?")[0].endswith(".pyeabot"):
                        open_pkg(u)
                        return
                    render(market.fetch_catalog(u))
                except Exception as e:                          # noqa: BLE001
                    render([], "Lỗi: %s" % e)
            threading.Thread(target=work, daemon=True).start()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Tải", GREEN, h=46, size=13, on_release=load))
        row.add_widget(mkbtn("Đóng", BLUE, h=46, size=13, on_release=lambda *_: pop.dismiss()))
        box.add_widget(row)
        pop.open()

    @mainthread
    def _market_confirm(self, pkg, done):
        prefs = self.store.load_prefs()
        trusted = list(prefs.get("market_trusted", []))
        known = pkg["pub"] in trusted
        msg = ("%s %s\nTác giả: %s\nNhà phát hành (vân tay): %s%s\nChữ ký: HỢP LỆ\nQuyền bot xin: %s\n\n%s\n\nCài xong bot CHƯA có quyền nào; bạn cấp ở «Quyền bot»." % (
            pkg["name"], pkg.get("version", ""), pkg.get("author", "") or "?", pkg["fingerprint"], "  (ĐÃ TIN CẬY)" if known else "  (chưa từng tin cậy)",
            "; ".join(pkg["perms"]) or "không xin quyền nào", (pkg.get("description") or "")[:300]))

        def do(trust):
            def go(_p=None):
                path, _t = market.install(self.store, pkg, trusted)
                if trust and not known:
                    q = self.store.load_prefs()
                    q["market_trusted"] = trusted + [pkg["pub"]]
                    self.store.save_prefs(q)
                self._info_cache.clear()
                self.refresh_bots(select=path)
                self.select_bot(path)
                done()
            return go
        popup("Cài bot từ chợ", msg, [("Huỷ", PANEL2, None), ("Cài", GREEN, do(False)), ("Cài + tin cậy nhà phát hành", AMBER, do(True))], size=(0.94, 0.8))

    def versions_dialog(self, *_):
        """Lịch sử phiên bản của bot đang chọn: xem số dòng đổi so với bản hiện tại và khôi phục (khôi phục cũng hoàn tác được)."""
        path = self.selected
        if not path:
            self.toast("Chọn một bot trước.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        body = vbox(spacing=dp(4))
        pop = StyledPopup(title="Phiên bản - %s" % os.path.basename(path), content=box, size_hint=(0.95, 0.85), auto_dismiss=False)

        def restore(name):
            if self._bot_in_use(path):
                self.toast("Bot này đang chạy trong phiên. Ngắt phiên hoặc gỡ bot trước khi khôi phục.")
                return
            try:
                botversions.restore(path, name)
            except (OSError, ValueError) as e:
                self.toast("Không khôi phục được: %s" % e)
                return
            self._info_cache.pop(path, None)
            self.refresh_bots()
            self.select_bot(path)
            self.toast("Đã khôi phục %s (bản trước đó được lưu lại, có thể hoàn tác)." % name[:15])
            fill()

        def fill():
            body.clear_widgets()
            items = botversions.list_versions(path)
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    cur = fh.read()
            except OSError:
                cur = ""
            if not items:
                body.add_widget(wlabel("Chưa có phiên bản cũ. Bản cũ được lưu tự động mỗi khi AI sửa đè, nạp lại file cùng tên, cài lại mẫu hoặc xoá bot.", 12, MUTED))
            for it in items:
                try:
                    a, r = botversions.diff_stats(botversions.read_version(path, it["name"]), cur)
                except (OSError, ValueError):
                    a = r = 0
                row = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(6))
                row.add_widget(wlabel("%s\n%s · %d B · so với hiện tại: +%d −%d dòng" % (it["when"], it["label"], it["size"], a, r), 11, TEXT))
                row.add_widget(mkbtn("Khôi phục", GREEN, h=44, size=12, size_hint_x=0.32,
                                     on_release=lambda *_, n=it["name"]: confirm("Khôi phục phiên bản", "Thay nội dung %s bằng bản %s? Bản hiện tại sẽ được lưu lại." % (
                                         os.path.basename(path), it["when"]), lambda: restore(n), "Khôi phục")))
                body.add_widget(row)
        fill()
        box.add_widget(vscroll(body))
        box.add_widget(mkbtn("Đóng", BLUE, h=44, size=13, on_release=lambda *_: pop.dismiss()))
        pop.open()

    def delete_selected(self, *_):
        if not self.selected:
            return
        if self._bot_in_use(self.selected):
            self.toast("File này đang được gắn vào tài sản và phiên đang chạy. Hãy ngắt phiên hoặc gỡ bot trước.")
            return
        path = self.selected

        def go():
            self.store.delete_bot(path)
            self._info_cache.pop(path, None)
            self.attach_cfgs = [c for c in self.attach_cfgs if c["bot_path"] != path]
            self.store.save_instances(self.attach_cfgs)
            self.selected = None
            self.refresh_bots()
            self.select_bot(self.selected)
        confirm("Xoá file bot", "Xoá %s, thông số đã lưu và các lần gắn bot này?" % os.path.basename(path), go, "Xoá")

    # ---------------------------------------------------------- form
    def save_forms(self, show=False):
        form = self.settings_tab.gform
        if form:
            vals, errs = form.read()
            errs = list(errs) + dnd.problems(vals) + fieldmap.parse_overrides(vals.get("field_overrides"))[1] + histengine.parse_profiles(vals.get("history_profiles"))[1]
            if errs:
                popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
                return False
            old_ex = self.settings.get("exchange")
            self.settings = vals
            # đổi sàn mà danh sách theo dõi vẫn là mặc định của sàn cũ -> đổi sang mặc định của sàn mới
            if vals["exchange"] != old_ex and parse_watchlist(vals["watchlist"]) == parse_watchlist(EXCHANGE_WATCH.get(old_ex, "")):
                self.settings["watchlist"] = EXCHANGE_WATCH.get(vals["exchange"], vals["watchlist"])
                form.set_values(self.settings)
        return self._commit_settings(show)

    def _commit_settings(self, show=False):
        """Phần SAU khi `self.settings` đã được đặt: lưu đĩa, nạp ánh xạ trường, áp dụng prefs/màn hình/nhịp làm mới (dùng chung cho nút Lưu và nút «Áp dụng» của Trợ lý)."""
        self.store.save_settings(self.settings)
        old_lang = i18n.lang()
        new_lang = i18n.set_lang(self.settings.get("language"))
        fieldmap.configure(self.settings)                      # ánh xạ trường tay có hiệu lực ngay cho phiên chạy trong app
        prefs.apply(self.settings)
        self.apply_secure()
        self._ev.cancel()
        self._ev = Clock.schedule_interval(self.refresh, float(self.settings["ui_refresh"]))
        if self.is_connected():
            self.ctl.set_watch(parse_watchlist(self.settings["watchlist"]))
            cur = getattr(self, "_sess_ex", None)
            if cur and cur != self.settings.get("exchange"):
                confirm("Cần kết nối lại", "Phiên đang chạy vẫn dùng nguồn «%s». Nguồn mới «%s» chỉ áp dụng sau khi NGẮT rồi KẾT NỐI lại (bot đang chạy sẽ dừng). Kết nối lại ngay?" % (
                    cur, self.settings.get("exchange")), lambda: self._reconnect(), yes_text="Kết nối lại", yes_color=GREEN)
        if new_lang != old_lang:
            self.toast("%s / %s" % (i18n.CAT_RESTART.get(new_lang, "Restart the app to apply the language"), "Khởi động lại app để đổi ngôn ngữ"))
        elif show:
            self.toast("Đã lưu cài đặt.")
        return True

    def _force_stop(self):
        try:
            native.stop_service()
        except Exception as e:                                  # noqa: BLE001
            self.toast("Không buộc dừng được: %s" % e)
        self._stop_t = None

    def _reconnect(self):
        rb = any(i.get("status") in ("running", "starting") for i in (self.last_snap or {}).get("instances", []))
        self.stop_session()
        Clock.schedule_once(lambda *_: self.start_session(run_bots=rb), 1.5)

    def ask_text(self, title, hint, on_ok, text=""):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        ti = mk_input(text, hint)
        box.add_widget(ti)
        pop = StyledPopup(title=title, content=box, size_hint=(0.9, 0.38), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("OK", GREEN, on_release=lambda *_: (pop.dismiss(), on_ok(ti.text.strip())) if ti.text.strip() else None))
        box.add_widget(row)
        pop.open()

    def params_popup(self, title, inputs, values, bot_path, on_save, on_apply=None):
        """Form tham số TỰ SINH từ khai báo trong code bot (như hộp Inputs của MT5) + bộ tham số có tên + áp dụng ngay."""
        form = ParamForm(inputs, values)
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box.add_widget(wlabel("%d tham số nhận dạng từ code bot. Chỉnh rồi bấm Lưu%s." % (
            len(inputs), " hoặc 'Lưu & áp dụng' (bot đang chạy được khởi tạo lại, lệnh mở giữ nguyên)" if on_apply else ""), 11, MUTED))
        box.add_widget(vscroll(form))
        pop = StyledPopup(title=title, content=box, size_hint=(0.97, 0.94), auto_dismiss=False)

        def read():
            vals, errs = form.read()
            if errs:
                popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
                return None
            return vals

        def save_preset(*_):
            vals = read()
            if vals is not None:
                self.ask_text("Lưu bộ tham số", "Tên bộ (vd Thận trọng)", lambda n: self.store.save_preset(bot_path, n, vals))

        def load_preset(*_):
            presets = self.store.load_presets(bot_path)
            if not presets:
                self.toast("Chưa có bộ tham số nào. Bấm 'Lưu bộ' để tạo.")
                return
            c = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
            lst = vbox(spacing=dp(4))
            pp = StyledPopup(title="Nạp bộ tham số", content=c, size_hint=(0.92, 0.7), auto_dismiss=False)
            for n in sorted(presets):
                r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
                r.add_widget(mkbtn(n, PANEL2, h=44, size=13, on_release=lambda *_, k=n: (form.set_values(presets[k]), pp.dismiss())))
                r.add_widget(mkbtn("Xoá", RED, h=44, size=12, size_hint_x=0.3,
                                   on_release=lambda *_, k=n: (self.store.delete_preset(bot_path, k), pp.dismiss())))
                lst.add_widget(r)
            c.add_widget(vscroll(lst))
            c.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pp.dismiss()))
            pp.open()

        def copy_json(*_):
            vals = read()
            if vals is not None:
                Clipboard.copy(json.dumps(vals, ensure_ascii=False))
                self.toast("Đã sao chép tham số (JSON).")

        def paste_json(*_):
            try:
                d = json.loads(Clipboard.paste() or "")
                if not isinstance(d, dict):
                    raise ValueError
                form.set_values({k: v for k, v in d.items() if k in inputs})
            except ValueError:
                self.toast("Clipboard không chứa JSON tham số hợp lệ.")

        r1 = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(4))
        for t, fn in (("Lưu bộ", save_preset), ("Nạp bộ", load_preset), ("Sao chép", copy_json), ("Dán", paste_json)):
            r1.add_widget(mkbtn(t, PANEL2, h=40, size=11, on_release=fn))
        box.add_widget(r1)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Huỷ", PANEL2, size=12, on_release=lambda *_: pop.dismiss()))
        r2.add_widget(mkbtn("Mặc định", PANEL2, size=12, on_release=lambda *_: form.reset()))

        def do(cb):
            def go(*_):
                v = read()
                if v is not None:
                    pop.dismiss()
                    cb(v)
            return go
        r2.add_widget(mkbtn("Lưu", GREEN, size=12, on_release=do(on_save)))
        if on_apply:
            r2.add_widget(mkbtn("Lưu & áp dụng", BLUE, size=12, on_release=do(on_apply)))
        box.add_widget(r2)
        pop.open()

    def form_popup(self, title, inputs, values, on_save, size=(0.97, 0.92)):
        form = ParamForm(inputs, values)
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box.add_widget(vscroll(form))
        pop = StyledPopup(title=title, content=box, size_hint=size, auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def save(*_):
            vals, errs = form.read()
            if errs:
                popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
                return
            pop.dismiss()
            on_save(vals)
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Mặc định", PANEL2, on_release=lambda *_: form.reset()))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=save))
        box.add_widget(row)
        pop.open()

    # ---------------------------------------------------------- phiên giao dịch
    def is_connected(self):
        return bool(self.ctl and self.ctl.is_alive())

    def feed_exchange(self):
        """Nguồn giá THỰC SỰ đang dùng: khi đang kết nối là nguồn của phiên (đổi Cài đặt không áp dụng cho phiên đang chạy)."""
        if self.is_connected() and getattr(self, "_sess_ex", None):
            return self._sess_ex
        return self.settings.get("exchange")

    def toggle_session(self):
        (self.stop_session if self.is_connected() else (lambda: self.start_session(run_bots=False)))()

    def _saved_positions(self):
        try:
            with open(self.store.state_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            ok = d.get("mode") == self.settings["mode"] and d.get("exchange") == self.settings["exchange"]
            return len(d.get("account", {}).get("positions", [])) if ok else 0
        except Exception:
            return 0

    def run_bots_or_connect(self, *_):
        """Nút tab Bot: chưa kết nối -> kết nối VÀ chạy các bot đã bật; đang kết nối -> chạy tất cả bot chưa chạy."""
        if not self.is_connected():
            self.start_session(run_bots=True)
            return
        live = {i["iid"]: i for i in (self.last_snap or {}).get("instances", [])}
        n = 0
        for cfg in self.attach_cfgs:
            ctl = self.ctl_for(cfg)
            if ctl is None:
                continue
            i = live.get(cfg["iid"])
            if i is None:
                ctl.attach(cfg, True)
                n += 1
            elif i["status"] not in ("running", "starting"):
                ctl.inst_start(cfg["iid"])
                n += 1
        self.toast("Đã chạy %d bot." % n if n else "Không có bot nào cần chạy (chưa gắn bot, hoặc tất cả đang chạy).")

    def start_session(self, *_, run_bots=None):
        """run_bots: True = chạy các bot đã bật ngay khi kết nối; False = chỉ kết nối (giá, biểu đồ, đặt lệnh tay); None = như lần trước."""
        if self.is_connected():
            return
        if run_bots is not None:
            self._run_bots = bool(run_bots)
        if not self.save_forms():
            return
        s = self.settings
        self._sess_ex = s["exchange"]
        live = s["mode"] == "live"
        if live and s["exchange"] in ("simulated", "public"):
            self.toast("Chế độ LIVE cần chọn sàn thật (binance, oanda, exness, cầu nối MT, ccxt) ở tab Cài đặt.")
            return
        if live and not s["live_confirm"]:
            self.toast("Chế độ LIVE cần tick 'Tôi hiểu rủi ro giao dịch tiền thật' và nhập API ở tab Cài đặt.")
            return
        if live and not self.license_gate_live():          # hết 90 ngày dùng thử (bản Play) và chưa có khoá -> không mở phiên LIVE mới
            return
        if live and self.risk_needed():                    # LIVE chỉ sau khi đã đọc + xác nhận cảnh báo rủi ro (một lần)
            self.risk_dialog(lambda *a: self.start_session(run_bots=getattr(self, "_run_bots", False)))
            return

        def proceed(resume):
            if live:
                where = "TESTNET/DEMO (tiền giả)" if s["testnet"] else "tài khoản THẬT"
                confirm("GIAO DỊCH TIỀN THẬT" if not s["testnet"] else "LIVE TESTNET/DEMO",
                        "Phiên sẽ đặt lệnh trên %s (%s)%s. Bạn đã thử kỹ ở chế độ paper chưa?" % (
                            s["exchange"], where, "" if s["testnet"] else " và có thể làm mất vốn"),
                        lambda: self._do_start(resume), "Kết nối LIVE")
            else:
                self._do_start(resume)
        n = self._saved_positions()
        if n:
            popup("Phiên trước còn %d lệnh mở" % n,
                  "Lần chạy trước dừng khi còn lệnh chưa đóng. Khôi phục sổ lệnh đó (tiếp tục quản lý) hay bắt đầu phiên mới?",
                  [("Phiên mới", PANEL2, lambda p: proceed(False)), ("Khôi phục", GREEN, lambda p: proceed(True))], size=(0.95, 0.45))
        else:
            proceed(False)

    def _make_config(self, resume):
        return {"settings": dict(self.settings), "resume": resume, "ai_auto": False,
                "log_file": os.path.join(self.store.logs_dir, time.strftime("%Y%m%d") + ".log"),
                "trades_csv": self.store.trades_csv,
                "instances": [dict(c, running=bool(c.get("auto", True)) and bool(getattr(self, "_run_bots", False)))
                              for c in self.attach_cfgs if (c.get("account") or "main") == "main"]}

    def _do_start(self, resume=False):
        cfg = self._make_config(resume)
        self._last_config = cfg
        self.log_cursor = 0
        self.log_tab.clear()
        self.trade_tab._tr_sig = None
        self.chart_tab._ev_sig = None
        self.last_snap = None
        self._alarm_seen = time.time()
        self.main_ctl, self.extra_handles, self.viewed = None, {}, "main"
        started = False
        if native.IS_ANDROID and self.settings["background_service"]:
            started = self._start_service_mode(cfg)
        if not started:
            self._start_local(cfg)
            self._start_extra_accounts(self.ctl, cfg.get("resume"), local=True)          # tài khoản phụ cũng chạy song song, mỗi tài khoản một phiên riêng
        self._maybe_battery_prompt()

    def _start_service_mode(self, cfg):
        h = ServiceHandle(self.client, self.store.events_path, pending=True)
        h.start(cfg)
        if not self.client.host_alive():
            ok, err = native.start_service(json.dumps({"data_dir": self.data_dir}), "PyEA Runner", "Đang khởi động phiên...")
            if not ok:
                self.client.pop_commands()
                self.log_tab.append([(0, time.time(), "WARN", "Không bật được dịch vụ nền (%s) -> chạy trực tiếp trong app" %
                                      (err.strip().splitlines()[-1] if err else "?"))])
                return False
        self.ctl = h
        self.log_tab.append([(0, time.time(), "INFO", "Phiên chạy NỀN bằng dịch vụ (vẫn chạy khi tắt màn hình / thoát app).")])
        self._start_extra_accounts(h, cfg.get("resume"))
        return True

    def _start_local(self, cfg):
        if not cfg.get("resume"):
            try:
                os.remove(self.store.state_path)
            except OSError:
                pass
            try:
                open(self.store.events_path, "w").close()
            except OSError:
                pass
        sess = TradingSession(cfg["settings"], log_file=cfg["log_file"], trades_csv=cfg["trades_csv"],
                              state_file=self.store.state_path, events_file=self.store.events_path,
                              resume=cfg["resume"], alarm_cb=native.notify_alarm, ai_hub=self.hub,
                              alerts_file=self.store.alerts_path)
        ctl = LocalController(sess)
        for c in cfg["instances"]:
            ctl.attach(c, start=c.get("running", True))
        ctl.start()
        self.ctl = ctl
        android_utils.set_keep_awake(bool(cfg["settings"]["keep_awake"]))

    def stop_session(self, *_):
        if not self.is_connected():
            self.toast("Chưa có phiên nào đang chạy.")
            return
        if self.is_connected():
            self._stop_t, self._stop_warned = time.time(), False
            self.toast("Đang ngắt kết nối… bot sẽ dừng; vị thế đang mở KHÔNG tự đóng.")
            self._stop_extra_accounts()
            (self.main_ctl or self.ctl).stop()
            if self.main_ctl is not None:
                self.ctl = self.main_ctl
                self.viewed = "main"

    def _maybe_battery_prompt(self):
        if not native.IS_ANDROID:
            return
        prefs = self.store.load_prefs()
        if prefs.get("battery_prompted") or native.is_ignoring_battery_optimizations():
            return
        prefs["battery_prompted"] = True
        self.store.save_prefs(prefs)
        popup("Giữ bot sống khi chạy nền",
              "Android có thể 'tối ưu pin' và giết bot nền sau một thời gian. Hãy cho phép PyEA Runner KHÔNG bị tối ưu pin "
              "(hộp thoại hệ thống sẽ hiện ra).",
              [("Để sau", PANEL2, None),
               ("Mở cài đặt", GREEN, lambda p: (native.request_ignore_battery_optimizations(), None)[1])], size=(0.95, 0.45))

    # ---------------------------------------------------------- bot gắn vào tài sản
    def _symbol_choices(self):
        out = parse_watchlist(self.settings["watchlist"])
        for c in self.attach_cfgs:
            if c["symbol"] not in out:
                out.append(c["symbol"])
        return out

    def _save_attach(self):
        self.store.save_instances(self.attach_cfgs)
        self.attach_tab._att_sig = None

    def open_attach_dialog(self):
        paths = self.store.list_bots()
        if not paths:
            self.toast("Chưa có file bot. Hãy nạp file .py trước.")
            return
        names = [os.path.basename(p) for p in paths]
        syms = self._symbol_choices() or ["BTCUSD"]
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        sp_bot = mk_spinner(os.path.basename(self.selected) if self.selected else names[0], names)
        sp_sym = mk_spinner(self.chart_sym if self.chart_sym in syms else syms[0], syms)
        ti_sym = mk_input("", "hoặc gõ mã khác")
        sp_tf = tf_picker("5m", size_hint_y=None, height=dp(44))
        acc_rows = self.account_book().list()
        acc_names = ["Chính"] + [a["name"] for a in acc_rows]
        sp_acc = mk_spinner(self.account_name(self.viewed) if self.viewed != "main" else "Chính", acc_names)
        fields = [("Bot (EA)", sp_bot), ("Tài sản", sp_sym), ("Mã khác", ti_sym), ("Khung giờ", sp_tf)]
        if acc_rows:
            fields.append(("Tài khoản", sp_acc))
        for t, w in fields:
            box.add_widget(labeled(t, w))
        box.add_widget(wlabel("Sau khi gắn, bấm 'Tham số' để chỉnh thông số riêng cho tài sản này. "
                              "Có thể gắn nhiều bot (hoặc cùng 1 bot) vào nhiều tài sản.", 11, MUTED))
        pop = StyledPopup(title="Gắn bot vào tài sản", content=box, size_hint=(0.95, 0.7), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def ok(*_):
            path = os.path.join(self.store.bots_dir, sp_bot.text)
            sym = (ti_sym.text.strip() or sp_sym.text).upper()
            base = os.path.splitext(sp_bot.text)[0]
            n = 1
            while any(c["iid"] == "%s-%s-%d" % (base, sym, n) for c in self.attach_cfgs):
                n += 1
            cfg = {"iid": "%s-%s-%d" % (base, sym, n), "bot_path": path, "symbol": sym, "tf": sp_tf.text,
                   "params": self.store.load_params(path), "auto": True}
            acc = next((a["id"] for a in acc_rows if a["name"] == sp_acc.text), "main")
            if acc != "main":
                cfg["account"] = acc
                cfg["iid"] = "%s@%s" % (cfg["iid"], acc)                    # iid duy nhất giữa các tài khoản
            self.attach_cfgs.append(cfg)
            self._save_attach()
            ctl = self.ctl_for(cfg)
            if ctl is not None:
                ctl.attach(cfg, True)
            pop.dismiss()
            self.ask_bot_perms(path)                                          # bot khai báo quyền mạng -> hỏi Cho phép / Từ chối
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Gắn bot", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def deploy_from_backtest(self, res, bot_path):
        """Backtest -> chạy thật 1 chạm: gắn đúng bot + mã + khung + THAM SỐ vừa thử. Tài khoản thật: gắn nhưng chưa chạy."""
        if res is None or not res.ok or not bot_path:
            self.toast("Hãy chạy backtest thành công trước khi triển khai.")
            return
        if getattr(res, "by_bot", None):
            self.toast("Đây là kết quả DANH MỤC - các bot đã được gắn sẵn; triển khai từng bot bằng backtest đơn lẻ.")
            return
        live = self.settings.get("mode") == "live"
        cfg = deploy_cfg(bot_path, res.symbol, res.timeframe, res.params, [c["iid"] for c in self.attach_cfgs], live)
        rp = res.report or {}
        txt = ("Gắn %s vào %s khung %s với đúng tham số đã backtest.\n\nKết quả backtest: lãi ròng %s · sụt vốn tối đa %s%% · %s lệnh.\n\n"
               % (os.path.basename(bot_path), cfg["symbol"], cfg["tf"], fm(rp.get("Lợi nhuận ròng") or 0.0),
                  rp.get("Sụt vốn tối đa (%)", "-"), rp.get("Tổng số lệnh", "-")))
        txt += ("Đang ở chế độ TIỀN THẬT: bot sẽ được gắn nhưng CHƯA chạy - hãy kiểm tra ở tab Bot rồi bấm Chạy. Quá khứ không đảm bảo tương lai."
                if live else "Chế độ giả lập (paper): bot sẽ chạy ngay trên tài khoản giả lập.")

        def go(p):
            self.attach_cfgs.append(cfg)
            self._save_attach()
            ctl = self.ctl_for(cfg)
            if ctl is not None:
                ctl.attach(cfg, bool(cfg.get("auto", True)))
            self.root_panel.switch_to(self.tabs["bots"])
            self.toast("Đã gắn %s%s" % (cfg["iid"], "" if cfg["auto"] else " (chưa chạy - bấm Chạy khi sẵn sàng)"))
        popup("Triển khai từ backtest", txt, [("Huỷ", PANEL2, None), ("Triển khai", AMBER, go)], size=(0.92, 0.6))

    def _cfg(self, iid):
        return next((c for c in self.attach_cfgs if c["iid"] == iid), None)

    def toggle_instance(self, iid):
        cfg = self._cfg(iid)
        if cfg is None:
            return
        ctl = self.ctl_for(cfg)
        if ctl is not None and (cfg.get("account") or "main") != "main":
            cfg["auto"] = not cfg.get("auto", True)                        # tài khoản phụ: không có snapshot ở đây -> theo cờ auto
            (ctl.inst_start if cfg["auto"] else ctl.inst_stop)(iid)
            self._save_attach()
        elif self.is_connected():
            live = {i["iid"]: i for i in (self.last_snap or {}).get("instances", [])}
            i = live.get(iid)
            if i is None:
                self.ctl.attach(cfg, True)
            elif i["status"] in ("running", "starting"):
                self.ctl.inst_stop(iid)
            else:
                self.ctl.inst_start(iid)
        else:
            cfg["auto"] = not cfg.get("auto", True)
            self._save_attach()

    def reload_bot(self, iid):
        """Nạp lại mã file bot đang chạy mà KHÔNG dừng bot, vị thế/lệnh chờ giữ nguyên. Lỗi -> bản cũ chạy tiếp (xem Nhật ký)."""
        cfg = self._cfg(iid)
        if cfg is None:
            return
        live = {i["iid"] for i in (self.last_snap or {}).get("instances", [])} if self.is_connected() else set()
        if iid not in live:
            self.toast("Bot chưa chạy - lần chạy tới sẽ tự dùng mã mới nhất.")
            return
        (self.ctl_for(cfg) or self.ctl).reload_bot(iid)
        self.toast("Đang nạp lại %s - xem kết quả ở tab Nhật ký" % os.path.basename(cfg["bot_path"]))

    def toggle_trace(self, iid):
        """Bật/tắt Trace cho một bot: ghi vết callback + lệnh + api.trace() vào Nhật ký (mức TRACE)."""
        cfg = self._cfg(iid)
        if cfg is None:
            return
        cfg["trace"] = not cfg.get("trace")
        self._save_attach()
        live = {i["iid"] for i in (self.last_snap or {}).get("instances", [])} if self.is_connected() else set()
        if iid in live:
            (self.ctl_for(cfg) or self.ctl).set_trace(iid, cfg["trace"])
        self.toast("Trace %s cho %s%s" % ("BẬT" if cfg["trace"] else "TẮT", os.path.basename(cfg["bot_path"]),
                                         " - xem ở tab Nhật ký (mức TRACE)" if cfg["trace"] else ""))

    def remove_attachment(self, iid):
        cfg = self._cfg(iid)
        if cfg is None:
            return

        def go():
            ctl = self.ctl_for(cfg)
            if ctl is not None:
                ctl.detach(iid)
            self.attach_cfgs = [c for c in self.attach_cfgs if c["iid"] != iid]
            self._save_attach()
        confirm("Gỡ bot", "Gỡ %s khỏi %s? (lệnh đang mở của bot vẫn giữ nguyên, hãy đóng ở tab Giao dịch)" % (
            os.path.basename(cfg["bot_path"]), cfg["symbol"]), go, "Gỡ")

    def edit_params_dialog(self, iid):
        cfg = self._cfg(iid)
        info = self.get_info(cfg["bot_path"]) if cfg else None          # nạp lại nếu file bot đã đổi (vd AI vừa sửa)
        if cfg is None or info is None or not info.ok or not info.inputs:
            self.toast("Bot này không khai báo tham số (hoặc không nạp được). Dùng inputs={...}, Input(...) hoặc "
                       "thuộc tính có kiểu như `lot: float = 0.01  # Khối lượng`.")
            return

        def save(vals, apply=False):
            cfg["params"] = vals
            self.store.save_params(cfg["bot_path"], vals)
            self._save_attach()
            if apply and self.is_connected():
                live = {i["iid"] for i in (self.last_snap or {}).get("instances", [])}
                if iid in live:
                    (self.ctl_for(cfg) or self.ctl).set_params(iid, vals)
                    self.toast("Đã gửi tham số mới. Bot được khởi tạo lại (on_deinit 'params' → on_init), lệnh đang mở giữ nguyên.")
                else:
                    self.toast("Đã lưu. Bot chưa chạy nên tham số mới sẽ dùng khi bot chạy.")
            elif apply:
                self.toast("Đã lưu. Tham số sẽ dùng khi KẾT NỐI và chạy bot.")
        self.params_popup("Tham số: %s (%s %s)" % (info.name, cfg["symbol"], cfg["tf"]), info.inputs,
                          build_params(info.inputs, cfg.get("params")), cfg["bot_path"],
                          lambda v: save(v, False), lambda v: save(v, True))

    def show_instance_chart(self, iid):
        cfg = self._cfg(iid)
        if cfg:
            self.set_chart(cfg["symbol"], cfg["tf"])
            self.root_panel.switch_to(self.tabs["chart"])

    # ---------------------------------------------------------- thị trường / giao dịch thủ công
    def set_chart(self, sym, tf):
        self.chart_sym, self.chart_tf = sym, tf
        self._save_workspace()
        if self.ctl is not None and self.is_connected():
            self.ctl.set_chart(sym, tf)

    def symbol_menu(self, sym):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        pop = StyledPopup(title=sym, content=box, size_hint=(0.9, 0.62), auto_dismiss=True)

        def go(fn):
            return lambda *_: (pop.dismiss(), fn())
        box.add_widget(mkbtn("Xem biểu đồ", BLUE, on_release=go(lambda: (self.set_chart(sym, self.chart_tf), self.root_panel.switch_to(self.tabs["chart"])))))
        box.add_widget(mkbtn("Đặt lệnh thủ công", GREEN, on_release=go(lambda: self.open_order_dialog(sym))))
        box.add_widget(mkbtn("Gắn bot vào tài sản này", PANEL2, on_release=go(lambda: (setattr(self, "chart_sym", sym), self.open_attach_dialog()))))
        box.add_widget(mkbtn("Xoá khỏi danh sách theo dõi", RED, on_release=go(lambda: self._remove_watch(sym))))
        pop.open()

    def _remove_watch(self, sym):
        wl = [x for x in parse_watchlist(self.settings["watchlist"]) if x != sym]
        self._set_watchlist(wl)

    def _set_watchlist(self, wl):
        self.settings["watchlist"] = ",".join(wl)
        self.store.save_settings(self.settings)
        if self.settings_tab.gform:
            self.settings_tab.gform.set_values(self.settings)
        if self.is_connected():
            self.ctl.set_watch(wl)

    def add_symbol_dialog(self):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        ti = mk_input("", "Gõ mã, cách nhau dấu phẩy (vd BTCUSDT, EUR_USD)")
        box.add_widget(ti)
        info = wlabel("Gợi ý từ nguồn thị trường (chạm để thêm):", 11, MUTED)
        box.add_widget(info)
        lst = vbox(spacing=dp(3))
        box.add_widget(vscroll(lst))
        pop = StyledPopup(title="Thêm mã theo dõi", content=box, size_hint=(0.95, 0.85), auto_dismiss=False)
        allsyms = []

        def show(*_):
            lst.clear_widgets()
            last = ti.text.split(",")[-1].strip().upper()
            hits = [s for s in allsyms if last in s][:25]
            for s in hits:
                lst.add_widget(mkbtn(s, PANEL2, h=36, size=12, on_release=lambda *_, x=s: add(x)))

        def add(x):
            parts = [p.strip() for p in ti.text.split(",")[:-1] if p.strip()]
            ti.text = ", ".join(parts + [x]) + ", "
            show()

        @mainthread
        def loaded(syms, err):
            allsyms[:] = syms
            info.text = "Gợi ý từ nguồn thị trường (chạm để thêm):" if syms else "Không tải được danh sách (%s) - vẫn có thể gõ tay." % err
            show()

        def work():
            try:
                loaded(make_feed(self.settings["exchange"], self.settings).symbols(), "")
            except Exception as e:
                loaded([], str(e)[:80])
        threading.Thread(target=work, daemon=True).start()
        ti.bind(text=show)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def ok(*_):
            new = parse_watchlist(ti.text)
            if new:
                cur = parse_watchlist(self.settings["watchlist"])
                self._set_watchlist(cur + [x for x in new if x not in cur])
            pop.dismiss()
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Thêm", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def _default_vol(self, symbol):
        v = float(self.settings.get("default_volume") or 0.0)
        return ("%.10g" % v) if v > 0 else str(default_volume(symbol))

    def open_order_dialog(self, symbol=None):
        if not self.is_connected():
            self.toast("Hãy KẾT NỐI phiên trước (tab Bot hoặc Thị trường → KẾT NỐI) rồi đặt lệnh.")
            return
        syms = self._symbol_choices()
        sym0 = symbol or self.chart_sym or (syms[0] if syms else "BTCUSD")
        if sym0 not in syms:
            syms = syms + [sym0]
        TYPES = OrderedDict([("Thị trường", None), ("Limit (chờ giá tốt hơn)", "limit"), ("Stop (chờ phá giá)", "stop"),
                             ("Stop-limit", "stop_limit")])
        EXPS = OrderedDict([("Đến khi huỷ", 0), ("1 giờ", 3600), ("1 ngày", 86400), ("1 tuần", 7 * 86400)])
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        sp_sym = mk_spinner(sym0, syms)
        sp_type = mk_spinner("Thị trường", list(TYPES))
        price = flabel("", 13, TEXT, bold=True, size_hint_y=None, height=dp(26))
        vol = mk_input(self._default_vol(sym0))
        px, trig = mk_input("", "giá đặt (lệnh chờ)"), mk_input("", "giá kích hoạt")
        sp_exp = mk_spinner("Đến khi huỷ", list(EXPS))
        sl, tp = mk_input("", "để trống = không đặt"), mk_input("", "để trống = không đặt")
        form = vbox(spacing=dp(6))
        note = wlabel("", 11, MUTED)
        pop = StyledPopup(title="Đặt lệnh", content=box, size_hint=(0.95, 0.92), auto_dismiss=False)

        def kind():
            return TYPES.get(sp_type.text)

        def build_form(*_):
            form.clear_widgets()
            k = kind()
            rows = [("Tài sản", sp_sym), ("Loại lệnh", sp_type), ("Khối lượng", vol)]
            if k == "stop_limit":
                rows += [("Giá kích hoạt (stop)", trig), ("Giá limit", px)]
            elif k:
                rows += [("Giá đặt", px)]
            rows += [("Stop Loss (giá)", sl), ("Take Profit (giá)", tp)]
            if k:
                rows += [("Hết hạn", sp_exp)]
            for t, w in rows:
                form.add_widget(labeled(t, w))
            note.text = {None: "SL/TP là GIÁ tuyệt đối. Mua: SL < giá < TP. Bán: TP < giá < SL.",
                         "limit": "Buy limit đặt DƯỚI giá ask; Sell limit đặt TRÊN giá bid. Vỏ giữ chỗ ký quỹ cho lệnh chờ.",
                         "stop": "Buy stop đặt TRÊN giá ask; Sell stop đặt DƯỚI giá bid.",
                         "stop_limit": "Chạm giá kích hoạt thì thành lệnh limit tại giá limit (mua: limit ≤ kích hoạt; bán: limit ≥ kích hoạt)."}[k]
            form.height = dp(46 * len(rows))
        form.size_hint_y = None
        box.add_widget(form)
        box.add_widget(price)
        box.add_widget(note)

        def upd(*_):
            t = ((self.last_snap or {}).get("watch") or {}).get(sp_sym.text)
            price.text = (("Bid %s   Ask %s" % (fp(t["bid"]), fp(t["ask"]))) if t else "Giá: đang tải...")

        def pick(*_):
            vol.text = self._default_vol(sp_sym.text)
            upd()
        sp_sym.bind(text=pick)
        sp_type.bind(text=build_form)
        build_form()
        upd()

        def send(side):
            k = kind()
            try:
                v, slv, tpv = num(vol.text), num(sl.text), num(tp.text)
                p, tr = (num(px.text), num(trig.text)) if k else (0.0, 0.0)
            except ValueError as e:
                note.text, note.color = str(e), DOWN
                return
            if k and p <= 0:
                note.text, note.color = "Hãy nhập giá đặt cho lệnh chờ.", DOWN
                return
            if k == "stop_limit" and tr <= 0:
                note.text, note.color = "Stop-limit cần giá kích hoạt.", DOWN
                return
            t = ((self.last_snap or {}).get("watch") or {}).get(sp_sym.text)
            now = t["time"] if t else time.time()                       # giờ THỊ TRƯỜNG (tick), không phải giờ máy
            expiration = (now + EXPS[sp_exp.text]) if (k and EXPS[sp_exp.text]) else 0.0
            if slv <= 0 or tpv <= 0:                                    # ô SL/TP để trống -> dùng % mặc định trong Cài đặt (nếu có)
                ref = p if k else ((t["ask"] if side == "buy" else t["bid"]) if t else 0.0)
                d_sl, d_tp = default_stops(side, ref, self.settings.get("default_sl_pct"), self.settings.get("default_tp_pct"))
                slv = slv if slv > 0 else d_sl
                tpv = tpv if tpv > 0 else d_tp

            def do():
                if k:
                    status, res = self.ctl.place_pending(sp_sym.text, side, k, v, p, tr, slv, tpv, "thủ công", expiration)
                else:
                    status, res = self.ctl.place_order(sp_sym.text, side, v, slv, tpv, "thủ công")
                pop.dismiss()
                if status == "ok":
                    if k:
                        self.toast("Đã đặt lệnh chờ #%d %s %s %s @ %s" % (res.order.id, SIDE_VN[side], k, sp_sym.text, fp(res.price)))
                    else:
                        self.toast("Đã %s #%d %s %s @ %s" % (SIDE_VN[side], res.id, res.symbol, fmt_vol(res.volume, res.symbol), fp(res.open_price)))
                elif status == "sent":
                    self.toast("Đã gửi lệnh %s %s tới dịch vụ nền. Xem kết quả ở tab Giao dịch / Nhật ký." % (SIDE_VN[side], sp_sym.text))
                else:
                    self.toast("Không đặt được lệnh: %s" % (getattr(res, "message", "") or "xem lý do ở tab Nhật ký"))
            live = self.settings["mode"] == "live" and not self.settings["testnet"]
            label = "%s %s %s%s" % (SIDE_VN[side], vol.text, sp_sym.text, (" (%s @ %s)" % (k, px.text)) if k else "")
            if slv or tpv:
                label += " · SL %s · TP %s" % (fp(slv) if slv else "không", fp(tpv) if tpv else "không")
            if live:
                confirm("LỆNH THẬT", "%s trên tài khoản THẬT?" % label, do, "Đặt lệnh", RED)
            elif self.settings.get("confirm_trades", True):
                confirm("Xác nhận lệnh", "%s?" % label, do, "Đặt lệnh", RED if side == "sell" else GREEN)
            else:
                do()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Đóng", PANEL2, size_hint_x=0.6, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("BÁN", RED, on_release=lambda *_: send("sell")))
        row.add_widget(mkbtn("MUA", GREEN, on_release=lambda *_: send("buy")))
        box.add_widget(row)
        pop.open()

    def chart_order_send(self, sym, side, kind, price, sl, tp, on_done=None):
        """Gửi lệnh soạn trên biểu đồ: hỏi khối lượng -> xác nhận (lệnh THẬT nếu live) -> đặt như hộp «Đặt lệnh»."""
        if not self.is_connected():
            self.toast("Hãy KẾT NỐI phiên trước rồi đặt lệnh.")
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        vol = mk_input(self._default_vol(sym))
        label = "%s %s%s" % (SIDE_VN[side], sym, (" (%s @ %s)" % (kind, fp(price))) if kind else " (thị trường)")
        if sl or tp:
            label += " · SL %s · TP %s" % (fp(sl) if sl else "không", fp(tp) if tp else "không")
        box.add_widget(wlabel(label, 13, TEXT))
        box.add_widget(labeled("Khối lượng", vol))
        note = wlabel("", 11, MUTED)
        box.add_widget(note)
        pop = StyledPopup(title="Gửi lệnh từ biểu đồ", content=box, size_hint=(0.92, 0.5), auto_dismiss=False)

        def go(*_):
            try:
                v = num(vol.text)
            except ValueError as e:
                note.text, note.color = str(e), DOWN
                return
            if v <= 0:
                note.text, note.color = "Khối lượng phải lớn hơn 0.", DOWN
                return
            t = ((self.last_snap or {}).get("watch") or {}).get(sym)
            exp = 0.0

            def do():
                pop.dismiss()
                if kind:
                    status, res = self.ctl.place_pending(sym, side, kind, v, price, 0.0, sl, tp, "thủ công", exp)
                else:
                    status, res = self.ctl.place_order(sym, side, v, sl, tp, "thủ công")
                if status == "ok":
                    if kind:
                        self.toast("Đã đặt lệnh chờ #%d %s %s %s @ %s" % (res.order.id, SIDE_VN[side], kind, sym, fp(res.price)))
                    else:
                        self.toast("Đã %s #%d %s %s @ %s" % (SIDE_VN[side], res.id, res.symbol, fmt_vol(res.volume, res.symbol), fp(res.open_price)))
                    if on_done:
                        on_done()
                elif status == "sent":
                    self.toast("Đã gửi lệnh %s %s tới dịch vụ nền. Xem kết quả ở tab Giao dịch / Nhật ký." % (SIDE_VN[side], sym))
                    if on_done:
                        on_done()
                else:
                    self.toast("Không đặt được lệnh: %s" % (getattr(res, "message", "") or "xem lý do ở tab Nhật ký"))
            text = "%s, KL %s" % (label, vol.text)
            live = self.settings["mode"] == "live" and not self.settings["testnet"]
            if live:
                confirm("LỆNH THẬT", "%s trên tài khoản THẬT?" % text, do, "Đặt lệnh", RED)
            elif self.settings.get("confirm_trades", True):
                confirm("Xác nhận lệnh", "%s?" % text, do, "Đặt lệnh", RED if side == "sell" else GREEN)
            else:
                do()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Quay lại", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Gửi lệnh", RED if side == "sell" else GREEN, on_release=go))
        box.add_widget(row)
        pop.open()

    def open_modify_dialog(self, pid):
        p = next((x for x in (self.last_snap or {}).get("positions", []) if x.id == pid), None)
        if p is None:
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        sl = mk_input(("%.10g" % p.sl) if p.sl else "", "để trống = bỏ SL")
        tp = mk_input(("%.10g" % p.tp) if p.tp else "", "để trống = bỏ TP")
        box.add_widget(wlabel("#%d %s %s %s @ %s" % (p.id, p.symbol, SIDE_VN.get(p.side, p.side), fmt_vol(p.volume, p.symbol), fp(p.open_price)), 13, TEXT))
        box.add_widget(labeled("Stop Loss", sl))
        box.add_widget(labeled("Take Profit", tp))
        trails = (self.last_snap or {}).get("trails") or {}
        old_rule = trails.get(pid) or trails.get(str(pid)) or {}
        tr_d = mk_input(("%.10g" % old_rule["distance"]) if old_rule.get("distance") else "", "khoảng giá, vd 0.0020; trống = tắt")
        tr_be = mk_input(("%.10g" % old_rule["be_at"]) if old_rule.get("be_at") else "", "lãi bao nhiêu thì kéo SL về hòa vốn; trống = tắt")
        box.add_widget(labeled("Trailing Stop (khoảng giá)", tr_d))
        box.add_widget(labeled("Hòa vốn khi lãi ≥ (khoảng giá)", tr_be))
        msg = wlabel("", 11, MUTED)
        box.add_widget(msg)
        pop = StyledPopup(title="Sửa SL/TP / trailing / đóng một phần", content=box, size_hint=(0.92, 0.9), auto_dismiss=False)

        def part(frac):
            def do():
                pop.dismiss()
                res = self.ctl.close_position(pid, p.volume * frac)
                if res is not True and res is not None and not getattr(res, "ok", True):
                    self.toast("Không đóng được một phần: %s" % res.message)
            confirm("Đóng một phần", "Đóng %d%% (%s) của lệnh #%d theo giá thị trường?" % (frac * 100, fmt_vol(p.volume * frac, p.symbol), pid), do, "Đóng", RED)
        pr = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pr.add_widget(flabel("Chốt một phần:", 12, MUTED, size_hint_x=0.4))
        for f in (0.25, 0.5, 0.75):
            pr.add_widget(mkbtn("%d%%" % (f * 100), PANEL2, h=MIN_TOUCH, size=13, on_release=lambda *_, fr=f: part(fr)))
        box.add_widget(pr)

        def ok(*_):
            try:
                a, b = num(sl.text), num(tp.text)
                rule = {"distance": num(tr_d.text), "be_at": num(tr_be.text)}
                if old_rule:                                    # giữ các mục nâng cao (start/step/be_offset) nếu có
                    rule.update({k: v for k, v in old_rule.items() if k in ("start", "step", "be_offset")})
                from .trail import clean_rule
                new_rule = clean_rule(rule)
            except ValueError as e:
                msg.text, msg.color = str(e), DOWN
                return
            pop.dismiss()
            res = self.ctl.modify_position(pid, a, b)
            if res is not True and res is not None and not getattr(res, "ok", True):
                self.toast("Không sửa được: %s" % res.message)
            if (new_rule or None) != (old_rule or None):
                ok_, m_ = self.ctl.set_trailing(pid, new_rule)
                if not ok_:
                    self.toast("Trailing: %s" % m_)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def close_one(self, pid):
        if self.is_connected():
            confirm("Đóng lệnh", "Đóng lệnh #%d theo giá thị trường?" % pid, lambda: self.ctl.close_position(pid), "Đóng", RED)

    def close_all_positions(self, *_):
        if self.is_connected():
            confirm("Đóng tất cả lệnh", "Đóng toàn bộ lệnh đang mở (mọi tài sản) theo giá thị trường?",
                    lambda: self.ctl.request_close_all(), "Đóng hết")

    # ---------------------------------------------------------- vòng cập nhật
    def _net_step(self):
        net = getattr(self, "_net", None)
        if net is None:
            return
        online, changed = net.check()
        if changed and online:
            self._net_mute = False
        mode = self.settings.get("net_alert", "connected")
        allowed = mode == "always" or (mode == "connected" and self.is_connected())
        want = (not online) and allowed and not getattr(self, "_net_mute", False)
        was = getattr(self, "_net_warned", False)
        if want and not was:
            self.net_banner.height, self.net_banner.opacity = dp(34), 1
            self.log_tab.append([(0, time.time(), "ERROR", "MẤT KẾT NỐI MẠNG của thiết bị - giá/lệnh từ sàn thật sẽ không cập nhật được.")])
            try:
                if native.IS_ANDROID:
                    native.notify_alarm("Mất mạng", "Thiết bị mất kết nối mạng - giá/lệnh sàn thật không cập nhật.")
            except Exception:                                  # noqa: BLE001
                pass
        elif was and not want:
            self.net_banner.height, self.net_banner.opacity = 0, 0
            if online:
                self.log_tab.append([(0, time.time(), "INFO", "Đã có lại kết nối mạng.")])
        self._net_warned = want
        if want:
            d = int(time.time() - net.since)
            self.net_lbl.text = "⚠ MẤT MẠNG %d phút %02d giây - kiểm tra Wi-Fi/4G. (chạm để tắt cảnh báo)" % (d // 60, d % 60)

    def _net_banner_touch(self, w, touch):
        if w.height > 0 and w.collide_point(*touch.pos):
            self._net_mute = True
            return True
        return False

    def refresh(self, dt):
        t0 = time.perf_counter()
        try:
            self._net_step()
        except Exception:                                      # noqa: BLE001
            pass
        try:
            return self._refresh_inner(dt)
        finally:
            meter = getattr(self, "meter", None)
            if meter is not None:
                try:
                    meter.note_refresh(time.perf_counter() - t0)
                    st = getattr(self.ctl, "_state", None) if self.ctl is not None else None
                    meter.sample((st or {}).get("pid"), getattr(self.client, "state_path", None))
                except Exception:                                  # noqa: BLE001 - đo tải không được làm hỏng vòng cập nhật
                    pass

    def _refresh_inner(self, dt):
        self._fps_check()
        try:
            self.client.touch_ui()
        except OSError:
            pass
        tab = getattr(self, "settings_tab", None)
        if tab is not None:
            tab.refresh_dnd()                           # nhãn «Không làm phiền» tự cập nhật khi hết hạn (đã giới hạn 5 giây/lần)
        c = self.ctl
        if isinstance(c, ServiceHandle):
            self._service_watch(c)
            c = self.ctl
        alive = bool(c and c.is_alive())
        snap = c.snapshot() if c else None
        if snap is not None:
            self.last_snap = snap
            prefs.set_contracts(snap.get("contracts"))
        if c:
            new = c.get_logs(self.log_cursor)
            if new:
                self.log_cursor = new[-1][0]
                self.log_tab.append(new)
        if self._was_alive and not alive:
            self._on_finished()
        self._was_alive = alive
        st = getattr(self, "_stop_t", None)
        if st:
            if not alive:
                self._stop_t = None
                self.toast("Đã ngắt kết nối.")
            elif time.time() - st > 10 and not getattr(self, "_stop_warned", False):
                self._stop_warned = True
                confirm("Chưa ngắt được", "Đã gửi lệnh ngắt hơn 10 giây mà phiên vẫn chạy (có thể đang chờ mạng/sàn trả lời). Chờ thêm, hoặc BUỘC DỪNG dịch vụ nền? "
                        "Buộc dừng sẽ tắt ngay mọi bot; vị thế đang mở trên sàn thật vẫn giữ nguyên - hãy kiểm tra lại trên sàn.",
                        lambda: self._force_stop(), yes_text="Buộc dừng", yes_color=RED)
        self.attach_tab.set_running(alive)
        # Tab đang ẨN không cần vẽ lại mỗi giây: khi người dùng chuyển tab, `_catch_up` cập nhật ngay nên nhìn thấy đúng dữ liệu mới nhất.
        if self.tab_visible("market"):
            self.market_tab.update(snap)
        if self.tab_visible("trade"):
            self.trade_tab.update(self.last_snap)
        self.attach_tab.update(snap, alive)
        choices = self._symbol_choices()
        if self.chart_sym is None and choices:
            self.chart_sym = choices[0]
        self.chart_tab.set_choices(choices, self.chart_sym, self.chart_tf)
        ch, evs = None, []
        if c and alive and self.chart_sym:
            c.set_chart(self.chart_sym, self.chart_tf)
            if self.tab_visible("chart"):
                ch = c.chart(self.chart_sym, self.chart_tf)
                evs = c.events()
        if self.tab_visible("chart"):
            self.chart_tab.update(snap, ch, evs)
        if self.tab_visible("ai"):
            self.ai_tab.update()

    IDLE_FPS, IDLE_AFTER_S = 20.0, 15.0

    def _fps_init(self):
        self._last_touch = time.time()
        self._fps_full = None
        self._fps_low = False
        try:
            Window.bind(on_motion=self._on_motion)
        except Exception:                                       # noqa: BLE001
            pass

    def _on_motion(self, *_):
        self._last_touch = time.time()
        if getattr(self, "_fps_low", False):
            self._set_fps(False)

    def _set_fps(self, low):
        """Hạ/khôi phục tốc độ khung của đồng hồ Kivy (Clock._max_fps, đọc lại mỗi vòng idle). Không có thuộc tính này thì không làm gì."""
        try:
            if not hasattr(Clock, "_max_fps"):
                return
            if self._fps_full is None:
                self._fps_full = float(Clock._max_fps) or 60.0
            Clock._max_fps = self.IDLE_FPS if low else self._fps_full
            self._fps_low = bool(low)
        except Exception:                                       # noqa: BLE001
            pass

    def _fps_check(self):
        want = bool(self.settings.get("idle_fps_save", True)) and (time.time() - getattr(self, "_last_touch", time.time()) > self.IDLE_AFTER_S)
        if want != getattr(self, "_fps_low", False):
            self._set_fps(want)

    def tab_visible(self, key):
        """Tab `key` đang hiển thị? Không xác định được (chưa dựng, chạy thử...) thì coi là CÓ (an toàn: cập nhật như cũ)."""
        if not getattr(self, "lazy_tabs", True):
            return True
        rp, tabs = getattr(self, "root_panel", None), getattr(self, "tabs", None)
        cur = getattr(rp, "current_tab", None) if rp is not None else None
        if not tabs or key not in tabs or cur is None:
            return True
        return cur is tabs[key]

    def _catch_up(self, *_):
        """Vừa chuyển tab: cập nhật ngay tab mới thay vì đợi vòng sau."""
        try:
            self._refresh_inner(0)
        except Exception:                                       # noqa: BLE001 - lỗi vẽ một tab không được làm văng app
            pass

    def _on_finished(self):
        android_utils.set_keep_awake(False)
        fin = self.ctl.finished_state() if self.ctl else None
        if fin and fin[0] == "error":
            popup("Phiên đã dừng vì lỗi", (fin[1] or "")[:900], size=(0.95, 0.6), color=DOWN)

    # ---------------------------------------------------------- dịch vụ nền: theo dõi / báo động
    def _service_watch(self, h):
        if h.failed_to_start():
            self.log_tab.append([(0, time.time(), "ERROR", "Dịch vụ nền không phản hồi -> chạy trực tiếp trong app")])
            native.notify_alarm("PyEA: dịch vụ nền không phản hồi", "Phiên được chạy trực tiếp trong app (sẽ dừng nếu bạn thoát app).")
            self.client.pop_commands()
            if self._last_config:
                self._start_local(self._last_config)
            return
        if h.crashed() and h.expect_running:
            self._watchdog_restart()
        for a in h.alarms():
            if a["t"] > self._alarm_seen:
                self._alarm_seen = a["t"]
                self.log_tab.append([(0, a["t"], "ERROR", "CẢNH BÁO%s: %s - %s" % (" (im lặng - đang không làm phiền)" if a.get("quiet") else "", a["title"], a["text"]))])
                if not a.get("quiet"):
                    popup(a["title"], a["text"], size=(0.92, 0.4), color=AMBER)

    def _watchdog_restart(self):
        now = time.time()
        self._restarts = [t for t in self._restarts if now - t < 600]
        if len(self._restarts) >= 3:
            return
        self._restarts.append(now)
        self.log_tab.append([(0, now, "ERROR", "Dịch vụ nền ngừng phản hồi -> đang khởi động lại và khôi phục phiên")])
        native.notify_alarm("PyEA: dịch vụ nền ngừng phản hồi", "Đang tự khởi động lại và khôi phục phiên...")
        native.start_service(json.dumps({"data_dir": self.data_dir}), "PyEA Runner", "Đang khôi phục phiên...")

    # ---------------------------------------------------------- AI
    def _hub_snapshot(self):
        c = self.ctl
        return c.market_view() if c is not None else {"ready": False}

    def _hub_bot(self):
        path = self.selected or (self.attach_cfgs[0]["bot_path"] if self.attach_cfgs else None)
        if not path:
            return None
        info = self.get_info(path)
        try:
            with open(path, "r", encoding="utf-8") as f:
                src = f.read()
        except OSError:
            return None
        params = build_params(info.inputs, self.store.load_params(path)) if info and info.ok else {}
        return (info.name if info and info.ok else os.path.basename(path), src, params)

    def ai_info(self):
        c = self.ctl
        if c is not None and c.is_alive():
            return c.ai_info()
        h = self.hub
        return {"auto_on": h.auto_on, "signal": h.get_signal(), "status": h.status_text, "busy": h.busy}

    def toggle_ai_auto(self):
        c = self.ctl
        if c is not None and c.is_alive():
            c.set_ai_auto(not self.ai_info().get("auto_on"))
        elif self.hub.auto_on:
            self.hub.stop_auto()
        else:
            self.hub.start_auto()

    # ---------------------------------------------------------- popup lý do vào/ra lệnh
    def show_event(self, ev, events=None):
        if events is None:
            events = self.ctl.events() if self.ctl else [ev]
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(6), padding=dp(4))
        for title, body in explain.describe_event(ev, events):
            box.add_widget(flabel(escape_markup(title), 12, AMBER, bold=True, size_hint_y=None, height=dp(26)))
            add_text_block(box, body, 12)
        content.add_widget(vscroll(box))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = StyledPopup(title=explain.event_title(ev), content=content, size_hint=(0.97, 0.92), auto_dismiss=False)
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(explain.describe_text(ev, events))))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        content.add_widget(row)
        pop.open()

    # ---------------------------------------------------------- kiểm tra hệ thống
    def run_diagnostics(self):
        self.toast("Đang kiểm tra hệ thống (vài giây)...")

        def work():
            try:
                res = diagnostics.run_checks(self.data_dir, self.settings, self.store)
            except Exception:
                res = [{"name": "Kiểm tra", "status": "LỖI", "detail": traceback.format_exc(limit=2)}]
            self._show_diag(res)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _show_diag(self, results):
        text = diagnostics.format_report(results)
        self._last_diag = text                                  # Trợ lý đọc được (khi bạn bật «Cho Trợ lý xem trạng thái»)
        try:
            with open(os.path.join(self.data_dir, "diagnostics.txt"), "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            pass
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(4))
        col = {"OK": UP, "CHÚ Ý": AMBER, "LỖI": DOWN}
        for r in results:
            add_text_block(box, "[%s] %s: %s" % (r["status"], r["name"], r["detail"]), 12, col.get(r["status"], TEXT))
        content.add_widget(vscroll(box))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = StyledPopup(title="Kiểm tra hệ thống", content=content, size_hint=(0.97, 0.9), auto_dismiss=False)
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(text), size=12))
        if native.IS_ANDROID:
            row.add_widget(mkbtn("Tối ưu pin", AMBER, on_release=lambda *_: native.request_ignore_battery_optimizations(), size=12))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss(), size=12))
        content.add_widget(row)
        pop.open()

    def open_agents(self):
        hub = self.hub
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        lst = vbox(spacing=dp(4))
        pop = StyledPopup(title="Quản lý AI", content=content, size_hint=(0.95, 0.85), auto_dismiss=False)

        def rebuild():
            lst.clear_widgets()
            if not hub.agents:
                lst.add_widget(wlabel("Chưa có AI nào. Bấm 'Thêm AI', chọn nhà cung cấp và dán API key. "
                                      "Nên ưu tiên model miễn phí hoặc model tài chính chuyên biệt "
                                      "(chạy qua 'Máy chủ riêng' / 'Tuỳ chỉnh').", 12, MUTED))
            for i, a in enumerate(hub.agents):
                txt = "%s%s\n[size=11sp][color=%s]%s | %s%s[/color][/size]" % (
                    escape_markup(a["name"]), "" if a.get("enabled", True) else "  (tắt)", hexc(MUTED),
                    escape_markup(a["preset"]), escape_markup(a.get("model") or "(model mặc định)"),
                    " | chốt quyết định" if a.get("decider") else "")
                b = mkbtn(txt, PANEL2, h=58, on_release=lambda *_, i=i: edit(i), markup=True)
                b.halign = "left"
                b.bind(size=lambda w, s: setattr(w, "text_size", (s[0] - dp(16), s[1])))
                lst.add_widget(b)
            self.ai_tab.refresh_agents()

        def edit(idx):
            new = idx is None
            agent = default_agent(len(hub.agents) + 1) if new else dict(hub.agents[idx])
            form = ParamForm(AGENT_INPUTS, agent)
            box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
            note = wlabel("", 11, MUTED)
            res = wlabel("", 12, AMBER)

            def upd_note(*_):
                note.text = escape_markup(PRESETS.get(form.ctrl["preset"].text, {}).get("note", ""))
            form.ctrl["preset"].bind(text=upd_note)
            upd_note()
            inner = vbox(spacing=dp(4))
            inner.add_widget(note)
            inner.add_widget(form)
            inner.add_widget(res)
            box.add_widget(vscroll(inner))
            ep = StyledPopup(title="Thêm AI" if new else "Sửa AI", content=box, size_hint=(0.97, 0.92), auto_dismiss=False)

            def collect():
                vals, errs = form.read()
                if errs:
                    res.text = "[color=%s]%s[/color]" % (hexc(DOWN), escape_markup("\n".join(errs)))
                    return None
                if not vals["name"].strip():
                    res.text = "Tên không được để trống"
                    return None
                for j, a in enumerate(hub.agents):
                    if a["name"] == vals["name"] and j != idx:
                        res.text = "Tên bị trùng"
                        return None
                return vals

            def save(*_):
                vals = collect()
                if vals is None:
                    return
                agents = list(hub.agents)
                if new:
                    agents.append(vals)
                else:
                    agents[idx] = vals
                if vals.get("decider"):          # chỉ 1 AI chốt quyết định
                    for a in agents:
                        if a is not vals:
                            a["decider"] = False
                hub.set_agents(agents)
                ep.dismiss()
                rebuild()

            def test(*_):
                vals = collect()
                if vals is None:
                    return
                res.text = "Đang thử kết nối..."

                def work():
                    ok, msg = hub.test_agent(vals)
                    self._set_text(res, ("[color=%s]OK: %s[/color]" % (hexc(UP), escape_markup(msg))) if ok else
                                   ("[color=%s]Lỗi: %s[/color]" % (hexc(DOWN), escape_markup(msg))))
                threading.Thread(target=work, daemon=True).start()

            def delete(*_):
                agents = [a for j, a in enumerate(hub.agents) if j != idx]
                hub.set_agents(agents)
                ep.dismiss()
                rebuild()
            row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
            row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: ep.dismiss(), size=12))
            row.add_widget(mkbtn("Thử", BLUE, on_release=test, size=12))
            if not new:
                row.add_widget(mkbtn("Xoá", RED, on_release=delete, size=12))
            row.add_widget(mkbtn("Lưu", GREEN, on_release=save, size=12))
            box.add_widget(row)
            ep.open()

        content.add_widget(vscroll(lst))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Thêm AI", GREEN, on_release=lambda *_: edit(None)))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        content.add_widget(row)
        rebuild()
        pop.open()

    @mainthread
    def _set_text(self, widget, text):
        widget.text = text

    def review_code(self, msg):
        code = extract_bot_code(msg["text"])
        if not code:
            return
        ok, info = check_bot_code(code)
        old = ""
        if self.selected:
            try:
                with open(self.selected, "r", encoding="utf-8") as f:
                    old = f.read()
            except OSError:
                pass
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        content.add_widget(wlabel(escape_markup(info), 13, UP if ok else DOWN))
        box = vbox(spacing=dp(0))
        for ln in make_diff(old, code):
            col = UP if ln.startswith("+") and not ln.startswith("+++") else \
                DOWN if ln.startswith("-") and not ln.startswith("---") else AMBER if ln.startswith("@@") else MUTED
            box.add_widget(wlabel(escape_markup(ln[:160]), 10, col))
        content.add_widget(vscroll(box))
        pop = StyledPopup(title="Thay đổi AI đề xuất", content=content, size_hint=(0.97, 0.92), auto_dismiss=False)

        def new_ver(*_):
            path = save_new_version(self.store.bots_dir, self.selected, code)
            pop.dismiss()
            self.refresh_bots(select=path)
            self.select_bot(path)
            self.toast("Đã lưu thành bot mới: %s" % os.path.basename(path))

        def overwrite(*_):
            if not self.selected:
                return
            if self._bot_in_use(self.selected):
                self.toast("Bot này đang chạy trong phiên. Hãy ngắt phiên hoặc gỡ bot trước khi ghi đè.")
                return
            overwrite_with_backup(self.selected, code)
            pop.dismiss()
            self._info_cache.pop(self.selected, None)
            self.refresh_bots()
            self.select_bot(self.selected)
            self.toast("Đã ghi đè (bản cũ lưu ở .bak).")

        def send_err(*_):
            pop.dismiss()
            hub = self.hub
            if msg["who"] in [a["name"] for a in hub.agents]:
                hub.ask_single(msg["who"], "Code bạn đưa bị lỗi: %s\nHãy sửa và trả lại TOÀN BỘ file." % info)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss(), size=12))
        if ok:
            row.add_widget(mkbtn("Lưu bản mới", GREEN, on_release=new_ver, size=12))
            row.add_widget(mkbtn("Ghi đè", AMBER, on_release=overwrite, size=12))
        else:
            row.add_widget(mkbtn("Gửi lỗi cho AI", BLUE, on_release=send_err, size=12))
        content.add_widget(row)
        pop.open()
