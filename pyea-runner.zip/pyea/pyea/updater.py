"""Kiểm tra bản cập nhật qua GitHub Releases (mặc định TẮT, chỉ khi người dùng nhập kho `chủ/tên`). KHÔNG import Kivy. KHÔNG tự cài:
Android bắt người dùng tự bấm cài APK, nên app chỉ báo «có bản mới» + mở trang tải. Chỉ gọi API công khai (GET), không gửi gì ngoài yêu cầu HTTPS thông thường."""
import re

from .feeds import FeedError, HttpError, http_json

API_BASE = "https://api.github.com"
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")


def parse_version(text):
    """«v1.9.13», «1.10.0-rc1» -> (1, 9, 13). Không đọc được -> None."""
    m = re.match(r"^\s*[vV]?(\d+)(?:\.(\d+))?(?:\.(\d+))?", str(text or ""))
    return tuple(int(x or 0) for x in m.groups()) if m else None


def is_newer(latest, current):
    a, b = parse_version(latest), parse_version(current)
    return bool(a and b and a > b)


def check(repo, current, api_base=API_BASE, http=http_json, timeout=10):
    """-> {"status": "newer"|"current"|"none"|"error", "latest", "url", "notes", "apk", "message"}. Không bao giờ ném lỗi."""
    repo = str(repo or "").strip()
    if not REPO_RE.match(repo):
        return {"status": "error", "message": "Kho cập nhật phải có dạng «chủ/tên», vd nguoidung/TradingBot-APK"}
    try:
        d = http(api_base.rstrip("/") + "/repos/%s/releases/latest" % repo, headers={"Accept": "application/vnd.github+json", "User-Agent": "PyEA-Runner"}, timeout=timeout)
    except HttpError as e:
        if getattr(e, "status", 0) == 404:
            return {"status": "none", "message": "Kho này chưa có bản phát hành (Releases) nào."}
        return {"status": "error", "message": "Không kiểm tra được (HTTP %s)" % getattr(e, "status", "?")}
    except (FeedError, OSError, ValueError) as e:
        return {"status": "error", "message": "Không kiểm tra được: %s" % e}
    if not isinstance(d, dict) or not d.get("tag_name"):
        return {"status": "error", "message": "Phản hồi không đúng định dạng GitHub Releases"}
    if d.get("draft") or d.get("prerelease"):
        return {"status": "none", "message": "Bản phát hành mới nhất là bản nháp/thử nghiệm - bỏ qua."}
    apk = ""
    for a in d.get("assets") or []:
        if isinstance(a, dict) and str(a.get("name", "")).lower().endswith(".apk") and str(a.get("browser_download_url", "")).startswith("https://"):
            apk = a["browser_download_url"]
            break
    out = {"latest": str(d["tag_name"]), "url": str(d.get("html_url") or ""), "notes": str(d.get("body") or "")[:1500], "apk": apk}
    if parse_version(d["tag_name"]) is None:
        return dict(out, status="error", message="Không đọc được số phiên bản «%s»" % d["tag_name"])
    return dict(out, status="newer" if is_newer(d["tag_name"], current) else "current", message="")
