"""Nguồn giá THẬT không cần tài khoản/API (chỉ để xem biểu đồ, chạy bot ở chế độ paper, backtest), CÓ NGUỒN DỰ PHÒNG TỰ ĐỘNG:
  - crypto (BTCUSDT, BTCUSD, ETHUSD...): Binance -> Bybit -> OKX -> Coinbase -> Kraken (API công khai, không khoá);
  - vàng/forex/chỉ số/cổ phiếu: Yahoo Finance -> Twelve Data (nếu có khoá miễn phí) -> riêng vàng: PAXG/USDT của Binance (token vàng 24/7, giá sát vàng giao ngay).
  Nguồn nào lỗi thì bị «nghỉ» 60 giây rồi thử lại; `PublicFeed.active[mã]` cho biết nguồn đang dùng.
Lưu ý: Yahoo không có hợp đồng API chính thức (có thể đổi/chặn bất cứ lúc nào) và giá forex/vàng ở đây là giá tham chiếu, KHÔNG phải giá khớp của sàn bạn giao dịch
-> chỉ dùng để quan sát/thử bot; không dùng để đặt lệnh thật (chế độ live bị chặn với nguồn này).
Không scrape TradingView: điều khoản của họ cấm và giao thức không công khai, dễ vỡ/bị chặn."""
import calendar
import re
import time

from .feeds import BinanceFeed, FeedError, history_resampled, http_json, tf_seconds
from .ratelimit import limiter_for
from .sdk import Candle, Tick

CRYPTO = {"BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "DOGE", "LTC", "DOT", "AVAX", "LINK", "MATIC", "TRX", "BCH", "ATOM", "NEAR", "UNI"}
_QUOTES = ("USDT", "USDC", "FDUSD", "BUSD")
YAHOO_HOSTS = ("https://query1.finance.yahoo.com", "https://query2.finance.yahoo.com")
BINANCE_HOSTS = ("https://api.binance.com", "https://data-api.binance.vision")
UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36", "Accept": "application/json"}

# khung có sẵn ở Yahoo (khung khác được ghép từ khung nhỏ hơn)
YAHOO_INT = {"1m": "1m", "2m": "2m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "60m", "1d": "1d", "1w": "1wk", "1mo": "1mo"}
_MAX_LOOKBACK = {"1m": 7 * 86400, "2m": 59 * 86400, "5m": 59 * 86400, "15m": 59 * 86400, "30m": 59 * 86400, "1h": 729 * 86400}

YAHOO_ALIAS = {"US500": "^GSPC", "SPX500": "^GSPC", "SPX500_USD": "^GSPC", "US30": "^DJI", "NAS100": "^NDX", "US100": "^NDX", "GER40": "^GDAXI",
               "UK100": "^FTSE", "JP225": "^N225", "OIL": "CL=F", "USOIL": "CL=F", "WTI": "CL=F", "XTIUSD": "CL=F", "XBRUSD": "BZ=F",
               "XAUUSD": "GC=F", "GOLD": "GC=F", "XAGUSD": "SI=F", "SILVER": "SI=F", "DXY": "DX-Y.NYB"}
FX = {"EUR", "USD", "GBP", "JPY", "AUD", "NZD", "CAD", "CHF", "SGD", "HKD", "CNH", "MXN", "ZAR", "TRY", "SEK", "NOK", "VND"}


def route(symbol):
    """-> ("binance", mã Binance) | ("yahoo", mã Yahoo)."""
    s = str(symbol).strip().upper().replace("/", "").replace("_", "")
    if re.search(r"[\^=\-.]", str(symbol)):                      # mã Yahoo dạng ^GSPC, EURUSD=X, BTC-USD
        return "yahoo", str(symbol).strip()
    for q in _QUOTES:
        if s.endswith(q) and len(s) > len(q):
            return "binance", s
    if s.endswith("USD") and s[:-3] in CRYPTO:
        return "binance", s[:-3] + "USDT"
    if s in YAHOO_ALIAS:
        return "yahoo", YAHOO_ALIAS[s]
    if len(s) == 6 and s[:3] in FX and s[3:] in FX:
        return "yahoo", s + "=X"
    return "yahoo", s                                              # cổ phiếu, ETF...


def parse_yahoo(d, symbol=""):
    """-> (list Candle, meta). Bỏ nến thiếu giá (Yahoo trả None)."""
    try:
        res = d["chart"]["result"][0]
        ts = res.get("timestamp") or []
        q = res["indicators"]["quote"][0]
        meta = res.get("meta") or {}
    except (KeyError, IndexError, TypeError):
        err = ((d or {}).get("chart") or {}).get("error") if isinstance(d, dict) else None
        raise FeedError("Yahoo không có dữ liệu cho %s%s" % (symbol, (": " + str(err.get("description"))) if err else ""))
    out = []
    for i, t in enumerate(ts):
        try:
            o, h, l, c = q["open"][i], q["high"][i], q["low"][i], q["close"][i]
        except (KeyError, IndexError, TypeError):
            continue
        if None in (o, h, l, c):
            continue
        v = (q.get("volume") or [0] * len(ts))[i] or 0
        out.append(Candle(float(t), float(o), float(h), float(l), float(c), float(v)))
    return out, meta


_TD_INT = {"1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1h", "2h": "2h", "4h": "4h", "1d": "1day", "1w": "1week", "1mo": "1month"}


def split_crypto(code):
    for q in _QUOTES:
        if code.endswith(q) and len(code) > len(q):
            return code[:-len(q)], q
    return code, "USDT"


def _f(x):
    return float(x)


def _iso(t):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))


class _Src:
    """Một nguồn giá. Giao diện như feed: tick(code) / history(code, tf, n, end); `native` = khung gốc -> tham số nguồn."""
    name = "?"
    native = {}
    max_chunk = 300
    host = ""

    def __init__(self):
        self.limiter = limiter_for(self.name.lower(), self.host)

    def get(self, path, params=None):
        return http_json(self.host + path, params, headers=UA, limiter=self.limiter, cost=1)

    def history(self, code, tf, n, end=None):
        tf_seconds(tf)
        if tf not in self.native:
            return history_resampled(self, self.native, code, tf, n, end)
        rows = self.fetch(code, tf, max(2, min(int(n), self.max_chunk)), end)
        rows.sort(key=lambda c: c.time)
        if end is not None:
            rows = [c for c in rows if c.time < end]
        return rows[-int(n):]


class BinanceSrc(_Src):
    name = "Binance"
    max_chunk = 1000

    def __init__(self):
        self._f = {}

    def _feed(self, h):
        if h not in self._f:
            self._f[h] = BinanceFeed(h)
        return self._f[h]

    def _try(self, fn):
        last = None
        for h in BINANCE_HOSTS:
            try:
                return fn(self._feed(h))
            except FeedError as e:
                last = e
        raise last or FeedError("Không kết nối được Binance")

    @property
    def native(self):
        from .feeds import _BINANCE_INT
        return _BINANCE_INT

    def tick(self, code):
        t = self._try(lambda f: f.tick(code))
        return t

    def history(self, code, tf, n, end=None):
        return self._try(lambda f: f.history(code, tf, n, end))


class BybitSrc(_Src):
    name = "Bybit"
    host = "https://api.bybit.com"
    max_chunk = 1000
    native = {"1m": "1", "3m": "3", "5m": "5", "15m": "15", "30m": "30", "1h": "60", "2h": "120", "4h": "240", "6h": "360", "12h": "720",
              "1d": "D", "1w": "W", "1mo": "M"}

    def _sym(self, code):
        b, _ = split_crypto(code)
        return b + "USDT"

    def tick(self, code):
        d = self.get("/v5/market/tickers", {"category": "spot", "symbol": self._sym(code)})
        try:
            r = d["result"]["list"][0]
            return Tick(code, time.time(), _f(r["bid1Price"]), _f(r["ask1Price"]))
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("Bybit: giá không hợp lệ")

    def fetch(self, code, tf, n, end):
        params = {"category": "spot", "symbol": self._sym(code), "interval": self.native[tf], "limit": n}
        if end is not None:
            params["end"] = int(end * 1000) - 1
        d = self.get("/v5/market/kline", params)
        try:
            return [Candle(_f(r[0]) / 1000.0, _f(r[1]), _f(r[2]), _f(r[3]), _f(r[4]), _f(r[5])) for r in d["result"]["list"]]
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("Bybit: nến không hợp lệ")


class OkxSrc(_Src):
    name = "OKX"
    host = "https://www.okx.com"
    max_chunk = 300
    native = {"1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6Hutc",
              "12h": "12Hutc", "1d": "1Dutc", "1w": "1Wutc", "1mo": "1Mutc"}

    def _sym(self, code):
        b, _ = split_crypto(code)
        return b + "-USDT"

    def tick(self, code):
        d = self.get("/api/v5/market/ticker", {"instId": self._sym(code)})
        try:
            r = d["data"][0]
            return Tick(code, time.time(), _f(r["bidPx"]), _f(r["askPx"]))
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("OKX: giá không hợp lệ")

    def fetch(self, code, tf, n, end):
        params = {"instId": self._sym(code), "bar": self.native[tf], "limit": n}
        if end is not None:
            params["after"] = int(end * 1000)                      # trả các nến CŨ HƠN mốc này
        d = self.get("/api/v5/market/candles", params)
        try:
            return [Candle(_f(r[0]) / 1000.0, _f(r[1]), _f(r[2]), _f(r[3]), _f(r[4]), _f(r[5])) for r in d["data"]]
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("OKX: nến không hợp lệ")


class CoinbaseSrc(_Src):
    name = "Coinbase"
    host = "https://api.exchange.coinbase.com"
    max_chunk = 300
    native = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600, "6h": 21600, "1d": 86400}

    def _sym(self, code):
        b, _ = split_crypto(code)
        return b + "-USD"                                           # Coinbase niêm yết theo USD (xấp xỉ USDT)

    def tick(self, code):
        d = self.get("/products/%s/ticker" % self._sym(code))
        try:
            return Tick(code, time.time(), _f(d["bid"]), _f(d["ask"]))
        except (KeyError, TypeError, ValueError):
            raise FeedError("Coinbase: giá không hợp lệ")

    def fetch(self, code, tf, n, end):
        g = self.native[tf]
        t2 = int(end if end is not None else time.time() + g)
        d = self.get("/products/%s/candles" % self._sym(code), {"granularity": g, "start": _iso(t2 - n * g), "end": _iso(t2)})
        try:
            return [Candle(_f(r[0]), _f(r[3]), _f(r[2]), _f(r[1]), _f(r[4]), _f(r[5])) for r in d]      # [time, low, high, open, close, volume]
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("Coinbase: nến không hợp lệ")


class KrakenSrc(_Src):
    name = "Kraken"
    host = "https://api.kraken.com"
    max_chunk = 720
    native = {"1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440}
    _ALIAS = {"BTC": "XBT", "DOGE": "XDG"}

    def _sym(self, code):
        b, _ = split_crypto(code)
        return self._ALIAS.get(b, b) + "USD"

    def _result(self, d):
        if isinstance(d, dict) and d.get("error"):
            raise FeedError("Kraken: %s" % d["error"])
        res = (d or {}).get("result") or {}
        for k, v in res.items():
            if k != "last":
                return v
        raise FeedError("Kraken: không có dữ liệu")

    def tick(self, code):
        r = self._result(self.get("/0/public/Ticker", {"pair": self._sym(code)}))
        try:
            return Tick(code, time.time(), _f(r["b"][0]), _f(r["a"][0]))
        except (KeyError, IndexError, TypeError, ValueError):
            raise FeedError("Kraken: giá không hợp lệ")

    def fetch(self, code, tf, n, end):
        rows = self._result(self.get("/0/public/OHLC", {"pair": self._sym(code), "interval": self.native[tf]}))     # tối đa 720 nến GẦN NHẤT
        try:
            return [Candle(_f(r[0]), _f(r[1]), _f(r[2]), _f(r[3]), _f(r[4]), _f(r[6])) for r in rows][:-1] or []       # bỏ nến đang chạy (chưa chốt)
        except (IndexError, TypeError, ValueError):
            raise FeedError("Kraken: nến không hợp lệ")


class YahooSrc(_Src):
    name = "Yahoo"
    native = YAHOO_INT
    max_chunk = 1000

    def __init__(self):
        self.limiter = limiter_for("yahoo", YAHOO_HOSTS[0], rules=[(100, 60.0)])

    def _chart(self, ysym, params):
        last = None
        for h in YAHOO_HOSTS:
            try:
                return http_json("%s/v8/finance/chart/%s" % (h, ysym.replace("^", "%5E")), params, headers=UA, limiter=self.limiter, cost=1)
            except FeedError as e:                                 # HttpError là con của FeedError
                last = e
        raise last or FeedError("Không kết nối được Yahoo Finance")

    def tick(self, code):
        d = self._chart(code, {"interval": "1m", "range": "1d"})
        cs, meta = parse_yahoo(d, code)
        px = meta.get("regularMarketPrice") or (cs[-1].close if cs else None)
        if px is None:
            raise FeedError("Yahoo: chưa có giá %s" % code)
        return Tick(code, time.time(), float(px), float(px))

    def history(self, code, tf, n, end=None):
        tf_seconds(tf)
        n = max(2, int(n))
        if tf not in YAHOO_INT:
            return history_resampled(self, YAHOO_INT, code, tf, n, end)
        step = tf_seconds(tf)
        t2 = int(end if end is not None else time.time() + step)
        span = min(int(n * step * 1.6) + 3 * 86400, _MAX_LOOKBACK.get(tf, 10 ** 10))
        d = self._chart(code, {"interval": YAHOO_INT[tf], "period1": max(0, t2 - span), "period2": t2, "includePrePost": "false"})
        cs, _ = parse_yahoo(d, code)
        if end is not None:
            cs = [c for c in cs if c.time < end]
        return cs[-n:]


class TwelveDataSrc(_Src):
    name = "TwelveData"
    host = "https://api.twelvedata.com"
    native = _TD_INT
    max_chunk = 1000

    def __init__(self, key):
        self.key = key
        self.limiter = limiter_for("twelvedata", self.host, rules=[(7, 60.0)])      # gói miễn phí: 8 yêu cầu/phút

    @staticmethod
    def symbol(user_sym):
        s = str(user_sym).strip().upper().replace("/", "").replace("_", "")
        if s in ("XAUUSD", "GOLD"):
            return "XAU/USD"
        if s == "XAGUSD":
            return "XAG/USD"
        if len(s) == 6 and s[:3] in FX and s[3:] in FX:
            return s[:3] + "/" + s[3:]
        if s.isalpha() and 1 <= len(s) <= 5 and s not in YAHOO_ALIAS:
            return s
        return None

    def get(self, path, params=None):
        d = http_json(self.host + path, dict(params or {}, apikey=self.key), headers=UA, limiter=self.limiter, cost=1)
        if isinstance(d, dict) and d.get("status") == "error":
            raise FeedError("Twelve Data: %s" % d.get("message", d.get("code")))
        return d

    def tick(self, code):
        d = self.get("/price", {"symbol": code})
        try:
            px = float(d["price"])
        except (KeyError, TypeError, ValueError):
            raise FeedError("Twelve Data: giá không hợp lệ")
        return Tick(code, time.time(), px, px)

    def fetch(self, code, tf, n, end):
        params = {"symbol": code, "interval": self.native[tf], "outputsize": n, "order": "asc", "timezone": "UTC"}
        if end is not None:
            params["end_date"] = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(end))
        d = self.get("/time_series", params)
        out = []
        for r in (d.get("values") or []):
            try:
                dt = r["datetime"]
                t = calendar.timegm(time.strptime(dt[:19], "%Y-%m-%d %H:%M:%S" if len(dt) > 10 else "%Y-%m-%d"))
                out.append(Candle(float(t), _f(r["open"]), _f(r["high"]), _f(r["low"]), _f(r["close"]), _f(r.get("volume") or 0)))
            except (KeyError, ValueError, TypeError):
                continue
        return out


def clean_candles(cs):
    """Bỏ nến hỏng (giá <= 0, không hữu hạn, râu lệch xa so với trung vị) - một nến rác làm thang giá của biểu đồ nổ tung."""
    out = []
    for c in cs:
        try:
            vals = (c.open, c.high, c.low, c.close)
            if not all(v == v and v not in (float("inf"), float("-inf")) and v > 0 for v in vals):
                continue
        except TypeError:
            continue
        c.high = max(c.high, c.open, c.close)
        c.low = min(c.low, c.open, c.close)
        out.append(c)
    if len(out) >= 5:
        med = sorted(c.close for c in out)[len(out) // 2]
        out = [c for c in out if c.high <= med * 4.0 and c.low >= med / 4.0]
    return out


class PublicFeed:
    max_chunk = 1000
    COOLDOWN = 60.0

    def __init__(self, tick_ttl=2.0, twelvedata_key="", clock=time.time):
        self.crypto = [BinanceSrc(), BybitSrc(), OkxSrc(), CoinbaseSrc(), KrakenSrc()]
        self.yahoo = YahooSrc()
        self.td = TwelveDataSrc(twelvedata_key) if str(twelvedata_key or "").strip() else None
        self.ttl = tick_ttl
        self.clock = clock
        self._tick = {}
        self._down = {}                      # tên nguồn -> thời điểm được thử lại
        self.active = {}                     # mã -> nguồn đang dùng
        self.native = YAHOO_INT

    def symbols(self):
        return ["BTCUSDT", "ETHUSDT", "XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "US500", "AAPL"]

    def _chain(self, symbol):
        """Danh sách (nguồn, mã dùng cho nguồn đó) theo thứ tự thử."""
        kind, code = route(symbol)
        if kind == "binance":
            return [(s, code) for s in self.crypto]
        chain = [(self.yahoo, code)]
        if self.td is not None:
            tds = TwelveDataSrc.symbol(symbol)
            if tds:
                chain.append((self.td, tds))
        if str(symbol).strip().upper().replace("/", "") in ("XAUUSD", "GOLD"):
            chain.append((self.crypto[0], "PAXGUSDT"))               # token vàng 1:1: giá sát vàng giao ngay, chạy 24/7
            chain.append((self.crypto[1], "PAXGUSDT"))
        return chain

    def _run(self, symbol, fn):
        now = self.clock()
        chain = self._chain(symbol)
        cands = [x for x in chain if self._down.get(x[0].name, 0) <= now] or chain     # mọi nguồn đang «nghỉ» -> thử hết, đừng bỏ trống
        last = None
        for src, code in cands:
            try:
                r = fn(src, code)
            except FeedError as e:
                last = e
                self._down[src.name] = now + self.COOLDOWN
                continue
            self._down.pop(src.name, None)
            self.active[symbol] = src.name
            return r
        raise FeedError("Mọi nguồn giá công khai đều lỗi cho %s (%s)" % (symbol, last))

    def tick(self, symbol):
        now = self.clock()
        c = self._tick.get(symbol)
        ttl = max(self.ttl, 10.0) if (self.td is not None and self.active.get(symbol) == "TwelveData") else self.ttl
        if c and now - c[0] < ttl:
            return c[1]
        t = self._run(symbol, lambda src, code: src.tick(code))
        t = Tick(symbol, t.time, t.bid, t.ask)
        self._tick[symbol] = (now, t)
        return t

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        return clean_candles(self._run(symbol, lambda src, code: src.history(code, tf, n, end)))

    def close(self):
        for s in self.crypto:
            try:
                for f in getattr(s, "_f", {}).values():
                    f.close()
            except Exception:                                          # noqa: BLE001
                pass
