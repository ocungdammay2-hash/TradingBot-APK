"""BỘ LỌC LỊCH SỬ KIỂU MT5 (thuần dữ liệu, không Kivy): 3 bảng Vị thế · Lệnh · Giao dịch, lọc theo kỳ / mã / chiều / kết quả / nguồn bot, sắp xếp, tổng.

Nguồn dữ liệu có hai loại, ra CÙNG một dạng «dòng» nên bộ lọc chạy giống nhau:
  - từ SÀN: deal đã chuẩn hoá của brokerhist (`positions_from_deals`, deal trade) · - từ SỔ APP: danh sách Trade trong trades.csv.
Dòng = dict: id, time (giờ đóng/giờ khớp), open_time, symbol, side, volume, price (giá vào/giá khớp), price2 (giá ra, vị thế), profit, swap, commission,
owner (nguồn: bot/«thủ công»/ghi chú), entry ("IN"/"OUT"/... cho deal), state (cho lệnh)."""
import time

from . import brokerhist as bh
from .btanalysis import parse_day

TABS = (("positions", "Vị thế"), ("orders", "Lệnh"), ("deals", "Giao dịch"))
SORTS = (("time_desc", "Mới nhất trước"), ("time_asc", "Cũ nhất trước"), ("profit_desc", "Lãi nhiều nhất"), ("profit_asc", "Lỗ nhiều nhất"), ("symbol", "Theo mã"))
SIDES = (("", "Mua + Bán"), ("buy", "Chỉ MUA"), ("sell", "Chỉ BÁN"))
RESULTS = (("", "Lãi + Lỗ"), ("win", "Chỉ lãi"), ("loss", "Chỉ lỗ"))
ALL_SYMBOLS = "Tất cả mã"
MAX_ROWS = 100


# ---------------------------------------------------------------------------------------------- khoảng thời gian
def custom_range(from_text, to_text, tz_offset_s=0.0):
    """'2026-10-01' .. '2026-10-31' (giờ địa phương, «đến» gồm cả ngày đó) -> (since, until) epoch UTC. Sai -> ValueError."""
    a, b = parse_day(from_text), parse_day(to_text, end_of_day=True)
    if a is None and b is None:
        raise ValueError("Nhập «Từ ngày» và/hoặc «Đến ngày» dạng 2026-10-01")
    a = None if a is None else a - tz_offset_s
    b = None if b is None else b - tz_offset_s
    if a is not None and b is not None and a >= b:
        raise ValueError("«Từ ngày» phải trước «Đến ngày»")
    return a, b


def in_range(t, since=None, until=None):
    t = float(t or 0.0)
    return (since is None or t >= since) and (until is None or t < until)


# ---------------------------------------------------------------------------------------------- dựng dòng
def _row(**kw):
    base = {"id": "", "time": 0.0, "open_time": None, "symbol": "", "side": "", "volume": 0.0, "price": 0.0, "price2": 0.0, "profit": 0.0,
            "swap": 0.0, "commission": 0.0, "owner": "", "entry": "", "state": "", "kind": "trade"}
    base.update(kw)
    return base


def positions_from_broker(res):
    """res['positions'] của brokerhist.fetch -> dòng vị thế đã đóng."""
    out = []
    for p in (res or {}).get("positions", []) or []:
        out.append(_row(id=p.get("position_id", ""), time=p.get("close_time") or 0.0, open_time=p.get("open_time"), symbol=p.get("symbol", ""),
                        side=p.get("side", ""), volume=p.get("volume", 0.0), price=p.get("open_price", 0.0), price2=p.get("close_price", 0.0),
                        profit=p.get("profit", 0.0), swap=p.get("swap", 0.0), commission=p.get("commission", 0.0), owner=p.get("comment", "")))
    return out


def deals_from_broker(res):
    out = []
    for raw in (res or {}).get("deals", []) or []:
        d = bh.norm_deal(raw)
        if d["kind"] != "trade":
            continue
        out.append(_row(id=d["id"], time=d["time"], symbol=d["symbol"], side=d["side"], volume=d["qty"], price=d["price"], profit=d["profit"],
                        swap=d["swap"], commission=d["commission"] + d["fee"], owner=d["comment"], entry=d["entry"]))
    return out


def orders_from_broker(res):
    """Mỗi order_id (hoặc deal lẻ) = MỘT lệnh đã khớp: khối lượng cộng, giá bình quân gia quyền. Lệnh bị huỷ/hết hạn sàn không báo -> không có ở đây."""
    groups, order = {}, []
    for r in deals_from_broker(res):
        raw = next((d for d in (res or {}).get("deals", []) if str(d.get("id", "")) == r["id"]), {})
        key = str(raw.get("order_id") or "") or ("deal:" + r["id"])
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(r)
    out = []
    for key in order:
        g = groups[key]
        vol = sum(x["volume"] for x in g)
        price = (sum(x["price"] * x["volume"] for x in g) / vol) if vol > 0 else g[0]["price"]
        out.append(_row(id="" if key.startswith("deal:") else key, time=min(x["time"] for x in g), symbol=g[0]["symbol"], side=g[0]["side"], volume=vol,
                        price=price, profit=sum(x["profit"] for x in g), swap=sum(x["swap"] for x in g), commission=sum(x["commission"] for x in g),
                        owner=g[0]["owner"], state="Đã khớp"))
    return out


def _owner(t):
    return "thủ công" if getattr(t, "owner", "") in ("", "manual") else getattr(t, "owner", "")


def positions_from_trades(trades):
    return [_row(id=str(t.id), time=t.close_time, open_time=t.open_time, symbol=t.symbol, side=t.side, volume=t.volume, price=t.open_price,
                 price2=t.close_price, profit=t.profit, swap=getattr(t, "swap", 0.0), commission=getattr(t, "fee", 0.0), owner=_owner(t)) for t in trades or []]


def deals_from_trades(trades):
    """Mỗi lệnh đã đóng = 2 giao dịch (vào + ra); lãi/lỗ nằm ở giao dịch ra như MT5."""
    out = []
    for t in trades or []:
        opp = "sell" if t.side == "buy" else "buy"
        out.append(_row(id="%s-in" % t.id, time=t.open_time, symbol=t.symbol, side=t.side, volume=t.volume, price=t.open_price, owner=_owner(t), entry="IN"))
        out.append(_row(id="%s-out" % t.id, time=t.close_time, symbol=t.symbol, side=opp, volume=t.volume, price=t.close_price, profit=t.profit,
                        swap=getattr(t, "swap", 0.0), commission=getattr(t, "fee", 0.0), owner=_owner(t), entry="OUT"))
    return out


def orders_from_trades(trades):
    return [dict(r, state="Đã khớp") for r in deals_from_trades(trades)]


# ---------------------------------------------------------------------------------------------- lọc / sắp xếp / tổng
def symbols_of(rows):
    return sorted({r["symbol"] for r in rows if r.get("symbol")})


def owners_of(rows):
    return sorted({r["owner"] for r in rows if r.get("owner")})


def apply_filters(rows, since=None, until=None, symbol="", side="", result="", owner=""):
    out = []
    for r in rows:
        if not in_range(r["time"], since, until):
            continue
        if symbol and symbol != ALL_SYMBOLS and r["symbol"] != symbol:
            continue
        if side and r["side"] != side:
            continue
        if result == "win" and not r["profit"] > 0:
            continue
        if result == "loss" and not r["profit"] < 0:
            continue
        if owner and r["owner"] != owner:
            continue
        out.append(r)
    return out


def sort_rows(rows, key="time_desc"):
    if key == "time_asc":
        return sorted(rows, key=lambda r: r["time"])
    if key == "profit_desc":
        return sorted(rows, key=lambda r: -r["profit"])
    if key == "profit_asc":
        return sorted(rows, key=lambda r: r["profit"])
    if key == "symbol":
        return sorted(rows, key=lambda r: (r["symbol"], -r["time"]))
    return sorted(rows, key=lambda r: -r["time"])


def totals(rows):
    """Tổng của các dòng ĐANG HIỆN (sau lọc): số dòng, lãi/lỗ, swap, hoa hồng, số dòng lãi, thắng %."""
    prof = sum(r["profit"] for r in rows)
    graded = [r for r in rows if r["profit"] != 0]
    wins = sum(1 for r in graded if r["profit"] > 0)
    return {"count": len(rows), "profit": prof, "swap": sum(r["swap"] for r in rows), "commission": sum(r["commission"] for r in rows),
            "wins": wins, "win_pct": (100.0 * wins / len(graded)) if graded else 0.0}


def view(rows_by_tab, tab, **flt):
    """Một lệnh gọi cho giao diện: (các dòng đã lọc+sắp xếp, tổng của TOÀN BỘ dòng khớp bộ lọc). `flt` có thêm sort."""
    sort = flt.pop("sort", "time_desc")
    rows = sort_rows(apply_filters(rows_by_tab.get(tab, []), **flt), sort)
    return rows, totals(rows)
