"""
NHIỀU TÀI KHOẢN CÙNG LÚC.

Tài khoản CHÍNH ("main") là cài đặt hiện tại của app (như trước đây). Tài khoản PHỤ là các hồ sơ lưu trong `accounts.json`
(sàn + khoá + chế độ + rủi ro...), mỗi hồ sơ chạy MỘT phiên riêng trong dịch vụ nền (sổ lệnh, sự kiện, lịch sử, báo động riêng,
thư mục `accounts/<id>/`). Bot gắn kèm trường `account` (mặc định "main") để biết chạy trên tài khoản nào.

Giới hạn (nói thẳng):
  - Chạy SONG SONG có ở cả chế độ DỊCH VỤ NỀN (ServiceHost) lẫn chạy TRỰC TIẾP trong app (mỗi tài khoản một TradingSession + LocalController, ui_accounts.py).
    Chạy nền vẫn được khuyên dùng: chạy trực tiếp thì đóng app là mọi tài khoản dừng.
  - Tài khoản phụ không dùng chung AI-hub (chat/nhóm AI chỉ cho tài khoản chính); bot vẫn dùng được `api.ai_signal` của tài khoản chính nếu có.
  - Các khoá bí mật trong hồ sơ được mã hoá bằng cùng SecretBox với settings.json.
"""
import json
import os
import re
import threading
import time
import unicodedata

from .keystore import box_for
from .settings import GLOBAL_INPUTS, clean_settings

MAIN = "main"

# khoá cấp ỨNG DỤNG (không thuộc về một tài khoản)
ACCOUNT_DENY = {"background_service", "auto_resume", "start_on_boot", "boot_alert", "bot_ai_enabled", "bot_ai_agent", "bot_ai_max_per_hour", "bot_ai_max_per_day", "bot_ai_cache_s", "bot_ai_timeout", "bot_ai_max_tokens", "bot_ai_max_context", "bot_ai_allow_web", "bot_ai_system", "bot_ai_record", "watchdog_alarm", "watchdog_minutes", "power_mode", "notify_trades", "keep_awake", "ui_refresh", "chart_bars"} | \
               {k for k, v in GLOBAL_INPUTS.items() if v.group == "AI"}


def slug(name):
    """id an toàn cho tên thư mục: bỏ dấu tiếng Việt (đ -> d), chỉ giữ a-z0-9 và dấu gạch ngang."""
    t = unicodedata.normalize("NFKD", str(name or "").lower().replace("đ", "d"))
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", "-", t.encode("ascii", "ignore").decode()).strip("-") or "acc"


class AccountBook:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.path = os.path.join(data_dir, "accounts.json")
        self._lock = threading.RLock()
        self._box = box_for(data_dir)

    # ---- đọc/ghi ----
    def _read(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            return [a for a in d.get("accounts", []) if isinstance(a, dict) and a.get("id")]
        except (OSError, ValueError):
            return []

    def _write(self, rows):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"version": 1, "accounts": rows}, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def _open(self, a):
        return dict(a, settings=self._box.open_settings(a.get("settings", {})))

    # ---- API ----
    def list(self):
        with self._lock:
            return [self._open(a) for a in self._read()]

    def get(self, aid):
        for a in self.list():
            if a["id"] == aid:
                return a
        return None

    def enabled(self):
        return [a for a in self.list() if a.get("enabled", True)]

    def add(self, name, settings):
        """Lưu một hồ sơ từ bộ cài đặt `settings` (thường là cài đặt hiện tại). Trả về hồ sơ vừa tạo."""
        name = str(name or "").strip()
        if not name:
            raise ValueError("Tên tài khoản không được để trống")
        with self._lock:
            rows = self._read()
            taken = {a["id"] for a in rows} | {MAIN}
            base, n, aid = slug(name), 1, slug(name)
            while aid in taken:
                n += 1
                aid = "%s-%d" % (base, n)
            prof = {k: v for k, v in clean_settings(settings).items() if k not in ACCOUNT_DENY}
            row = {"id": aid, "name": name, "enabled": True, "created": time.time(), "settings": self._box.seal_settings(prof)}
            rows.append(row)
            self._write(rows)
            return self._open(row)

    def update(self, aid, name=None, enabled=None, settings=None):
        with self._lock:
            rows = self._read()
            for a in rows:
                if a["id"] == aid:
                    if name is not None and str(name).strip():
                        a["name"] = str(name).strip()
                    if enabled is not None:
                        a["enabled"] = bool(enabled)
                    if settings is not None:
                        prof = {k: v for k, v in clean_settings(settings).items() if k not in ACCOUNT_DENY}
                        a["settings"] = self._box.seal_settings(prof)
                    self._write(rows)
                    return self._open(a)
        raise KeyError("Không có tài khoản '%s'" % aid)

    def remove(self, aid):
        with self._lock:
            rows = self._read()
            keep = [a for a in rows if a["id"] != aid]
            if len(keep) == len(rows):
                return False
            self._write(keep)
            return True

    # ---- dùng ----
    def effective_settings(self, aid, base):
        """Cài đặt hiệu lực của tài khoản phụ: cài đặt ứng dụng (base) + hồ sơ tài khoản đè lên."""
        a = self.get(aid)
        if a is None:
            raise KeyError("Không có tài khoản '%s'" % aid)
        merged = dict(base)
        merged.update(a["settings"])
        return clean_settings(merged)

    def data_dir_for(self, aid):
        d = os.path.join(self.data_dir, "accounts", aid)
        os.makedirs(d, exist_ok=True)
        return d
