"""
Strategy Tester kiểu MT5: chạy bot trên dữ liệu lịch sử bằng CHÍNH engine giao dịch (TradingSession đồng bộ),
nên SL/TP, phí, ký quỹ, sự kiện + lý do vào/ra lệnh hoạt động y như khi chạy thật.

Chế độ mô phỏng tick từ nến:
  ohlc       : 4 tick/nến (O → L → H → C nếu nến tăng; O → H → L → C nếu nến giảm)  [mặc định, giống "1 minute OHLC"]
  ohlc_hl    : luôn O → H → L → C
  ohlc_lh    : luôn O → L → H → C
  ohlc_worst : sau tick mở cửa, chọn thứ tự BẤT LỢI cho vị thế đang mở (đang mua: xuống đáy trước -> SL chạm trước TP; đang bán: lên đỉnh trước);
               không có vị thế thì theo hướng nến như `ohlc`. Cho cận dưới thận trọng của kết quả.
  open       : 1 tick/nến tại giá mở cửa (rất nhanh, giống "Open prices only")
Giá bid/ask = giá ± spread/2 (spread_pct % của giá).

Nến OHLC KHÔNG nói được giá đi đỉnh hay đáy trước. Khi SL và TP cùng nằm trong một nến, thứ tự giả định quyết định lệnh thắng hay thua:
dùng `intrabar_sensitivity()` (chạy cả ba thứ tự) - nếu kết quả khác nhau nhiều thì chiến lược phụ thuộc vào giả định, KHÔNG nên tin.
"""
import heapq
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from dataclasses import replace as dc_replace

from . import airec
from .engine import Account, CandleBuilder, TradingSession, _Halt
from .feeds import FeedError, tf_seconds
from .sdk import BaseBot, Candle, Tick

MODES = {"ohlc": "OHLC (4 tick/nến)", "ohlc_hl": "OHLC cố định O→H→L→C", "ohlc_lh": "OHLC cố định O→L→H→C",
         "ohlc_worst": "OHLC xấu nhất cho lệnh đang mở", "open": "Chỉ giá mở cửa (nhanh)"}
WORST_NOTE = "Nến OHLC không cho biết đỉnh hay đáy đến trước: khi SL và TP cùng nằm trong một nến, thứ tự giả định quyết định thắng/thua."


class _ReplayFeed:
    def tick(self, symbol):
        raise FeedError("backtest: không có giá hiện tại cho %s" % symbol)

    def history(self, *a, **k):
        return []

    def symbols(self):
        return []

    def close(self):
        pass


# --------------------------------------------------------------------------
# Mô hình chi phí (spread, phí, trượt giá, swap/funding)
# --------------------------------------------------------------------------
@dataclass
class CostModel:
    """Chi phí giao dịch dùng trong Strategy Tester. Mọi trường mặc định 0 => hành vi cũ (chỉ spread % + phí % notional).
       - spread_points > 0: spread cố định theo ĐƠN VỊ GIÁ (ưu tiên hơn spread_pct)
       - slippage_pct: trượt giá bất lợi mỗi lần khớp (cả vào lẫn ra) - mô phỏng bằng nới spread mỗi phía
       - swap_*_pct_day: % notional mỗi ngày (dương = TRẢ), tính liên tục theo thời gian giữ lệnh
       - funding_8h_pct: perp crypto, % notional mỗi 8 giờ: dương => vị thế MUA trả, BÁN nhận
       - swap_triple_weekday (0=T2..4=T6, -1=tắt): kiểu broker MT - swap tính RỜI RẠC mỗi ngày giao dịch (T2-T6) ở giờ rollover
         `swap_rollover_hour_utc`, ngày này tính x3 (bù T7/CN). Tắt (-1) = tính liên tục theo thời gian như trước.
       per_symbol: {"XAUUSD": {"spread_points": 0.25, ...}} ghi đè theo mã."""
    spread_pct: float = 0.01
    spread_points: float = 0.0
    commission_pct: float = 0.0
    commission_per_lot: float = 0.0
    commission_min: float = 0.0
    slippage_pct: float = 0.0
    swap_long_pct_day: float = 0.0
    swap_short_pct_day: float = 0.0
    funding_8h_pct: float = 0.0
    swap_triple_weekday: int = -1
    swap_rollover_hour_utc: float = 21.0
    per_symbol: dict = field(default_factory=dict)

    @classmethod
    def from_settings(cls, st, spread_pct=None):
        g = lambda k, d=0.0: float(st.get(k, d) or 0.0)             # noqa: E731
        return cls(spread_pct=g("spread_pct", 0.01) if spread_pct is None else float(spread_pct), spread_points=g("bt_spread_points"),
                   commission_pct=g("commission_pct"), commission_per_lot=g("bt_commission_per_lot"), commission_min=g("bt_commission_min"),
                   slippage_pct=g("bt_slippage_pct"), swap_long_pct_day=g("bt_swap_long_pct_day"), swap_short_pct_day=g("bt_swap_short_pct_day"),
                   funding_8h_pct=g("bt_funding_8h_pct"),
                   swap_triple_weekday={"off": -1, "mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4}.get(str(st.get("bt_swap_triple_day") or "off").lower(), -1),
                   swap_rollover_hour_utc=g("bt_swap_rollover_hour", 21.0) % 24.0)

    def for_symbol(self, symbol):
        ov = self.per_symbol.get(symbol)
        return dc_replace(self, **{k: v for k, v in ov.items() if k in self.__dataclass_fields__ and k != "per_symbol"}) if ov else self

    def half_spread(self, price):
        """Nửa spread + trượt giá (đơn vị giá) - mỗi lần khớp bất lợi đúng khoản này so với giá giữa."""
        full = self.spread_points if self.spread_points > 0 else price * self.spread_pct / 100.0
        return full / 2.0 + price * self.slippage_pct / 100.0

    def apply_to(self, account):
        account.fee_rate = max(0.0, self.commission_pct) / 100.0
        account.fee_per_unit = max(0.0, self.commission_per_lot)
        account.fee_min = max(0.0, self.commission_min)

    def rollovers(self, t0, t1):
        """Số 'lần tính swap' trong (t0, t1]: mỗi ngày giao dịch (T2-T6) một lần ở giờ rollover UTC; ngày `swap_triple_weekday` tính 3 lần;
        T7/CN không tính. Chỉ dùng khi swap_triple_weekday >= 0."""
        if t1 <= t0:
            return 0
        h = self.swap_rollover_hour_utc * 3600.0
        k = math.floor((t0 - h) / 86400.0) + 1                  # rollover thứ k nằm ở k*86400 + h; k đầu tiên > t0
        total = 0
        while k * 86400.0 + h <= t1:
            wd = (int(k) + 3) % 7                               # 1970-01-01 là thứ Năm -> 0 = Thứ Hai
            total += 0 if wd >= 5 else (3 if wd == self.swap_triple_weekday else 1)
            k += 1
        return total

    def swap_amount(self, pos, price, dt, t_end=None):
        """Swap/funding của vị thế trong `dt` giây kết thúc ở `t_end` (epoch UTC) (dương = trả)."""
        notional = pos.volume * price
        amt = 0.0
        rate = self.swap_long_pct_day if pos.side == "buy" else self.swap_short_pct_day
        if rate:
            if self.swap_triple_weekday >= 0 and t_end is not None:
                amt += notional * rate / 100.0 * self.rollovers(t_end - dt, t_end)
            else:
                amt += notional * rate / 100.0 * dt / 86400.0
        if self.funding_8h_pct:
            amt += notional * self.funding_8h_pct / 100.0 * dt / 28800.0 * (1.0 if pos.side == "buy" else -1.0)
        return amt


def cost_breakdown(trades, cm_for):
    """Tách chi phí đã trả. cm_for(symbol) -> CostModel. Spread/trượt giá là ƯỚC TÍNH (đã nằm trong giá khớp, không thấy riêng trong sổ lệnh)."""
    fee = sum(t.fee for t in trades)
    swap = sum(t.swap for t in trades)
    spread = slip = 0.0
    for t in trades:
        cm = cm_for(t.symbol)
        pa, pb = t.open_price, t.close_price
        full = lambda p: cm.spread_points if cm.spread_points > 0 else p * cm.spread_pct / 100.0       # noqa: E731
        spread += t.volume * (full(pa) + full(pb)) / 2.0
        slip += t.volume * (pa + pb) * cm.slippage_pct / 100.0
    total = fee + swap + spread + slip
    net = sum(t.profit for t in trades)
    return {"Phí giao dịch": fee, "Swap/Funding": swap, "Spread đã trả (ước)": spread, "Trượt giá (ước)": slip, "Tổng chi phí": total,
            "Lãi gộp (trước chi phí)": net + total, "Chi phí / lãi gộp (%)": (total / (net + total) * 100.0) if (net + total) > 1e-12 else None}


class _Swapper:
    """Tính swap theo thời gian thực trôi qua của từng mã (không tính hai lần khi nhiều bot cùng mã)."""

    def __init__(self, sess, cm_for):
        self.sess, self.cm_for, self.last = sess, cm_for, {}

    def accrue(self, symbol, t, price):
        prev = self.last.get(symbol)
        self.last[symbol] = t
        cm = self.cm_for(symbol)
        if prev is None or t <= prev or not (cm.swap_long_pct_day or cm.swap_short_pct_day or cm.funding_8h_pct):
            return
        for p in list(self.sess.account.positions.values()):
            if p.symbol == symbol:
                self.sess.account.accrue_swap(p, cm.swap_amount(p, price, t - prev, t))


def candle_ticks(c, step, mode, net=0.0):
    """[(thời gian, giá)] mô phỏng bên trong 1 nến. `net` (chỉ cho ohlc_worst): khối lượng ròng đang mở (>0 mua, <0 bán) tại thời điểm chọn thứ tự."""
    if mode == "open":
        return [(c.time, c.open)]
    up = c.close >= c.open
    if mode == "ohlc_hl":
        up = False
    elif mode == "ohlc_lh":
        up = True
    elif mode == "ohlc_worst" and net:
        up = net > 0                                    # đang MUA -> đáy trước (SL trước TP); đang BÁN -> đỉnh trước
    path = [c.open, c.low, c.high, c.close] if up else [c.open, c.high, c.low, c.close]
    return [(c.time + step * k / 4.0, p) for k, p in enumerate(path)]


def _net_volume(sess, symbol):
    with sess.lock:
        return sum((p.volume if p.side == "buy" else -p.volume) for p in sess.account.positions.values() if p.symbol == symbol)


@dataclass
class BacktestResult:
    ok: bool = True
    error: str = ""
    report: dict = field(default_factory=dict)
    trades: list = field(default_factory=list)
    events: list = field(default_factory=list)
    candles: list = field(default_factory=list)       # nến hiển thị (cuối warm-up + cửa sổ test)
    plots: dict = field(default_factory=dict)
    curve: list = field(default_factory=list)         # [(t, balance, equity)]
    symbol: str = ""
    timeframe: str = ""
    params: dict = field(default_factory=dict)
    logs: list = field(default_factory=list)


def compute_report(trades, start_balance, curve, bars=0):
    n = len(trades)
    profits = [t.profit for t in trades]
    gp = sum(p for p in profits if p > 0)
    gl = sum(p for p in profits if p < 0)
    wins = [p for p in profits if p > 0]
    losses = [p for p in profits if p < 0]
    net = sum(profits)

    def streak(pred):
        best_n = best_m = cur_n = 0
        cur_m = 0.0
        for p in profits:
            if pred(p):
                cur_n += 1
                cur_m += p
                if cur_n > best_n:
                    best_n = cur_n
                if abs(cur_m) > abs(best_m):
                    best_m = cur_m
            else:
                cur_n, cur_m = 0, 0.0
        return best_n, best_m
    mw, mwm = streak(lambda p: p > 0)
    ml, mlm = streak(lambda p: p <= 0)
    longs = [t for t in trades if t.side == "buy"]
    shorts = [t for t in trades if t.side == "sell"]

    def wr(ts):
        return (sum(1 for t in ts if t.profit > 0) / len(ts) * 100.0) if ts else 0.0
    peak, dd_abs, dd_pct = start_balance, 0.0, 0.0
    for _, _, eq in curve:
        peak = max(peak, eq)
        dd_abs = max(dd_abs, peak - eq)
        if peak > 0:
            dd_pct = max(dd_pct, (peak - eq) / peak * 100.0)
    rets = []
    for i in range(1, len(curve)):
        e0, e1 = curve[i - 1][2], curve[i][2]
        if e0 > 0:
            rets.append(e1 / e0 - 1.0)
    sharpe = 0.0
    if len(rets) > 2:
        m = sum(rets) / len(rets)
        sd = math.sqrt(sum((r - m) ** 2 for r in rets) / (len(rets) - 1))
        sharpe = (m / sd * math.sqrt(len(rets))) if sd > 0 else 0.0
    end_eq = curve[-1][2] if curve else start_balance
    return {
        "Số dư ban đầu": start_balance, "Số dư cuối": start_balance + net, "Lợi nhuận ròng": net,
        "Lợi nhuận gộp": gp, "Lỗ gộp": gl,
        "Profit factor": (gp / abs(gl)) if gl < 0 else (None if gp == 0 else float("inf")),
        "Kỳ vọng / lệnh": (net / n) if n else 0.0, "Recovery factor": (net / dd_abs) if dd_abs > 0 else None,
        "Sharpe (xấp xỉ)": sharpe,
        "Sụt vốn tối đa (tuyệt đối)": dd_abs, "Sụt vốn tối đa (%)": dd_pct,
        "Tổng số lệnh": n, "Lệnh mua": len(longs), "Lệnh bán": len(shorts),
        "Thắng (%)": wr(trades), "Thắng - mua (%)": wr(longs), "Thắng - bán (%)": wr(shorts),
        "Lệnh lãi": len(wins), "Lệnh lỗ": len(losses),
        "Lãi lớn nhất": max(wins) if wins else 0.0, "Lỗ lớn nhất": min(losses) if losses else 0.0,
        "Lãi trung bình": (sum(wins) / len(wins)) if wins else 0.0, "Lỗ trung bình": (sum(losses) / len(losses)) if losses else 0.0,
        "Chuỗi thắng dài nhất (lệnh)": mw, "Chuỗi thắng dài nhất ($)": mwm,
        "Chuỗi thua dài nhất (lệnh)": ml, "Chuỗi thua dài nhất ($)": mlm,
        "Số nến test": bars, "Equity cuối": end_eq,
    }


def _throttle(speed, stop_event, pause_event):
    """Tốc độ chạy kiểu «Visual mode» của MT5: `speed` nến/giây (0 = tối đa). Ngủ từng lát ngắn để «Dừng» có hiệu lực ngay; `pause_event` đặt = tạm dừng."""
    end = time.monotonic() + (1.0 / speed if speed and speed > 0 else 0.0)
    while True:
        if stop_event is not None and stop_event.is_set():
            return
        paused = pause_event is not None and pause_event.is_set()
        left = end - time.monotonic()
        if not paused and left <= 0:
            return
        time.sleep(0.05 if paused else min(0.05, max(left, 0.0005)))


def run_backtest(bot_path, params, settings, symbol, tf, candles, warmup=100, mode="ohlc", spread_pct=None,
                 progress=None, stop_event=None, costs=None, ai_signals=None, speed=0.0, pause_event=None, on_step=None, debugger=None):
    """candles: list Candle cũ -> mới (đã gồm cả đoạn warm-up). `debugger`: pyea.botdebug.Tracer (ghi từng dòng/điểm dừng của bot, chỉ backtest). `costs`: CostModel (mặc định lấy từ settings). Trả về BacktestResult.
    `ai_signals`: None = KHÔNG phát lại (api.ai_signal luôn None, báo cáo cảnh báo nếu bot có đọc); list bản ghi (airec.load_dir) = phát lại theo đồng hồ thị trường.
    `speed` (nến/giây, 0 = tối đa) + `pause_event` (Event: đặt = tạm dừng) + `on_step(i, n, candle, (time, balance, equity))` mỗi nến khi speed>0: chế độ xem từng nến
    như Visual mode của MT5. Không đổi kết quả (chỉ chậm hơn)."""
    step = tf_seconds(tf)
    res = BacktestResult(symbol=symbol, timeframe=tf, params=dict(params or {}))
    candles = [c for c in candles if c is not None]
    if len(candles) < 5:
        res.ok, res.error = False, "Không đủ dữ liệu nến để backtest (%d)" % len(candles)
        return res
    warmup = max(0, min(int(warmup), len(candles) - 3))
    cm = (costs if isinstance(costs, CostModel) else CostModel.from_settings(settings, spread_pct)).for_symbol(symbol)
    if costs is not None and spread_pct is not None:
        cm = dc_replace(cm, spread_pct=float(spread_pct))

    st = dict(settings, mode="paper", exchange="simulated", state_file=None, read_only=False)   # Strategy Tester không bị chế độ chỉ-xem
    sess = TradingSession(st, sync=True, feed=_ReplayFeed())
    sess.debugger = debugger
    hub = _make_hub(sess, ai_signals, st, (candles[warmup].time, candles[-1].time + step))
    sess.events = deque(maxlen=200000)
    sess.account = Account(float(st["initial_balance"]), st["commission_pct"], st["leverage"])
    cm.apply_to(sess.account)
    swapper = _Swapper(sess, lambda _s: cm)
    sess.status = "running"
    sess.ready.set()
    b = CandleBuilder(step, max_len=len(candles) + 10, tf=tf)
    b.seed(candles[:warmup], candles[warmup].time)
    sess.builders[(symbol, tf)] = b

    inst = sess.attach(bot_path, symbol, tf, params or {}, iid="bt")
    inst.plot_cap = 10 ** 7
    curve = []
    err = ""
    try:
        inst.start()                           # đồng bộ: nạp bot + on_init
    except _Halt as h:
        res.ok, res.error = False, str(h)
        res.logs = [x[3] for x in sess.logs]
        return res
    except Exception as e:                     # pragma: no cover
        res.ok, res.error = False, "Lỗi khởi tạo backtest: %s" % e
        return res

    test = candles[warmup:]
    last_tick = None
    fitness = None
    try:
        for i, c in enumerate(test):
            if stop_event is not None and stop_event.is_set():
                err = "Đã dừng theo yêu cầu"
                break
            tks = candle_ticks(c, step, mode)
            n_ = 0
            while n_ < len(tks):                           # theo CHỈ SỐ: `for` trên danh sách cũ sẽ bỏ qua việc đổi thứ tự bên dưới
                t, p = tks[n_]
                half = cm.half_spread(p)
                last_tick = Tick(symbol, t, p - half, p + half)
                sess.process_tick(last_tick)
                if n_ == 0 and mode == "ohlc_worst":        # sau tick mở cửa bot đã phản ứng -> mới biết sổ lệnh để chọn thứ tự bất lợi
                    tks = [tks[0]] + candle_ticks(c, step, mode, _net_volume(sess, symbol))[1:]
                n_ += 1
            swapper.accrue(symbol, c.time + step, c.close)
            sess._check_max_loss()
            sess._check_margin()
            curve.append((c.time, sess.account.balance, sess.account.equity()))
            if speed and speed > 0:
                if on_step:
                    on_step(i + 1, len(test), c, curve[-1])
                if progress:
                    progress(i + 1, len(test))
                _throttle(speed, stop_event, pause_event)
            else:
                if pause_event is not None and pause_event.is_set():
                    _throttle(0, stop_event, pause_event)
                if progress and (i % 50 == 0 or i == len(test) - 1):
                    progress(i + 1, len(test))
    except _Halt as h:
        err = ("Bot lỗi: " + str(h)) if h.error else str(h)
        if h.error:
            res.ok = False
    except Exception as e:
        res.ok, err = False, "Lỗi backtest: %s" % e
    finally:
        try:
            if last_tick is not None and sess.account.positions:
                sess.close_all("stop", "Kết thúc backtest: đóng lệnh còn mở theo giá cuối")
                curve.append((last_tick.time, sess.account.balance, sess.account.equity()))
            fitness = _call_on_tester(inst, sess)
            if inst.bot is not None:
                inst.bot.on_deinit("backtest_end")
        except Exception:
            fitness = None
    res.error = err
    res.trades = list(sess.account.trades)
    res.events = list(sess.events)
    res.candles = candles[max(0, warmup - 30):]
    res.plots = {n: list(s.items()) for n, s in inst.plots.items()}
    res.curve = curve
    res.logs = [x[3] for x in sess.logs][-200:]
    res.report = compute_report(res.trades, float(st["initial_balance"]), curve, len(test))
    res.report.update(cost_breakdown(res.trades, lambda _s: cm))
    res.report["Mô phỏng tick"] = MODES.get(mode, mode)
    if hub.summary():
        res.report["Tín hiệu AI"] = hub.summary()
    if fitness is not None:
        res.report[FITNESS_KEY] = fitness
    return res


def _make_hub(sess, ai_signals, settings, window=None):
    """Gắn hub tín hiệu AI cho phiên backtest: phát lại bản ghi (list) hoặc NullHub (None). Trả hub."""
    if ai_signals is None:
        hub = airec.NullHub()
    else:
        hub = airec.ReplayHub(ai_signals, lambda: airec.market_now(sess), settings.get("ai_signal_ttl", 30), window)
    sess.ai_hub = hub
    return hub


FITNESS_KEY = "Fitness (on_tester)"


def _call_on_tester(inst, sess):
    """Gọi `bot.on_tester()` (như OnTester() của MT5) SAU khi đã đóng hết lệnh, TRƯỚC on_deinit. -> float hữu hạn | None (bot không có hàm / lỗi)."""
    bot = getattr(inst, "bot", None)
    fn = getattr(bot, "on_tester", None)
    if fn is None or getattr(type(bot), "on_tester", None) is getattr(BaseBot, "on_tester", None):
        return None
    try:
        v = float(fn())
    except Exception as e:                                  # noqa: BLE001 - lỗi trong on_tester không làm hỏng backtest
        sess.log("on_tester lỗi: %s" % e, "ERROR")
        return None
    if not math.isfinite(v):
        sess.log("on_tester trả về giá trị không hữu hạn (%r) - bỏ qua" % v, "WARN")
        return None
    return v


def intrabar_sensitivity(bot_path, params, settings, symbol, tf, candles, warmup=100, modes=("ohlc_hl", "ohlc_lh", "ohlc_worst"),
                         costs=None, key="Lợi nhuận ròng", tolerance_pct=25.0, progress=None, stop_event=None, ai_signals=None):
    """Chạy CÙNG bot/tham số với nhiều thứ tự trong nến để đo độ nhạy với giả định (PDF: 'chạy cả hai để thấy độ nhạy').
    -> {"ok", "results": {mode: {"value", "trades", "dd_pct"}}, "min", "max", "spread", "fragile": bool, "note": str}.
    fragile = các kết quả khác dấu (lãi/lỗ) hoặc chênh nhau > tolerance_pct% của biên độ lớn nhất - chiến lược dựa vào giả định, đừng tin."""
    out = {"ok": True, "results": {}, "key": key, "fragile": False, "note": "", "error": ""}
    for i, m in enumerate(modes):
        if stop_event is not None and stop_event.is_set():
            out["error"] = "Đã dừng theo yêu cầu"
            break
        r = run_backtest(bot_path, params, settings, symbol, tf, candles, warmup, m, costs=costs, ai_signals=ai_signals)
        if not r.ok and not r.trades:
            out["ok"], out["error"] = False, r.error or "backtest lỗi ở thứ tự %s" % m
            return out
        out["results"][m] = {"value": r.report.get(key), "trades": r.report.get("Tổng số lệnh", 0),
                             "dd_pct": r.report.get("Sụt vốn tối đa (%)", 0.0), "label": MODES.get(m, m)}
        if progress:
            progress(i + 1, len(modes))
    vals = [v["value"] for v in out["results"].values() if isinstance(v["value"], (int, float)) and math.isfinite(v["value"])]
    if len(vals) >= 2:
        lo, hi = min(vals), max(vals)
        out["min"], out["max"], out["spread"] = lo, hi, hi - lo
        scale = max(abs(lo), abs(hi))
        out["fragile"] = (lo < 0 < hi) or (scale > 0 and (hi - lo) / scale * 100.0 > tolerance_pct)
    if out["fragile"]:
        out["note"] = ("KẾT QUẢ NHẠY với thứ tự giá trong nến (%s từ %.4g đến %.4g): chiến lược phụ thuộc vào giả định không kiểm chứng được từ dữ liệu OHLC. "
                       "Hãy kiểm lại bằng khung nhỏ hơn / dữ liệu tick thật trước khi tin." % (key, out["min"], out["max"]))
    elif len(vals) >= 2:
        out["note"] = "Kết quả ổn định giữa các thứ tự trong nến (chênh ≤ %.0f%%)." % tolerance_pct
    return out


def optimize(bot_path, base_params, grid, settings, symbol, tf, candles, warmup=100, mode="open", top=20,
             sort_key="Lợi nhuận ròng", max_runs=120, progress=None, stop_event=None, costs=None, ai_signals=None):
    """Quét lưới tham số (như Optimization của MT5). grid: {"fast": [5,10,15], "slow": [20,30]}.
    Trả về list {"params", "report"} sắp xếp giảm dần theo `sort_key`. `top=None` = trả TẤT CẢ lần chạy (để thống kê so sánh từng tham số)."""
    import itertools
    names = list(grid)
    combos = list(itertools.product(*[grid[n] for n in names]))[:max_runs]
    out = []
    for i, vals in enumerate(combos):
        if stop_event is not None and stop_event.is_set():
            break
        p = dict(base_params or {})
        p.update(dict(zip(names, vals)))
        r = run_backtest(bot_path, p, settings, symbol, tf, candles, warmup, mode, costs=costs, ai_signals=ai_signals)
        if r.ok or r.trades:
            out.append({"params": p, "report": r.report})
        if progress:
            progress(i + 1, len(combos))

    def key(x):
        v = x["report"].get(sort_key)
        return -1e30 if v is None else (1e30 if v == float("inf") else v)
    out.sort(key=key, reverse=True)
    return out if top is None else out[:top]


# --------------------------------------------------------------------------
# Backtest DANH MỤC: nhiều bot / nhiều mã chạy CHUNG một tài khoản (như MT5 chạy nhiều EA trên một tài khoản)
# --------------------------------------------------------------------------
def run_portfolio(entries, settings, warmup=100, mode="ohlc", costs=None, progress=None, stop_event=None, ai_signals=None):
    """entries: [{"bot_path", "params", "symbol", "tf", "candles", "iid"(tuỳ chọn)}]. Tick của các mã được trộn theo THỜI GIAN,
    mọi bot dùng chung số dư/ký quỹ. Trả BacktestResult có thêm `by_bot` {iid: báo cáo riêng}."""
    res = BacktestResult(symbol=",".join(sorted({e["symbol"] for e in entries})) if entries else "", timeframe="+".join(sorted({e["tf"] for e in entries})) if entries else "",
                         params={})
    res.by_bot = {}
    if not entries:
        res.ok, res.error = False, "Chưa có bot nào trong danh mục"
        return res
    base_cm = costs if isinstance(costs, CostModel) else CostModel.from_settings(settings)
    cm_for = base_cm.for_symbol
    st = dict(settings, mode="paper", exchange="simulated", state_file=None, read_only=False)
    sess = TradingSession(st, sync=True, feed=_ReplayFeed())
    hub = _make_hub(sess, ai_signals, st)
    sess.events = deque(maxlen=400000)
    sess.account = Account(float(st["initial_balance"]), st["commission_pct"], st["leverage"])
    base_cm.apply_to(sess.account)
    sess.status = "running"
    sess.ready.set()
    swapper = _Swapper(sess, cm_for)
    insts, gens, tests, meta = [], [], {}, {}
    for k, e in enumerate(entries):
        cs = [c for c in e["candles"] if c is not None]
        if len(cs) < 5:
            res.ok, res.error = False, "Không đủ dữ liệu nến cho %s (%d)" % (e["symbol"], len(cs))
            return res
        w = max(0, min(int(e.get("warmup", warmup)), len(cs) - 3))
        step = tf_seconds(e["tf"])
        b = CandleBuilder(step, max_len=len(cs) + 10, tf=e["tf"])
        b.seed(cs[:w], cs[w].time)
        sess.builders[(e["symbol"], e["tf"])] = b
        iid = e.get("iid") or "bt%d" % (k + 1)
        inst = sess.attach(e["bot_path"], e["symbol"], e["tf"], e.get("params") or {}, iid=iid)
        inst.plot_cap = 10 ** 7
        insts.append((iid, inst))
        meta[iid] = (e["symbol"], e["tf"])
        test = cs[w:]
        tests[iid] = test

        def gen(test=test, sym=e["symbol"], step=step, k=k):
            for ci, c in enumerate(test):
                tk = candle_ticks(c, step, mode)
                for j in range(len(tk)):
                    if j == 1 and mode == "ohlc_worst":      # heapq.merge lấy tick kế SAU khi tick trước đã được xử lý -> thấy đúng sổ lệnh
                        tk = [tk[0]] + candle_ticks(c, step, mode, _net_volume(sess, sym))[1:]
                    t, p = tk[j]
                    yield (t, k, ci, j, sym, p, step, c.close, j == len(tk) - 1)
        gens.append(gen())
    if hub.replaying and tests:
        hub.window = (min(t[0].time for t in tests.values()), max(t[-1].time for t in tests.values()))
    try:
        for iid, inst in insts:
            inst.start()
    except _Halt as h:
        res.ok, res.error = False, str(h)
        return res
    except Exception as e:                                       # pragma: no cover
        res.ok, res.error = False, "Lỗi khởi tạo backtest danh mục: %s" % e
        return res
    total = sum(len(t) for t in tests.values())
    done = 0
    curve, err, last_tick = [], "", None
    try:
        for t, k, ci, j, sym, p, step, close, last in heapq.merge(*gens, key=lambda x: (x[0], x[1], x[2], x[3])):
            if stop_event is not None and stop_event.is_set():
                err = "Đã dừng theo yêu cầu"
                break
            half = cm_for(sym).half_spread(p)
            last_tick = Tick(sym, t, p - half, p + half)
            sess.process_tick(last_tick)
            if last:
                swapper.accrue(sym, t, close)
                sess._check_max_loss()
                sess._check_margin()
                curve.append((t, sess.account.balance, sess.account.equity()))
                done += 1
                if progress and (done % 50 == 0 or done == total):
                    progress(done, total)
    except _Halt as h:
        err = ("Bot lỗi: " + str(h)) if h.error else str(h)
        if h.error:
            res.ok = False
    except Exception as e:
        res.ok, err = False, "Lỗi backtest danh mục: %s" % e
    finally:
        try:
            if last_tick is not None and sess.account.positions:
                sess.close_all("stop", "Kết thúc backtest: đóng lệnh còn mở theo giá cuối")
                curve.append((last_tick.time, sess.account.balance, sess.account.equity()))
            for _iid, inst in insts:
                if inst.bot is not None:
                    inst.bot.on_deinit("backtest_end")
        except Exception:
            pass
    res.error = err
    res.trades = list(sess.account.trades)
    res.events = list(sess.events)
    res.curve = curve
    res.logs = [x[3] for x in sess.logs][-200:]
    res.report = compute_report(res.trades, float(st["initial_balance"]), curve, total)
    res.report.update(cost_breakdown(res.trades, cm_for))
    res.report["Mô phỏng tick"] = MODES.get(mode, mode)
    res.report["Số bot"] = len(insts)
    if hub.summary():
        res.report["Tín hiệu AI"] = hub.summary()
    for iid, inst in insts:
        mine = [t for t in res.trades if t.owner == iid]
        rep = compute_report(mine, float(st["initial_balance"]), [(c[0], float(st["initial_balance"]) + sum(x.profit for x in mine if x.close_time <= c[0]),
                                                                  float(st["initial_balance"]) + sum(x.profit for x in mine if x.close_time <= c[0])) for c in curve[::max(1, len(curve) // 400)]],
                             len(tests[iid]))
        res.by_bot[iid] = {"symbol": meta[iid][0], "tf": meta[iid][1], "trades": len(mine), "net": sum(x.profit for x in mine), "report": rep}
    res.candles = []
    res.plots = {iid + ":" + n: list(sr.items()) for iid, inst in insts for n, sr in inst.plots.items()}
    return res


# --------------------------------------------------------------------------
# Walk-forward (như Forward/Walk-forward Optimization): tối ưu trên đoạn IN-SAMPLE, kiểm trên đoạn OUT-OF-SAMPLE kế tiếp, trượt dần
# --------------------------------------------------------------------------
def walk_forward(bot_path, base_params, grid, settings, symbol, tf, candles, warmup=100, is_bars=500, oos_bars=125, anchored=False,
                 mode="open", sort_key="Lợi nhuận ròng", max_runs=60, costs=None, progress=None, stop_event=None, ai_signals=None):
    """Trả dict: ok, error, windows[{is_from,is_to,oos_from,oos_to,params,is_value,oos_value,oos_trades}], report (gộp các đoạn OOS),
    trades, curve (nối các đoạn OOS), wfe (hiệu suất walk-forward = lãi/nến OOS ÷ lãi/nến IS), positive_windows_pct.
    anchored=True: IN-SAMPLE luôn bắt đầu từ đầu và dài dần; False: cửa sổ IN-SAMPLE cố định trượt theo."""
    out = {"ok": True, "error": "", "windows": [], "report": {}, "trades": [], "curve": [], "wfe": None, "positive_windows_pct": None,
           "sort_key": sort_key, "anchored": bool(anchored)}
    cs = [c for c in candles if c is not None]
    is_bars, oos_bars = int(is_bars), int(oos_bars)
    if is_bars < 20 or oos_bars < 5:
        out.update(ok=False, error="Cửa sổ quá ngắn (IS >= 20 nến, OOS >= 5 nến)")
        return out
    w0 = max(0, min(int(warmup), len(cs) - 3))
    m = len(cs) - w0
    if m < is_bars + oos_bars:
        out.update(ok=False, error="Không đủ dữ liệu: cần ít nhất %d nến sau warm-up, có %d" % (is_bars + oos_bars, m))
        return out
    wins, start = [], 0
    while True:
        is_from = 0 if anchored else start
        is_to = start + is_bars
        if is_to + oos_bars > m:
            break
        wins.append((is_from, is_to, is_to, is_to + oos_bars))
        start += oos_bars
    start_balance = float(settings.get("initial_balance", 10000.0))
    all_trades, curve, offset, is_vals, oos_net, oos_n = [], [], 0.0, [], 0.0, 0

    def seg(a, b):
        lead = min(w0, w0 + a)
        return cs[w0 + a - lead: w0 + b], lead
    for wi, (a, b, c, d) in enumerate(wins):
        if stop_event is not None and stop_event.is_set():
            out["error"] = "Đã dừng theo yêu cầu"
            break
        isc, lead = seg(a, b)
        best = optimize(bot_path, base_params, grid, settings, symbol, tf, isc, lead, mode, 1, sort_key, max_runs, costs=costs, ai_signals=ai_signals) if grid else []
        if best:
            params, isv = best[0]["params"], best[0]["report"].get(sort_key)
        else:
            params, isv = dict(base_params or {}), None
            if not grid:
                r0 = run_backtest(bot_path, params, settings, symbol, tf, isc, lead, mode, costs=costs, ai_signals=ai_signals)
                isv = r0.report.get(sort_key) if r0.report else None
        oc, lead2 = seg(c, d)
        r = run_backtest(bot_path, params, settings, symbol, tf, oc, lead2, mode, costs=costs, ai_signals=ai_signals)
        net = sum(t.profit for t in r.trades)
        ov = r.report.get(sort_key) if r.report else None
        out["windows"].append({"index": wi + 1, "is_from": cs[w0 + a].time, "is_to": cs[w0 + b - 1].time, "oos_from": cs[w0 + c].time,
                               "oos_to": cs[w0 + d - 1].time, "params": params, "is_value": isv, "oos_value": ov, "oos_net": net,
                               "oos_trades": len(r.trades), "oos_error": r.error if not r.ok else ""})
        for t in r.trades:
            all_trades.append(dc_replace(t))
        for (tt, bal, eq) in r.curve:
            curve.append((tt, start_balance + offset + (bal - start_balance), start_balance + offset + (eq - start_balance)))
        offset += net
        oos_net += net
        oos_n += d - c
        if isv is not None and sort_key == "Lợi nhuận ròng":
            is_vals.append(isv / max(1, b - a))
        if progress:
            progress(wi + 1, len(wins))
    out["trades"], out["curve"] = all_trades, curve
    out["report"] = compute_report(all_trades, start_balance, curve, oos_n) if curve else {}
    pos = [w for w in out["windows"] if (w["oos_net"] or 0) > 0]
    out["positive_windows_pct"] = (len(pos) / len(out["windows"]) * 100.0) if out["windows"] else None
    if is_vals and oos_n:
        mean_is = sum(is_vals) / len(is_vals)
        out["wfe"] = ((oos_net / oos_n) / mean_is) if mean_is > 1e-12 else None
    return out
