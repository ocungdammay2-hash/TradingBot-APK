"""Giao diện MT5 trực tiếp: «Kiểm tra kết nối MT5» và «Thử lệnh DEMO MT5» (chạy ngay trên điện thoại, không cần máy tính). Logic ở pyea/mt5ws.py."""
import threading

from kivy.clock import mainthread
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout

import os

from . import android_utils, mt5ea, mt5ws
from .ui_widgets import AMBER, BLUE, DOWN, PANEL2, UP, StyledPopup, confirm, flabel, mk_input, mkbtn, popup


def _show(rows, title):
    worst = "LỖI" if any(l == "LỖI" for l, _ in rows) else "CHÚ Ý" if any(l == "CHÚ Ý" for l, _ in rows) else "OK"
    mark = {"OK": "✓", "CHÚ Ý": "!", "LỖI": "✗"}
    text = "\n\n".join("%s %s" % (mark[l], t) for l, t in rows)
    if worst == "OK":
        text += "\n\nMọi bước đều qua. Luôn thử DEMO trước khi dùng tiền thật."
    popup(title + (" - có lỗi" if worst == "LỖI" else " - cần chú ý" if worst == "CHÚ Ý" else " - đạt"), text, size=(0.94, 0.85), color=DOWN if worst == "LỖI" else AMBER if worst == "CHÚ Ý" else UP)


def mt5ws_test(app, trade=False):
    vals, errs = app.settings_tab.gform.read()
    if errs:
        popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
        return
    if vals.get("exchange") != "mt5ws":
        popup("Chưa chọn MT5 trực tiếp", "Hãy đặt «Nguồn thị trường / sàn» = mt5ws rồi thử lại.", size=(0.9, 0.35), color=AMBER)
        return

    def work():
        rows = mt5ws.selftest(vals, trade=trade)
        done(rows)

    @mainthread
    def done(rows):
        _show(rows, "Thử lệnh DEMO MT5" if trade else "Kiểm tra kết nối MT5")

    def go(*_):
        app.toast("Đang thử lệnh DEMO MT5..." if trade else "Đang kiểm tra kết nối MT5...")
        threading.Thread(target=work, daemon=True).start()
    if trade:
        confirm("Thử lệnh trên DEMO", "App sẽ mua khối lượng NHỎ NHẤT của một mã rồi đóng ngay. Chỉ chạy nếu là tài khoản DEMO (tài khoản thật sẽ bị từ chối). Tiếp tục?", go)
    else:
        go()


def mt5ws_notify_test(app):
    """Gửi một thông báo thử tới MT5 mobile của tài khoản (lệnh 42). Cần đã nối MetaQuotes ID/thông báo đẩy trên điện thoại."""
    vals, errs = app.settings_tab.gform.read()
    if errs or vals.get("exchange") != "mt5ws":
        popup("Chưa sẵn sàng", "\n".join(errs) or "Hãy đặt «Nguồn thị trường / sàn» = mt5ws rồi thử lại.", size=(0.9, 0.4), color=AMBER)
        return

    def work():
        try:
            b = mt5ws.make_backend(vals)
            try:
                b.notify_mobile("PyEA Runner: thông báo thử")
            finally:
                b.close()
            msg = ("Đã gửi lệnh thông báo. Nếu điện thoại không nhận được: sàn có thể không bật thông báo đẩy cho tài khoản này (giao thức không báo lại việc đã tới nơi hay chưa).", UP)
        except Exception as e:
            msg = (str(e), DOWN)
        show(*msg)

    @mainthread
    def show(text, color):
        popup("Thông báo MT5 mobile", text, size=(0.9, 0.5), color=color)
    app.toast("Đang gửi thông báo thử...")
    threading.Thread(target=work, daemon=True).start()


def mt5ws_open_demo(app):
    """Mở tài khoản DEMO mới ngay trên điện thoại (lệnh 29+30) bằng địa chỉ web terminal đang cài. Chỉ hiện kết quả, KHÔNG tự lưu: người dùng tự điền vào Cài đặt."""
    vals, errs = app.settings_tab.gform.read()
    uri = str(vals.get("mt5ws_uri") or "").strip() if vals else ""
    box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8))
    box.add_widget(flabel("Mở tài khoản DEMO trên máy chủ: %s\n(đổi địa chỉ ở ô «mt5ws_uri» nếu muốn broker khác). Nhiều broker bắt xác minh email/SMS nên có thể bị từ chối." % (mt5ws.normalize_uri(uri) or mt5ws.DEFAULT_URI), 12))
    name, email, dep, lev = mk_input("Nguyen Van A", "Họ tên"), mk_input("", "Email (nếu broker yêu cầu)"), mk_input("10000", "Số dư DEMO"), mk_input("100", "Đòn bẩy")
    for w in (name, email, dep, lev):
        w.size_hint_y = None
        w.height = dp(44)
        box.add_widget(w)
    row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
    pop = StyledPopup(title="Mở tài khoản DEMO", content=box, size_hint=(0.92, 0.75), auto_dismiss=False)

    def work(args):
        try:
            r = mt5ws.open_demo_account(uri, args[0], args[1], "", float(args[2] or 10000), int(float(args[3] or 100)))
            text, color = ("Đã mở DEMO.\nSố tài khoản: %s\nMật khẩu giao dịch: %s\nMật khẩu chỉ-xem: %s\n\nGHI LẠI NGAY (app không lưu hộ), rồi nhập vào Cài đặt: mt5ws_login / mt5ws_password."
                           % (r["login"], r["password"], r["investor"]), UP)
        except Exception as e:
            text, color = str(e), DOWN
        show(text, color)

    @mainthread
    def show(text, color):
        popup("Mở tài khoản DEMO", text, size=(0.92, 0.6), color=color)

    def go(*_):
        pop.dismiss()
        app.toast("Đang mở tài khoản DEMO...")
        threading.Thread(target=work, args=((name.text, email.text, dep.text, lev.text),), daemon=True).start()
    row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
    row.add_widget(mkbtn("Mở DEMO", BLUE, on_release=go))
    box.add_widget(row)
    pop.open()


def mt5ea_test(app):
    """Kiểm tra cầu nối EA: mở cổng cục bộ, đợi EA nối, đọc tài khoản/giá/vị thế (không đặt lệnh)."""
    vals, errs = app.settings_tab.gform.read()
    if errs:
        popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
        return
    if vals.get("exchange") != "mt5ea":
        popup("Chưa chọn MT5 qua EA", "Hãy đặt «Nguồn thị trường / sàn» = mt5ea rồi thử lại. (Tính năng này TUỲ CHỌN và không bao giờ tự bật.)", size=(0.9, 0.4), color=AMBER)
        return

    def work():
        done(mt5ea.selftest(vals, wait=25.0))

    @mainthread
    def done(rows):
        _show(rows, "Kiểm tra cầu nối EA")
    app.toast("Đang đợi EA nối (tối đa 25 giây)...")
    threading.Thread(target=work, daemon=True).start()


def mt5ea_export_files(app):
    """Ghi bridge.set, startup.ini và mã EA (PyEABridge.mq5) từ Cài đặt ra thư mục của app (Android/data/<gói>/files/mt5_bridge) để chép sang MT5."""
    vals, errs = app.settings_tab.gform.read()
    bad = list(errs or []) + mt5ea.problems(vals or {}, require=True)
    if bad:
        popup("Chưa đủ thông tin", "\n".join(bad), size=(0.9, 0.5), color=DOWN)
        return
    base = android_utils.external_files_dir() or app.data_dir
    out = os.path.join(base, "mt5_bridge")
    try:
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, "bridge.set"), "w", encoding="utf-8") as f:
            f.write(mt5ea.make_set_file(vals))
        with open(os.path.join(out, "startup.ini"), "w", encoding="utf-8") as f:
            f.write(mt5ea.make_startup_ini(vals))
        with open(os.path.join(out, "PyEABridge.mq5"), "w", encoding="utf-8") as f:
            f.write(mt5ea.ea_source())
    except OSError as e:
        popup("Không ghi được file", str(e), size=(0.9, 0.4), color=DOWN)
        return
    popup("Đã tạo file cấu hình EA", "Thư mục: %s\n\nCách KHÔNG cần mở MT5: trong Termux chạy `PYEA_TOKEN=<token> MT5_DIR=<thư mục MT5> bash run_mt5_termux.sh setup` - script lấy các file này TỪ APP, ghi vào MT5 và biên dịch EA; "
          "lỗi biên dịch (nếu có) tự hiện trong app (EA CHƯA được biên dịch thử).\n\n• PyEABridge.mq5: mã EA.\n• bridge.set: tham số EA (cổng + token).\n• startup.ini: mẫu khởi động MT5 tối giản.\n\n"
          "Token trong các file này là bí mật, đừng chia sẻ." % out, size=(0.94, 0.7), color=UP)


def mt5ea_export_diag(app):
    """Xuất nhật ký chẩn đoán cầu nối (log MT5/giám sát/EA đã đẩy về app; token đã che) ra file văn bản để gửi đi - không cần mở MT5."""
    srvs = list(getattr(mt5ea, "_SERVERS", {}).values())
    if not srvs:
        popup("Chưa có gì để xuất", "Cầu nối EA chưa được bật (đặt «Nguồn thị trường / sàn» = mt5ea và bấm «Kiểm tra EA cầu nối»).", size=(0.9, 0.4), color=AMBER)
        return
    text = "\n".join(s.diagnostics_text() for s in srvs)
    base = android_utils.external_files_dir() or app.data_dir
    out = os.path.join(base, "mt5_bridge")
    path = os.path.join(out, "chan_doan_ea.txt")
    try:
        os.makedirs(out, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
    except OSError as e:
        popup("Không ghi được file", str(e), size=(0.9, 0.4), color=DOWN)
        return
    tail = "\n".join(text.splitlines()[-18:])
    popup("Đã xuất chẩn đoán", "File: %s\n(token đã được che)\n\n%s" % (path, tail), size=(0.94, 0.8), color=UP)
