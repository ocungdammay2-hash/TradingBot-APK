"""Giao diện MT5 trực tiếp: «Kiểm tra kết nối MT5» và «Thử lệnh DEMO MT5» (chạy ngay trên điện thoại, không cần máy tính). Logic ở pyea/mt5ws.py."""
import threading

from kivy.clock import mainthread

from . import mt5ws
from .ui_widgets import AMBER, DOWN, UP, confirm, popup


def _show(rows, title):
    worst = "LỖI" if any(l == "LỖI" for l, _ in rows) else "CHÚ Ý" if any(l == "CHÚ Ý" for l, _ in rows) else "OK"
    mark = {"OK": "✓", "CHÚ Ý": "!", "LỖI": "✗"}
    text = "\n\n".join("%s %s" % (mark[l], t) for l, t in rows)
    if worst == "OK":
        text += "\n\nMọi bước đều qua. Luôn thử DEMO trước khi dùng tiền thật."
    popup(title + (" - có lỗi" if worst == "LỖI" else " - cần chú ý" if worst == "CHÚ Ý" else " - đạt"), text, size=(0.94, 0.85), color=DOWN if worst == "LỖI" else AMBER if worst == "CHÚ Ý" else UP)


def mt5ws_test(app, trade=False):
    vals, errs = app.settings_tab.gform.read()
    if errs:
        popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
        return
    if vals.get("exchange") != "mt5ws":
        popup("Chưa chọn MT5 trực tiếp", "Hãy đặt «Nguồn thị trường / sàn» = mt5ws rồi thử lại.", size=(0.9, 0.35), color=AMBER)
        return

    def work():
        rows = mt5ws.selftest(vals, trade=trade)
        done(rows)

    @mainthread
    def done(rows):
        _show(rows, "Thử lệnh DEMO MT5" if trade else "Kiểm tra kết nối MT5")

    def go(*_):
        app.toast("Đang thử lệnh DEMO MT5..." if trade else "Đang kiểm tra kết nối MT5...")
        threading.Thread(target=work, daemon=True).start()
    if trade:
        confirm("Thử lệnh trên DEMO", "App sẽ mua khối lượng NHỎ NHẤT của một mã rồi đóng ngay. Chỉ chạy nếu là tài khoản DEMO (tài khoản thật sẽ bị từ chối). Tiếp tục?", go)
    else:
        go()
