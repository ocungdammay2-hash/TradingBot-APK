"""Mô tả «khung dữ liệu bot dùng» (không Kivy): nguồn nến của từng khung khác khung bot + ghi chú tải."""
import time

SOURCE_TEXT = {"real": "nến thật", "builder": "nến sàn (lịch sử + cache)", "resampled": "GHÉP từ khung bot (hạn chế)"}


def _d(t):
    return time.strftime("%Y-%m-%d %H:%M", time.gmtime(t)) if t else "-"


def mtf_lines(mtf):
    """{khung: {source, n, first, last}} -> [dòng chữ]."""
    out = []
    for tf, v in sorted((mtf or {}).items()):
        out.append("%s: %s · %d nến (%s → %s)" % (tf, SOURCE_TEXT.get(v.get("source"), v.get("source")), v.get("n", 0), _d(v.get("first")), _d(v.get("last"))))
    return out


def mtf_text(mtf, notes=None):
    lines = mtf_lines(mtf) + list(notes or [])
    resampled = [tf for tf, v in (mtf or {}).items() if v.get("source") == "resampled"]
    if resampled:
        lines.append("Bot hỏi khung %s mà chưa khai báo `# @mtf: %s` ở đầu file bot: backtest chỉ ghép từ nến khung bot nên lịch sử ngắn." % (", ".join(sorted(resampled)), ",".join(sorted(resampled))))
    return " | ".join(lines)
