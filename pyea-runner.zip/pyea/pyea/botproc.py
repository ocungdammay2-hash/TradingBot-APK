"""
CÔ LẬP TIẾN TRÌNH CHO BOT (cài đặt `bot_isolation = process`, mặc định `thread`).

Mã bot chạy ở MỘT TIẾN TRÌNH PYTHON RIÊNG; vỏ chỉ trao đổi dữ liệu qua pipe JSON (không pickle, không chia sẻ bộ nhớ):
  vỏ -> bot : on_init / on_tick / on_bar / on_trade / on_timer / on_deinit / đổi tham số
  bot -> vỏ : mọi lời gọi `self.api.*` (buy/sell/positions/candles/...) là RPC, vỏ thực thi bằng đúng BotContext như chế độ luồng.

ĐƯỢC GÌ (đã kiểm thử): bot treo/vòng lặp vô hạn bị GIẾT được (`bot_hang_kill_s`), bot crash/os._exit/segfault/hết bộ nhớ không kéo sập app,
môi trường con sạch (không thừa hưởng biến môi trường chứa khoá), không đọc được bộ nhớ của vỏ (không có khoá/settings trong tiến trình con),
giới hạn bộ nhớ (`bot_mem_mb`, POSIX).

KHÔNG ĐƯỢC GÌ (nói thẳng): tiến trình con chạy cùng người dùng OS nên vẫn đọc được TỆP trong thư mục dữ liệu. Với khoá API được mã hoá bằng
Android Keystore, tệp đó vô dụng với tiến trình con (khoá nằm trong Keystore, cần JVM) - nhưng với khoá file trên máy tính thì KHÔNG.
ANDROID: không có trình thông dịch Python để sinh tiến trình con (Popen vô dụng) và p4a chỉ cho khai báo dịch vụ LÚC DỰNG APK. Vì vậy app khai báo sẵn
`WORKER_SLOTS` dịch vụ worker (Botworker0..N, buildozer.spec) - mỗi dịch vụ p4a là MỘT TIẾN TRÌNH Android riêng với trình thông dịch Python riêng. Mỗi bot lấy
một «chỗ», vỏ mở cổng loopback 127.0.0.1 (cổng ngẫu nhiên + mã bí mật dùng một lần), khởi động dịch vụ kèm cổng/mã qua PYTHON_SERVICE_ARGUMENT; worker
(service_botworker.py) nối vào, nói đúng giao thức JSON ở trên (chỉ khác đường truyền: socket thay cho pipe). Giết bot treo = dừng dịch vụ (p4a: onDestroy ->
Process.killProcess). Hết chỗ / APK dựng từ cấu hình cũ (không có dịch vụ worker) / không nối được -> tự rơi về chế độ luồng và ghi cảnh báo.
Khác biệt trên Android: `bot_mem_mb` không áp dụng (RLIMIT_AS làm hỏng tiến trình có JVM). Backtest luôn chạy chế độ luồng (tất định, nhanh).
CHƯA kiểm chứng trên thiết bị thật (không có Android trong môi trường phát triển): phần đường truyền socket + worker được kiểm thử bằng TIẾN TRÌNH THẬT
khởi chạy qua điểm tiêm `LAUNCHER`, còn các lời gọi pyjnius khởi động/dừng dịch vụ thì chỉ đọc theo tài liệu p4a.
"""
import hmac
import json
import os
import queue
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import fields, is_dataclass

from . import sdk
from .sdk import Input

_CLASSES = {n: getattr(sdk, n) for n in ("Tick", "Candle", "Position", "Trade", "PendingOrder", "OrderResult", "TradeUpdate", "SymbolInfo", "AccountInfo")
            if hasattr(sdk, n)}
_EXC = {"ValueError": ValueError, "KeyError": KeyError, "TypeError": TypeError, "IndexError": IndexError, "ZeroDivisionError": ZeroDivisionError,
        "AttributeError": AttributeError, "NotImplementedError": NotImplementedError, "OverflowError": OverflowError, "AssertionError": AssertionError}


class ProcessUnavailable(Exception):
    pass


class BotCrash(Exception):
    """Mã bot ném ngoại lệ trong tiến trình con (nội dung = traceback phía con)."""


def enc(o):
    if is_dataclass(o) and not isinstance(o, type):
        d = {f.name: enc(getattr(o, f.name)) for f in fields(o)}
        d["__t__"] = type(o).__name__
        return d
    if isinstance(o, dict):
        return {str(k): enc(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set, frozenset)):
        return [enc(v) for v in o]
    if o is None or isinstance(o, (bool, int, float, str)):
        return o
    raise TypeError("không truyền được kiểu %s qua ranh giới tiến trình" % type(o).__name__)


def dec(o):
    if isinstance(o, dict):
        t = o.get("__t__")
        if t in _CLASSES:
            known = {f.name for f in fields(_CLASSES[t])}
            return _CLASSES[t](**{k: dec(v) for k, v in o.items() if k in known})
        return {k: dec(v) for k, v in o.items()}
    if isinstance(o, list):
        return [dec(v) for v in o]
    return o


WORKER_SLOTS = 4            # số dịch vụ worker khai báo trong buildozer.spec (Botworker0..3); đổi ở đây phải đổi cả buildozer.spec
ACCEPT_S = 25.0             # chờ worker nối vào bao lâu (khởi động dịch vụ + nạp Python mất vài giây)
TRANSPORT = None            # None = tự chọn (Android -> socket, còn lại pipe) · "pipe" · "socket" (test)
LAUNCHER = None             # điểm tiêm: hàm (slot, argument_json) -> (ok, lỗi). None = khởi động dịch vụ p4a qua pyjnius
KILLER = None               # điểm tiêm: hàm (slot) -> None. None = dừng dịch vụ p4a (p4a: onDestroy -> killProcess)


def is_android():
    return bool(os.environ.get("ANDROID_ARGUMENT")) or ("ANDROID_ROOT" in os.environ and "ANDROID_DATA" in os.environ)


SLOT_COOLDOWN_S = 3.0       # sau khi một worker kết thúc, chỗ đó «nguội» ngần này giây rồi mới cho bot khác dùng (xem SlotPool)


class SlotPool:
    """Chỗ worker: mỗi bot ở tiến trình riêng chiếm một chỗ đến khi bị giải phóng.
    Chỗ vừa giải phóng còn «nguội» `cooldown` giây: dừng dịch vụ p4a là BẤT ĐỒNG BỘ (onDestroy -> killProcess chạy sau) nên khởi động lại NGAY cùng dịch vụ có thể
    bị giết nhầm bởi lệnh dừng cũ. Bot khởi động ngay sau đó chờ chỗ nguội (tối đa `cooldown`) hoặc dùng chỗ khác."""

    def __init__(self, n):
        self.n, self._used, self._ready_at, self._lock = n, set(), {}, threading.Lock()

    def _pick(self, now):
        for k in range(self.n):
            if k not in self._used and self._ready_at.get(k, 0.0) <= now:
                return k
        return None

    def acquire(self):
        for _ in range(2):
            with self._lock:
                k = self._pick(time.monotonic())
                if k is not None:
                    self._used.add(k)
                    return k
                waits = [self._ready_at[j] for j in range(self.n) if j not in self._used and j in self._ready_at]
            if not waits:
                return None
            time.sleep(max(0.0, min(waits) - time.monotonic()) + 0.01)
        return None

    def release(self, k, cooldown=0.0):
        with self._lock:
            self._used.discard(k)
            if cooldown > 0:
                self._ready_at[k] = time.monotonic() + cooldown
            else:
                self._ready_at.pop(k, None)

    def free(self):
        """Số chỗ chưa bị bot chiếm (kể cả chỗ đang nguội: chúng sẽ sẵn sàng sau vài giây)."""
        with self._lock:
            return self.n - len(self._used)


POOL = SlotPool(WORKER_SLOTS)


def _android_ctx():
    from . import android_native as an
    return an


def _default_launch(slot, argument):
    an = _android_ctx()
    return an.start_service(argument, name=an.worker_name(slot), foreground=False)


def _default_kill(slot):
    an = _android_ctx()
    an.stop_service(an.worker_name(slot))


def use_socket():
    return TRANSPORT == "socket" or (TRANSPORT is None and is_android())


def available():
    """(ok, lý do). Pipe: cần trình thông dịch Python. Socket (Android): cần dịch vụ worker trong APK và còn chỗ trống."""
    if use_socket():
        if POOL.free() <= 0:
            return False, "đã dùng hết %d chỗ worker (mỗi bot ở tiến trình riêng chiếm một chỗ)" % WORKER_SLOTS
        if LAUNCHER is not None:
            return True, ""
        try:
            ok = _android_ctx().worker_services_present()
        except Exception as e:                                  # noqa: BLE001 - pyjnius không có / không phải Android thật
            return False, "Android: không kiểm tra được dịch vụ worker (%s)" % type(e).__name__
        if not ok:
            return False, "Android: APK này không có dịch vụ worker (dựng từ buildozer.spec cũ) - cài bản mới để cô lập bot"
        return True, ""
    exe = sys.executable
    if not exe or not os.path.exists(exe):
        return False, "không tìm thấy trình thông dịch Python (sys.executable rỗng)"
    return True, ""


# ===================================================================================== đường truyền socket (Android)
class _Writer:
    def __init__(self, f):
        self._f = f

    def write(self, text):
        self._f.write(text)

    def flush(self):
        self._f.flush()


class _SocketProc:
    """Giao diện giống subprocess.Popen mà RemoteBot dùng (stdin/stdout/poll/kill/wait/returncode/pid) nhưng chạy trên socket tới dịch vụ worker."""

    def __init__(self, conn, slot, kill_fn):
        self.slot, self._kill_fn, self._conn = slot, kill_fn, conn
        self.pid = "worker%d" % slot
        self.returncode = None
        self._rf = conn.makefile("r", encoding="utf-8", newline="\n")
        self._wf = conn.makefile("w", encoding="utf-8", newline="\n")
        self.stdin = _Writer(self._wf)
        self.stdout = self._lines()
        self._released = False

    def _lines(self):
        try:
            for line in self._rf:
                yield line
        except (OSError, ValueError):
            pass
        finally:
            self._ended(-1)                                    # worker đóng kết nối / bị giết: coi như tiến trình đã thoát

    def _ended(self, code):
        if self.returncode is None:
            self.returncode = code
        if not self._released:
            self._released = True
            POOL.release(self.slot, SLOT_COOLDOWN_S)

    def poll(self):
        return self.returncode

    def kill(self):
        """Dừng dịch vụ worker (giết cả tiến trình Android) rồi đóng đường truyền."""
        try:
            self._kill_fn(self.slot)
        except Exception:                                      # noqa: BLE001
            pass
        for f in (self._wf, self._rf):
            try:
                f.close()
            except (OSError, ValueError):
                pass
        try:
            self._conn.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self._conn.close()
        except OSError:
            pass
        self._ended(-9)

    def wait(self, timeout=None):
        end = None if timeout is None else time.monotonic() + timeout
        while self.returncode is None:
            if end is not None and time.monotonic() > end:
                raise subprocess.TimeoutExpired("worker%d" % self.slot, timeout)
            time.sleep(0.02)
        return self.returncode


def _accept_worker(srv, token, deadline):
    """Nhận kết nối ĐẦU TIÊN có mã bí mật đúng. Kết nối khác (ứng dụng khác trên máy cùng dò cổng loopback) bị đóng, không làm hỏng lượt."""
    while True:
        left = deadline - time.monotonic()
        if left <= 0:
            return None
        srv.settimeout(left)
        try:
            conn, _ = srv.accept()
        except (socket.timeout, OSError):
            return None
        try:
            conn.settimeout(5.0)
            line = conn.makefile("r", encoding="utf-8", newline="\n").readline()
            hello = json.loads(line) if line else {}
            if hello.get("t") == "hello" and hmac.compare_digest(str(hello.get("token", "")), token):
                conn.settimeout(None)
                return conn
        except (OSError, ValueError):
            pass
        try:
            conn.close()
        except OSError:
            pass


def _spawn_socket(runner, wd):
    slot = POOL.acquire()
    if slot is None:
        raise ProcessUnavailable("đã dùng hết %d chỗ worker" % WORKER_SLOTS)
    launch, kill = LAUNCHER or _default_launch, KILLER or _default_kill
    srv, launched = None, False
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.bind(("127.0.0.1", 0))
        srv.listen(4)
        token = secrets.token_hex(16)
        launched = True
        ok, err = launch(slot, json.dumps({"port": srv.getsockname()[1], "token": token, "slot": slot, "data_dir": wd}))
        if not ok:
            raise ProcessUnavailable("không khởi động được dịch vụ worker: %s" % (str(err).strip().splitlines() or ["?"])[-1])
        conn = _accept_worker(srv, token, time.monotonic() + ACCEPT_S)
        if conn is None:
            try:
                kill(slot)                                      # worker kẹt/chưa nối: dừng để lần sau dùng lại được (dịch vụ p4a đang chạy sẽ BỎ QUA lệnh start thứ hai)
            except Exception:                                   # noqa: BLE001
                pass
            raise ProcessUnavailable("dịch vụ worker không nối vào sau %.0fs" % ACCEPT_S)
        return _SocketProc(conn, slot, kill)
    except BaseException:
        POOL.release(slot, SLOT_COOLDOWN_S if launched else 0.0)
        raise
    finally:
        if srv is not None:
            srv.close()


# ===================================================================================== phía VỎ (cha)
class RemoteBot:
    """Đóng vai BaseBot cho BotRunner: mỗi callback = một yêu cầu tới tiến trình con; trong lúc chờ phục vụ RPC của bot."""

    def __init__(self, runner, ctx, proc, hang_s=0.0, stop_grace=3.0):
        self.r, self.ctx, self.proc = runner, ctx, proc
        self.hang_s, self.stop_grace = float(hang_s or 0.0), float(stop_grace)
        self.q = queue.Queue()
        self._id = 0
        self._halt = None
        self.dead = False
        threading.Thread(target=self._reader, name="botproc-rd-" + runner.iid, daemon=True).start()

    def _reader(self):
        try:
            for line in self.proc.stdout:
                self.q.put(line)
        except (OSError, ValueError):
            pass
        self.q.put(None)

    def _send(self, obj):
        try:
            self.proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError):
            self._die("tiến trình bot đã đóng pipe")

    def _die(self, why):
        from .engine import _Halt
        self.kill()
        raise _Halt("Tiến trình bot %s: %s" % (self.r.iid, why), error=True, reason="process")

    def kill(self):
        self.dead = True
        try:
            if self.proc.poll() is None:
                self.proc.kill()
                self.proc.wait(2)
        except (OSError, subprocess.TimeoutExpired):
            pass

    def _wait(self, msg):
        """Gửi `msg`, phục vụ RPC của bot, trả thông điệp kết thúc (ret/exc/ready/ack)."""
        self._send(msg)
        t0, stop_seen = time.monotonic(), None
        while True:
            try:
                line = self.q.get(timeout=0.25)
            except queue.Empty:
                if self.proc.poll() is not None:
                    self._die("đã thoát đột ngột (mã %s)" % self.proc.returncode)
                if self.r._stop.is_set():
                    stop_seen = stop_seen or time.monotonic()
                    if time.monotonic() - stop_seen > self.stop_grace:
                        self._die("không phản hồi sau yêu cầu dừng %.0fs -> đã giết" % self.stop_grace)
                if self.hang_s and time.monotonic() - t0 > self.hang_s:
                    self._die("treo quá %.0fs trong callback '%s' -> đã giết tiến trình" % (self.hang_s, msg.get("fn", msg.get("t"))))
                continue
            if line is None:
                self._die("đã thoát đột ngột (mã %s)" % self.proc.poll())
            try:
                m = json.loads(line)
            except ValueError:
                continue                                        # dòng rác (vd print lạc vào stdout)
            if m.get("t") == "rpc":
                self._serve(m)
                continue
            return m

    def _serve(self, m):
        from .engine import _Halt
        name = str(m.get("name", ""))
        rep = {"t": "rpc_ret", "id": m.get("id")}
        try:
            if name.startswith("_") or not hasattr(self.ctx, name):
                raise AttributeError("API không có '%s'" % name)
            v = getattr(self.ctx, name)
            if m.get("op") == "getattr":
                rep.update(kind="callable") if callable(v) else rep.update(kind="value", v=enc(v))
            else:
                rep.update(v=enc(v(*dec(m.get("args", [])), **dec(m.get("kw", {})))))
        except _Halt as h:                                      # api.stop()/lỗi nghiêm trọng: huỷ callback ở phía con, vỏ ném lại sau
            self._halt = h
            rep = {"t": "rpc_ret", "id": m.get("id"), "halt": True}
        except Exception as e:                                  # noqa: BLE001
            rep["err"] = {"type": type(e).__name__, "msg": str(e)}
        self._send(rep)

    def call(self, fn, *args):
        self._id += 1
        res = self._wait({"t": "call", "id": self._id, "fn": fn, "args": enc(list(args))})
        if self._halt is not None:
            h, self._halt = self._halt, None
            raise h
        if res.get("t") == "exc":
            raise BotCrash(res.get("tb", "").strip())
        return dec(res.get("v"))

    # ---- giao diện giống BaseBot ----
    def on_init(self): return self.call("on_init")
    def on_tick(self, tick): return self.call("on_tick", tick)
    def on_bar(self, candle): return self.call("on_bar", candle)
    def on_trade(self, upd): return self.call("on_trade", upd)
    def on_timer(self): return self.call("on_timer")
    def on_deinit(self, reason): return self.call("on_deinit", reason)

    def _set_params(self, new):
        self._id += 1
        res = self._wait({"t": "params", "id": self._id, "params": enc(new)})
        if res.get("t") == "exc":
            raise BotCrash(res.get("tb", "").strip())

    def bind(self, params):
        self._id += 1
        res = self._wait({"t": "bind", "id": self._id, "params": enc(params)})
        if res.get("t") == "exc":
            raise BotCrash(res.get("tb", "").strip())

    def close(self):
        if self.dead:
            return
        try:
            self.proc.stdin.write(json.dumps({"t": "stop"}) + "\n")
            self.proc.stdin.flush()
            self.proc.wait(1.5)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
        self.kill()


def allowed_hosts(runner, dev_mode=False):
    """Danh sách host bot được phép nối (đã khai báo ∩ đã cho phép) hoặc None = không đặt rào (dev_mode / bot_net_policy=off)."""
    st = runner.settings
    if dev_mode or str(st.get("bot_net_policy", "enforce")) != "enforce":
        return None
    from .perms import PermStore, parse_declared
    try:
        with open(runner.bot_path, "r", encoding="utf-8", errors="replace") as f:
            decl = parse_declared(f.read())
    except OSError:
        decl = {"network": []}
    base = getattr(runner.session, "data_dir", None)
    return PermStore(base).effective_hosts(runner.bot_path, decl)


def start_remote_bot(runner, ctx, dev_mode=False):
    """Sinh tiến trình con, nạp bot, trả (RemoteBot, {"name", "inputs": {tên: Input}}). Ném ProcessUnavailable nếu không dùng được."""
    ok, why = available()
    if not ok:
        raise ProcessUnavailable(why)
    st = runner.settings
    wd = runner.data_dir()
    if use_socket():
        proc = _spawn_socket(runner, wd)                       # Android: dịch vụ worker p4a qua socket loopback
    else:
        pkg_parent = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        env = {"PATH": os.defpath, "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1", "LANG": "C.UTF-8", "HOME": wd, "TMPDIR": wd}
        code = "import sys; sys.path.insert(0, %r); from pyea.botproc import child_main; child_main()" % pkg_parent
        mem = int(st.get("bot_mem_mb") or 0)
        pre = None
        if mem > 0 and os.name == "posix":
            def pre():                                          # noqa: E306 - chạy trong tiến trình con trước exec
                import resource
                resource.setrlimit(resource.RLIMIT_AS, (mem << 20, mem << 20))
        try:
            errf = open(os.path.join(wd, "child.log"), "w", encoding="utf-8")
            proc = subprocess.Popen([sys.executable, "-s", "-c", code], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errf, cwd=wd, env=env,
                                    text=True, encoding="utf-8", bufsize=1, preexec_fn=pre, close_fds=True)
        except OSError as e:
            raise ProcessUnavailable("không sinh được tiến trình con: %s" % e)
    rb = RemoteBot(runner, ctx, proc, hang_s=float(st.get("bot_hang_kill_s") or 0.0))
    rb._id += 1
    net = allowed_hosts(runner, dev_mode)
    res = rb._wait({"t": "init", "id": rb._id, "path": runner.bot_path, "dev_mode": bool(dev_mode), "net": net})
    if res.get("t") == "exc":
        rb.kill()
        from .loader import BotLoadError
        raise BotLoadError(res.get("tb", "").strip().splitlines()[-1] if res.get("tb") else "lỗi nạp bot")
    inputs = {k: Input(d["default"], d.get("label"), d.get("min"), d.get("max"), d.get("step"), d.get("choices"), d.get("help", ""), d.get("group"),
                       d.get("secret", False)) for k, d in (res.get("inputs") or {}).items()}
    from .loader import InputsDict
    ins = InputsDict(inputs)
    ins.aliases = dict(res.get("aliases") or {})
    return rb, {"name": res.get("name") or os.path.basename(runner.bot_path), "inputs": ins}


# ===================================================================================== phía BOT (con)
class _ChildHalt(BaseException):
    pass


class _Io:
    def __init__(self, rf, wf):
        self.rf, self.wf, self.n = rf, wf, 0

    def send(self, obj):
        self.wf.write(json.dumps(obj, ensure_ascii=False) + "\n")
        self.wf.flush()

    def recv(self):
        line = self.rf.readline()
        if not line:
            raise SystemExit(0)                                  # cha đã đóng pipe
        return json.loads(line)

    def rpc(self, op, name, args=None, kw=None):
        self.n += 1
        self.send({"t": "rpc", "id": self.n, "op": op, "name": name, "args": enc(list(args or [])), "kw": enc(kw or {})})
        while True:
            m = self.recv()
            if m.get("t") == "rpc_ret" and m.get("id") == self.n:
                if m.get("halt"):
                    raise _ChildHalt()
                if m.get("err"):
                    raise _EXC.get(m["err"]["type"], RuntimeError)(m["err"]["msg"])
                return m


class _KVProxy:
    """api.store / api.shared phía bot: mỗi thao tác là một RPC `kv_call` (vỏ giữ dữ liệu và ghi đĩa)."""

    def __init__(self, io, space):
        self._io, self._space = io, space

    def _call(self, op, *a):
        return dec(self._io.rpc("call", "kv_call", [self._space, op] + list(a)).get("v"))

    def get(self, key, default=None): return self._call("get", key, default)
    def set(self, key, value):
        try:                                                    # kiểm ở phía bot: enc() sẽ lặng lẽ đổi set -> list, khác chế độ luồng
            json.dumps(value, ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError) as e:
            raise ValueError("Giá trị phải là JSON (None/bool/số/chuỗi/list/dict, không NaN): %s" % e)
        return self._call("set", key, value)

    def delete(self, key): return self._call("delete", key)
    def has(self, key): return self._call("has", key)
    def keys(self): return self._call("keys")
    def items(self): return self._call("items")
    def clear(self): return self._call("clear")
    def incr(self, key, delta=1): return self._call("incr", key, delta)
    def size(self): return self._call("size")


class _ApiProxy:
    def __init__(self, io):
        self.__dict__["_io"] = io
        self.__dict__["_kinds"] = {}

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        if name in ("store", "shared"):
            return _KVProxy(self._io, name)
        io, kinds = self._io, self._kinds
        if kinds.get(name) is True:
            return lambda *a, **k: dec(io.rpc("call", name, a, k).get("v"))
        r = io.rpc("getattr", name)
        if r.get("kind") == "callable":
            kinds[name] = True
            return lambda *a, **k: dec(io.rpc("call", name, a, k).get("v"))
        kinds[name] = False
        return dec(r.get("v"))

    def __setattr__(self, name, value):
        raise AttributeError("api là chỉ-đọc")


def child_main(rf=None, wf=None):
    """Điểm vào của tiến trình bot. Mặc định (pipe): stdout GỐC dành cho giao thức, print() của bot chuyển sang stderr (child.log).
    Có `rf`/`wf` (worker Android, socket): dùng đúng hai luồng đó; service_botworker.py đã chuyển stdout/stderr sang child.log."""
    if rf is None:
        proto = os.fdopen(os.dup(1), "w", encoding="utf-8")
        sys.stdout = sys.stderr
        io = _Io(sys.stdin, proto)
    else:
        io = _Io(rf, wf)
    cls, bot = None, None
    try:
        while True:
            m = io.recv()
            t, mid = m.get("t"), m.get("id")
            try:
                if t == "init":
                    if m.get("net") is not None:                   # rào mạng TRƯỚC khi nạp mã bot (code cấp module cũng bị chặn)
                        from .perms import install_network_guard
                        install_network_guard(m["net"])
                    from .loader import collect_inputs, load_bot_class
                    cls, _ = load_bot_class(m["path"], bool(m.get("dev_mode")))
                    ins = collect_inputs(cls, m["path"])
                    io.send({"t": "ready", "id": mid, "name": getattr(cls, "name", None) or cls.__name__,
                             "inputs": {k: {"default": v.default, "label": v.label, "min": v.min, "max": v.max, "step": v.step, "choices": v.choices,
                                            "help": v.help, "group": v.group, "secret": v.secret} for k, v in ins.items()},
                             "aliases": dict(getattr(ins, "aliases", None) or {})})
                elif t == "bind":
                    bot = cls(_ApiProxy(io), dec(m["params"]))
                    io.send({"t": "ack", "id": mid})
                elif t == "params":
                    bot._set_params(dec(m["params"]))
                    io.send({"t": "ack", "id": mid})
                elif t == "call":
                    try:
                        v = getattr(bot, m["fn"])(*dec(m.get("args", [])))
                        io.send({"t": "ret", "id": mid, "v": enc(v)})
                    except _ChildHalt:
                        io.send({"t": "ret", "id": mid, "halted": True})
                elif t == "stop":
                    break
            except _ChildHalt:
                io.send({"t": "ret", "id": mid, "halted": True})
            except SystemExit:
                raise
            except BaseException:                                 # noqa: BLE001 - lỗi của MÃ BOT: báo traceback cho vỏ, tiến trình vẫn sống
                io.send({"t": "exc", "id": mid, "tb": traceback.format_exc(limit=8)})
    except SystemExit:
        pass
