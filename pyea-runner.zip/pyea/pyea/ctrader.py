"""
cTrader Open API (Spotware) - NỐI THẲNG từ điện thoại tới broker cTrader: KHÔNG máy tính, KHÔNG VPS, KHÔNG dịch vụ trung gian (không MetaApi...).
App mở một kết nối WebSocket (JSON, cổng 5036) tới live.ctraderapi.com / demo.ctraderapi.com - máy chủ chính thức của Spotware - rồi xác thực bằng
ứng dụng (client id/secret do CHÍNH BẠN đăng ký ở openapi.ctrader.com) + access token của tài khoản cTrader ID của bạn.

ĐÃ ĐỐI CHIẾU (tài liệu help.ctrader.com/open-api + các file .proto chính thức của Spotware, 08/11/2026): host/cổng; phong bì JSON {clientMsgId, payloadType,
payload}; payloadType (2100.. và HEARTBEAT 51); trình tự ApplicationAuth -> (GetAccountListByAccessToken) -> AccountAuth; trường của NewOrder/AmendOrder/
AmendPositionSLTP/ClosePosition/CancelOrder/Reconcile/ExecutionEvent/Trader/Deal/Trendbar/Symbol; giá bid/ask + thanh nến theo 1/100000; khối lượng theo 0,01 đơn vị
(lot = khối lượng / lotSize); OAuth (id.ctrader.com + openapi.ctrader.com/apps/token); làm mới token bằng ProtoOARefreshTokenReq.

CHƯA KIỂM CHỨNG VỚI SÀN THẬT (nói thẳng): chưa chạy với broker/tài khoản cTrader nào - toàn bộ thử nghiệm dùng máy chủ giả theo đúng tài liệu. Những chỗ tài liệu không
nói rõ được ghi `# CHƯA XÁC MINH` ngay tại chỗ (vd giới hạn khoảng thời gian của GetTrendbars - mã tự thu hẹp khi bị từ chối; hành vi bỏ trống SL/TP khi sửa).
LUÔN thử trên tài khoản DEMO (ctrader_env = demo) trước khi dùng live.
"""
import http.server
import json
import os
import threading
import time
import urllib.parse
import uuid
from collections import deque

from .bridges import BridgeError, MtBackend
from .feeds import TIMEFRAMES
from .sdk import Candle
from .wsclient import WebSocketClient, WsClosed, WsError

# ---------------------------------------------------------------- hằng số (ProtoOAPayloadType, ProtoPayloadType)
PT = {
    "APP_AUTH_REQ": 2100, "APP_AUTH_RES": 2101, "ACC_AUTH_REQ": 2102, "ACC_AUTH_RES": 2103,
    "NEW_ORDER_REQ": 2106, "CANCEL_ORDER_REQ": 2108, "AMEND_ORDER_REQ": 2109, "AMEND_SLTP_REQ": 2110, "CLOSE_POS_REQ": 2111,
    "ASSET_LIST_REQ": 2112, "ASSET_LIST_RES": 2113, "SYMBOLS_REQ": 2114, "SYMBOLS_RES": 2115, "SYMBOL_BY_ID_REQ": 2116, "SYMBOL_BY_ID_RES": 2117,
    "TRADER_REQ": 2121, "TRADER_RES": 2122, "TRADER_UPDATE": 2123, "RECONCILE_REQ": 2124, "RECONCILE_RES": 2125, "EXEC_EVENT": 2126,
    "SUB_SPOTS_REQ": 2127, "SUB_SPOTS_RES": 2128, "UNSUB_SPOTS_REQ": 2129, "SPOT_EVENT": 2131, "ORDER_ERROR": 2132,
    "DEAL_LIST_REQ": 2133, "DEAL_LIST_RES": 2134, "TRENDBARS_REQ": 2137, "TRENDBARS_RES": 2138, "ERROR_RES": 2142,
    "TOKEN_INVALIDATED": 2147, "CLIENT_DISCONNECT": 2148, "ACCOUNTS_BY_TOKEN_REQ": 2149, "ACCOUNTS_BY_TOKEN_RES": 2150,
    "ACCOUNT_DISCONNECT": 2164, "REFRESH_TOKEN_REQ": 2173, "REFRESH_TOKEN_RES": 2174, "DEAL_BY_POS_REQ": 2179, "DEAL_BY_POS_RES": 2180,
    "PNL_REQ": 2187, "PNL_RES": 2188, "PNL_SUB_REQ": 2190, "PNL_SUB_RES": 2191,
    "HEARTBEAT": 51, "COMMON_ERROR": 50,
}
ERR_TYPES = (PT["ERROR_RES"], PT["COMMON_ERROR"])
PERIOD = {"1m": 1, "2m": 2, "3m": 3, "4m": 4, "5m": 5, "10m": 6, "15m": 7, "30m": 8, "1h": 9, "4h": 10, "12h": 11, "1d": 12, "1w": 13, "1mo": 14}
PERIOD_NAMES = {"M1": 1, "M2": 2, "M3": 3, "M4": 4, "M5": 5, "M10": 6, "M15": 7, "M30": 8, "H1": 9, "H4": 10, "H12": 11, "D1": 12, "W1": 13, "MN1": 14}
# Cửa sổ thời gian (giây) khởi đầu cho mỗi lần xin nến - CHƯA XÁC MINH giới hạn của máy chủ: nếu bị từ chối, mã tự chia đôi rồi thử lại.
SPAN = {1: 3 * 86400, 2: 3 * 86400, 3: 3 * 86400, 4: 3 * 86400, 5: 3 * 86400, 6: 30 * 86400, 7: 30 * 86400, 8: 30 * 86400, 9: 30 * 86400,
        10: 360 * 86400, 11: 360 * 86400, 12: 360 * 86400, 13: 1800 * 86400, 14: 1800 * 86400}
ORDER_MARKET, ORDER_LIMIT, ORDER_STOP, ORDER_SLTP, ORDER_STOP_LIMIT = 1, 2, 3, 4, 6
EX_ACCEPTED, EX_FILLED, EX_REPLACED, EX_CANCELLED, EX_EXPIRED, EX_REJECTED, EX_CANCEL_REJECTED, EX_PARTIAL = 2, 3, 4, 5, 6, 7, 8, 11
SCALE = 100000.0
LIVE_HOST, DEMO_HOST, PORT = "live.ctraderapi.com", "demo.ctraderapi.com", 5036
AUTH_URL = "https://id.ctrader.com/my/settings/openapi/grantingaccess/"
TOKEN_URL = "https://openapi.ctrader.com/apps/token"
OAUTH_PORT = 53682
HEARTBEAT_EVERY = 10.0

ERR_VI = {
    "NOT_ENOUGH_MONEY": "Không đủ tiền ký quỹ", "TRADING_BAD_VOLUME": "Khối lượng không hợp lệ (ngoài min/max/bước của mã)",
    "TRADING_BAD_STOPS": "SL/TP không hợp lệ", "TRADING_BAD_PRICES": "Giá không hợp lệ", "PROTECTION_IS_TOO_CLOSE_TO_MARKET": "SL/TP quá sát giá thị trường",
    "MARKET_CLOSED": "Thị trường đóng cửa", "TRADING_DISABLED": "Mã này đang tắt giao dịch", "TRADING_NOT_ALLOWED": "Tài khoản/phiên không được phép giao dịch",
    "POSITION_NOT_FOUND": "Không thấy vị thế (có thể đã đóng)", "ORDER_NOT_FOUND": "Không thấy lệnh (có thể đã khớp/huỷ)",
    "SYMBOL_NOT_FOUND": "Không có mã này", "UNKNOWN_SYMBOL": "Mã không xác định", "NO_QUOTES": "Chưa có giá cho mã này",
    "SHORT_SELLING_NOT_ALLOWED": "Mã này không cho bán khống", "MAX_EXPOSURE_REACHED": "Vượt mức phơi nhiễm tối đa",
    "TOO_MANY_POSITIONS": "Quá nhiều vị thế", "REQUEST_FREQUENCY_EXCEEDED": "Gửi yêu cầu quá nhanh", "SERVER_IS_UNDER_MAINTENANCE": "Máy chủ đang bảo trì",
    "CH_ACCESS_TOKEN_INVALID": "Access token không hợp lệ/hết hạn", "OA_AUTH_TOKEN_EXPIRED": "Access token đã hết hạn",
    "CH_CLIENT_AUTH_FAILURE": "Sai Client ID/Secret của ứng dụng cTrader", "ACCOUNT_NOT_AUTHORIZED": "Tài khoản chưa được xác thực với token này",
    "CH_CTID_TRADER_ACCOUNT_NOT_FOUND": "Không thấy tài khoản cTrader này", "CONNECTIONS_LIMIT_EXCEEDED": "Vượt số kết nối cho phép",
    "UNABLE_TO_CANCEL_ORDER": "Không huỷ được lệnh", "UNABLE_TO_AMEND_ORDER": "Không sửa được lệnh", "POSITION_LOCKED": "Vị thế đang bị khoá",
}
TOKEN_ERRORS = ("CH_ACCESS_TOKEN_INVALID", "OA_AUTH_TOKEN_EXPIRED")


def _num(x, d=0.0):
    try:
        v = float(x)
        return v if v == v else d
    except (TypeError, ValueError):
        return d


def _int(x, d=0):
    try:
        return int(x)
    except (TypeError, ValueError):
        return d


def _enum(v, names):
    """Enum JSON có thể là số hoặc tên -> số."""
    if isinstance(v, str):
        return names.get(v.upper(), _int(v))
    return _int(v)


def _side(v):
    return "buy" if _enum(v, {"BUY": 1, "SELL": 2}) == 1 else "sell"


def err_text(code, desc=""):
    base = ERR_VI.get(str(code), "")
    return "%s%s%s" % (code, (" - " + base) if base else "", (" (%s)" % desc) if desc else "")


# =========================================================================================== token (bền qua các tiến trình)
def tokens_path(settings):
    p = (settings or {}).get("ctrader_tokens_path")
    if p:
        return str(p)
    root = os.environ.get("ANDROID_PRIVATE") or os.path.join(os.path.expanduser("~"), ".pyea")
    return os.path.join(root, "ctrader_tokens.json")


class Tokens:
    """Access/refresh token. Làm mới (refresh) sẽ VÔ HIỆU token cũ => token mới phải được ghi bền ở MỘT file dùng chung cho mọi tiến trình của app (bot chạy riêng
    cũng đọc được), nếu không lần khởi động sau sẽ dùng token cũ đã chết. File ghi kèm `origin` = refresh token trong Cài đặt lúc đó: người dùng dán token MỚI vào
    Cài đặt (khác origin) thì Cài đặt thắng, ngược lại dùng token trong file."""

    def __init__(self, access, refresh, client_id, path):
        self.access, self.refresh, self.client_id, self.path = str(access or "").strip(), str(refresh or "").strip(), str(client_id or ""), path
        self.origin = self.refresh
        self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            return
        if d.get("client_id") == self.client_id and d.get("origin") == self.origin and d.get("access") and d.get("refresh"):
            self.access, self.refresh = d["access"], d["refresh"]

    def update(self, access, refresh):
        self.access, self.refresh = str(access), str(refresh or self.refresh)
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            tmp = "%s.%d.tmp" % (self.path, os.getpid())
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"client_id": self.client_id, "origin": self.origin, "access": self.access, "refresh": self.refresh, "saved": time.time()}, f)
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            os.replace(tmp, self.path)
        except OSError:
            pass                                                      # không ghi được: vẫn dùng trong phiên này


# =========================================================================================== kết nối WebSocket JSON
class CtConn:
    def __init__(self, url, client_id, client_secret, tokens, account_id=None, live=False, timeout=15.0):
        self.url, self.cid, self.secret, self.tokens = url, str(client_id), str(client_secret), tokens
        self.account_id = _int(account_id) or None
        self.live, self.timeout = live, timeout
        self.ws = None
        self.ok = False
        self._lock = threading.RLock()                 # kết nối lại
        self._send_lock = threading.Lock()
        self._pending = {}
        self.spots = {}                                # symbolId -> [bid, ask, ts]
        self.subs = set()
        self.events = deque(maxlen=400)                # (seq, clientMsgId, loại, payload) ExecutionEvent / OrderErrorEvent gần nhất
        self._evseq = 0
        self._ev_cond = threading.Condition()
        self._stop = threading.Event()
        self._thread = None
        self.pnl_sub = False
        self.accounts = []

    # ---- gửi/nhận ----
    def _send(self, pt, payload, cmid=None):
        msg = {"payloadType": pt, "payload": payload or {}}
        if cmid:
            msg["clientMsgId"] = cmid
        with self._send_lock:
            try:
                self.ws.send_text(json.dumps(msg))
            except (WsError, OSError, AttributeError) as e:
                self.ok = False
                raise BridgeError("Mất kết nối cTrader: %s" % e)

    def _raw_call(self, pt, payload, timeout=None):
        cmid = uuid.uuid4().hex[:16]
        ev = threading.Event()
        box = []
        self._pending[cmid] = (ev, box)
        try:
            self._send(pt, payload, cmid)
            if not ev.wait(timeout or self.timeout):
                raise BridgeError("cTrader không trả lời (quá %.0fs)" % (timeout or self.timeout))
        finally:
            self._pending.pop(cmid, None)
        res = box[0]
        if isinstance(res, Exception):
            raise res
        return res

    def _reader(self, ws):
        last_hb = time.monotonic()
        try:
            while not self._stop.is_set() and ws is self.ws:
                try:
                    raw = ws.recv(1.0)
                except WsClosed as e:
                    raise BridgeError("cTrader đóng kết nối: %s" % e)
                if raw:
                    try:
                        self._dispatch(json.loads(raw))
                    except ValueError:
                        continue
                if time.monotonic() - last_hb >= HEARTBEAT_EVERY:
                    last_hb = time.monotonic()
                    self._send(PT["HEARTBEAT"], {})
        except (BridgeError, WsError) as e:
            err = e if isinstance(e, BridgeError) else BridgeError(str(e))
        else:
            err = BridgeError("Đã đóng kết nối cTrader")
        if ws is self.ws:
            self.ok = False
        for ev, box in list(self._pending.values()):
            box.append(err)
            ev.set()
        with self._ev_cond:
            self._ev_cond.notify_all()

    def _dispatch(self, m):
        pt, pl, cmid = _int(m.get("payloadType")), m.get("payload") or {}, m.get("clientMsgId")
        if pt == PT["SPOT_EVENT"]:
            sid = _int(pl.get("symbolId"))
            cur = self.spots.setdefault(sid, [0.0, 0.0, 0.0])
            if pl.get("bid"):
                cur[0] = _num(pl["bid"]) / SCALE
            if pl.get("ask"):
                cur[1] = _num(pl["ask"]) / SCALE
            cur[2] = (_num(pl.get("timestamp")) / 1000.0) if pl.get("timestamp") else time.time()
            return
        if pt in (PT["EXEC_EVENT"], PT["ORDER_ERROR"]):
            with self._ev_cond:
                self._evseq += 1
                self.events.append((self._evseq, cmid, pt, pl))
                self._ev_cond.notify_all()
        if cmid and cmid in self._pending:
            ev, box = self._pending[cmid]
            if pt in ERR_TYPES:
                box.append(BridgeError(err_text(pl.get("errorCode"), pl.get("description", "")), 0, str(pl.get("errorCode", ""))))
            else:
                box.append((pt, pl))
            ev.set()
            return
        if pt in (PT["TOKEN_INVALIDATED"], PT["CLIENT_DISCONNECT"], PT["ACCOUNT_DISCONNECT"]):
            self.ok = False

    # ---- kết nối + xác thực ----
    def ensure(self):
        if self.ok and self.ws is not None:
            return
        with self._lock:
            if self.ok and self.ws is not None:
                return
            self._close_ws()
            if not self.cid or not self.secret:
                raise BridgeError("Thiếu Client ID / Client Secret của ứng dụng cTrader (đăng ký ở openapi.ctrader.com)")
            if not self.tokens.access:
                raise BridgeError("Thiếu access token cTrader - dùng nút «Đăng nhập cTrader» ở Cài đặt")
            ws = WebSocketClient(self.url, timeout=self.timeout)
            try:
                ws.connect()
            except WsError as e:
                raise BridgeError("Không kết nối được cTrader (%s)" % e)
            self.ws = ws
            self._stop.clear()
            self._thread = threading.Thread(target=self._reader, args=(ws,), daemon=True)
            self._thread.start()
            try:
                self._auth()
            except BridgeError:
                self._close_ws()
                raise
            self.ok = True
            for sid in list(self.subs):                                  # nối lại: đăng ký lại giá
                try:
                    self._raw_call(PT["SUB_SPOTS_REQ"], {"ctidTraderAccountId": self.account_id, "symbolId": [sid], "subscribeToSpotTimestamp": True})
                except BridgeError:
                    pass
            self.pnl_sub = False

    def _auth(self):
        pt, _ = self._expect(self._raw_call(PT["APP_AUTH_REQ"], {"clientId": self.cid, "clientSecret": self.secret}), PT["APP_AUTH_RES"])
        for attempt in (0, 1):
            if not self.account_id:
                self.account_id = self._pick_account()
            try:
                self._expect(self._raw_call(PT["ACC_AUTH_REQ"], {"ctidTraderAccountId": self.account_id, "accessToken": self.tokens.access}), PT["ACC_AUTH_RES"])
                return
            except BridgeError as e:
                if attempt == 0 and e.code in TOKEN_ERRORS and self.tokens.refresh:
                    self.refresh_token()
                    continue
                raise

    @staticmethod
    def _expect(res, pt):
        if res[0] != pt:
            raise BridgeError("cTrader trả loại tin lạ %s (mong %s)" % (res[0], pt))
        return res

    def list_accounts(self):
        """[{id, live, login, broker}] của access token hiện tại (cần đã xác thực ứng dụng)."""
        _, pl = self._expect(self._raw_call(PT["ACCOUNTS_BY_TOKEN_REQ"], {"accessToken": self.tokens.access}), PT["ACCOUNTS_BY_TOKEN_RES"])
        out = [{"id": _int(a.get("ctidTraderAccountId")), "live": bool(a.get("isLive")), "login": _int(a.get("traderLogin")), "broker": a.get("brokerTitleShort", "")}
               for a in (pl.get("ctidTraderAccount") or [])]
        self.accounts = out
        return out

    def _pick_account(self):
        accs = self.list_accounts()
        want = [a for a in accs if a["live"] == self.live]
        if not want:
            raise BridgeError("Token không có tài khoản %s nào (có: %s). Đổi «cTrader môi trường» hoặc cấp lại quyền." %
                              ("LIVE" if self.live else "DEMO", ", ".join("%s%s" % (a["login"] or a["id"], " live" if a["live"] else " demo") for a in accs) or "không có"))
        return want[0]["id"]

    def discover(self):
        """Chỉ nối + xác thực ỨNG DỤNG rồi liệt kê tài khoản của token (không cần chọn tài khoản trước) - cho nút «Chọn tài khoản cTrader»."""
        if not self.cid or not self.secret or not self.tokens.access:
            raise BridgeError("Cần Client ID, Client Secret và access token trước")
        ws = WebSocketClient(self.url, timeout=self.timeout)
        try:
            ws.connect()
        except WsError as e:
            raise BridgeError("Không kết nối được cTrader (%s)" % e)
        self.ws, self._stop = ws, threading.Event()
        threading.Thread(target=self._reader, args=(ws,), daemon=True).start()
        try:
            self._expect(self._raw_call(PT["APP_AUTH_REQ"], {"clientId": self.cid, "clientSecret": self.secret}), PT["APP_AUTH_RES"])
            try:
                return self.list_accounts()
            except BridgeError as e:
                if e.code in TOKEN_ERRORS and self.tokens.refresh:
                    self.refresh_token()
                    return self.list_accounts()
                raise
        finally:
            self.close()

    def refresh_token(self):
        """ProtoOARefreshTokenReq (tài liệu): token cũ bị vô hiệu ngay khi có token mới => ghi bền ngay."""
        _, pl = self._expect(self._raw_call(PT["REFRESH_TOKEN_REQ"], {"refreshToken": self.tokens.refresh}), PT["REFRESH_TOKEN_RES"])
        if not pl.get("accessToken"):
            raise BridgeError("Làm mới token cTrader thất bại")
        self.tokens.update(pl["accessToken"], pl.get("refreshToken") or self.tokens.refresh)

    # ---- gọi thường ----
    def call(self, pt, payload, expect, timeout=None):
        """Gọi một yêu cầu cần `ctidTraderAccountId`; tự nối lại/làm mới token/thử lại khi bị giới hạn tần suất."""
        for attempt in range(3):
            self.ensure()
            body = dict(payload)
            body["ctidTraderAccountId"] = self.account_id
            try:
                res = self._raw_call(pt, body, timeout)
                return self._expect(res, expect)[1]
            except BridgeError as e:
                if e.code == "REQUEST_FREQUENCY_EXCEEDED" and attempt < 2:
                    time.sleep(0.6 * (attempt + 1))
                    continue
                if e.code in TOKEN_ERRORS and attempt < 2 and self.tokens.refresh:
                    try:
                        self.refresh_token()
                    except BridgeError:
                        raise e
                    self.ok = False
                    continue
                if not self.ok and attempt < 2 and not e.code:
                    continue                                                 # rớt kết nối giữa chừng: nối lại rồi thử lại (CHỈ cho lệnh đọc; lệnh giao dịch dùng trade_call)
                raise
        raise BridgeError("cTrader: thử lại không thành công")

    def trade_call(self, pt, payload, want, mine=None, wait=8.0):
        """Lệnh giao dịch: KHÔNG tự thử lại (tránh đặt lệnh hai lần). Chờ ExecutionEvent thoả `want(payload)`. Sự kiện được coi là của yêu cầu này khi mang đúng
        clientMsgId HOẶC thoả `mine(payload)` (theo orderId/positionId/clientOrderId - phòng khi máy chủ không lặp lại clientMsgId trong sự kiện; CHƯA XÁC MINH)."""
        self.ensure()
        body = dict(payload)
        body["ctidTraderAccountId"] = self.account_id
        cmid = uuid.uuid4().hex[:16]
        ev = threading.Event()
        box = []
        self._pending[cmid] = (ev, box)
        seq0 = self._evseq
        deadline = time.monotonic() + wait
        seen = seq0
        try:
            self._send(pt, body, cmid)
            while True:
                if box and isinstance(box[0], Exception):
                    raise box[0]
                with self._ev_cond:
                    for seq, c, t, pl in list(self.events):
                        if seq <= seen:
                            continue
                        seen = max(seen, seq)
                        if not (c == cmid or (mine is not None and mine(pl))):
                            continue
                        if t == PT["ORDER_ERROR"]:
                            raise BridgeError(err_text(pl.get("errorCode"), pl.get("description", "")), 0, str(pl.get("errorCode", "")))
                        ex = _int(pl.get("executionType"))
                        if ex in (EX_REJECTED, EX_CANCEL_REJECTED):
                            raise BridgeError(err_text(pl.get("errorCode") or "ORDER_REJECTED"), 0, str(pl.get("errorCode") or ""))
                        if want(pl):
                            return pl
                    left = deadline - time.monotonic()
                    if left <= 0:
                        raise BridgeError("cTrader chưa xác nhận lệnh sau %.0fs - KIỂM TRA vị thế trước khi gửi lại" % wait)
                    self._ev_cond.wait(min(0.25, left))
        finally:
            self._pending.pop(cmid, None)

    def _close_ws(self):
        ws, self.ws, self.ok = self.ws, None, False
        if ws is not None:
            try:
                ws.close()
            except Exception:                                               # noqa: BLE001
                pass

    def close(self):
        self._stop.set()
        self._close_ws()


# =========================================================================================== backend chuẩn hoá (MtBackend)
class CtraderBackend(MtBackend):
    name = "ctrader"
    max_chunk = 1000
    native_kinds = {"limit", "stop"}               # stop-limit để vỏ tự theo dõi (chưa xác minh ngữ nghĩa giá của stop-limit cTrader)
    limiter_kind = "generic"
    can_modify_position = True
    OP_WAIT = 8.0

    def __init__(self, conn):
        self.c = conn
        self._sym = None                           # name -> id
        self._sym_by_id = {}
        self._spec = {}                            # id -> dict thô
        self._cur = ""
        self._lock = threading.RLock()

    # ---- ký hiệu / đặc tả ----
    def _load_symbols(self):
        if self._sym is None:
            pl = self.c.call(PT["SYMBOLS_REQ"], {}, PT["SYMBOLS_RES"])
            m = {}
            for s in pl.get("symbol") or []:
                if s.get("enabled", True) is False:
                    continue
                name = str(s.get("symbolName") or "")
                if name:
                    m[name] = _int(s.get("symbolId"))
            self._sym = m
            self._sym_by_id = {v: k for k, v in m.items()}
        return self._sym

    def symbols(self):
        return sorted(self._load_symbols())

    def _sid(self, symbol):
        m = self._load_symbols()
        if symbol not in m:
            low = {k.upper().replace("/", ""): v for k, v in m.items()}
            sid = low.get(str(symbol).upper().replace("/", ""))
            if sid is None:
                raise BridgeError("cTrader không có mã %s" % symbol)
            return sid
        return m[symbol]

    def _specs(self, ids):
        need = [i for i in ids if i not in self._spec]
        if need:
            pl = self.c.call(PT["SYMBOL_BY_ID_REQ"], {"symbolId": need}, PT["SYMBOL_BY_ID_RES"])
            for s in pl.get("symbol") or []:
                self._spec[_int(s.get("symbolId"))] = s
        return {i: self._spec.get(i, {}) for i in ids}

    def _lot(self, sid):
        """lotSize (đơn vị giao thức: 0,01 đơn vị) - lot = khối lượng giao thức / lotSize."""
        ls = _num(self._specs([sid])[sid].get("lotSize"))
        if ls <= 0:
            raise BridgeError("cTrader không báo lotSize cho mã id=%s" % sid)
        return ls

    def spec(self, symbol):
        sid = self._sid(symbol)
        s, ls = self._specs([sid])[sid], self._lot(sid)
        return {"volume_min": _num(s.get("minVolume")) / ls, "volume_max": _num(s.get("maxVolume")) / ls, "volume_step": _num(s.get("stepVolume")) / ls}

    def _proto_volume(self, sid, lots):
        s, ls = self._specs([sid])[sid], self._lot(sid)
        v = int(round(float(lots) * ls))
        step = _int(s.get("stepVolume"))
        if step > 1:
            v = (v // step) * step
        if v <= 0:
            raise BridgeError("Khối lượng %.8g quá nhỏ so với bước của mã" % lots)
        return v

    # ---- giá / nến ----
    def tick(self, symbol):
        sid = self._sid(symbol)
        if sid not in self.c.subs:
            self.c.call(PT["SUB_SPOTS_REQ"], {"symbolId": [sid], "subscribeToSpotTimestamp": True}, PT["SUB_SPOTS_RES"])
            self.c.subs.add(sid)
        end = time.monotonic() + 4.0
        while time.monotonic() < end:
            sp = self.c.spots.get(sid)
            if sp and sp[0] > 0 and sp[1] > 0:
                return sp[0], sp[1], sp[2] or time.time()
            time.sleep(0.05)
        raise BridgeError("Chưa có giá %s từ cTrader (thị trường đóng cửa?)" % symbol)

    def candles(self, symbol, tf, count, end=None):
        period = PERIOD.get(tf)
        if period is None:
            raise BridgeError("cTrader không có khung %s" % tf)
        sid, step = self._sid(symbol), TIMEFRAMES[tf]
        want, to_ms = int(count), (int(end * 1000) - 1 if end is not None else int((time.time() + 60) * 1000))   # `end` là cận trên KHÔNG gồm
        span = SPAN[period] * 1000
        got = {}
        for _ in range(60):
            if len(got) >= want:
                break
            frm = max(0, to_ms - span)
            try:
                pl = self.c.call(PT["TRENDBARS_REQ"], {"symbolId": sid, "period": period, "fromTimestamp": frm, "toTimestamp": to_ms,
                                                       "count": max(1, want - len(got))}, PT["TRENDBARS_RES"])
            except BridgeError as e:
                if span > 2 * step * 1000 and e.code in ("INCORRECT_BOUNDARIES", ""):     # CHƯA XÁC MINH giới hạn khoảng thời gian: thu hẹp rồi thử lại
                    span //= 2
                    continue
                raise
            rows = pl.get("trendbar") or []
            for tb in rows:
                low = _num(tb.get("low"))
                t = _int(tb.get("utcTimestampInMinutes")) * 60
                if t <= 0:
                    continue
                got[t] = Candle(float(t), (low + _num(tb.get("deltaOpen"))) / SCALE, (low + _num(tb.get("deltaHigh"))) / SCALE, low / SCALE,
                                (low + _num(tb.get("deltaClose"))) / SCALE, _num(tb.get("volume")))
            if frm <= 0:
                break
            to_ms = frm - 1
        out = sorted(got.values(), key=lambda c: c.time)
        if end is not None:
            out = [c for c in out if c.time < end]
        return out[-want:]

    # ---- tài khoản ----
    def _currency(self, asset_id):
        if not self._cur:
            try:
                pl = self.c.call(PT["ASSET_LIST_REQ"], {}, PT["ASSET_LIST_RES"])
                for a in pl.get("asset") or []:
                    if _int(a.get("assetId")) == asset_id:
                        self._cur = str(a.get("name") or "")
            except BridgeError:
                pass
        return self._cur

    def _pnl(self):
        """{positionId: (gross, net)} đã đổi ra tiền, hoặc None nếu không đọc được (không bịa 0)."""
        try:
            if not self.c.pnl_sub:
                self.c.call(PT["PNL_SUB_REQ"], {}, PT["PNL_SUB_RES"])
                self.c.pnl_sub = True
            pl = self.c.call(PT["PNL_REQ"], {}, PT["PNL_RES"])
        except BridgeError:
            return None
        k = 10.0 ** _int(pl.get("moneyDigits"), 2)
        return {str(_int(r.get("positionId"))): (_num(r.get("grossUnrealizedPnL")) / k, _num(r.get("netUnrealizedPnL")) / k)
                for r in pl.get("positionUnrealizedPnL") or []}

    def account(self):
        pl = self.c.call(PT["TRADER_REQ"], {}, PT["TRADER_RES"])
        tr = pl.get("trader") or {}
        k = 10.0 ** _int(tr.get("moneyDigits"), 2)
        bal = _num(tr.get("balance")) / k
        raw, _ = self._reconcile()
        margin = sum(_num(p.get("usedMargin")) / (10.0 ** _int(p.get("moneyDigits"), _int(tr.get("moneyDigits"), 2))) for p in raw)
        pnl = self._pnl() if raw else {}
        equity = bal + (sum(v[1] for v in pnl.values()) if pnl else 0.0)
        acct_type = _enum(tr.get("accountType"), {"HEDGED": 0, "NETTED": 1, "SPREAD_BETTING": 2})
        lev = _num(tr.get("leverageInCents")) / 100.0
        return {"balance": bal, "equity": equity, "margin": margin, "free_margin": equity - margin, "leverage": lev or 1.0,
                "currency": self._currency(_int(tr.get("depositAssetId"))), "hedging": acct_type == 0,
                "margin_level": (equity / margin * 100.0) if margin > 0 else None, "platform": "cTrader",
                "equity_known": pnl is not None}

    # ---- vị thế / lệnh ----
    def _reconcile(self):
        pl = self.c.call(PT["RECONCILE_REQ"], {}, PT["RECONCILE_RES"])
        return list(pl.get("position") or []), list(pl.get("order") or [])

    def _name(self, sid):
        self._load_symbols()
        return self._sym_by_id.get(sid, "id%s" % sid)

    def positions(self):
        raw, _ = self._reconcile()
        if not raw:
            return []
        ids = sorted({_int((p.get("tradeData") or {}).get("symbolId")) for p in raw})
        specs = self._specs(ids)
        pnl = self._pnl() or {}
        out = []
        for p in raw:
            td = p.get("tradeData") or {}
            sid = _int(td.get("symbolId"))
            ls = _num(specs.get(sid, {}).get("lotSize")) or self._lot(sid)
            pid = str(_int(p.get("positionId")))
            k = 10.0 ** _int(p.get("moneyDigits"), 2)
            row = {"id": pid, "symbol": self._name(sid), "side": _side(td.get("tradeSide")), "volume": _num(td.get("volume")) / ls,
                   "price": _num(p.get("price")), "sl": _num(p.get("stopLoss")), "tp": _num(p.get("takeProfit")),
                   "time": _num(td.get("openTimestamp")) / 1000.0, "comment": str(td.get("comment") or td.get("label") or "")}
            if pid in pnl:
                row["profit"] = pnl[pid][0]                                  # lãi/lỗ gộp của phần đang mở (chưa trừ swap/hoa hồng) - đúng cột «Lợi nhuận» kiểu MT
            row["swap"] = _num(p.get("swap")) / k
            row["commission"] = _num(p.get("commission")) / k                # CHƯA XÁC MINH dấu (cTrader báo phí âm hay dương)
            out.append(row)
        return out

    _KIND = {ORDER_LIMIT: "limit", ORDER_STOP: "stop", ORDER_STOP_LIMIT: "stop_limit"}

    def orders(self):
        _, raw = self._reconcile()
        raw = [o for o in raw if _enum(o.get("orderType"), {"MARKET": 1, "LIMIT": 2, "STOP": 3, "STOP_LOSS_TAKE_PROFIT": 4, "MARKET_RANGE": 5, "STOP_LIMIT": 6}) in self._KIND]
        specs = self._specs(sorted({_int((o.get("tradeData") or {}).get("symbolId")) for o in raw})) if raw else {}
        out = []
        for o in raw:
            td = o.get("tradeData") or {}
            sid = _int(td.get("symbolId"))
            ot = _enum(o.get("orderType"), {"LIMIT": 2, "STOP": 3, "STOP_LIMIT": 6})
            ls = _num(specs.get(sid, {}).get("lotSize")) or self._lot(sid)
            out.append({"id": str(_int(o.get("orderId"))), "symbol": self._name(sid), "side": _side(td.get("tradeSide")), "kind": self._KIND[ot],
                        "volume": _num(td.get("volume")) / ls, "price": _num(o.get("limitPrice") if ot == ORDER_LIMIT else o.get("stopPrice")),
                        "sl": _num(o.get("stopLoss")), "tp": _num(o.get("takeProfit")), "type_code": ot})
        return out

    # ---- giao dịch ----
    @staticmethod
    def _exec_fill(pl):
        o, d, p = pl.get("order") or {}, pl.get("deal") or {}, pl.get("position") or {}
        price = _num(d.get("executionPrice")) or _num(o.get("executionPrice")) or _num(p.get("price")) or None
        return o, d, p, price

    def market(self, symbol, side, volume, comment=""):
        sid = self._sid(symbol)
        coid = "pyea-" + uuid.uuid4().hex[:12]
        pv = self._proto_volume(sid, volume)
        body = {"symbolId": sid, "orderType": ORDER_MARKET, "tradeSide": 1 if side == "buy" else 2, "volume": pv, "clientOrderId": coid}
        if comment:
            body["comment"] = comment[:40]
            body["label"] = comment[:40]
        pl = self.c.trade_call(PT["NEW_ORDER_REQ"], body, lambda e: _int(e.get("executionType")) in (EX_FILLED, EX_PARTIAL),
                               lambda e: (e.get("order") or {}).get("clientOrderId") == coid, self.OP_WAIT)
        o, d, p, price = self._exec_fill(pl)
        ls = self._lot(sid)
        return {"order_id": str(_int(o.get("orderId"))), "position_id": str(_int(p.get("positionId") or d.get("positionId") or o.get("positionId"))),
                "price": price, "volume": (_num(d.get("filledVolume")) or pv) / ls}

    def close_position(self, position_id, volume=None):
        pid = _int(position_id)
        cur = [p for p in self._reconcile()[0] if _int(p.get("positionId")) == pid]
        if not cur:
            raise BridgeError("Không thấy vị thế #%s trên cTrader" % position_id)
        td = cur[0].get("tradeData") or {}
        sid = _int(td.get("symbolId"))
        pv = _int(td.get("volume")) if volume is None else self._proto_volume(sid, volume)
        pl = self.c.trade_call(PT["CLOSE_POS_REQ"], {"positionId": pid, "volume": pv}, lambda e: _int(e.get("executionType")) in (EX_FILLED, EX_PARTIAL),
                               lambda e: _int((e.get("position") or {}).get("positionId")) == pid or _int((e.get("order") or {}).get("positionId")) == pid, self.OP_WAIT)
        o, d, p, price = self._exec_fill(pl)
        return {"order_id": str(_int(o.get("orderId"))), "position_id": str(pid), "price": price, "volume": pv / self._lot(sid)}

    def modify_position(self, position_id, sl, tp):
        """AmendPositionSLTP. Mức = 0 thì BỎ TRƯỜNG (CHƯA XÁC MINH: tài liệu không nói bỏ trống là xoá hay giữ nguyên - `selfcheck --trade` kiểm trên demo)."""
        pid = _int(position_id)
        body = {"positionId": pid}
        if sl:
            body["stopLoss"] = float(sl)
        if tp:
            body["takeProfit"] = float(tp)
        self.c.trade_call(PT["AMEND_SLTP_REQ"], body, lambda e: True, lambda e: _int((e.get("position") or {}).get("positionId")) == pid, self.OP_WAIT)

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        if kind not in self.native_kinds:
            raise BridgeError("cTrader: lệnh chờ '%s' chưa được hỗ trợ native" % kind)
        sid = self._sid(symbol)
        coid = "pyea-" + uuid.uuid4().hex[:12]
        body = {"symbolId": sid, "orderType": ORDER_LIMIT if kind == "limit" else ORDER_STOP, "tradeSide": 1 if side == "buy" else 2,
                "volume": self._proto_volume(sid, volume), "clientOrderId": coid}
        body["limitPrice" if kind == "limit" else "stopPrice"] = float(price)
        if expiry:
            body["timeInForce"], body["expirationTimestamp"] = 1, int(float(expiry) * 1000)          # GOOD_TILL_DATE
        else:
            body["timeInForce"] = 2                                                                # GOOD_TILL_CANCEL
        if comment:
            body["comment"] = comment[:40]
            body["label"] = comment[:40]
        pl = self.c.trade_call(PT["NEW_ORDER_REQ"], body, lambda e: (e.get("order") or {}).get("orderId") is not None,
                               lambda e: (e.get("order") or {}).get("clientOrderId") == coid, self.OP_WAIT)
        return str(_int((pl.get("order") or {}).get("orderId")))

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        oid = _int(order_id)
        cur = [o for o in self.orders() if o["id"] == str(oid)]
        if not cur:
            raise BridgeError("Không thấy lệnh chờ #%s trên cTrader" % order_id)
        body = {"orderId": oid}
        if price is not None:
            body["limitPrice" if cur[0]["kind"] == "limit" else "stopPrice"] = float(price)
        if sl is not None:
            body["stopLoss"] = float(sl)
        if tp is not None:
            body["takeProfit"] = float(tp)
        self.c.trade_call(PT["AMEND_ORDER_REQ"], body, lambda e: True, lambda e: _int((e.get("order") or {}).get("orderId")) == oid, self.OP_WAIT)

    def cancel_pending(self, order_id):
        oid = _int(order_id)
        self.c.trade_call(PT["CANCEL_ORDER_REQ"], {"orderId": oid}, lambda e: _int(e.get("executionType")) == EX_CANCELLED,
                          lambda e: _int((e.get("order") or {}).get("orderId")) == oid, self.OP_WAIT)

    # ---- lịch sử deal ----
    WEEK = 7 * 86400

    def _deal_rows(self, since, until):
        out, t1 = [], float(until)
        for _ in range(60):                                                      # cửa sổ tối đa 1 tuần mỗi yêu cầu (CHƯA XÁC MINH) -> lùi dần
            t0 = max(float(since), t1 - self.WEEK)
            pl = self.c.call(PT["DEAL_LIST_REQ"], {"fromTimestamp": int(t0 * 1000), "toTimestamp": int(t1 * 1000), "maxRows": 1000}, PT["DEAL_LIST_RES"])
            out += list(pl.get("deal") or [])
            if t0 <= float(since):
                break
            t1 = t0 - 0.001
        return out

    def _norm(self, rows, trades_only=True):
        ids = sorted({_int(r.get("symbolId")) for r in rows if r.get("symbolId") is not None})
        specs = self._specs(ids) if ids else {}
        out = []
        for r in rows:
            sid = _int(r.get("symbolId"))
            ls = _num(specs.get(sid, {}).get("lotSize")) or 1.0
            cd = r.get("closePositionDetail") or {}
            k = 10.0 ** _int(cd.get("moneyDigits") or r.get("moneyDigits"), 2)
            qty = (_num(r.get("filledVolume")) or _num(r.get("volume"))) / ls
            out.append({"id": str(_int(r.get("dealId"))), "time": _num(r.get("executionTimestamp") or r.get("createTimestamp")) / 1000.0,
                        "symbol": self._name(sid), "side": _side(r.get("tradeSide")), "qty": qty, "price": _num(r.get("executionPrice")),
                        "fee": (_num(r.get("commission")) + _num(cd.get("swap"))) / k, "pnl": _num(cd.get("grossProfit")) / k,
                        "order_id": str(_int(r.get("orderId"))), "position_id": str(_int(r.get("positionId"))),
                        "entry": "OUT" if cd else "IN", "reason": "", "profit": _num(cd.get("grossProfit")) / k,
                        "commission": _num(r.get("commission")) / k, "swap": _num(cd.get("swap")) / k, "kind": "trade", "comment": str(r.get("comment") or "")})
        return [x for x in sorted(out, key=lambda x: x["time"]) if _enum_ok(x)]

    def deals(self, since):
        return self._norm(self._deal_rows(since, time.time() + 60))

    def history(self, since, until=None):
        return self._norm(self._deal_rows(since, until or time.time() + 60))

    def deals_by_position(self, position_id):
        pl = self.c.call(PT["DEAL_BY_POS_REQ"], {"positionId": _int(position_id), "fromTimestamp": int((time.time() - 90 * 86400) * 1000),
                                                 "toTimestamp": int((time.time() + 60) * 1000)}, PT["DEAL_BY_POS_RES"])
        return self._norm(list(pl.get("deal") or []))

    def close(self):
        self.c.close()


def _enum_ok(x):
    return x["qty"] > 0


# =========================================================================================== OAuth (chỉ dùng điện thoại)
def auth_url(client_id, redirect_uri, scope="trading"):
    return AUTH_URL + "?" + urllib.parse.urlencode({"client_id": client_id, "redirect_uri": redirect_uri, "scope": scope, "product": "web"})


def exchange_code(client_id, client_secret, code, redirect_uri, fetch=None):
    """Đổi `code` (sống 1 phút) lấy access/refresh token: GET openapi.ctrader.com/apps/token. `fetch(url)->dict` cho test."""
    q = urllib.parse.urlencode({"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri, "client_id": client_id, "client_secret": client_secret})
    d = (fetch or _http_get_json)(TOKEN_URL + "?" + q)
    if d.get("errorCode") or not d.get("accessToken"):
        raise BridgeError("Đổi mã lấy token thất bại: %s %s" % (d.get("errorCode", ""), d.get("description", "")))
    return {"access": d["accessToken"], "refresh": d.get("refreshToken", ""), "expires_in": d.get("expiresIn")}


def _http_get_json(url, timeout=20):
    import urllib.request
    from .feeds import ssl_context
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"Accept": "application/json"}), timeout=timeout, context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:                                                    # noqa: BLE001
        raise BridgeError("Không gọi được openapi.ctrader.com: %s" % e)


def wait_for_code(port=OAUTH_PORT, timeout=180.0, started=None):
    """Mở máy chủ HTTP CỤC BỘ trên điện thoại (127.0.0.1) chờ trình duyệt chuyển hướng về redirect_uri http://localhost:<port>/callback?code=... .
    Không cần máy chủ ngoài. Trả code, hoặc ném BridgeError khi hết giờ / người dùng từ chối."""
    box = {}
    ev = threading.Event()

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            if "code" in q:
                box["code"] = q["code"][0]
            elif "error" in q:
                box["error"] = q.get("error_description", q["error"])[0]
            body = ("<html><meta charset=utf-8><body style='font-family:sans-serif'><h3>%s</h3>Bạn có thể quay lại ứng dụng PyEA.</body></html>" %
                    ("Đã nhận mã đăng nhập cTrader" if "code" in box else "Đăng nhập không thành công")).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            if box:
                ev.set()

    try:
        srv = http.server.HTTPServer(("127.0.0.1", port), H)
    except OSError as e:
        raise BridgeError("Không mở được cổng cục bộ %s để nhận đăng nhập: %s" % (port, e))
    srv.timeout = 0.5
    try:
        if started:
            started()
        end = time.monotonic() + timeout
        while not ev.is_set() and time.monotonic() < end:
            srv.handle_request()
    finally:
        srv.server_close()
    if "code" in box:
        return box["code"]
    raise BridgeError("Đăng nhập cTrader không hoàn tất: %s" % box.get("error", "hết giờ chờ"))


def oauth_login(client_id, client_secret, open_url, port=OAUTH_PORT, scope="trading", timeout=180.0, fetch=None):
    """Toàn bộ luồng trên điện thoại: mở trình duyệt tới id.ctrader.com -> bạn đăng nhập/cho phép -> trình duyệt về http://localhost:<port>/callback -> đổi token.
    YÊU CẦU: trong ứng dụng ở openapi.ctrader.com phải đăng ký đúng redirect URI http://localhost:<port>/callback."""
    redirect = "http://localhost:%d/callback" % port
    url = auth_url(client_id, redirect, scope)
    code = wait_for_code(port, timeout, started=lambda: open_url(url))
    return exchange_code(client_id, client_secret, code, redirect, fetch)


# =========================================================================================== tạo từ cài đặt
def _live(settings):
    return str(settings.get("ctrader_env", "demo")).lower() == "live"


def _url(settings):
    u = str(settings.get("ctrader_ws_url") or "").strip()
    return u or "wss://%s:%d" % (LIVE_HOST if _live(settings) else DEMO_HOST, PORT)


def make_backend(settings):
    cid, sec = str(settings.get("ctrader_client_id", "")).strip(), str(settings.get("ctrader_client_secret", "")).strip()
    tokens = Tokens(settings.get("ctrader_access_token", ""), settings.get("ctrader_refresh_token", ""), cid, tokens_path(settings))
    conn = CtConn(_url(settings), cid, sec, tokens, settings.get("ctrader_account") or None, _live(settings))
    return CtraderBackend(conn)
