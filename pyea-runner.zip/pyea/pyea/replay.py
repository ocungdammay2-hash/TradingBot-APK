"""Phát lại MỘT LẦN BACKTEST ĐÃ XONG (không chạy lại bot): cho thấy nến, chỉ báo, chấm vào/ra và đường vốn lớn dần theo thời gian.
Không phụ thuộc Kivy. Kết quả backtest không bị đổi - chỉ cắt lát dữ liệu đã có tới nến thứ `pos`."""
from bisect import bisect_right

WINDOW = 2000          # tối đa số nến đưa cho biểu đồ mỗi khung hình (nhẹ cho dữ liệu hàng chục nghìn nến)


class Replay:
    def __init__(self, res):
        self.res = res
        self.candles = list(res.candles or [])
        self.times = [c.time for c in self.candles]
        self.ev = sorted(res.events or [], key=lambda e: e.time)
        self.ev_t = [e.time for e in self.ev]
        self.curve = list(res.curve or [])
        self.curve_t = [p[0] for p in self.curve]
        self.plots = {k: ([p[0] for p in v], list(v)) for k, v in (res.plots or {}).items()}
        n = len(self.candles)
        # bắt đầu từ nến test đầu tiên (đoạn warm-up hiện sẵn như MT5)
        k0 = (bisect_right(self.times, self.curve_t[0]) if self.curve_t else min(n, 2))
        self.start = max(2, min(n, k0))
        self.pos = self.start
        self.n = n

    @property
    def done(self):
        return self.pos >= self.n

    def seek(self, pos):
        self.pos = max(self.start, min(self.n, int(pos)))
        return self.pos

    def step(self, k=1):
        return self.seek(self.pos + k)

    def frame(self):
        """-> (candles, plots, events, equity[]) tới nến hiện tại."""
        lo = max(0, self.pos - WINDOW)
        cs = self.candles[lo:self.pos]
        t_last = self.times[self.pos - 1] if self.pos else 0.0
        plots = {}
        for name, (ts, pts) in self.plots.items():
            plots[name] = pts[max(0, bisect_right(ts, cs[0].time) - 1 if cs else 0):bisect_right(ts, t_last)]
        evs = self.ev[:bisect_right(self.ev_t, t_last)]
        eq = [p[2] for p in self.curve[:bisect_right(self.curve_t, t_last)]]
        return cs, plots, evs, eq

    def text(self):
        t = self.times[self.pos - 1] if self.pos else 0
        return self.pos, self.n, t
