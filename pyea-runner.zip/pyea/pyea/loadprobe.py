"""«TẢI THIẾT BỊ»: đo CHÍNH app trên máy đang chạy (CPU, RAM, ghi đĩa của giao diện và dịch vụ nền, thời gian mỗi vòng cập nhật) để quyết định tối ưu
dựa trên SỐ ĐO thay vì đoán. Đọc /proc (Android/Linux) nên không cần quyền đặc biệt; không đọc được thì ghi «không đo được», không bịa số.
Dùng cùng ý với `python -m pyea.loadbench` (đo từng thành phần trên máy phát triển)."""
import os
import time
from collections import deque

try:
    _TCK = float(os.sysconf("SC_CLK_TCK"))
except (AttributeError, ValueError, OSError):
    _TCK = 100.0


def read_proc(pid):
    """-> dict(cpu_s, rss_mb, threads, write_mb) cho một tiến trình; trường không đọc được = None."""
    out = {"cpu_s": None, "rss_mb": None, "threads": None, "write_mb": None}
    try:
        with open("/proc/%d/stat" % pid, "r") as f:
            raw = f.read()
        parts = raw[raw.rindex(")") + 2:].split()                    # sau tên tiến trình (có thể chứa khoảng trắng)
        out["cpu_s"] = (int(parts[11]) + int(parts[12])) / _TCK       # utime + stime
        out["threads"] = int(parts[17])
    except (OSError, ValueError, IndexError):
        pass
    try:
        with open("/proc/%d/status" % pid, "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    out["rss_mb"] = int(line.split()[1]) / 1024.0
                    break
    except (OSError, ValueError, IndexError):
        pass
    try:
        with open("/proc/%d/io" % pid, "r") as f:
            for line in f:
                if line.startswith("write_bytes:"):
                    out["write_mb"] = int(line.split()[1]) / 1048576.0
                    break
    except (OSError, ValueError, IndexError):
        pass
    return out


class LoadMeter:
    """Lấy mẫu tối đa mỗi `every` giây; giữ ~1 giờ. Gọi `note_refresh(giây)` mỗi vòng cập nhật giao diện."""

    def __init__(self, every=5.0, keep=720):
        self.every = every
        self.rows = deque(maxlen=keep)
        self.ref_n, self.ref_sum, self.ref_max = 0, 0.0, 0.0
        self._last = 0.0

    def note_refresh(self, secs):
        self.ref_n += 1
        self.ref_sum += secs
        self.ref_max = max(self.ref_max, secs)

    def sample(self, host_pid=None, state_path=None, now=None):
        now = time.time() if now is None else now
        if now - self._last < self.every:
            return False
        self._last = now
        ui = read_proc(os.getpid())
        host = read_proc(int(host_pid)) if host_pid and int(host_pid) != os.getpid() else None
        size = None
        try:
            size = os.path.getsize(state_path) / 1024.0 if state_path else None
        except OSError:
            pass
        self.rows.append({"t": now, "ui": ui, "host": host, "state_kb": size})
        return True

    @staticmethod
    def _rate(rows, who, key, per):
        a = next((r for r in rows if r.get(who) and r[who].get(key) is not None), None)
        b = next((r for r in reversed(rows) if r.get(who) and r[who].get(key) is not None), None)
        if a is None or b is None or b["t"] - a["t"] < 10:
            return None
        return (b[who][key] - a[who][key]) / (b["t"] - a["t"]) * per

    def report(self):
        rows = list(self.rows)
        if len(rows) < 2:
            return "Chưa đủ số liệu - để app chạy khoảng 1 phút rồi mở lại màn hình này."
        span = rows[-1]["t"] - rows[0]["t"]
        L = ["Đo trong %.0f giây gần nhất (số CPU: 100%% = dùng hết MỘT nhân)" % span]

        def line(name, who):
            cpu = self._rate(rows, who, "cpu_s", 100.0)
            wr = self._rate(rows, who, "write_mb", 3600.0)
            last = rows[-1][who] or {}
            return "%s: CPU %s · RAM %s · luồng %s · ghi đĩa %s" % (
                name, "%.1f%%" % cpu if cpu is not None else "không đo được",
                "%.0f MB" % last["rss_mb"] if last.get("rss_mb") is not None else "?",
                last.get("threads") if last.get("threads") is not None else "?",
                "%.1f MB/giờ" % wr if wr is not None else "không đo được")
        L.append(line("Giao diện", "ui"))
        if rows[-1].get("host"):
            L.append(line("Dịch vụ nền", "host"))
        else:
            L.append("Dịch vụ nền: chưa chạy (hoặc cùng tiến trình giao diện)")
        if self.ref_n:
            L.append("Vòng cập nhật giao diện: TB %.1f ms · lớn nhất %.0f ms · %d vòng" % (self.ref_sum / self.ref_n * 1000, self.ref_max * 1000, self.ref_n))
        if rows[-1].get("state_kb") is not None:
            L.append("state.json: %.1f KB" % rows[-1]["state_kb"])
        L.append("")
        L.append("Cách dùng: ghi số này lúc chart đóng/mở, 1 bot/nhiều bot, rồi so sánh để biết phần nào đáng tối ưu. Số đo là của máy này; "
                 "app KHÔNG tự suy ra % giảm tải.")
        return "\n".join(L)


def profiler_text(instances):
    """Profiler bot: thời gian chạy từng callback (on_tick/on_bar/...) của từng bot đang gắn, từ số đo có sẵn trong engine (CallbackStats).
    `instances` = snapshot["instances"]. Chỉ là số ĐO ĐƯỢC của máy này; cảnh báo callback chậm (TB > 50 ms hoặc lớn nhất > 500 ms)."""
    rows = []
    for m in instances or []:
        met = m.get("metrics") or {}
        cbs = met.get("callbacks") or {}
        if not cbs and not met.get("errors"):
            continue
        rows.append("%s (%s %s)  lỗi: %d" % (m.get("bot") or m.get("iid"), m.get("symbol", ""), m.get("tf", ""), int(met.get("errors") or 0)))
        for name in sorted(cbs):
            c = cbs[name]
            slow = " ⚠ CHẬM" if c.get("avg_ms", 0) > 50 or c.get("max_ms", 0) > 500 else ""
            rows.append("   %-9s %7d lần · TB %.2f ms · lớn nhất %.1f ms%s" % (name, c.get("n", 0), c.get("avg_ms", 0.0), c.get("max_ms", 0.0), slow))
        if met.get("last_error"):
            rows.append("   lỗi gần nhất: %s" % str(met["last_error"])[:160])
    if not rows:
        return "Profiler bot: chưa có bot nào chạy/đo được."
    return "Profiler bot - thời gian callback\n" + "\n".join(rows)
