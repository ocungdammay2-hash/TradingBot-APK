"""
Phiên bản bot + hoàn tác. Mỗi lần file bot bị GHI ĐÈ (AI sửa, nạp lại file cùng tên) hoặc XOÁ, bản cũ được lưu vào
<thư mục bot>/.versions/<tên>/<YYYYmmdd-HHMMSS>_<hash>_<nhãn>.py. Khôi phục luôn lưu bản hiện tại trước (nên khôi phục cũng hoàn tác được).
Giữ tối đa MAX_KEEP bản mỗi bot; bản trùng nội dung với bản mới nhất không lưu lại.
"""
import difflib
import hashlib
import os
import re
import time

MAX_KEEP = 30
TAGS = {"ai": "AI sửa đè", "nap": "Nạp lại file", "xoa": "Trước khi xoá", "khoiphuc": "Trước khi khôi phục", "tay": "Lưu thủ công"}


def vdir(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    return os.path.join(os.path.dirname(os.path.abspath(path)), ".versions", stem)


def _read(p):
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _h(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:8]


def snapshot(path, tag="tay", now=None):
    """Lưu NỘI DUNG HIỆN TẠI của `path` (nếu có và khác bản mới nhất). Trả tên bản đã lưu hoặc None. Không bao giờ ném lỗi."""
    try:
        text = _read(path)
        d = vdir(path)
        os.makedirs(d, exist_ok=True)
        items = list_versions(path)
        if items and items[0]["hash"] == _h(text):
            return None
        tag = tag if tag in TAGS else "tay"
        base = time.strftime("%Y%m%d-%H%M%S", time.localtime(now or time.time()))
        name = "%s_%s_%s.py" % (base, _h(text), tag)
        n = 2
        while os.path.exists(os.path.join(d, name)):
            name = "%s-%d_%s_%s.py" % (base, n, _h(text), tag)
            n += 1
        with open(os.path.join(d, name), "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        for old in list_versions(path)[MAX_KEEP:]:
            try:
                os.remove(os.path.join(d, old["name"]))
            except OSError:
                pass
        return name
    except OSError:
        return None


_RE = re.compile(r"^(\d{8}-\d{6}(?:-\d+)?)_([0-9a-f]{8})_(\w+)\.py$")


def list_versions(path):
    """Mới -> cũ: [{name, hash, tag, label, when, size}]."""
    d = vdir(path)
    out = []
    try:
        names = os.listdir(d)
    except OSError:
        return []
    for n in names:
        m = _RE.match(n)
        if not m:
            continue
        try:
            size = os.path.getsize(os.path.join(d, n))
        except OSError:
            continue
        out.append({"name": n, "stamp": m.group(1), "hash": m.group(2), "tag": m.group(3), "label": TAGS.get(m.group(3), m.group(3)),
                    "when": "%s-%s-%s %s:%s:%s" % (m.group(1)[0:4], m.group(1)[4:6], m.group(1)[6:8], m.group(1)[9:11], m.group(1)[11:13], m.group(1)[13:15]),
                    "size": size})
    out.sort(key=lambda x: x["stamp"], reverse=True)
    return out


def read_version(path, name):
    if not _RE.match(name):                       # chặn đường dẫn lạ (../)
        raise ValueError("tên phiên bản không hợp lệ")
    return _read(os.path.join(vdir(path), name))


def restore(path, name, now=None):
    """Khôi phục bản `name` vào `path` (bản hiện tại được lưu trước, nhãn «khôi phục»). Trả nội dung đã khôi phục."""
    text = read_version(path, name)
    if os.path.exists(path):
        snapshot(path, "khoiphuc", now)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    return text


def diff_stats(old, new):
    a = (old or "").splitlines()
    b = (new or "").splitlines()
    add = rem = 0
    for ln in difflib.unified_diff(a, b, lineterm="", n=0):
        if ln.startswith("+") and not ln.startswith("+++"):
            add += 1
        elif ln.startswith("-") and not ln.startswith("---"):
            rem += 1
    return add, rem
