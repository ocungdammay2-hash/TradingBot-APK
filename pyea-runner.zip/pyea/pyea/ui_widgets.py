"""Widget dùng chung cho giao diện Kivy: theme, bảng, form tham số, biểu đồ, popup.

Lưu ý kỹ thuật (đã rút kinh nghiệm):
- Texture của Label bị giới hạn ~4096px chiều cao trên nhiều GPU -> KHÔNG đưa văn bản dài
  (log, code) vào 1 Label; dùng mỗi dòng 1 Label trong ScrollView.
- Font mặc định của Kivy thiếu dấu tiếng Việt -> nạp DejaVu Sans trong assets/.
- Không dùng emoji (DejaVu không có glyph) - chỉ dùng ký tự thường, ■ ▶ ●.
"""
import math
import os
import time
from .sdk import SUBTYPES
from bisect import bisect_left, bisect_right

from kivy.clock import Clock
from kivy.core.text import Label as CoreLabel
from kivy.core.text import LabelBase
from kivy.graphics import Canvas, Color, Ellipse, Line, Quad, Rectangle, RoundedRectangle, Triangle
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.utils import escape_markup

from . import chart_indicators as chind
from . import drawings
from . import guides
from .i18n import tr
from .chartorder import PriceMap, classify, nearest_line
from .feeds import TF_GROUPS, TIMEFRAMES
from .prefs import fmt_time

# ---------------------------------------------------------------- theme
class Col(list):
    """Màu có thể ĐỔI TẠI CHỖ (đổi giao diện sáng/tối sau khi các module khác đã `from ui_widgets import PANEL`). Dùng như tuple."""
    def __eq__(self, o):
        return tuple(self) == tuple(o)

    def __ne__(self, o):
        return not self.__eq__(o)

    def __add__(self, o):
        return tuple(self) + tuple(o)

    def __getitem__(self, i):
        r = list.__getitem__(self, i)
        return tuple(r) if isinstance(i, slice) else r

    def __radd__(self, o):
        return tuple(o) + tuple(self)

    def __iter__(self):
        return list.__iter__(self)

    def __hash__(self):                                   # noqa: F811 - hashable theo giá trị hiện tại (dùng làm khoá cache chỉ trong 1 lần chạy)
        return hash(tuple(self))


THEMES = {
    "dark": {"BG": (0.05, 0.06, 0.08, 1), "BG2": (0.08, 0.09, 0.12, 1), "PANEL": (0.11, 0.13, 0.17, 1), "PANEL2": (0.16, 0.19, 0.25, 1),
             "TEXT": (0.92, 0.94, 0.97, 1), "MUTED": (0.60, 0.66, 0.74, 1), "GREEN": (0.13, 0.62, 0.40, 1), "RED": (0.80, 0.24, 0.28, 1),
             "BLUE": (0.18, 0.46, 0.84, 1), "AMBER": (0.95, 0.70, 0.22, 1), "UP": (0.20, 0.78, 0.50, 1), "DOWN": (0.92, 0.32, 0.36, 1),
             "INK": (1, 1, 1, 1), "LOG_BOT": (0.45, 0.72, 1, 1), "LOG_TRACE": (0.62, 0.55, 0.95, 1),
             "BUBBLE_USER": (0.10, 0.22, 0.38, 1), "BUBBLE_DECISION": (0.28, 0.22, 0.08, 1)},
    "light": {"BG": (0.94, 0.95, 0.97, 1), "BG2": (0.90, 0.92, 0.95, 1), "PANEL": (1.0, 1.0, 1.0, 1), "PANEL2": (0.88, 0.90, 0.94, 1),
              "TEXT": (0.09, 0.11, 0.15, 1), "MUTED": (0.33, 0.38, 0.46, 1), "GREEN": (0.08, 0.50, 0.30, 1), "RED": (0.74, 0.17, 0.21, 1),
              "BLUE": (0.12, 0.38, 0.76, 1), "AMBER": (0.80, 0.52, 0.04, 1), "UP": (0.05, 0.50, 0.28, 1), "DOWN": (0.78, 0.16, 0.20, 1),
              "INK": (0, 0, 0, 1), "LOG_BOT": (0.10, 0.36, 0.70, 1), "LOG_TRACE": (0.40, 0.28, 0.72, 1),
              "BUBBLE_USER": (0.82, 0.90, 0.99, 1), "BUBBLE_DECISION": (0.99, 0.93, 0.76, 1)},
}
LIGHT_PALETTE = [(0.62, 0.42, 0.0, 1), (0.10, 0.40, 0.80, 1), (0.55, 0.22, 0.75, 1), (0.02, 0.50, 0.48, 1), (0.78, 0.34, 0.06, 1)]
DARK_PALETTE = [(0.98, 0.78, 0.22, 1), (0.36, 0.66, 0.98, 1), (0.82, 0.48, 0.96, 1), (0.30, 0.86, 0.82, 1), (0.98, 0.58, 0.36, 1)]

BG = Col(THEMES["dark"]["BG"])
BG2 = Col(THEMES["dark"]["BG2"])
PANEL = Col(THEMES["dark"]["PANEL"])
PANEL2 = Col(THEMES["dark"]["PANEL2"])
TEXT = Col(THEMES["dark"]["TEXT"])
MUTED = Col(THEMES["dark"]["MUTED"])
GREEN = Col(THEMES["dark"]["GREEN"])
RED = Col(THEMES["dark"]["RED"])
BLUE = Col(THEMES["dark"]["BLUE"])
AMBER = Col(THEMES["dark"]["AMBER"])
UP = Col(THEMES["dark"]["UP"])
DOWN = Col(THEMES["dark"]["DOWN"])
INK = Col(THEMES["dark"]["INK"])                      # màu nét phủ lên nền (lưới, đường ngắm): trắng trên nền tối, đen trên nền sáng
LOG_BOT = Col(THEMES["dark"]["LOG_BOT"])
LOG_TRACE = Col(THEMES["dark"]["LOG_TRACE"])
BUBBLE_USER = Col(THEMES["dark"]["BUBBLE_USER"])
BUBBLE_DECISION = Col(THEMES["dark"]["BUBBLE_DECISION"])
PALETTE = [Col(c) for c in DARK_PALETTE]
CURRENT_THEME = ["dark"]


def apply_theme(name):
    """Đổi bảng màu TẠI CHỖ. Gọi TRƯỚC khi dựng giao diện (widget đã dựng giữ màu cũ). Tên lạ -> dark."""
    name = name if name in THEMES else "dark"
    g = globals()
    for k, v in THEMES[name].items():
        g[k][:] = v
    for c, v in zip(PALETTE, LIGHT_PALETTE if name == "light" else DARK_PALETTE):
        c[:] = v
    CURRENT_THEME[0] = name
    return name


def resolve_theme(setting, night=None):
    """setting: dark | light | auto. auto theo chế độ tối của hệ thống (night=True/False; None/không rõ -> dark)."""
    if setting == "light":
        return "light"
    if setting == "auto" and night is False:
        return "light"
    return "dark"


def luminance(c):
    def ch(v):
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(float(v)) for v in c[:3])
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = luminance(a), luminance(b)
    if la < lb:
        la, lb = lb, la
    return (la + 0.05) / (lb + 0.05)


def on_color(bg):
    """Chữ trên nút: giữ TRẮNG (như trước) trừ khi trắng quá mờ trên nền đó (tương phản < 3) -> dùng gần đen."""
    white = (1, 1, 1, 1)
    return white if contrast(bg, white) >= 3.0 else (0.06, 0.07, 0.10, 1)


ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
MIN_TOUCH = 48   # dp - vùng chạm tối thiểu (dễ bấm khi đeo găng/tay ướt, màn hình nhỏ)


def hexc(c):
    return "%02x%02x%02x" % tuple(int(v * 255) for v in c[:3])


def setup_fonts():
    reg = os.path.join(ASSETS, "DejaVuSans.ttf")
    bold = os.path.join(ASSETS, "DejaVuSans-Bold.ttf")
    if os.path.exists(reg):
        LabelBase.register(name="Roboto", fn_regular=reg,
                           fn_bold=bold if os.path.exists(bold) else reg)


# ---------------------------------------------------------------- helpers
def fp(x):
    if x is None:
        return "-"
    ax = abs(x)
    if ax >= 100:
        return "{:,.2f}".format(x)
    if ax >= 1:
        return "%.4f" % x
    return "%.6f" % x


def round_price(x):
    """Làm tròn giá kéo thả theo độ chính xác thường gặp (>=100: 2 số lẻ; >=1: 5; nhỏ hơn: 6). Sàn còn tự làm tròn theo tick riêng."""
    ax = abs(x)
    return round(x, 2 if ax >= 100 else (5 if ax >= 1 else 6))


def fm(x):
    return "{:+,.2f}".format(x)


def flabel(text="", size=13, color=TEXT, bold=False, halign="left", **kw):
    """Label chiều cao cố định, căn giữa theo chiều dọc."""
    lb = Label(text=tr(text), font_size=sp(size), color=color, bold=bold, halign=halign,
               valign="middle", markup=True, **kw)
    lb.bind(size=lambda w, s: setattr(w, "text_size", s))
    return lb


def wlabel(text="", size=13, color=TEXT, bold=False, **kw):
    """Label tự xuống dòng, tự cao theo nội dung (đừng nhét văn bản quá dài)."""
    lb = Label(text=tr(text), font_size=sp(size), color=color, bold=bold, markup=True,
               halign="left", valign="top", size_hint_y=None, **kw)
    lb.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
    lb.bind(texture_size=lambda w, s: setattr(w, "height", s[1] + dp(2)))
    return lb


def mkbtn(text, bg=BLUE, h=MIN_TOUCH, on_release=None, size=14, **kw):
    dim = tuple(v * 0.7 for v in bg[:3]) + (1,)
    b = Button(text=tr(text), font_size=sp(size), background_normal="", background_down="",
               background_color=bg, color=on_color(bg), size_hint_y=None, height=dp(h), **kw)
    b.bind(state=lambda w, st: setattr(w, "background_color", dim if st == "down" else bg))
    b.halign = kw.get("halign", "center")
    b.bind(width=lambda w, v: setattr(w, "text_size", (max(0, v - dp(8)), None)))      # chữ dài xuống dòng, không tràn nút
    if on_release:
        b.bind(on_release=on_release)
    return b


def mkchip(text, color, active, on_toggle):
    """Nút bật/tắt dạng chip (dùng để ẩn/hiện đường chỉ báo...). on_toggle(active:bool)."""
    from kivy.uix.togglebutton import ToggleButton
    on_bg = tuple(v * 0.55 for v in color[:3]) + (1,)
    b = ToggleButton(text=tr(text), font_size=sp(11), size_hint=(None, None), height=dp(36), halign="center",
                     background_normal="", background_down="", color=TEXT if active else MUTED,
                     background_color=on_bg if active else PANEL2, state="down" if active else "normal")
    b.bind(texture_size=lambda w, ts: setattr(w, "width", ts[0] + dp(22)))

    def _chg(w, st):
        a = st == "down"
        w.background_color = on_bg if a else PANEL2
        w.color = TEXT if a else MUTED
        on_toggle(a)
    b.bind(state=_chg)
    return b


class GestureScrollView(ScrollView):
    """ScrollView cho phép widget cử chỉ (biểu đồ) TỰ xử lý chạm: kéo/chụm ngay trong vùng biểu đồ,
    còn chạm ngoài biểu đồ thì cuộn trang như bình thường (nếu không, ScrollView giành mất cử chỉ kéo)."""

    def __init__(self, **kw):
        super().__init__(**kw)
        self.gesture_widgets = []

    def on_touch_down(self, touch):
        try:
            if self.gesture_widgets and self.collide_point(*touch.pos):
                hit = False
                touch.push()
                try:
                    touch.apply_transform_2d(self.to_local)
                    for w in self.gesture_widgets:
                        if w.collide_point(*touch.pos) and w.on_touch_down(touch):
                            hit = True
                            break
                finally:
                    touch.pop()
                if hit:
                    return True
        except Exception:      # cơ chế cử chỉ lỗi thì quay về ScrollView thường (vẫn cuộn được)
            pass
        return super().on_touch_down(touch)


class PickButton(Button):
    """Nút chọn 1 giá trị: bấm mở LƯỚI nút lớn trong popup (không bị tràn màn hình như danh sách thả của Spinner).
    Có `.text` (giá trị đang chọn) và `.values` như Spinner nên dùng thay Spinner được."""

    def __init__(self, text="", values=(), groups=None, cols=4, title="Chọn", **kw):
        kw.setdefault("font_size", sp(13))
        kw.setdefault("background_normal", "")
        kw.setdefault("background_down", "")
        kw.setdefault("background_color", PANEL2)
        kw.setdefault("color", TEXT)
        super().__init__(text=text, **kw)
        self.values = list(values)
        self.groups, self.cols, self.title_text = groups, cols, title
        self.bind(on_release=self.open_grid)

    def open_grid(self, *_):
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        body = vbox(spacing=dp(6))
        pop = StyledPopup(title=self.title_text, content=content, size_hint=(0.94, 0.82), auto_dismiss=True,
                    separator_color=BLUE)

        def choose(v):
            self.text = str(v)
            pop.dismiss()
        groups = [(t, [i for i in items if i in self.values]) for t, items in self.groups] if self.groups \
            else [("", list(self.values))]
        for title, items in groups:
            if not items:
                continue
            if title:
                body.add_widget(section(title))
            grid = GridLayout(cols=self.cols, size_hint_y=None, spacing=dp(6), row_default_height=dp(MIN_TOUCH),
                              row_force_default=True)
            grid.bind(minimum_height=grid.setter("height"))
            for it in items:
                grid.add_widget(mkbtn(str(it), BLUE if str(it) == self.text else PANEL2, h=MIN_TOUCH, size=14,
                                      on_release=lambda *_, v=it: choose(v)))
            body.add_widget(grid)
        content.add_widget(vscroll(body))
        content.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        pop.open()


def tf_picker(text="1m", **kw):
    """Nút chọn khung thời gian (21 khung như MT5, chia nhóm Phút/Giờ/Ngày-Tuần-Tháng)."""
    return PickButton(text=text, values=list(TIMEFRAMES), groups=TF_GROUPS, cols=4, title="Khung thời gian", **kw)


def vscroll(content):
    # scroll_timeout/scroll_distance: mặc định Kivy (55 ms / 20) khiến ngón kéo bắt đầu trên ô nhập, công tắc, nút xổ... bị các widget đó "ăn" -> khó cuộn.
    # Chờ 220 ms và chỉ cần xê dịch ~6dp là coi như kéo trang; chạm nhanh (nhả trước 220 ms) vẫn bấm được bình thường.
    sv = ScrollView(do_scroll_x=False, bar_width=dp(6), scroll_timeout=220, scroll_distance=dp(6))
    sv.add_widget(content)
    return sv


def gscroll(content, gesture_widgets=()):
    """vscroll nhưng cho các widget cử chỉ (biểu đồ) tự xử lý kéo/chụm. Biểu đồ biết ScrollView cha để chuyển
    cử chỉ kéo DỌC thành cuộn trang."""
    sv = GestureScrollView(do_scroll_x=False, bar_width=dp(6), scroll_timeout=220, scroll_distance=dp(6))
    sv.add_widget(content)
    for w in gesture_widgets:
        sv.gesture_widgets.append(w)
        w.scroll_parent = sv
    return sv


def vbox(**kw):
    """BoxLayout dọc, chiều cao = tổng con (dùng trong ScrollView)."""
    b = BoxLayout(orientation="vertical", size_hint_y=None, **kw)
    b.bind(minimum_height=b.setter("height"))
    return b


def section(text):
    return flabel(text, 13, AMBER, bold=True, size_hint_y=None, height=dp(34))


class Panel(BoxLayout):
    def __init__(self, bg=PANEL, radius=8, **kw):
        super().__init__(**kw)
        with self.canvas.before:
            self._col = Color(*bg)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(radius)])
        self.bind(pos=self._upd, size=self._upd)

    def _upd(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def set_bg(self, bg):
        self._col.rgba = bg


class TapPanel(Panel):
    """Panel bấm được (như chạm một dòng lệnh trong MT5): chạm nhẹ vào CHỖ TRỐNG của dòng = gọi on_tap(); nút con vẫn ăn chạm của chúng;
    kéo (cuộn trang) thì không tính là chạm."""

    def __init__(self, on_tap=None, **kw):
        super().__init__(**kw)
        self.on_tap = on_tap

    def on_touch_down(self, touch):
        if super().on_touch_down(touch):
            return True
        if self.on_tap is not None and self.collide_point(*touch.pos):
            touch.grab(self)
            touch.ud["tap_panel"] = (touch.x, touch.y)
            return True
        return False

    def on_touch_up(self, touch):
        if touch.grab_current is self:
            touch.ungrab(self)
            o = touch.ud.get("tap_panel")
            if o and self.collide_point(*touch.pos) and abs(touch.x - o[0]) < dp(10) and abs(touch.y - o[1]) < dp(10) and self.on_tap:
                self.on_tap()
            return True
        return super().on_touch_up(touch)


def mk_input(text="", hint="", **kw):
    return TextInput(text=text, hint_text=hint, multiline=False, write_tab=False, font_size=sp(14),
                     background_color=PANEL2, foreground_color=TEXT, cursor_color=TEXT, hint_text_color=MUTED,
                     size_hint_y=None, height=dp(44), padding=[dp(8), dp(12), dp(8), dp(6)], **kw)


def mk_spinner(text, values, **kw):
    return Spinner(text=text, values=list(values), font_size=sp(13), background_normal="", background_color=PANEL2,
                   color=TEXT, size_hint_y=None, height=dp(44), **kw)


# ---------------------------------------------------------------- popup
POPUP_STACK = []                     # các popup đang mở (trên cùng = cuối) - để nút Back đóng popup trên cùng thay vì thoát app


def top_popup():
    """Popup trên cùng đang mở (None nếu không có)."""
    return POPUP_STACK[-1] if POPUP_STACK else None


class StyledPopup(Popup):
    """Popup NỀN TỐI TỰ VẼ. Kivy mặc định dùng ảnh nền trong atlas: trên một số máy Android ảnh này không nạp được -> hộp TRẮNG, chữ sáng/tiêu đề
    thành vô hình (đã gặp thật). Nên KHÔNG phụ thuộc ảnh: background="" + màu nền đặc + tự vẽ thêm một hình chữ nhật nền phía sau."""

    def __init__(self, **kw):
        if isinstance(kw.get("title"), str):
            kw["title"] = tr(kw["title"])
        kw.setdefault("background", "")
        kw.setdefault("background_color", PANEL)
        kw.setdefault("title_color", TEXT)
        kw.setdefault("separator_color", BLUE)
        kw.setdefault("overlay_color", (0, 0, 0, 0.6))
        super().__init__(**kw)
        try:
            with self.canvas.before:
                self._bg_col = Color(*PANEL)
                self._bg_rect = Rectangle(pos=self.pos, size=self.size)
            self.bind(pos=self._bg_upd, size=self._bg_upd)
        except Exception:                                    # noqa: BLE001 - vẽ thêm là phụ; hỏng thì vẫn còn background_color
            pass

    def _bg_upd(self, *_):
        self._bg_rect.pos = self.pos
        self._bg_rect.size = self.size

    back_blocks = False              # True: nút Back KHÔNG đóng được (hộp thoại bắt buộc: rủi ro, điều khoản)

    def open(self, *a, **kw):
        if self in POPUP_STACK:
            POPUP_STACK.remove(self)
        POPUP_STACK.append(self)
        return super().open(*a, **kw)

    def dismiss(self, *a, **kw):
        if self in POPUP_STACK:
            POPUP_STACK.remove(self)
        return super().dismiss(*a, **kw)


def popup(title, message, buttons=None, size=(0.92, 0.6), color=TEXT):
    """buttons: [(text, color, callback)] ; callback(popup) -> đóng nếu trả về != False."""
    content = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8))
    body = vbox(padding=dp(2))
    body.add_widget(wlabel(message, 13, color))
    content.add_widget(vscroll(body))
    buttons = buttons or [("Đóng", BLUE, None)]
    stack = len(buttons) >= 3 or any(len(b[0]) > 16 for b in buttons)      # nhiều/dài thì xếp DỌC để không tràn chữ
    row = BoxLayout(orientation="vertical" if stack else "horizontal", size_hint_y=None, spacing=dp(8),
                    height=dp(MIN_TOUCH * len(buttons) + 8 * (len(buttons) - 1)) if stack else dp(MIN_TOUCH))
    pop = StyledPopup(title=title, content=content, size_hint=size, auto_dismiss=False)
    for text, bg, cb in buttons:
        def _go(_w, cb=cb):
            if cb is None or cb(pop) is not False:
                pop.dismiss()
        row.add_widget(mkbtn(text, bg, on_release=_go))
    content.add_widget(row)
    pop.open()
    return pop


def confirm(title, message, on_yes, yes_text="Đồng ý", yes_color=RED):
    return popup(title, message, [("Huỷ", PANEL2, None),
                                  (yes_text, yes_color, lambda p: on_yes())], size=(0.9, 0.45))


# ---------------------------------------------------------------- bảng
def _make_tappable(widget, cb, slop=10):
    """Làm một widget (ô bảng) chạm được mà không chặn kéo cuộn: chạm nhẹ tại chỗ = gọi cb; kéo xa hơn `slop` dp thì bỏ qua."""
    def down(w, touch):
        if w.collide_point(*touch.pos):
            touch.ud["tapcell_%s" % id(w)] = (touch.x, touch.y)
        return False

    def up(w, touch):
        o = touch.ud.get("tapcell_%s" % id(w))
        if o and w.collide_point(*touch.pos) and abs(touch.x - o[0]) < dp(slop) and abs(touch.y - o[1]) < dp(slop):
            cb()
        return False
    widget.bind(on_touch_down=down, on_touch_up=up)


class Table(GridLayout):
    def __init__(self, headers, weights, row_h=28, **kw):
        super().__init__(cols=len(headers), size_hint_y=None, row_default_height=dp(row_h),
                         row_force_default=True, spacing=(dp(2), dp(1)), **kw)
        self.bind(minimum_height=self.setter("height"))
        self.headers = headers
        self.weights = weights
        self.row_h = row_h
        self.set_rows([])

    def _cell(self, text, color, bold, w):
        lb = Label(text=str(text), font_size=sp(11), color=color, bold=bold, size_hint_x=w,
                   size_hint_y=None, height=dp(self.row_h), halign="center", valign="middle",
                   shorten=True, shorten_from="right")
        lb.bind(size=lambda wd, s: setattr(wd, "text_size", s))
        return lb

    def set_rows(self, rows, on_row=None):
        """rows: list các list; mỗi ô là text hoặc (text, color). `on_row(i)` (tuỳ chọn): chạm vào dòng i (không phải kéo cuộn) thì được gọi."""
        self.clear_widgets()
        for h, w in zip(self.headers, self.weights):
            self.add_widget(self._cell(h, MUTED, True, w))
        for i, row in enumerate(rows):
            for item, w in zip(row, self.weights):
                text, color = item if isinstance(item, tuple) else (item, TEXT)
                cell = self._cell(text, color, False, w)
                if on_row is not None:
                    _make_tappable(cell, lambda i=i: on_row(i))
                self.add_widget(cell)


class StatBox(Panel):
    def __init__(self, title, **kw):
        super().__init__(orientation="vertical", padding=[dp(8), dp(4)], spacing=0, **kw)
        self.t = flabel(title, 10, MUTED)
        self.v = flabel("-", 15, TEXT, bold=True)
        self.add_widget(self.t)
        self.add_widget(self.v)

    def set(self, text, color=TEXT):
        self.v.text = text
        self.v.color = color


# ---------------------------------------------------------------- biểu đồ
def _fv(v):
    """Số chỉ báo gọn (nhãn cửa sổ phụ)."""
    a = abs(v)
    if a >= 1000:
        return "{:,.0f}".format(v)
    if a >= 10:
        return "%.2f" % v
    if a >= 1:
        return "%.3f" % v
    return "%.5g" % v


def clip_runs(pts, lo, hi):
    """Cắt đường gấp khúc [(x, v)...] theo khoảng giá [lo, hi] (Liang-Barsky theo trục giá).
    Trả về list các đoạn liên tục [x, v, x, v, ...] - phần ngoài khoảng bị bỏ, không bị kẹp méo."""
    runs, cur = [], []
    for (xa, va), (xb, vb) in zip(pts, pts[1:]):
        t0, t1, dv = 0.0, 1.0, vb - va
        if dv == 0:
            if va < lo or va > hi:
                if len(cur) >= 4:
                    runs.append(cur)
                cur = []
                continue
        else:
            ta_, tb_ = (lo - va) / dv, (hi - va) / dv
            t0, t1 = max(0.0, min(ta_, tb_)), min(1.0, max(ta_, tb_))
            if t0 > t1:
                if len(cur) >= 4:
                    runs.append(cur)
                cur = []
                continue
        if t0 > 0 and cur:
            if len(cur) >= 4:
                runs.append(cur)
            cur = []
        if not cur:
            cur = [xa + (xb - xa) * t0, va + dv * t0]
        cur += [xa + (xb - xa) * t1, va + dv * t1]
        if t1 < 1:
            if len(cur) >= 4:
                runs.append(cur)
            cur = []
    if len(cur) >= 4:
        runs.append(cur)
    return runs


class CandleChart(Widget):
    """Biểu đồ nến kiểu MT5, điều khiển bằng CẢM ỨNG:
       · kéo ngang = lướt qua lại (có đà) · kéo dọc = cuộn trang · chụm 2 ngón = thu/phóng
       · kéo ngang trên trục giờ (dải dưới) = thu/phóng · chạm 2 lần = về mặc định · chạm nến = hiện giá/chỉ báo (crosshair)
       · chạm chấm vào/ra = popup lý do.
    Vẽ: lưới + trục, nến, chỉ báo MT5 (overlay trên giá + cửa sổ phụ RSI/MACD/...), đường chỉ báo của bot (ẩn/hiện được),
    chấm vào/ra lệnh nối nét đứt. `bars` = số nến hiển thị, `offset` = số nến đã lướt lùi so với nến mới nhất."""
    RM = 54          # dp lề phải (nhãn giá)
    BM = 16          # dp lề dưới (nhãn giờ)
    SUB_H = 92       # dp mỗi cửa sổ phụ
    GAP = 3          # dp khe giữa các cửa sổ
    MIN_BARS = 12
    DEFAULT_BARS = 60

    def __init__(self, on_tap=None, on_change=None, **kw):
        super().__init__(**kw)
        self.on_tap, self.on_change = on_tap, on_change
        self.candles, self.plots, self.events, self.hlines = [], {}, [], []
        self.hidden = set()
        self.draft = None                    # lệnh đang soạn TRÊN biểu đồ: {side, price, sl, tp, bid, ask} (giá 0 = chưa đặt)
        self.on_draft = None                 # gọi khi người dùng kéo/chạm đổi đường
        self.bot_objects = []                # đối tượng do BOT vẽ (api.draw_*): chỉ hiển thị, không chọn/xoá/lưu
        self.objects = []                    # đối tượng vẽ tay (pyea/drawings.py) của mã đang xem
        self.tool, self._tool_pts = None, []  # công cụ vẽ đang chọn + các điểm đã chạm
        self.on_object = None                # callback(kind, [(time, price), ...]) khi đủ điểm
        self.on_object_tap = None            # callback(obj) khi chạm trúng một đối tượng
        self.selected = ""
        self._obj_xy = None
        self._pm = PriceMap()
        self.indicators = []                 # cấu hình chỉ báo MT5 (chart_indicators.new_cfg)
        self._ires = {}
        self.bars, self.offset, self._off_f = self.DEFAULT_BARS, 0, 0.0
        self.show_markers = self.show_lines = self.show_grid = True
        self.cross = None                    # (thời gian nến, giá) của crosshair
        self._subgeo, self.cross_pane = [], None    # hình học cửa sổ phụ (để tiêu điểm kéo xuống chỉ báo) · (số thứ tự cửa sổ, giá trị) khi tiêu điểm nằm ở cửa sổ phụ
        self.pshift, self.pzoom = 0.0, 1.0          # kéo dọc trên cột giá: dời / co giãn thang giá (0 / 1 = tự vừa khung)
        self.crosshair_mode = False          # như nút ✚ của MT5: BẬT = một ngón kéo di chuyển tiêu điểm; TẮT = kéo để lướt biểu đồ
        self.on_toast = None
        self.scroll_parent = None            # ScrollView cha (để chuyển kéo dọc thành cuộn trang)
        self._hits, self._zones, self._tex = [], {}, {}
        self._hlhits, self.on_line_tap = [], None          # đường lệnh trên biểu đồ chạm được: [(y, tag, giá, màu)] ; on_line_tap(tag)
        self.on_line_drag = None             # callback(tag, giá mới) khi NHẤN GIỮ rồi kéo thả đường SL/TP/giá lệnh chờ (như MT5) và thả tay
        self._ldrag, self._arm_ev, self._arm_touch = None, None, None
        self._ov = Canvas()                  # LỚP PHỦ: đường lệnh đang soạn/đang kéo vẽ riêng, kéo thả KHÔNG vẽ lại nến + chỉ báo (nguyên nhân giật)
        self._ov_ev, self._dyn, self._draft_t = None, {}, 0.0
        self._touches, self._pinch, self._pinched = {}, None, False
        self._vel, self._fling_v, self._fling_ev, self._redraw_ev = [], 0.0, None, None
        self._last_tap = (0.0, 0.0, 0.0)
        self._bw, self._x0, self._pw, self._start, self._slots = 1.0, 0.0, 1.0, 0, 1
        self.bind(pos=self.redraw, size=self.redraw)

    # ------------------------------------------------------------ dữ liệu
    def _data_sig(self, candles, plots, events, hlines):
        try:
            if not candles:
                return ("empty", len(events or ()), repr(hlines or ()))
            l, f = candles[-1], candles[0]
            return (len(candles), f.time, l.time, l.close, l.high, l.low, l.volume, len(events or ()), repr(hlines or ()),
                    tuple((k, len(v), (v[-1] if len(v) else None)) for k, v in sorted((plots or {}).items())))
        except Exception:                                       # noqa: BLE001
            return None

    def update(self, candles, plots=None, events=None, hlines=None):
        sig = self._data_sig(candles, plots, events, hlines)
        if sig is not None and sig == getattr(self, "_dsig", None) and self.candles:
            return                                              # dữ liệu y hệt lần trước: khỏi vẽ lại (giảm CPU khi giá đứng yên)
        self._dsig = sig
        old_last = self.candles[-1].time if self.candles else None
        if self.candles and candles and self.candles[-1].close and not (0.5 <= candles[-1].close / self.candles[-1].close <= 2.0):
            self.pshift, self.pzoom = 0.0, 1.0                    # đổi sang mã khác hẳn: bỏ dời/co giãn thang giá cũ
        self.candles = candles or []
        self.plots = plots or {}
        self.events = events or []
        self.hlines = hlines or []
        if old_last is not None and self.offset > 0 and self.candles:
            # nến mới ra: giữ nguyên khung nhìn THEO THỜI GIAN (nếu không, nội dung sẽ trôi khi đang xem lại quá khứ)
            times = [c.time for c in self.candles]
            k = bisect_left(times, old_last)
            if k < len(times) and times[k] == old_last and k < len(times) - 1:
                self._off_f += len(times) - 1 - k
                self.offset = int(round(self._off_f))
        self._clamp_view()
        self.redraw()

    def set_indicators(self, cfgs):
        self.indicators = list(cfgs or [])
        self._ires = {k: v for k, v in self._ires.items() if k in {c["uid"] for c in self.indicators}}
        self.redraw()

    def wanted_height(self, base_dp):
        """Chiều cao (dp) để chứa vùng giá + các cửa sổ phụ đang hiện."""
        k = sum(1 for c in self.indicators if c.get("visible", True) and chind.INDICATORS[c["key"]].pane == "sub")
        return base_dp + k * (self.SUB_H + self.GAP)

    def _results(self):
        out = []
        if not self.candles:
            return out
        last = self.candles[-1]
        sig0 = (len(self.candles), self.candles[0].time, last.time, last.close, last.high, last.low, last.volume)
        for cfg in self.indicators:
            if not cfg.get("visible", True) or cfg["key"] not in chind.INDICATORS:
                continue
            sig = (sig0, cfg["key"], repr(sorted((cfg.get("params") or {}).items())))
            ent = self._ires.get(cfg["uid"])
            if ent is None or ent[0] != sig:
                ent = self._ires[cfg["uid"]] = (sig, chind.compute(cfg, self.candles))
            out.append((cfg, ent[1]))
        return out

    # ------------------------------------------------------------ khung nhìn
    def _max_bars(self):
        return max(30, min(1500, len(self.candles)))

    def _clamp_view(self):
        n = len(self.candles)
        self.bars = int(max(self.MIN_BARS, min(self._max_bars(), self.bars)))
        mo = max(0, n - self.bars)
        self._off_f = max(0.0, min(float(mo), self._off_f))
        self.offset = int(round(self._off_f))

    def set_offset(self, off):
        self._off_f = float(off)
        self._clamp_view()

    def _pad(self, bars):
        """Số ô trống bên phải: tối thiểu 10% (để chỉ báo dịch sang tương lai hiện được, vd mây Ichimoku +26 nến)."""
        base = max(4, int(round(bars * 0.10)))
        need = 0
        for cfg, res in self._results():
            if res["pane"] == "main":
                for ln in res["lines"]:
                    need = max(need, ln["shift"])
        return max(base, min(need, max(4, bars // 2)))

    def _anchor_g(self, anchor_x):
        """Chỉ số nến (số thực) đang nằm dưới toạ độ x theo khung nhìn HIỆN TẠI."""
        n = len(self.candles)
        start = max(0, n - int(self.offset) - self.bars)
        bw = self._pw / max(1, self.bars + self._pad(self.bars))
        return start + (anchor_x - self._x0) / max(1e-6, bw) - 0.5

    def _set_zoom(self, new_bars, g_anchor, anchor_x):
        """Đặt số nến hiển thị sao cho nến g_anchor nằm đúng dưới x = anchor_x."""
        n = len(self.candles)
        nb = int(round(max(self.MIN_BARS, min(self._max_bars(), new_bars))))
        bw_n = self._pw / max(1, nb + self._pad(nb))
        start_n = g_anchor + 0.5 - (anchor_x - self._x0) / max(1e-6, bw_n)
        self.bars = nb
        self._off_f = n - nb - start_n
        self._clamp_view()

    def zoom_by(self, factor, anchor_x=None):
        """factor < 1: phóng to (ít nến hơn); > 1: thu nhỏ. Giữ nến dưới `anchor_x` đứng yên (mặc định: mép phải)."""
        if len(self.candles) < 2:
            return
        if anchor_x is None:
            anchor_x = self._x0 + self._pw
        old = self.bars
        self._set_zoom(self.bars * factor, self._anchor_g(anchor_x), anchor_x)
        if self.bars != old:
            self._notify()

    def pan_pixels(self, dx):
        """dx > 0 (kéo sang phải) = xem nến cũ hơn."""
        self._off_f += dx / max(1e-6, self._bw)
        self._clamp_view()

    def go_latest(self):
        self._stop_fling()
        self._off_f, self.offset = 0.0, 0
        self.redraw()

    def reset_view(self):
        self._stop_fling()
        self.bars, self._off_f, self.offset, self.cross = self.DEFAULT_BARS, 0.0, 0, None
        self.pshift, self.pzoom = 0.0, 1.0
        self._clamp_view()
        self.redraw()
        self._notify()

    def _notify(self):
        if self.on_change:
            self.on_change()

    # ------------------------------------------------------------ lớp phủ (đường đang soạn/đang kéo)
    def request_overlay(self):
        if self._ov_ev is None:
            self._ov_ev = Clock.schedule_once(self._flush_ov, 0)

    def _flush_ov(self, *_):
        self._ov_ev = None
        self._redraw_overlay()

    def _redraw_overlay(self):
        self._ov.clear()
        if len(self.candles) < 2 or self.width < dp(80) or self.height < dp(60):
            return
        with self._ov:
            self._draw_draft(self._x0, self._pw, None)
            self._draw_ldrag()

    def _dyn_text(self, key, text, x, y, size, color):
        """Chữ đổi liên tục khi kéo: dựng lại texture tối đa ~16 lần/giây (mỗi lần dựng tốn nhiều trên điện thoại), còn lại dùng chữ cũ."""
        now = time.time()
        old = self._dyn.get(key)
        if old is not None and old[0] != text and now - old[2] < 0.06:
            tex = old[1]
        elif old is not None and old[0] == text:
            tex = old[1]
        else:
            lb = CoreLabel(text=text, font_size=sp(size), color=color, font_name="Roboto")
            lb.refresh()
            tex = lb.texture
            self._dyn[key] = (text, tex, now)
        if tex is None:
            return
        w, h = tex.size
        Color(1, 1, 1, 1)
        Rectangle(texture=tex, pos=(x, y - h / 2), size=(w, h))

    def _draw_ldrag(self):
        d = self._ldrag
        if not d:
            return
        pm = self._pm
        y = max(pm.y0 + dp(2), min(pm.y0 + pm.h - dp(2), pm.y(d["price"])))
        x0, pw = self._x0, self._pw
        Color(1, 1, 1, 0.95)
        Line(points=[x0, y, x0 + pw, y], width=dp(2.2))
        Color(*d["col"])
        Ellipse(pos=(x0 + pw - dp(30), y - dp(12)), size=(dp(24), dp(24)))
        ref = d.get("ref")
        pct = (" (%+.2f%%)" % ((d["price"] / ref - 1.0) * 100.0)) if ref else ""
        self._dyn_text("ld", "%s  %s%s" % (d["label"], fp(d["price"]), pct), x0 + dp(6), y + dp(12), 11, d["col"])

    def _arm_drag(self, *_):
        """Nhấn giữ đủ lâu trên đường SL/TP/giá lệnh chờ -> nhấc đường lên để kéo (giống MT5; chạm nhanh/kéo ngang vẫn là mở hộp sửa/lướt biểu đồ)."""
        self._arm_ev = None
        t = self._arm_touch
        st = self._touches.get(t[0]) if t else None
        if st is None or st["moved"] or len(self._touches) != 1:
            return
        hit = t[1]
        st["drag_line"] = hit[1]
        self._ldrag = {"tag": hit[1], "price": hit[2], "orig": hit[2], "col": hit[3], "label": hit[4],
                      "ref": self.candles[-1].close if self.candles else None}
        st["moved"] = True
        self.request_overlay()
        if self.on_toast:
            self.on_toast("Kéo lên/xuống để dời %s, thả tay để áp dụng." % hit[4])

    def _cancel_arm(self):
        if self._arm_ev is not None:
            self._arm_ev.cancel()
            self._arm_ev = None

    def _line_at(self, x, y):
        """Đường lệnh KÉO ĐƯỢC (SL/TP của lệnh mở/chờ, giá lệnh chờ) gần điểm chạm."""
        if x > self._x0 + self._pw:
            return None
        near = [(abs(h[0] - y), h) for h in self._hlhits if h[1] and len(h[1]) > 2 and (h[1][2] in ("sl", "tp") or (h[1][0] == "pend" and h[1][2] == "entry"))
                and abs(h[0] - y) <= dp(18)]
        return min(near, key=lambda t: t[0])[1] if near else None

    def request_redraw(self):
        if self._redraw_ev is None:
            self._redraw_ev = Clock.schedule_once(self._flush, 0)

    def _flush(self, *_):
        self._redraw_ev = None
        self.redraw()

    # ------------------------------------------------------------ vẽ chữ
    def _label(self, text, size=10, color=MUTED):
        key = (text, size, color)
        t = self._tex.get(key)
        if t is None:
            if len(self._tex) > 400:
                self._tex.clear()
            lb = CoreLabel(text=text, font_size=sp(size), color=color, font_name="Roboto")
            lb.refresh()
            t = self._tex[key] = lb.texture
        return t

    def _text(self, text, x, y, size=10, color=MUTED, anchor="left"):
        t = self._label(text, size, color)
        if t is None:
            return 0
        w, h = t.size
        Color(1, 1, 1, 1)
        Rectangle(texture=t, pos=(x - (w if anchor == "right" else w / 2 if anchor == "center" else 0), y - h / 2), size=(w, h))
        return w

    # ------------------------------------------------------------ vẽ
    def redraw(self, *_):
        self.canvas.clear()
        self._hits, self._zones, self._subgeo, self._hlhits = [], {}, [], []
        with self.canvas:
            Color(*BG2)
            Rectangle(pos=self.pos, size=self.size)
            if len(self.candles) < 2 or self.width < dp(80) or self.height < dp(60):
                self.canvas.add(self._ov)
                self._ov.clear()
                return
            self._draw()
        self.canvas.add(self._ov)                             # trên cùng, sau nến/chỉ báo
        self._redraw_overlay()

    def _series_pts(self, ln, start, end):
        v, sh = ln["v"], ln["shift"]
        out = []
        for g in range(start, end):
            j = g - sh
            if 0 <= j < len(v) and v[j] is not None:
                out.append((g, v[j]))
        return out

    def _draw_lines(self, res, cfg, X, Yf, start, end, lo, hi, bottom_y=None):
        """Vẽ các đường/chấm/cột của 1 chỉ báo trong khoảng giá [lo, hi]; Yf: giá -> toạ độ y."""
        for k, ln in enumerate(res["lines"]):
            col = chind.line_color(cfg, ln, k)
            pts = self._series_pts(ln, start, end)
            if not pts:
                continue
            st = ln["style"]
            if st == "line":
                runs, cur = [], [pts[0]]
                for a, b in zip(pts, pts[1:]):
                    if b[0] == a[0] + 1:
                        cur.append(b)
                    else:
                        runs.append(cur)
                        cur = [b]
                runs.append(cur)
                Color(*col)
                for r in runs:
                    for seg in clip_runs([(X(g), v) for g, v in r], lo, hi):
                        Line(points=[c for i in range(0, len(seg), 2) for c in (seg[i], Yf(seg[i + 1]))], width=dp(ln.get("width", 1.1)))
            elif st == "dots":
                Color(*col)
                r = dp(1.7)
                for g, v in pts:
                    if lo <= v <= hi:
                        Ellipse(pos=(X(g) - r, Yf(v) - r), size=(2 * r, 2 * r))
            elif st in ("tri_up", "tri_down"):
                Color(*col)
                r = dp(4)
                for g, v in pts:
                    if lo <= v <= hi:
                        x, y = X(g), Yf(v)
                        if st == "tri_up":
                            Triangle(points=[x - r, y - dp(10), x + r, y - dp(10), x, y - dp(3)])
                        else:
                            Triangle(points=[x - r, y + dp(10), x + r, y + dp(10), x, y + dp(3)])
            elif st.startswith("hist"):
                y0 = Yf(max(lo, min(hi, 0.0)))
                bw = max(dp(1), self._bw * 0.6)
                prev = None
                for g, v in pts:
                    if st == "hist_ud":
                        c = UP if (prev is None or v >= prev) else DOWN
                    elif st == "hist_vol":
                        cd = self.candles[g] if 0 <= g < len(self.candles) else None
                        c = UP if (cd is None or cd.close >= cd.open) else DOWN
                    else:
                        c = col
                    prev = v
                    Color(*c)
                    y1 = Yf(max(lo, min(hi, v)))
                    Rectangle(pos=(X(g) - bw / 2, min(y0, y1)), size=(bw, max(abs(y1 - y0), dp(0.8))))

    def _draw_fills(self, res, X, Yf, start, end, lo, hi):
        for f in res["fills"]:
            la, lb = res["lines"][f["a"]], res["lines"][f["b"]]
            pa = dict(self._series_pts(la, start, end))
            pb = dict(self._series_pts(lb, start, end))
            gs = sorted(set(pa) & set(pb))
            for g0, g1 in zip(gs, gs[1:]):
                if g1 != g0 + 1:
                    continue
                a0, a1, b0, b1 = pa[g0], pa[g1], pb[g0], pb[g1]
                Color(*(f["pos"] if (a0 + a1) >= (b0 + b1) else f["neg"]))
                cl = lambda v: max(lo, min(hi, v))      # noqa: E731
                Quad(points=[X(g0), Yf(cl(a0)), X(g1), Yf(cl(a1)), X(g1), Yf(cl(b1)), X(g0), Yf(cl(b0))])

    def _draw(self):
        n_all = len(self.candles)
        bars = self.bars = int(max(self.MIN_BARS, min(self._max_bars(), self.bars)))
        pad = self._pad(bars)                                 # ô trống bên phải (để chỉ báo dịch tới tương lai)
        slots = bars + pad
        off = max(0, min(int(self.offset), max(0, n_all - bars)))
        start = max(0, n_all - off - bars)
        end = min(n_all, start + slots)
        vis = self.candles[start:end]
        n = len(vis)
        if n < 1:
            return
        results = self._results()
        mains = [(c, r) for c, r in results if r["pane"] == "main"]
        subs = [(c, r) for c, r in results if r["pane"] == "sub"]
        bm, sh, gap = dp(self.BM), dp(self.SUB_H), dp(self.GAP)
        x0, pw = self.x, self.width - dp(self.RM)
        bw = pw / slots
        self._bw, self._x0, self._pw, self._start, self._slots = bw, x0, pw, start, slots
        main_y0 = self.y + bm + len(subs) * (sh + gap)
        ph = max(dp(60), self.y + self.height - dp(6) - main_y0)
        hi = max(c.high for c in vis)
        lo = min(c.low for c in vis)
        if hi <= lo:
            hi, lo = lo + 1e-9, lo - 1e-9
        padp = (hi - lo) * 0.08
        hi, lo = hi + padp, lo - padp
        if self.pshift or self.pzoom != 1.0:
            rng = hi - lo
            mid = (hi + lo) / 2.0 + self.pshift * rng
            half = rng / 2.0 * self.pzoom
            hi, lo = mid + half, mid - half
        self._pm = PriceMap(main_y0, ph, lo, hi)

        def X(g):
            return x0 + (g - start + 0.5) * bw

        def Y(p):
            return main_y0 + max(0.0, min(1.0, (p - lo) / (hi - lo))) * ph

        def Yraw(p):
            return main_y0 + (p - lo) / (hi - lo) * ph
        times = [c.time for c in vis]
        step = (times[-1] - times[-2]) if n >= 2 else 60.0
        # --- lưới + nhãn giá
        for k in range(5):
            p = lo + (hi - lo) * k / 4.0
            y = Y(p)
            if self.show_grid:
                Color(*INK[:3], 0.06)
                Line(points=[x0, y, x0 + pw, y], width=1)
            self._text(fp(p), x0 + pw + dp(3), y, 9, MUTED)
        span = times[-1] - times[0]
        if step >= 27 * 86400:
            fmt = "%m/%Y"
        elif step >= 86400:
            fmt = "%d/%m/%y" if span > 200 * 86400 else "%d/%m"
        else:
            fmt = "%d/%m %H:%M" if span > 86400 else "%H:%M"
        label_idx = sorted({0, n // 3, 2 * n // 3, n - 1})
        for i in label_idx:
            x = X(start + i)
            if self.show_grid:
                Color(*INK[:3], 0.04)
                Line(points=[x, self.y + bm, x, main_y0 + ph], width=1)
            self._text(fmt_time(fmt, times[i]), x, self.y + bm / 2, 9, MUTED, "center")
        # --- nến
        body = max(dp(1), bw * 0.65)
        # Gom theo màu: mỗi khung hình chỉ 2 lệnh Color thay vì một lệnh cho MỖI nến (nến không chồng nhau nên hình giống hệt).
        for col, up in ((UP, True), (DOWN, False)):
            Color(*col)
            for i, c in enumerate(vis):
                if (c.close >= c.open) is not up:
                    continue
                x = X(start + i)
                Line(points=[x, Y(c.low), x, Y(c.high)], width=1)
                yo, yc = Y(c.open), Y(c.close)
                Rectangle(pos=(x - body / 2, min(yo, yc)), size=(body, max(abs(yc - yo), dp(1))))
        # --- chỉ báo MT5 trên biểu đồ giá
        gend = start + slots                                   # tới hết ô trống: chỉ báo dịch +N nến vẫn hiện
        for cfg, res in mains:
            self._draw_fills(res, X, Yraw, start, gend, lo, hi)
        for cfg, res in mains:
            self._draw_lines(res, cfg, X, Yraw, start, gend, lo, hi)
        # --- đường chỉ báo của bot (api.plot)
        idx = {t: i for i, t in enumerate(times)}
        for k, (name, pts) in enumerate(self.plots.items()):
            if name in self.hidden:
                continue
            co = []
            for t, v in pts:
                i = idx.get(t)
                if i is not None:
                    co += [X(start + i), Y(v)]
            if len(co) >= 4:
                Color(*PALETTE[k % len(PALETTE)])
                Line(points=co, width=dp(1.1))
        # --- đường giá vào của lệnh đang mở
        if self.show_lines:
            for hl in self.hlines:
                price, col = hl[0], hl[1]
                if lo <= price <= hi:
                    Color(*col)
                    Line(points=[x0, Y(price), x0 + pw, Y(price)], width=1, dash_length=dp(4), dash_offset=dp(3))
                    if len(hl) > 2 and hl[2]:
                        self._text(hl[2], x0 + dp(4), Y(price) + dp(8), 9, col)
                    if len(hl) > 3 and hl[3]:
                        tg = hl[3]
                        self._hlhits.append((Y(price), tg, price, col, (hl[2] or "").split(" ")[0] + (" #%s" % tg[1] if len(tg) > 1 else ""), None))
        self._draw_objects(X, Yraw, x0, pw, main_y0, ph, lo, hi, step)
        # --- giá hiện tại
        if off == 0:
            last = self.candles[-1].close
            Color(*BLUE)
            Line(points=[x0, Y(last), x0 + pw, Y(last)], width=1, dash_length=dp(2), dash_offset=dp(2))
            Rectangle(pos=(x0 + pw, Y(last) - dp(7)), size=(dp(self.RM), dp(14)))
            self._text(fp(last), x0 + pw + dp(3), Y(last), 9, (1, 1, 1, 1))
        # --- chấm vào/ra lệnh
        if self.show_markers and self.events:
            self._markers(vis, times, X, Y, step, start)
        # --- cửa sổ phụ
        for k, (cfg, res) in enumerate(subs):
            py0 = self.y + bm + (len(subs) - 1 - k) * (sh + gap)
            self._draw_sub(cfg, res, X, py0, sh, x0, pw, start, end, gend)
        # --- crosshair + ô thông tin
        self._draw_cross(vis, times, start, X, Y, main_y0, ph, x0, pw, mains, subs)
        self._draw_cross_button(x0, pw, main_y0, ph)
        # --- nút "Mới nhất" khi đang xem quá khứ
        if off > 0:
            zw, zh = dp(78), dp(28)
            zx, zy = x0 + pw - zw - dp(6), main_y0 + dp(8)
            Color(*BLUE)
            RoundedRectangle(pos=(zx, zy), size=(zw, zh), radius=[dp(14)])
            self._text("Mới nhất ▶", zx + zw / 2, zy + zh / 2, 10, (1, 1, 1, 1), "center")
            self._zones["latest"] = (zx - dp(10), zy - dp(10), zw + dp(20), zh + dp(20))

    CB = 40            # dp: nút tiêu điểm ✚

    def _draw_cross_button(self, x0, pw, main_y0, ph):
        """Nút ✚ tròn góc trên-phải biểu đồ (như MT5): chạm để bật/tắt chế độ tiêu điểm."""
        d = dp(self.CB)
        bx, by = x0 + pw - d - dp(6), main_y0 + ph - d - dp(6)
        if self.crosshair_mode:
            Color(*BLUE)
        else:
            Color(*PANEL2[:3], 0.92)
        Ellipse(pos=(bx, by), size=(d, d))
        Color(*(((1, 1, 1) if self.crosshair_mode else tuple(INK[:3])) + (1,)))
        cx, cy, r = bx + d / 2.0, by + d / 2.0, d * 0.28
        Line(points=[cx - r, cy, cx + r, cy], width=dp(1.4))
        Line(points=[cx, cy - r, cx, cy + r], width=dp(1.4))
        self._zones["cross"] = (bx - dp(6), by - dp(6), d + dp(12), d + dp(12))

    def set_crosshair_mode(self, on):
        self.crosshair_mode = bool(on)
        if not on:
            self.cross = None
        self.redraw()

    def _xhair_at(self, x, y):
        """Đặt tiêu điểm tại điểm chạm: ngang bám nến gần nhất, dọc theo đúng giá tại ngón tay."""
        n = len(self.candles)
        if n < 1 or self._bw <= 0:
            return
        g = int(self._start + (x - self._x0) / self._bw)
        g = max(self._start, min(n - 1, g, self._start + self._slots - 1))
        c = self.candles[g]
        self.cross = (c.time, c.close)
        self._cross_price_from_y(y)
        self.redraw()

    # ------------------------------------------------------------ công cụ vẽ (pyea/drawings.py)
    def _draw_objects(self, X, Yraw, x0, pw, y0, ph, lo, hi, step):
        all_t = [c.time for c in self.candles]

        def xy(t, p):
            return X(drawings.frac_index(all_t, t, step)), Yraw(p)
        self._obj_xy = xy
        x1, ytop = x0 + pw, y0 + ph

        def seg(a, b, c, d):
            return drawings.clip_segment(a, b, c, d, x0, y0, x1, ytop)
        for o in list(self.objects) + list(self.bot_objects):
            col = drawings.COLORS[o["color"] % len(drawings.COLORS)]
            w = dp(2.2) if o["id"] == self.selected else dp(1.2)
            pts = [xy(t, p) for t, p in o["pts"]]
            Color(*col)
            k = o["kind"]
            if k == "hline":
                s_ = seg(x0, pts[0][1], x1, pts[0][1])
                if s_:
                    Line(points=list(s_), width=w)
                    self._text(fp(o["pts"][0][1]), x0 + dp(4), pts[0][1] + dp(8), 9, col)
            elif k == "trend":
                s_ = seg(pts[0][0], pts[0][1], pts[1][0], pts[1][1])
                if s_:
                    Line(points=list(s_), width=w)
            elif k == "rect":
                ax, bx = sorted((pts[0][0], pts[1][0]))
                ay, by = sorted((pts[0][1], pts[1][1]))
                cx0, cx1, cy0, cy1 = max(ax, x0), min(bx, x1), max(ay, y0), min(by, ytop)
                if cx0 < cx1 and cy0 < cy1:
                    Color(col[0], col[1], col[2], 0.16)
                    Rectangle(pos=(cx0, cy0), size=(cx1 - cx0, cy1 - cy0))
                    Color(*col)
                    Line(rectangle=(cx0, cy0, cx1 - cx0, cy1 - cy0), width=w)
            elif k == "fib":
                ax, bx = sorted((pts[0][0], pts[1][0]))
                for r, price in drawings.fib_prices(o["pts"][0][1], o["pts"][1][1]):
                    y = Yraw(price)
                    s_ = seg(ax, y, max(bx, ax + dp(40)), y)
                    if s_:
                        if r in (0.0, 1.0):
                            Line(points=list(s_), width=w)
                        else:
                            Line(points=list(s_), width=w, dash_length=dp(4), dash_offset=dp(3))
                        self._text("%.1f%%  %s" % (r * 100, fp(price)), s_[0] + dp(3), y + dp(7), 8, col)
            elif k == "text":
                if x0 <= pts[0][0] <= x1 and y0 <= pts[0][1] <= ytop:
                    self._text(o.get("text") or "•", pts[0][0], pts[0][1], 11, col, "center")
        for t, p in self._tool_pts:                                    # điểm đã chạm của công cụ đang vẽ dở
            x, y = xy(t, p)
            if x0 <= x <= x1 and y0 <= y <= ytop:
                Color(*INK[:3], 0.9)
                Ellipse(pos=(x - dp(5), y - dp(5)), size=(dp(10), dp(10)))

    def set_tool(self, kind):
        self.tool = kind if kind in drawings.KINDS else None
        self._tool_pts = []
        self.request_redraw()

    def _obj_point(self, touch):
        """Toạ độ chạm -> (thời gian, giá) theo khung nhìn hiện tại."""
        times = [c.time for c in self.candles]
        step = (times[-1] - times[-2]) if len(times) >= 2 else 60.0
        g = (touch.x - self._x0) / self._bw - 0.5 + self._start
        return drawings.time_at(times, g, step), self._pm.price(touch.y)

    def _object_touch(self, touch):
        """True nếu cú chạm đã được công cụ vẽ / chọn đối tượng xử lý."""
        if self.tool and self.candles:
            self._tool_pts.append(self._obj_point(touch))
            if len(self._tool_pts) >= drawings.POINTS[self.tool]:
                kind, pts = self.tool, self._tool_pts
                self.tool, self._tool_pts = None, []
                if self.on_object:
                    self.on_object(kind, pts)
            self.request_redraw()
            return True
        if self.objects and self._obj_xy is not None and self.on_object_tap:
            o = drawings.nearest(self.objects, touch.x, touch.y, self._obj_xy, self._pw, dp(12))
            if o is not None:
                self.selected = o["id"]
                self.request_redraw()
                self.on_object_tap(o)
                return True
        return False

    # ------------------------------------------------------------ đặt lệnh trên biểu đồ (như MT5 mobile)
    DRAFT_COL = {"entry": BLUE, "sl": (0.95, 0.45, 0.20, 1), "tp": (0.13, 0.62, 0.40, 1)}

    def draft_lines(self):
        d = self.draft
        if not d:
            return {}
        return {"entry": d.get("price"), "sl": d.get("sl"), "tp": d.get("tp")}

    def draft_label(self, name):
        d = self.draft or {}
        if name == "entry":
            return classify(d.get("side"), d.get("price"), d.get("bid"), d.get("ask"))[1]
        return "SL" if name == "sl" else "TP"

    def _draw_draft(self, x0, pw, Y):
        d = self.draft
        if not d:
            return
        for name, price in self.draft_lines().items():
            if not price:
                continue
            col = self.DRAFT_COL[name]
            y = max(self._pm.y0 + dp(2), min(self._pm.y0 + self._pm.h - dp(2), self._pm.y(price)))
            Color(*col)
            Line(points=[x0, y, x0 + pw, y], width=dp(1.4))
            Ellipse(pos=(x0 + pw - dp(26), y - dp(9)), size=(dp(18), dp(18)))          # tay nắm để kéo
            Color(1, 1, 1, 1)
            Line(points=[x0 + pw - dp(21), y, x0 + pw - dp(13), y], width=1)
            self._dyn_text("dr_" + name, "%s  %s" % (self.draft_label(name), fp(price)), x0 + dp(6), y + dp(10), 10, col)

    def set_draft_price(self, name, price):
        if not self.draft or name not in ("entry", "sl", "tp"):
            return
        self.draft["price" if name == "entry" else name] = float(price)
        self.request_overlay()                                 # chỉ lớp phủ, không vẽ lại nến
        self._notify_draft()

    def _notify_draft(self, force=False):
        now = time.time()
        if self.on_draft and (force or now - self._draft_t >= 0.12):          # dựng lại thanh nút mỗi pixel kéo là nguyên nhân giật thứ hai
            self._draft_t = now
            self.on_draft()

    def _draft_hit(self, x, y):
        if not self.draft or x > self._x0 + self._pw + dp(self.RM):
            return None
        return nearest_line(self.draft_lines(), y, self._pm, dp(28))

    def _draw_sub(self, cfg, res, X, py0, ph, x0, pw, start, end, gend):
        Color(*PANEL)
        Rectangle(pos=(x0, py0), size=(pw, ph))
        Color(*INK[:3], 0.10)
        Line(rectangle=(x0, py0, pw, ph), width=1)
        name = chind.describe(cfg)
        if res["note"] or not res["lines"]:
            self._text("%s - %s" % (name, res["note"] or "không có dữ liệu"), x0 + dp(6), py0 + ph - dp(8), 10, AMBER)
            return
        rng = chind.sub_axis_range(res, start, gend)
        if rng is None:
            self._text(name + " (chưa đủ dữ liệu)", x0 + dp(6), py0 + ph - dp(8), 10, MUTED)
            return
        lo, hi = rng
        top_m, bot_m = dp(16), dp(4)
        self._subgeo.append((py0, ph, lo, hi, top_m, bot_m))

        def Yf(v):
            return py0 + bot_m + (v - lo) / (hi - lo) * (ph - top_m - bot_m)
        for lv in res["levels"]:
            if lo <= lv <= hi:
                Color(*INK[:3], 0.22)
                Line(points=[x0, Yf(lv), x0 + pw, Yf(lv)], width=1, dash_length=dp(3), dash_offset=dp(3))
                self._text(_fv(lv), x0 + pw + dp(3), Yf(lv), 9, MUTED)
        if res["zero"] and lo < 0 < hi:
            Color(*INK[:3], 0.28)
            Line(points=[x0, Yf(0), x0 + pw, Yf(0)], width=1)
            self._text("0", x0 + pw + dp(3), Yf(0), 9, MUTED)
        self._text(_fv(hi), x0 + pw + dp(3), py0 + ph - dp(10), 9, MUTED)
        self._text(_fv(lo), x0 + pw + dp(3), py0 + dp(7), 9, MUTED)
        self._draw_lines(res, cfg, X, Yf, start, gend, lo, hi)
        # nhãn: tên + giá trị tại crosshair (hoặc nến cuối đang hiện)
        g = self._cross_index()
        if g is None or not (start <= g < end):
            g = end - 1
        parts = [name]
        for ln in res["lines"][:3]:
            j = g - ln["shift"]
            if 0 <= j < len(ln["v"]) and ln["v"][j] is not None and ln["style"] not in ("dots", "tri_up", "tri_down"):
                parts.append("%s %s" % (ln["name"], _fv(ln["v"][j])) if len(res["lines"]) > 1 else _fv(ln["v"][j]))
        self._text("  ".join(parts), x0 + dp(6), py0 + ph - dp(8), 10, TEXT)

    def _cross_index(self):
        if self.cross is None or not self.candles:
            return None
        times = [c.time for c in self.candles]
        i = bisect_right(times, self.cross[0]) - 1
        return i if i >= 0 else None

    def _draw_cross(self, vis, times, start, X, Y, main_y0, ph, x0, pw, mains, subs):
        g = self._cross_index()
        if g is None or not (start <= g < start + len(vis)):
            return
        c = self.candles[g]
        x = X(g)
        Color(*INK[:3], 0.45)
        Line(points=[x, self.y + dp(self.BM), x, main_y0 + ph], width=1, dash_length=dp(3), dash_offset=dp(3))
        tl = fmt_time("%d/%m %H:%M", c.time)                         # nhãn thời gian ở trục dưới (như MT5) - để so hai biểu đồ cùng một thời điểm
        tw0 = self._label(tl, 9, TEXT).size[0] + dp(8)
        tx = max(x0, min(x - tw0 / 2.0, x0 + pw - tw0))
        Color(0.35, 0.38, 0.45, 1)
        Rectangle(pos=(tx, self.y + dp(1)), size=(tw0, dp(14)))
        self._text(tl, tx + tw0 / 2.0, self.y + dp(8), 9, (1, 1, 1, 1), "center")
        Color(*INK[:3], 0.45)
        price = self.cross[1]
        yy = Y(price)
        cp = self.cross_pane
        if cp is not None and cp[0] < len(self._subgeo):                 # tiêu điểm đang ở cửa sổ chỉ báo (như MT5): đường ngang + nhãn giá trị của chỉ báo
            py0, sph, slo, shi, tm, bm_ = self._subgeo[cp[0]]
            ys = py0 + bm_ + (cp[1] - slo) / ((shi - slo) or 1e-12) * (sph - tm - bm_)
            Line(points=[x0, ys, x0 + pw, ys], width=1, dash_length=dp(3), dash_offset=dp(3))
            Color(0.35, 0.38, 0.45, 1)
            Rectangle(pos=(x0 + pw, ys - dp(7)), size=(dp(self.RM), dp(14)))
            self._text(_fv(cp[1]), x0 + pw + dp(3), ys, 9, (1, 1, 1, 1))
        elif main_y0 <= yy <= main_y0 + ph:
            Line(points=[x0, yy, x0 + pw, yy], width=1, dash_length=dp(3), dash_offset=dp(3))
            Color(0.35, 0.38, 0.45, 1)
            Rectangle(pos=(x0 + pw, yy - dp(7)), size=(dp(self.RM), dp(14)))
            self._text(fp(price), x0 + pw + dp(3), yy, 9, (1, 1, 1, 1))
        lines = ["%s   O %s  H %s  L %s  C %s" % (fmt_time("%d/%m %H:%M", c.time), fp(c.open), fp(c.high),
                                                  fp(c.low), fp(c.close))]
        extra = []
        for cfg, res in mains:
            for ln in res["lines"][:2]:
                j = g - ln["shift"]
                if 0 <= j < len(ln["v"]) and ln["v"][j] is not None and ln["style"] == "line":
                    extra.append("%s %s" % (chind.describe(cfg) if len(res["lines"]) == 1 else ln["name"], fp(ln["v"][j])))
        if extra:
            lines.append("  ".join(extra[:4]))
        tw = max(self._label(t, 10, TEXT).size[0] for t in lines)
        bx, by = x0 + dp(4), main_y0 + ph - dp(6) - dp(15) * len(lines)
        Color(*PANEL[:3], 0.88)
        Rectangle(pos=(bx, by), size=(tw + dp(10), dp(15) * len(lines) + dp(4)))
        for i, t in enumerate(lines):
            self._text(t, bx + dp(5), by + dp(15) * (len(lines) - 1 - i) + dp(10), 10, TEXT)

    def _markers(self, vis, times, X, Y, step, start):
        r = dp(6)
        pos = {}
        marks = []
        more_right = start + len(vis) < len(self.candles)      # còn nến thật bên phải cửa sổ (đang xem quá khứ)
        for ev in self.events:
            if more_right and ev.time >= times[-1] + step:
                continue
            i = bisect_right(times, ev.time) - 1
            if i < 0:
                continue
            marks.append((ev, X(start + i), Y(ev.price)))
            if ev.pos_id:
                pos.setdefault(ev.pos_id, {})[ev.kind] = (X(start + i), Y(ev.price), ev)
        # đường nối vào -> ra
        for d in pos.values():
            if "open" in d and "close" in d:
                ox, oy, _ = d["open"]
                cx, cy, ce = d["close"]
                lc = UP if ce.profit >= 0 else DOWN
                Color(lc[0], lc[1], lc[2], 0.85)
                Line(points=[ox, oy, cx, cy], width=1, dash_length=dp(3), dash_offset=dp(3))
        for ev, x, y in marks:
            if ev.kind == "open":
                col = UP if ev.side == "buy" else DOWN
                dy = -2 * r if ev.side == "buy" else 2 * r
                pts = [x - r, y + dy, x + r, y + dy, x, y]
                Color(*col)
                Triangle(points=pts)
                Color(1, 1, 1, 0.9)
                Line(points=pts, close=True, width=1)
            elif ev.kind == "close":
                Color(*(UP if ev.profit >= 0 else DOWN))
                Ellipse(pos=(x - r * 0.8, y - r * 0.8), size=(r * 1.6, r * 1.6))
                Color(1, 1, 1, 0.9)
                Line(circle=(x, y, r * 0.8), width=1)
            else:
                Color(0.75, 0.78, 0.84, 1)
                Quad(points=[x, y + r * 0.8, x + r * 0.8, y, x, y - r * 0.8, x - r * 0.8, y])
            self._hits.append((x, y, ev))

    # ------------------------------------------------------------ cử chỉ chạm
    def _zone_of(self, touch):
        if touch.y < self.y + dp(self.BM) + dp(8):
            return "taxis"
        return "paxis" if touch.x > self._x0 + self._pw else "plot"

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return False
        btn = getattr(touch, "button", None)
        if btn in ("scrollup", "scrolldown"):                 # con lăn chuột (chạy thử trên máy tính)
            self.zoom_by(0.85 if btn == "scrollup" else 1.18, touch.x)
            self.request_redraw()
            return True
        z = self._zones.get("cross")
        if z and z[0] <= touch.x <= z[0] + z[2] and z[1] <= touch.y <= z[1] + z[3] and not self._touches:
            self.set_crosshair_mode(not self.crosshair_mode)         # nút ✚ ăn chạm, không lướt/không đặt tiêu điểm
            return True
        touch.grab(self)
        if not self._touches:
            self._pinched = False
        self._stop_fling()
        self._touches[touch.uid] = {"x": touch.x, "y": touch.y, "sx": touch.x, "sy": touch.y, "t0": time.time(),
                                    "lock": None, "moved": False, "zone": self._zone_of(touch)}
        if self.draft and len(self._touches) == 1 and self._touches[touch.uid]["zone"] == "plot":
            self._touches[touch.uid]["drag"] = self._draft_hit(touch.x, touch.y)
        if (len(self._touches) == 1 and self._touches[touch.uid]["zone"] == "plot" and not self.draft and not self.crosshair_mode
                and self.on_line_drag is not None and not self.tool):
            hit = self._line_at(touch.x, touch.y)
            if hit is not None:
                self._arm_touch = (touch.uid, hit)
                self._cancel_arm()
                self._arm_ev = Clock.schedule_once(self._arm_drag, 0.4)
        if (self.crosshair_mode and len(self._touches) == 1 and self._touches[touch.uid]["zone"] == "plot" and not self.draft
                and not self._touches[touch.uid].get("drag") and touch.x <= self._x0 + self._pw):
            self._touches[touch.uid]["xhair"] = True               # một ngón = di chuyển tiêu điểm (hai ngón vẫn chụm để zoom)
            self._xhair_at(touch.x, touch.y)
        self._vel = []
        if len(self._touches) == 2:
            a, b = list(self._touches.values())
            mid0 = (a["x"] + b["x"]) / 2.0
            self._pinch = {"d0": max(dp(20), math.hypot(a["x"] - b["x"], a["y"] - b["y"])), "bars0": self.bars,
                           "g0": self._anchor_g(mid0)}
            self._pinched = True
            for t in self._touches.values():
                t["moved"] = True
                t["xhair"] = False
        return True

    def on_touch_move(self, touch):
        if touch.grab_current is not self:
            return False
        st = self._touches.get(touch.uid)
        if st is None:
            return True
        st["x"], st["y"] = touch.x, touch.y
        if len(self._touches) >= 2 and self._pinch:
            a, b = list(self._touches.values())[:2]
            d = max(dp(20), math.hypot(a["x"] - b["x"], a["y"] - b["y"]))
            mid = (a["x"] + b["x"]) / 2.0
            self._set_zoom(self._pinch["bars0"] * self._pinch["d0"] / d, self._pinch["g0"], mid)
            self.request_redraw()
            return True
        if st.get("drag_line") and self._ldrag:
            self._ldrag["price"] = self._pm.price(touch.y)
            self.request_overlay()
            return True
        if st.get("drag"):
            st["moved"] = True
            self.set_draft_price(st["drag"], self._pm.price(touch.y))
            return True
        if st.get("xhair"):
            st["moved"] = True
            self._xhair_at(touch.x, touch.y)
            return True
        dx_total, dy_total = touch.x - st["sx"], touch.y - st["sy"]
        if st["lock"] is None:
            if max(abs(dx_total), abs(dy_total)) < dp(8):
                return True
            vertical = abs(dy_total) > abs(dx_total) * 2.0 and st["zone"] not in ("taxis", "paxis") and self.scroll_parent is not None
            st["lock"] = "p" if st["zone"] == "paxis" else ("v" if vertical else "h")
            st["moved"] = True
            self._cancel_arm()                                 # đã lướt/cuộn: không còn là nhấn giữ
            st["px"], st["py"] = st["sx"], st["sy"]
        dx, dy = touch.x - st["px"], touch.y - st["py"]
        st["px"], st["py"] = touch.x, touch.y
        if st["lock"] == "p":                                  # kéo lên/xuống trên cột giá: dời khung giá (nội dung đi theo ngón tay)
            self.pshift = max(-3.0, min(3.0, self.pshift - dy / max(1.0, self._pm.h) * self.pzoom))
            self.request_redraw()
            return True
        if st["lock"] == "h":
            if st["zone"] == "taxis":
                self.zoom_by(math.exp(-dx / dp(220)), touch.x)
            else:
                if len(self.candles) - self.bars <= 0 and not st.get("warned") and self.on_toast:
                    st["warned"] = True                            # đang hiện TOÀN BỘ nến nên không còn gì để lướt: nói rõ thay vì im lặng
                    self.on_toast("Đang hiển thị toàn bộ %d nến nên không lướt được - chụm 2 ngón để phóng to, hoặc chạm 2 lần để về mặc định." % len(self.candles))
                self.pan_pixels(dx)
                self._vel.append((time.time(), dx))
                del self._vel[:-6]
            self.request_redraw()
        else:
            self._scroll_page(dy)
        return True

    def on_touch_up(self, touch):
        if touch.grab_current is not self:
            return False
        touch.ungrab(self)
        st = self._touches.pop(touch.uid, None)
        if st is None:
            return True
        self._cancel_arm()
        if st.get("drag_line") and self._ldrag:
            d, self._ldrag = self._ldrag, None
            self.request_overlay()
            if abs(d["price"] - d["orig"]) > 1e-12 and self.on_line_drag:
                self.on_line_drag(d["tag"], d["price"])
            return True
        if st.get("drag"):
            self._notify_draft(force=True)                     # thả tay: cập nhật thanh nút cuối cùng
        if len(self._touches) < 2:
            self._pinch = None
        if self._pinched:
            for t in self._touches.values():
                t["sx"], t["sy"], t["lock"] = t["x"], t["y"], None
            if not self._touches:
                self._notify()
            return True
        if st.get("drag") or st.get("xhair"):
            return True
        if not st["moved"] and time.time() - st["t0"] < 0.45 and st["zone"] == "plot" and touch.x < self._x0 + self._pw and not self.draft \
                and self._object_touch(touch):
            return True
        if not st["moved"] and time.time() - st["t0"] < 0.45 and self.draft and st["zone"] == "plot" and touch.x < self._x0 + self._pw:
            self.set_draft_price("entry", self._pm.price(touch.y))        # chạm chỗ trống = dời đường vào tới đó
            return True
        if not st["moved"] and time.time() - st["t0"] < 0.45:
            now = time.time()
            t_prev, x_prev, y_prev = self._last_tap
            if now - t_prev < 0.35 and abs(touch.x - x_prev) < dp(30) and abs(touch.y - y_prev) < dp(30):
                self._last_tap = (0.0, 0.0, 0.0)
                self.reset_view()                              # chạm 2 lần = về mặc định
            else:
                self._last_tap = (now, touch.x, touch.y)
                self._tap(touch.x, touch.y)
        elif st["lock"] == "h" and st["zone"] == "plot":
            self._start_fling()
            self._notify()
        else:
            self._notify()
        return True

    def _scroll_page(self, dy):
        sv = self.scroll_parent
        try:
            extra = sv.children[0].height - sv.height
            if extra > 1:
                sv.scroll_y = max(0.0, min(1.0, sv.scroll_y - dy / extra))
        except Exception:
            pass

    def _start_fling(self):
        now = time.time()
        recent = [(t, d) for t, d in self._vel if now - t < 0.12]
        if len(recent) >= 2:
            dt = max(0.016, recent[-1][0] - recent[0][0])
            v = sum(d for _, d in recent[1:]) / dt
            if abs(v) > dp(300):
                self._fling_v = max(-dp(4000), min(dp(4000), v))
                self._fling_ev = Clock.schedule_interval(self._fling_step, 1 / 60.0)

    def _stop_fling(self):
        self._fling_v = 0.0
        if self._fling_ev is not None:
            self._fling_ev.cancel()
            self._fling_ev = None

    def _fling_step(self, dt):
        before = self._off_f
        self.pan_pixels(self._fling_v * dt)
        self._fling_v *= 0.90 ** (dt * 60.0)
        self.redraw()
        if abs(self._fling_v) < dp(40) or self._off_f == before:
            self._stop_fling()
            return False

    def _tap(self, x, y):
        z = self._zones.get("latest")
        if z and z[0] <= x <= z[0] + z[2] and z[1] <= y <= z[1] + z[3]:
            self.go_latest()
            return
        best, bd = None, (dp(28)) ** 2
        for hx, hy, ev in self._hits:
            d = (hx - x) ** 2 + (hy - y) ** 2
            if d <= bd:
                best, bd = ev, d
        if best is not None and self.on_tap:
            self.on_tap(best)
            return
        if self.on_line_tap is not None and x <= self._x0 + self._pw:        # chạm đường lệnh/SL/TP (như MT5) -> mở hộp sửa
            near = [(abs(h[0] - y), h[1]) for h in self._hlhits if abs(h[0] - y) <= dp(14)]
            if near:
                self.on_line_tap(min(near, key=lambda t: t[0])[1])
                return
        # chạm chỗ trống: hiện/ẩn crosshair tại nến gần nhất
        n = len(self.candles)
        if n < 2 or self._bw <= 0:
            return
        g = int(self._start + (x - self._x0) / self._bw)
        if g < 0 or g >= n or x > self._x0 + self._pw:
            self.cross = None
        elif self.cross is not None and self._cross_index() == g:
            self.cross = None
        else:
            c = self.candles[g]
            self.cross = (c.time, c.close)
            self._cross_price_from_y(y)
        self.redraw()

    def _cross_price_from_y(self, y):
        """Tiêu điểm theo toạ độ y: trong cửa sổ chỉ báo -> giá trị chỉ báo tại y; trong vùng giá -> giá (theo thang đang hiển thị, kể cả khi đã dời/co giãn)."""
        for i, (py0, ph, lo, hi, tm, bm_) in enumerate(self._subgeo):
            if py0 <= y <= py0 + ph:
                self.cross_pane = (i, lo + (y - py0 - bm_) / max(1.0, ph - tm - bm_) * (hi - lo))
                return
        self.cross_pane = None
        if self.cross is not None and y >= self._pm.y0:
            self.cross = (self.cross[0], self._pm.price(y))


class LineChart(Widget):
    def __init__(self, color=BLUE, **kw):
        super().__init__(**kw)
        self.values, self.base, self.color = [], None, color
        self.bind(pos=self.redraw, size=self.redraw)

    def update(self, values, base=None):
        self.values = values or []
        self.base = base
        self.redraw()

    def redraw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*BG2)
            Rectangle(pos=self.pos, size=self.size)
            v = self.values[-300:]
            x0, y0 = self.pos
            w, h = self.size
            if len(v) < 2 or w < 20 or h < 20:
                return
            hi, lo = max(v), min(v)
            if self.base is not None:
                hi, lo = max(hi, self.base), min(lo, self.base)
            if hi <= lo:
                hi, lo = lo + 1e-9, lo - 1e-9
            m = dp(6)

            def Y(p):
                return y0 + m + (p - lo) / (hi - lo) * (h - 2 * m)
            step = w / (len(v) - 1)
            if self.base is not None:
                Color(*MUTED)
                Line(points=[x0, Y(self.base), x0 + w, Y(self.base)], width=1, dash_length=dp(4), dash_offset=dp(3))
            Color(*(UP if v[-1] >= v[0] else DOWN))
            Line(points=[c for i, p in enumerate(v) for c in (x0 + i * step, Y(p))], width=dp(1.2))


# ---------------------------------------------------------------- form tham số
def _lab(inp, x):
    f = getattr(inp, "label_of", None)
    return f(x) if f else str(x)


class ParamForm(BoxLayout):
    """Sinh form nhập tham số từ dict[str, Input]."""

    def __init__(self, inputs, values=None, section=None, **kw):
        """section = {"title": ..., "groups": [tên nhóm...], "visible": hàm(giá_trị_hiện_tại)->(tập khoá hiện | None = hiện hết), "watch": khoá theo dõi}:
        các nhóm đó được GOM vào MỘT mục gập (đóng mặc định) ở đầu form; ô nào cũng vẫn có trong `ctrl` nên đọc/lưu như thường."""
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(4), **kw)
        self.bind(minimum_height=self.setter("height"))
        self.inputs = inputs
        self.ctrl = {}
        self.rows = {}
        self._section = section
        self._sec_box = None
        self._show_all = False
        values = values or {}
        if section:
            self._sec_btn = mkbtn("", BLUE, h=MIN_TOUCH, size=13, on_release=lambda *_: self.open_api_dialog())
            self.add_widget(self._sec_btn)
            # 1.9.23: các ô API KHÔNG nằm trong trang cuộn nữa (nhiều máy bấm tam giác không xổ) mà mở trong hộp thoại riêng.
            # Hộp này không gắn vào cây giao diện - chỉ giữ giá trị; hộp thoại sửa vào đây rồi «Lưu» đọc như cũ.
            self._sec_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=0)
            self._sec_box.bind(minimum_height=self._sec_fit)
            self._sec_open = False
            self._sec_note = flabel("", 12, MUTED, size_hint_y=None, height=dp(26))
            self._sec_box.add_widget(self._sec_note)
            self._all_btn = mkbtn("Hiện tất cả sàn", PANEL2, h=40, size=12, on_release=lambda *_: self._toggle_all())
            self._sec_box.add_widget(self._all_btn)
        prev, prev_sec = object(), object()
        for key, inp in inputs.items():
            in_sec = bool(section and inp.group in section.get("groups", ()))
            if in_sec:
                if inp.group != prev_sec:
                    prev_sec = inp.group
                    self._sec_box.add_widget(flabel(inp.group, 12, AMBER, bold=True, size_hint_y=None, height=dp(30)))
                row = self._row(key, inp, values.get(key, inp.default))
                self._sec_box.add_widget(row)
                self.rows[key] = row
                continue
            if inp.group != prev:
                prev = inp.group
                if inp.group:
                    self.add_widget(flabel(inp.group, 12, AMBER, bold=True, size_hint_y=None, height=dp(30)))
            self.add_widget(self._row(key, inp, values.get(key, inp.default)))
        if section:
            watch = self.ctrl.get(section.get("watch"))
            if watch is not None and hasattr(watch, "bind"):
                watch.bind(text=lambda *_: self._apply_visibility())
            self._apply_visibility()
            ex = values.get(section.get("watch"))
            self._set_open(False)
            self._sec_title()

    # ---- mục gập «Kết nối sàn / API» ----
    def _sec_fit(self, *_):
        if self._sec_open:
            self._sec_box.height = self._content_h()

    def _content_h(self):
        return sum(float(c.height) for c in self._sec_box.children)        # spacing = 0 nên bằng tổng chiều cao các hàng đang hiện

    def _set_open(self, on):
        self._sec_open = bool(on)
        box = self._sec_box
        box.opacity = 1 if on else 0
        box.disabled = not on
        box.height = self._content_h() if on else 0
        self._sec_btn.text = ("▼ " if on else "▶ ") + self._section.get("title", "") + ("  (chạm để đóng)" if on else "  (chạm để mở ô nhập API)")

    def _sec_title(self):
        ex = self._current_values().get(self._section.get("watch"))
        self._sec_btn.text = tr("KẾT NỐI SÀN / API: bấm để NHẬP KHOÁ API (sàn đang chọn: %s)") % (ex or "-")

    _EX_NAMES = {"binance_spot": "Binance Spot", "binance_futures": "Binance Futures", "oanda": "OANDA", "capital": "Capital.com", "exness": "Exness",
                 "metaapi": "MetaApi (MT4/MT5)", "mt5gw": "Cổng MT5 tự dựng", "bridge": "Cầu nối MT4/MT5", "mt5ws": "MT5 trực tiếp (Web Terminal)", "mt5ea": "MT5 qua EA cầu nối (giả lập)", "ccxt": "Sàn khác (ccxt)", "public": "Giá công khai", "simulated": "Giả lập"}

    def open_api_dialog(self):
        """Hộp thoại nhập khoá API của sàn đang chọn: thẻ tóm tắt sàn ở đầu · các ô xếp THEO NHÓM, mỗi ô nhãn trên - ô nhập toàn chiều rộng - gợi ý nhỏ ·
        nút Hiện/ẩn khoá · «Xong» luôn ghim ở đáy. Ô nào cũng nằm sẵn trong `self.ctrl`; «Xong» chép giá trị vào đó."""
        sec = self._section
        vals = self._current_values()
        ex = vals.get(sec.get("watch"))
        try:
            vis = sec["visible"](vals)
        except Exception:                                    # noqa: BLE001
            vis = None
        keys = [k for k in self.rows if self._show_all or vis is None or k in vis]
        content = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8))
        # --- thẻ tóm tắt
        head = Panel(bg=PANEL2, orientation="vertical", size_hint_y=None, padding=[dp(10), dp(6)], spacing=dp(2))
        head.bind(minimum_height=head.setter("height"))
        head.add_widget(flabel("[b]%s[/b]" % escape_markup(self._EX_NAMES.get(ex, ex or "-")), 16, TEXT, size_hint_y=None, height=dp(26)))
        note = sec.get("note")
        head.add_widget(wlabel((note(vals) if callable(note) else "") or "", 11, MUTED))
        content.add_widget(head)
        # --- danh sách ô theo nhóm
        body = vbox(padding=dp(2), spacing=dp(8))
        editors, groups_seen = {}, set()

        def group_title(k, grp):
            if k == "live_confirm":
                return "AN TOÀN KHI GIAO DỊCH THẬT"
            if grp == "Sàn (chỉ khi live)":
                return "KHOÁ %s" % str(self._EX_NAMES.get(ex, ex or "SÀN")).upper()
            return str(grp).upper()

        for k in keys:
            inp, src = self.inputs[k], self.ctrl[k]
            gt = group_title(k, inp.group)
            if gt not in groups_seen:
                groups_seen.add(gt)
                body.add_widget(flabel("[b]%s[/b]" % escape_markup(gt), 12, AMBER, size_hint_y=None, height=dp(30)))
            if inp.kind == "bool":
                ed = Switch(active=bool(src.active), size_hint_x=None, width=dp(90), size_hint_y=None, height=dp(44))
            elif inp.kind == "choice":
                ed = Spinner(text=str(src.text), values=[str(x) for x in inp.choices], size_hint_y=None, height=dp(44), font_size=sp(14),
                             background_normal="", background_color=PANEL2, color=TEXT)
            else:
                ed = TextInput(text=str(src.text), multiline=False, write_tab=False, size_hint_y=None, height=dp(44), font_size=sp(14),
                               background_color=PANEL2, foreground_color=TEXT, cursor_color=TEXT, password=bool(inp.secret),
                               hint_text=tr("(để trống nếu không dùng)"), hint_text_color=MUTED, padding=[dp(10), dp(12), dp(10), dp(6)])
            editors[k] = ed
            card = Panel(bg=PANEL, orientation="vertical", size_hint_y=None, padding=[dp(10), dp(8)], spacing=dp(4))
            card.bind(minimum_height=card.setter("height"))
            card.add_widget(flabel("[b]%s[/b]" % escape_markup(inp.label or k), 13, TEXT, size_hint_y=None, height=dp(22)))
            if inp.help:
                card.add_widget(wlabel(inp.help, 11, MUTED))
            card.add_widget(ed)
            body.add_widget(card)
        if not keys:
            body.add_widget(wlabel("Nguồn này không cần khoá API.", 13, TEXT))
        content.add_widget(vscroll(body))
        pop = StyledPopup(title=tr("Khoá API"), content=content, size_hint=(0.96, 0.92), auto_dismiss=False)

        def done(*_):
            for k, ed in editors.items():
                c = self.ctrl[k]
                if isinstance(c, Switch):
                    c.active = bool(ed.active)
                else:
                    c.text = str(ed.text)
            pop.dismiss()

        def toggle_all(*_):
            pop.dismiss()
            self._show_all = not self._show_all
            self._apply_visibility()
            self.open_api_dialog()

        def toggle_secret(*_):
            for k, ed in editors.items():
                if getattr(self.inputs[k], "secret", False) and isinstance(ed, TextInput):
                    ed.password = not ed.password
        bar = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(8))
        bar.add_widget(mkbtn("Hiện/ẩn khoá", PANEL2, size=12, on_release=toggle_secret))
        bar.add_widget(mkbtn("Chỉ sàn đang chọn" if self._show_all else "Hiện tất cả sàn", PANEL2, size=12, on_release=toggle_all))
        content.add_widget(bar)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(8))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Xong", GREEN, size=15, on_release=done, size_hint_x=1.6))
        content.add_widget(row)
        content.add_widget(wlabel("Sau khi bấm «Xong», nhớ bấm «Lưu» ở đầu tab Cài đặt để ghi nhớ.", 11, MUTED))
        pop.open()
        return pop

    def toggle_section(self):
        self._set_open(not self._sec_open)
        try:                                                    # mở ra thì cuộn tới đầu mục để thấy ngay các ô nhập
            sv = self.parent
            while sv is not None and not hasattr(sv, "scroll_to"):
                sv = sv.parent
            if sv is not None and self._sec_open:
                from kivy.clock import Clock
                Clock.schedule_once(lambda *_: sv.scroll_to(self._sec_btn, padding=dp(10), animate=False), 0.05)
        except Exception:                                       # noqa: BLE001 - chỉ là tiện ích, không được làm hỏng bấm mở
            pass

    def _toggle_all(self):
        self._show_all = not self._show_all
        self._apply_visibility()

    def _current_values(self):
        vals = {}
        for k, c in self.ctrl.items():
            try:
                vals[k] = self._raw(c)
            except Exception:                                # noqa: BLE001
                pass
        return vals

    def _apply_visibility(self):
        sec = self._section
        if not sec:
            return
        try:
            vis = sec["visible"](self._current_values())
        except Exception:                                    # noqa: BLE001
            vis = None
        show_all = self._show_all or vis is None
        for key, row in self.rows.items():
            on = show_all or key in vis
            row.opacity = 1 if on else 0
            row.disabled = not on
            row.height = (row._full_h + dp(3)) if on else 0
        self._all_btn.text = "Chỉ hiện sàn đang chọn" if self._show_all else "Hiện tất cả sàn"
        self._sec_title()
        note = sec.get("note")
        self._sec_note.text = (note(self._current_values()) if callable(note) else "") or ""
        if self._sec_open:
            self._sec_box.height = self._content_h()

    def _row(self, key, inp, value):
        h = 70 if inp.help else 56
        row = Panel(bg=PANEL, size_hint_y=None, height=dp(h), padding=[dp(8), dp(4)], spacing=dp(8))
        title = "[b]%s[/b]" % escape_markup(inp.label or key)
        if inp.help:
            title += "\n[size=10sp][color=%s]%s[/color][/size]" % (hexc(MUTED), escape_markup(inp.help))
        g = guides.guide_for(key)
        if g:
            tl = BoxLayout(size_hint_x=0.58, spacing=dp(4))
            tl.add_widget(flabel(title, 13, TEXT))
            q = mkbtn("?", PANEL2, on_release=lambda *_, g=g: popup(g[0], g[1], size=(0.94, 0.85)), size=14, size_hint_x=None, width=dp(34))
            q.size_hint_y = None
            q.height = dp(34)
            tl.add_widget(q)
            row.add_widget(tl)
        else:
            row.add_widget(flabel(title, 13, TEXT, size_hint_x=0.58))
        if inp.kind == "bool":
            c = Switch(active=bool(value), size_hint_x=0.42)
        elif inp.kind == "choice" and len(inp.choices) > 8:
            ch = [_lab(inp, x) for x in inp.choices]
            tf = set(ch) <= set(TIMEFRAMES)
            c = PickButton(text=_lab(inp, value), values=ch, groups=TF_GROUPS if tf else None, cols=4 if tf else 2,
                           title="Khung thời gian" if tf else (inp.label or "Chọn"), size_hint_x=0.42)
        elif inp.kind == "choice":
            c = Spinner(text=_lab(inp, value), values=[_lab(inp, x) for x in inp.choices], size_hint_x=0.42,
                        font_size=sp(13), background_normal="", background_color=PANEL2, color=TEXT)
        else:
            c = TextInput(text=str(inp.display(value)), multiline=(getattr(inp, "subtype", None) == "text"), write_tab=False, size_hint_x=0.42,
                          font_size=sp(14), background_color=PANEL2, foreground_color=TEXT,
                          hint_text=SUBTYPES.get(getattr(inp, "subtype", None) or "", ""),
                          cursor_color=TEXT, hint_text_color=MUTED, password=bool(inp.secret),
                          padding=[dp(8), dp(12), dp(8), dp(6)])
        self.ctrl[key] = c
        row.add_widget(c)
        row._full_h = dp(h)
        return row

    @staticmethod
    def _raw(c):
        if isinstance(c, Switch):
            return c.active
        return c.text

    def read(self):
        """Trả về (values, errors)."""
        vals, errs = {}, []
        for key, inp in self.inputs.items():
            try:
                vals[key] = inp.coerce(self._raw(self.ctrl[key]))
            except ValueError as e:
                errs.append("%s: %s" % (inp.label or key, e))
        return vals, errs

    def set_values(self, values):
        for key, inp in self.inputs.items():
            c = self.ctrl[key]
            v = values.get(key, inp.default)
            if isinstance(c, Switch):
                c.active = bool(v)
            elif isinstance(c, (Spinner, PickButton)):
                c.text = _lab(inp, v)
            else:
                c.text = str(inp.display(v))

    def update_values(self, values):
        """Chỉ đổi các ô có trong `values` (các ô khác - kể cả ô người dùng đang gõ dở - giữ nguyên)."""
        sub = {k: v for k, v in values.items() if k in self.ctrl}
        for key, v in sub.items():
            inp, c = self.inputs[key], self.ctrl[key]
            if isinstance(c, Switch):
                c.active = bool(v)
            elif isinstance(c, (Spinner, PickButton)):
                c.text = _lab(inp, v)
            else:
                c.text = str(inp.display(v))

    def reset(self):
        self.set_values({})
