"""
BỘ MÁY LỊCH SỬ TÀI KHOẢN DÙNG CHUNG cho MỌI sàn (trả lời «sao cứ hardcode từng sàn, sao không làm chuẩn chung như MT5»).

Lõi (brokerhist.py) chỉ biết hợp đồng deal chuẩn hoá. File này là phần LẤY dữ liệu từ sàn về hợp đồng đó, và nó KHÔNG biết sàn nào cả:
mọi thứ riêng của từng sàn nằm trong MỘT HỒ SƠ DỮ LIỆU (JSON) mô tả
    · gọi endpoint nào, tham số gì (mẫu `{since:ms}` `{symbol}` `{account}`...)
    · phân trang kiểu nào (cửa sổ thời gian · con trỏ · số trang · fromId · danh sách URL trang)
    · mỗi bản ghi thô thành deal ra sao (ánh xạ trường theo đường dẫn chấm, phân loại nạp/rút/phí/giao dịch, vào/ra, dấu +/-,
      tách một lần khớp thành nhiều deal theo từng vị thế con, sàn netting không báo mã vị thế thì dựng lại)
Sàn mới = thêm MỘT hồ sơ JSON (dán ở Cài đặt → «Hồ sơ lịch sử sàn», hoặc đưa vào histprofiles.py), KHÔNG sửa mã. Hồ sơ có sẵn của OANDA / Binance Futures /
ccxt cũng chỉ là dữ liệu (pyea/histprofiles.py) đi qua đúng bộ máy này - bộ test còn chạy một sàn giả thứ ba (ZetaX) chỉ cấu hình bằng JSON.

Giới hạn nói thẳng: hồ sơ mô tả được cách ĐỌC (đường dẫn, phân trang, tên trường, phân loại, đơn vị thời gian). Giao thức xác thực/ký request vẫn thuộc về
adapter của sàn (`broker.history_call(method, path, params, body)`); sàn mới nằm trong khuôn REST của «cầu nối» (exchange = bridge) thì adapter đó có sẵn.

---------------------------------------------------------------------------------------------------------------------------------------------
HỒ SƠ (JSON)
{
  "name": "tên",                       "time_unit": "auto|s|ms|iso",      (mặc định auto: tự nhận giây/mili-giây/ISO-8601)
  "notes": ["ghi chú hiển thị cho người dùng ở mục Lịch sử"],
  "netting": {"key": ["symbol", "group"]},       (tuỳ chọn: sàn không báo mã vị thế -> dựng vị thế từ chuỗi các lần khớp theo khoá)
  "max_pages": 100, "max_calls": 400, "default_days": 7,
  "sources": [ {                         (chạy lần lượt; nguồn trước có thể «khám phá» danh sách mã cho nguồn sau)
      "id": "fills", "method": "GET", "path": "/v1/fills", "params": {"limit": 1000}, "body": {...},
      "required": true,                  (false: lỗi thì chỉ thêm ghi chú, các nguồn khác vẫn chạy)
      "needs": "fetchLedger",            (chỉ chạy nếu adapter báo có khả năng này; không có thì ghi chú và bỏ qua)
      "per_symbol": {"var": "symbol", "from": ["watch", "discovered"], "max": 40},
      "discover_symbols": "symbol",      (đường dẫn trong bản ghi thô: gom các mã để nguồn sau hỏi theo mã)
      "records": "data.items",           (đường dẫn tới danh sách bản ghi; "" = chính phản hồi)
      "paging": {"type": "none|window|cursor|page|from_id|page_urls", ...},
      "emit": [ {                        (một bản ghi thô -> 0..n deal)
          "when": {"field": "type", "eq": "ORDER_FILL"},    each: "tradesClosed" (đường dẫn con: mỗi phần tử là một deal),
          "kind": "trade|balance|credit|other" hoặc {"path": "type", "map": {...}},
          "entry": "IN|OUT|INOUT" hoặc {"out_if": {...}, "else": "IN"},
          "fallback": true,              (chỉ chạy khi các emit trước không sinh deal nào từ bản ghi này)
          "map": {"id": ..., "time": ..., "symbol": ..., "side": ..., "qty": ..., "price": ..., "profit": ..., "commission": ..., "swap": ...,
                  "fee": ..., "order_id": ..., "position_id": ..., "comment": ..., "group": ...} } ] } ]
}
Giá trị của `map` (đặc tả trường): "đường.dẫn" · "^đường.dẫn" (từ bản ghi CHA khi dùng each) · [danh sách đường dẫn thay thế] ·
  {"path"|"paths"|"const", "abs", "neg", "neg_if": {điều kiện}, "scale", "lower", "upper", "sign": ["buy","sell"], "map": {"A": "buy"},
   "default", "prefix", "suffix" (dùng {i} = thứ tự con), "once": true (chỉ gắn vào deal đầu tiên của bản ghi - vd hoa hồng của cả lần khớp),
   "only_if": {điều kiện} (không thoả thì bỏ qua), "unit": "ms"}
Điều kiện: {"field": "đường dẫn" hoặc [..], "eq|ne|in|nin|gt|ge|lt|le|regex|contains|exists": giá trị} · danh sách = VÀ · {"any": [...]} · {"not": {...}}.
Quy ước dấu của deal: profit/commission/swap/fee là ẢNH HƯỞNG LÊN SỐ DƯ (phí là số ÂM; sàn báo phí dạng số dương thì dùng "neg": true).
Mẫu tham số: {since} {until} {until_now} {now} {t0} {t1} (giờ, kèm định dạng :s :ms :iso :iso9 :f3) · {symbol} · {cursor} · {page} · {account} và các khoá do adapter cung cấp.
Phân trang: window {days, start, end, unit, limit, limit_param, time} · cursor {param, next, limit, limit_param} · page {param, start, limit, limit_param} ·
  from_id {param, id, limit, limit_param, plus_one} · page_urls {urls, max} (phản hồi đầu liệt kê URL các trang).
"""
import json
import math
import re
import calendar
import time
from urllib.parse import urlsplit

from . import brokerhist


class HistoryError(Exception):
    """Hồ sơ sai hoặc không chạy được (lỗi gọi sàn là lỗi của adapter - được ném nguyên)."""


_MISSING = object()
PAGING_TYPES = ("none", "window", "cursor", "page", "from_id", "page_urls")
DEAL_TEXT = ("id", "symbol", "side", "position_id", "order_id", "comment", "group")
DEAL_NUM = ("price", "qty", "profit", "commission", "swap", "fee")
MAP_KEYS = DEAL_TEXT + DEAL_NUM + ("time",)
PROFILE_KEYS = {"name", "time_unit", "notes", "netting", "max_pages", "max_calls", "default_days", "sources"}
SOURCE_KEYS = {"query_post", "id", "method", "path", "params", "body", "paging", "records", "emit", "per_symbol", "discover_symbols", "required", "needs", "note_fail", "time_unit"}
EMIT_KEYS = {"when", "each", "kind", "entry", "map", "fallback", "time_unit"}
PAGING_KEYS = {"type", "days", "start", "end", "unit", "limit", "limit_param", "time", "param", "next", "id", "plus_one", "urls", "max", "start_value"}
SPEC_KEYS = {"path", "paths", "const", "abs", "neg", "neg_if", "scale", "map", "lower", "upper", "default", "prefix", "suffix", "sign", "once", "only_if", "unit"}
COND_KEYS = {"field", "eq", "ne", "in", "nin", "exists", "gt", "ge", "lt", "le", "regex", "contains", "any", "all", "not"}
SYMBOL_ORIGINS = ("watch", "discovered")
MAX_SYMBOLS = 40
WARN = "CHÚ Ý: "


# ---------------------------------------------------------------------------------------------- tiện ích
def _num(v):
    if v is None or isinstance(v, bool):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _path(rec, path):
    """Đường dẫn chấm (`a.b.0.c`) -> giá trị hoặc _MISSING."""
    cur = rec
    for part in str(path).split("."):
        if isinstance(cur, dict):
            if part not in cur:
                return _MISSING
            cur = cur[part]
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return _MISSING
        else:
            return _MISSING
    return cur


def _get(rec, parent, path):
    if path == ".":
        return rec
    if isinstance(path, str) and path.startswith("^"):
        return _path(parent if parent is not None else rec, path[1:])
    return _path(rec, path)


def _present(v):
    return v is not _MISSING and v is not None and v != ""


def _first(rec, parent, paths):
    for p in paths if isinstance(paths, (list, tuple)) else [paths]:
        v = _get(rec, parent, p)
        if _present(v):
            return v
    return None


_ISO = re.compile(r"^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(\.\d+)?\s*(Z|[+-]\d\d:?\d\d)?$")


def parse_time(v, unit="auto"):
    """Số (giây/ms/µs/ns) hoặc chuỗi ISO-8601 -> epoch UTC giây (0.0 nếu không đọc được)."""
    if v is None or v is _MISSING or isinstance(v, bool):
        return 0.0
    x = _num(v)
    if x is not None and not (isinstance(v, str) and _ISO.match(v.strip())):
        u = str(unit or "auto").lower()
        if u == "s":
            return x
        if u == "ms":
            return x / 1e3
        if u == "us":
            return x / 1e6
        if u == "ns":
            return x / 1e9
        a = abs(x)
        return x / 1e9 if a > 1e17 else x / 1e6 if a > 1e14 else x / 1e3 if a > 1e11 else x
    m = _ISO.match(str(v).strip())
    if not m:
        return 0.0
    base = calendar.timegm(tuple(int(g) for g in m.groups()[:6]))
    frac = float(m.group(7)) if m.group(7) else 0.0
    off = 0
    z = m.group(8)
    if z and z != "Z":
        sign = 1 if z[0] == "+" else -1
        digits = z[1:].replace(":", "")
        off = sign * (int(digits[:2]) * 3600 + int(digits[2:]) * 60)
    return base + frac - off


def _fmt_time(t, fmt):
    t = float(t)
    if fmt == "ms":
        return int(round(t * 1000))
    if fmt == "s":
        return int(t)
    if fmt == "f3":
        return "%.3f" % t
    if fmt == "iso":
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t))
    if fmt == "iso9":
        return time.strftime("%Y-%m-%dT%H:%M:%S.000000000Z", time.gmtime(t))
    return int(t)


_TPL = re.compile(r"\{(\w+)(?::(\w+))?\}")
TIME_VARS = ("since", "until", "until_now", "now", "t0", "t1")


def _var(vars_, name, fmt, typed):
    if name not in vars_ or vars_[name] is None:
        return ""
    v = vars_[name]
    if name in TIME_VARS:
        out = _fmt_time(v, fmt or "s")
        return out if typed else str(out)
    return v if typed else str(v)


def render(value, vars_):
    """Thay mẫu `{tên}` / `{tên:định_dạng}` trong chuỗi, danh sách, từ điển. Chuỗi gồm đúng MỘT mẫu thì giữ kiểu (số nguyên cho :ms/:s)."""
    if isinstance(value, dict):
        return {k: render(v, vars_) for k, v in value.items()}
    if isinstance(value, list):
        return [render(v, vars_) for v in value]
    if isinstance(value, str):
        m = _TPL.fullmatch(value)
        if m:
            return _var(vars_, m.group(1), m.group(2), True)
        return _TPL.sub(lambda mm: str(_var(vars_, mm.group(1), mm.group(2), False)), value)
    return value


# ---------------------------------------------------------------------------------------------- điều kiện / đặc tả trường
def _eq(v, x):
    if isinstance(x, bool):
        return str(v).strip().lower() == str(x).lower()
    if isinstance(x, (int, float)):
        vv = _num(v)
        return (0.0 if vv is None else vv) == float(x)
    return str("" if v is None else v).strip().lower() == str(x).strip().lower()


def _cond(c, rec, parent, ctx):
    if c is None or c is True:
        return True
    if c is False:
        return False
    if isinstance(c, list):
        return all(_cond(x, rec, parent, ctx) for x in c)
    if not isinstance(c, dict):
        return False
    if "any" in c:
        return any(_cond(x, rec, parent, ctx) for x in c["any"])
    if "all" in c:
        return all(_cond(x, rec, parent, ctx) for x in c["all"])
    if "not" in c:
        return not _cond(c["not"], rec, parent, ctx)
    v = _first(rec, parent, c.get("field", "."))
    if "exists" in c:
        return _present(v) == bool(c["exists"])
    for op in ("eq", "ne", "in", "nin", "gt", "ge", "lt", "le", "regex", "contains"):
        if op not in c:
            continue
        x = render(c[op], ctx)
        if op == "eq":
            return _eq(v, x)
        if op == "ne":
            return not _eq(v, x)
        if op == "in":
            return any(_eq(v, y) for y in (x if isinstance(x, list) else [x]))
        if op == "nin":
            return not any(_eq(v, y) for y in (x if isinstance(x, list) else [x]))
        if op == "regex":
            return re.search(str(x), str("" if v is None else v)) is not None
        if op == "contains":
            return str(x).lower() in str("" if v is None else v).lower()
        vv, xx = _num(v), _num(x)
        if vv is None or xx is None:
            return False
        return {"gt": vv > xx, "ge": vv >= xx, "lt": vv < xx, "le": vv <= xx}[op]
    return True


def _value(spec, rec, parent, ctx, i=0, once=None, field=""):
    """Đặc tả trường -> giá trị thô (hoặc None)."""
    if spec is None:
        return None
    if isinstance(spec, (list, tuple)):
        return _first(rec, parent, spec)
    if isinstance(spec, (int, float, bool)):
        return spec
    if isinstance(spec, str):
        v = _get(rec, parent, spec)
        return v if _present(v) else None
    if not isinstance(spec, dict):
        return None
    if spec.get("once") and once is not None:
        if field in once:
            return None
    if "only_if" in spec and not _cond(spec["only_if"], rec, parent, ctx):
        return None
    if "const" in spec:
        v = spec["const"]
    else:
        v = _first(rec, parent, spec.get("paths") or spec.get("path") or ".")
    if "sign" in spec:
        x = _num(v)
        pos, neg = (list(spec["sign"]) + ["", ""])[:2]
        v = pos if (x or 0) > 0 else neg if (x or 0) < 0 else None
    if "map" in spec and v is not None:
        key = str(v).strip().lower()
        table = {str(k).strip().lower(): val for k, val in spec["map"].items()}
        v = table.get(key, table.get("*", spec.get("default")))
    if v is not None and any(k in spec for k in ("abs", "neg", "neg_if", "scale")):
        x = _num(v)
        if x is not None:
            if spec.get("abs"):
                x = abs(x)
            if spec.get("scale") is not None:
                x *= float(spec["scale"])
            if spec.get("neg") or ("neg_if" in spec and _cond(spec["neg_if"], rec, parent, ctx)):
                x = -x
            v = x
    if isinstance(v, str):
        if spec.get("lower"):
            v = v.lower()
        elif spec.get("upper"):
            v = v.upper()
    if v is not None and (spec.get("prefix") or spec.get("suffix")):
        v = "%s%s%s" % (str(spec.get("prefix", "")).replace("{i}", str(i)), v, str(spec.get("suffix", "")).replace("{i}", str(i)))
    if v is None:
        v = spec.get("default")
    if spec.get("once") and once is not None and v is not None:
        once.add(field)
    return v


def _norm_side(s):
    t = str("" if s is None else s).strip().lower()
    return "buy" if t in ("buy", "b", "bid", "long") else "sell" if t in ("sell", "s", "ask", "short") else ""


def _kind_of(spec, rec, parent, ctx, once):
    if spec is None:
        return "trade"
    if isinstance(spec, str) and spec in brokerhist.KINDS:
        return spec
    raw = _value(spec, rec, parent, ctx, 0, once, "kind") if not isinstance(spec, str) else spec
    if raw in brokerhist.KINDS:
        return raw
    return brokerhist.classify(raw)


def _entry_of(spec, rec, parent, ctx, once):
    if spec is None:
        return ""
    if isinstance(spec, str):
        return spec.upper()
    if isinstance(spec, dict) and ("out_if" in spec or "in_if" in spec):
        if "out_if" in spec and _cond(spec["out_if"], rec, parent, ctx):
            return "OUT"
        if "in_if" in spec:
            return "IN" if _cond(spec["in_if"], rec, parent, ctx) else str(spec.get("else", "")).upper()
        return str(spec.get("else", "IN")).upper()
    return str(_value(spec, rec, parent, ctx, 0, once, "entry") or "").upper()


# ---------------------------------------------------------------------------------------------- bản ghi thô -> deal
def _children(emit, rec):
    each = emit.get("each")
    if not each:
        return [rec]
    v = _path(rec, each)
    if v is _MISSING or v is None:
        return []
    if isinstance(v, list):
        return [x for x in v if isinstance(x, dict)]
    return [v] if isinstance(v, dict) else []


def _build(emit, ch, parent, ctx, i, once, tunit, drops):
    m = emit.get("map") or {}
    d = {}
    for f in DEAL_TEXT:
        d[f] = str(_value(m.get(f), ch, parent, ctx, i, once, f) or "")
    d["side"] = _norm_side(d["side"])
    tspec = m.get("time")
    unit = (tspec.get("unit") if isinstance(tspec, dict) else None) or emit.get("time_unit") or tunit
    d["time"] = parse_time(_value(tspec, ch, parent, ctx, i, once, "time"), unit)
    for f in DEAL_NUM:
        x = _num(_value(m.get(f), ch, parent, ctx, i, once, f))
        d[f] = 0.0 if x is None else x
    d["qty"] = abs(d["qty"])
    d["kind"] = _kind_of(emit.get("kind"), ch, parent, ctx, once)
    d["entry"] = _entry_of(emit.get("entry"), ch, parent, ctx, once) if d["kind"] == "trade" else ""
    if d["time"] <= 0:
        drops["no_time"] += 1
        return None
    if d["kind"] == "trade" and (not d["symbol"] or not d["side"] or d["qty"] <= 0):
        drops["bad_trade"] += 1
        return None
    return d


def _emit_record(src, rec, ctx, tunit, drops):
    out, once, produced = [], set(), False
    for em in src.get("emit") or [{}]:
        if em.get("fallback") and produced:
            continue
        if not _cond(em.get("when"), rec, None, ctx):
            continue
        for i, ch in enumerate(_children(em, rec)):
            d = _build(em, ch, rec, ctx, i, once, tunit, drops)
            if d:
                out.append(d)
                produced = True
    return out


# ---------------------------------------------------------------------------------------------- dựng vị thế cho sàn netting
def apply_netting(deals, spec):
    """Sàn không báo mã vị thế (netting một chiều): dựng position_id + vào/ra từ chuỗi lần khớp theo khoá (mặc định theo mã). Quy tắc:
    số lượng ròng về 0 là ĐÓNG vị thế; lần khớp đảo chiều được TÁCH thành phần đóng + phần mở vị thế mới; lần khớp có gợi ý «ra» (vd có lãi/lỗ đã thực
    hiện) khi chưa biết vị thế nào đang mở thì thuộc vị thế mở TRƯỚC kỳ (giá mở hiện «?»)."""
    keyf = list((spec or {}).get("key") or ["symbol"])
    state, out = {}, []
    for d in sorted(deals, key=lambda x: (x["time"], x["id"])):
        if d["kind"] != "trade" or d["position_id"]:
            out.append(d)
            continue
        key = "|".join(str(d.get(k, "")) for k in keyf if k != "group" or d.get("group"))
        st = state.setdefault(key, {"net": 0.0, "n": 0, "pid": ""})
        s = d["qty"] if d["side"] == "buy" else -d["qty"]
        eps = 1e-9 * max(1.0, d["qty"])
        net = st["net"]
        if abs(net) <= eps:
            if d["entry"] == "OUT":                                   # đóng thứ đã mở trước kỳ: không biết giá mở, số lượng ròng vẫn chưa biết
                out.append(dict(d, position_id="%s#0" % key, entry="OUT"))
                continue
            st["n"] += 1
            st["pid"] = "%s#%d" % (key, st["n"])
            st["net"] = s
            out.append(dict(d, position_id=st["pid"], entry="IN"))
        elif net * s > 0:
            st["net"] = net + s
            out.append(dict(d, position_id=st["pid"], entry="IN"))
        elif abs(s) <= abs(net) + eps:
            st["net"] = 0.0 if abs(abs(net) - abs(s)) <= eps else net + s
            out.append(dict(d, position_id=st["pid"], entry="OUT"))
        else:                                                         # đảo chiều: đóng hết phần cũ + mở phần dư
            closing, rest = abs(net), d["qty"] - abs(net)
            frac = closing / d["qty"]
            out.append(dict(d, id=d["id"] + "a", qty=closing, position_id=st["pid"], entry="OUT", commission=d["commission"] * frac, fee=d["fee"] * frac))
            st["n"] += 1
            st["pid"] = "%s#%d" % (key, st["n"])
            st["net"] = s + net
            out.append(dict(d, id=d["id"] + "b", qty=rest, position_id=st["pid"], entry="IN", profit=0.0, swap=0.0,
                            commission=d["commission"] * (1 - frac), fee=d["fee"] * (1 - frac)))
    return out


# ---------------------------------------------------------------------------------------------- gọi sàn + phân trang
class _Run:
    def __init__(self, call, ctx, profile):
        self.call, self.ctx, self.p = call, dict(ctx or {}), profile
        self.calls, self.notes, self.discovered = 0, [], []
        self.max_calls = int(profile.get("max_calls") or 400)
        self.max_pages = int(profile.get("max_pages") or 100)
        self.capped = False

    def note(self, text, warn=True):
        """Ghi chú hiển thị dưới mục Lịch sử. Mặc định là CẢNH BÁO (tiền tố «CHÚ Ý: » - giao diện tô vàng): số liệu có thể thiếu."""
        text = (WARN + text) if (warn and text) else text
        if text and text not in self.notes:
            self.notes.append(text)

    def request(self, src, path, params, body):
        if self.calls >= self.max_calls:
            self.capped = True
            return None
        self.calls += 1
        return self.call(str(src.get("method") or "GET").upper(), path, params or None, body)


def _extract(src, resp):
    path = src.get("records", "")
    d = resp if path in ("", None) else _path(resp, path)
    if d is _MISSING or d is None:
        return []
    if isinstance(d, list):
        return [x for x in d if isinstance(x, dict)]
    return [d] if isinstance(d, dict) else []


def _rel_url(u):
    p = urlsplit(str(u))
    return p.path + ("?" + p.query if p.query else "")


def _fetch_pages(run, src, vars_, seen):
    """Một lần «chạy» nguồn với các biến cho trước (một mã / không mã): trả danh sách bản ghi thô mới (đã loại trùng)."""
    pg = src.get("paging") or {}
    typ = pg.get("type") or "none"
    path = render(src["path"], vars_)
    params = render(src.get("params") or {}, vars_)
    body = render(src.get("body"), vars_) if src.get("body") is not None else None
    out, pages = [], 0
    limit = pg.get("limit")
    if limit and pg.get("limit_param"):
        params[pg["limit_param"]] = limit

    def take(resp):
        new = 0
        for r in _extract(src, resp):
            k = json.dumps(r, sort_keys=True, default=str)
            if k not in seen:
                seen.add(k)
                out.append(r)
                new += 1
        return new

    def hit_cap():
        run.note("Đã dừng ở %d trang/%d lần gọi (giới hạn an toàn) - lịch sử có thể chưa đủ; chọn kỳ ngắn hơn." % (run.max_pages, run.max_calls))

    if typ == "none":
        r = run.request(src, path, params, body)
        if r is not None:
            take(r)
        return out
    if typ == "page_urls":
        r = run.request(src, path, params, body)
        if r is None:
            return out
        take(r)
        urls = _path(r, pg.get("urls", "pages"))
        for u in (urls if isinstance(urls, list) else [])[:int(pg.get("max") or run.max_pages)]:
            rr = run.request(src, _rel_url(u), None, None)
            if rr is None:
                break
            take(rr)
        if isinstance(urls, list) and len(urls) > int(pg.get("max") or run.max_pages):
            hit_cap()
        return out
    if typ == "window":
        unit = pg.get("unit") or "ms"
        since, end = vars_["since"], vars_["until"]
        days = pg.get("days")
        wins, t0 = [], since
        if days:
            span = float(days) * 86400.0
            while t0 < end and len(wins) < run.max_pages:
                t1 = min(t0 + span - 1.0, end)
                wins.append((t0, t1))
                t0 = t1 + 0.001
            if t0 < end:
                hit_cap()
        else:
            wins = [(since, end)]
        for w0, w1 in wins:
            cur = w0
            while pages < run.max_pages * 4:
                p = dict(params)
                if pg.get("start"):
                    p[pg["start"]] = _fmt_time(cur, unit)
                if pg.get("end"):
                    p[pg["end"]] = _fmt_time(w1, unit)
                r = run.request(src, path, p, body)
                pages += 1
                if r is None:
                    return out
                recs = _extract(src, r)
                take(r)
                if not (limit and len(recs) >= int(limit) and pg.get("time")):
                    break
                last = max(parse_time(_first(x, None, pg["time"]), pg.get("unit") or "auto") for x in recs)
                cur = last if last > cur else cur + 0.001                                    # trang đầy: lật tiếp từ mốc cuối (loại trùng ở `seen`)
                if cur > w1:
                    break
        return out
    if typ in ("cursor", "page", "from_id"):
        cursor, page = None, int(pg.get("start_value", 1))
        while pages < run.max_pages:
            p = dict(params)
            if typ == "cursor" and cursor:
                p[pg.get("param", "cursor")] = cursor
            elif typ == "page":
                p[pg.get("param", "page")] = page
            elif typ == "from_id" and cursor is not None:
                p[pg.get("param", "fromId")] = cursor
            r = run.request(src, path, p, body)
            pages += 1
            if r is None:
                return out
            recs = _extract(src, r)
            new = take(r)
            if typ == "cursor":
                nxt = _path(r, pg.get("next", "next"))
                if nxt in (_MISSING, None, "", 0) or not recs or not new:
                    return out
                cursor = nxt
            elif typ == "page":
                if not recs or (limit and len(recs) < int(limit)) or not new:
                    return out
                page += 1
            else:
                if not recs or (limit and len(recs) < int(limit)) or not new:
                    return out
                lid = _first(recs[-1], None, pg.get("id", "id"))
                if lid is None:
                    return out
                lx = _num(lid)
                cursor = lid if lx is None else int(lx) + (1 if pg.get("plus_one") else 0)
        hit_cap()
    return out


def _symbols_for(run, src):
    ps = src.get("per_symbol") or {}
    syms = []
    for origin in ps.get("from") or ["watch", "discovered"]:
        pool = run.ctx.get("symbols") if origin == "watch" else run.discovered
        for s in pool or []:
            if s and s not in syms:
                syms.append(s)
    cap = int(ps.get("max") or MAX_SYMBOLS)
    if len(syms) > cap:
        run.note("Sàn hỏi lịch sử theo từng mã: chỉ đọc %d mã đầu trong %d mã tìm thấy." % (cap, len(syms)))
        syms = syms[:cap]
    return syms


def _collect(run, src, since, end):
    vars_ = dict(run.ctx)
    now = time.time()
    vars_.update(since=since, until=end, until_now=min(end, now), now=now, t0=since, t1=end)
    seen, recs = set(), []
    if src.get("per_symbol"):
        syms = _symbols_for(run, src)
        if not syms:
            run.note("Nguồn «%s» sàn bắt buộc hỏi theo từng mã nhưng chưa biết mã nào (chưa có lệnh trong kỳ và Danh sách theo dõi trống) - bỏ qua." % src.get("id", "?"))
            return []
        var = (src["per_symbol"] or {}).get("var", "symbol")
        for sy in syms:
            v = dict(vars_)
            v[var] = sy
            for r in _fetch_pages(run, src, v, seen):
                recs.append(r)
    else:
        recs = _fetch_pages(run, src, vars_, seen)
    return recs


# ---------------------------------------------------------------------------------------------- hồ sơ: kiểm tra + nạp
def _check_cond(c, where, errs):
    if c is None or isinstance(c, bool):
        return
    if isinstance(c, list):
        for x in c:
            _check_cond(x, where, errs)
        return
    if not isinstance(c, dict):
        errs.append("%s: điều kiện phải là đối tượng hoặc danh sách" % where)
        return
    for k in c:
        if k not in COND_KEYS:
            errs.append("%s: khoá điều kiện lạ «%s» (có: %s)" % (where, k, ", ".join(sorted(COND_KEYS))))
    for k in ("any", "all"):
        if k in c:
            for x in c[k] if isinstance(c[k], list) else []:
                _check_cond(x, where, errs)
    if "not" in c:
        _check_cond(c["not"], where, errs)
    if not any(k in c for k in ("any", "all", "not")) and "field" not in c:
        errs.append("%s: điều kiện thiếu «field»" % where)


def _check_spec(spec, where, errs):
    if spec is None or isinstance(spec, (str, int, float, bool)):
        return
    if isinstance(spec, list):
        if not all(isinstance(x, str) for x in spec):
            errs.append("%s: danh sách đường dẫn thay thế chỉ gồm chuỗi" % where)
        return
    if not isinstance(spec, dict):
        errs.append("%s: đặc tả trường phải là chuỗi, danh sách hoặc đối tượng" % where)
        return
    for k in spec:
        if k not in SPEC_KEYS:
            errs.append("%s: khoá lạ «%s» (có: %s)" % (where, k, ", ".join(sorted(SPEC_KEYS))))
    if not any(k in spec for k in ("path", "paths", "const")):
        errs.append("%s: cần «path», «paths» hoặc «const»" % where)
    for k in ("only_if", "neg_if"):
        if k in spec:
            _check_cond(spec[k], where + "." + k, errs)
    if "sign" in spec and not (isinstance(spec["sign"], list) and len(spec["sign"]) == 2):
        errs.append("%s: «sign» phải là danh sách 2 phần tử [khi dương, khi âm]" % where)
    if "map" in spec and not isinstance(spec["map"], dict):
        errs.append("%s: «map» phải là đối tượng" % where)


def validate_profile(p):
    """Trả danh sách lỗi (rỗng = hợp lệ). Bắt lỗi gõ tên khoá, thiếu đường dẫn, kiểu phân trang lạ..."""
    errs = []
    if not isinstance(p, dict):
        return ["hồ sơ phải là một đối tượng JSON"]
    for k in p:
        if k not in PROFILE_KEYS:
            errs.append("khoá lạ «%s» ở cấp hồ sơ (có: %s)" % (k, ", ".join(sorted(PROFILE_KEYS))))
    srcs = p.get("sources")
    if not isinstance(srcs, list) or not srcs:
        errs.append("thiếu «sources» (danh sách nguồn dữ liệu, ít nhất một)")
        return errs
    if "notes" in p and not (isinstance(p["notes"], list) and all(isinstance(x, str) for x in p["notes"])):
        errs.append("«notes» phải là danh sách chuỗi")
    if "netting" in p and not (isinstance(p["netting"], dict) and isinstance(p["netting"].get("key", ["symbol"]), list)):
        errs.append("«netting» phải là {\"key\": [\"symbol\", ...]}")
    ids = set()
    for i, s in enumerate(srcs):
        w = "nguồn #%d" % (i + 1)
        if not isinstance(s, dict):
            errs.append("%s: phải là đối tượng" % w)
            continue
        w = "nguồn «%s»" % (s.get("id") or i + 1)
        for k in s:
            if k not in SOURCE_KEYS:
                errs.append("%s: khoá lạ «%s» (có: %s)" % (w, k, ", ".join(sorted(SOURCE_KEYS))))
        if not s.get("id"):
            errs.append("%s: thiếu «id»" % w)
        elif s["id"] in ids:
            errs.append("%s: «id» bị trùng" % w)
        ids.add(s.get("id"))
        if not isinstance(s.get("path"), str) or not s.get("path"):
            errs.append("%s: thiếu «path»" % w)
        mth = str(s.get("method") or "GET").upper()
        if mth not in ("GET", "POST", "CCXT"):
            errs.append("%s: «method» chỉ nhận GET/POST/CCXT" % w)
        elif mth == "POST" and not s.get("query_post"):
            errs.append("%s: hồ sơ lịch sử chỉ ĐỌC - POST bị chặn (không thể đặt/sửa/huỷ lệnh). Sàn bắt buộc hỏi lịch sử bằng POST thì thêm \"query_post\": true" % w)
        if isinstance(s.get("path"), str) and s["path"] and mth != "CCXT" and not s["path"].startswith("/"):
            errs.append("%s: «path» phải bắt đầu bằng «/» (đường dẫn trên máy chủ của sàn, không phải địa chỉ đầy đủ)" % w)
        if isinstance(s.get("path"), str) and "://" in s["path"]:
            errs.append("%s: «path» không được chứa địa chỉ đầy đủ" % w)
        pg = s.get("paging") or {}
        if not isinstance(pg, dict):
            errs.append("%s: «paging» phải là đối tượng" % w)
            pg = {}
        for k in pg:
            if k not in PAGING_KEYS:
                errs.append("%s: khoá phân trang lạ «%s»" % (w, k))
        typ = pg.get("type") or "none"
        if typ not in PAGING_TYPES:
            errs.append("%s: kiểu phân trang «%s» không có (chỉ: %s)" % (w, typ, ", ".join(PAGING_TYPES)))
        if typ == "window" and not (pg.get("start") or "{" in json.dumps(s.get("params") or {})):
            errs.append("%s: phân trang window cần «start» (tên tham số thời điểm bắt đầu) hoặc mẫu {since}/{t0} trong params" % w)
        if typ == "window" and pg.get("limit") and not pg.get("time"):
            errs.append("%s: window có «limit» thì cần «time» (đường dẫn thời gian của bản ghi để lật trang đầy)" % w)
        if typ == "cursor" and not pg.get("next"):
            errs.append("%s: phân trang cursor cần «next» (đường dẫn con trỏ trang kế trong phản hồi)" % w)
        if typ == "page_urls" and not pg.get("urls"):
            errs.append("%s: phân trang page_urls cần «urls»" % w)
        ps = s.get("per_symbol")
        if ps is not None:
            if not isinstance(ps, dict):
                errs.append("%s: «per_symbol» phải là đối tượng" % w)
            else:
                for o in ps.get("from") or []:
                    if o not in SYMBOL_ORIGINS:
                        errs.append("%s: per_symbol.from «%s» không có (chỉ: %s)" % (w, o, ", ".join(SYMBOL_ORIGINS)))
        emits = s.get("emit") or [{}]
        if not isinstance(emits, list):
            errs.append("%s: «emit» phải là danh sách" % w)
            continue
        if not s.get("emit"):
            errs.append("%s: thiếu «emit» (cách biến bản ghi thành deal)" % w)
        for j, e in enumerate(emits):
            we = "%s, emit #%d" % (w, j + 1)
            if not isinstance(e, dict):
                errs.append("%s: phải là đối tượng" % we)
                continue
            for k in e:
                if k not in EMIT_KEYS:
                    errs.append("%s: khoá lạ «%s» (có: %s)" % (we, k, ", ".join(sorted(EMIT_KEYS))))
            _check_cond(e.get("when"), we + ".when", errs)
            m = e.get("map")
            if not isinstance(m, dict):
                errs.append("%s: thiếu «map»" % we)
                continue
            for k, sp in m.items():
                if k not in MAP_KEYS:
                    errs.append("%s: trường «%s» không thuộc hợp đồng deal (%s)" % (we, k, ", ".join(MAP_KEYS)))
                _check_spec(sp, "%s.map.%s" % (we, k), errs)
            for k in ("id", "time"):
                if k not in m:
                    errs.append("%s: map thiếu «%s»" % (we, k))
            kd = e.get("kind")
            if isinstance(kd, str) and kd not in brokerhist.KINDS:
                errs.append("%s: kind «%s» không hợp lệ (chỉ: %s)" % (we, kd, ", ".join(brokerhist.KINDS)))
            elif isinstance(kd, dict):
                _check_spec(kd, we + ".kind", errs)
            en = e.get("entry")
            if isinstance(en, str) and en.upper() not in ("", "IN", "OUT", "INOUT", "OUT_BY"):
                errs.append("%s: entry «%s» không hợp lệ" % (we, en))
            elif isinstance(en, dict):
                if "out_if" in en or "in_if" in en:
                    for k in ("out_if", "in_if"):
                        if k in en:
                            _check_cond(en[k], we + ".entry." + k, errs)
                else:
                    _check_spec(en, we + ".entry", errs)
    return errs


def parse_profiles(text):
    """Chuỗi JSON (hoặc dict) `{tên_sàn: hồ_sơ}` do người dùng dán -> (dict hợp lệ, [lỗi]). Hồ sơ sai bị bỏ kèm lý do; không ném."""
    errs = []
    if text in (None, "", {}):
        return {}, errs
    if isinstance(text, str):
        try:
            raw = json.loads(text)
        except ValueError as e:
            return {}, ["Hồ sơ lịch sử: JSON không hợp lệ (%s)" % e]
    else:
        raw = text
    if not isinstance(raw, dict):
        return {}, ["Hồ sơ lịch sử: phải là đối tượng {tên_sàn: hồ_sơ}"]
    out = {}
    for scope, prof in raw.items():
        bad = validate_profile(prof)
        if bad:
            errs.extend("«%s»: %s" % (scope, b) for b in bad)
        else:
            out[str(scope)] = prof
    return out, errs


def resolve(profiles_text, scope, builtin=None, embedded=None):
    """Chọn hồ sơ: người dùng dán cho đúng sàn (`scope` = exchange trong Cài đặt) > hồ sơ nhúng trong cấu hình cầu nối > hồ sơ có sẵn của app.
    Trả (hồ sơ | None, nguồn: 'user'|'embedded'|'builtin'|'', [ghi chú lỗi])."""
    from . import histprofiles
    mine, errs = parse_profiles(profiles_text)
    notes = [WARN + "Hồ sơ lịch sử bạn dán bị lỗi nên BỎ QUA: " + e for e in errs] if errs else []
    if scope in mine:
        return mine[scope], "user", notes
    if isinstance(embedded, dict):
        bad = validate_profile(embedded)
        if not bad:
            return embedded, "embedded", notes
        notes += [WARN + "Hồ sơ lịch sử nhúng trong cầu nối bị lỗi nên BỎ QUA: " + b for b in bad]
    b = histprofiles.BUILTIN.get(builtin or scope)
    if b is not None:
        return b, "builtin", notes
    return None, "", notes


ORIGIN_VN = {"user": "do bạn dán ở Cài đặt", "embedded": "nhúng trong cấu hình cầu nối", "builtin": "có sẵn trong app"}


# ---------------------------------------------------------------------------------------------- chạy hồ sơ
def _has(caps, need):
    if caps is None:
        return True                                   # adapter không khai khả năng -> cứ thử
    if isinstance(caps, dict):
        return bool(caps.get(need))
    return need in caps


def fetch_deals(profile, call, since, until=None, ctx=None):
    """Chạy hồ sơ. `call(method, path, params, body) -> JSON` do adapter của sàn cấp (lo xác thực/ký).
    Trả {"deals": [deal chuẩn hoá, cũ -> mới], "notes": [...], "sources": {id: {records, deals, calls}}}."""
    bad = validate_profile(profile)
    if bad:
        raise HistoryError("Hồ sơ lịch sử không hợp lệ: " + "; ".join(bad[:5]))
    now = time.time()
    since = float(since or 0.0)
    if since <= 0:
        since = now - float(profile.get("default_days") or 7) * 86400.0
    end = float(until) if until else now + 5.0
    run = _Run(call, ctx, profile)
    tunit = profile.get("time_unit") or "auto"
    drops = {"no_time": 0, "bad_trade": 0}
    deals, stats = [], {}
    caps = run.ctx.get("capabilities")
    for src in profile["sources"]:
        sid = src["id"]
        need = src.get("needs")
        if need and not _has(caps, need):
            run.note("Sàn/adapter này không báo hỗ trợ «%s» nên nguồn «%s» được bỏ qua - số liệu liên quan có thể thiếu." % (need, sid))
            continue
        c0 = run.calls
        try:
            recs = _collect(run, src, since, end)
        except Exception as e:                                           # noqa: BLE001 - nguồn tuỳ chọn lỗi không được làm hỏng cả lịch sử
            if src.get("required", True):
                raise
            run.note("Không đọc được nguồn «%s»: %s%s" % (sid, str(e)[:160], (" - " + src["note_fail"]) if src.get("note_fail") else ""))
            stats[sid] = {"records": 0, "deals": 0, "calls": run.calls - c0}
            continue
        if src.get("discover_symbols"):
            for r in recs:
                v = _first(r, None, src["discover_symbols"])
                if v and str(v) not in run.discovered:
                    run.discovered.append(str(v))
        n0 = len(deals)
        sup = set()
        for r in recs:
            for d in _emit_record(src, r, run.ctx, src.get("time_unit") or tunit, drops):
                key = (sid, d["id"], d["kind"], d["entry"])
                if d["id"] and key in sup:
                    continue
                sup.add(key)
                if not d["id"]:
                    d["id"] = "%s:%d" % (sid, len(deals))
                deals.append(d)
        stats[sid] = {"records": len(recs), "deals": len(deals) - n0, "calls": run.calls - c0}
    if drops["no_time"]:
        run.note("Bỏ %d bản ghi không đọc được thời gian." % drops["no_time"])
    if drops["bad_trade"]:
        run.note("Bỏ %d bản ghi giao dịch thiếu mã/chiều/khối lượng." % drops["bad_trade"])
    if run.capped and "dừng ở" not in " ".join(run.notes):
        run.note("Đã dừng ở %d lần gọi (giới hạn an toàn) - lịch sử có thể chưa đủ; chọn kỳ ngắn hơn." % run.max_calls)
    if profile.get("netting"):
        deals = apply_netting(deals, profile["netting"])
    lo, hi = since - 1e-6, end + 1e-6
    deals = [brokerhist.norm_deal({k: v for k, v in d.items() if k != "group"}) for d in deals if lo <= d["time"] <= hi]
    deals.sort(key=lambda d: (d["time"], d["id"]))
    notes = list(profile.get("notes") or []) + run.notes
    return {"deals": deals, "notes": notes, "sources": stats}


def run_for_broker(broker, builtin, since, until=None, embedded=None):
    """Dùng trong `broker.account_history`: chọn hồ sơ (người dùng > nhúng > có sẵn), chạy qua `broker.history_call`, đặt `broker.history_notes`.
    Không có hồ sơ nào -> NotImplementedError (giao diện hiện lời nhắn rõ, không bịa số)."""
    scope = getattr(broker, "field_scope", None) or builtin
    prof, origin, notes = resolve(getattr(broker, "history_profiles", None), scope, builtin, embedded)
    broker.history_notes = list(notes)
    if prof is None:
        raise NotImplementedError("Chưa có hồ sơ lịch sử cho sàn «%s». Dán một hồ sơ ở Cài đặt → «Hồ sơ lịch sử sàn» (JSON, xem pyea/histengine.py) - không cần sửa mã." % scope)
    ctx = {}
    hc = getattr(broker, "history_ctx", None)
    if callable(hc):
        ctx = hc() or {}
    res = fetch_deals(prof, broker.history_call, since, until, ctx)
    broker.history_notes = ["Hồ sơ lịch sử «%s» (%s)." % (prof.get("name") or scope, ORIGIN_VN.get(origin, origin))] + list(notes) + res["notes"]
    broker.history_stats = res["sources"]
    return res["deals"]
