"""Kiểm tra hệ thống (nút 'Kiểm tra hệ thống'): giúp phát hiện sớm lỗi trên thiết bị thật
và dán báo cáo lại cho người hỗ trợ. Không phụ thuộc Kivy."""
import os
import platform
import sys
import time

from . import android_native as an
from .ipc import ServiceClient

OK, WARN, FAIL = "OK", "CHÚ Ý", "LỖI"


def run_checks(data_dir, settings, store=None, network=True):
    res = []

    def add(name, status, detail=""):
        res.append({"name": name, "status": status, "detail": str(detail)})

    add("Python", OK, "%s | %s" % (sys.version.split()[0], platform.platform()))
    if an.IS_ANDROID:
        info = an.device_info()
        add("Thiết bị Android", OK if info else WARN,
            "%(model)s | Android %(android)s (API %(sdk)s) | ABI %(abis)s" % info if info else "không đọc được (pyjnius?)")
    else:
        add("Nền tảng", WARN, "Không phải Android: dịch vụ nền / thông báo / chọn file hệ thống không khả dụng")

    try:
        p = os.path.join(data_dir, ".write_test")
        with open(p, "w") as f:
            f.write("x")
        os.remove(p)
        add("Thư mục dữ liệu ghi được", OK, data_dir)
    except OSError as e:
        add("Thư mục dữ liệu ghi được", FAIL, "%s: %s" % (data_dir, e))

    try:
        import certifi
        add("Chứng chỉ HTTPS (certifi)", OK if os.path.exists(certifi.where()) else FAIL, certifi.where())
    except Exception as e:
        add("Chứng chỉ HTTPS (certifi)", FAIL, e)

    assets = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "DejaVuSans.ttf")
    add("Font tiếng Việt", OK if os.path.exists(assets) else FAIL, assets)

    try:                                                     # giờ dựng form Cài đặt THẬT trên máy này (ui.SettingsTab ghi vào boot.log)
        import re
        from . import bootlog
        bp = bootlog.path()
        if bp and os.path.exists(bp):
            with open(bp, "rb") as f:
                f.seek(0, 2)
                f.seek(max(0, f.tell() - 30000))
                last = [x for x in f.read().decode("utf-8", "replace").splitlines() if "cài đặt: dựng" in x]
            if last:
                m = re.search(r"trong ([0-9.]+)s, khung hình dài nhất ([0-9.]+)s", last[-1])
                secs, worst = (float(m.group(1)), float(m.group(2))) if m else (0.0, 0.0)
                add("Hiệu năng: dựng form Cài đặt", WARN if (secs > 10 or worst > 2) else OK, last[-1].split(" ", 1)[-1])
    except Exception:                                        # noqa: BLE001
        pass

    if store is not None:
        n = len(store.list_bots())
        add("Bot đã nạp", OK if n else WARN, "%d file" % n)
        agents = store.load_agents()
        en = [a for a in agents if a.get("enabled", True)]
        add("AI đã cấu hình", OK if en else WARN, "%d AI (%d đang bật)" % (len(agents), len(en)))
        if os.path.exists(store.crash_path):
            add("Nhật ký crash của app", WARN, "có file %s" % store.crash_path)
        sc = os.path.join(data_dir, "service_crash.log")
        if os.path.exists(sc):
            add("Nhật ký crash của dịch vụ nền", WARN, "có file %s" % sc)

    if an.IS_ANDROID:
        try:
            if an.service_class_exists(an.SERVICE_NAME):
                add("Dịch vụ nền (foreground service)", OK, "đã được đóng gói trong APK")
            else:
                add("Dịch vụ nền (foreground service)", FAIL, "không tìm thấy lớp %s.Service%s trong APK (kể cả qua ClassLoader của app)" % (an.package_name(), an.SERVICE_NAME))
        except Exception as e:
            add("Dịch vụ nền (foreground service)", FAIL, "không kiểm được lớp dịch vụ: %s" % e)
        add("Loại khỏi tối ưu pin", OK if an.is_ignoring_battery_optimizations() else WARN,
            "đã loại" if an.is_ignoring_battery_optimizations() else "CHƯA - Android có thể giết bot nền; bấm 'Tối ưu pin'")
    client = ServiceClient(data_dir)
    alive = client.host_alive()
    add("Dịch vụ nền đang chạy", OK if alive else WARN, "có" if alive else "không (bình thường nếu bot chưa chạy)")

    ex = settings.get("exchange", "simulated")
    if ex == "public":
        add("Nguồn thị trường", OK if network else WARN, "giá thật công khai (Binance/Yahoo), không cần khoá API" + ("" if network else " - cần mạng"))
    elif ex == "simulated":
        add("Nguồn thị trường", OK, "giả lập offline (không cần mạng) - %d tài sản mẫu" % len(__import__("pyea.feeds", fromlist=["SIM_UNIVERSE"]).SIM_UNIVERSE))
    elif not network:
        add("Kiểm tra sàn (%s)" % ex, WARN, "bỏ qua kiểm tra mạng")
    else:
        # MỘT bộ kiểm tra chung cho mọi sàn (pyea/selfcheck.py): chỉ đọc, đi qua đúng giao diện mà vỏ dùng. Muốn thử lệnh thật (demo):
        #   python -m pyea.selfcheck --exchange <sàn> --settings file.json --trade --yes
        from . import selfcheck
        smap = {selfcheck.OK: OK, selfcheck.WARN: WARN, selfcheck.FAIL: FAIL, selfcheck.SKIP: OK}
        try:
            rows, _, _ = selfcheck.run(settings, trade=False, tfs=("1m", "1h"), deep=False)
        except Exception as e:                                           # noqa: BLE001 - chẩn đoán không được làm app sập
            add("Kiểm tra sàn (%s)" % ex, FAIL, "%s: %s" % (type(e).__name__, str(e)[:200]))
        else:
            for r in rows:
                add("Sàn: " + r["name"], smap.get(r["status"], WARN), (r["detail"] + (" [bỏ qua]" if r["status"] == selfcheck.SKIP else ""))[:300])
    return res


def format_report(results):
    mark = {OK: "[OK]   ", WARN: "[CHÚ Ý]", FAIL: "[LỖI]  "}
    lines = ["PyEA Runner - báo cáo kiểm tra %s" % time.strftime("%Y-%m-%d %H:%M:%S")]
    for r in results:
        lines.append("%s %s: %s" % (mark.get(r["status"], r["status"]), r["name"], r["detail"]))
    return "\n".join(lines)
