"""Nhãn lệnh GỌN cho MT5 (comment tối đa 31 ký tự) - mã hoá «bot nào / logic nào» và nhận diện NGUỒN gốc của một lệnh.

Giới hạn của MT5: comment chỉ 31 ký tự, và sàn có thể cắt/ghi đè nó. Cách khắc phục:
  - Nhãn lưu trong comment CHỈ là mã ngắn:  «pyea» + MÃ-BOT(4 ký tự base36, băm từ id bot) + «:» + NHÃN-LOGIC(≤13 ký tự)  = ≤22 ký tự,
    còn 9 ký tự «~xxxxxxxx» dành cho nonce duy nhất của từng lệnh (mt5ws._new_tag) -> tổng ≤31.
  - Tên đầy đủ của bot/logic KHÔNG nằm trong comment mà nằm trong SỔ APP (vị thế ảo có `owner`, sự kiện có lý do/chi tiết). Từ mã 4 ký tự, app tra
    ngược ra bot bằng cách băm lại danh sách bot đang có (`match_owner`) - không cần lưu thêm file.
  - Nguồn gốc (`classify`): 'app' (comment bắt đầu «pyea»), 'ea' (magic ≠ 0 hoặc comment lạ - EA/bot khác), 'manual' (comment rỗng và magic 0 -
    đặt tay trên MT5), 'sl_tp' (sàn tự đóng: comment dạng «[sl ...]»/«[tp ...]»). Đây là SUY LUẬN từ dữ liệu sàn trả về, không phải sự thật tuyệt đối.
"""
import hashlib
import re

PREFIX = "pyea"
CODE_LEN = 4
BASE_LIMIT = 22                 # chừa 9 ký tự cho «~» + 8 hex nonce trong comment 31 ký tự của MT5
LABEL_LIMIT = BASE_LIMIT - len(PREFIX) - CODE_LEN - 1
_B36 = "0123456789abcdefghijklmnopqrstuvwxyz"
_SAFE = re.compile(r"[^0-9A-Za-z_.\-]+")
_RE = re.compile(r"^pyea(?:([0-9a-z]{%d}):([^~]*))?(?:~([0-9a-f]{8}))?$" % CODE_LEN)

ORIGIN_NAMES = {"app": "App/Bot này", "manual": "Đặt tay (MT5)", "ea": "EA/bot khác", "sl_tp": "Sàn tự đóng (SL/TP/stop-out)", "unknown": "Không rõ"}


def owner_code(owner):
    """Mã 4 ký tự base36 ổn định từ id bot (băm SHA-1). Va chạm hiếm (36^4 ≈ 1,7 triệu) và chỉ dùng để gợi ý bot, vị thế vẫn khớp theo ticket."""
    n = int.from_bytes(hashlib.sha1(str(owner or "manual").encode("utf-8")).digest()[:5], "big")
    out = ""
    for _ in range(CODE_LEN):
        n, r = divmod(n, 36)
        out += _B36[r]
    return out


def clean_label(label):
    """Nhãn logic gọn: chỉ chữ/số/_.-, bỏ dấu tiếng Việt sang ASCII gần đúng, cắt cho vừa."""
    import unicodedata
    s = unicodedata.normalize("NFKD", str(label or "")).replace("đ", "d").replace("Đ", "D")
    s = "".join(c for c in s if not unicodedata.combining(c))
    return _SAFE.sub("-", s).strip("-")[:LABEL_LIMIT]


def compose(owner=None, label=""):
    """Phần cơ sở của comment (≤22 ký tự). Không có owner -> chỉ «pyea» (tương thích bản cũ)."""
    if not owner:
        return PREFIX
    base = "%s%s:%s" % (PREFIX, owner_code(owner), clean_label(label))
    return base[:BASE_LIMIT]


def decode(comment):
    """-> {'app': bool, 'code': mã bot|'', 'label': nhãn|'', 'nonce': 8 hex|''} ; không phải nhãn của app -> app=False."""
    c = str(comment or "")
    m = _RE.match(c)
    if not m:
        return {"app": c.startswith(PREFIX), "code": "", "label": "", "nonce": ""} if c.startswith(PREFIX) else {"app": False, "code": "", "label": "", "nonce": ""}
    return {"app": True, "code": m.group(1) or "", "label": m.group(2) or "", "nonce": m.group(3) or ""}


def match_owner(code, owners):
    """Tìm id bot (trong danh sách `owners` đang có) có mã khớp; không có/không duy nhất -> None."""
    hit = [o for o in owners if owner_code(o) == code]
    return hit[0] if len(hit) == 1 else None


def classify(comment, magic=0, reason=None):
    """Nguồn gốc lệnh theo comment + magic (+ mã lý do mở của MT5 nếu có: 3 = do EA/chương trình). Xem chú thích đầu file về độ tin cậy."""
    c = str(comment or "").strip()
    if c.startswith(PREFIX):
        return "app"
    if re.match(r"^\[(sl|tp|so)\b", c, re.I):
        return "sl_tp"
    if magic:
        return "ea"
    if not c:
        return "ea" if reason == 3 else "manual"
    return "ea"


def origin_name(origin):
    return ORIGIN_NAMES.get(origin, ORIGIN_NAMES["unknown"])
