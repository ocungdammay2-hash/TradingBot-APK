"""Lịch kinh tế trong phiên giao dịch (phần VỎ): nạp lịch nền, báo trước tin quan trọng, và (tuỳ chọn) chặn lệnh MỚI của bot/AI quanh giờ ra tin.

Nguồn lịch do NGƯỜI DÙNG chọn (`calendar_source`: URL hoặc file; xem econcal.py) - vỏ không gắn cứng nhà cung cấp.

Nguyên tắc an toàn:
  * Lịch hỏng/không có mạng/chưa cấu hình => KHÔNG chặn gì (chặn lệnh vì lịch hỏng còn nguy hiểm hơn là có tin). Lỗi chỉ hiện ở `calendar.error`.
  * Chỉ chặn lệnh MỚI (mở vị thế, đặt lệnh chờ) của bot/AI. Đóng vị thế/huỷ lệnh/đóng hết luôn được phép (kể cả SL/TP, kill switch, stop-out).
    Lệnh bạn bấm tay không bị chặn (bạn đang nhìn thấy tin). Lệnh chờ đã đặt từ trước và khớp trong lúc có tin không bị chặn.
  * Không áp dụng trong backtest (phiên đồng bộ): lịch hiện tại không có nghĩa gì với dữ liệu quá khứ.
  * Việc nạp lịch chạy ở luồng riêng - vòng poll không bao giờ chờ mạng.

Không import Kivy."""
import os
import threading
import time

from . import prefs
from .econcal import IMPACT_NAME, MIN_IMPACT, EconCalendar, symbol_currencies
from .sdk import Ret


class CalendarMixin:
    def _cal_init(self):
        self.cal = None
        self._cal_src = None
        self._cal_alerted = {}                    # khoá sự kiện -> giờ đã báo (không báo lặp)
        self._cal_t = 0.0
        self._cal_thread = None

    # ---- cài đặt ----
    def _cal_on(self):
        return bool(self.settings.get("calendar_enabled")) and bool(str(self.settings.get("calendar_source") or "").strip()) and not self.sync

    def _cal_min_impact(self, key="calendar_min_impact"):
        return MIN_IMPACT.get(str(self.settings.get(key) or "high").lower(), 3)

    def _cal_get(self):
        """Đối tượng lịch (tạo lại khi người dùng đổi nguồn). None khi tắt."""
        if not self._cal_on():
            return None
        src = str(self.settings.get("calendar_source")).strip()
        if self.cal is None or self._cal_src != src:
            cache = os.path.join(self.data_dir, "calendar_cache.json") if getattr(self, "data_dir", None) else None
            self.cal = EconCalendar(src, cache_path=cache, ttl=max(300.0, float(self.settings.get("calendar_refresh_h") or 6.0) * 3600.0))
            self._cal_src = src
            self._cal_alerted = {}
        return self.cal

    def _cal_symbols(self):
        with self.lock:
            syms = set(self.needed_symbols()) if self.account is not None else set()
            syms |= {p.symbol for p in (self.account.positions.values() if self.account is not None else [])}
        return sorted(syms)

    def _cal_currencies(self, symbols):
        cur = set()
        ov = self.settings.get("calendar_currencies") or ""
        for s in symbols:
            cur |= symbol_currencies(s, ov)
        return cur

    # ---- vòng poll ----
    def _check_calendar(self):
        try:
            self._check_calendar_inner()
        except Exception as e:                                       # noqa: BLE001 - lịch không được làm sập phiên
            self.log("Lịch kinh tế lỗi: %s" % e, "WARN")

    def _check_calendar_inner(self):
        cal = self._cal_get()
        if cal is None:
            return
        now = time.time()
        if now - self._cal_t < 20.0:
            return
        self._cal_t = now
        if cal.stale() and not (self._cal_thread and self._cal_thread.is_alive()):
            self._cal_thread = threading.Thread(target=self._cal_refresh, args=(cal,), name="pyea-calendar", daemon=True)
            self._cal_thread.start()
        lead = float(self.settings.get("calendar_alert_min") or 0.0) * 60.0
        if lead <= 0:
            return
        symbols = self._cal_symbols()
        cur = self._cal_currencies(symbols)
        if not cur:
            return
        for e in cal.upcoming(now, lead, self._cal_min_impact(), cur):
            if e.key() in self._cal_alerted or e.ts < now:
                continue
            self._cal_alerted[e.key()] = now
            mins = max(0, int(round((e.ts - now) / 60.0)))
            blocked = bool(self.settings.get("news_block")) and e.impact >= self._cal_min_impact("news_block_min_impact")
            self.alarm("Tin sắp ra: %s %s" % (e.currency, e.title),
                       "%s lúc %s (còn %d phút), mức %s%s%s. Ảnh hưởng: %s.%s" % (
                           e.currency, prefs.fmt_time("%H:%M", e.ts), mins, IMPACT_NAME.get(e.impact, "?"),
                           (" · dự báo %s" % e.forecast) if e.forecast else "", (" · trước đó %s" % e.previous) if e.previous else "",
                           ", ".join(s for s in symbols if (symbol_currencies(s, self.settings.get("calendar_currencies") or "") & {e.currency}) or e.currency == "ALL")[:60] or "-",
                           " Bot/AI bị chặn lệnh mới quanh giờ này." if blocked else ""), critical=False)
        for k in [k for k, t in self._cal_alerted.items() if now - t > 86400.0]:
            self._cal_alerted.pop(k, None)

    def _cal_refresh(self, cal):
        ok, err = cal.refresh()
        if ok:
            self.log("Lịch kinh tế: đã nạp %d sự kiện" % len(cal.events))
        elif err and time.time() - getattr(self, "_cal_warn_t", 0.0) > 600.0:
            self._cal_warn_t = time.time()
            self.log("Lịch kinh tế: không nạp được (%s) - giữ lịch cũ, KHÔNG chặn lệnh vì lịch" % err, "WARN")

    # ---- chặn lệnh mới ----
    def _news_block(self, symbol):
        """Tin đang chặn lệnh mới của `symbol` (EconEvent) hoặc None. Không bao giờ ném lỗi."""
        try:
            if not self.settings.get("news_block"):
                return None
            cal = self._cal_get()
            if cal is None or not cal.events:
                return None
            return cal.blocking(symbol, float(self.settings.get("news_block_before_min") or 0.0) * 60.0,
                                float(self.settings.get("news_block_after_min") or 0.0) * 60.0,
                                self._cal_min_impact("news_block_min_impact"), self.settings.get("calendar_currencies") or "")
        except Exception:                                            # noqa: BLE001
            return None

    def _cal_gate(self, symbol, closing, owner):
        """Dùng trong `_gate`: (Ret.NEWS_BLOCK, thông báo) hoặc None."""
        if closing or owner == "manual" or self.sync:
            return None
        e = self._news_block(symbol)
        if e is None:
            return None
        mins = (e.ts - time.time()) / 60.0
        when = ("sẽ ra sau %.0f phút" % mins) if mins > 0 else ("đã ra %.0f phút trước" % -mins)
        return Ret.NEWS_BLOCK, "Đang chặn lệnh mới quanh tin %s %s (mức %s, %s lúc %s) - thử lại sau khi hết cửa sổ tin" % (
            e.currency, e.title, IMPACT_NAME.get(e.impact, "?"), when, prefs.fmt_time("%H:%M", e.ts))

    # ---- truy vấn cho giao diện / bot ----
    def calendar_upcoming(self, hours=24.0, min_impact=None, symbol=None):
        """Các tin sắp tới (dict) - cho giao diện và api.calendar(). symbol=None: theo mọi mã app đang theo dõi."""
        cal = self._cal_get()
        if cal is None:
            return []
        mi = MIN_IMPACT.get(str(min_impact).lower(), min_impact if isinstance(min_impact, int) else self._cal_min_impact())
        cur = symbol_currencies(symbol, self.settings.get("calendar_currencies") or "") if symbol else self._cal_currencies(self._cal_symbols())
        return [e.as_dict() for e in cal.upcoming(time.time(), float(hours) * 3600.0, mi, cur)]

    def calendar_state(self):
        on = self._cal_on()
        cal = self.cal if on else None
        out = {"enabled": on, "source": str(self.settings.get("calendar_source") or ""), "events": len(cal.events) if cal else 0,
               "loaded_at": cal.loaded_at if cal else 0.0, "error": cal.error if cal else "", "next": [], "blocking": None,
               "news_block": bool(self.settings.get("news_block"))}
        if on and cal is not None:
            out["next"] = self.calendar_upcoming(24.0)[:6]
            for s in self._cal_symbols():
                e = self._news_block(s)
                if e is not None:
                    out["blocking"] = dict(e.as_dict(), symbol=s)
                    break
        return out
