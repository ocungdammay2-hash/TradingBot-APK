"""
TRẠNG THÁI TÀI KHOẢN DO SÀN BÁO (giống khung «Giao dịch» của MT5: Số dư · Tài sản · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ).

Số liệu cùng tên trong sổ riêng của app (engine.Account) là số TỰ TÍNH (lãi/lỗ = Δgiá × khối lượng, ký quỹ = Σ khối lượng × giá / đòn bẩy; không có contract
size, quy đổi tiền tệ, quy tắc ký quỹ riêng từng mã) nên với sàn kiểu MT chúng KHÔNG khớp số của sàn. Hợp đồng chung để lấy số của sàn:

    broker.account_state() -> dict   (tuỳ chọn; vỏ gọi ở luồng poll, mỗi `account_state_interval` giây)

Broker trả dict theo tên gốc của sàn; `normalize()` quy về MỘT dạng (bí danh tên trường bên dưới - không viết riêng cho sàn nào):
    balance · equity · margin · free_margin · margin_level (%) · profit (lãi/lỗ thả nổi) · credit · leverage · currency
Trường sàn không báo thì để None (không bịa); margin_level/free_margin/profit chỉ được TÍNH từ các trường đã có theo định nghĩa của MT5:
    margin_level = equity / margin × 100 (None khi chưa có ký quỹ) · free_margin = equity - margin · profit = equity - balance - credit
"""
import math

from . import fieldmap

# Tên trường của sàn KHÔNG nằm ở đây nữa mà ở bảng bí danh chung pyea/fieldmap.py (SCHEMAS["account"], SCHEMAS["position"]) + ghi đè của người dùng:
# sàn mới đặt tên khác thì chỉnh trong Cài đặt («Ánh xạ trường tuỳ chỉnh»), không sửa mã.
NUMERIC = tuple(k for k in fieldmap.SCHEMAS["account"] if k != "currency")


def _num(v):
    return fieldmap.num(v)


def normalize(raw, scope=None):
    """dict thô của sàn -> {balance, equity, margin, free_margin, margin_level, profit, credit, leverage, currency} (None = sàn không báo).
    Trả None nếu không có cả số dư lẫn tài sản (dữ liệu vô dụng). `scope` = tên sàn (để áp ghi đè tay của đúng sàn đó)."""
    if not isinstance(raw, dict):
        return None
    fieldmap.remember(scope, "account", raw)
    out = {k: _num(fieldmap.pick("account", raw, k, scope)) for k in NUMERIC}
    out["currency"] = str(fieldmap.pick("account", raw, "currency", scope) or "")
    if out["balance"] is None and out["equity"] is None:
        return None
    eq, mg = out["equity"], out["margin"]
    if out["free_margin"] is None and eq is not None and mg is not None:
        out["free_margin"] = eq - mg
    if out["margin_level"] is None and eq is not None and mg is not None and mg > 1e-12:
        out["margin_level"] = eq / mg * 100.0
    if out["profit"] is None and eq is not None and out["balance"] is not None:
        out["profit"] = eq - out["balance"] - (out["credit"] or 0.0)
    return out


# ---------------------------------------------------------------------------------------------- lãi/lỗ TỪNG VỊ THẾ do sàn báo
def normalize_position_stats(rows, scope=None):
    """Danh sách vị thế (mỗi dòng có `id`/`ref` + các trường lãi/lỗ của sàn) -> {ticket: {profit, swap, commission, price}}.
    `profit` = lãi/lỗ của phần đang mở KHÔNG gồm swap/hoa hồng (đúng cột «Lợi nhuận» của MT5); swap/hoa hồng riêng. Trường nào sàn không báo thì VẮNG mặt
    (không bịa 0); vị thế không có trường nào thì bỏ qua."""
    out = {}
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        ref = str(fieldmap.pick("position", r, "id", scope) or "")
        if not ref:
            continue
        fieldmap.remember(scope, "position", r)
        st = {}
        for k in ("profit", "swap", "commission", "price"):
            v = _num(fieldmap.pick("position", r, k, scope))
            if v is not None:
                st[k] = v
        if st:
            out[ref] = st
    return out
