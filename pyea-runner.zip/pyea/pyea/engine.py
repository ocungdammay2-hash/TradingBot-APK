"""
Engine kiểu MT5: MỘT phiên giao dịch (TradingSession) có tài khoản chung, nhiều tài sản và nhiều bot.

  TradingSession : tài khoản chung (paper hoặc live), vòng lấy giá cho mọi mã cần thiết (Market Watch +
                   bot + vị thế + biểu đồ), kiểm tra SL/TP/ngưỡng lỗ, đặt/đóng/sửa lệnh (thủ công hoặc từ bot),
                   ghi sự kiện kèm lý do, lưu/khôi phục sổ lệnh.
  BotRunner      : 1 "bot gắn vào tài sản" (như EA gắn vào chart): chạy bot cho đúng 1 mã + khung giờ, nhận
                   tick từ session. Dùng đứng riêng (BotRunner(path, settings, params)) sẽ tự tạo session riêng.
Mọi vào/ra lệnh sinh TradeEvent kèm LÝ DO để hiện khi chạm vào chấm trên biểu đồ.
"""
import csv
import json
import math
import os
import queue
import threading
import time
import traceback
from collections import OrderedDict, deque
from dataclasses import fields, replace

from .broker import BrokerError, make_broker
from .feeds import FeedError, make_feed, tf_bucket, tf_next, tf_seconds
from .loader import BotLoadError, build_params, collect_inputs, load_bot_class, params_report
from .datacache import HistoryCache, find_gaps, load_history
from . import dnd, logrot, redact, schema
from .kvstore import KVStore
from .orders import OrderMixin
from .reconcile import ReconcileMixin
from .trail import TrailMixin
from .protect import ProtectMixin
from .linkwatch import LinkMixin
from .calwatch import CalendarMixin
from .sync import ExchangeSyncMixin
from .sdk import (API_VERSION, Candle, OrderResult, PendingOrder, Position, Ret, Trade, TradeEvent, TradeUpdate, jsonable)
from .shell import AlertBook, CallbackStats, trade_stats

STATUS_TEXT = {
    "idle": "Chưa chạy", "starting": "Đang khởi động...", "running": "Đang chạy",
    "stopping": "Đang dừng...", "stopped": "Đã dừng", "error": "Lỗi",
}
SRC_LABEL = {"sl": "Stop Loss", "tp": "Take Profit", "manual": "Thủ công", "risk": "Ngưỡng lỗ", "stop": "Dừng bot",
             "bot": "Bot", "ai": "AI", "kill": "Kill switch", "stopout": "Stop-out"}


class _Halt(Exception):
    """Dừng có chủ đích (error=True nếu là lỗi)."""

    def __init__(self, msg, error=False, reason="error"):
        super().__init__(msg)
        self.error = error
        self.reason = reason


def _mk(cls, d):
    names = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in d.items() if k in names})


def _atomic_write(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def parse_watchlist(text):
    out = []
    for x in str(text or "").replace(";", ",").replace("\n", ",").replace(" ", ",").split(","):
        x = x.strip().upper()
        if x and x not in out:
            out.append(x)
    return out


# --------------------------------------------------------------------------
# Sổ lệnh / tài khoản
# --------------------------------------------------------------------------
class Account:
    def __init__(self, balance, commission_pct=0.0, leverage=1.0):
        self.start_balance = float(balance)
        self.balance = float(balance)
        self.fee_rate = max(0.0, float(commission_pct)) / 100.0
        self.fee_per_unit = 0.0               # phí cố định / đơn vị khối lượng (lot) mỗi chiều (mô hình phí kiểu broker MT)
        self.fee_min = 0.0                    # phí tối thiểu mỗi lần khớp
        self.swap_total = 0.0                 # tổng swap/funding đã trả (dương = trả)
        self.leverage = max(1.0, float(leverage))
        self.positions = OrderedDict()
        self.pending = OrderedDict()          # lệnh chờ (PendingOrder) - id chung bộ đếm với vị thế
        self.trades = []
        self._next_id = 1
        self.peak_equity = self.balance
        self.max_drawdown = 0.0

    def floating(self):
        return sum(p.profit for p in self.positions.values())

    def equity(self):
        return self.balance + self.floating()

    def margin_used(self):
        return sum(p.volume * p.open_price for p in self.positions.values()) / self.leverage

    def reserved_margin(self):
        """Ký quỹ GIỮ CHỖ cho lệnh chờ (như MT5): nếu không giữ, đặt 10 lệnh chờ rồi khớp hết sẽ âm vốn."""
        return sum(o.volume * o.price for o in self.pending.values()) / self.leverage

    def free_margin(self):
        return self.equity() - self.margin_used() - self.reserved_margin()

    def margin_level(self):
        """equity / ký quỹ đang dùng × 100; None nếu chưa có vị thế."""
        used = self.margin_used()
        return (self.equity() / used * 100.0) if used > 1e-12 else None

    def can_open(self, volume, price):
        return self.margin_used() + self.reserved_margin() + volume * price / self.leverage <= self.equity() + 1e-9

    def add_pending(self, order):
        order.id = self._next_id
        self._next_id += 1
        self.pending[order.id] = order
        return order

    def fee_for(self, volume, price):
        """Phí MỘT lần khớp: max(phí tối thiểu, % notional + phí/đơn vị). Mặc định (hai tham số mới = 0) y hệt trước đây."""
        return max(self.fee_min, volume * price * self.fee_rate + volume * self.fee_per_unit)

    def accrue_swap(self, pos, amount):
        """Ghi swap/funding (dương = TRẢ, âm = nhận) vào vị thế; lãi/lỗ thả nổi và lệnh đóng sau đó đã gồm khoản này."""
        pos.swap += amount
        pos.profit -= amount
        self.swap_total += amount

    @staticmethod
    def _gross(pos, price):
        if pos.side == "buy":
            return (price - pos.open_price) * pos.volume
        return (pos.open_price - price) * pos.volume

    def mark(self, tick):
        """Cập nhật lãi/lỗ thả nổi của các vị thế CÙNG MÃ với tick."""
        for p in self.positions.values():
            if p.symbol == tick.symbol:
                price = tick.bid if p.side == "buy" else tick.ask
                p.profit = self._gross(p, price) - p.fee - p.swap
        eq = self.equity()
        self.peak_equity = max(self.peak_equity, eq)
        if self.peak_equity > 0:
            self.max_drawdown = max(self.max_drawdown, (self.peak_equity - eq) / self.peak_equity * 100.0)

    def open(self, symbol, side, volume, price, sl, tp, comment, t, owner="", pos_id=None, ref=""):
        if pos_id is None:
            pos_id = self._next_id
            self._next_id += 1
        else:
            self._next_id = max(self._next_id, int(pos_id) + 1)
        pos = Position(id=pos_id, symbol=symbol, side=side, volume=volume,
                       open_price=price, open_time=t, sl=sl, tp=tp, comment=comment,
                       fee=self.fee_for(volume, price), owner=owner, ref=str(ref or ""))
        pos.profit = -pos.fee
        self.positions[pos.id] = pos
        return pos

    def reduce(self, pos_id, volume, price, t, reason):
        """Đóng MỘT PHẦN vị thế: chốt lãi/lỗ phần đó, vị thế còn lại giữ nguyên id/giá vào."""
        pos = self.positions[pos_id]
        if volume >= pos.volume - 1e-12:
            return self.close(pos_id, price, t, reason)
        frac = volume / pos.volume
        fee_part = pos.fee * frac
        swap_part = pos.swap * frac
        close_fee = self.fee_for(volume, price)
        gross = ((price - pos.open_price) if pos.side == "buy" else (pos.open_price - price)) * volume
        profit = gross - fee_part - close_fee - swap_part
        self.balance += profit
        pos.volume -= volume
        pos.fee -= fee_part
        pos.swap -= swap_part
        tr = Trade(id=pos.id, symbol=pos.symbol, side=pos.side, volume=volume, open_price=pos.open_price, close_price=price,
                   open_time=pos.open_time, close_time=t, profit=profit, reason=reason, comment=pos.comment, owner=pos.owner,
                   swap=swap_part, fee=fee_part + close_fee)
        self.trades.append(tr)
        return tr

    def close(self, pos_id, price, t, reason):
        pos = self.positions.pop(pos_id)
        gross = self._gross(pos, price)
        close_fee = self.fee_for(pos.volume, price)
        profit = gross - pos.fee - close_fee - pos.swap
        self.balance += profit
        tr = Trade(id=pos.id, symbol=pos.symbol, side=pos.side, volume=pos.volume,
                   open_price=pos.open_price, close_price=price, open_time=pos.open_time,
                   close_time=t, profit=profit, reason=reason, comment=pos.comment, owner=pos.owner,
                   swap=pos.swap, fee=pos.fee + close_fee)
        self.trades.append(tr)
        return tr

    def to_dict(self):
        return {"start_balance": self.start_balance, "balance": self.balance, "next_id": self._next_id,
                "peak": self.peak_equity, "max_dd": self.max_drawdown,
                "positions": [jsonable(p) for p in self.positions.values()],
                "pending": [jsonable(o) for o in self.pending.values()],
                "trades": [jsonable(t) for t in self.trades[-300:]]}

    def restore(self, d):
        self.start_balance = float(d.get("start_balance", self.start_balance))
        self.balance = float(d.get("balance", self.balance))
        self._next_id = int(d.get("next_id", 1))
        self.peak_equity = float(d.get("peak", self.balance))
        self.max_drawdown = float(d.get("max_dd", 0.0))
        self.positions = OrderedDict((p["id"], _mk(Position, p)) for p in d.get("positions", []))
        self.pending = OrderedDict((o["id"], _mk(PendingOrder, o)) for o in d.get("pending", []))
        self.trades = [_mk(Trade, t) for t in d.get("trades", [])]


# --------------------------------------------------------------------------
# Ghép tick thành nến
# --------------------------------------------------------------------------
def _mtime(path):
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def _fmt_trace(v):
    if isinstance(v, float):
        return "%.8g" % v
    s = str(v)
    return s if len(s) <= 80 else s[:77] + "..."


class CandleBuilder:
    """Ghép tick thành nến. `tf` (vd '1w', '1mo') cho phép nến tuần/tháng đúng lịch; không có `tf` thì cắt theo `step`."""

    def __init__(self, step, max_len=3000, tf=None):
        self.step = step
        self.tf = tf
        self.closed = deque(maxlen=max_len)
        self.current = None
        self.gap = None                    # (t_nến_trước, t_nến_mới) khi tick mới nhảy cóc qua ≥1 nến (mất feed) - vỏ lấp bằng backfill()

    def _open_of(self, t):
        return tf_bucket(self.tf, t) if self.tf else int(t // self.step) * self.step

    def seed(self, hist, now):
        cur_open = self._open_of(now)
        for c in hist:
            if c.time < cur_open:
                self.closed.append(c)
            elif c.time == cur_open:
                self.current = replace(c)

    def update(self, t, price):
        """Trả về nến vừa đóng (nếu có)."""
        open_t = self._open_of(t)
        done = None
        if self.current is None:
            self.current = Candle(open_t, price, price, price, price)
        elif open_t > self.current.time:
            done = self.current
            self.closed.append(done)
            exp = tf_next(self.tf, done.time) if self.tf else done.time + self.step
            if open_t > exp:
                self.gap = (done.time, open_t)
            self.current = Candle(open_t, price, price, price, price)
        else:
            c = self.current
            c.high = max(c.high, price)
            c.low = min(c.low, price)
            c.close = price
        return done

    def backfill(self, hist, gap=None):
        """Chèn các nến ĐÃ ĐÓNG còn thiếu (lấy từ `hist`, nằm giữa 2 mốc của `gap`) vào đúng thứ tự. Trả về số nến đã chèn."""
        gap = gap or self.gap
        self.gap = None
        if gap is None:
            return 0
        have = {c.time for c in self.closed}
        add = [replace(c) for c in hist if gap[0] < c.time < gap[1] and c.time not in have]
        if not add:
            return 0
        merged = sorted(list(self.closed) + add, key=lambda c: c.time)
        self.closed.clear()
        self.closed.extend(merged)
        return len(add)


# --------------------------------------------------------------------------
# API đưa cho bot (self.api)
# --------------------------------------------------------------------------
class BotContext:
    """Đối tượng `self.api` trong bot. Bot chỉ thấy/chỉnh được LỆNH CỦA CHÍNH NÓ."""

    def __init__(self, runner):
        self._r = runner

    # thông tin
    @property
    def symbol(self):
        return self._r.symbol

    @property
    def timeframe(self):
        return self._r.tf

    @property
    def mode(self):
        return self._r.session.settings["mode"]

    @property
    def tick(self):
        return self._r.last_tick

    @property
    def ai_signal(self):
        """Tín hiệu mới nhất từ nhóm AI (dict) hoặc None. Khoá: id, action(buy|sell|hold|close_all),
        confidence, sl_pct, tp_pct, reason, by, votes, age"""
        hub = self._r.session.ai_hub
        return hub.get_signal() if hub is not None else None

    @property
    def balance(self):
        return self._r.session.account.balance

    @property
    def equity(self):
        return self._r.session.account.equity()

    # thông tin về vỏ / tài khoản / mã (bot không tự hardcode được - vỏ trả lời)
    @property
    def version(self):
        """Phiên bản API của vỏ (so với `# @api_min:` trong bot)."""
        return API_VERSION

    @property
    def data_dir(self):
        """Thư mục RIÊNG của bot này để ghi file (trạng thái, cache...)."""
        return self._r.data_dir()

    @property
    def store(self):
        """Kho khoá-giá trị JSON RIÊNG của bot này, sống qua lần khởi động lại (và khi bot bị nạp lại/đổi tham số):
        `self.api.store.set("so_lenh", 3)`, `.get("so_lenh", 0)`, `.delete(k)`, `.keys()`, `.items()`, `.incr(k, 1)`, `.clear()`.
        Chỉ nhận JSON; giới hạn 64 KB/giá trị, 256 KB/kho. Trong backtest/tối ưu chỉ nằm trong bộ nhớ (không rò giữa các lần chạy)."""
        return self._r.kv("store")

    @property
    def shared(self):
        """Biến DÙNG CHUNG giữa các bot của tài khoản (như GlobalVariable của MT5), cùng API với `store`, bền qua lần khởi động lại.
        Dùng cho phối hợp giữa bot (vd bot A đặt cờ 'tạm dừng', bot B đọc). Mọi bot đều ghi/đọc được - đặt tên có tiền tố."""
        return self._r.kv("shared")

    def kv_call(self, space, op, *args):
        """Cổng cho bot chạy ở tiến trình riêng (không dành cho bot gọi trực tiếp - dùng `api.store` / `api.shared`)."""
        return self._r.kv(space).call(op, *args)

    def account_info(self):
        """AccountInfo: balance, equity, margin, reserved, free_margin, margin_level, leverage, mode, demo, netting, trade_allowed..."""
        return self._r.session.account_info()

    def symbol_info(self, symbol=None):
        """SymbolInfo của mã (mặc định mã của bot): volume_min/max/step, stops_level, trade_mode, spread, market_open..."""
        return self._r.session.symbol_info(symbol or self._r.symbol)

    def time_info(self):
        """{'utc','server','skew_s','local_offset_s'}: giờ máy, giờ thị trường (tick mới nhất) và độ lệch."""
        return self._r.session.time_info()

    def set_timer(self, seconds):
        """Gọi bot.on_timer() mỗi `seconds` giây (0 = tắt) - kể cả khi không có tick."""
        self._r.set_timer(seconds)

    # dữ liệu nến
    def candles(self, count=100, include_current=False, timeframe=None):
        """List Candle (cũ -> mới). Mặc định chỉ nến ĐÃ ĐÓNG của khung của bot; `timeframe='1h'` lấy khung khác (đa khung giờ).
        Không sửa các object này."""
        r = self._r
        if timeframe is not None and timeframe != r.tf:
            data = r.other_candles(timeframe, include_current)
        else:
            b = r.builder
            data = list(b.closed)
            if include_current and b.current is not None:
                data.append(replace(b.current))
        return data[-int(count):] if count else data

    def closes(self, count=100, include_current=False, timeframe=None):
        return [c.close for c in self.candles(count, include_current, timeframe)]

    # giao dịch (reason/details/ai hiện khi chạm vào chấm vào/ra lệnh trên biểu đồ). Mọi hàm trả về OrderResult:
    # `if res:` đúng khi thành công; res.retcode (xem sdk.Ret), res.message, res.position / res.order, res.price, res.volume
    def buy(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None, request_id=""):
        """request_id: nếu bot retry cùng request_id trong 2 phút, vỏ trả lại kết quả cũ thay vì gửi lệnh thứ hai."""
        return self._r._open("buy", volume, sl, tp, comment, reason, details, ai, request_id)

    def sell(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None, request_id=""):
        return self._r._open("sell", volume, sl, tp, comment, reason, details, ai, request_id)

    def buy_limit(self, volume, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        return self._r._pending("buy", "limit", volume, price, 0.0, sl, tp, comment, expiration, reason, details, ai)

    def sell_limit(self, volume, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        return self._r._pending("sell", "limit", volume, price, 0.0, sl, tp, comment, expiration, reason, details, ai)

    def buy_stop(self, volume, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        return self._r._pending("buy", "stop", volume, price, 0.0, sl, tp, comment, expiration, reason, details, ai)

    def sell_stop(self, volume, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        return self._r._pending("sell", "stop", volume, price, 0.0, sl, tp, comment, expiration, reason, details, ai)

    def buy_stop_limit(self, volume, stop_price, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        """Chạm stop_price (trên giá) thì thành lệnh limit mua tại `price` (<= stop_price)."""
        return self._r._pending("buy", "stop_limit", volume, price, stop_price, sl, tp, comment, expiration, reason, details, ai)

    def sell_stop_limit(self, volume, stop_price, price, sl=0.0, tp=0.0, comment="", expiration=0.0, reason="", details=None, ai=None):
        return self._r._pending("sell", "stop_limit", volume, price, stop_price, sl, tp, comment, expiration, reason, details, ai)

    def oco(self, *orders):
        """Nối các lệnh chờ CỦA BOT thành nhóm OCO (one-cancels-other): một lệnh khớp thì vỏ huỷ các lệnh còn lại. Nhận OrderResult/PendingOrder/id.
        Vd: a = self.api.buy_stop(...); b = self.api.sell_stop(...); self.api.oco(a, b). Lệnh native trên sàn có độ trễ đồng bộ
        (native_sync_s) nên về lý thuyết cả hai có thể khớp trước khi vỏ kịp huỷ; lệnh do vỏ theo dõi thì chính xác theo từng tick."""
        ids = []
        for o in orders:
            o = getattr(o, "order", None) or o                 # OrderResult -> PendingOrder
            ids.append(o if isinstance(o, int) else getattr(o, "id", None))
        return self._r.session.link_oco(ids, owner=self._r.iid)

    def calendar(self, hours=24.0, min_impact="medium"):
        """Tin kinh tế sắp ra trong `hours` giờ tới liên quan tới mã của bot (danh sách dict: ts [epoch giây UTC], currency, title, impact [0 nghỉ lễ · 1 thấp · 2 vừa · 3 cao],
        forecast, previous, actual). min_impact: "low" | "medium" | "high" hoặc số 0-3. Rỗng nếu người dùng chưa bật/cấu hình lịch hoặc lịch lỗi (khi đó vỏ KHÔNG chặn lệnh).
        Vd: if self.api.calendar(1, "high"): return   # có tin mạnh trong 1 giờ tới -> đứng ngoài.   Lệnh mới có thể trả Ret.NEWS_BLOCK nếu người dùng bật «chặn lệnh quanh tin»."""
        return self._r.session.calendar_upcoming(hours, min_impact, symbol=self._r.symbol)

    def stats(self):
        """Thống kê các lệnh ĐÃ ĐÓNG của bot này: dict trades, wins, losses, win_rate, profit, gross_profit, gross_loss, profit_factor (None nếu
        không có lệnh), avg_win, avg_loss, best, worst, expectancy, max_drawdown (tuyệt đối theo đường lãi cộng dồn), max_drawdown_pct (so số dư ban đầu)."""
        s = self._r.session
        with s.lock:
            mine = [t for t in (s.account.trades if s.account else []) if t.owner == self._r.iid]
        return trade_stats(mine, float(s.settings.get("initial_balance") or 0.0))

    def positions(self, side=None):
        return self._r.own_positions(side)

    def orders(self, side=None):
        """Lệnh chờ CỦA BOT NÀY."""
        return self._r.own_orders(side)

    def cancel_order(self, order, reason=""):
        oid = order if isinstance(order, int) else order.id
        if oid not in [o.id for o in self._r.own_orders()]:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s của bot này" % oid)
        return self._r.session.cancel_order(oid, "bot", reason, self._r._context())

    def modify_order(self, order, price=None, sl=None, tp=None, expiration=None):
        oid = order if isinstance(order, int) else order.id
        if oid not in [o.id for o in self._r.own_orders()]:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s của bot này" % oid)
        return self._r.session.modify_order(oid, price, sl, tp, expiration)

    def close(self, position, reason="", details=None, ai=None, volume=None):
        """Đóng vị thế (volume=None: đóng hết; volume nhỏ hơn: đóng MỘT PHẦN). Trả về OrderResult."""
        pid = position if isinstance(position, int) else position.id
        if pid not in [p.id for p in self._r.own_positions()]:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s của bot này" % pid)
        return self._r._close_position(pid, "bot", reason, details, ai, volume)

    def close_all(self, side=None, reason="", details=None, ai=None):
        n = 0
        for p in self.positions(side):
            if self._r._close_position(p.id, "bot", reason, details, ai):
                n += 1
        return n

    def modify(self, position, sl=None, tp=None):
        pid = position if isinstance(position, int) else position.id
        if pid not in [p.id for p in self._r.own_positions()]:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s của bot này" % pid)
        return self._r.session.modify_position(pid, sl, tp)

    # hiển thị
    def plot(self, name, value, time=None):
        """Vẽ 1 đường chỉ báo lên biểu đồ nến. time=None -> nến hiện tại."""
        self._r._plot(name, value, time)

    def status(self, text):
        """Dòng 'bot đang nghĩ gì' hiện ở tab Biểu đồ."""
        self._r.bot_status = str(text)[:300]

    def signal(self, text, price=None, side="", details=None):
        """Đánh dấu 1 tín hiệu KHÔNG vào lệnh (vd bị lọc) lên biểu đồ; chạm vào để xem."""
        self._r._note(text, price, side, details)

    def log(self, *args):
        self._r.log(" ".join(str(a) for a in args), "BOT")

    @property
    def trace_enabled(self):
        """True khi người dùng bật «Trace» cho bot này - dùng để bỏ qua việc tính giá trị chỉ phục vụ trace."""
        return bool(self._r.trace_on)

    def trace(self, text, **values):
        """Ghi vết quyết định (chỉ khi người dùng bật Trace trên thẻ bot; tắt thì gần như không tốn gì). Vd:
        self.api.trace("RSI cắt lên 30 -> mua", rsi=rsi, close=c)  - hiện ở tab Nhật ký (mức TRACE) và gói chẩn đoán."""
        self._r._trace(text, values)


# --------------------------------------------------------------------------
# Phiên giao dịch (tài khoản chung)
# --------------------------------------------------------------------------
class TradingSession(OrderMixin, ReconcileMixin, ExchangeSyncMixin, ProtectMixin, TrailMixin, LinkMixin, CalendarMixin):
    RETRY_BASE_S = 2.0                      # chờ mạng khi khôi phục phiên: lùi nhịp = RETRY_BASE_S * số lần thử (tối đa 60 giây)

    def __init__(self, settings, log_file=None, trades_csv=None, state_file=None, events_file=None,
                 resume=False, alarm_cb=None, notify_cb=None, ai_hub=None, feed=None, sync=False, alerts_file=None):
        self.settings = settings
        self.log_file, self.trades_csv = log_file, trades_csv
        self.state_file, self.events_file = state_file, events_file
        self.resume = resume
        self.alarm_cb, self.notify_cb = alarm_cb, notify_cb
        self.ai_hub = ai_hub
        self.feed = feed
        self.sync = sync                    # True: chạy đồng bộ từng tick (backtest), không thread
        self.lock = threading.RLock()
        self.logs, self._log_id = deque(maxlen=800), 0
        self.events, self._event_id = deque(maxlen=800), 0
        self.account, self.broker = None, None
        self.ticks = {}
        self.builders = {}
        self.instances = OrderedDict()
        self.watch = parse_watchlist(settings.get("watchlist"))
        self.status, self.message = "idle", ""
        self.equity_hist = deque(maxlen=600)
        self.tick_count = 0
        self.started_at = None
        self.interval_override = None
        self.ready = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._cmds = queue.Queue()
        self._close_retry = {}
        self._order_fail = 0
        self._last_save = 0.0
        self._feed_fail = {}
        self._chart_symbols = set()
        self.chart_req = None
        self._finished = False
        # ---- hạ tầng của vỏ ----
        self.halted = False                         # Kill switch đang bật
        self._tick_wall = {}                        # symbol -> giờ MÁY nhận tick gần nhất (đo độ tươi của dữ liệu)
        self._bf_last = {}                          # (symbol, tf) -> giờ MÁY lần backfill gần nhất (chặn gọi dồn dập)
        self._trade_lock = threading.RLock()        # "trade context": lệnh gửi sàn xếp hàng tuần tự
        self._req_cache = {}                        # (owner, request_id) -> (giờ, OrderResult)  chống gửi trùng khi bot retry
        self._margin_alerted = False
        self.alerts = AlertBook(alerts_file) if (alerts_file or not sync) else None
        self.data_dir = os.path.dirname(os.path.abspath(state_file)) if state_file else None
        self.cache = HistoryCache(os.path.join(self.data_dir, "cache")) if (self.data_dir and not sync) else None
        self._recon_init()
        self._sync_init()
        self._prot_init()
        self._trail_init()
        self._link_init()
        self._cal_init()
        self._feed_first_fail = {}                  # mã -> giờ bắt đầu chuỗi lỗi giá hiện tại
        self._feed_next = {}                        # mã -> giờ được thử lại (lùi nhịp khi lỗi kéo dài)

    # ---------------- nhật ký / cảnh báo ----------------
    def log(self, msg, level="INFO"):
        ts = time.time()
        msg = redact.redact(str(msg))                    # bot/sàn lỡ in khoá ra nhật ký -> che trước khi vào bộ nhớ + file
        with self.lock:
            self._log_id += 1
            self.logs.append((self._log_id, ts, level, msg))
        if self.log_file:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write("%s [%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)), level, msg))
                self._log_writes = getattr(self, "_log_writes", 0) + 1
                if self._log_writes % 200 == 0:                      # file ngày phình (bot in quá nhiều) -> xoay vòng, giữ 2 bản
                    logrot.rotate_if_big(self.log_file, 5 * 1024 * 1024, keep=2)
            except OSError:
                pass

    def get_logs(self, after=0):
        with self.lock:
            return [x for x in self.logs if x[0] > after]

    def shared_kv(self):
        """Kho `api.shared` của cả phiên (tạo lười)."""
        kv = self.__dict__.get("_shared_kv")
        if kv is None:
            with self.lock:
                kv = self.__dict__.get("_shared_kv")
                if kv is None:
                    mem = self.sync or not self.data_dir
                    kv = self._shared_kv = KVStore(None if mem else os.path.join(self.data_dir, "shared_vars.json"))
        return kv

    def alarm(self, title, text, critical=True):
        """Cảnh báo cho người dùng. `critical=True` (MẶC ĐỊNH, an toàn: cảnh báo mới quên phân loại không bị tắt tiếng nhầm) = sự cố cần biết ngay.
        critical=False = thông tin thường (cảnh báo giá/chỉ báo, khớp một phần, trượt giá...): khi «Không làm phiền» đang bật chỉ hiện thông báo IM LẶNG
        (vẫn ghi nhật ký). Cảnh báo nghiêm trọng vẫn kêu trừ khi người dùng tắt «dnd_critical_pass» (xem dnd.py)."""
        self.log("CẢNH BÁO: %s - %s" % (title, text), "ERROR")
        if self.alarm_cb:
            try:
                if dnd.muted(critical):
                    self.alarm_cb(title, text[:240], quiet=True)       # callback không hiểu `quiet` -> lỗi bị nuốt: thà không kêu còn hơn kêu giữa DND
                else:
                    self.alarm_cb(title, text[:240])
            except Exception:
                pass

    def notify(self, title, text):
        if self.notify_cb and self.settings.get("notify_trades"):
            try:
                self.notify_cb(title, text)
            except Exception:
                pass

    # ---------------- vòng đời ----------------
    def is_alive(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self.is_alive():
            return
        self.status = "starting"
        self._stop.clear()
        self.ready.clear()
        self._finished = False
        self._thread = threading.Thread(target=self._run, name="pyea-session", daemon=True)
        self._thread.start()

    def stop(self, wait=False, timeout=15):
        if self.is_alive() and self.status in ("starting", "running"):
            self.status = "stopping"
        self._stop.set()
        if wait and self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout)

    def request_close_all(self, symbol=None):
        self._cmds.put(("close_all", symbol))

    def set_chart(self, symbol, tf):
        self.chart_req = (symbol, tf)
        self._cmds.put(("chart", symbol, tf))

    def set_watch(self, symbols):
        with self.lock:
            self.watch = list(symbols)

    def setup(self):
        s = self.settings
        live = s["mode"] == "live"
        ex = s["exchange"]
        syms = self.needed_symbols()
        if live:
            if ex == "simulated":
                raise _Halt("Chế độ live cần chọn sàn thật (không phải 'simulated')", error=True, reason="config")
            if not s.get("live_confirm"):
                raise _Halt("Chưa tick xác nhận rủi ro giao dịch thật", error=True, reason="config")
            try:
                self.broker = make_broker(s)
            except BrokerError as e:                                 # thiếu/sai cấu hình: thử lại cũng vô ích
                raise _Halt("Kết nối sàn thất bại: %s" % e, error=True, reason="broker")
            balance = self._connect_broker(syms)
            self.log("LIVE %s%s: kết nối OK, số dư khả dụng = %.4f" % (ex, " (TESTNET/DEMO)" if s.get("testnet") else "", balance), "WARN")
            try:
                for w in (getattr(self.broker, "check_permissions", None) or (lambda: []))():
                    self.log("QUYỀN API KEY: %s" % w, "WARN")
                    if "RÚT TIỀN" in w:
                        self.alarm("API key có quyền RÚT TIỀN", w)
            except Exception:
                pass
        else:
            balance = float(s["initial_balance"])
        if self.feed is None:
            try:
                self.feed = make_feed(ex, s)
            except FeedError as e:
                raise _Halt(str(e), error=True, reason="feed")
        lev = s["leverage"] if (not live or ex != "binance_spot") else 1.0
        self.account = Account(balance, s["commission_pct"], lev)
        if self.resume:
            self._load_state()

    def _connect_broker(self, syms):
        """Kết nối sàn. Phiên KHÔI PHỤC sau sự cố (resume) mà chưa có mạng thì CHỜ và thử lại (lùi nhịp tới 60 giây) thay vì bỏ cuộc: vị thế đang mở cần
        được canh lại ngay khi có mạng. Người dùng bấm Bắt đầu thì báo lỗi ngay như cũ."""
        tries, t0, alarmed = 0, time.time(), 0.0
        while True:
            try:
                return self.broker.prepare(syms[0] if syms else "BTCUSDT", self.settings["leverage"])
            except BrokerError as e:
                tries += 1
                if not self.resume or self._stop.is_set():
                    raise _Halt("Kết nối sàn thất bại: %s" % e, error=True, reason="broker")
                self.message = "Đang chờ kết nối sàn để khôi phục phiên (lần %d): %s" % (tries, e)
                self.log(self.message, "WARN")
                now = time.time()
                rep = float(self.settings.get("link_repeat_min", 10.0) or 0.0) * 60.0
                if not alarmed or (rep > 0 and now - alarmed >= rep):
                    alarmed = now
                    self.alarm("Chưa kết nối được sàn để khôi phục phiên",
                               "%s. App tự thử lại (đã chờ %s). Trong lúc này SL/TP do app canh KHÔNG chạy; SL/TP native trên sàn (nếu có) vẫn hoạt động." % (
                                   e, self._fmt_dur(now - t0)))
                if self._stop.wait(min(60.0, self.RETRY_BASE_S * tries)):
                    raise _Halt("Đã dừng khi đang chờ kết nối sàn")

    def _run(self):
        try:
            self.setup()
            self.status = "running"
            self.started_at = time.time()
            self.ready.set()
            base = float(self.settings["tick_interval"])
            while not self._stop.is_set():
                interval = max(base, float(self.interval_override or 0))
                t0 = time.monotonic()
                self.poll_once()
                self._handle_commands()
                if time.time() - self._last_save > 20:
                    self._save_state()
                self._stop.wait(max(0.0, interval - (time.monotonic() - t0)))
        except _Halt as h:
            self.message = str(h)
            self.log(str(h), "ERROR" if h.error else "WARN")
            self.status = "error" if h.error else "stopped"
            if h.error or h.reason == "max_loss":
                self.alarm("Phiên dừng: " + ("lỗi" if h.error else "đạt ngưỡng lỗ tối đa"), str(h).strip().splitlines()[0])
        except Exception:
            self.message = "Lỗi engine"
            self.log("Lỗi engine:\n" + traceback.format_exc(limit=6), "ERROR")
            self.status = "error"
            self.alarm("Phiên dừng vì lỗi engine", traceback.format_exc(limit=1).strip().splitlines()[-1])
        finally:
            self._finish()

    def _finish(self):
        if self._finished:
            return
        self._finished = True
        try:
            for inst in list(self.instances.values()):
                inst.request_stop()
            if self.account is not None and self.settings.get("close_on_stop") and self.account.positions:
                self.log("Đóng các lệnh còn mở khi dừng")
                self.close_all("stop", "Đóng lệnh còn mở khi dừng phiên")
        except Exception:
            self.log("Lỗi khi dừng:\n" + traceback.format_exc(limit=4), "ERROR")
        if self.status not in ("error", "stopped"):
            self.status = "stopped"
        self._save_state(clean=True)
        self.log("Phiên đã dừng")
        self.ready.set()
        if self.feed is not None:
            try:
                self.feed.close()
            except Exception:
                pass
        try:
            from .feeds import pool_close_all
            pool_close_all()                                   # đóng các kết nối giữ sẵn (GET keep-alive)
        except Exception:                                      # noqa: BLE001
            pass

    # ---------------- giá ----------------
    def needed_symbols(self):
        with self.lock:
            out = list(self.watch)
            for inst in self.instances.values():
                out.append(inst.symbol)
            out += [sym for sym, _ in self.builders]
            if self.account is not None:
                out += [p.symbol for p in self.account.positions.values()]
                out += [o.symbol for o in self.account.pending.values()]
            if self.alerts is not None:
                out += self.alerts.symbols()
            if self.chart_req:
                out.append(self.chart_req[0])
        seen, uniq = set(), []
        for x in out:
            if x and x not in seen:
                seen.add(x)
                uniq.append(x)
        return uniq

    def get_tick(self, symbol):
        t = self.ticks.get(symbol)
        if t is not None:
            return t
        t = self.feed.tick(symbol)
        with self.lock:
            self.ticks[symbol] = t
            self._tick_wall[symbol] = time.time()
        return t

    def get_builder(self, symbol, tf):
        """Builder nến (đã nạp lịch sử) dùng chung cho biểu đồ và bot cùng (mã, khung)."""
        key = (symbol, tf)
        b = self.builders.get(key)
        if b is not None:
            return b
        first = self.get_tick(symbol)
        n = int(self.settings["history_bars"])
        ex = self.settings["exchange"]
        if ex == "simulated" or self.cache is None:          # giả lập sinh tức thì, không cần cache
            hist = self.feed.history(symbol, tf, n)
        else:
            hist, info = load_history(self.feed, self.cache, ex, symbol, tf, n)
            self.log("Lịch sử %s %s: %d nến (cache %d · tải %d%s)%s" % (
                symbol, tf, len(hist), info["cached"], info["fetched"], " · tải lại đủ" if info["refetched"] else "",
                (" · CÒN %d khoảng trống (%d nến thiếu)" % (info["gaps"], info["gap_candles"])) if info["gaps"] else ""),
                "WARN" if info["gaps"] else "INFO")
        b = CandleBuilder(tf_seconds(tf), tf=tf)
        b.seed(hist, first.time)
        with self.lock:
            self.builders.setdefault(key, b)
            return self.builders[key]

    def poll_once(self):
        for sym in self.needed_symbols():
            if time.time() < self._feed_next.get(sym, 0.0):
                continue                                             # lỗi kéo dài: lùi nhịp hỏi giá (không dồn dập vào mạng/sàn đang hỏng)
            try:
                tick = self.feed.tick(sym)
                if self._feed_fail.get(sym, 0) > 0:
                    self.log("Đã lấy lại được giá %s sau %d lần lỗi" % (sym, self._feed_fail[sym]), "WARN")
                self._feed_fail[sym] = 0
                self._feed_first_fail.pop(sym, None)
                self._feed_next.pop(sym, None)
            except FeedError as e:
                n = self._feed_fail[sym] = self._feed_fail.get(sym, 0) + 1
                self._feed_first_fail.setdefault(sym, time.time())
                if n in (1, 5, 20):
                    self.log("Không lấy được giá %s (%d lần): %s" % (sym, n, e), "WARN")
                if n >= 10:
                    self._feed_next[sym] = time.time() + min(15.0, 1.0 + n / 10.0)
                # Cảnh báo mất kết nối do `_check_link` lo (một đợt = một cảnh báo, kèm tình trạng vị thế). Dừng cứng chỉ khi người dùng đặt `feed_halt_min`.
                halt_min = float(self.settings.get("feed_halt_min") or 0.0)
                if halt_min > 0 and time.time() - self._feed_first_fail[sym] >= halt_min * 60.0 and self._has_exposure(sym):
                    raise _Halt("Mất kết nối giá %s quá lâu" % sym, error=True, reason="feed")
                continue
            self.process_tick(tick)
        self._sync_native_pending()
        self._check_max_loss()
        self._check_margin()
        self._check_hung()
        self._check_protection()                    # TRƯỚC đối soát: lệnh bảo vệ native vừa khớp phải được ghi đúng là SL/TP, không phải «đối soát»
        self._check_reconcile()
        self._check_exchange_sync()
        self._check_account_flags()
        self._check_account_state()
        self._check_position_stats()
        self._check_link()
        self._check_calendar()
        self._ensure_alert_builders()
        with self.lock:
            self.equity_hist.append(self.account.equity())

    def _has_exposure(self, sym):
        return any(p.symbol == sym for p in self.account.positions.values()) or any(
            i.symbol == sym for i in self.instances.values())

    def process_tick(self, tick):
        """Xử lý 1 tick (thread session hoặc backtest đồng bộ): ghép nến, mark, SL/TP, phát cho bot."""
        closed = {}
        with self.lock:
            self.ticks[tick.symbol] = tick
            self._tick_wall[tick.symbol] = time.time()
            self.tick_count += 1
            self.account.mark(tick)
            for (sym, tf), b in list(self.builders.items()):
                if sym == tick.symbol:
                    closed[tf] = b.update(tick.time, tick.mid)
        self._backfill_gaps(tick.symbol)                 # lấp khoảng trống nến TRƯỚC khi bot thấy nến mới
        self._check_pending(tick)
        self._check_sl_tp(tick)
        self._check_trails(tick)
        self._check_alerts(tick)
        for tf, done in closed.items():
            if done is not None:
                self._check_candle_alerts(tick.symbol, tf)
        for inst in list(self.instances.values()):
            if inst.symbol == tick.symbol:
                inst.deliver(tick, closed.get(inst.tf))

    def _backfill_gaps(self, symbol):
        """Feed live mất một lúc rồi có lại: các nến ở giữa không được ghép từ tick nên bot sẽ tính chỉ báo trên chuỗi THỦNG.
        Phát hiện ở CandleBuilder.gap -> tải bù lịch sử từ nguồn giá rồi chèn đúng chỗ. Cuối tuần/lễ của forex không tính là thủng
        (find_gaps). Backtest/giả lập không làm. Chặn gọi dồn dập 20 giây/(mã, khung); lỗi tải -> thử lại sau."""
        if self.sync or self.settings.get("exchange") == "simulated":
            return
        for (sym, tf), b in list(self.builders.items()):
            if sym != symbol or b.gap is None:
                continue
            gap = b.gap
            ex = self.settings.get("exchange")
            if not find_gaps([Candle(gap[0], 0, 0, 0, 0), Candle(gap[1], 0, 0, 0, 0)], tf, ex):
                b.gap = None                                      # nghỉ cuối tuần/lễ bình thường
                continue
            now = time.time()
            if now - self._bf_last.get((sym, tf), 0.0) < 20.0:
                continue
            self._bf_last[(sym, tf)] = now
            step = tf_seconds(tf)
            missing = max(1, int(round((gap[1] - gap[0]) / step)) - 1)
            self.log("Phát hiện khoảng trống dữ liệu %s %s: thiếu %d nến (mất giá khoảng %s) - đang tải bù từ nguồn giá" % (
                sym, tf, missing, "%d phút" % round((gap[1] - gap[0]) / 60.0)), "WARN")
            try:
                hist = self.feed.history(sym, tf, min(max(missing + 5, 8), 1500))     # nguồn giá trả N nến cuối tới HIỆN TẠI; +5 là biên
            except FeedError as e:
                self.log("Tải bù nến %s %s thất bại (sẽ thử lại): %s" % (sym, tf, e), "WARN")
                continue
            with self.lock:
                added = b.backfill(hist, gap)
            self.log("Đã lấp %d/%d nến thiếu của %s %s%s" % (added, missing, sym, tf, "" if added >= missing else
                                                          " - nguồn giá không có đủ, chuỗi nến vẫn còn khoảng trống"),
                     "INFO" if added >= missing else "WARN")

    def _check_sl_tp(self, tick):
        with self.lock:
            plist = [p for p in self.account.positions.values() if p.symbol == tick.symbol]
        for p in plist:
            hit = None
            px = tick.bid if p.side == "buy" else tick.ask
            hold = self.prot_hold(p.symbol)                                 # vừa khởi động lại, chưa xác minh lệnh bảo vệ cũ: chưa tự đóng
            sl_lv = 0.0 if (hold or self.prot_covered(p.id, "sl")) else p.sl    # mức đã có lệnh bảo vệ NATIVE trên sàn: sàn canh, vỏ KHÔNG canh nữa
            tp_lv = 0.0 if (hold or self.prot_covered(p.id, "tp")) else p.tp    # (cả hai cùng đóng sẽ đóng nhầm vị thế ảo khác - xem protect.py)
            if p.side == "buy":
                hit = "sl" if (sl_lv and px <= sl_lv) else "tp" if (tp_lv and px >= tp_lv) else None
            else:
                hit = "sl" if (sl_lv and px >= sl_lv) else "tp" if (tp_lv and px <= tp_lv) else None
            if hit:
                name = "Stop Loss" if hit == "sl" else "Take Profit"
                level = p.sl if hit == "sl" else p.tp
                self.close_position(p.id, hit, "Giá chạm %s: %s %.8g so với mức đặt %.8g" % (
                    name, "bid" if p.side == "buy" else "ask", px, level),
                    {"mức đặt": level, "giá hiện tại": px, "bid": tick.bid, "ask": tick.ask})

    def _check_max_loss(self):
        pct = float(self.settings["max_loss_pct"])
        if pct <= 0 or self.account is None:
            return
        acc = self.account
        if acc.equity() <= acc.start_balance * (1 - pct / 100.0):
            self.log("Equity giảm quá %.1f%% -> đóng hết lệnh và dừng phiên" % pct, "WARN")
            self.close_all("risk", "Equity giảm quá %.1f%% so với vốn ban đầu %.2f (hiện %.2f)" % (
                pct, acc.start_balance, acc.equity()))
            raise _Halt("Đạt ngưỡng lỗ tối đa %.1f%%" % pct, reason="max_loss")

    def _handle_commands(self):
        while True:
            try:
                cmd = self._cmds.get_nowait()
            except queue.Empty:
                return
            try:
                if cmd[0] == "close_all":
                    self.log("Đóng tất cả lệnh%s (thủ công)" % ((" " + cmd[1]) if cmd[1] else ""))
                    self.close_all("manual", "Người dùng bấm 'Đóng tất cả'", symbol=cmd[1])
                elif cmd[0] == "chart":
                    self.get_builder(cmd[1], cmd[2])
                elif cmd[0] == "kill":
                    self.kill_switch(cmd[1])
                elif cmd[0] == "resume":
                    self.resume_trading()
                elif cmd[0] == "reset_paper":
                    self.reset_paper()
            except Exception as e:
                self.log("Lệnh nội bộ lỗi: %s" % e, "WARN")

    # ---------------- sự kiện / lý do ----------------
    def base_context(self, symbol):
        t = self.ticks.get(symbol)
        acc = self.account
        return {"bid": t.bid if t else None, "ask": t.ask if t else None, "symbol": symbol,
                "balance": acc.balance if acc else None, "equity": acc.equity() if acc else None,
                "open_positions": len(acc.positions) if acc else 0, "mode": self.settings["mode"]}

    def add_event(self, kind, symbol, price, side="", volume=0.0, pos_id=0, source="bot", reason="",
                  details=None, ai=None, profit=0.0, ctx=None, owner=""):
        t = self.ticks[symbol].time if symbol in self.ticks else time.time()
        with self.lock:
            self._event_id += 1
            ev = TradeEvent(id=self._event_id, kind=kind, time=t, price=price, side=side, volume=volume,
                            pos_id=pos_id, source=source, reason=redact.redact(str(reason or "")), details=jsonable(details or {}),
                            context=jsonable(ctx or self.base_context(symbol)), ai=self._ai_info(ai),
                            profit=profit, wall_time=time.time(), symbol=symbol, owner=owner)
            self.events.append(ev)
        if self.events_file:
            try:
                with open(self.events_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(jsonable(ev), ensure_ascii=False) + "\n")
            except OSError:
                pass
        return ev

    def _ai_info(self, ai):
        if ai is True:
            ai = self.ai_hub.get_signal() if self.ai_hub is not None else None
        if not isinstance(ai, dict):
            return None
        return jsonable({k: ai.get(k) for k in ("id", "by", "model", "action", "confidence", "sl_pct", "tp_pct",
                                                "reason", "age", "votes", "discussion", "mode", "prompt_hash", "provider", "replayed") if k in ai})

    # ---------------- giao dịch: xem orders.OrderMixin (send_order, place_pending, close_position, kill_switch...) ----------------
    def _order_failed(self, msg):
        self._order_fail += 1
        self.log(msg, "ERROR")
        if self._order_fail == 3:
            self.alarm("Đặt lệnh thất bại liên tiếp", msg)

    def _save_trade(self, tr):
        if not self.trades_csv:
            return
        try:
            new = not os.path.exists(self.trades_csv)
            with open(self.trades_csv, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["owner", "id", "symbol", "side", "volume", "open_price", "close_price",
                                "open_time", "close_time", "profit", "reason"])
                w.writerow([tr.owner, tr.id, tr.symbol, tr.side, tr.volume, tr.open_price, tr.close_price,
                            tr.open_time, tr.close_time, round(tr.profit, 8), tr.reason])
        except OSError:
            pass

    # ---------------- lưu / khôi phục ----------------
    def _save_state(self, clean=False):
        """clean=True: ghi khi dừng phiên CÓ CHỦ ĐÍCH (để lần khôi phục sau phân biệt «người dùng dừng» với «bị giết/crash»)."""
        self._last_save = time.time()
        if not self.state_file or self.account is None:
            return
        try:
            with self.lock:
                data = {"_schema": schema.CURRENT, "mode": self.settings["mode"], "exchange": self.settings["exchange"], "saved_at": time.time(),
                        "account": self.account.to_dict(), "event_id": self._event_id, "halted": self.halted,
                        "clean": bool(clean), "booked": list(self._booked)[-1500:]}
            _atomic_write(self.state_file, json.dumps(data, ensure_ascii=False))
        except Exception:
            pass

    def _load_state(self):
        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            return
        newer = schema.newer(d)
        if newer:                                       # phiên do bản app MỚI hơn ghi: không đọc, không ghi đè - giữ nguyên làm .bak
            bak = schema.set_aside(self.state_file, newer)
            self.log("Phiên đã lưu thuộc định dạng v%d mới hơn app này -> KHÔNG khôi phục, giữ nguyên tại %s" % (newer, bak), "WARN")
            return
        if d.get("mode") != self.settings["mode"] or d.get("exchange") != self.settings["exchange"]:
            self.log("Bỏ qua phiên đã lưu (khác chế độ/sàn)", "WARN")
            return
        self.account.restore(d.get("account", {}))
        self._event_id = int(d.get("event_id", 0))
        for oid in d.get("booked") or []:
            self._book_order(oid)
        self.halted = bool(d.get("halted", False))
        if self.halted:
            self.log("Phiên được khôi phục Ở TRẠNG THÁI KILL SWITCH - giao dịch vẫn bị khoá", "WARN")
        if self.events_file and os.path.exists(self.events_file):
            try:
                with open(self.events_file, "r", encoding="utf-8") as f:
                    for line in f.readlines()[-500:]:
                        self.events.append(_mk(TradeEvent, json.loads(line)))
                if self.events:
                    self._event_id = max(self._event_id, max(e.id for e in self.events))
            except Exception:
                pass
        self.log("KHÔI PHỤC phiên: %d lệnh mở, %d lệnh chờ, %d lệnh đã đóng, số dư %.4f" % (
            len(self.account.positions), len(self.account.pending), len(self.account.trades), self.account.balance), "WARN")
        self._restore_gap(d)

    def _restore_gap(self, d):
        """Phiên được khôi phục sau một khoảng NGỪNG: nói rõ app đã không canh vị thế bao lâu. Phiên lưu mỗi 20 giây lúc đang chạy nên `saved_at` ≈ lúc app chết.
        Dừng có chủ đích (clean) thì chỉ ghi nhật ký. Đối soát với sàn chạy ngay ở vòng poll đầu tiên."""
        saved = float(d.get("saved_at") or 0.0)
        gap = time.time() - saved if saved else 0.0
        self.restore_info = {"gap_s": gap, "clean": bool(d.get("clean")), "positions": len(self.account.positions), "pending": len(self.account.pending)}
        if gap < 90.0 or not (self.account.positions or self.account.pending):
            return
        txt = "App ngừng hoạt động khoảng %s (từ lần lưu cuối) khi còn %d vị thế, %d lệnh chờ." % (self._fmt_dur(gap), len(self.account.positions), len(self.account.pending))
        if d.get("clean"):
            self.log("KHÔI PHỤC sau khi bạn dừng phiên: " + txt, "WARN")
            return
        txt += (" Trong lúc đó SL/TP và lệnh chờ do APP canh không chạy (SL/TP native trên sàn, nếu có, vẫn đã hoạt động); mức nào đã bị vượt sẽ được đóng "
                "ngay theo giá thị trường. App đang đối soát với sàn.")
        self.log("KHÔI PHỤC SAU SỰ CỐ: " + txt, "WARN")
        self.alarm("Phiên khôi phục sau khi ngừng %s" % self._fmt_dur(gap), txt)

    # ---------------- bot gắn vào tài sản ----------------
    def attach(self, bot_path, symbol, tf, params=None, iid=None):
        symbol = symbol.strip().upper()
        if iid is None:
            base = os.path.splitext(os.path.basename(bot_path))[0]
            n = 1
            while "%s-%s-%d" % (base, symbol, n) in self.instances:
                n += 1
            iid = "%s-%s-%d" % (base, symbol, n)
        inst = BotRunner(bot_path, self.settings, params or {}, session=self, symbol=symbol, tf=tf, iid=iid)
        with self.lock:
            self.instances[iid] = inst
        return inst

    def detach(self, iid):
        inst = self.instances.get(iid)
        if inst is not None:
            inst.stop()
            with self.lock:
                self.instances.pop(iid, None)

    # ---------------- ảnh chụp cho giao diện ----------------
    def snapshot(self):
        base = {"status": self.status, "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message,
                "mode": self.settings["mode"], "exchange": self.settings["exchange"], "ready": False,
                "watch": {}, "instances": [], "positions": [], "trades": [], "equity_curve": []}
        with self.lock:
            acc = self.account
            base["instances"] = [i.summary() for i in self.instances.values()]
            if acc is None:
                return base
            tr = acc.trades
            wins = sum(1 for t in tr if t.profit > 0)
            eq = acc.equity()
            base.update({
                "ready": True, "balance": acc.balance, "equity": eq, "floating": acc.floating(),
                "margin": acc.margin_used(), "start_balance": acc.start_balance, "pnl": eq - acc.start_balance,
                "pnl_pct": (eq - acc.start_balance) / acc.start_balance * 100.0 if acc.start_balance else 0.0,
                "max_dd": acc.max_drawdown, "n_trades": len(tr), "wins": wins,
                "win_rate": (wins / len(tr) * 100.0) if tr else 0.0,
                "uptime": (time.time() - self.started_at) if self.started_at else 0.0, "ticks": self.tick_count,
                "free_margin": eq - acc.margin_used() - acc.reserved_margin(), "reserved": acc.reserved_margin(),
                "margin_level": acc.margin_level(), "broker_account": self.broker_account(), "broker_positions": self.broker_positions(), "halted": self.halted, "read_only": bool(self.settings.get("read_only")),
                "pending": [replace(o) for o in acc.pending.values()],
                "alerts": self.alerts.list() if self.alerts is not None else [],
                "positions": [replace(p) for p in acc.positions.values()], "trails": self.trail_rules(),
                "trades": [replace(t) for t in tr[-40:]][::-1],
                "equity_curve": list(self.equity_hist)[-200:],
                "watch": {s: {"bid": t.bid, "ask": t.ask, "time": t.time} for s, t in self.ticks.items()
                          if s in set(self.watch) | {i.symbol for i in self.instances.values()}
                          | {p.symbol for p in acc.positions.values()}},
            })
        base["health"] = self.health()
        base["link"] = self.link_state()
        base["calendar"] = self.calendar_state()
        base["contracts"] = self._ui_contracts()
        base["reconcile"] = dict(self.recon)
        base["exchange_sync"] = dict(self.exch)
        return base

    def chart(self, symbol, tf, bars=160, max_events=300):
        b = self.builders.get((symbol, tf))
        if b is None:
            return None
        with self.lock:
            candles = list(b.closed)[-bars:]
            if b.current is not None:
                candles.append(replace(b.current))
            times = {c.time for c in candles}
            plots = {}
            for inst in self.instances.values():
                if inst.symbol == symbol and inst.tf == tf:
                    for n, ser in inst.plots.items():
                        pts = [(t, v) for t, v in ser.items() if t in times]
                        plots[n if len(self.instances) <= 1 else "%s·%s" % (inst.iid, n)] = pts
            evs = [replace(e) for e in self.events if e.symbol == symbol][-max_events:]
            t = self.ticks.get(symbol)
            status = {i.iid: i.bot_status for i in self.instances.values() if i.symbol == symbol and i.bot_status}
        return {"symbol": symbol, "timeframe": tf, "candles": candles, "plots": plots, "events": evs,
                "bid": t.bid if t else None, "ask": t.ask if t else None, "bot_status": status,
                "positions": [replace(p) for p in self.account.positions.values() if p.symbol == symbol]
                if self.account else [],
                "pending": [replace(o) for o in self.account.pending.values() if o.symbol == symbol] if self.account else []}


# --------------------------------------------------------------------------
# Bot gắn vào 1 tài sản (như EA gắn vào chart)
# --------------------------------------------------------------------------
class BotRunner:
    def __init__(self, bot_path, settings, params, log_file=None, trades_csv=None, ai_hub=None, state_file=None,
                 events_file=None, resume=False, alarm_cb=None, notify_cb=None, session=None, symbol=None,
                 tf=None, iid=None):
        self.own_session = session is None
        if session is None:
            session = TradingSession(settings, log_file, trades_csv, state_file, events_file, resume,
                                     alarm_cb, notify_cb, ai_hub)
        self.session = session
        self.bot_path = bot_path
        self.params = params
        wl = parse_watchlist(settings.get("watchlist"))
        self.symbol = (symbol or settings.get("symbol") or (wl[0] if wl else "BTCUSD")).strip().upper()
        self.tf = tf or settings.get("timeframe") or "1m"
        self.iid = iid or os.path.splitext(os.path.basename(bot_path))[0]
        if self.own_session:
            session.instances[self.iid] = self
            if self.symbol in session.watch:
                session.watch.remove(self.symbol)
            session.watch.insert(0, self.symbol)
        self.status, self.message = "idle", ""
        self.bot_name = os.path.basename(bot_path)
        self.bot, self.bot_params, self.builder = None, {}, None
        self.bot_inputs = {}
        self.params_msg = ""
        self.plots = {}
        self.plot_cap = 3000
        self.bot_status = ""
        self._cb_name = ""
        self.started_at = None
        # ---- hạ tầng vỏ: on_trade / on_timer / đo thời gian / chống treo ----
        self.cbstats = CallbackStats()
        self.trace_on = False                      # chế độ Trace: ghi vết mọi callback/lệnh/api.trace() của bot này (bật trên thẻ bot)
        self.trace_buf = deque(maxlen=300)         # (epoch, dòng) gần nhất - đưa vào gói chẩn đoán
        self.code_mtime = 0.0                      # mtime của file bot lúc nạp (phát hiện «mã đã đổi» để Tải lại không cần dừng bot)
        self.hung = False
        self.cb_started = 0.0                      # monotonic lúc callback hiện tại bắt đầu (0 = không đang chạy callback)
        self._updates = deque(maxlen=500)          # TradeUpdate chờ gọi bot.on_trade
        self._in_cb = False
        self._timer_iv = 0.0
        self._timer_next = 0.0
        self._q = queue.Queue()
        self._stop = threading.Event()
        self._thread = None

    # ---- tiện ích truy cập (tương thích API cũ) ----
    @property
    def account(self):
        return self.session.account

    @property
    def events(self):
        return self.session.events

    @property
    def logs(self):
        return self.session.logs

    @property
    def lock(self):
        return self.session.lock

    @property
    def settings(self):
        return self.session.settings

    @property
    def last_tick(self):
        return self.session.ticks.get(self.symbol)

    @property
    def ai_hub(self):
        return self.session.ai_hub

    @property
    def interval_override(self):
        return self.session.interval_override

    @interval_override.setter
    def interval_override(self, v):
        self.session.interval_override = v

    def log(self, msg, level="INFO"):
        self.session.log("[%s] %s" % (self.iid, msg) if not self.own_session else msg, level)

    def get_logs(self, after=0):
        return self.session.get_logs(after)

    def own_positions(self, side=None):
        with self.session.lock:
            return [replace(p) for p in self.session.account.positions.values()
                    if p.owner == self.iid and (side is None or p.side == side)]

    def own_orders(self, side=None):
        with self.session.lock:
            return [replace(o) for o in self.session.account.pending.values()
                    if o.owner == self.iid and (side is None or o.side == side)]

    def data_dir(self):
        import tempfile
        d = os.path.join(self.session.data_dir or tempfile.gettempdir(), "bot_data", self.iid)
        os.makedirs(d, exist_ok=True)
        return d

    def kv(self, space):
        """KVStore `store` (riêng bot, file bot_data/<iid>/store.json) hoặc `shared` (chung tài khoản, shared_vars.json).
        Phiên đồng bộ (backtest/tối ưu) hoặc không có thư mục dữ liệu -> chỉ trong bộ nhớ."""
        if space == "shared":
            return self.session.shared_kv()
        if space != "store":
            raise AttributeError("không có kho '%s'" % space)
        kvs = self.__dict__.setdefault("_kv", {})
        if "store" not in kvs:
            mem = self.session.sync or not self.session.data_dir
            kvs["store"] = KVStore(None if mem else os.path.join(self.data_dir(), "store.json"))
        return kvs["store"]

    def other_candles(self, tf, include_current=False):
        """Nến khung KHÁC khung của bot: dùng builder dùng chung (nạp lịch sử lần đầu) hoặc ghép từ khung của bot."""
        from .feeds import TIMEFRAMES, resample
        if tf not in TIMEFRAMES:
            raise ValueError("Khung thời gian không hỗ trợ: %s" % tf)
        s = self.session
        b = s.builders.get((self.symbol, tf))
        if b is None and not s.sync:
            try:
                b = s.get_builder(self.symbol, tf)
            except FeedError:
                b = None
        if b is not None:
            data = list(b.closed)
            if include_current and b.current is not None:
                data.append(replace(b.current))
            return data
        base_s, want = tf_seconds(self.tf), tf_seconds(tf)
        if tf not in ("1w", "1mo") and (want < base_s or want % base_s):
            raise ValueError("Không có dữ liệu khung %s: phải lớn hơn và chia hết khung %s của bot" % (tf, self.tf))
        allc = list(self.builder.closed)
        if self.builder.current is not None:
            allc.append(replace(self.builder.current))
        data = resample(allc, tf)
        return data if include_current else data[:-1]       # nến cuối luôn là nến đang hình thành

    # ---- on_trade / on_timer ----
    def notify_trade(self, upd):
        if self.bot is None or self.status not in ("starting", "running"):
            return
        self._updates.append(upd)
        if self.session.sync:
            if not self._in_cb:                    # backtest: không có luồng riêng -> gọi ngay nếu không đang trong callback của bot
                self._drain_updates()
        elif self._thread is not None:
            self._q.put(("__wake__", None))

    def _drain_updates(self):
        if self._in_cb or self.bot is None:
            return
        while self._updates and self.status in ("starting", "running"):
            self._call("on_trade", self.bot.on_trade, self._updates.popleft())

    def set_timer(self, seconds):
        self._timer_iv = max(0.0, float(seconds or 0.0))
        self._timer_next = self._timer_now() + self._timer_iv

    def _timer_now(self):
        if self.session.sync:                      # backtest: dùng giờ THỊ TRƯỜNG của tick gần nhất
            t = self.session.ticks.get(self.symbol) or self.last_tick
            return t.time if t is not None else 0.0
        return time.time()

    def _service_timer(self):
        if self._timer_iv > 0 and self.bot is not None:
            now = self._timer_now()
            if now >= self._timer_next:
                self._timer_next = now + self._timer_iv
                self._call("on_timer", self.bot.on_timer)

    def mark_hung(self, elapsed):
        self.hung = True
        self.status = "error"
        self.message = "Bot treo: %s chạy %.0f giây chưa xong (giới hạn %.0f giây)" % (
            self._cb_name or "callback", elapsed, float(self.settings.get("bot_callback_timeout") or 0))
        self._stop.set()
        self.log(self.message, "ERROR")
        self.session.alarm("Bot %s bị treo" % self.iid, self.message)

    # ---- điều khiển ----
    def is_alive(self):
        if self.own_session:
            return (self._thread is not None and self._thread.is_alive()) or self.session.is_alive()
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self.status = "starting"
        self._stop.clear()
        if self.own_session:
            self.session.start()
        elif self.session.sync:
            self._setup()
            self.status = "running"
            return
        self._thread = threading.Thread(target=self._run, name="pyea-bot-" + self.iid, daemon=True)
        self._thread.start()

    def stop(self):
        if self._thread is not None and self._thread.is_alive() and self.status in ("starting", "running"):
            self.status = "stopping"
        self._stop.set()
        if self.own_session:
            self.session.stop()

    def request_stop(self):
        self._stop.set()

    def request_close_all(self):
        self.session.request_close_all()

    def deliver(self, tick, closed):
        if self.session.sync:
            if self.status == "running":
                self._on_tick(tick, closed)
        elif self.status in ("starting", "running"):
            self._q.put((tick, closed))

    # ---- chạy ----
    def _setup(self):
        s = self.session
        if not s.sync:
            limit, t0 = (24 * 3600.0 if s.resume else 120.0), time.time()      # phiên khôi phục có thể đang chờ mạng (xem TradingSession._connect_broker)
            while not s.ready.wait(1.0):
                if self._stop.is_set():
                    raise _Halt("Đã dừng khi đang chờ phiên giao dịch")
                if s.status in ("error", "stopped") or time.time() - t0 > limit:
                    break
            if s.status in ("error",) or s.account is None:
                raise _Halt("Phiên giao dịch chưa sẵn sàng: %s" % (s.message or s.status), error=True, reason="session")
        remote, info = None, None
        if str(self.settings.get("bot_isolation") or "thread") == "process" and not s.sync:
            from .botproc import ProcessUnavailable, start_remote_bot     # mã bot chạy ở TIẾN TRÌNH RIÊNG (xem botproc.py)
            try:
                remote, info = start_remote_bot(self, BotContext(self), bool(self.settings.get("dev_mode")))
            except ProcessUnavailable as e:
                self.log("Cô lập tiến trình không dùng được (%s) - chạy bot trong luồng như thường." % e, "WARN")
            except BotLoadError as e:
                raise _Halt(str(e), error=True, reason="load")
        if remote is None:
            try:
                cls, _ = load_bot_class(self.bot_path, bool(self.settings.get("dev_mode")))
            except BotLoadError as e:
                raise _Halt(str(e), error=True, reason="load")
            self.bot_name = cls.name or cls.__name__
            self.bot_inputs = collect_inputs(cls, self.bot_path)        # nhận dạng tham số như MT5 nhận dạng `input`
            self.code_mtime = _mtime(self.bot_path)
        else:
            self.bot_name, self.bot_inputs = info["name"], info["inputs"]
        self.bot_params = build_params(self.bot_inputs, self.params)
        if self.params:                                          # bot đổi tham số giữa các phiên bản: nói rõ cái gì bị bỏ / mới thay vì im lặng
            dropped, fresh = params_report(self.bot_inputs, self.params)
            if dropped:
                self.log("Tham số đã lưu %s KHÔNG còn trong bot (bỏ qua). Nếu bot chỉ đổi tên, tác giả cần khai báo "
                         "`param_aliases = {\"tên_cũ\": \"tên_mới\"}`." % ", ".join(dropped), "WARN")
            if fresh:
                self.log("Tham số mới của bot (dùng giá trị mặc định): %s" % ", ".join(fresh), "INFO")
        tries = 0
        while True:
            try:
                self.builder = s.builders.get((self.symbol, self.tf)) or s.get_builder(self.symbol, self.tf)
                break
            except FeedError as e:
                tries += 1
                if s.sync or not s.resume or self._stop.is_set() or s._stop.is_set():       # chỉ phiên khôi phục mới chờ mạng; bấm Bắt đầu thì báo lỗi ngay
                    raise _Halt("Không lấy được dữ liệu %s %s: %s" % (self.symbol, self.tf, e), error=True, reason="feed")
                self.message = "Đang chờ dữ liệu %s %s để khôi phục (lần %d): %s" % (self.symbol, self.tf, tries, e)
                if tries in (1, 5, 20) or tries % 60 == 0:
                    self.log(self.message, "WARN")
                if self._stop.wait(min(60.0, s.RETRY_BASE_S * tries)):
                    raise _Halt("Đã dừng khi đang chờ dữ liệu")
        if remote is None:
            self.bot = cls(BotContext(self), self.bot_params)
        else:
            try:
                remote.bind(self.bot_params)
            except Exception as e:                                       # noqa: BLE001
                remote.kill()
                raise _Halt("Không khởi tạo được bot trong tiến trình riêng: %s" % e, error=True, reason="load")
            self.bot = remote
            self.log("Bot %s chạy ở TIẾN TRÌNH RIÊNG (pid %s)" % (self.bot_name, remote.proc.pid))
        self.log("Đã nạp bot %s cho %s %s (%d nến lịch sử). Tham số: %s" % (
            self.bot_name, self.symbol, self.tf, len(self.builder.closed), self.bot_params))
        ok = self._call("on_init", self.bot.on_init)
        if ok is False:
            raise _Halt("Bot trả về False trong on_init -> huỷ chạy", reason="init_failed")

    def _run(self):
        reason = "user"
        try:
            self._setup()
            self.status = "running"
            self.started_at = time.time()
            self.log("Bot bắt đầu chạy: %s | %s %s | chế độ %s" % (self.bot_name, self.symbol, self.tf, self.settings["mode"]))
            while not self._stop.is_set():
                try:
                    item = self._q.get(timeout=0.5)
                except queue.Empty:
                    if self.session._finished or self.session.status in ("error", "stopped"):
                        break
                    self._service_timer()
                    self._drain_updates()
                    continue
                if item[0] == "__params__":
                    self._apply_params_now(item[1])
                    continue
                if item[0] == "__reload__":
                    self._reload_now()
                    continue
                if item[0] == "__wake__":
                    self._drain_updates()
                    continue
                self._on_tick(item[0], item[1])
        except _Halt as h:
            reason = h.reason
            self.message = str(h)
            self.log(str(h), "ERROR" if h.error else "WARN")
            self.status = "error" if h.error else "stopped"
            if h.error:
                self.session.alarm("Bot %s dừng vì lỗi" % self.iid, str(h).strip().splitlines()[0])
        except Exception:
            reason = "error"
            self.message = "Lỗi engine"
            self.log("Lỗi engine:\n" + traceback.format_exc(limit=6), "ERROR")
            self.status = "error"
            self.session.alarm("Bot %s dừng vì lỗi engine" % self.iid, traceback.format_exc(limit=1).strip().splitlines()[-1])
        finally:
            self._shutdown(reason)

    def _call(self, name, fn, *args):
        """Gọi callback của bot: đo thời gian (cbstats), bắt lỗi. bot_error_tolerance>0 = chịu N lỗi/giờ rồi mới tự TẮT bot
        (circuit breaker); =0 = tắt ngay ở lỗi đầu tiên."""
        self._cb_name = name
        self._in_cb = True
        t0 = time.monotonic()
        self.cb_started = t0
        try:
            dbg = getattr(self.session, "debugger", None)           # debugger bot (backtest): pyea/botdebug.py
            if dbg is not None and dbg.path == self.bot_path:
                return dbg.run(name, fn, *args)
            return fn(*args)
        except _Halt:
            raise
        except Exception:
            tb = traceback.format_exc(limit=6)
            self.cbstats.errors += 1
            self.cbstats.last_error = tb.strip().splitlines()[-1]
            tol = int(self.settings.get("bot_error_tolerance") or 0)
            if tol > 0 and name in ("on_tick", "on_bar", "on_trade", "on_timer"):
                now = time.time()
                self.cbstats.error_times = [x for x in self.cbstats.error_times if now - x < 3600] + [now]
                n = len(self.cbstats.error_times)
                if n <= tol:
                    self.log("Lỗi trong bot (%s) - lần %d/%d trong 1 giờ, bot vẫn chạy:\n%s" % (name, n, tol, tb), "ERROR")
                    return None
                raise _Halt("Bot %s lỗi %d lần trong 1 giờ (> %d) -> TỰ ĐỘNG TẮT (circuit breaker):\n%s" % (self.iid, n, tol, tb),
                            error=True, reason="circuit")
            raise _Halt("Lỗi trong bot %s (%s):\n%s" % (self.iid, name, tb), error=True, reason="error")
        finally:
            dt = time.monotonic() - t0
            self.cbstats.record(name, dt)
            if self.trace_on and name != "on_tick":                                  # on_tick mỗi tick -> chỉ ghi khi bot tự gọi api.trace
                self._trace("callback %s xong sau %.1f ms" % (name, dt * 1000.0))
            self.cb_started = 0.0
            self._cb_name = ""
            self._in_cb = False

    # ---- nạp lại MÃ bot khi đang chạy (như biên dịch lại EA): lệnh/vị thế/lệnh chờ giữ nguyên ----
    def code_stale(self):
        """True nếu file bot trên đĩa mới hơn bản đang chạy."""
        m = _mtime(self.bot_path)
        return bool(self.code_mtime and m and m > self.code_mtime + 1e-6)

    def reload_code(self):
        """Gọi từ bất kỳ thread. Nạp lại file bot, giữ nguyên vị thế; lỗi (cú pháp, kiểm tra an toàn, on_init lỗi/False) -> GIỮ BẢN CŨ chạy tiếp.
        Trả về True nếu đã xếp lịch/thực hiện (kết quả ở nhật ký). Bot chưa chạy: lần chạy sau tự nạp mã mới."""
        if self.bot is None or self.status not in ("running", "starting"):
            return False
        if self.session.sync:
            return self._reload_now()
        self._q.put(("__reload__",))
        return True

    def _reload_now(self):
        if getattr(self.bot, "proc", None) is not None:
            self.log("Bot đang chạy ở TIẾN TRÌNH RIÊNG - dừng rồi chạy lại để nạp mã mới (không thể nạp nóng).", "WARN")
            return False
        try:
            cls, _ = load_bot_class(self.bot_path, bool(self.settings.get("dev_mode")))
        except BotLoadError as e:
            self.log("Nạp lại mã bot THẤT BẠI - giữ bản đang chạy:\n%s" % e, "ERROR")
            return False
        inputs = collect_inputs(cls, self.bot_path)
        params = build_params(inputs, self.params)
        old = (self.bot, self.bot_inputs, self.bot_params, self.bot_name)
        self.log("Nạp lại mã bot %s - gọi on_deinit('reload') rồi on_init() với bản mới, lệnh đang mở giữ nguyên" % os.path.basename(self.bot_path))
        try:
            self._cb_name = "on_deinit"
            old[0].on_deinit("reload")
        except Exception:                                          # noqa: BLE001
            self.log("Lỗi trong on_deinit('reload') của bản cũ:\n" + traceback.format_exc(limit=4), "ERROR")
        finally:
            self._cb_name = ""
        self.bot_inputs, self.bot_params, self.bot_name = inputs, params, cls.name or cls.__name__
        try:
            self.bot = cls(BotContext(self), params)
            self._cb_name = "on_init"
            if self.bot.on_init() is False:
                raise RuntimeError("on_init trả về False")
        except Exception as e:                                     # noqa: BLE001
            self.log("Bản mới KHÔNG khởi tạo được (%s) - quay lại bản cũ:\n%s" % (e, traceback.format_exc(limit=4)), "ERROR")
            self.bot, self.bot_inputs, self.bot_params, self.bot_name = old
            try:
                self._cb_name = "on_init"
                self.bot.on_init()
            except Exception:                                      # noqa: BLE001
                self.log("Bản cũ cũng lỗi khi on_init lại:\n" + traceback.format_exc(limit=4), "ERROR")
            return False
        finally:
            self._cb_name = ""
        self.code_mtime = _mtime(self.bot_path)
        self.log("Đã nạp lại mã bot %s (%s)" % (self.bot_name, getattr(cls, "version", "")), "INFO")
        return True

    # ---- đổi tham số khi bot đang chạy (giống MT5: OnDeinit(REASON_PARAMETERS) rồi OnInit; lệnh đang mở giữ nguyên) ----
    def apply_params(self, values):
        """Gọi từ bất kỳ thread. Bot chưa chạy: chỉ ghi nhận cho lần chạy sau. Đang chạy: thực hiện trong thread của bot."""
        self.params = dict(values or {})
        if self.bot is None or self.status not in ("running", "starting") or self.session.sync:
            return
        self._q.put(("__params__", dict(values or {})))

    def _apply_params_now(self, values):
        old = dict(self.bot_params)
        new = build_params(self.bot_inputs, values)
        changed = {k: (old.get(k), new[k]) for k in new if old.get(k) != new[k]}
        if not changed:
            self.params_msg = "Tham số không thay đổi"
            return
        desc = ", ".join("%s: %s → %s" % (k, a, b) for k, (a, b) in changed.items())
        self.log("Đổi tham số (%s) - gọi on_deinit('params') rồi on_init() lại, lệnh đang mở giữ nguyên" % desc)
        try:
            self._cb_name = "on_deinit"
            self.bot.on_deinit("params")
        except Exception:
            self.log("Lỗi trong on_deinit('params'):\n" + traceback.format_exc(limit=4), "ERROR")
        self.bot_params = new
        self.bot._set_params(new)
        ok = self._call("on_init", self.bot.on_init)
        if ok is False:                                           # như INIT_PARAMETERS_INCORRECT: từ chối, quay lại tham số cũ
            self.bot_params = old
            self.bot._set_params(old)
            self._call("on_init", self.bot.on_init)
            self.params = dict(old)
            self.params_msg = "Tham số bị bot từ chối (on_init trả về False) - giữ tham số cũ: " + desc
            self.log(self.params_msg, "WARN")
            self.session.alarm("Tham số bị từ chối: " + self.iid, "Bot trả về False trong on_init với tham số mới -> đã quay lại tham số cũ.", critical=False)
            return
        self.params_msg = "Đã áp dụng: " + desc
        t = self.last_tick
        if t is not None:
            self.session.add_event("note", self.symbol, t.mid, "", 0.0, 0, "bot", "Đổi tham số: " + desc,
                                   {k: "%s → %s" % v for k, v in changed.items()}, None, 0.0, self._context(), self.iid)

    def _on_tick(self, tick, closed):
        if closed is not None:
            self._call("on_bar", self.bot.on_bar, closed)
        self._call("on_tick", self.bot.on_tick, tick)
        self._service_timer()
        self._drain_updates()

    def _shutdown(self, reason):
        if self.bot is not None:
            try:
                self._cb_name = "on_deinit"
                self.bot.on_deinit(reason)
            except Exception:
                self.log("Lỗi trong on_deinit:\n" + traceback.format_exc(limit=4), "ERROR")
            if hasattr(self.bot, "close"):
                self.bot.close()                                          # bot chạy tiến trình riêng: dọn tiến trình con
        if self.own_session:
            self.session.stop(wait=True)
            self.message = self.message or self.session.message
            if self.session.status == "error":
                self.status = "error"
        if self.status not in ("error", "stopped"):
            self.status = "stopped"
        self.log("Bot đã dừng (%s)" % reason)

    # ---- giao dịch cho bot ----
    def _context(self):
        s = self.session
        t = self.last_tick
        b = self.builder
        ind = {}
        with s.lock:
            for name, ser in self.plots.items():
                if ser:
                    ind[name] = next(reversed(ser.values()))

            def cd(c):
                return None if c is None else {"time": c.time, "open": c.open, "high": c.high, "low": c.low, "close": c.close}
            return jsonable({
                "callback": self._cb_name or "(ngoài callback)", "instance": self.iid, "bid": t.bid if t else None,
                "ask": t.ask if t else None, "last_closed": cd(b.closed[-1] if b and b.closed else None),
                "current": cd(b.current if b else None), "indicators": ind, "params": self.bot_params,
                "balance": s.account.balance, "equity": s.account.equity(), "open_positions": len(s.account.positions),
                "mode": s.settings["mode"], "symbol": self.symbol, "timeframe": self.tf})

    def _open(self, side, volume, sl, tp, comment, reason="", details=None, ai=None, request_id=""):
        res = self.session.send_order(self.symbol, side, volume, sl, tp, comment, self.iid, reason, details, ai,
                                      self._context(), request_id)
        if self.trace_on:
            self._trace("%s %s sl=%s tp=%s -> %s: %s" % (side, volume, sl, tp, res.retcode, res.message))
        return res

    def _pending(self, side, kind, volume, price, stop_price, sl, tp, comment, expiration, reason, details, ai):
        res = self.session.place_pending(self.symbol, side, kind, volume, price, stop_price, sl, tp, comment, self.iid,
                                         expiration, reason, details, ai, self._context())
        if self.trace_on:
            self._trace("%s_%s %s @%s -> %s: %s" % (side, kind, volume, price, res.retcode, res.message))
        return res

    def _close_position(self, pos_id, source="bot", reason="", details=None, ai=None, volume=None):
        res = self.session.close_position(pos_id, source, reason, details, ai, self._context(), volume)
        if self.trace_on:
            self._trace("close #%s vol=%s (%s) -> %s: %s" % (pos_id, volume, reason, getattr(res, "retcode", "?"), getattr(res, "message", "")))
        return res

    # ---- Trace: bật/tắt trên thẻ bot; dòng đi vào nhật ký (mức TRACE) + bộ đệm cho gói chẩn đoán ----
    def set_trace(self, on):
        on = bool(on)
        if on != self.trace_on:
            self.trace_on = on
            self.log("Trace %s" % ("BẬT - ghi vết callback, lệnh và api.trace()" if on else "TẮT"), "INFO")

    def _trace(self, text, values=None):
        if not self.trace_on:
            return
        line = "[trace %s] %s" % (self._cb_name or "-", str(text)[:300])
        if values:
            line += " | " + ", ".join("%s=%s" % (k, _fmt_trace(v)) for k, v in list(values.items())[:20])
        self.trace_buf.append((time.time(), line))
        self.log(line, "TRACE")

    def _note(self, text, price, side, details):
        t = self.last_tick
        if t is None:
            return
        self.session.add_event("note", self.symbol, float(price) if price else t.mid, side or "", 0.0, 0, "bot",
                               str(text)[:400], details, None, 0.0, self._context(), self.iid)

    def _plot(self, name, value, t):
        if value is None:
            return
        if t is None:
            if self.builder is None or self.builder.current is None:
                return
            t = self.builder.current.time
        with self.session.lock:
            series = self.plots.setdefault(str(name), OrderedDict())
            series[t] = float(value)
            while len(series) > self.plot_cap:
                series.popitem(last=False)

    # ---- thông tin ----
    def summary(self):
        s = self.session
        with s.lock:
            pos = [p for p in s.account.positions.values() if p.owner == self.iid] if s.account else []
            closed = [t for t in (s.account.trades if s.account else []) if t.owner == self.iid]
            return {"iid": self.iid, "bot": self.bot_name, "bot_path": self.bot_path, "symbol": self.symbol, "tf": self.tf,
                    "status": self.status, "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message,
                    "bot_status": self.bot_status, "params_msg": self.params_msg, "open": len(pos),
                    "pending": sum(1 for o in (s.account.pending.values() if s.account else []) if o.owner == self.iid),
                    "profit": sum(p.profit for p in pos) + sum(t.profit for t in closed), "trades": len(closed),
                    "hung": self.hung, "timer": self._timer_iv, "trace": self.trace_on,
                    "code_stale": self.code_stale(),
                    "metrics": dict(trade_stats(closed, s.account.start_balance if s.account else 0.0),
                                    callbacks=self.cbstats.summary(), errors=self.cbstats.errors,
                                    last_error=self.cbstats.last_error)}

    def snapshot(self, chart_bars=240, max_trades=30, max_events=250):
        """Ảnh chụp kiểu cũ: phiên + biểu đồ của mã/khung của bot này (dùng cho AI market_context, test)."""
        snap = self.session.snapshot()
        snap.update({"bot": self.bot_name, "symbol": self.symbol, "timeframe": self.tf, "bot_status": self.bot_status,
                     "status": self.status if self.own_session or self.status in ("error",) else snap["status"],
                     "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message or snap["message"],
                     "candles": [], "plots": {}, "events": []})
        t = self.last_tick
        if t is not None:
            snap.update({"bid": t.bid, "ask": t.ask, "tick_time": t.time})
        ch = self.session.chart(self.symbol, self.tf, chart_bars, max_events)
        if ch:
            snap["candles"] = ch["candles"]
            snap["events"] = ch["events"]
            with self.session.lock:
                times = {c.time for c in ch["candles"]}
                snap["plots"] = {n: [(a, v) for a, v in s.items() if a in times] for n, s in self.plots.items()}
        snap["ready"] = bool(snap.get("ready") and t is not None and ch)
        return snap
