"""Kết nối MT5 MỘT BƯỚC (không cài thêm gì): người dùng chỉ nhập login + mật khẩu + tên server của tài khoản MT4/MT5 (cộng token MetaApi - dán MỘT LẦN).
App tự làm phần còn lại trên dịch vụ đám mây MetaApi (nơi MT5 chạy thật): tìm tài khoản đã có (tránh tạo trùng) hoặc tạo mới, Deploy,
đợi trạng thái CONNECTED, rồi đặt sẵn nguồn «metaapi» + account id + region trong Cài đặt. Mật khẩu MT KHÔNG được lưu trong app - chỉ gửi tới MetaApi.

Đối chiếu tài liệu chính thức MetaApi (đã đọc, KHÔNG chạy được với dịch vụ thật vì sandbox chặn):
  POST {prov}/users/current/accounts        header auth-token + transaction-id (32 ký tự ngẫu nhiên); body name/server/magic/platform/login/password;
                                            201 {id,state} | 202 {message} + Retry-After => gửi LẠI cùng transaction-id | 400 lỗi (E_AUTH, E_SRV_NOT_FOUND, E_SERVER_TIMEZONE)
  GET  {prov}/users/current/accounts?query= tìm theo _id/name/server/login; trả mảng [{_id, login, server, state, connectionStatus, region}]
  GET  {prov}/users/current/accounts/{id}   trạng thái; POST .../{id}/deploy -> 204 (bỏ qua nếu đã deploy)
CHƯA KIỂM CHỨNG VỚI METAAPI THẬT (nói thẳng): test dùng máy chủ giả đúng theo tài liệu trên; các chỗ đoán được đánh dấu `# CHƯA XÁC MINH`.
Chi phí/giới hạn do MetaApi quyết định (có gói miễn phí/dùng thử, sau đó tính phí) - xem docs/MT5_QUICK.md."""
import json
import re
import time
import uuid

from .feeds import FeedError, HttpError, http_json

PROV_URL = "https://mt-provisioning-api-v1.agiliumtrade.agiliumtrade.ai"
DEFAULT_REGION = "new-york"
PLATFORMS = ("mt5", "mt4")
MAGIC = 0                       # magic 0 = lệnh của app không bị xếp nhầm là «EA khác» (docs/MT5_GAPS.md mục nguồn gốc lệnh)  # CHƯA XÁC MINH: MetaApi nhận 0
CONNECTED = "CONNECTED"


class QuickError(Exception):
    """Lỗi đã được dịch sang tiếng Việt. `code`: E_AUTH | E_SRV_NOT_FOUND | E_SERVER_TIMEZONE | token | quyền | tham số | mạng | giới hạn | máy chủ | đã tồn tại ... ;
    `result`: kết quả một phần (vd đã có account id nhưng chưa CONNECTED) để giao diện vẫn lưu được."""

    def __init__(self, msg, code="", result=None):
        Exception.__init__(self, msg)
        self.code, self.result = code, result


# ----------------------------------------------------------------------------------------------- kiểm đầu vào
def problems(login, password, server, token, platform="mt5"):
    """Danh sách lỗi nhập liệu (rỗng = hợp lệ). Không gọi mạng."""
    out = []
    login = str(login or "").strip()
    if not re.fullmatch(r"\d{3,12}", login):
        out.append("Login MT5 chỉ gồm chữ số (vd 12345678).")
    if not str(password or ""):
        out.append("Chưa nhập mật khẩu MT5 (có thể dùng mật khẩu CHỈ-XEM «investor» để chỉ xem, không đặt lệnh).")
    server = str(server or "").strip()
    if not server:
        out.append("Chưa nhập tên server (vd Exness-MT5Real8, ICMarketsSC-Demo) - xem trong MT5: Tệp → Đăng nhập, hoặc email broker gửi.")
    elif re.search(r"[\s/\\:]", server) or len(server) > 80:
        out.append("Tên server có ký tự lạ: chỉ nhập TÊN server (vd ICMarketsSC-Demo), không nhập địa chỉ IP/cổng.")
    t = str(token or "").strip()
    if len(t) < 20 or re.search(r"\s", t):
        out.append("Chưa có token MetaApi hợp lệ: đăng ký miễn phí ở metaapi.cloud → Tokens → dán vào đây (chỉ cần một lần).")
    if platform not in PLATFORMS:
        out.append("Nền tảng phải là mt5 hoặc mt4.")
    return out


# ----------------------------------------------------------------------------------------------- dịch lỗi
def _body(e):
    try:
        d = json.loads(e.body or "{}")
        return d if isinstance(d, dict) else {}
    except ValueError:
        return {}


def _code_of(d):
    det = d.get("details")
    if isinstance(det, str):
        return det
    if isinstance(det, dict):
        return str(det.get("code") or "")
    return ""


def _similar_servers(d, limit=8):
    det = d.get("details")
    sbb = det.get("serversByBrokers") if isinstance(det, dict) else None
    names = []
    if isinstance(sbb, dict):
        for lst in sbb.values():
            names += [str(x) for x in (lst if isinstance(lst, list) else [lst])]
    elif isinstance(sbb, list):
        names = [str(x) for x in sbb]
    return names[:limit]


def explain_http(e, step="gọi MetaApi"):
    """HttpError -> QuickError tiếng Việt, kèm gợi ý hành động cụ thể."""
    d = _body(e)
    code, msg, st = _code_of(d), str(d.get("message") or "").strip(), e.status
    if code == "E_SRV_NOT_FOUND":
        sim = _similar_servers(d)
        return QuickError("MetaApi không tìm thấy server này. Kiểm tra lại TÊN server (đúng từng ký tự, phân biệt Real/Demo)."
                          + ("\nGợi ý tên gần giống: " + ", ".join(sim) if sim else ""), code)
    if code == "E_AUTH":
        return QuickError("Broker từ chối đăng nhập: sai login, mật khẩu hoặc server. Thử đăng nhập cùng thông tin đó trong MT5 để chắc chắn "
                          "(đúng loại mật khẩu: giao dịch hay investor; tài khoản Real/Demo đúng server).", code)
    if code == "E_SERVER_TIMEZONE":
        return QuickError("MetaApi chưa tự dò được cấu hình của broker này. Thử lại sau ít phút; nếu vẫn lỗi, broker cần được thiết lập thủ công "
                          "trên web MetaApi (provisioning profile) - app chưa làm phần này.", code)
    if code == "E_RESOURCE_SLOTS":
        return QuickError("Tài khoản này cần thêm tài nguyên (resource slot, tính phí) trên MetaApi - hãy tạo/nâng cấp trên web metaapi.cloud.", code)
    if st == 401:
        return QuickError("Token MetaApi sai hoặc hết hạn. Vào metaapi.cloud → Tokens → tạo token mới rồi dán lại.", "token")
    if st == 403:
        return QuickError("Token MetaApi không đủ quyền hoặc gói đã hết hạn mức (%s)." % (msg or "403"), "quyền")
    if st == 400:
        return QuickError("MetaApi từ chối dữ liệu nhập: %s" % (msg or e.body[:160] or "không rõ"), "tham số")
    if st == 404:
        return QuickError("Không tìm thấy tài khoản/tài nguyên trên MetaApi khi %s." % step, "không thấy")
    if st == 429:
        return QuickError("MetaApi đang giới hạn tốc độ. Đợi một phút rồi thử lại.", "giới hạn")
    if st >= 500:
        return QuickError("Máy chủ MetaApi đang lỗi tạm thời (HTTP %s). Thử lại sau." % st, "máy chủ")
    return QuickError("MetaApi trả lỗi HTTP %s khi %s: %s" % (st, step, msg or (e.body or "")[:160]), "http")


# ----------------------------------------------------------------------------------------------- gọi API
class _Api:
    def __init__(self, token, prov_url=PROV_URL, timeout=30, http=http_json):
        self.token, self.base, self.timeout, self.http = str(token).strip(), prov_url.rstrip("/"), timeout, http

    def call(self, method, path, params=None, body=None, tx=None, out_headers=None, step="gọi MetaApi"):
        headers = {"auth-token": self.token, "Accept": "application/json"}
        if tx:
            headers["transaction-id"] = tx
        try:
            return self.http(self.base + path, params, headers=headers, method=method, timeout=self.timeout, body=body, out_headers=out_headers)
        except HttpError as e:
            raise explain_http(e, step)
        except FeedError as e:
            raise QuickError("Lỗi mạng khi %s: %s" % (step, e), "mạng")


def _same(a, b):
    return str(a or "").strip().lower() == str(b or "").strip().lower()


def find_existing(api, login, server):
    """Tài khoản đã có trên MetaApi cùng login + server (tránh tạo trùng = tránh tốn thêm phí). None nếu không có."""
    d = api.call("GET", "/users/current/accounts", {"query": str(login), "limit": 100}, step="tìm tài khoản đã có")
    items = d if isinstance(d, list) else (d.get("items") if isinstance(d, dict) else None) or []
    for a in items:
        if isinstance(a, dict) and _same(a.get("login"), login) and _same(a.get("server"), server):
            return a
    return None


def create_account(api, login, password, server, platform="mt5", name="", keywords=None, progress=None, wait=60.0, retries=8,
                   sleep=time.sleep):
    """POST tạo tài khoản. 202 (đang tự dò cấu hình broker) -> đợi Retry-After rồi gửi LẠI cùng transaction-id. Trả (id, state)."""
    tx = uuid.uuid4().hex                                          # 32 ký tự ngẫu nhiên đúng yêu cầu tài liệu
    body = {"login": str(login).strip(), "password": str(password), "name": name or ("PyEA %s" % str(login).strip()), "server": str(server).strip(),
            "platform": platform, "magic": MAGIC}
    if keywords:
        body["keywords"] = list(keywords)
    for i in range(retries + 1):
        oh = {}
        d = api.call("POST", "/users/current/accounts", body=body, tx=tx, out_headers=oh, step="tạo tài khoản")
        if isinstance(d, dict) and d.get("id"):
            return str(d["id"]), str(d.get("state") or "")
        # 202: chưa có id; có `message` (đang dò cấu hình broker)
        try:
            ra = float(oh.get("retry-after") or 0)
        except ValueError:
            ra = 0.0
        ra = min(max(ra, 2.0), wait)
        if progress:
            progress("MetaApi đang tự dò cấu hình broker... đợi %d giây (lần %d)" % (ra, i + 1))
        sleep(ra)
    raise QuickError("MetaApi vẫn đang dò cấu hình broker sau %d lần chờ. Thử lại sau vài phút (bấm Kết nối lần nữa - app dùng lại tài khoản đã tạo)." % (retries + 1), "đang xử lý")


def get_account(api, acc_id):
    d = api.call("GET", "/users/current/accounts/%s" % acc_id, step="đọc trạng thái tài khoản")
    return d if isinstance(d, dict) else {}


def deploy(api, acc_id):
    api.call("POST", "/users/current/accounts/%s/deploy" % acc_id, step="bật (deploy) tài khoản")      # 204; đã deploy thì MetaApi bỏ qua


def wait_connected(api, acc_id, progress=None, timeout=240.0, interval=5.0, sleep=time.sleep, now=time.monotonic):
    """Đợi state=DEPLOYED và connectionStatus=CONNECTED. Trả (thông tin tài khoản, đã_nối: bool)."""
    t0, info = now(), {}
    while True:
        info = get_account(api, acc_id)
        st, cs = str(info.get("state") or ""), str(info.get("connectionStatus") or "")
        if st == "DEPLOYED" and cs == CONNECTED:
            return info, True
        if progress:
            progress("Đang đợi MT5 trên đám mây nối với broker... (trạng thái %s / %s)" % (st or "?", cs or "?"))
        if now() - t0 >= timeout:
            return info, False
        sleep(interval)


def connect(login, password, server, token, platform="mt5", progress=None, prov_url=PROV_URL, timeout=240.0, verify=True, client_url="",
            http=http_json, sleep=time.sleep, now=time.monotonic, keywords=None):
    """Toàn bộ quy trình một bước. Trả dict: account_id, region, state, connection, connected, reused, info(thông tin tài khoản MT nếu đọc được), note.
    Ném QuickError (tiếng Việt) nếu không tạo/đọc được tài khoản. Nếu đã có account id nhưng chưa CONNECTED -> KHÔNG ném lỗi: connected=False + note."""
    bad = problems(login, password, server, token, platform)
    if bad:
        raise QuickError("\n".join(bad), "nhập liệu")
    say = progress or (lambda *_: None)
    api = _Api(token, prov_url, http=http)
    say("Đang tìm tài khoản %s trên MetaApi..." % login)
    acc = find_existing(api, login, server)
    reused = acc is not None
    if reused:
        acc_id = str(acc.get("_id") or acc.get("id") or "")
        state = str(acc.get("state") or "")
        say("Đã có tài khoản này trên MetaApi - dùng lại (không tạo trùng).")
        if state == "DRAFT":
            raise QuickError("Tài khoản này trên MetaApi đang ở trạng thái DRAFT (chưa có mật khẩu). Xoá nó trên web metaapi.cloud rồi bấm Kết nối lại.", "DRAFT")
    else:
        say("Đang tạo tài khoản MT trên MetaApi (có thể mất 1-2 phút nếu broker mới)...")
        acc_id, state = create_account(api, login, password, server, platform, progress=say, sleep=sleep, keywords=keywords)
    if not acc_id:
        raise QuickError("MetaApi không trả về mã tài khoản.", "http")
    if state != "DEPLOYED":
        say("Đang bật (deploy) tài khoản...")
        deploy(api, acc_id)
    info, ok = wait_connected(api, acc_id, say, timeout=timeout, sleep=sleep, now=now)
    res = {"account_id": acc_id, "region": str(info.get("region") or "") or DEFAULT_REGION, "state": str(info.get("state") or state),
           "connection": str(info.get("connectionStatus") or ""), "connected": ok, "reused": reused, "info": None, "note": ""}
    if not info.get("region"):
        res["note"] += "MetaApi không báo region - dùng mặc định %s (nếu lỗi 404, đổi ô «MetaApi region» theo web MetaApi). " % DEFAULT_REGION   # CHƯA XÁC MINH: trường region có trong GET tài khoản
    if not ok:
        res["note"] += ("Đã tạo/bật tài khoản nhưng MT5 chưa nối được với broker trong %d giây (trạng thái: %s). Thường do sai mật khẩu/server hoặc broker đóng cửa; "
                        "cài đặt vẫn được lưu - kiểm tra lại thông tin rồi bấm Kết nối lại." % (timeout, res["connection"] or "không rõ"))
        return res
    if verify:
        try:
            from .bridges import MetaApiBackend
            kw = {"client_url": client_url, "data_url": client_url} if client_url else {}
            res["info"] = MetaApiBackend(token, acc_id, res["region"], **kw).account()
        except Exception as e:                                       # không bắt buộc: client API đôi khi chưa đồng bộ xong ngay sau khi nối
            res["note"] += "Đã nối nhưng chưa đọc được số dư ngay (%s) - thử lại sau ít phút." % str(e)[:120]
    return res


def apply_settings(settings, result, token):
    """Bản sao `settings` đã đặt nguồn MetaApi theo kết quả (KHÔNG chứa mật khẩu MT)."""
    s = dict(settings or {})
    s.update({"exchange": "metaapi", "metaapi_token": str(token).strip(), "metaapi_account": result["account_id"], "metaapi_region": result["region"]})
    return s


def summary(result):
    """Văn bản kết quả cho người dùng."""
    lines = []
    lines.append(("✓ ĐÃ NỐI" if result.get("connected") else "! ĐÃ LƯU nhưng CHƯA NỐI") + " - tài khoản MetaApi %s (%s)%s" % (
        result["account_id"], result["region"], " · dùng lại tài khoản đã có" if result.get("reused") else ""))
    inf = result.get("info")
    if inf:
        lines.append("Số dư %s %s · vốn %s · đòn bẩy 1:%s" % (inf.get("balance"), inf.get("currency", ""), inf.get("equity"), int(inf.get("leverage") or 0)))
    if result.get("note"):
        lines.append(result["note"].strip())
    lines.append("Nguồn thị trường đã đặt = metaapi. Bấm «Kết nối» ở màn hình chính để chạy. Luôn thử DEMO trước khi dùng tiền thật.")
    return "\n\n".join(lines)
