"""Điều khoản sử dụng (EULA), chính sách riêng tư, hướng dẫn nhanh lần đầu và «cài đặt mẫu an toàn». KHÔNG import Kivy.

LƯU Ý: các văn bản dưới đây là BẢN MẪU viết đúng theo cách app thực sự hoạt động (dữ liệu lưu cục bộ, không máy chủ của tác giả). Chúng KHÔNG phải tư vấn
pháp lý: trước khi phân phối thương mại/Play Store hãy để luật sư rà soát, điền tên pháp nhân, địa chỉ liên hệ, luật áp dụng. Cảnh báo rủi ro giao dịch ở pyea/risk.py.
"""
import time

LEGAL_VERSION = 1

EULA_TITLE = "Điều khoản sử dụng"
EULA_TEXT = """ĐIỀU KHOẢN SỬ DỤNG PyEA Runner  (bản mẫu - cần luật sư rà soát trước khi phân phối thương mại)

1. Bản chất phần mềm. PyEA Runner là công cụ chạy bot giao dịch và biểu đồ trên thiết bị của bạn. Phần mềm KHÔNG phải tư vấn đầu tư, không đảm bảo lợi nhuận, và không phải sàn giao dịch hay môi giới.

2. Rủi ro. Giao dịch tài chính (đặc biệt có đòn bẩy) có thể mất toàn bộ vốn. Kết quả backtest/paper KHÔNG đảm bảo kết quả thật: dữ liệu, độ trượt giá, phí và thanh khoản thật khác mô phỏng. Bạn tự chịu trách nhiệm về mọi lệnh do bạn, bot của bạn hoặc AI tạo ra.

3. Bot và mã tuỳ chỉnh. Bot là mã Python chạy với quyền của app. Chỉ nạp bot bạn tin tưởng và đã đọc. Tác giả không chịu trách nhiệm về mã do bạn hoặc bên thứ ba viết.

4. Tài khoản sàn và khoá API. Bạn dùng khoá API của riêng mình; nên tạo khoá CHỈ có quyền cần thiết, KHÔNG bật quyền rút tiền, và thử trên tài khoản demo/testnet trước. Khoá lưu trên thiết bị của bạn (có thể mã hoá bằng Android Keystore nếu bạn bật).

5. Dịch vụ bên thứ ba. App gọi API của sàn/nhà cung cấp dữ liệu/AI do BẠN chọn. Họ có điều khoản riêng; việc họ lỗi, đổi API, giới hạn tốc độ hoặc ngừng dịch vụ nằm ngoài kiểm soát của tác giả.

6. Không bảo hành. Phần mềm được cung cấp «NGUYÊN TRẠNG», không bảo hành rõ ràng hay ngụ ý (gồm tính phù hợp cho mục đích cụ thể, không có lỗi, hoạt động liên tục 24/7). Trong phạm vi pháp luật cho phép, tác giả không chịu trách nhiệm về thiệt hại gián tiếp hoặc mất mát tài chính phát sinh từ việc sử dụng.

7. Giấy phép. Quyền sử dụng/sao chép/phân phối do chủ sở hữu mã nguồn quyết định (xem tệp LICENSE đi kèm). [Điền: tên chủ sở hữu, luật áp dụng, liên hệ.]

8. Thay đổi. Điều khoản có thể thay đổi; khi nội dung đổi, app sẽ hỏi lại bạn đồng ý.
"""

PRIVACY_TITLE = "Chính sách riêng tư"
PRIVACY_TEXT = """CHÍNH SÁCH RIÊNG TƯ PyEA Runner  (bản mẫu - cần rà soát trước khi phân phối thương mại / theo GDPR nếu có người dùng EU)

Dữ liệu lưu TRÊN THIẾT BỊ của bạn: cài đặt, khoá API (che khi xuất/gửi), bot, lịch sử lệnh, nhật ký, báo cáo, đối tượng vẽ. Tác giả KHÔNG vận hành máy chủ thu dữ liệu của app và không nhận bất cứ thứ gì mặc định.

App chỉ gửi dữ liệu ra ngoài khi BẠN cấu hình/bấm:
 • Tới sàn/nhà cung cấp dữ liệu bạn chọn: lệnh, truy vấn giá, số dư (kèm khoá API của bạn).
 • Tới nhà cung cấp AI bạn chọn (nếu bật Trợ lý/AI): nội dung câu hỏi + dữ liệu thị trường/lệnh liên quan; khoá API, mã bí mật được che trước khi gửi.
 • Kiểm tra cập nhật (mặc định TẮT): hỏi API GitHub của kho bạn nhập; chỉ gửi yêu cầu HTTPS thông thường (địa chỉ IP của bạn hiển thị với GitHub).
 • Gửi báo lỗi tự động (mặc định TẮT): chỉ khi bạn bật và nhập địa chỉ máy chủ nhận; nội dung là nhật ký lỗi đã che bí mật, phiên bản app, hệ điều hành; KHÔNG gồm khoá API, số dư hay lịch sử lệnh.
 • Nút «Gửi/Sao chép báo lỗi» và «Gói chẩn đoán»: dữ liệu đi qua kênh bạn chọn (Zalo, email...). Bạn xem được nội dung trước khi gửi.

Không có telemetry/phân tích sử dụng ngầm. Xoá dữ liệu: gỡ app hoặc xoá dữ liệu ứng dụng trong Cài đặt Android. Quyền của người dùng EU (truy cập, xoá, rút đồng ý): vì dữ liệu nằm trên thiết bị bạn nên bạn tự thực hiện được; liên hệ chủ sở hữu mã nguồn cho yêu cầu khác. [Điền: tên/địa chỉ liên hệ.]
"""

ONBOARDING = (
    ("1/6 · Chào mừng", "PyEA Runner chạy bot giao dịch (EA) và xem biểu đồ trên điện thoại.\n\nMặc định app ở chế độ PAPER (giao dịch giả lập, không dùng tiền thật). "
                        "Đừng chuyển sang LIVE trước khi bạn đã thử bot ở paper và demo/testnet."),
    ("2/6 · Chọn nguồn giá", "Tab «Cài đặt» → «Nguồn thị trường / sàn». «simulated» chạy ngay không cần tài khoản. Muốn giá thật: chọn Binance/OANDA/Capital.com... rồi dán khoá API vào mục API của sàn đó "
                             "(ưu tiên khoá demo/testnet, KHÔNG bật quyền rút tiền)."),
    ("3/6 · Kết nối & xem giá", "Tab «Thị trường» → KẾT NỐI. Danh sách mã (Market Watch) hiện giá bid/ask. Chạm vào mã để mở biểu đồ; kéo = lướt, chụm = thu/phóng, nút «Vẽ» = công cụ vẽ, «＋» = đặt lệnh ngay trên biểu đồ."),
    ("4/6 · Gắn bot", "Tab «Bot» → chọn bot mẫu (vd ma_cross.py) → gắn vào mã + khung thời gian → Chạy. Bot vào/ra lệnh theo luật của nó; chạm chấm ▲▼ trên biểu đồ để xem LÝ DO của từng lệnh."),
    ("5/6 · Thử trước khi chạy", "Tab «Backtest»: chạy bot trên dữ liệu lịch sử (có chế độ xem từng nến, báo cáo HTML, nhật ký debug). Kết quả backtest chỉ để tham khảo, không đảm bảo kết quả thật."),
    ("6/6 · An toàn", "• Đặt «Dừng bot nếu lỗ quá (%)» trong Cài đặt.\n• Dùng SL/TP; bật «SL/TP native» nếu sàn hỗ trợ để sàn canh khi app tắt.\n• Cài đặt → Sao lưu định kỳ.\n• Có sự cố: Nhật ký → Kiểm tra hệ thống, hoặc hỏi Trợ lý."),
)

# Cài đặt mẫu cho người mới: an toàn tuyệt đối (giả lập, không tiền thật). Chỉ ghi đè các khoá này, giữ nguyên phần còn lại.
SAMPLE_SETTINGS = {"mode": "paper", "exchange": "simulated", "watchlist": "BTCUSD,ETHUSD,EURUSD,XAUUSD", "initial_balance": 10000.0, "leverage": 1.0,
                   "max_loss_pct": 10.0, "close_on_stop": True, "read_only": False}


def sample_patch(settings):
    """Bản sao `settings` đã áp cài đặt mẫu an toàn (không sửa dict gốc)."""
    out = dict(settings or {})
    out.update(SAMPLE_SETTINGS)
    return out


def needed(prefs, version=LEGAL_VERSION):
    try:
        return int((prefs or {}).get("legal_ack", 0)) < version
    except (TypeError, ValueError):
        return True


def acknowledge(prefs, version=LEGAL_VERSION):
    prefs["legal_ack"] = version
    prefs["legal_ack_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    return prefs
