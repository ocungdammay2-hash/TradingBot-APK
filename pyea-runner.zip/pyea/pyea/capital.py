"""CAPITAL.COM (CFD: forex, vàng, chỉ số, crypto...) qua REST công khai - có môi trường DEMO.

Tên đường dẫn/trường dựa trên TÀI LIỆU open-api.capital.com (đọc ngày 2026-11-03): POST /api/v1/session (header X-CAP-API-KEY + body identifier/password;
token CST và X-SECURITY-TOKEN trả ở HEADER, hết hạn sau 10 phút không dùng) · GET /markets/{epic} · GET /prices/{epic} (resolution MINUTE..WEEK, max<=1000)
· POST/GET/PUT/DELETE /positions · POST/GET/PUT/DELETE /workingorders · GET /confirms/{dealReference} · GET /accounts.
CHƯA chạy với sàn thật: test dùng máy chủ giả viết theo đúng tài liệu nên chỉ chứng minh mã nhất quán với tài liệu. Việc ĐẦU TIÊN khi có tài khoản demo:
`python -m pyea.selfcheck --exchange capital --settings capital.json` (chỉ đọc) rồi thêm `--trade --yes`.

Giới hạn đã biết (nói thẳng, không giấu):
  * Vỏ coi tài khoản là netting (một hướng/mã). Đóng MỘT PHẦN vị thế: API DELETE đóng cả vị thế -> app báo lỗi rõ thay vì đoán (đóng hết thì được).
  * Xoá SL/TP của vị thế: gửi `null` (tài liệu không nói rõ) - kiểm trên demo.
  * Lịch sử tài khoản kiểu MT5 chưa có (API chỉ có /history/transactions không kèm giá khớp).
"""
import re
import threading
import time

from .broker import BrokerError, Fill
from .feeds import FeedError, HttpError, http_json, history_resampled, resolve_base, tf_seconds
from .protection import ProtectionAPI
from .ratelimit import limiter_for
from .sdk import Candle, Tick

_RES = {"1m": "MINUTE", "5m": "MINUTE_5", "15m": "MINUTE_15", "30m": "MINUTE_30", "1h": "HOUR", "4h": "HOUR_4", "1d": "DAY", "1w": "WEEK"}
SESSION_TTL = 9 * 60.0                      # tài liệu: hết hạn sau 10 phút không dùng -> làm mới sớm hơn một chút


def _utc(ts):
    """'2022-04-06T13:18:00' (UTC) -> epoch."""
    import calendar
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)", str(ts or ""))
    if not m:
        return 0.0
    return float(calendar.timegm(tuple(int(g) for g in m.groups())))


def _fmt_utc(epoch):
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(float(epoch)))


class CapitalClient:
    """Phiên đăng nhập dùng chung giữa feed và broker (một tài khoản = một phiên, tự đăng nhập lại khi hết hạn)."""

    def __init__(self, base, api_key, identifier, password, account=""):
        if not (api_key and identifier and password):
            raise BrokerError("Thiếu Capital.com API key / email / mật khẩu API key")
        self.base = base.rstrip("/")
        self.key, self.ident, self.pw, self.account = api_key.strip(), identifier.strip(), password, (account or "").strip()
        self.limiter = limiter_for("capital", self.base)
        self._tok = None
        self._at = 0.0
        self._lock = threading.RLock()
        self.info = {}

    def _login(self):
        h = {}
        d = http_json(self.base + "/api/v1/session", headers={"X-CAP-API-KEY": self.key, "Content-Type": "application/json"},
                      method="POST", body={"identifier": self.ident, "password": self.pw, "encryptedPassword": False}, timeout=15,
                      limiter=self.limiter, cost=1, out_headers=h)
        cst, sec = h.get("cst"), h.get("x-security-token")
        if not cst or not sec:
            raise BrokerError("Capital.com không trả CST/X-SECURITY-TOKEN: %s" % str(d)[:160])
        self._tok, self._at, self.info = {"CST": cst, "X-SECURITY-TOKEN": sec}, time.monotonic(), d if isinstance(d, dict) else {}
        cur = str(self.info.get("currentAccountId") or "")
        if self.account and cur and self.account != cur:
            http_json(self.base + "/api/v1/session", headers=self._headers(), method="PUT", body={"accountId": self.account},
                      timeout=15, limiter=self.limiter, cost=1)
            self.info["currentAccountId"] = self.account

    def _headers(self):
        h = dict(self._tok or {})
        h["X-CAP-API-KEY"] = self.key
        h["Content-Type"] = "application/json"
        return h

    def call(self, method, path, params=None, body=None, timeout=15):
        """Gọi API; tự đăng nhập, và nếu bị 401 (phiên hết hạn) thì đăng nhập lại ĐÚNG MỘT lần rồi gửi lại (401 = chưa xử lý nên gửi lại lệnh là an toàn)."""
        try:
            with self._lock:
                if self._tok is None or time.monotonic() - self._at > SESSION_TTL:
                    self._login()
            for attempt in (0, 1):
                try:
                    r = http_json(self.base + "/api/v1" + path, params, headers=self._headers(), method=method, body=body, timeout=timeout,
                                  limiter=self.limiter, cost=1)
                    self._at = time.monotonic()
                    return r
                except HttpError as e:
                    if e.status == 401 and attempt == 0:
                        with self._lock:
                            self._login()
                        continue
                    raise
        except HttpError as e:
            raise BrokerError("Capital.com HTTP %s: %s" % (e.status, str(getattr(e, "body", "") or e)[:200]))
        except FeedError as e:
            raise BrokerError(str(e))


class CapitalFeed:
    def __init__(self, client):
        self.c = client
        self._symbols = None

    def _get(self, path, params=None):
        try:
            return self.c.call("GET", path, params)
        except BrokerError as e:
            raise FeedError(str(e))

    def symbols(self):
        if self._symbols is None:
            d = self._get("/marketnavigation")
            self._symbols = sorted({str(n.get("name") or n.get("id")) for n in (d.get("nodes") or [])}) if isinstance(d, dict) else []
        return self._symbols

    def tick(self, symbol):
        d = self._get("/markets/%s" % symbol)
        try:
            sn = d["snapshot"]
            return Tick(symbol, time.time(), float(sn["bid"]), float(sn["offer"]), tradeable=str(sn.get("marketStatus", "TRADEABLE")).upper() == "TRADEABLE")
        except (KeyError, ValueError, TypeError):
            raise FeedError("Phản hồi giá Capital.com không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        res = _RES.get(tf)
        if not res:
            return history_resampled(self, _RES, symbol, tf, n, end)
        params = {"resolution": res, "max": max(2, min(int(n), 1000))}
        if end is not None:
            params["to"] = _fmt_utc(end)
        d = self._get("/prices/%s" % symbol, params)
        out = []
        for p in (d.get("prices") if isinstance(d, dict) else None) or []:
            try:
                o, h, l, c = (p[k] for k in ("openPrice", "highPrice", "lowPrice", "closePrice"))
                mid = lambda q: (float(q["bid"]) + float(q["ask"])) / 2.0      # noqa: E731
                out.append(Candle(_utc(p["snapshotTimeUTC"]), mid(o), mid(h), mid(l), mid(c), float(p.get("lastTradedVolume") or 0)))
            except (KeyError, ValueError, TypeError):
                continue
        return sorted(out, key=lambda x: x.time)

    def close(self):
        pass


class CapitalBroker(ProtectionAPI):
    supports_short = True
    netting = True
    PROT_STYLE = "position"
    native_pending = {"limit", "stop"}
    CONFIRM_TRIES, CONFIRM_WAIT = 6, 0.4

    def __init__(self, client):
        self.c = client
        self._lv = {}

    # ---- tiện ích ----
    def _confirm(self, ref):
        """Đợi sàn xác nhận deal (GET /confirms/{dealReference}). Trả dict xác nhận; lỗi/từ chối -> BrokerError."""
        last = None
        for i in range(self.CONFIRM_TRIES):
            try:
                d = self.c.call("GET", "/confirms/%s" % ref)
            except BrokerError as e:
                last = e                                         # 404 khi sàn chưa kịp ghi: đợi rồi thử lại
                time.sleep(self.CONFIRM_WAIT)
                continue
            st = str(d.get("dealStatus") or d.get("status") or "").upper()
            if st in ("ACCEPTED", "OPEN", "AMENDED", "DELETED", "CLOSED"):
                return d
            if st in ("REJECTED", "FAILED", "CANCELLED"):
                raise BrokerError("Capital.com từ chối lệnh: %s" % (d.get("reason") or d.get("rejectReason") or st))
            time.sleep(self.CONFIRM_WAIT)
        raise BrokerError("Capital.com chưa xác nhận lệnh %s (%s) - kiểm tra vị thế trên sàn trước khi đặt lại" % (ref, last or "không phản hồi"))

    def _ref(self, d):
        ref = (d or {}).get("dealReference")
        if not ref:
            raise BrokerError("Capital.com không trả dealReference: %s" % str(d)[:160])
        return str(ref)

    def prepare(self, symbol, leverage=1.0):
        return self.balance()

    def balance(self):
        d = self.c.call("GET", "/accounts")
        rows = (d or {}).get("accounts") or []
        cur = str(self.c.info.get("currentAccountId") or "")
        row = next((a for a in rows if str(a.get("accountId")) == cur), None) or next((a for a in rows if a.get("preferred")), None) or (rows[0] if rows else None)
        try:
            return float(row["balance"]["available"] if "available" in row["balance"] else row["balance"]["balance"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi tài khoản Capital.com không hợp lệ: %s" % str(d)[:160])

    def account_flags(self):
        try:
            rows = (self.c.call("GET", "/accounts") or {}).get("accounts") or []
        except BrokerError:
            return {}
        cur = str(self.c.info.get("currentAccountId") or "")
        row = next((a for a in rows if str(a.get("accountId")) == cur), None) or (rows[0] if rows else {})
        c = str(row.get("currency") or "").upper()
        return {"currency": c} if c else {}

    # ---- vị thế ----
    def _positions_raw(self):
        d = self.c.call("GET", "/positions")
        out = []
        for it in (d or {}).get("positions") or []:
            p, m = it.get("position") or {}, it.get("market") or {}
            try:
                out.append({"id": str(p["dealId"]), "symbol": str(m.get("epic") or p.get("epic")), "side": "buy" if str(p["direction"]).upper() == "BUY" else "sell",
                            "qty": abs(float(p["size"])), "price": float(p.get("level") or 0), "sl": float(p.get("stopLevel") or 0),
                            "tp": float(p.get("profitLevel") or 0), "order": str(p.get("workingOrderId") or "")})
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def positions(self):
        agg = {}
        for p in self._positions_raw():
            a = agg.setdefault(p["symbol"], {"q": 0.0, "v": 0.0})
            q = p["qty"] if p["side"] == "buy" else -p["qty"]
            a["q"] += q
            a["v"] += abs(q) * p["price"]
        return {s: {"qty": a["q"], "price": (a["v"] / abs(a["q"])) if a["q"] else 0.0} for s, a in agg.items() if abs(a["q"]) > 0}

    def market_order(self, symbol, side, qty, reduce_only=False, ref=None):
        qty = float(qty)
        if qty <= 0:
            raise BrokerError("Khối lượng phải > 0")
        if reduce_only:
            return self._close(symbol, "sell" if side == "buy" else "buy", qty)
        d = self.c.call("POST", "/positions", body={"epic": symbol, "direction": "BUY" if side == "buy" else "SELL", "size": qty, "guaranteedStop": False})
        cf = self._confirm(self._ref(d))
        try:
            deal = str(cf.get("dealId") or "")
            if not deal:
                deal = str(((cf.get("affectedDeals") or [{}])[0]).get("dealId") or "")
            fill = Fill(price=float(cf["level"]), qty=abs(float(cf.get("size") or qty)), ref=deal, order_id=deal)
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi xác nhận Capital.com không hợp lệ: %s" % str(cf)[:200])
        self.note_own_ref(deal)
        return fill

    def _close(self, symbol, held_side, qty):
        """Đóng các vị thế đang giữ chiều `held_side` (lệnh đóng đi NGƯỢC chiều). API chỉ đóng CẢ vị thế (DELETE): đóng hết thì làm, đóng một phần thì báo lỗi rõ."""
        rows = [p for p in self._positions_raw() if p["symbol"] == symbol and p["side"] == held_side]
        total = sum(p["qty"] for p in rows)
        if not rows:
            raise BrokerError("Không có vị thế %s để đóng trên Capital.com" % symbol)
        if qty + 1e-9 < total:
            raise BrokerError("Capital.com chỉ đóng CẢ vị thế (cần %.8g, đang có %.8g) - đóng một phần chưa hỗ trợ" % (qty, total))
        px = qs = 0.0
        last = ""
        for p in rows:
            d = self.c.call("DELETE", "/positions/%s" % p["id"])
            cf = self._confirm(self._ref(d))
            lv = float(cf.get("level") or 0)
            q = abs(float(cf.get("size") or p["qty"]))
            px, qs, last = px + lv * q, qs + q, p["id"]
        return Fill(price=px / qs if qs else 0.0, qty=qs, ref=last, order_id=last)

    # ---- SL/TP gắn vào vị thế (PROT_STYLE = "position") ----
    def position_levels(self, symbol):
        rows = [{"ref": p["id"], "side": p["side"], "qty": p["qty"], "sl": p["sl"], "tp": p["tp"], "owned": False, "symbol": symbol}
                for p in self._positions_raw() if p["symbol"] == symbol]
        self._lv = {r["ref"]: r for r in rows}
        return rows

    def set_position_levels(self, ref, sl, tp):
        body = {"stopLevel": float(sl) if sl else None, "profitLevel": float(tp) if tp else None}
        d = self.c.call("PUT", "/positions/%s" % ref, body=body)
        self._confirm(self._ref(d))

    # ---- lệnh chờ native ----
    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind not in self.native_pending:
            raise BrokerError("Capital.com: vỏ chỉ dùng lệnh chờ native loại limit/stop (nhận '%s')" % kind)
        body = {"epic": symbol, "direction": "BUY" if side == "buy" else "SELL", "size": float(volume), "level": float(price),
                "type": "LIMIT" if kind == "limit" else "STOP"}
        if sl:
            body["stopLevel"] = float(sl)
        if tp:
            body["profitLevel"] = float(tp)
        if expiry:
            body["goodTillDate"] = _fmt_utc(expiry)
        d = self.c.call("POST", "/workingorders", body=body)
        cf = self._confirm(self._ref(d))
        oid = str(cf.get("dealId") or ((cf.get("affectedDeals") or [{}])[0]).get("dealId") or "")
        if not oid:
            raise BrokerError("Capital.com không trả mã lệnh chờ: %s" % str(cf)[:160])
        return oid

    def cancel_pending(self, native_id, symbol=None):
        d = self.c.call("DELETE", "/workingorders/%s" % native_id)
        self._confirm(self._ref(d))
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        body = {}
        if price is not None:
            body["level"] = float(price)
        if sl is not None:
            body["stopLevel"] = float(sl) if sl else None
        if tp is not None:
            body["profitLevel"] = float(tp) if tp else None
        if not body:
            return str(native_id)
        d = self.c.call("PUT", "/workingorders/%s" % native_id, body=body)
        self._confirm(self._ref(d))
        return str(native_id)

    def pending_orders(self, known=None):
        d = self.c.call("GET", "/workingorders")
        out = {}
        for it in (d or {}).get("workingOrders") or []:
            o = it.get("workingOrderData") or {}
            try:
                out[str(o["dealId"])] = {"symbol": str(o.get("epic")), "side": "buy" if str(o["direction"]).upper() == "BUY" else "sell",
                                         "price": float(o["orderLevel"]), "qty": abs(float(o["orderSize"])), "type": str(o.get("orderType") or "")}
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def order_result(self, native_id, symbol=None):
        native_id = str(native_id)
        if native_id in self.pending_orders():
            return {"state": "open"}
        for p in self._positions_raw():
            if p["order"] == native_id:                          # lệnh chờ đã khớp: vị thế mang workingOrderId của nó
                return {"state": "filled", "price": p["price"], "qty": p["qty"]}
        return {"state": "canceled", "reason": "không còn trong danh sách lệnh chờ và không thấy vị thế khớp"}

    def history(self, since=0.0, symbols=None):
        return []                                                # /history/transactions không kèm giá khớp -> chưa đối soát lịch sử


def _client_from_settings(settings):
    base = resolve_base(dict(settings, exchange="capital"))
    key = (base, settings.get("capital_identifier", ""), settings.get("capital_api_key", ""), settings.get("capital_password", ""),
           settings.get("capital_account", ""))
    c = _CLIENTS.get(key)
    if c is None:
        c = _CLIENTS[key] = CapitalClient(base, settings.get("capital_api_key", ""), settings.get("capital_identifier", ""),
                                          settings.get("capital_password", ""), settings.get("capital_account", ""))
    return c


_CLIENTS = {}


def make_capital_feed(settings):
    try:
        return CapitalFeed(_client_from_settings(settings))
    except BrokerError as e:
        raise FeedError(str(e))


def make_capital_broker(settings):
    return CapitalBroker(_client_from_settings(settings))
