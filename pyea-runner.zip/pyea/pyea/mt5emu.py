"""«Kết nối MT5 nhanh» = chính MT5 THẬT chạy trong giả lập trên điện thoại (proot + Ubuntu + Box64 + Wine), cài và đăng nhập TỰ ĐỘNG.
HAI cách chạy, cùng một đường cài/giám sát/báo tiến trình:
  1. NHÚNG (ưu tiên, pyea/embedded.py): chạy ngay trong app, KHÔNG cần Termux. Người dùng chỉ nhập login + mật khẩu + server. Cần APK targetSdk 28 (xem tools/p4a_hook.py).
  2. TERMUX (dự phòng khi máy/APK không hợp cách 1): dán MỘT lệnh vào Termux; tools/mt5_phone/install_mt5_termux.sh làm phần còn lại.
Cả hai báo tiến trình về app qua cổng cục bộ (cầu nối EA, pyea/mt5ea.py). Module này là phần LOGIC (không Kivy): kiểm nhập liệu, tạo cài đặt + lệnh dán, đọc tiến trình.
Giao diện ở pyea/ui_mt5emu.py.

THẬT THÀ: phần logic và script đã test bằng lệnh giả (tests/test_mt5_install.py, tests/test_mt5emu.py). CHƯA từng chạy Box64/Wine/MT5 trên điện thoại thật.
Cách Termux: việc KHÔNG tự động hoá được là cài Termux (app riêng, bản F-Droid/GitHub) và dán lệnh 1 lần - Android không cho một app tự cài app khác hay tự chạy file tải về
(cách nhúng tránh được điều này nhờ targetSdk 28, đổi lại chỉ cài ngoài, không lên Google Play).
Mật khẩu: chỉ trong RAM, chỉ đi qua cổng 127.0.0.1 tới script, và app quên ngay khi EA đã nối được (xem Mt5EaServer.first_login_password)."""
import re
import secrets
import shlex
import time

from . import mt5ea

TOKEN_OK = re.compile(r"^[A-Za-z0-9_.-]{8,64}$")
TERMUX_URL = "https://f-droid.org/packages/com.termux/"
START_CMD = "bash ~/pyea-start-mt5.sh"
STOP_CMD = "bash ~/pyea-start-mt5.sh stop"

_BOOT = r'''rm -f ~/pyea_install.sh; exec 3<>/dev/tcp/127.0.0.1/@PORT@ || { echo "Không nối được app PyEA: hãy mở app và bấm Bắt đầu"; exit 1; }; printf "SUPHELLO|v=1|token=@TOKEN@\nGET|name=install_mt5_termux.sh\n" >&3; while IFS= read -r -t 20 -u 3 l; do case $l in *b64=*) b=${l#*b64=}; b=${b%%|*}; printf %s "${b//%3D/=}" | base64 -d > ~/pyea_install.sh; break;; FILE*) break;; esac; done; [ -s ~/pyea_install.sh ] && @ENV@ bash ~/pyea_install.sh || echo "Không lấy được script từ app PyEA (sai token? app chưa mở?)"'''


def problems(login, password, server, installer_url=""):
    out = []
    if not re.fullmatch(r"\d{4,12}", str(login or "").strip()):
        out.append("Login MT5 là một dãy số (4-12 chữ số)")
    if not password:
        out.append("Chưa nhập mật khẩu")
    elif not mt5ea.ini_safe(password):
        out.append("Mật khẩu không được chứa ký tự xuống dòng")
    sv = str(server or "").strip()
    if not sv:
        out.append("Chưa nhập server (vd Exness-MT5Real8, hoặc địa chỉ:cổng như trong email của sàn)")
    elif len(sv) > 100 or not mt5ea.ini_safe(sv):
        out.append("Tên server không hợp lệ")
    url = str(installer_url or "").strip()
    if url and (not url.startswith("https://") or re.search(r"\s", url) or len(url) > 400):
        out.append("Link bộ cài MT5 của sàn phải bắt đầu bằng https:// và không có khoảng trắng (hoặc để trống)")
    return out


def plan(settings, login, server, lean=False):
    """Cài đặt cần đặt cho nguồn mt5ea. Giữ token cũ nếu hợp lệ (để file cũ trong Debian vẫn dùng được), không thì sinh token mới. lean = chế độ nhẹ của EA (MT5 nhúng)."""
    tok = str(settings.get("mt5ea_token") or "")
    if not TOKEN_OK.match(tok):
        tok = secrets.token_hex(12)
    out = {"exchange": "mt5ea", "mt5ea_token": tok, "mt5ea_port": str(settings.get("mt5ea_port") or mt5ea.DEFAULT_PORT),
           "mt5ea_login": str(login).strip(), "mt5ea_server": str(server).strip(), "mt5ea_supervised": "yes"}
    if lean:
        out["mt5ea_lean"] = "yes"
    return out


def bootstrap_command(port, token, installer_url=""):
    """MỘT dòng dán vào Termux: nối cổng cục bộ của app, tải install_mt5_termux.sh qua giao thức PyEA-EA (không cần curl/wget), rồi chạy nó."""
    if not TOKEN_OK.match(str(token)):
        raise ValueError("token chứa ký tự không an toàn để dán vào dòng lệnh")
    env = "PYEA_PORT=%d PYEA_TOKEN=%s" % (int(port), token)
    if installer_url:
        env += " MT5_SETUP_URL=%s" % shlex.quote(installer_url)
    inner = _BOOT.replace("@PORT@", str(int(port))).replace("@TOKEN@", token).replace("@ENV@", env)
    return "bash -c " + shlex.quote(inner)


def prepare(settings, login, password, server, installer_url=""):
    """Gom việc phía app: kiểm nhập liệu, đặt cài đặt, mở cổng cục bộ, cấp sẵn file + mật khẩu (chỉ RAM). Trả (cài đặt cần lưu, máy chủ, lệnh dán).
    Ném ValueError (lỗi nhập liệu) hoặc BridgeError (không mở được cổng)."""
    bad = problems(login, password, server, installer_url)
    if bad:
        raise ValueError("\n".join(bad))
    upd = plan(settings, login, server)
    srv = mt5ea.ensure_server(dict(settings, **upd))
    srv.start()
    srv.install_reset()
    srv.set_first_login_password(password)
    return upd, srv, bootstrap_command(int(upd["mt5ea_port"]), upd["mt5ea_token"], installer_url)


def prepare_embedded(settings, login, password, server, installer_url="", data_dir="", launcher=None, profile="lean"):
    """Như prepare() nhưng cho MT5 NHÚNG: mở cổng cục bộ + cấp file/mật khẩu (RAM), rồi bật dịch vụ Emu. Trả (cài đặt cần lưu, máy chủ, (ok, lỗi bật dịch vụ)).
    Mật khẩu KHÔNG đi qua dịch vụ/ghi file: script trong Ubuntu lấy qua cổng cục bộ (GET startup.ini)."""
    from . import embedded
    bad = problems(login, password, server, installer_url)
    if bad:
        raise ValueError("\n".join(bad))
    upd = plan(settings, login, server, lean=True)
    srv = mt5ea.ensure_server(dict(settings, **upd))
    srv.start()
    srv.install_reset()
    srv.set_first_login_password(password)
    res = embedded.launch(data_dir, int(upd["mt5ea_port"]), upd["mt5ea_token"], profile, mt5_url=str(installer_url or "").strip(), starter=launcher)
    return upd, srv, res


# ----------------------------------------------------------------------------------------------- tiến trình
def _row_state(rec):
    st = (rec or {}).get("state", "")
    return {"start": "run", "progress": "run", "ok": "ok", "skip": "ok", "fail": "fail", "wait": "run"}.get(st, "todo")


def progress(srv, stages=None):
    """Đọc tiến trình từ máy chủ cục bộ. rows = [(id, nhãn, trạng_thái, chi_tiết)] với trạng thái todo|run|ok|fail. stages: INSTALL_STAGES (Termux, mặc định) hoặc EMBED_STAGES.
    connected = EA đã nối VÀ báo có tài khoản đăng nhập (kết luận thật); done = connected hoặc script báo đăng nhập ổn."""
    rows, nok = [], 0
    for sid, label in (stages or mt5ea.INSTALL_STAGES):
        rec = srv.install.get(sid)
        stt = _row_state(rec)
        if stt == "ok":
            nok += 1
        rows.append((sid, label, stt, (rec or {}).get("detail", "")))
    info = dict(srv.info or {})
    try:
        login = int(info.get("login") or 0)
    except (TypeError, ValueError):
        login = 0
    connected = bool(srv.connected and login)
    login_rec = srv.install.get("login") or {}
    failed = [r for r in rows if r[2] == "fail"]
    done = connected or login_rec.get("state") == "ok"
    pct = 100 if connected else min(99, int(100 * nok / len(rows)))
    return {"rows": rows, "pct": pct, "failed": failed, "connected": connected, "done": done, "started": bool(srv.install),
            "login": login, "server": str(info.get("server") or ""), "demo": str(info.get("demo") or ""), "link": str(info.get("link") or "socket"),
            "log_ok": login_rec.get("state") == "ok"}


def progress_embedded(srv, data_dir):
    """progress() cho MT5 nhúng + trạng thái dịch vụ Emu đọc từ emu/state.json (phase, lỗi, số đo CPU/RAM). Không cần máy chủ cục bộ có báo gì để biết dịch vụ chết/lỗi."""
    from . import embedded
    p = progress(srv, mt5ea.EMBED_STAGES) if srv is not None else {"rows": [(i, l, "todo", "") for i, l in mt5ea.EMBED_STAGES], "pct": 0, "failed": [], "connected": False,
                                                                       "done": False, "started": False, "login": 0, "server": "", "demo": "", "link": "socket", "log_ok": False}
    st = embedded.status(data_dir)
    p["emu"] = st
    if st["phase"] == "failed" and not p["failed"]:           # lỗi do dịch vụ gặp mà chưa kịp báo qua cổng (hoặc app không nhận được)
        sid = st.get("failed_stage") or "precheck"
        rows = [(i, l, "fail" if i == sid else s, d if i != sid else (st.get("error") or d)) for (i, l, s, d) in p["rows"]]
        p["rows"], p["failed"] = rows, [r for r in rows if r[2] == "fail"]
    res = (srv.res if srv is not None else {}) or {}
    if res and (time.monotonic() - res.get("t", 0)) < 60:
        p["res"] = res
    elif st.get("res"):
        p["res"] = dict(st["res"])
    return p


def headline_embedded(p):
    emu = p.get("emu") or {}
    ph = emu.get("phase", "idle")
    res = p.get("res") or {}
    cost = (" CPU %.0f%% (100%% = 1 nhân), RAM %d MB." % (res.get("cpu", 0), res.get("rss_mb", 0))) if res else ""
    if p["connected"]:
        via = " (qua đường tệp + relay vì MT5 chặn socket)" if p.get("link") == "file" else ""
        return ("ĐÃ NỐI: MT5 nhúng đã đăng nhập tài khoản %s%s và EA đang nối với app%s.%s" % (p["login"], (" @ " + p["server"]) if p["server"] else "", via, cost), "ok")
    if p["failed"]:
        sid, label, _, detail = p["failed"][0]
        return ("LỖI ở bước «%s». Xem chi tiết bên dưới, sửa nguyên nhân rồi bấm «Khởi động lại» (làm tiếp từ bước lỗi, không tải lại phần đã xong)." % label, "fail")
    if ph == "stopped":
        return ("MT5 nhúng đang DỪNG. Bấm «Khởi động lại» để bật.", "wait")
    if ph == "idle" and not p["started"]:
        return ("Đang bật dịch vụ MT5 nhúng...", "wait")
    if ph in ("installing", "installed") or not p["done"]:
        if ph == "running":
            return ("MT5 đang chạy, đang đăng nhập và đợi EA nối vào app...%s" % cost, "wait")
        alive = "" if (emu.get("alive", True) or ph == "idle") else " (CHƯA thấy dịch vụ nền báo nhịp - Android có thể đã tắt nó; bấm «Khởi động lại»)"
        return ("Đang cài (%d%%). Lần đầu có thể mất hàng chục phút; cứ để app mở, không cần làm gì khác.%s" % (p["pct"], alive), "wait")
    return ("MT5 báo đã đăng nhập; đang đợi EA nối vào app...%s" % cost, "wait")


MARK = {"todo": "·", "run": "▶", "ok": "✓", "fail": "✗"}


def render(p):
    lines = []
    for sid, label, stt, detail in p["rows"]:
        line = "%s %s" % (MARK[stt], label)
        if stt in ("run", "fail") and detail:
            line += "\n    " + detail[:300]
        lines.append(line)
    return "\n".join(lines)


def headline(p):
    if p["connected"]:
        via = " (qua đường tệp + relay vì MT5 chặn socket)" if p.get("link") == "file" else ""
        return ("ĐÃ NỐI: MT5 trong giả lập đã đăng nhập tài khoản %s%s và EA đang nối với app%s." % (p["login"], (" @ " + p["server"]) if p["server"] else "", via), "ok")
    if p["failed"]:
        sid, label, _, detail = p["failed"][0]
        return ("LỖI ở bước «%s». Sửa theo gợi ý rồi chạy lại CÙNG lệnh trong Termux (nó làm tiếp từ bước lỗi)." % label, "fail")
    if not p["started"]:
        return ("Chưa thấy Termux báo về. Làm lần lượt: (1) cài Termux, (2) bấm «Sao chép lệnh», (3) mở Termux, giữ ngón tay trên màn hình → Dán, Enter.", "wait")
    if p["log_ok"]:
        return ("MT5 báo đã đăng nhập; đang đợi EA nối vào app...", "wait")
    return ("Đang cài (%d%%). Có thể mất hàng chục phút ở lần đầu; giữ Termux mở và đừng tắt app PyEA." % p["pct"], "wait")
