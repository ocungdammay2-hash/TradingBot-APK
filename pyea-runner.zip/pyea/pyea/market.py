"""
Chợ bot KHÔNG CẦN MÁY CHỦ của tác giả: gói bot có CHỮ KÝ Ed25519 của người bán (.pyeabot, JSON) + danh mục (index.json) đặt ở nơi bất kỳ qua https
(vd GitHub raw của người bán / của cộng đồng). Ai cũng tự đăng được; app chỉ xác minh và hiển thị, KHÔNG kiểm duyệt nội dung.

Chữ ký chứng minh: gói đúng của người giữ khoá riêng đó, không bị sửa trên đường tải. KHÔNG chứng minh bot an toàn hay có lãi.
Vì vậy khi cài: hiện vân tay nhà phát hành (đánh dấu «tin cậy» nếu bạn biết họ), quyền bot khai báo (mạng...), và bot chưa được cấp quyền nào cho tới khi bạn cho.
Không có thanh toán/bản quyền bot trong bản này (cần máy chủ hoặc Play Billing); người bán muốn thu tiền phải làm ngoài app.
(Về «mã hoá nguồn bot»: Python chạy trên máy người dùng nên không giấu được mã - chữ ký bảo vệ TOÀN VẸN, không bảo vệ BÍ MẬT.)

Danh mục: {"bots":[{"name","version","author","description","url","pub","sha256"}]}; `url` tải ra gói .pyeabot; `sha256` là băm file gói; `pub` phải khớp khoá ký trong gói.
"""
import base64
import hashlib
import json
import os
import re
import urllib.request

from . import ed25519
from .codeedit import check_bot_code
from .perms import describe, parse_declared

MAX_BYTES = 512 * 1024
SIGNED_FIELDS = ("v", "name", "version", "author", "description", "filename", "code")


class MarketError(Exception):
    pass


def fingerprint(pub_b64u):
    """Vân tay ngắn để người dùng so khớp (8 nhóm hex của SHA-256 khoá công khai)."""
    raw = ed25519_b64d(pub_b64u)
    h = hashlib.sha256(raw).hexdigest()[:24]
    return " ".join(h[i:i + 4] for i in range(0, len(h), 4))


def ed25519_b64d(s):
    s = re.sub(r"\s+", "", str(s)).replace("-", "+").replace("_", "/")
    try:
        return base64.b64decode(s + "=" * (-len(s) % 4), validate=True)
    except (ValueError, TypeError):
        raise MarketError("Khoá/chữ ký sai định dạng.")


def _canon(doc):
    return json.dumps({k: doc.get(k) for k in SIGNED_FIELDS}, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def pack(code, seed, name, version="1.0", author="", description="", filename=None):
    """Tạo gói .pyeabot (chạy ở máy người bán). seed: 32 byte khoá riêng Ed25519."""
    ok, msg = check_bot_code(code)
    if not ok:
        raise MarketError("Code bot không hợp lệ: " + msg)
    doc = {"v": 1, "name": name, "version": str(version), "author": author, "description": description,
           "filename": filename or re.sub(r"[^\w\-]+", "_", name).strip("_").lower() + ".py", "code": code}
    doc["pub"] = ed25519.b64u(ed25519.public_key(seed))
    doc["sig"] = ed25519.b64u(ed25519.sign(seed, _canon(doc)))
    return json.dumps(doc, ensure_ascii=False, indent=1).encode("utf-8")


def verify(blob):
    """-> dict gói đã xác minh (kèm "fingerprint", "perms" đọc được). Ném MarketError nếu hỏng/chữ ký sai/code không hợp lệ."""
    if len(blob) > MAX_BYTES:
        raise MarketError("Gói quá lớn (> %d KB)." % (MAX_BYTES // 1024))
    try:
        doc = json.loads(blob.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise MarketError("Không phải gói .pyeabot (JSON hỏng).")
    if not isinstance(doc, dict) or doc.get("v") != 1 or not all(isinstance(doc.get(k), str) for k in ("name", "code", "pub", "sig", "filename")):
        raise MarketError("Gói thiếu trường bắt buộc.")
    if not re.fullmatch(r"[\w\-]{1,60}\.py", doc["filename"]):
        raise MarketError("Tên file trong gói không an toàn.")
    if not ed25519.verify(ed25519_b64d(doc["pub"]), _canon(doc), ed25519_b64d(doc["sig"])):
        raise MarketError("CHỮ KÝ KHÔNG HỢP LỆ - gói đã bị sửa hoặc không phải của nhà phát hành này.")
    ok, msg = check_bot_code(doc["code"])
    if not ok:
        raise MarketError("Code trong gói không hợp lệ: " + msg)
    declared = parse_declared(doc["code"])
    return dict(doc, fingerprint=fingerprint(doc["pub"]), perms=describe(declared), declared=declared)


def _get(url, timeout=20, limit=MAX_BYTES):
    if not re.match(r"^(https://|http://(127\.0\.0\.1|localhost)[:/])", url.lower()):
        raise MarketError("Chỉ nhận địa chỉ https:// (http:// chỉ cho localhost).")
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "PyEA-Runner"}), timeout=timeout) as r:
            data = r.read(limit + 1)
    except Exception as e:                                       # noqa: BLE001 - mạng/HTTP lỗi -> báo gọn
        raise MarketError("Không tải được %s: %s" % (url, e))
    if len(data) > limit:
        raise MarketError("Tệp quá lớn.")
    return data


def fetch_catalog(url):
    try:
        doc = json.loads(_get(url).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise MarketError("Danh mục không phải JSON.")
    rows = doc.get("bots") if isinstance(doc, dict) else None
    if not isinstance(rows, list):
        raise MarketError("Danh mục thiếu mục «bots».")
    out = []
    for r in rows[:200]:
        if isinstance(r, dict) and isinstance(r.get("name"), str) and isinstance(r.get("url"), str):
            out.append({k: str(r.get(k, ""))[:300] for k in ("name", "version", "author", "description", "url", "pub", "sha256")})
    return out


def fetch_package(entry_or_url, expect_sha=None, expect_pub=None):
    """Tải + xác minh. Với mục danh mục: băm gói phải khớp `sha256` và khoá ký phải khớp `pub` (nếu danh mục có khai)."""
    if isinstance(entry_or_url, dict):
        url, expect_sha, expect_pub = entry_or_url["url"], entry_or_url.get("sha256") or None, entry_or_url.get("pub") or None
    else:
        url = entry_or_url
    blob = _get(url)
    if expect_sha and hashlib.sha256(blob).hexdigest() != expect_sha.lower():
        raise MarketError("Băm SHA-256 của gói KHÔNG khớp danh mục - không cài.")
    pkg = verify(blob)
    if expect_pub and pkg["pub"] != expect_pub:
        raise MarketError("Khoá ký của gói khác khoá ghi trong danh mục - không cài.")
    return pkg


def install(store, pkg, trusted=()):
    """Cài vào thư mục bot (bản cũ cùng tên được lưu vào phiên bản). Trả (đường dẫn, đã_tin_cậy). KHÔNG cấp quyền nào cho bot."""
    path = store.install_bot_text(pkg["filename"], pkg["code"])
    return path, pkg["pub"] in set(trusted)
