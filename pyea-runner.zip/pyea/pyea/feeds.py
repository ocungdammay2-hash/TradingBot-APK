"""
Nguồn giá nhiều tài sản (feed). Giao diện chung:
    symbols() -> list[str]            danh sách mã (Market Watch)
    tick(symbol) -> Tick              giá bid/ask hiện tại
    history(symbol, tf, n, end=None)  n nến kết thúc trước `end` (epoch giây; None = mới nhất)
    close()
Các nguồn:
  SimFeed     : nhiều tài sản giả (crypto/forex/vàng/cổ phiếu/chỉ số) chạy offline, tua nhanh được
  BinanceFeed : crypto thật (spot hoặc futures USDT-M), API công khai
  OandaFeed   : forex / kim loại / chỉ số CFD thật (tài khoản demo miễn phí) - cần token + account id
"""
import calendar
import http.client
import json
import math
import random
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict

from .ratelimit import limiter_for
from .sdk import Candle, Tick

# Bộ khung thời gian đầy đủ như MT5 (M1..M30, H1..H12, D1, W1, MN1). Giữ tên cũ (1m/5m/1h/1d) để không vỡ cấu hình đã lưu.
# Quy ước nến (UTC, mọi nguồn dùng chung để nến lịch sử khớp nến dựng từ tick):
#   phút/giờ/ngày: mở tại bội số của khung tính từ 00:00 UTC · tuần "1w": mở Thứ Hai 00:00 UTC · tháng "1mo": ngày 1 hằng tháng.
TIMEFRAMES = OrderedDict([
    ("1m", 60), ("2m", 120), ("3m", 180), ("4m", 240), ("5m", 300), ("6m", 360), ("10m", 600), ("12m", 720),
    ("15m", 900), ("20m", 1200), ("30m", 1800),
    ("1h", 3600), ("2h", 7200), ("3h", 10800), ("4h", 14400), ("6h", 21600), ("8h", 28800), ("12h", 43200),
    ("1d", 86400), ("1w", 604800), ("1mo", 2592000),      # 1mo: độ dài danh nghĩa 30 ngày (độ dài thật: tf_span)
])
TF_LABELS = OrderedDict((k, k) for k in TIMEFRAMES)
TF_LABELS.update({"1mo": "1 tháng", "1w": "1 tuần", "1d": "1 ngày"})
TF_GROUPS = [("PHÚT", ["1m", "2m", "3m", "4m", "5m", "6m", "10m", "12m", "15m", "20m", "30m"]),
             ("GIỜ", ["1h", "2h", "3h", "4h", "6h", "8h", "12h"]),
             ("NGÀY (1d) · TUẦN (1w) · THÁNG (1mo)", ["1d", "1w", "1mo"])]
_WEEK_ANCHOR = 4 * 86400        # 1970-01-05 00:00 UTC là Thứ Hai


class FeedError(Exception):
    pass


class HttpError(FeedError):
    """Lỗi HTTP có mã trạng thái (để tầng trên phân biệt 429/401/404...). Vẫn là FeedError nên mã cũ bắt được."""

    def __init__(self, status, body="", retry_after=0.0):
        FeedError.__init__(self, "HTTP %s: %s" % (status, (body or "")[:200]))
        self.status, self.body, self.retry_after = status, body or "", retry_after


def tf_seconds(tf):
    try:
        return TIMEFRAMES[tf]
    except KeyError:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)


def tf_bucket(tf, t):
    """Giờ MỞ của nến chứa thời điểm t (epoch giây UTC)."""
    step = tf_seconds(tf)
    if tf == "1mo":
        g = time.gmtime(t)
        return calendar.timegm((g.tm_year, g.tm_mon, 1, 0, 0, 0))
    if tf == "1w":
        return int((t - _WEEK_ANCHOR) // step) * step + _WEEK_ANCHOR
    return int(t // step) * step


def tf_prev(tf, start, k=1):
    """Giờ mở của nến đứng trước nến mở lúc `start` đúng k nến."""
    if tf == "1mo":
        g = time.gmtime(start)
        y, m = divmod(g.tm_year * 12 + (g.tm_mon - 1) - k, 12)
        return calendar.timegm((y, m + 1, 1, 0, 0, 0))
    return start - k * tf_seconds(tf)


def tf_next(tf, start):
    return tf_prev(tf, start, -1)


def tf_span(tf, start):
    """Độ dài THẬT (giây) của nến mở lúc `start` (tháng có 28-31 ngày)."""
    return tf_next(tf, start) - start


def resample(candles, tf):
    """Gộp nến nhỏ thành khung `tf` (nến đã sắp xếp hoặc không). Nến cuối có thể chưa đủ (đang hình thành)."""
    out, cur = [], None
    for c in sorted(candles, key=lambda c: c.time):
        b = tf_bucket(tf, c.time)
        if cur is not None and cur.time == b:
            cur.high = max(cur.high, c.high)
            cur.low = min(cur.low, c.low)
            cur.close = c.close
            cur.volume += c.volume
        else:
            cur = Candle(b, c.open, c.high, c.low, c.close, c.volume)
            out.append(cur)
    return out


UTC_TFS = ("1d", "1w", "1mo")       # khung có MỐC căn: app dựng nến từ tick theo UTC (tuần mở Thứ Hai, tháng ngày 1), lịch sử PHẢI cùng mốc


def utc_misaligned(candles, tf):
    """Hơn nửa số nến không mở đúng mốc UTC của khung -> nguồn căn theo giờ máy chủ sàn (MT: GMT+2/+3...) hoặc 17:00 New York (forex)."""
    if tf not in UTC_TFS or not candles:
        return False
    return sum(1 for c in candles if tf_bucket(tf, c.time) != c.time) * 2 > len(candles)


def history_via_1h(feed, symbol, tf, n, end=None):
    """n nến 1d/1w/1mo ĐÚNG mốc UTC bằng cách ghép từ nến 1h (bỏ nến đầu thiếu). Tối đa 6000 nến 1h (~250 ngày; ~35 tuần; ~8 tháng) để không tải quá nặng."""
    ratio = max(1, -(-TIMEFRAMES[tf] // 3600))
    raw = fetch_history(feed, symbol, "1h", min((int(n) + 1) * ratio, 6000), end)
    out = resample(raw, tf)
    if len(out) > 1:
        out = out[1:]
    return out[-int(n):]


def utc_guard(feed, native, symbol, tf, n, end=None):
    """Bọc history của sàn có thể trả nến ngày/tuần/tháng theo mốc KHÁC UTC: kiểm mốc; lệch -> nhớ (feed._utc_bad) và ghép từ nến 1h theo UTC để khớp nến dựng từ tick
    (nếu không, nến lịch sử và nến live chồng lên nhau lệch giờ, chỉ báo khung lớn sai)."""
    if tf not in UTC_TFS:
        return native()
    if getattr(feed, "_utc_bad", False):
        return history_via_1h(feed, symbol, tf, n, end)
    out = native()
    if utc_misaligned(out, tf):
        feed._utc_bad = True
        return history_via_1h(feed, symbol, tf, n, end)
    return out


def pick_base(tf, native):
    """Khung gốc LỚN NHẤT mà sàn có sẵn và chia hết `tf` (để ghép nến, vd 3h = 3 x 1h, 12m = 4 x 3m)."""
    want = tf_seconds(tf)
    best = None
    for k in native:
        if k in ("1w", "1mo"):
            continue
        s = TIMEFRAMES[k]
        if s < want and want % s == 0 and (best is None or s > TIMEFRAMES[best]):
            best = k
    return best


def history_resampled(feed, native, symbol, tf, n, end=None):
    """Lấy n nến khung `tf` cho sàn không có sẵn khung đó: tải khung gốc rồi ghép (bỏ nến đầu vì thường thiếu phần đầu)."""
    base = pick_base(tf, native)
    if base is None:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)
    ratio = TIMEFRAMES[tf] // TIMEFRAMES[base]
    raw = fetch_history(feed, symbol, base, (int(n) + 1) * ratio, end)
    out = resample(raw, tf)
    if len(out) > 1:
        out = out[1:]
    return out[-int(n):]


# --------------------------------------------------------------------------
# HTTP (dùng certifi để chạy được trên Android)
# --------------------------------------------------------------------------
_ctx = None


def ssl_context():
    global _ctx
    if _ctx is None:
        try:
            import certifi
            _ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            _ctx = ssl.create_default_context()
    return _ctx


# --------------------------------------------------------------------------
# Giữ kết nối (keep-alive) cho yêu cầu GET: mỗi `urlopen` mở TCP+TLS mới (đo bằng sandbox: 2,5 ms CPU/yêu cầu so với 0,5 ms khi giữ kết nối, chưa kể
# thời gian bật sóng di động), mà app lấy giá MỖI GIÂY cho MỖI mã. CHỈ dùng cho GET (idempotent): POST/DELETE (đặt/sửa/huỷ lệnh) luôn dùng kết nối MỚI
# như trước để không bao giờ gửi trùng lệnh khi kết nối cũ đã chết giữa chừng. Lỗi kết nối cũ -> thử lại ĐÚNG MỘT lần trên kết nối mới.
# --------------------------------------------------------------------------
POOL_ENABLED = True
POOL_MAX_IDLE = 4                  # kết nối nhàn rỗi tối đa cho mỗi (scheme, host, port)
POOL_REUSED_TIMEOUT_S = 3.0        # kết nối dùng lại có thể «chết ngầm» (đổi Wi-Fi/4G): chỉ chờ tối đa chừng này rồi thử lại trên kết nối MỚI (GET idempotent)
POOL_IDLE_S = 45.0                 # sàn thường đóng kết nối nhàn rỗi sau ~60s; bỏ sớm hơn để khỏi dùng kết nối đã chết
_pool = {}
_pool_lock = threading.Lock()


def _proxy_applies(scheme, host):
    try:
        if urllib.request.getproxies().get(scheme) and not urllib.request.proxy_bypass(host):
            return True
    except Exception:                                      # noqa: BLE001
        return True
    return False


def pool_close_all():
    with _pool_lock:
        conns = [c for lst in _pool.values() for c, _t in lst]
        _pool.clear()
    for c in conns:
        try:
            c.close()
        except Exception:
            pass


def _pool_take(key, make):
    now = time.monotonic()
    with _pool_lock:
        lst = _pool.get(key) or []
        while lst:
            c, t = lst.pop()
            if now - t <= POOL_IDLE_S:
                return c, True
            try:
                c.close()
            except Exception:
                pass
    return make(), False


def _pool_give(key, conn):
    with _pool_lock:
        lst = _pool.setdefault(key, [])
        if len(lst) < POOL_MAX_IDLE:
            lst.append((conn, time.monotonic()))
            return
    try:
        conn.close()
    except Exception:
        pass


def _pool_get(url, headers, timeout):
    """-> (status, headers, text) hoặc None khi không áp dụng được. Ném FeedError khi lỗi mạng (như đường cũ)."""
    u = urllib.parse.urlsplit(url)
    if u.scheme not in ("http", "https") or not u.hostname or _proxy_applies(u.scheme, u.hostname):
        return None
    port = u.port or (443 if u.scheme == "https" else 80)
    path = (u.path or "/") + (("?" + u.query) if u.query else "")
    key = (u.scheme, u.hostname, port)
    hdrs = {"Accept-Encoding": "identity", "User-Agent": "Python-urllib/3"}
    hdrs.update(headers or {})

    def make():
        if u.scheme == "https":
            return http.client.HTTPSConnection(u.hostname, port, timeout=timeout, context=ssl_context())
        return http.client.HTTPConnection(u.hostname, port, timeout=timeout)
    last = None
    for attempt in (0, 1):
        conn, reused = _pool_take(key, make) if attempt == 0 else (make(), False)
        try:
            tmo = min(timeout, POOL_REUSED_TIMEOUT_S) if reused else timeout
            conn.timeout = tmo
            if conn.sock is not None:
                conn.sock.settimeout(tmo)
            conn.request("GET", path, headers=hdrs)
            r = conn.getresponse()
            raw = r.read()
            status, rh = r.status, r.msg
        except (http.client.HTTPException, OSError, ssl.SSLError) as e:
            try:
                conn.close()
            except Exception:
                pass
            last = e
            if reused:
                continue                                        # kết nối cũ đã chết: thử lại một lần trên kết nối mới
            raise FeedError("Lỗi mạng: %s" % e)
        if 300 <= status < 400:
            try:
                conn.close()
            except Exception:
                pass
            return None                                          # chuyển hướng: để urllib xử lý như cũ
        if r.will_close or (rh.get("Connection", "") or "").lower() == "close":
            try:
                conn.close()
            except Exception:
                pass
        else:
            _pool_give(key, conn)
        try:
            return status, rh, raw.decode("utf-8", "replace") if status >= 400 else raw.decode("utf-8")
        except UnicodeDecodeError as e:
            raise FeedError("Lỗi mạng: %s" % e)
    raise FeedError("Lỗi mạng: %s" % last)


HTTP_TAP = None      # callable(method, url, status, request_body, response_text) | None - selfcheck dùng để thu phản hồi THÔ của sàn (chung cho mọi adapter)


def _tap(method, url, status, data, text):
    t = HTTP_TAP
    if t is not None:
        try:
            t(method, url, status, data, text)
        except Exception:                                  # noqa: BLE001 - công cụ chẩn đoán không được làm hỏng lệnh thật
            pass


def http_json(url, params=None, headers=None, method="GET", timeout=10, body=None, limiter=None, cost=1.0, raw_body=None, out_headers=None):
    """GET/POST JSON. `limiter` (ratelimit.RateLimiter): chờ đủ chỗ trước khi gửi, báo lại 429/418/5xx + header used-weight.
    `raw_body` (bytes/str): gửi nguyên văn thay cho json (dùng khi chữ ký phải khớp từng byte, vd Exness).
    `out_headers` (dict): nếu truyền, được điền header phản hồi (khoá viết thường) khi thành công - cho sàn trả token ở header (Capital.com: CST/X-SECURITY-TOKEN)."""
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    headers = dict(headers or {})
    data = None
    if raw_body is not None:
        data = raw_body.encode("utf-8") if isinstance(raw_body, str) else raw_body
        headers.setdefault("Content-Type", "application/json")
        if method == "GET":
            method = "POST"
    elif body is not None:
        data = json.dumps(body).encode("utf-8")
        headers.setdefault("Content-Type", "application/json")
        if method == "GET":
            method = "POST"
    if limiter is not None:
        try:
            limiter.acquire(cost)
        except Exception as e:                      # RateLimitError -> FeedError cho các tầng cũ
            raise FeedError(str(e))
    if method == "GET" and data is None and POOL_ENABLED:
        pooled = _pool_get(url, headers, timeout)
        if pooled is not None:                                  # None = không dùng được đường giữ kết nối (proxy, chuyển hướng...) -> đường cũ bên dưới
            status, rheaders, body = pooled
            if status >= 400:
                ra = 0.0
                try:
                    ra = float(rheaders.get("Retry-After", 0) or 0)
                except Exception:
                    pass
                if limiter is not None:
                    limiter.on_http(status, rheaders)
                _tap(method, url, status, data, body)
                raise HttpError(status, body, ra)
            if limiter is not None:
                limiter.on_http(status, rheaders)
            if out_headers is not None:
                out_headers.update({k.lower(): v for k, v in rheaders.items()})
            _tap(method, url, status, data, body)
            try:
                return json.loads(body) if body.strip() else {}
            except ValueError as e:
                raise FeedError("Lỗi mạng: %s" % e)
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            if limiter is not None:
                limiter.on_http(r.status, r.headers)
            if out_headers is not None:
                out_headers.update({k.lower(): v for k, v in r.headers.items()})
            txt = r.read().decode("utf-8")
            _tap(method, url, r.status, data, txt)
            return json.loads(txt) if txt.strip() else {}
    except urllib.error.HTTPError as e:
        try:
            body_txt = e.read().decode("utf-8", "ignore")
        except Exception:
            body_txt = ""
        ra = 0.0
        try:
            ra = float(e.headers.get("Retry-After", 0) or 0)
        except Exception:
            pass
        if limiter is not None:
            limiter.on_http(e.code, e.headers)
        _tap(method, url, e.code, data, body_txt)
        raise HttpError(e.code, body_txt, ra)
    except Exception as e:
        raise FeedError("Lỗi mạng: %s" % e)


# --------------------------------------------------------------------------
# Feed mô phỏng nhiều tài sản
# --------------------------------------------------------------------------
# symbol: (giá khởi điểm, biến động/phút, loại)
SIM_UNIVERSE = {
    "BTCUSD": (30000.0, 0.0007, "crypto"), "ETHUSD": (2000.0, 0.0009, "crypto"),
    "EURUSD": (1.0800, 0.00012, "forex"), "GBPUSD": (1.2600, 0.00014, "forex"),
    "XAUUSD": (2300.0, 0.00025, "kim loại"), "US500": (5200.0, 0.00018, "chỉ số"),
    "AAPL": (190.0, 0.0004, "cổ phiếu"), "USOIL": (78.0, 0.0005, "hàng hoá"),
}


class SimFeed:
    """Giá ngẫu nhiên (random walk có drift chậm) cho nhiều mã. `speed` = số giây mô phỏng
    trôi qua trong 1 giây thật (speed=10 -> nến 1 phút đóng sau ~6 giây thật)."""

    max_chunk = 200000        # lịch sử giả sinh liền 1 lần (không phân trang -> không đứt giá)

    def __init__(self, start_price=30000.0, speed=10.0, vol_per_min=0.0007, seed=None, universe=None):
        self.universe = dict(universe or SIM_UNIVERSE)
        self.default = (float(start_price), float(vol_per_min), "khác")
        self.speed = float(speed)
        self.seed = seed
        self._t0_wall = time.time()
        self._t0_mono = time.monotonic()
        self._st = {}

    @property
    def sim_time(self):
        return self._t0_wall + (time.monotonic() - self._t0_mono) * self.speed

    def symbols(self):
        return sorted(self.universe)

    def _state(self, symbol):
        st = self._st.get(symbol)
        if st is None:
            p0, vol, _ = self.universe.get(symbol, self.default)
            rng = random.Random("%s|%s" % (self.seed, symbol)) if self.seed is not None else random.Random()
            st = self._st[symbol] = {"price": p0, "vol": vol, "drift": 0.0, "rng": rng, "last": time.monotonic()}
        return st

    def tick(self, symbol):
        st = self._state(symbol)
        now = time.monotonic()
        dt = max((now - st["last"]) * self.speed, 0.01)
        st["last"] = now
        scale = math.sqrt(dt / 60.0)
        rng, vol = st["rng"], st["vol"]
        st["drift"] = 0.97 * st["drift"] + rng.gauss(0, vol * 0.15) * scale
        st["price"] *= math.exp(st["drift"] * scale + rng.gauss(0, vol * scale))
        half = st["price"] * 0.00005
        return Tick(symbol, self.sim_time, st["price"] - half, st["price"] + half)

    def history(self, symbol, tf, n, end=None):
        st = self._state(symbol)
        tf_seconds(tf)
        t_end = tf_bucket(tf, end if end is not None else self.sim_time)
        rng = random.Random("%s|h|%s|%s|%s" % (self.seed, symbol, tf, int(t_end)))
        raw, p = [], 1.0
        for i in range(n):
            t0 = tf_prev(tf, t_end, n - i)
            step = tf_span(tf, t0)
            o = p
            hi = lo = o
            for _ in range(8):
                p *= math.exp(rng.gauss(0, st["vol"] * math.sqrt(step / 60.0 / 8)))
                hi, lo = max(hi, p), min(lo, p)
            raw.append((t0, o, hi, lo, p))
        k = st["price"] / p
        return [Candle(t, o * k, h * k, l * k, c * k, 0.0) for (t, o, h, l, c) in raw]

    def close(self):
        pass


# --------------------------------------------------------------------------
# Binance (public)
# --------------------------------------------------------------------------
_BASES = {
    ("binance_spot", False): "https://api.binance.com",
    ("binance_spot", True): "https://testnet.binance.vision",
    ("binance_futures", False): "https://fapi.binance.com",
    ("binance_futures", True): "https://testnet.binancefuture.com",
    ("oanda", False): "https://api-fxtrade.oanda.com",
    ("oanda", True): "https://api-fxpractice.oanda.com",
    ("capital", False): "https://api-capital.backend-capital.com",
    ("capital", True): "https://demo-api-capital.backend-capital.com",
}


def resolve_base(settings):
    """URL gốc theo sàn/testnet; `base_url` (nếu nhập) được ưu tiên."""
    custom = (settings.get("base_url") or "").strip()
    if custom:
        return custom.rstrip("/")
    return _BASES.get((settings.get("exchange", "binance_spot"), bool(settings.get("testnet"))),
                      "https://api.binance.com")


# Khung Binance có sẵn (giá trị = chuỗi interval của API; tháng là "1M" viết hoa)
_BINANCE_INT = {"1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1h", "2h": "2h", "4h": "4h",
                "6h": "6h", "8h": "8h", "12h": "12h", "1d": "1d", "1w": "1w", "1mo": "1M"}


class _WsBook:
    """Luồng WebSocket `<mã>@bookTicker` của Binance (giá bid/ask ĐẨY về, độ trễ vài chục ms thay vì chu kỳ thăm dò). 1 luồng/mã, tự nối lại
    (chờ 1 -> 30 giây). KHÔNG bao giờ ném lỗi ra ngoài: mất luồng thì `fresh()` hết hạn và BinanceFeed quay lại REST."""

    def __init__(self, url, symbol, offset_fn):
        self.url, self.symbol, self.offset_fn = url, symbol, offset_fn
        self.tick = None
        self.stamp = 0.0
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, name="binance-ws-" + symbol, daemon=True)
        self.thread.start()

    def fresh(self, max_age=4.0):
        return self.tick is not None and time.time() - self.stamp <= max_age

    def _run(self):
        from .wsclient import WebSocketClient
        wait = 1.0
        while not self.stop.is_set():
            ws = None
            try:
                ws = WebSocketClient(self.url, timeout=10.0)
                ws.connect()
                wait = 1.0
                while not self.stop.is_set():
                    msg = ws.recv(timeout=5.0)
                    if msg is None:
                        continue
                    d = json.loads(msg)
                    if isinstance(d, dict) and "b" in d and "a" in d:
                        self.tick = Tick(self.symbol, time.time() + (self.offset_fn() or 0.0), float(d["b"]), float(d["a"]))
                        self.stamp = time.time()
            except Exception:                                  # noqa: BLE001 - mọi lỗi mạng/định dạng: nối lại, REST lo phần dự phòng
                pass
            finally:
                try:
                    if ws is not None:
                        ws.close()
                except Exception:                              # noqa: BLE001
                    pass
            self.stop.wait(wait)
            wait = min(30.0, wait * 2)


class BinanceFeed:
    def __init__(self, base_url="https://api.binance.com", futures=False, ws=False, ws_base=None):
        self.ws_on = bool(ws)
        self.ws_base = (ws_base or ("wss://fstream.binance.com" if futures else "wss://stream.binance.com:9443")).rstrip("/")
        self._ws = {}
        self.base = base_url.rstrip("/")
        self.p = "/fapi/v1" if futures else "/api/v3"
        self.offset = None
        self._symbols = None
        self.limiter = limiter_for("binance_futures" if futures else "binance_spot", self.base)

    def _sync(self):
        try:
            d = http_json(self.base + self.p + "/time", limiter=self.limiter, cost=1)
            self.offset = d["serverTime"] / 1000.0 - time.time()
        except Exception:
            self.offset = 0.0

    def symbols(self):
        if self._symbols is None:
            rows = http_json(self.base + self.p + "/ticker/price", timeout=20, limiter=self.limiter, cost=4)
            if not isinstance(rows, list):
                raise FeedError("Danh sách mã không hợp lệ")
            self._symbols = sorted(r["symbol"] for r in rows if r.get("symbol", "").endswith("USDT"))
        return self._symbols

    def tick(self, symbol):
        if self.ws_on:                                         # giá đẩy qua WebSocket nếu còn mới, ngược lại REST (và luồng vẫn tự nối lại)
            w = self._ws.get(symbol)
            if w is None:
                w = self._ws[symbol] = _WsBook("%s/ws/%s@bookTicker" % (self.ws_base, symbol.lower()), symbol, lambda: self.offset)
            if w.fresh():
                return w.tick
        if self.offset is None:
            self._sync()
        d = http_json(self.base + self.p + "/ticker/bookTicker", {"symbol": symbol}, limiter=self.limiter, cost=2)
        try:
            return Tick(symbol, time.time() + self.offset, float(d["bidPrice"]), float(d["askPrice"]))
        except (KeyError, ValueError):
            raise FeedError("Phản hồi giá không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        iv = _BINANCE_INT.get(tf)
        if iv is None:                      # 2m/4m/6m/10m/12m/20m/3h: Binance không có -> ghép từ khung nhỏ hơn
            return history_resampled(self, _BINANCE_INT, symbol, tf, n, end)
        params = {"symbol": symbol, "interval": iv, "limit": max(2, min(int(n), 1000))}
        if end is not None:
            params["endTime"] = int(end * 1000) - 1
        rows = http_json(self.base + self.p + "/klines", params, limiter=self.limiter, cost=2 if params["limit"] <= 1000 else 10)
        if not isinstance(rows, list):
            raise FeedError("Phản hồi nến không hợp lệ")
        return [Candle(r[0] / 1000.0, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5]))
                for r in rows]

    # ---- dữ liệu thị trường công khai bổ sung (không cần API key) ----
    def depth(self, symbol, limit=20):
        """Sổ lệnh: {"bids": [[giá, KL]...], "asks": [...]} (số thực, bids giảm dần, asks tăng dần). Futures chỉ nhận limit 5/10/20/50/100/500/1000."""
        valid = (5, 10, 20, 50, 100, 500, 1000) if self.p.startswith("/fapi") else None
        limit = int(limit)
        if valid:
            limit = min((v for v in valid if v >= limit), default=1000)
        d = http_json(self.base + self.p + "/depth", {"symbol": symbol, "limit": limit}, limiter=self.limiter,
                      cost=(2 if limit <= 50 else 5 if limit <= 100 else 10 if limit <= 500 else 20) if valid else
                      (5 if limit <= 100 else 25 if limit <= 500 else 50 if limit <= 1000 else 250))
        if not isinstance(d, dict) or "bids" not in d or "asks" not in d:
            raise FeedError("Phản hồi sổ lệnh không hợp lệ")
        try:
            return {"bids": [[float(a), float(b)] for a, b, *_ in d["bids"]], "asks": [[float(a), float(b)] for a, b, *_ in d["asks"]],
                    "update_id": d.get("lastUpdateId")}
        except (TypeError, ValueError):
            raise FeedError("Sổ lệnh có giá trị không phải số")

    def agg_trades(self, symbol, start_ms=None, end_ms=None, from_id=None, limit=1000):
        """Giao dịch gộp: [{"id", "t" (giây), "p", "q", "buyer_maker"}]. Dùng CẶP startTime/endTime (cửa sổ < 1 giờ) HOẶC fromId, không trộn."""
        params = {"symbol": symbol, "limit": max(1, min(int(limit), 1000))}
        if from_id is not None:
            params["fromId"] = int(from_id)
        else:
            if start_ms is not None:
                params["startTime"] = int(start_ms)
            if end_ms is not None:
                params["endTime"] = int(end_ms)
        rows = http_json(self.base + self.p + "/aggTrades", params, limiter=self.limiter, cost=20 if self.p.startswith("/fapi") else 4)
        if not isinstance(rows, list):
            raise FeedError("Phản hồi aggTrades không hợp lệ")
        out = []
        for r in rows:
            try:
                out.append({"id": int(r["a"]), "t": r["T"] / 1000.0, "p": float(r["p"]), "q": float(r["q"]), "buyer_maker": bool(r.get("m"))})
            except (KeyError, TypeError, ValueError):
                raise FeedError("aggTrades có dòng sai định dạng")
        return out

    def symbol_info(self, symbol):
        """Thông số mã từ exchangeInfo (chuẩn hoá: xem pyea/specs.py)."""
        d = http_json(self.base + self.p + "/exchangeInfo", {"symbol": symbol}, limiter=self.limiter, cost=1 if self.p.startswith("/fapi") else 20)
        rows = d.get("symbols") if isinstance(d, dict) else None
        if not rows:
            raise FeedError("Sàn không trả thông số cho %s" % symbol)
        return rows[0]

    def close(self):
        for w in list(self._ws.values()):
            w.stop.set()
        self._ws.clear()


# --------------------------------------------------------------------------
# OANDA v20 (forex / kim loại / chỉ số CFD)
# --------------------------------------------------------------------------
_OANDA_GRAN = {"1m": "M1", "2m": "M2", "4m": "M4", "5m": "M5", "10m": "M10", "15m": "M15", "30m": "M30",
               "1h": "H1", "2h": "H2", "3h": "H3", "4h": "H4", "6h": "H6", "8h": "H8", "12h": "H12",
               "1d": "D", "1w": "W", "1mo": "M"}


class OandaFeed:
    def __init__(self, base_url, token, account_id):
        if not token or not account_id:
            raise FeedError("OANDA cần API token và Account ID")
        self.base = base_url.rstrip("/")
        self.h = {"Authorization": "Bearer " + token.strip()}
        self.acc = account_id.strip()
        self._symbols = None
        self.limiter = limiter_for("oanda", self.base)

    def _get(self, path, params=None):
        return http_json(self.base + path, params, headers=self.h, timeout=15, limiter=self.limiter, cost=1)

    def symbols(self):
        if self._symbols is None:
            d = self._get("/v3/accounts/%s/instruments" % self.acc)
            self._symbols = sorted(i["name"] for i in d.get("instruments", []))
        return self._symbols

    def tick(self, symbol):
        d = self._get("/v3/accounts/%s/pricing" % self.acc, {"instruments": symbol})
        try:
            p = d["prices"][0]
            t = p.get("time")
            return Tick(symbol, _oanda_time(t) if t else time.time(), float(p["bids"][0]["price"]), float(p["asks"][0]["price"]),
                        tradeable=_oanda_tradeable(p))
        except (KeyError, IndexError, ValueError, TypeError):
            raise FeedError("Phản hồi giá OANDA không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        gran = _OANDA_GRAN.get(tf)
        if not gran:                        # 3m/6m/12m/20m: OANDA không có -> ghép từ khung nhỏ hơn
            return history_resampled(self, _OANDA_GRAN, symbol, tf, n, end)
        # Căn nến theo UTC (mặc định OANDA căn 17:00 New York) để khớp nến dựng từ tick; tuần mở Thứ Hai.
        params = {"granularity": gran, "count": max(2, min(int(n), 5000)), "price": "M",
                  "alignmentTimezone": "UTC", "dailyAlignment": 0, "weeklyAlignment": "Monday"}
        if end is not None:
            params["to"] = "%.0f" % end
        d = self._get("/v3/instruments/%s/candles" % symbol, params)
        out = []
        for c in d.get("candles", []):
            m = c.get("mid") or {}
            try:
                out.append(Candle(_oanda_time(c["time"]), float(m["o"]), float(m["h"]), float(m["l"]), float(m["c"]),
                                  float(c.get("volume", 0))))
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def close(self):
        pass


def _oanda_tradeable(p):
    """Giá OANDA có giao dịch được không. Tài liệu pricing hiện trả `status` ("tradeable" | "non-tradeable" | "invalid"); cờ bool `tradeable` là bản
    cũ. Ưu tiên `status`; thiếu cả hai -> coi là giao dịch được (không chặn nhầm lệnh khi sàn đổi định dạng)."""
    st = p.get("status")
    if st is not None:
        return str(st).lower() == "tradeable"
    return bool(p.get("tradeable", True))


def _oanda_time(t):
    """RFC3339 ('2024-01-02T03:04:05.000000000Z') hoặc epoch -> epoch giây."""
    try:
        return float(t)
    except (TypeError, ValueError):
        pass
    import calendar
    s = str(t).split(".")[0].rstrip("Z")
    return float(calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%S")))


# --------------------------------------------------------------------------
def make_feed(kind, settings):
    """kind: simulated | binance_spot | binance_futures | oanda | exness | metaapi | mt5gw | bridge | ctrader | mt5ws | dnse | ccxt  (còn nhận 'binance' = spot)."""
    if kind in ("binance", "binance_spot", "binance_futures"):
        fut = kind == "binance_futures"
        st = dict(settings, exchange="binance_futures" if fut else "binance_spot")
        return BinanceFeed(resolve_base(st), futures=fut, ws=bool(settings.get("binance_ws", True)) and not settings.get("testnet"))
    if kind == "public":
        from .publicfeed import PublicFeed
        return PublicFeed(twelvedata_key=settings.get("twelvedata_key", ""))
    if kind == "oanda":
        return OandaFeed(resolve_base(dict(settings, exchange="oanda")), settings.get("oanda_token", ""),
                         settings.get("oanda_account", ""))
    if kind == "capital":
        from .capital import make_capital_feed
        return make_capital_feed(settings)
    if kind == "exness":
        from .exness import ExnError, make_exness_feed
        try:
            return make_exness_feed(settings)
        except ExnError as e:
            raise FeedError(str(e))
    if kind in ("metaapi", "mt5gw", "bridge", "ctrader", "mt5ws", "dnse"):
        from .bridges import BridgeError, make_bridge_feed
        try:
            return make_bridge_feed(dict(settings, exchange=kind))
        except BridgeError as e:
            raise FeedError(str(e))
    if kind == "ccxt":
        from .ccxt_adapter import make_ccxt_feed
        try:
            return make_ccxt_feed(settings)
        except Exception as e:                                       # noqa: BLE001 - BrokerError(thiếu ccxt) -> FeedError
            raise FeedError(str(e))
    return SimFeed(start_price=float(settings.get("sim_start_price", 30000.0)),
                   speed=float(settings.get("sim_speed", 10.0)))


def fetch_history(feed, symbol, tf, bars, end=None, progress=None):
    """Lấy `bars` nến (có phân trang) kết thúc trước `end`. Trả về list Candle cũ -> mới, không trùng."""
    step = tf_seconds(tf)
    out, cursor, guard = [], end, 0
    while len(out) < bars and guard < 60:
        guard += 1
        chunk = feed.history(symbol, tf, min(getattr(feed, "max_chunk", 1000), bars - len(out) + 2), cursor)
        if not chunk:
            break
        chunk = [c for c in chunk if end is None or c.time < end]
        if not chunk:
            break
        out = chunk + out
        new_cursor = chunk[0].time
        if cursor is not None and new_cursor >= cursor:
            break
        cursor = new_cursor
        if progress:
            progress(len(out), bars)
    seen, uniq = set(), []
    for c in out:
        if c.time not in seen:
            seen.add(c.time)
            uniq.append(c)
    uniq.sort(key=lambda c: c.time)
    return uniq[-bars:]
