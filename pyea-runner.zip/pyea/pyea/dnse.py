"""DNSE OpenAPI (V2) - ký request + client mức thấp. CHƯA nối vào bot/UI (xem docs/DNSE.md).

Nguồn ĐÃ đối chiếu (2 nguồn độc lập khớp nhau): thanhdat-phung/dnse_openapi (signing.py mô tả), pskho/dnse-mt5-connector (docs/DNSE_API_AUTH.md),
và README chính thức của gói PyPI `dnse-sdk-openapi` 2.4.1:
  - Base: https://openapi.dnse.com.vn (production) · https://sb-openapi.dnse.com.vn (sandbox; credential riêng)
  - Chuỗi ký 3 dòng:  "(request-target): <method viết thường> <path, không query/body>\\ndate: <Date>\\nnonce: <32 hex>"
  - HMAC-SHA256 bằng API secret -> base64 -> URL-encode (/ -> %2F, + -> %2B, = -> %3D)
  - Header: X-Signature = Signature keyId="<api key>",algorithm="hmac-sha256",headers="(request-target) date",signature="<..>",nonce="<..>"
            Date (UTC, dạng "Wed, 29 Apr 2026 03:35:08 +0000", lệch > ~5 phút bị từ chối) · X-Api-Key · version (tuỳ chọn)
  - Endpoint đã biết: GET /accounts · GET /accounts/{no}/balances · POST /registration/send-email-otp · POST /registration/trading-token
    POST /accounts/{no}/orders?marketType=&orderCategory= · PUT|DELETE /accounts/{no}/orders/{id}
CHƯA XÁC MINH (không có tài liệu đọc được): header/body mang OTP khi lấy trading token, tên header trading token khi đặt lệnh, giá trị enum
marketType/orderCategory, đường dẫn danh sách lệnh/vị thế/nến/giá. Các chỗ đó để THAM SỐ, không đoán cứng.
"""
import base64
import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

PROD = "https://openapi.dnse.com.vn"
SANDBOX = "https://sb-openapi.dnse.com.vn"


class DnseError(Exception):
    def __init__(self, msg, status=0, body=None):
        Exception.__init__(self, msg)
        self.status, self.body = status, body


def http_date(now=None):
    """Header Date: UTC, đúng '+0000' (không GMT/Z)."""
    return time.strftime("%a, %d %b %Y %H:%M:%S +0000", time.gmtime(time.time() if now is None else now))


def signing_string(method, path, date, nonce):
    """path: CHỈ đường dẫn (bỏ base URL, query và body)."""
    path = urllib.parse.urlsplit(path).path or "/"
    return "(request-target): %s %s\ndate: %s\nnonce: %s" % (method.lower(), path, date, nonce)


def sign(secret, method, path, date, nonce):
    mac = hmac.new(secret.encode("utf-8"), signing_string(method, path, date, nonce).encode("utf-8"), hashlib.sha256).digest()
    return urllib.parse.quote(base64.b64encode(mac).decode("ascii"), safe="")


def auth_headers(api_key, api_secret, method, path, version="", date=None, nonce=None, date_header="Date"):
    date = date or http_date()
    nonce = nonce or os.urandom(16).hex()
    sig = sign(api_secret, method, path, date, nonce)
    h = {"X-Api-Key": api_key, date_header: date,
         "X-Signature": 'Signature keyId="%s",algorithm="hmac-sha256",headers="(request-target) date",signature="%s",nonce="%s"' % (api_key, sig, nonce)}
    if version:
        h["version"] = version
    return h


class DnseClient:
    def __init__(self, api_key, api_secret, base_url=PROD, version="", timeout=15.0, date_header="Date", opener=None):
        if not api_key or not api_secret:
            raise DnseError("Thiếu API Key/Secret DNSE")
        self.key, self.secret, self.base = api_key, api_secret, base_url.rstrip("/")
        self.version, self.timeout, self.date_header = version, timeout, date_header
        self._open = opener or urllib.request.urlopen

    def request(self, method, path, query=None, body=None, extra_headers=None, trading=False):
        """Mỗi lần gọi ký MỚI (Date + nonce mới). Lệnh giao dịch (`trading=True`) KHÔNG BAO GIỜ tự gửi lại: lỗi mạng -> DnseError để người gọi
        kiểm trạng thái lệnh trước khi thử lại (đúng khuyến nghị của SDK chính thức)."""
        url = self.base + path + (("?" + urllib.parse.urlencode(query)) if query else "")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        h = auth_headers(self.key, self.secret, method, path, self.version, date_header=self.date_header)
        h["Accept"] = "application/json"
        if data is not None:
            h["Content-Type"] = "application/json"
        h.update(extra_headers or {})
        req = urllib.request.Request(url, data=data, headers=h, method=method.upper())
        try:
            with self._open(req, timeout=self.timeout) as r:
                raw = r.read().decode("utf-8", "replace")
                status = getattr(r, "status", 200)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", "replace") if hasattr(e, "read") else ""
            raise DnseError("DNSE HTTP %s: %s" % (e.code, raw[:200]), e.code, raw)
        except (urllib.error.URLError, OSError) as e:
            raise DnseError("Không kết nối được DNSE (%s)%s" % (e, " - KHÔNG tự gửi lại lệnh, hãy kiểm tra trạng thái lệnh" if trading else ""))
        try:
            return json.loads(raw) if raw.strip() else {}
        except ValueError:
            raise DnseError("Phản hồi DNSE không phải JSON (status %s): %s" % (status, raw[:120]), status, raw)

    # ---- đã biết đường dẫn ----
    def accounts(self):
        return self.request("GET", "/accounts")

    def balances(self, account_no):
        return self.request("GET", "/accounts/%s/balances" % urllib.parse.quote(str(account_no), safe=""))

    def send_email_otp(self):
        return self.request("POST", "/registration/send-email-otp")

    def place_order(self, account_no, trading_token, market_type, order_category, order, token_header="Trading-Token"):
        """order: dict theo DTO (accountNo?, symbol, side NB|NS, orderType, quantity, price, loanPackageId). market_type/order_category/
        token_header là THAM SỐ vì chưa xác minh được giá trị enum và tên header chính thức."""
        return self.request("POST", "/accounts/%s/orders" % urllib.parse.quote(str(account_no), safe=""),
                            {"marketType": market_type, "orderCategory": order_category}, order, {token_header: trading_token}, trading=True)

    def cancel_order(self, account_no, order_id, trading_token, market_type, order_category, token_header="Trading-Token"):
        return self.request("DELETE", "/accounts/%s/orders/%s" % (urllib.parse.quote(str(account_no), safe=""), urllib.parse.quote(str(order_id), safe="")),
                            {"marketType": market_type, "orderCategory": order_category}, None, {token_header: trading_token}, trading=True)


# ======================================================================================================= DNSE LightSpeed API V1 (đã có tài liệu đầy đủ)
# Nguồn: hdsd.dnse.com.vn «Tài liệu LightSpeed API V1» (endpoint, header, trường), đặc tả MDDS (xlsx do người dùng gửi: topic MQTT + trường tick/top price),
# mã mẫu MQTT của DNSE (người dùng gửi: broker datafeed-lts.dnse.com.vn:443 path /wss, MQTT 5, user = investorId, pass = JWT).
# CHƯA kiểm với tài khoản thật. Chỗ còn ĐOÁN (ghi rõ ở docs/DNSE.md): tên khoá JSON thực tế của tick/top price (parser chịu mọi kiểu chữ hoa/thường),
# đơn vị giá (chỉnh `dnse_price_scale`), endpoint nến lịch sử (`dnse_chart_url`).
import re as _re
import threading
import time as _time

from .bridges import BridgeError, MtBackend
from .exness import _num, _ts
from .feeds import HttpError, TIMEFRAMES, http_json
from .mqttws import MqttWs
from .sdk import Candle

API_V1 = "https://api.dnse.com.vn"
MQTT_URL = "wss://datafeed-lts.dnse.com.vn/wss"
CHART_URL = "https://services.entrade.com.vn/chart-api/v2/ohlcs"       # KHÔNG có trong tài liệu chính thức: đường dẫn phổ biến, cần kiểm
OPEN_STATUS = {"pending", "pendingnew", "new", "partiallyfilled"}
DERIV_RE = _re.compile(r"^(VN30F|VN100F|41I1|41I2|GB\d)", _re.I)


def is_derivative(symbol):
    return bool(DERIV_RE.match(str(symbol or "")))


class DnseV1:
    def __init__(self, username, password, base=API_V1, timeout=15.0, http=None):
        if not str(username or "").strip() or not password:
            raise BridgeError("Thiếu tên đăng nhập/mật khẩu DNSE")
        self.user, self.pw, self.base, self.timeout = str(username).strip(), password, base.rstrip("/"), timeout
        self._http = http or http_json
        self.jwt, self.jwt_t = "", 0.0
        self._lock = threading.Lock()

    def _call(self, method, path, params=None, body=None, headers=None, auth=True):
        h = {"Accept": "application/json"}
        if auth:
            h["Authorization"] = "Bearer " + self.token()
        h.update(headers or {})
        try:
            return self._http(self.base + path, params, headers=h, method=method, timeout=self.timeout, body=body)
        except HttpError as e:
            raise BridgeError("DNSE %s %s: HTTP %s %s" % (method, path, e.status, (e.body or "")[:160]))

    def token(self):
        with self._lock:
            if self.jwt and _time.time() - self.jwt_t < 7.5 * 3600:          # JWT hiệu lực 8 giờ
                return self.jwt
            r = self._call("POST", "/auth-service/login", body={"username": self.user, "password": self.pw}, auth=False)
            tok = (r or {}).get("token")
            if not tok:
                raise BridgeError("Đăng nhập DNSE không trả token")
            self.jwt, self.jwt_t = tok, _time.time()
            return tok

    def relogin(self):
        with self._lock:
            self.jwt = ""

    def accounts(self):
        return (self._call("GET", "/order-service/accounts") or {}).get("accounts", [])

    def balances(self, acc):
        return self._call("GET", "/order-service/account-balances/%s" % urllib.parse.quote(str(acc), safe="")) or {}

    def loan_packages(self, acc, derivative=False):
        if derivative:
            return self._call("GET", "/order-service/accounts/%s/derivative-loan-packages" % acc)
        return self._call("GET", "/order-service/v2/accounts/%s/loan-packages" % acc)

    def email_otp(self):
        return self._call("GET", "/auth-service/api/email-otp")

    def trading_token(self, otp, smart=False):
        r = self._call("POST", "/order-service/trading-token", headers={("smart-otp" if smart else "otp"): str(otp).strip()}) or {}
        tt = r.get("tradingToken") or r.get("trading_token")
        if not tt:
            raise BridgeError("DNSE không trả tradingToken (OTP sai/hết hạn?)")
        return tt

    def place_order(self, derivative, body, trading_token):
        path = "/order-service/derivative/orders" if derivative else "/order-service/v2/orders"
        return self._call("POST", path, body=body, headers={"Trading-Token": trading_token}) or {}

    def orders(self, acc, derivative=False):
        path = "/order-service/derivative/orders" if derivative else "/order-service/v2/orders"
        return (self._call("GET", path, {"accountNo": acc}) or {}).get("orders", [])

    def cancel(self, order_id, acc, trading_token, derivative=False):
        path = "/order-service/derivative/orders/%s" if derivative else "/order-service/v2/orders/%s"
        return self._call("DELETE", path % urllib.parse.quote(str(order_id), safe=""), {"accountNo": acc}, headers={"Trading-Token": trading_token}) or {}

    def deals(self, acc):
        return (self._call("GET", "/deal-service/deals", {"accountNo": acc}) or {}).get("deals", [])


def _lower_keys(o):
    return {str(k).lower(): v for k, v in o.items()} if isinstance(o, dict) else {}


def parse_quote(topic, payload):
    """Topic + JSON payload MQTT -> ("tick", sym, price, qty) | ("tp", sym, bid, ask) | None. Khoá JSON không phân biệt hoa/thường; lỗi định dạng -> None."""
    try:
        d = _lower_keys(json.loads(payload.decode("utf-8", "replace")))
    except ValueError:
        return None
    parts = topic.split("/")
    kind = parts[3] if len(parts) > 3 else ""
    sym = str(d.get("symbol") or (parts[-1] if parts else "")).upper()
    if kind == "tick":
        px = _num(d.get("matchprice", d.get("price")))
        return ("tick", sym, px, _num(d.get("matchqtty", d.get("qtty")))) if px > 0 else None
    if kind.upper() == "TP":
        def best(side, hi):
            vals = []
            for o in d.get(side) or []:
                p = _num(_lower_keys(o).get("price"))
                if p > 0:
                    vals.append(p)
            return (max(vals) if hi else min(vals)) if vals else 0.0
        bid, ask = best("bid", True), best("ask", False)
        return ("tp", sym, bid, ask) if (bid > 0 or ask > 0) else None
    return None


class DnseStream:
    """Luồng giá MQTT (1 kết nối, nhiều mã). Tự nối lại; mất giá thì tick() báo lỗi 'chưa có giá', KHÔNG bịa giá."""
    TOPICS = ("plaintext/quotes/stock/tick/%s", "plaintext/quotes/stock/TP/%s", "plaintext/quotes/derivative/tick/%s", "plaintext/quotes/derivative/TP/%s")

    def __init__(self, url, creds_fn, mqtt_factory=None):
        self.url, self.creds_fn = url, creds_fn
        self.factory = mqtt_factory or MqttWs
        self.ticks = {}                    # sym -> [bid, ask, last, epoch]
        self.want = []
        self._sub_done = set()
        self.stop = threading.Event()
        self.thread = None
        self.error = ""
        self._lock = threading.Lock()

    def watch(self, symbol):
        s = symbol.upper()
        with self._lock:
            if s not in self.want:
                self.want.append(s)
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, name="dnse-mqtt", daemon=True)
            self.thread.start()

    def get(self, symbol):
        with self._lock:
            return list(self.ticks.get(symbol.upper(), ()))

    def _apply(self, topic, payload):
        q = parse_quote(topic, payload)
        if not q:
            return
        with self._lock:
            t = self.ticks.setdefault(q[1], [0.0, 0.0, 0.0, 0.0])
            if q[0] == "tick":
                t[2] = q[2]
                if t[0] <= 0 and t[1] <= 0:
                    t[0] = t[1] = q[2]
            else:
                if q[2] > 0:
                    t[0] = q[2]
                if q[3] > 0:
                    t[1] = q[3]
            t[3] = _time.time()

    def _run(self):
        wait = 1.0
        while not self.stop.is_set():
            cli = None
            try:
                inv, tok = self.creds_fn()
                cli = self.factory(self.url, "pyea-%d" % (int(_time.time()) % 100000), inv, tok)
                cli.connect()
                self.error, wait = "", 1.0
                self._sub_done = set()
                while not self.stop.is_set():
                    with self._lock:
                        new = [s for s in self.want if s not in self._sub_done]
                    if new:
                        cli.subscribe([t % s for s in new for t in self.TOPICS])
                        self._sub_done.update(new)
                    for topic, payload in cli.poll(1.0):
                        self._apply(topic, payload)
            except Exception as e:                              # noqa: BLE001 - nối lại; lỗi hiện ở tick() qua self.error
                self.error = str(e)[:160]
            finally:
                try:
                    if cli is not None:
                        cli.close()
                except Exception:                                # noqa: BLE001
                    pass
            self.stop.wait(wait)
            wait = min(30.0, wait * 2)

    def close(self):
        self.stop.set()


class DnseBackend(MtBackend):
    name = "dnse"
    limiter_kind = "generic"
    native_kinds = {"limit"}                                     # stop/stop-limit: engine mô phỏng bằng phần mềm
    RES = {"1m": "1", "5m": "5", "15m": "15", "30m": "30", "1h": "1H", "1d": "1D"}

    def __init__(self, api, stream_url=MQTT_URL, loan_package=0, account="", price_scale=1.0, trading_token="", otp="", otp_smart=True,
                 chart_url=CHART_URL, http=None, stream=None):
        self.api, self.loan, self.acc_pref, self.scale = api, loan_package, str(account or "").strip(), float(price_scale or 1.0)
        self.tt, self.tt_t = str(trading_token or "").strip(), 0.0
        self.otp, self.otp_smart = str(otp or "").strip(), bool(otp_smart)
        self.chart_url, self._http = chart_url.rstrip("/"), http or http_json
        self._acc = None
        self._inv = ""
        self.stream = stream or DnseStream(stream_url, self._creds)

    # ---- tài khoản / token ----
    def _info(self):
        if self._acc is None:
            accs = self.api.accounts()
            if not accs:
                raise BridgeError("DNSE không trả tiểu khoản nào")
            pick = next((a for a in accs if str(a.get("id")) == self.acc_pref), None) if self.acc_pref else accs[0]
            if pick is None:
                raise BridgeError("Không thấy tiểu khoản %s (có: %s)" % (self.acc_pref, ", ".join(str(a.get("id")) for a in accs)))
            self._acc, self._inv = str(pick.get("id")), str(pick.get("investorId", ""))
            self._deriv_acc = bool(pick.get("derivativeAccount"))
        return self._acc

    def _creds(self):
        self._info()
        return self._inv or "investor", self.api.token()

    def _tt(self):
        if self.tt and (self.tt_t == 0.0 or _time.time() - self.tt_t < 7.5 * 3600):
            return self.tt
        if not self.otp:
            raise BridgeError("Chưa có trading token DNSE: nhập OTP (Smart OTP hoặc Email OTP) ở Cài đặt rồi thử lại - token có hiệu lực 8 giờ")
        self.tt, self.tt_t = self.api.trading_token(self.otp, self.otp_smart), _time.time()
        self.otp = ""                                            # OTP chỉ dùng 1 lần
        return self.tt

    def ping(self):
        self._info()
        return self.account()

    # ---- dữ liệu ----
    def symbols(self):
        return []

    def tick(self, symbol):
        self.stream.watch(symbol)
        t = self.stream.get(symbol)
        if not t or (t[0] <= 0 and t[1] <= 0):
            raise BridgeError("Chưa có giá %s từ MQTT DNSE%s" % (symbol, (" (%s)" % self.stream.error) if self.stream.error else ""))
        bid, ask = t[0] or t[1], t[1] or t[0]
        return bid * self.scale, ask * self.scale, t[3]

    def candles(self, symbol, tf, count, end=None):
        res = self.RES.get(tf)
        if res is None:
            raise BridgeError("DNSE: khung %s chưa hỗ trợ (có: %s)" % (tf, ", ".join(self.RES)))
        to = int(end or _time.time())
        frm = to - int(count) * TIMEFRAMES[tf] * (3 if tf in ("1d",) else 2)
        kind = "derivative" if is_derivative(symbol) else "stock"
        try:
            d = self._http(self.chart_url + "/" + kind, {"from": frm, "to": to, "symbol": symbol.upper(), "resolution": res}, timeout=15)
        except HttpError as e:
            raise BridgeError("DNSE nến %s: HTTP %s (đường dẫn nến chưa xác minh - chỉnh `dnse_chart_url`)" % (symbol, e.status))
        t, o, h, l, c, v = (d.get(k) or [] for k in ("t", "o", "h", "l", "c", "v"))
        n = min(len(t), len(o), len(h), len(l), len(c))
        out = [Candle(float(t[i]), float(o[i]) * self.scale, float(h[i]) * self.scale, float(l[i]) * self.scale, float(c[i]) * self.scale,
                      float(v[i]) if i < len(v) else 0.0) for i in range(n)]
        return out[-int(count):]

    def account(self):
        b = self.api.balances(self._info())
        eq = _num(b.get("netAssetValue"), _num(b.get("totalCash")))
        return {"balance": _num(b.get("totalCash")), "equity": eq, "margin": _num(b.get("marginDebt")), "free_margin": _num(b.get("availableCash")),
                "leverage": 1, "currency": "VND", "hedging": False}

    def positions(self):
        out = []
        for d in self.api.deals(self._info()):
            if str(d.get("status", "OPEN")).upper() != "OPEN":
                continue
            vol = _num(d.get("accumulateQuantity")) - _num(d.get("closedQuantity"))
            if vol <= 0:
                continue
            out.append({"id": str(d.get("id")), "symbol": str(d.get("symbol", "")).upper(), "side": "sell" if str(d.get("side", "NB")).upper() == "NS" else "buy",
                        "volume": vol, "price": _num(d.get("averageCostPrice"), _num(d.get("costPrice"))) * self.scale, "sl": 0.0, "tp": 0.0,
                        "time": _ts(d.get("createdDate"))})
        return out

    def _orders_raw(self):
        acc = self._info()
        rows = list(self.api.orders(acc, False))
        if getattr(self, "_deriv_acc", False):
            rows += list(self.api.orders(acc, True))
        return rows

    def orders(self):
        out = []
        for o in self._orders_raw():
            if str(o.get("orderStatus", "")).lower() not in OPEN_STATUS:
                continue
            out.append({"id": str(o.get("id")), "symbol": str(o.get("symbol", "")).upper(), "side": "sell" if str(o.get("side")).upper() == "NS" else "buy",
                        "kind": "limit", "volume": _num(o.get("leaveQuantity"), _num(o.get("quantity"))), "price": _num(o.get("price")) * self.scale,
                        "sl": 0.0, "tp": 0.0})
        return out

    def spec(self, symbol):
        if is_derivative(symbol):
            return {"volume_min": 1.0, "volume_max": 500.0, "volume_step": 1.0}
        return {"volume_min": 100.0, "volume_max": 500000.0, "volume_step": 100.0}

    # ---- lệnh (KHÔNG bao giờ tự gửi lại: lỗi mạng -> BridgeError để engine kiểm tra trạng thái) ----
    def _send(self, symbol, side, volume, price, otype):
        if not self.loan and self.loan != 0:
            raise BridgeError("Chưa đặt gói vay DNSE (dnse_loan_package)")
        acc = self._info()
        body = {"symbol": symbol.upper(), "side": "NS" if side == "sell" else "NB", "orderType": otype, "quantity": int(volume), "accountNo": acc,
                "loanPackageId": self.loan}
        if price:
            body["price"] = price / self.scale
        r = self.api.place_order(is_derivative(symbol), body, self._tt())
        if r.get("error"):
            raise BridgeError("DNSE từ chối lệnh: %s" % r.get("error"))
        return {"order_id": str(r.get("id", "")), "position_id": "", "price": _num(r.get("averagePrice")) * self.scale or None, "volume": float(volume)}

    def market(self, symbol, side, volume, comment=""):
        return self._send(symbol, side, volume, 0.0, "MTL" if is_derivative(symbol) else "MP")

    def close_position(self, position_id, volume=None):
        p = next((x for x in self.positions() if x["id"] == str(position_id)), None)
        if p is None:
            raise BridgeError("Không thấy vị thế DNSE %s" % position_id)
        return self.market(p["symbol"], "sell" if p["side"] == "buy" else "buy", volume or p["volume"])

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        if kind != "limit":
            raise BridgeError("DNSE chỉ hỗ trợ lệnh chờ LO native (stop do app mô phỏng)")
        return self._send(symbol, side, volume, price, "LO")

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        raise BridgeError("DNSE V1 không có sửa lệnh: app sẽ huỷ rồi đặt lại")

    def cancel_pending(self, order_id):
        row = next((o for o in self._orders_raw() if str(o.get("id")) == str(order_id)), None)
        self.api.cancel(order_id, self._info(), self._tt(), is_derivative(row.get("symbol")) if row else False)
        return {"order_id": str(order_id)}

    def deals(self, since):
        return []

    def close(self):
        self.stream.close()


def make_backend(settings):
    api = DnseV1(settings.get("dnse_username", ""), settings.get("dnse_password", ""), settings.get("dnse_api_base") or API_V1)
    lp = str(settings.get("dnse_loan_package", "") or "").strip()
    return DnseBackend(api, settings.get("dnse_mqtt_url") or MQTT_URL, int(lp) if lp.lstrip("-").isdigit() else "", settings.get("dnse_account", ""),
                       float(settings.get("dnse_price_scale", 1.0) or 1.0), settings.get("dnse_trading_token", ""), settings.get("dnse_otp", ""),
                       settings.get("dnse_otp_kind", "smart") != "email", settings.get("dnse_chart_url") or CHART_URL)
