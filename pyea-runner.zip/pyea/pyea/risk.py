"""
Cảnh báo rủi ro hiện MỘT LẦN khi mở app lần đầu (và lại hiện khi RISK_VERSION tăng), và là điều kiện để chạy LIVE.
Không Kivy: UI chỉ gọi needed()/acknowledge() và hiển thị RISK_TEXT. Xác nhận lưu trong ui_prefs.json (khoá "risk_ack").
"""
import time

RISK_VERSION = 1

RISK_TITLE = "Trước khi dùng - rủi ro & trách nhiệm"
RISK_TEXT = (
    "PyEA Runner là công cụ tự động hoá giao dịch, KHÔNG phải lời khuyên đầu tư.\n\n"
    "• Giao dịch có đòn bẩy (forex, CFD, futures) có thể làm bạn MẤT TOÀN BỘ vốn, có sàn còn thua quá số vốn.\n"
    "• Kết quả backtest / paper KHÔNG bảo đảm kết quả thật: trượt giá, spread nở, gián đoạn mạng, lệnh bị sàn từ chối.\n"
    "• Bot bạn tự viết hay do AI sinh ra có thể SAI. AI có thể bịa và tự tin sai. Luôn đọc code, thử trên DEMO/testnet với khối lượng nhỏ nhất.\n"
    "• Điện thoại có thể hết pin, mất mạng hoặc bị hệ thống giết app: lệnh có thể không được quản lý. Đặt SL/TP trên sàn khi có thể.\n"
    "• API key: chỉ cấp quyền giao dịch, KHÔNG bật quyền rút tiền; tạo khoá riêng cho app, giới hạn IP nếu sàn cho phép.\n"
    "• Bạn chịu hoàn toàn trách nhiệm về mọi lệnh được gửi từ tài khoản của bạn. Tác giả ứng dụng không chịu trách nhiệm về lỗ.\n\n"
    "Chỉ dùng số tiền bạn có thể chấp nhận mất."
)


def needed(prefs, version=RISK_VERSION):
    """True nếu người dùng chưa xác nhận bản cảnh báo này."""
    try:
        return int((prefs or {}).get("risk_ack", 0)) < version
    except (TypeError, ValueError):
        return True


def acknowledge(prefs, version=RISK_VERSION):
    """Ghi xác nhận vào dict prefs (người gọi tự lưu)."""
    prefs["risk_ack"] = version
    prefs["risk_ack_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    return prefs
