"""ĐO TẢI CPU THEO THÀNH PHẦN (không cần Kivy/thiết bị): chạy đúng mã của app trên một phiên đồng bộ và đo thời gian CPU mỗi phần trong
MỘT GIÂY ở trạng thái ổn định (1 tick/giây/mã, giao diện làm mới 1 lần/giây). Kết quả hữu ích nhất là TỶ LỆ giữa các phần (thuần Python nên
gần như không phụ thuộc máy); số tuyệt đối chỉ là của máy chạy đo. KHÔNG đo: vẽ Kivy/GPU, mạng, đánh thức CPU/pin (cần thiết bị).
Chạy: python -m pyea.loadbench [--bots N] [--indicators K] [--seconds S]"""
import argparse
import json
import os
import random
import shutil
import tempfile
import time
from collections import deque

from . import chart_indicators as chind
from .engine import Account, CandleBuilder, TradingSession
from .ipc import ServiceClient, merge_chart, snapshot_from_json, snapshot_to_json, split_chart
from .backtest import _ReplayFeed
from .sdk import Candle, Tick
from .settings import default_settings

BOT_CYCLE = ["ma_cross", "rsi_reversion", "breakout", "dca"]
UI_INDICATORS = ["ma", "bb", "rsi", "macd", "stoch", "atr", "ichimoku", "alligator"]


def _cpu():
    return time.process_time()


def build(n_bots, tf_s=60, seed=7):
    rnd = random.Random(seed)
    tmp = tempfile.mkdtemp(prefix="pyea-bench-")
    from .storage import Store
    store = Store(tmp)
    store.seed_examples()
    st = default_settings()
    st.update(mode="paper", exchange="simulated", initial_balance=100000.0, leverage=10.0, commission_pct=0.0, spread_pct=0.0, max_loss_pct=0.0,
              state_file=None)
    sess = TradingSession(st, sync=True, feed=_ReplayFeed())
    sess.events = deque(maxlen=200000)
    sess.account = Account(st["initial_balance"], 0.0, 10.0)
    sess.status = "running"
    sess.ready.set()
    p, t0, cs = 30000.0, 1.7e9, []
    for i in range(600):
        o = p
        p *= 1 + rnd.gauss(0, 0.0007)
        cs.append(Candle(t0 + i * tf_s, o, max(o, p) * 1.0002, min(o, p) * 0.9998, p, 10.0))
    b = CandleBuilder(tf_s, max_len=1500, tf="1m")
    b.seed(cs[:-1], cs[-1].time)
    sess.builders[("BTCUSD", "1m")] = b
    insts = []
    for k in range(n_bots):
        name = BOT_CYCLE[k % len(BOT_CYCLE)]
        path = os.path.join(store.bots_dir, name + ".py")
        if not os.path.exists(path):
            path = os.path.join(store.bots_dir, name + ".py.txt")
        inst = sess.attach(path, "BTCUSD", "1m", {}, iid="b%d" % k)
        inst.plot_cap = 5000
        inst.start()
        insts.append(inst)
    return sess, insts, tmp, rnd, p, t0 + 600 * tf_s


def run(n_bots=4, seconds=3000, n_ind=6, split=True):
    sess, insts, tmp, rnd, price, t = build(n_bots)
    out = {"bots": n_bots, "seconds": seconds, "indicators": n_ind}
    # ---- 1) tick: lõi vỏ (mark, SL/TP, nến, cảnh báo) và bot, đo từng cái
    t_all = t_bot = 0.0
    sess_deliver = {id(i): 0.0 for i in insts}
    orig = {}
    for inst in insts:
        orig[id(inst)] = inst.deliver

        def mk(i, f):
            def w(tick, closed):
                c0 = _cpu()
                f(tick, closed)
                sess_deliver[id(i)] += _cpu() - c0
            return w
        inst.deliver = mk(inst, orig[id(inst)])
    for s in range(seconds):
        price *= 1 + rnd.gauss(0, 0.0003)
        t += 1.0
        c0 = _cpu()
        sess.process_tick(Tick("BTCUSD", t, price * 0.9999, price * 1.0001))
        t_all += _cpu() - c0
    t_bot = sum(sess_deliver.values())
    out["tick_core_ms"] = (t_all - t_bot) / seconds * 1000
    out["tick_bots_ms"] = t_bot / seconds * 1000
    out["per_bot_ms"] = {BOT_CYCLE[k % 4] + "#%d" % k: sess_deliver[id(i)] / seconds * 1000 for k, i in enumerate(insts)}
    # ---- 2) dịch vụ nền: dựng ảnh chụp + JSON + ghi file (mỗi giây khi UI mở)
    client = ServiceClient(tmp)
    n = 200
    last_sig, n_chart_w = None, 0
    pc = {"chart": 0.0, "snap": 0.0, "json": 0.0, "write": 0.0}
    for _ in range(n):
        c0 = _cpu(); ch = sess.chart("BTCUSD", "1m", 400); c1 = _cpu()
        snap = sess.snapshot(); c2 = _cpu()
        d = snapshot_to_json(snap, ch)
        if split:
            static, sig = split_chart(d)
            if static is not None and sig != last_sig:
                client.write_chart(static); last_sig = sig; n_chart_w += 1
        st = {"snapshot": d, "logs": [list(x) for x in sess.get_logs(0)[-150:]], "hb": t}
        raw = json.dumps(st, ensure_ascii=False, separators=(",", ":")); c3 = _cpu()
        client.write_state(st); c4 = _cpu()
        pc["chart"] += c1 - c0; pc["snap"] += c2 - c1; pc["json"] += c3 - c2; pc["write"] += c4 - c3
    out["publish_ms"] = {k: v / n * 1000 for k, v in pc.items()}
    out["state_bytes"] = len(raw)
    # ---- 3) giao diện: đọc file + phân tích JSON + dựng đối tượng + tính chỉ báo hiển thị
    pu = {"read": 0.0, "objs": 0.0, "indicators": 0.0}
    cache = None
    cfgs = [chind.new_cfg(k) for k in UI_INDICATORS[:n_ind] if k in chind.INDICATORS]
    for _ in range(n):
        c0 = _cpu(); stt = client.read_state(); c1 = _cpu()
        dd = stt["snapshot"]
        if split and dd.get("chart") and "static" in dd["chart"]:
            if cache is None or cache.get("sig") != dd["chart"]["static"]:
                cache = client.read_chart()
            dd = dict(dd, chart=merge_chart(dd["chart"], cache))
        sn = snapshot_from_json(dd); c2 = _cpu()
        cand = sn["chart"]["candles"] if sn and sn.get("chart") else []
        for c in cfgs:
            chind.compute(c, cand)
        c3 = _cpu()
        pu["read"] += c1 - c0; pu["objs"] += c2 - c1; pu["indicators"] += c3 - c2
    out["ui_ms"] = {k: v / n * 1000 for k, v in pu.items()}
    # ---- 4) vòng chờ lệnh IPC (poll 0,25s = 4 lần/giây)
    cmd_dir = os.path.join(tmp, "cmd")
    os.makedirs(cmd_dir, exist_ok=True)
    c0 = _cpu()
    for _ in range(4000):
        sorted(os.listdir(cmd_dir))
    out["poll_ms_per_s"] = (_cpu() - c0) / 4000 * 4 * 1000
    shutil.rmtree(tmp, ignore_errors=True)
    out["total_ms_per_s"] = (out["tick_core_ms"] + out["tick_bots_ms"] + sum(out["publish_ms"].values())
                             + sum(out["ui_ms"].values()) + out["poll_ms_per_s"])
    return out


def report(o):
    tot = o["total_ms_per_s"]

    def row(name, ms):
        return "  %-34s %8.3f ms/s  %5.1f%%" % (name, ms, ms / tot * 100 if tot else 0)
    L = ["ĐO TẢI CPU (sandbox, %d bot, %d chỉ báo hiển thị, %d giây mô phỏng) - CHỈ tính thành phần Python, chưa gồm vẽ Kivy/mạng" % (o["bots"], o["indicators"], o["seconds"]),
         row("Tick: lõi vỏ (mark, SL/TP, nến...)", o["tick_core_ms"]), row("Tick: mã bot (on_tick/on_bar)", o["tick_bots_ms"])]
    p = o["publish_ms"]
    L += [row("Dịch vụ: dựng chart()", p["chart"]), row("Dịch vụ: dựng snapshot()", p["snap"]),
          row("Dịch vụ: tuần tự hoá JSON", p["json"]), row("Dịch vụ: ghi state.json", p["write"])]
    u = o["ui_ms"]
    L += [row("UI: đọc+phân tích state.json", u["read"]), row("UI: dựng đối tượng từ JSON", u["objs"]),
          row("UI: tính chỉ báo hiển thị", u["indicators"]), row("Poll IPC 4 lần/giây", o["poll_ms_per_s"]),
          "  %-34s %8.3f ms/s  = %.2f%% của MỘT nhân (máy đo)" % ("TỔNG", tot, tot / 10.0), "  state.json: %.1f KB mỗi lần ghi" % (o["state_bytes"] / 1024.0)]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--bots", type=int, default=4)
    ap.add_argument("--indicators", type=int, default=6)
    ap.add_argument("--seconds", type=int, default=3000)
    ap.add_argument("--no-split", action="store_true", help="đo kiểu cũ (một state.json to)")
    a = ap.parse_args(argv)
    print(report(run(a.bots, a.seconds, a.indicators, not a.no_split)))


if __name__ == "__main__":
    main()
