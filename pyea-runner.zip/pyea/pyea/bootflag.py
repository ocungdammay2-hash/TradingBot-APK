"""Cờ «tự chạy lại sau khi khởi động máy» - phần LOGIC, không phụ thuộc Android.

BootReceiver.java (nhận BOOT_COMPLETED / MY_PACKAGE_REPLACED) chỉ dựng lại dịch vụ nếu có file `boot_resume.flag` trong thư mục files của app.
Dịch vụ Python giữ file này: có khi phiên đang cần chạy (hoặc `desired` còn ghi «cần chạy») VÀ người dùng bật `auto_resume` + `start_on_boot`;
người dùng chủ động dừng phiên -> xoá cờ, nên máy khởi động lại sẽ không tự bật bot ngoài ý muốn."""
import os

FLAG = "boot_resume.flag"


def path(data_dir):
    return os.path.join(data_dir, FLAG)


def sync(data_dir, want, mirror_dir=None, loud=True):
    """Đặt/xoá cờ theo `want` (kèm bản sao ở `mirror_dir` = kho «device protected» đọc được TRƯỚC khi mở khoá máy; cờ không chứa bí mật).
    Nội dung cờ: «A» = báo động kiểu báo thức, «Q» = chỉ thông báo thường (BootReceiver.java đọc ký tự đầu).
    Trả về True nếu cờ chính đang tồn tại sau khi gọi."""
    if mirror_dir and mirror_dir != data_dir:
        _one(mirror_dir, want, loud)
    return _one(data_dir, want, loud)


def _one(data_dir, want, loud=True):
    p = path(data_dir)
    mark = "A" if loud else "Q"
    try:
        if want:
            cur = None
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    cur = f.read(1)
            if cur != mark:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(mark)
            return True
        if os.path.exists(p):
            os.remove(p)
    except OSError:
        return os.path.exists(p)
    return False
