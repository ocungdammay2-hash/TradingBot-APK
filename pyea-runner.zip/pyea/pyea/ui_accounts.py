"""Giao diện NHIỀU TÀI KHOẢN (mixin của PyEAApp). Lõi ở accounts.py + ipc.py (ServiceHost chạy song song nhiều phiên).

Quy ước: tài khoản CHÍNH = cài đặt hiện tại. Tài khoản PHỤ = hồ sơ lưu từ cài đặt hiện tại ("Thêm từ cài đặt hiện tại").
Bot gắn có trường `account` (mặc định main). "Xem" một tài khoản = hoán đổi `self.ctl` sang handle của tài khoản đó, nên mọi tab
(Giao dịch, Biểu đồ, Bot...) thao tác trên tài khoản đang xem. Chạy song song có ở CẢ HAI chế độ: dịch vụ nền (mỗi tài khoản một phiên trong ServiceHost)
và chạy TRỰC TIẾP trong app (mỗi tài khoản một TradingSession + LocalController riêng; không có AI hub cho tài khoản phụ)."""
import os
import time

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from .ui_widgets import StyledPopup

from . import android_native as native
from .accounts import MAIN, AccountBook
from .controller import LocalController
from .engine import TradingSession
from .ui_widgets import (AMBER, BLUE, GREEN, MIN_TOUCH, MUTED, PANEL2, RED, TEXT, UP, confirm, mkbtn, vbox, vscroll, wlabel)


class AccountsUIMixin:
    # ---------------------------------------------------------------- dữ liệu
    def account_book(self):
        return AccountBook(self.data_dir)

    def account_name(self, aid):
        if aid == MAIN:
            return "Chính"
        a = self.account_book().get(aid)
        return a["name"] if a else aid

    def ctl_for(self, cfg):
        """Controller của tài khoản mà cấu hình bot `cfg` thuộc về (None nếu phiên đó chưa chạy)."""
        aid = (cfg or {}).get("account") or MAIN
        if aid == MAIN:
            return getattr(self, "main_ctl", None) or (self.ctl if self.is_connected() else None)
        return self.extra_handles.get(aid)

    def reattach_extra_accounts(self, handle):
        """Mở lại app khi dịch vụ nền đang chạy nhiều tài khoản: gắn lại handle cho từng phiên phụ (token lấy từ tóm tắt)."""
        self.main_ctl = handle
        book = self.account_book()
        for row in handle.accounts():
            aid = row.get("id")
            if aid in (None, MAIN) or aid in self.extra_handles or not row.get("alive"):
                continue
            ev = os.path.join(book.data_dir_for(aid), "events.jsonl")
            self.extra_handles[aid] = handle.for_account(aid, ev, token=row.get("token"))

    def _account_cfg(self, acc, resume):
        book = self.account_book()
        st = book.effective_settings(acc["id"], self.settings)
        inst = [dict(c, running=bool(c.get("auto", True))) for c in self.attach_cfgs if (c.get("account") or MAIN) == acc["id"]]
        return {"settings": st, "resume": resume, "ai_auto": False, "log_file": None, "trades_csv": None, "account_name": acc["name"], "instances": inst}

    # ---------------------------------------------------------------- chạy / dừng tài khoản phụ
    def _start_local_account(self, acc, cfg):
        """Một tài khoản phụ chạy TRỰC TIẾP trong app (không có dịch vụ nền): phiên + controller riêng, dữ liệu trong thư mục của tài khoản
        (sổ lệnh, nhật ký, lịch sử lệnh, cảnh báo giá) - giống hệt cách ServiceHost chạy một tài khoản phụ."""
        from .storage import Store
        store = Store(self.account_book().data_dir_for(acc["id"]))
        if not cfg.get("resume"):                                      # phiên mới: xoá sổ lệnh + sự kiện của phiên cũ
            for path, wipe in ((store.state_path, "rm"), (store.events_path, "truncate")):
                try:
                    os.remove(path) if wipe == "rm" else open(path, "w").close()
                except OSError:
                    pass
        name = acc["name"]
        sess = TradingSession(cfg["settings"], log_file=os.path.join(store.logs_dir, time.strftime("%Y%m%d") + ".log"), trades_csv=store.trades_csv,
                              state_file=store.state_path, events_file=store.events_path, resume=bool(cfg.get("resume")),
                              alarm_cb=lambda t, x, n=name, **kw: native.notify_alarm("[%s] %s" % (n, t), x, **kw), alerts_file=store.alerts_path)
        ctl = LocalController(sess, account_id=acc["id"], account_name=name)
        for c in cfg.get("instances", []):
            ctl.attach(c, start=c.get("running", True))
        ctl.start()
        return ctl

    def _start_extra_accounts(self, handle, resume, local=False):
        """Gọi sau khi phiên chính đã chạy (qua dịch vụ nền, hoặc local=True: trực tiếp trong app). Tài khoản phụ chạy TIỀN THẬT phải được xác nhận riêng."""
        self.main_ctl = handle
        book = self.account_book()
        accs = book.enabled()
        if not accs:
            return []
        sts = {a["id"]: book.effective_settings(a["id"], self.settings) for a in accs}
        runnable = []
        for a in accs:
            st = sts[a["id"]]
            if st.get("mode") == "live" and not st.get("live_confirm"):
                self.toast("Tài khoản '%s' ở chế độ LIVE nhưng chưa tick xác nhận rủi ro - bỏ qua." % a["name"])
            else:
                runnable.append(a)
        real = [a["name"] for a in runnable if sts[a["id"]].get("mode") == "live" and not sts[a["id"]].get("testnet")]

        def go():
            names = []
            for a in runnable:
                ev = os.path.join(book.data_dir_for(a["id"]), "events.jsonl")
                try:
                    if local:
                        hx = self._start_local_account(a, self._account_cfg(a, resume))
                    else:
                        hx = handle.for_account(a["id"], ev, pending=True)
                        hx.start(self._account_cfg(a, resume))
                except Exception as e:                                        # noqa: BLE001 - một tài khoản lỗi không chặn tài khoản khác
                    self.toast("Không khởi động được tài khoản '%s': %s" % (a["name"], e))
                    continue
                self.extra_handles[a["id"]] = hx
                names.append(a["name"])
            if names:
                self.log_tab.append([(0, __import__("time").time(), "INFO", "Tài khoản phụ chạy song song: %s" % ", ".join(names))])
        if real:
            confirm("GIAO DỊCH TIỀN THẬT (tài khoản phụ)",
                    "Các tài khoản phụ sau sẽ đặt lệnh trên tài khoản THẬT và có thể làm mất vốn: %s. Bạn đã thử kỹ ở paper/demo chưa?" % ", ".join(real),
                    go, "Chạy song song")
        else:
            go()
        return [a["name"] for a in runnable]

    def _stop_extra_accounts(self):
        for hx in list(self.extra_handles.values()):
            try:
                hx.stop()
            except Exception:                                                 # noqa: BLE001
                pass

    # ---------------------------------------------------------------- xem tài khoản
    def view_account(self, aid):
        main = getattr(self, "main_ctl", None)
        if main is None or getattr(main, "kind", "") not in ("service", "local"):
            self.toast("Chưa có phiên nào đang chạy - bấm Bắt đầu để chạy các tài khoản.")
            return False
        ctl = main if aid == MAIN else self.extra_handles.get(aid)
        if ctl is None:
            self.toast("Tài khoản '%s' chưa chạy - bấm Bắt đầu (và bật 'chạy song song')." % self.account_name(aid))
            return False
        if getattr(main, "kind", "") == "service":
            main.set_view(aid)                                        # dịch vụ nền: báo cho dịch vụ biết tài khoản nào đang được xem
        self.ctl = ctl
        self.viewed = aid
        self.last_snap = None
        self.log_cursor = 0
        self.log_tab.clear()
        self.trade_tab._tr_sig = None
        self.chart_tab._ev_sig = None
        self.toast("Đang xem tài khoản: %s" % self.account_name(aid))
        return True

    # ---------------------------------------------------------------- hộp thoại
    def accounts_dialog(self, *_):
        book = self.account_book()
        rows = book.list()
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box = vbox(spacing=dp(6))
        viewed = getattr(self, "viewed", MAIN)
        box.add_widget(wlabel("Mỗi tài khoản chạy MỘT phiên riêng trong dịch vụ nền (sổ lệnh, nhật ký, đồng bộ sàn riêng). "
                              "Chạy được cả khi bật 'Chạy nền' lẫn chạy trực tiếp trong app (khuyên dùng chạy nền). Lưu hồ sơ từ CÀI ĐẶT HIỆN TẠI (sàn + khoá + chế độ + rủi ro).", 11, MUTED))
        pop = StyledPopup(title="Tài khoản (chạy song song)", content=content, size_hint=(0.97, 0.92), auto_dismiss=False)

        def reopen():
            pop.dismiss()
            self.accounts_dialog()

        box.add_widget(wlabel("● Chính  (cài đặt hiện tại: %s · %s)%s" % (self.settings["exchange"], self.settings["mode"],
                                                                      "   ◄ đang xem" if viewed == MAIN else ""), 13, UP if viewed == MAIN else TEXT))
        r0 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r0.add_widget(mkbtn("Xem tài khoản chính", PANEL2, size=12, on_release=lambda *_: (self.view_account(MAIN), reopen())))
        box.add_widget(r0)
        for a in rows:
            st = a["settings"]
            on = a.get("enabled", True)
            running = a["id"] in self.extra_handles
            box.add_widget(wlabel("● %s  (%s · %s)  ·  %s%s%s" % (a["name"], st.get("exchange", "?"), st.get("mode", "?"),
                                                                "chạy song song: BẬT" if on else "chạy song song: tắt", "  ·  ĐANG CHẠY" if running else "",
                                                                "   ◄ đang xem" if viewed == a["id"] else ""), 13, UP if viewed == a["id"] else TEXT))
            r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
            r.add_widget(mkbtn("Tắt" if on else "Bật", PANEL2, size=11, on_release=lambda *_, i=a["id"], o=on: (book.update(i, enabled=not o), reopen())))
            r.add_widget(mkbtn("Xem", PANEL2, size=11, on_release=lambda *_, i=a["id"]: (self.view_account(i), reopen())))
            r.add_widget(mkbtn("Lưu cài đặt vào", PANEL2, size=11, on_release=lambda *_, i=a["id"], n=a["name"]: confirm(
                "Cập nhật hồ sơ", "Ghi đè hồ sơ '%s' bằng CÀI ĐẶT HIỆN TẠI?" % n, lambda: (book.update(i, settings=self.settings), reopen()), "Ghi đè", GREEN)))
            r.add_widget(mkbtn("Xoá", RED, size=11, on_release=lambda *_, i=a["id"], n=a["name"]: confirm(
                "Xoá tài khoản", "Xoá hồ sơ '%s'? (phiên đang chạy vẫn chạy tới khi dừng; dữ liệu trong thư mục tài khoản được giữ lại)" % n,
                lambda: (book.remove(i), self.attach_cfgs.__setitem__(slice(None), [c for c in self.attach_cfgs if (c.get("account") or MAIN) != i]),
                         self._save_attach(), reopen()), "Xoá")))
            box.add_widget(r)
        if not rows:
            box.add_widget(wlabel("Chưa có tài khoản phụ. Cấu hình sàn ở tab Cài đặt cho tài khoản đó, bấm 'Lưu', rồi 'Thêm từ cài đặt hiện tại'.", 12, AMBER))
        content.add_widget(vscroll(box))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Thêm từ cài đặt hiện tại", GREEN, size=12, on_release=lambda *_: (pop.dismiss(), self._add_account_dialog())))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        content.add_widget(row)
        pop.open()

    def _add_account_dialog(self):
        from .ui import mk_input
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        ti = mk_input("", "Tên tài khoản (vd Exness VN, Binance futures)")
        box.add_widget(wlabel("Hồ sơ sẽ lưu: sàn=%s · chế độ=%s · khoá API (mã hoá) · watchlist · rủi ro." % (self.settings["exchange"], self.settings["mode"]), 12, TEXT))
        box.add_widget(ti)
        msg = wlabel("", 11, AMBER)
        box.add_widget(msg)
        pop = StyledPopup(title="Thêm tài khoản", content=box, size_hint=(0.95, 0.5), auto_dismiss=False)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def ok(*_):
            try:
                a = self.account_book().add(ti.text, self.settings)
            except ValueError as e:
                msg.text = str(e)
                return
            self.toast("Đã lưu tài khoản '%s'. Bấm Bắt đầu để chạy song song." % a["name"])
            pop.dismiss()
            self.accounts_dialog()
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()
