"""Nhật ký thay đổi hiển thị trong app («Có gì mới») + lịch sử API bot (để tác giả bot biết tính năng nào cần `# @api_min`)."""

# (phiên bản app, ngày, [thay đổi]) - mới nhất ở đầu
CHANGELOG = [
    ("1.9.50", "2026-11-14", [
        "SỬA build GitHub «Could not find kxml2/guava/asm…»: workflow dùng lại dist Gradle cũ trong cache (AGP cũ + jcenter đã chết). Đổi tiền tố cache, bỏ restore-key rộng, xoá thư mục dists trước khi build. (Suy luận từ log, chưa xác nhận trên runner.)",
        "Backtest → «Tối ưu hoá»: thêm phương pháp DI TRUYỀN (như Genetic của MT5): lưới lớn không giới hạn, chỉ thử tối đa 150 tổ hợp. Quét lưới vẫn giữ.",
        "Backtest: nút «Monte Carlo + Sortino · Calmar · R · theo tháng» cho lần chạy vừa xong (trộn thứ tự + lấy mẫu lại 1000 lần). Chỉ cho biết độ nhạy với thứ tự lệnh, KHÔNG dự báo.",
        "Webhook TradingView: tự bỏ tiền tố sàn («BINANCE:BTCUSDT.P» → BTCUSDT), ánh xạ mã tự khai (--webhook-symbol-map), hậu tố (--webhook-symbol-suffix), bí danh action (long/short/exit/flat) và qty; thêm executor chạy thẳng trong phiên PyEA.",
        "BOT THEO LUẬT: pyea/rules.py + bot mẫu «Bot theo luật» - gõ điều kiện vào/ra bằng biểu thức kiểu Pine rút gọn (sma/ema/rsi/atr/bollinger/macd, cross_above/cross_below, prev) mà không cần viết Python. Biểu thức kiểm bằng danh sách trắng, không chạy code tuỳ ý.",
        "NÓI THẲNG: các phần mới chỉ kiểm bằng test + chạy giao diện Kivy thật trên màn hình ảo (8 tab, không lỗi); CHƯA chạy trên điện thoại/sàn thật.",
    ]),
    ("1.9.49", "2026-11-10", [
        "KẾT NỐI DNSE (chứng khoán/phái sinh VN): chọn «dnse» ở Nguồn thị trường. Giá realtime qua MQTT/WebSocket (client MQTT 5 tự viết, không cần paho), tài khoản/số dư, vị thế (deal), sổ lệnh, đặt/huỷ lệnh LO/MP/MTL cho cổ phiếu và phái sinh, đăng nhập JWT tự gia hạn.",
        "OTP ngay trên điện thoại: nút «Gửi Email OTP DNSE» và «Lấy trading token DNSE» (Smart OTP hoặc Email OTP → trading token 8 giờ). Lệnh không bao giờ tự gửi lại khi lỗi mạng.",
        "Tra từ nhiều nguồn: tài liệu LightSpeed V1 chính thức, đặc tả MDDS + mã mẫu MQTT do bạn gửi, 2 repo bên thứ ba, README PyPI. Chi tiết và chỗ còn ĐOÁN (khoá JSON tick, đơn vị giá, đường dẫn nến): docs/DNSE.md.",
        "NÓI THẲNG: CHƯA thử tài khoản DNSE thật; mới kiểm bằng máy chủ MQTT/HTTP giả (23 test). Thử lệnh nhỏ trước.",
    ]),
    ("1.9.48", "2026-11-10", [
        "Trần đối tượng vẽ của bot nâng từ 60 lên 300 và CHỈNH ĐƯỢC (Cài đặt «Số đối tượng vẽ tối đa mỗi bot», tới 5000). Trần chỉ để biểu đồ không chậm và bot lỗi vòng lặp không tràn RAM.",
        "DNSE OpenAPI V2: thêm pyea/dnse.py (ký HTTP Signatures HMAC-SHA256, header, client mức thấp: accounts, balances, email OTP, đặt/huỷ lệnh không tự gửi lại) + test. CHƯA nối vào bot: còn thiếu đường dẫn danh sách lệnh/vị thế/nến và cách gửi OTP - xem docs/DNSE.md (đã tra 6+ nguồn).",
        "SỬA tài liệu: Candle.volume là TICK VOLUME với MT/Exness/OANDA (trước đây ghi nhầm là không có); OnChartEvent chỉ ảnh hưởng thao tác tay trên biểu đồ, không ảnh hưởng bot tự giao dịch.",
    ]),
    ("1.9.47", "2026-11-10", [
        "BOT VẼ LÊN BIỂU ĐỒ (API 1.8): api.draw_hline/draw_trend/draw_rect/draw_fib/draw_text(tên, ...), draw_delete, draw_clear - như ObjectCreate/ObjectMove/ObjectDelete của MQL5. Đối tượng của bot hiện chung biểu đồ với nét vẽ tay nhưng không lưu vào nét vẽ của bạn, không chọn/xoá bằng tay (xoá khi bot bị gỡ).",
        "SỔ LỆNH + GIAO DỊCH KHỚP: api.order_book(depth) và api.recent_trades(count) - hiện chỉ Binance (nguồn khác/backtest trả None, không bịa).",
        "GIÁ BINANCE ĐẨY QUA WEBSOCKET (cài đặt «Giá Binance đẩy qua WebSocket», mặc định bật; không dùng cho testnet): giá về ngay thay vì chờ chu kỳ thăm dò; mất luồng hoặc giá cũ quá 4 giây thì tự dùng REST. Chu kỳ lấy giá vẫn chỉnh được tới 0,2 giây cho các sàn khác.",
        "NÓI THẲNG: tất cả mới kiểm bằng máy chủ giả; chưa thử với Binance thật hay trên điện thoại. KHÔNG làm: DNSE (thiếu tài liệu ký request/OTP), tick-volume từng tick (nguồn giá không cấp), sự kiện chuột/nút trên biểu đồ.",
    ]),
    ("1.9.46", "2026-11-10", [
        "BOT ĐA MÃ (API 1.7): một bot đọc nến/giá và đặt lệnh trên MÃ KHÁC bằng symbol=... (candles, closes, tick_of, buy, sell, buy_limit/sell_limit/stop/stop_limit, positions, orders). Mã khác tự được thêm vào danh sách theo dõi giá. Giải quyết giới hạn «một mã/bot» so với EA MQL5.",
        "Backtest: run_backtest(..., extra={mã: {khung: nến}}) cho bot ĐỌC nến mã khác (chỉ nến đã đóng, không nhìn trước); chưa có dữ liệu thì báo lỗi rõ. Giao dịch nhiều mã trong backtest dùng chế độ danh mục.",
        "NÓI THẲNG: mới kiểm bằng giả lập; chưa thử trên điện thoại/sàn thật. Vẫn CHƯA làm: đối tượng vẽ do bot tạo trên biểu đồ, sổ lệnh sâu, dữ liệu tick từng giao dịch.",
    ]),
    ("1.9.45", "2026-11-10", [
        "TÀI LIỆU LẬP TRÌNH BOT: docs/BOT_DEV.md - quy tắc viết bot (cấu trúc file, vòng đời on_init/on_tick/on_bar/on_trade/on_timer/on_tester/on_deinit, tham chiếu self.api, mã Ret, danh sách bị chặn khi nạp, quyền, backtest/đa khung), bảng đối chiếu MQL5 → PyEA và bảng GIỚI HẠN so với EA MQL5.",
        "NÓI THẲNG về giới hạn: mỗi bot một mã; giá thăm dò ~1 giây (không hợp scalping/HFT); không chỉ báo .ex5, không đối tượng/sự kiện biểu đồ, không sổ lệnh sâu; backtest mô phỏng theo nến; chưa kiểm trên điện thoại/sàn thật. Có test kiểm mọi tên API trong tài liệu đều tồn tại.",
    ]),
    ("1.9.44", "2026-11-08", [
        "KẾT NỐI cTrader NGAY TỪ ĐIỆN THOẠI, KHÔNG máy tính/VPS/dịch vụ trung gian: chọn «Sàn = ctrader». App nối WebSocket thẳng tới live|demo.ctraderapi.com (cTrader Open API chính thức của Spotware) và dùng được cho bot như mọi sàn khác: giá, nến mọi khung, tài khoản, vị thế (SL/TP, sửa SL/TP), lệnh chờ limit/stop (đặt/sửa/huỷ), đóng một phần/toàn bộ, lịch sử deal, backtest dữ liệu thật, đa khung.",
        "Đăng nhập làm TRÊN ĐIỆN THOẠI: Cài đặt → «Đăng nhập cTrader» mở trình duyệt tới id.ctrader.com, mã đăng nhập quay về cổng cục bộ http://localhost:53682/callback ngay trên máy rồi đổi lấy token (không qua máy chủ nào của chúng tôi). «Chọn tài khoản cTrader» liệt kê tài khoản demo/live của token. Token tự làm mới khi hết hạn và được ghi bền ở một file dùng chung cho cả bot chạy riêng (vì làm mới sẽ vô hiệu token cũ).",
        "Cần một lần: đăng ký ứng dụng miễn phí ở openapi.ctrader.com bằng cTrader ID của bạn (lấy Client ID/Secret, thêm Redirect URI trên). Chỉ dùng được với broker CÓ cTrader (vd IC Markets, Pepperstone, FxPro, Spotware...). Lệnh giao dịch không tự gửi lại khi mất kết nối (tránh đặt trùng); báo lỗi tiếng Việt khi sàn từ chối.",
        "NÓI THẲNG: viết theo tài liệu + file .proto chính thức nhưng CHƯA chạy với broker/tài khoản cTrader thật (test dùng máy chủ giả). Chỗ tài liệu không rõ được ghi `# CHƯA XÁC MINH` trong pyea/ctrader.py (giới hạn cửa sổ thời gian nến - mã tự thu hẹp; bỏ trống SL/TP khi sửa; dấu hoa hồng; sự kiện lệnh có lặp clientMsgId hay không - mã đã có đường dự phòng). BẮT BUỘC thử tài khoản DEMO trước.",
        "Về Exness và ccxt: ccxt chỉ gồm các SÀN CRYPTO nên KHÔNG có Exness. Exness vẫn dùng «Exness API» chính thức (nối thẳng, chỉ khi tài khoản thuộc khu vực được Exness mở API); tài khoản MT5 Exness thông thường KHÔNG có cách nào chỉ dùng điện thoại mà không qua cầu nối, vì MT5 không có cổng tự động hoá công khai. Exness không có cTrader.",
    ]),
    ("1.9.43", "2026-11-08", [
        "PHÁT LẠI LẦN BACKTEST ĐÃ XONG (tab Backtest, dưới thanh tốc độ): «▶ Phát lại» cho thấy nến, chỉ báo, chấm vào/ra và đường vốn lớn dần theo thời gian mà KHÔNG chạy lại bot (kết quả không đổi). Tốc độ lấy từ thanh «Tốc độ (nến/giây)» (Tối đa = 400 nến/giây), đổi được khi đang phát; ⏸ tạm dừng, ◀1/1▶ lùi/tiến từng nến, ◀50/50▶ nhảy 50 nến, «Thoát» trả biểu đồ về toàn bộ kết quả. Chạy backtest mới tự thoát phát lại.",
        "Để nhẹ, biểu đồ khi phát lại chỉ giữ 2000 nến gần nhất; sau «Thoát» thấy đủ lại. Chưa thử trên máy thật.",
    ]),
    ("1.9.42", "2026-11-08", [
        "BACKTEST CÓ THANH TỐC ĐỘ NGAY CẠNH NÚT CHẠY: «Tốc độ (nến/giây)» (Tối đa · 1000 · 300 · 100 · 30 · 10 · 3). Trước đây chỉ có một ô nằm sâu trong form nên khó thấy, và phải chọn TRƯỚC khi chạy. Nay đổi được NGAY KHI ĐANG CHẠY (như thanh tốc độ Visual mode của MT5), đồng bộ với ô trong form và được lưu. Chạy ở «Tối đa» vẫn hiện tiến độ/đường vốn, đổi sang chậm là xem từng nến. Tốc độ không đổi kết quả.",
    ]),
    ("1.9.41", "2026-11-08", [
        "BIỂU ĐỒ NHẸ HƠN KHI LƯỚT/PHÓNG TO: nến được vẽ gom theo màu (2 lệnh đổi màu mỗi khung hình thay vì một lệnh cho từng nến), hình giữ nguyên. Đo trong giả lập: ~0,79 → ~0,64 ms mỗi lần vẽ 150 nến; trên máy thật chưa đo.",
        "Đã đo nhưng KHÔNG đổi: thư viện mạng (urllib/http) nạp lúc khởi động vì tab Thị trường cần ngay; gộp toàn bộ nến vào một khối đồ hoạ (Mesh) còn có thể giảm thêm nhưng chưa dám làm khi chưa thử trên máy thật.",
    ]),
    ("1.9.40", "2026-11-08", [
        "KHỞI ĐỘNG NHANH HƠN: trước đây trước khi hiện màn hình đầu tiên app dựng sẵn cả form Cài đặt (~780 widget, hơn một nửa toàn app) và nạp (exec) lần lượt cả 12 bot mẫu để đọc tên/tham số, rồi dựng danh sách bot hai lần. Nay form Cài đặt chỉ dựng khi bạn mở tab đó (hoặc khi có chỗ cần đọc nó), chỉ bot đang chọn được nạp ngay, các bot còn lại hiện tên file rồi được nạp dần từng lượt rồi cập nhật tên, và danh sách chỉ dựng một lần. Đo trong môi trường giả lập: dựng giao diện ~158 ms → ~11 ms (chưa đo trên máy thật, nên mức nhanh thực tế còn phụ thuộc điện thoại).",
        "Nạp một bot chỉ đọc file và quét AST an toàn MỘT lần (trước đây 2-3 lần).",
        "Không bỏ tính năng nào: mọi nơi đọc form Cài đặt (lưu, Trợ lý, nhập danh sách theo dõi, khôi phục sao lưu) vẫn thấy form đầy đủ như cũ.",
        "Chưa làm / nói thẳng: nạp thư viện lúc khởi động (~170 ms) và việc vẽ lại toàn biểu đồ mỗi khung hình khi lướt/phóng to vẫn như cũ; chưa xác nhận trên điện thoại thật.",
    ]),
    ("1.9.39", "2026-11-08", [
        "SỬA LỆNH NHƯ MT5: NHẤN GIỮ (~0,4 giây) lên đường SL/TP của lệnh đang mở, hoặc SL/TP/giá của lệnh chờ trên biểu đồ → đường được nhấc lên (hiện giá + % so với giá hiện tại) → kéo lên/xuống → THẢ TAY là áp dụng ngay. Chạm nhanh vào đường hoặc vào dòng lệnh vẫn mở hộp thoại sửa chi tiết (SL/TP/trailing/chốt một phần). Kéo ngang trước khi giữ đủ lâu vẫn là lướt biểu đồ.",
        "Kiểm hợp lệ như MT5 khi thả: lệnh MUA SL phải dưới bid, TP phải trên ask (BÁN ngược lại); lệnh chờ kiểm theo giá vào; giá vào của lệnh đã khớp không dời được. Sai thì báo rõ và không gửi sàn. Lệnh chờ giờ vẽ cả đường SL/TP của nó.",
        "CHỐNG GIẬT khi kéo: trước đây mỗi pixel kéo vẽ lại TOÀN BỘ biểu đồ (nến + chỉ báo) và dựng lại chữ + thanh nút. Nay đường đang soạn/đang kéo nằm ở lớp phủ riêng (chỉ vài nét vẽ mỗi khung hình), chữ giá dựng lại tối đa ~16 lần/giây, thanh nút lệnh nháp cập nhật ≤ ~8 lần/giây và một lần cuối khi thả. Lướt/zoom biểu đồ vẫn vẽ lại toàn bộ như cũ. Chưa đo trên máy thật.",
    ]),
    ("1.9.38", "2026-11-08", [
        "ĐA KHUNG TỰ PHÁT HIỆN: không cần khai báo `# @mtf:` nếu bot gọi khung dạng chữ (`timeframe=\"4h\"`) - app đọc mã và nạp nến thật. Bot hỏi khung qua biến/Input thì backtest phát hiện lúc chạy, nạp nến thật rồi chạy lại một lần (báo rõ trong dòng «Khung dữ liệu khác»).",
        "BACKTEST DANH MỤC nhận nến khung khác thật cho TỪNG bot theo đúng mã của bot đó (trước đây vẫn ghép).",
        "MỐC NẾN NGÀY/TUẦN/THÁNG: nguồn trả nến 1d/1w/1mo lệch mốc UTC (MT/MetaApi/Exness theo giờ máy chủ GMT+2/+3, ccxt) bị phát hiện (hơn nửa số nến không mở đúng mốc) và tự dựng lại từ nến 1h theo UTC, để khớp nến dựng từ tick - trước đây nến lịch sử và nến live lệch giờ chồng lên nhau. Tối đa 6000 nến 1h (~250 ngày, ~35 tuần, ~8 tháng). Binance (UTC theo tài liệu), OANDA (app đã ép dailyAlignment=0, UTC, tuần Thứ Hai), Capital, nguồn công khai (UTC) giữ nguyên. Chưa thử với tài khoản MT/Exness thật.",
    ]),
    ("1.9.37", "2026-11-08", [
        "CACHE NẾN: nến đã đóng được ghi xuống đĩa NGAY khi đóng (khung ≥ 1 giờ ghi liền, khung nhỏ gộp tối đa 1 lần/2 phút) và ghi nốt khi dừng phiên. Trước đây chỉ ghi lúc nạp lịch sử nên app chạy nhiều giờ rồi crash/khởi động lại phải tải bù nhiều hơn.",
        "BACKTEST ĐA KHUNG THẬT: thêm dòng đầu file bot `# @mtf: 1h, 1d` thì backtest nạp nến THẬT của các khung đó từ kho nến (lùi 300 nến trước đoạn test) thay vì ghép từ khung bot. Bot chỉ thấy nến đã ĐÓNG tại giờ thị trường hiện tại (không nhìn trước); nến đang hình thành (include_current) chỉ dựng từ phần đã xảy ra của khung bot. Khung nhỏ hơn khung bot cũng lấy được khi có dữ liệu thật. Áp dụng cho chạy đơn, tối ưu, walk-forward và độ nhạy; backtest DANH MỤC vẫn ghép.",
        "Khung chưa khai báo vẫn chạy bằng cách ghép từ khung bot: nến đầu bị thiếu một phần giờ được BỎ (trước đây đưa OHLC sai), lỗi nói rõ cần `# @mtf:`.",
        "Màn «Khung dữ liệu bot dùng» (tab Bot, từng bot; và trong tab Backtest): khung nào bot đã hỏi, nguồn (nến thật / nến sàn / ghép), số nến, từ ngày nào; báo cáo backtest có dòng «Khung dữ liệu khác». Chưa kiểm chứng trên sàn thật/máy thật.",
    ]),
    ("1.9.36", "2026-11-08", [
        "TƯƠNG QUAN CHỈ BÁO ↔ GIÁ (tab Backtest → «Tương quan chỉ báo ↔ giá»): với các chỉ báo bot vẽ bằng self.api.plot, tính tương quan hạng (Spearman) giữa giá trị chỉ báo ở nến i và lợi suất 1/5/20 nến SAU đó, có kiểm ý nghĩa đã trừ chồng lấn (|t|≥3 mới đánh dấu). Chỉ báo cùng thang giá (MA, band) được quy về khoảng cách tới giá. Báo cặp chỉ báo trùng thông tin (tương quan của thay đổi ≥ 0.8). Không có chỉ báo nào đủ mạnh thì nói thẳng là không có cơ sở thống kê.",
        "TƯƠNG QUAN THAM SỐ: «So sánh từng tham số» sau khi tối ưu có thêm tương quan giữa giá trị từng tham số và kết quả, và phụ thuộc giữa các tham số trong nhóm 25% lần chạy tốt nhất (tham số đi cùng nhau thì đừng chỉnh riêng lẻ).",
        "«Hỏi AI tư vấn» nhận thêm các bảng này. Số do code tính; AI chỉ đọc và đề xuất (vẫn chỉ là gợi ý, bạn bấm Áp dụng, nên kiểm bằng walk-forward). Tương quan quá khứ không phải nhân quả. Chưa kiểm chứng với AI thật.",
    ]),
    ("1.9.35", "2026-11-07", [
        "NÚT BACK: trước đây Back luôn đưa app xuống nền dù đang mở hộp thoại. Nay: đóng hộp thoại trên cùng → huỷ lệnh đang soạn trên biểu đồ → về TAB TRƯỚC ĐÓ → hết lịch sử mới xuống nền. Hộp thoại bắt buộc (rủi ro, điều khoản) nuốt phím Back chứ không thoát app.",
        "BOT ĐÃ NẠP: thêm nút «Đổi tài sản / khung giờ» ở mỗi bot. Bot đang chạy được gỡ rồi gắn lại với mã/khung mới (tham số giữ nguyên); lệnh đang mở trên mã cũ KHÔNG bị đóng - có cảnh báo trong hộp thoại.",
        "LỆNH/VỊ THẾ: chạm vào chính dòng vị thế hoặc lệnh chờ (tab Giao dịch) là mở hộp sửa SL/TP/trailing/chốt một phần (như MT5); trên biểu đồ chạm vào đường giá vào/SL/TP/lệnh chờ cũng mở hộp sửa.",
        "BIỂU ĐỒ: chưa tái hiện được lỗi không kéo ngang trong môi trường giả lập (kéo vẫn chạy). Đã giảm các nguyên nhân có thể: ngưỡng nhận kéo dọc (cuộn trang) tăng lên để kéo hơi chéo vẫn lướt ngang; rời tab thì tự tắt chế độ tiêu điểm ✚ (đang bật thì một ngón không lướt được); khi đang hiển thị TOÀN BỘ nến thì báo rõ lý do không lướt được. Chưa kiểm chứng trên máy thật.",
    ]),
    ("1.9.34", "2026-11-07", [
        "MÀN HÌNH «BOT HỎI AI» (tab AI → nút «Bot hỏi AI»): lịch sử MỌI lần bot gọi api.ask_ai, mới nhất trước - giờ, bot, mã, AI/model, có tra web hay không, trạng thái (✔ ok · ✖ lỗi · ⏳ hết hạn mức); chạm vào dòng để xem câu hỏi, kết quả đã kiểm schema và nguyên văn trả lời. Đầu màn hình: đang bật/tắt, đã dùng bao nhiêu/hạn mức trong 1 giờ và 24 giờ. Có «Làm mới» và «Xoá lịch sử».",
        "Nhật ký ai_ask_history.jsonl (giữ 500 dòng, che bí mật) ghi cả lần lỗi và lần bị từ chối vì hạn mức (tối đa 1 dòng/phút/key để không tràn). Chạy cả khi bot ở dịch vụ nền: màn hình đọc từ file chung.",
    ]),
    ("1.9.33", "2026-11-07", [
        "BOT GỌI AI: `self.api.ask_ai(câu_hỏi, include=[...], data={...}, schema={...}, web=False)` - bot tự viết câu hỏi, chọn dữ liệu kèm (vị thế, lệnh chờ, tài khoản, nến BẤT KỲ khung như 1d/4h, lịch kinh tế, thống kê, kho riêng, hoặc dict tự dựng), tự khai schema trả lời; vỏ kiểm lại JSON rồi trả AIAnswer. KHÔNG có kịch bản dựng sẵn nào trong vỏ. Không chặn bot: pending -> gọi lại cùng key ở tick sau.",
        "Cài đặt mới nhóm «Bot gọi AI» (mặc định TẮT): bật/tắt, AI mặc định, hạn mức lần/giờ và lần/ngày, dùng lại câu trả lời, cỡ ngữ cảnh tối đa (từ chối kèm lý do chứ không cắt ngầm), chỉ dẫn chung, ghi để backtest phát lại. Bí mật bị che trước khi gửi; lỗi mạng/AI chỉ trả status, không làm sập bot.",
        "TRA WEB cấu hình theo từng AI (không gắn nhà cung cấp): tab AI có thêm «Model tra web», «Tham số thêm khi tra web (JSON)», «Tham số thêm (JSON)»; cần thêm «Cho phép tra web» ở Cài đặt. Thiếu cấu hình thì báo lỗi rõ, không âm thầm hỏi không-web.",
        "Backtest: không gọi AI; bật «Phát lại tín hiệu AI đã ghi» thì ask_ai trả lại câu trả lời thật đã ghi (khớp theo tag, không nhìn trước tương lai); báo cáo nói rõ số lần hỏi/có câu trả lời. SDK API 1.6, khai `# @permission: ai_ask`.",
        "Mẫu bot «AI Advisor (mẫu tổng quát)»: câu hỏi, dữ liệu kèm, schema và ánh xạ hành động đều là tham số. Tài liệu docs/BOT_AI.md. Chưa kiểm chứng với nhà cung cấp AI thật hay chức năng tra web thật.",
    ]),
    ("1.9.32", "2026-11-07", [
        "TÁCH «KẾT NỐI» KHỎI «CHẠY BOT»: nút KẾT NỐI ở tab Thị trường (và nút «Kết nối» khi đặt lệnh từ biểu đồ) chỉ lấy giá, hiện biểu đồ, cho đặt lệnh tay - các bot đã gắn KHÔNG tự chạy. Muốn chạy bot: tab Bot bấm «KẾT NỐI & CHẠY BOT» (chưa kết nối) hoặc «CHẠY TẤT CẢ BOT» (đã kết nối), hoặc nút Chạy/Dừng từng bot.",
        "Kết nối lại sau khi đổi cài đặt giữ nguyên trạng thái: có bot đang chạy thì kết nối lại vẫn chạy bot, không thì chỉ kết nối. Tự khôi phục sau sự cố/khởi động máy vẫn nhớ bot nào đang chạy.",
        "GÓI CHẨN ĐOÁN có thêm boot.log (các mốc khởi động + ngăn xếp khi app chết kiểu native) và crash.log.old (lần crash trước, trước đây bị đổi tên nên không vào gói). Nếu app lại thoát khi vừa kết nối, gửi lại gói chẩn đoán để biết app chết ở đâu.",
    ]),
    ("1.9.31", "2026-11-07", [
        "BACKTEST TỰ LƯU DỮ LIỆU NẾN: lần đầu tải từ sàn/nguồn đang chọn, lần sau chỉ tải PHẦN CÒN THIẾU (nến mới + khoảng cũ hơn nếu cần) nên nhẹ máy, nhanh và tốn ít mạng. Chỉ lưu nến đã đóng; kiểm tra liền mạch, nếu không khớp thì tự tải lại đủ thay vì để lỗ ngầm.",
        "Lưu gọn: file nhị phân 48 byte/nến (100.000 nến ≈ 4,8 MB), đọc đúng đoạn cần (không nạp cả file), ghi nối thêm không ghi lại cả file, ghi an toàn khi mất điện. Nguồn «simulated» (giả) không được lưu.",
        "Nút MỚI «Dữ liệu nến đã lưu»: xem các chuỗi đã lưu (nguồn · mã · khung · số nến · khoảng ngày · dung lượng), XUẤT CSV (giờ UTC) để mang sang máy khác, NHẬP CSV (nhận dấu , ; tab, có/không tiêu đề, giờ epoch hoặc YYYY-MM-DD HH:MM, cả định dạng xuất của MT5), xoá từng chuỗi hoặc xoá hết.",
        "Ô mới «Nguồn dữ liệu» ở tab Backtest: «Sàn (tự lưu)» hoặc «File đã nhập» (chỉ dùng CSV đã nhập, không dùng mạng; tên mã phải trùng ô «Tài sản»). Áp dụng cho cả backtest danh mục. Lưu ý: backtest không còn lấy nến đang chạy dở của phút hiện tại.",
    ]),
    ("1.9.30", "2026-11-06", [
        "CÔNG TẮC TẮT BÁO ĐỘNG KHỞI ĐỘNG LẠI: cài đặt «Báo động (âm báo thức) khi máy tự khởi động lại» (Chạy nền & cảnh báo, mặc định bật). Tắt thì chỉ hiện một thông báo thường, không âm báo thức/rung lặp. Giá trị được ghi vào cờ khởi động nên áp dụng được cả khi máy chưa mở khoá.",
    ]),
    ("1.9.29", "2026-11-06", [
        "BÁO ĐỘNG KHI MÁY TỰ KHỞI ĐỘNG LẠI: thay vì một dòng thông báo thường, app phát thông báo kiểu BÁO THỨC (âm báo thức, rung, lặp tới khi bạn vuốt bỏ, hiện cả trên màn hình khoá, kênh riêng «Cảnh báo máy khởi động lại») khi máy vừa bật mà bot đang chạy trước đó.",
        "Nội dung nói rõ máy vừa khởi động lại và nêu nguyên nhân thường gặp (hết pin/cúp điện, treo máy, hệ thống tự khởi động). Ba trường hợp: chưa mở khoá (nhắc mở khoá), bot đã tự chạy lại (báo để bạn kiểm tra phiên), không tự chạy lại được (chạm để mở app).",
        "Âm báo thức dùng âm lượng BÁO THỨC của máy; chế độ Không làm phiền có thể vẫn chặn nếu bạn chưa cấp quyền bỏ qua cho kênh này trong Cài đặt thông báo. Chưa kiểm chứng trên máy thật.",
    ]),
    ("1.9.28", "2026-11-06", [
        "MÁY CÓ KHOÁ MÀN HÌNH: sau khi khởi động lại mà chưa mở khoá, Android chưa cho app đọc dữ liệu riêng nên bot chưa thể chạy. App giờ hiện thông báo «Bot đang dừng, hãy mở khoá màn hình, bot sẽ tự chạy lại» ngay lúc máy bật (thông báo tự mất khi bot chạy lại), thay vì im lặng.",
        "Lý do chưa chạy bot trước khi mở khoá: mã Python của app nằm trong kho dữ liệu bị mã hoá theo khoá màn hình; chuyển hết sang kho chạy-trước-khi-mở-khoá sẽ phải đưa cả API key ra kho kém bảo mật (Google khuyên không làm). Muốn tự chạy lại hoàn toàn không cần thao tác: tắt khoá màn hình (hoặc chọn «Vuốt»).",
    ]),
    ("1.9.27", "2026-11-06", [
        "TỰ CHẠY LẠI BOT SAU KHI KHỞI ĐỘNG MÁY: nếu bot đang chạy mà máy tắt/khởi động lại (hoặc app vừa được cập nhật), app tự dựng lại dịch vụ nền và khôi phục phiên + sổ lệnh khi máy mở khoá. Bấm Ngắt thì sẽ không tự chạy lại. Cài đặt mới «Tự chạy lại bot sau khi khởi động máy» (mặc định bật).",
        "Cách vượt giới hạn Android 15: dịch vụ nền khai báo loại «specialUse» (không nằm trong danh sách bị chặn khi khởi động từ BOOT_COMPLETED như dataSync/mediaPlayback...). Nếu ROM vẫn chặn, app phát thông báo «Bot chưa tự chạy lại» để bạn chạm mở.",
        "Một số ROM (Xiaomi/Oppo/Vivo...) cần cấp quyền «Tự khởi động» cho app trong Cài đặt máy; máy phải được mở khoá một lần sau khi bật. Chưa kiểm chứng trên máy thật.",
    ]),
    ("1.9.26", "2026-11-06", [
        "CHUẨN THAM SỐ BOT (PyEA Inputs) như `input` của MQL5, có tài liệu riêng docs/BOT_INPUTS.md: `Input(mặc_định, nhãn, min, max, step, help, choices, subtype)` + `Group(\"Tên nhóm\")`.",
        "Kiểu ô mới: Ô CHỌN CÓ NHÃN (choices là dict {giá_trị: nhãn} hoặc lớp enum.Enum), ô MÀU #RRGGBB, ô GIỜ HH:MM, ô NGÀY-GIỜ, ô VĂN BẢN dài (subtype=color/time/datetime/text); form kiểm định dạng khi nhập.",
        "Bot mẫu mới «Chuẩn tham số (mẫu đủ kiểu ô)» minh hoạ mọi kiểu. Nút «Nhờ AI chuyển bot sang chuẩn tham số» ở tab Bot: soạn sẵn yêu cầu + quy tắc + code bot vào khung chat AI để bạn xem lại rồi gửi. Trợ lý trong app cũng trả lời được về chuẩn này.",
    ]),
    ("1.9.25", "2026-11-06", [
        "NÚT NGẮT có phản hồi: bấm là hiện «Đang ngắt kết nối…», nút đổi thành «ĐANG NGẮT…» (khoá), xong báo «Đã ngắt kết nối». Quá 10 giây mà phiên chưa dừng (đang chờ mạng/sàn) thì hỏi «Buộc dừng» dịch vụ nền. Bấm NGẮT khi chưa kết nối cũng báo thay vì im lặng.",
        "THAM SỐ BOT NHẬN DẠNG RỘNG HƠN: thuộc tính `fast = 10` không cần chú thích kiểu vẫn thành tham số (như `input` của MT5); thêm giới hạn trong chú thích: `# SMA nhanh {2..200}`, `# Lot {0.01..10 step 0.01}` -> form kiểm min/max/bước. Vẫn dùng được `[a|b|c]`, `Literal[...]`, `Input(...)`, `inputs = {...}`.",
    ]),
    ("1.9.24", "2026-11-05", [
        "TIÊU ĐIỂM XUỐNG KHUNG CHỈ BÁO (như MT5): kéo ngón vào cửa sổ RSI/MACD... thì đường ngang chạy trong cửa sổ đó và nhãn bên phải hiện GIÁ TRỊ chỉ báo; kéo lên vùng giá thì về giá. Đường dọc vẫn xuyên suốt mọi khung.",
        "SỬA THANG GIÁ: giá tại tiêu điểm trước đây tính theo thang cũ khi đã dời/co giãn cột giá; nay dùng đúng thang đang hiển thị. Giới hạn mức dời, tự bỏ dời khi đổi sang mã có giá khác hẳn. Nguồn «public» lọc nến hỏng (giá <= 0, râu lệch xa) để không làm thang giá nổ (chart vàng chỉ còn các chấm, trục số âm).",
        "HỘP THOẠI API LÀM LẠI: thẻ tóm tắt sàn, các ô xếp theo NHÓM (tiêu đề từng nhóm), mỗi ô nhãn trên - ô nhập toàn chiều rộng - gợi ý nhỏ, nút Hiện/ẩn khoá, nút Xong ghim ở đáy.",
        "LỊCH SỬ LỆNH CHI TIẾT KIỂU MT5 (Vị thế/Lệnh/Giao dịch, lọc kỳ/mã/chiều/kết quả, tổng) đã có từ trước nhưng khó thấy: nay có nút «Lịch sử lệnh» ngay ở tab Biểu đồ và nút lớn ở tab Giao dịch (trên bảng lịch sử).",
    ]),
    ("1.9.23", "2026-11-05", [
        "Ô NHẬP API: không còn là mục gập trong trang cuộn (nhiều máy bấm không xổ) mà nút «KẾT NỐI SÀN / API» MỞ HỘP THOẠI riêng chứa các ô khoá của sàn đang chọn. Bấm «Xong» rồi «Lưu» ở đầu tab. Có nút «Hiện tất cả sàn» ngay trong hộp thoại.",
        "ĐỔI NGUỒN KHÔNG ÁP DỤNG CHO PHIÊN ĐANG CHẠY: chart vẫn là giả lập vì phiên cũ còn chạy. Nay chart/Thị trường ghi đúng nguồn của PHIÊN đang chạy, và khi Lưu đổi nguồn lúc đang kết nối app hỏi «Kết nối lại ngay?».",
        "LỊCH KINH TẾ: để trống ô «Nguồn lịch» (hoặc gõ auto) = dùng lịch tuần này miễn phí có sẵn (JSON, nguồn không chính thức, nạp tối đa 1 lần/giờ). Chỉ cần bật «Bật lịch kinh tế». Vẫn dán được URL/file riêng.",
    ]),
    ("1.9.22", "2026-11-05", [
        "NGUỒN DỰ PHÒNG TỰ ĐỘNG cho «public»: crypto thử lần lượt Binance -> Bybit -> OKX -> Coinbase -> Kraken (API công khai, không khoá); vàng/forex/chỉ số/cổ phiếu: Yahoo -> Twelve Data (nếu nhập khoá miễn phí ở Cài đặt) -> riêng vàng còn có PAXG/USDT của Binance/Bybit (token vàng chạy 24/7).",
        "Nguồn lỗi bị «nghỉ» 60 giây rồi thử lại, không làm chậm vòng giá. Cài đặt có ô «Twelve Data API key» (tuỳ chọn, mã hoá như khoá khác).",
        "Lưu ý: Coinbase/Kraken niêm yết theo USD (xấp xỉ USDT) nên có thể lệch vài phần nghìn so với Binance khi phải dùng dự phòng.",
    ]),
    ("1.9.21", "2026-11-05", [
        "GIÁ THẬT KHÔNG CẦN API: «Nguồn thị trường» có thêm «public» - crypto lấy từ API công khai của Binance, vàng/forex/chỉ số/cổ phiếu lấy từ Yahoo Finance (khung lạ tự ghép từ khung nhỏ). Dùng để xem biểu đồ, chạy bot paper, backtest; KHÔNG live. Giá là giá tham chiếu, có thể lệch giá khớp của sàn bạn giao dịch.",
        "Không scrape TradingView: điều khoản của họ cấm và giao thức không công khai nên dễ vỡ/bị chặn. Yahoo cũng không phải API chính thức - nếu họ đổi/chặn, chọn binance_spot (crypto) hoặc sàn có API.",
    ]),
    ("1.9.20", "2026-11-05", [
        "CẢNH BÁO MẤT MẠNG chỉ khi đang KẾT NỐI/chạy bot (mặc định). Cài đặt -> «Cảnh báo mất mạng»: connected / always / off. Chạm vào dải đỏ để tắt cảnh báo cho tới khi có mạng lại.",
        "BIỂU ĐỒ: kéo lên/xuống ở CỘT GIÁ (bên phải) để dời khung giá; chạm 2 lần để về mặc định. Kéo ngang vẫn lướt thời gian.",
    ]),
    ("1.9.19", "2026-11-05", [
        "MẤT MẠNG: dải ĐỎ trên cùng + dòng nhật ký + thông báo hệ thống khi thiết bị mất kết nối mạng (thăm dò mỗi ~8 giây, 2 lần lỗi liên tiếp mới báo; có mạng lại thì tự tắt). Trước đây chọn sàn giả lập thì không có gì để phát hiện.",
        "DỮ LIỆU GIẢ LẬP: khi sàn là «simulated», biểu đồ và tab Thị trường ghi rõ «DỮ LIỆU GIẢ LẬP - không phải giá thị trường thật» (giá do app tự sinh ngẫu nhiên). Muốn giá thật: chọn sàn thật ở Cài đặt.",
        "Ô NHẬP API luôn mở sẵn (tam giác ▶ không xổ trên một số máy); bấm tiêu đề để thu gọn.",
        "NÚT ✚ TIÊU ĐIỂM: bỏ hộp thoại thông báo mỗi lần bấm; cách dùng ghi ngay dưới tiêu đề biểu đồ.",
        "GIẢM CPU: biểu đồ không vẽ lại khi dữ liệu không đổi.",
    ]),
    ("1.9.18", "2026-11-05", [
        "NÚT TIÊU ĐIỂM ✚ (như MT5) ở góc trên-phải biểu đồ: BẬT -> một ngón chạm/kéo để di chuyển đường dọc + ngang (dọc bám nến gần nhất, ngang theo đúng giá); TẮT -> kéo để lướt biểu đồ trái/phải. Chụm hai ngón vẫn thu/phóng ở cả hai chế độ.",
        "Tiêu điểm nay có nhãn THỜI GIAN ở trục dưới (cùng nhãn giá bên phải) để so sánh hai biểu đồ cùng một thời điểm. Có cả ở biểu đồ Backtest.",
    ]),
    ("1.9.17", "2026-11-05", [
        "SỬA TAB CÀI ĐẶT: ~8 hàng nút cố định ở đáy chiếm gần nửa màn hình (chỉ chừa khe nhỏ để cuộn) -> nay MỌI nút (Không làm phiền, Sao lưu, Chẩn đoán, Hướng dẫn, Tài khoản, Trợ lý...) nằm TRONG vùng cuộn; chỉ «Lưu» và «Mặc định» ghim ở đầu tab.",
        "KÉO TRANG DỄ HƠN: ngón bắt đầu kéo trên ô nhập/công tắc/nút xổ trước đây bị chúng «ăn» (Kivy chỉ chờ 55 ms). Nay chờ 220 ms và chỉ cần xê dịch ~6dp là cuộn; chạm nhanh vẫn bấm bình thường; thanh cuộn rộng hơn. Áp dụng mọi danh sách/tab.",
        "Ô NHẬP API: mở sẵn khi đang chọn sàn thật; khi mở tự cuộn tới đầu mục; chữ nút ghi rõ «chạm để mở ô nhập API».",
        "ĐẶT LỆNH TRÊN BIỂU ĐỒ: hàng nút «＋ Đặt lệnh trên biểu đồ», «Lệnh mới», «Vẽ», «Kiểu» nay là một hàng riêng chia đều (1.9.15 dồn 6 nút một hàng làm «＋» bị ép nhỏ). Chưa kết nối thì hiện hộp thoại giải thích + nút «Kết nối» thay vì toast dễ bỏ sót.",
        "CHỤP MÀN HÌNH: mặc định «Chặn chụp/quay màn hình» đổi từ «sensitive» sang «off» (và chuyển một lần cho người đang giữ mặc định cũ). Vẫn bật lại được ở Cài đặt; khoá API luôn hiển thị dạng ẩn.",
    ]),
    ("1.9.16", "2026-11-04", [
        "CHẠY KHÔNG GIAO DIỆN (VPS/Docker/Raspberry Pi): `python -m pyea.headless --data-dir D` dùng cùng động cơ và dịch vụ nền như bản Android; LIVE bắt buộc `--accept-risk`; mã thoát cho systemd/Docker; kèm docs/vps/Dockerfile và pyea.service. Chưa thử trên VPS thật.",
        "SAO LƯU / ĐỒNG BỘ ĐA THIẾT BỊ KHÔNG CẦN MÁY CHỦ CỦA TÁC GIẢ: gói mã hoá bằng mật khẩu của bạn (PBKDF2 + mã xác thực), cất ở một file hoặc WebDAV (https). Gồm bot, tham số, bot đã gắn, giao diện/hình vẽ; cài đặt + khoá API chỉ khi bạn chọn. Không đồng bộ quyền bot, nhật ký, sổ lệnh. File mới hơn thắng; bot bị ghi đè lưu vào phiên bản cũ. Menu «Hướng dẫn · điều khoản…» → «Sao lưu / đồng bộ».",
        "CHỢ BOT CÓ CHỮ KÝ (không kiểm duyệt, không thanh toán): gói .pyeabot ký Ed25519 + danh mục index.json (có SHA-256) qua https; hiện vân tay nhà phát hành, quyền xin, đánh dấu tin cậy; cài xong bot chưa có quyền nào. Công cụ người bán: tools/bot_pack.py. Chữ ký bảo vệ toàn vẹn, KHÔNG bảo đảm bot an toàn hay có lãi; Python không giấu được mã nên không có «mã hoá nguồn».",
        "COPY TRADING (bot chủ + bot theo, bot mẫu): tín hiệu JSON ký HMAC-SHA256 qua file chung hoặc https PUT/GET; chỉ làm khi tín hiệu còn mới, chống phát lại/sửa; tỉ lệ khối lượng, SL/TP, bỏ qua vị thế có sẵn trước khi theo; ánh xạ lưu ngay trên comment vị thế nên bền khi khởi động lại. Kiểm chứng trong động cơ thật (backtest). Mỗi bot một mã; không phải copy tức thời; không có chợ tín hiệu.",
    ]),
    ("1.9.15", "2026-11-04", [
        "BẢN QUYỀN: DÙNG THỬ ĐẦY ĐỦ 90 NGÀY CHỈ KHI CÀI TỪ GOOGLE PLAY (người dùng = tester). Cài ngoài Play (APK/GitHub) không giới hạn gì. Hết 90 ngày và chưa có khoá: chặn MỞ PHIÊN LIVE MỚI; paper, backtest, lịch sử, quản lý/đóng lệnh đang có vẫn dùng. Khoá kích hoạt ký Ed25519 offline (công cụ tools/license_keygen.py), chống lùi đồng hồ và sửa tay file; menu «Bản quyền · dùng thử 90 ngày». Không chống được xoá dữ liệu app/cài lại (cần máy chủ).",
        "BUILD CHO GOOGLE PLAY (chưa build thử được ở đây): p4a v2026.05.09 (bản cũ KHÔNG có foregroundServiceType), target API 36 (Play yêu cầu từ 31/8/2026), NDK 28c, Kivy 2.3.1, dịch vụ nền khai báo foregroundServiceType=specialUse (dataSync bị Android 15 giới hạn 6 giờ/24 giờ nên không hợp bot 24/7) + quyền FOREGROUND_SERVICE_SPECIAL_USE.",
        "GIAO DIỆN SÁNG (Cài đặt → Giao diện: dark / light / auto theo Android; đổi xong mở lại app). Màu đổi tại chỗ, lưới/đường ngắm/bong bóng chat theo giao diện; test độ tương phản WCAG cho cả hai.",
        "RENKO, RANGE và GỘP N NẾN (nút «Kiểu» ở tab Biểu đồ): chỉ để xem, bot/backtest vẫn dùng nến thời gian.",
        "SỔ LỆNH (DOM) Binance tự làm mới 3 giây + THÔNG SỐ MÃ (tick, bước KL, KL tối thiểu, giá trị lệnh tối thiểu).",
        "BACKTEST TICK THẬT (Binance aggTrades): đúng quy tắc tài liệu (cửa sổ <1 giờ, 1000 dòng/lần, Futures chỉ 48 giờ gần nhất, ≥1000 giao dịch cùng ms chuyển sang fromId), giới hạn 300.000 tick; nến thiếu tick dùng đường OHLC và báo cáo ghi «Nến dùng tick thật x/y».",
        "PHIÊN BẢN BOT + HOÀN TÁC: AI sửa đè, nạp lại file cùng tên, cài lại mẫu hoặc xoá bot đều lưu bản cũ (tối đa 30); nút «Phiên bản bot» khôi phục (khôi phục cũng hoàn tác được).",
    ]),
    ("1.9.14", "2026-11-04", [
        "BINANCE FUTURES HEDGE MODE: tự nhận dualSidePosition; mọi lệnh (thị trường, chờ, SL/TP native) kèm positionSide LONG/SHORT và KHÔNG gửi reduceOnly (đúng tài liệu Binance). Trước đây bị từ chối ở Hedge Mode. Vỏ vẫn giữ một chiều mỗi mã. Chưa thử trên sàn thật (chỉ sàn giả áp đúng luật tài liệu).",
        "LỊCH SỬ BINANCE SPOT: hồ sơ lịch sử /api/v3/myTrades theo mã, cửa sổ ≤24 giờ. Spot không báo lãi/lỗ nên cột lãi/lỗ = 0 (không bịa); phí chỉ cộng khi trả bằng đồng quote.",
        "CÔNG CỤ VẼ TRÊN BIỂU ĐỒ: đường ngang, xu hướng, chữ nhật, Fibonacci, chữ (nút «Vẽ») + Danh sách đối tượng + chạm để xoá; lưu theo từng mã; chỉ để vẽ, không tự đặt lệnh.",
        "BÁO CÁO HTML kiểu MT5 (tab Backtest và Lịch sử): chỉ số, biểu đồ tăng trưởng, sụt vốn, phân tích theo mã/bot/chiều/phiên/giờ/thứ/lý do; một file không JavaScript, sáng/tối theo máy.",
        "DEBUGGER BOT trong backtest: ghi từng dòng đã chạy hoặc «điểm dừng» (có điều kiện) chụp giá trị biến; hiện lỗi trong bot; giới hạn an toàn; không đổi kết quả backtest. Profiler: thời gian từng callback của bot trong «Tải thiết bị».",
        "LẦN ĐẦU: Điều khoản + Riêng tư + hướng dẫn 6 bước + «cài đặt mẫu an toàn» (paper + giả lập, giữ khoá API). Menu «Hướng dẫn · điều khoản · riêng tư · cập nhật» trong Cài đặt. Bản mẫu cần luật sư rà soát trước khi bán.",
        "KIỂM TRA CẬP NHẬT (GitHub Releases, mặc định TẮT, chỉ báo không tự cài) và GỬI BÁO LỖI TỰ ĐỘNG (mặc định TẮT, tới địa chỉ do bạn nhập, đã che bí mật). Không telemetry.",
        "THỬ TẢI: `python -m pyea.stress` (8 bot × 8 mã + 100 backtest nối tiếp): không lỗi, backtest không rò RAM; sổ lệnh trong RAM tăng ~0,4 KB/lệnh đóng (bình thường). Tệp LICENSE.md (chưa chọn giấy phép) + docs/USER_GUIDE.md.",
    ]),
    ("1.9.13", "2026-11-03", [
        "SỬA RỦI RO CỦA KẾT NỐI GIỮ SẴN (1.9.12): kết nối GET dùng lại có thể «chết ngầm» khi đổi Wi-Fi/4G; trước đây yêu cầu giá sẽ chờ hết timeout (10 giây) mới thử lại. Nay trên kết nối dùng lại chỉ chờ tối đa 3 giây rồi thử lại ĐÚNG MỘT lần trên kết nối mới (GET idempotent; lệnh đặt/sửa/huỷ vẫn luôn kết nối mới, không thử lại).",
        "ĐÃ KIỂM TRA bằng mã: nhóm tối ưu 1.9.11-1.9.12 KHÔNG nằm trên đường vào lệnh của bot: engine/controller/ipc/botproc/trail/protection/reconcile/sync/broker/capital không import Kivy; tick tới bot qua hàng đợi của luồng engine; cập nhật tab ẩn chỉ đụng widget (không có lệnh gọi đặt/đóng lệnh).",
    ]),
    ("1.9.12", "2026-11-03", [
        "GIỮ KẾT NỐI KHI LẤY GIÁ: trước đây MỖI lần lấy giá app mở kết nối TCP+TLS mới (mỗi giây, mỗi mã). Nay yêu cầu GET dùng lại kết nối (keep-alive); đo trên máy phát triển: CPU phía app 2,47 → 0,50 ms mỗi yêu cầu (−80%), chưa kể thời gian bật sóng di động (chưa đo được ngoài thiết bị). CHỈ áp dụng cho GET: đặt/sửa/huỷ lệnh (POST/PUT/DELETE) vẫn dùng kết nối MỚI như trước nên không bao giờ gửi trùng lệnh khi kết nối cũ chết. Kết nối cũ chết thì GET tự thử lại đúng một lần; có proxy hay chuyển hướng thì dùng đường cũ.",
        "TAB ẨN KHÔNG VẼ LẠI MỖI GIÂY: Thị trường/Giao dịch/Biểu đồ/AI chỉ cập nhật khi đang xem; chuyển tab thì cập nhật ngay nên dữ liệu hiển thị không đổi. Không xác định được tab thì cập nhật như cũ.",
        "TIẾT KIỆM PIN KHI KHÔNG CHẠM (Cài đặt → Vận hành, bật mặc định, tắt được): sau 15 giây không chạm giao diện chạy 20 khung/giây thay vì 60; chạm lại là về 60 ngay. Dữ liệu vẫn cập nhật mỗi giây. CHƯA kiểm chứng trên Kivy thật (thuộc tính đồng hồ nội bộ) - tắt nếu thấy giật.",
        "THÊM SÀN CAPITAL.COM (CFD forex/vàng/chỉ số/crypto, có demo): giá, nến, lệnh thị trường, lệnh chờ limit/stop native, SL/TP gắn vào vị thế, tự đăng nhập lại khi phiên hết hạn (10 phút). Cài đặt → «Sàn» = capital, nhập API key + email + mật khẩu API key (mục Kết nối sàn / API); bật Testnet/Demo để dùng tài khoản demo. CHƯA chạy với sàn thật: đường dẫn/trường lấy từ tài liệu open-api.capital.com và test dùng máy chủ giả viết theo tài liệu. GIỚI HẠN: đóng MỘT PHẦN vị thế chưa hỗ trợ (API chỉ đóng cả vị thế) - app báo lỗi rõ; lịch sử kiểu MT5 chưa có. Việc đầu tiên: `python -m pyea.selfcheck --exchange capital --settings capital.json` trên DEMO.",
    ]),
    ("1.9.11", "2026-11-03", [
        "GIẢM TẢI GHI/ĐỌC TRẠNG THÁI (dựa trên SỐ ĐO, xem `python -m pyea.loadbench`): trước đây dịch vụ nền ghi state.json 59 KB MỖI GIÂY (khi giao diện mở), trong đó ~85% là nến + đường bot gần như không đổi. Nay phần nến đã đóng nằm ở chart.json (chỉ ghi lại khi có nến mới đóng, hoặc bot sửa điểm vẽ cũ), state.json chỉ mang nến đang chạy. Đo trên máy phát triển: dung lượng ghi mỗi giây giảm 73–92% (1 bot 48→3,7 KB; 4 bot 59→11,8 KB; 10 bot 87→23 KB); CPU Python của phần dịch vụ+giao diện giảm 44–62%. Dữ liệu hiển thị GIỐNG HỆT (có test so sánh từng nến/điểm vẽ).",
        "MÀN HÌNH «TẢI THIẾT BỊ» (Cài đặt): đo thật CPU, RAM, số luồng, ghi đĩa của giao diện và dịch vụ nền, thời gian mỗi vòng cập nhật, cỡ state.json - có nút Gửi. Dùng để so sánh các tình huống (chart đóng/mở, 1/nhiều bot) và chọn việc tối ưu theo số đo thay vì đoán.",
        "ĐO TẢI TRÊN MÁY PHÁT TRIỂN: `python -m pyea.loadbench --bots N --indicators K` chia CPU theo thành phần (tick, bot, dựng ảnh chụp, JSON, ghi file, đọc, chỉ báo). KHÔNG đo: vẽ Kivy/GPU, mạng, đánh thức CPU/pin - các phần này cần đo trên thiết bị. Chưa kiểm chứng mức giảm CPU/pin THỰC trên điện thoại.",
    ]),
    ("1.9.10", "2026-11-03", [
        "ĐẶT LỆNH NGAY TRÊN BIỂU ĐỒ như MT5 mobile: tab Biểu đồ có nút «＋» → hiện ĐƯỜNG VÀO kéo được (tay nắm tròn bên phải) + thanh chip [✕] [BUY/SELL…] [SL] [TP] [→]. Kéo đường lên/xuống hoặc chạm chỗ trống để đặt giá; loại lệnh TỰ SUY RA theo vị trí so với giá (gần giá = thị trường; mua dưới ask = BUY LIMIT, trên = BUY STOP; bán ngược lại). Chạm chip BUY/SELL để đổi chiều; chip SL/TP bật đường SL/TP kéo được. Bấm → để nhập khối lượng và xác nhận (lệnh THẬT hỏi riêng). Đường vị thế/lệnh chờ trên biểu đồ nay có NHÃN (BUY 0.01 +1.20, SL #3, TP #3, SELL LIMIT...). GIỚI HẠN: chưa kéo được SL/TP của vị thế ĐÃ MỞ trên biểu đồ (chạm dòng vị thế ở bảng → hộp sửa); chưa thử cảm ứng trên máy thật.",
        "LỊCH SỬ KIỂU MT5: tab Vị thế/Lệnh/Giao dịch, lọc theo mã, chiều mua/bán, lãi/lỗ, sắp xếp, kỳ (gồm 180 ngày) và chọn ngày tuỳ ý; dòng tổng cuối bảng cho biết nguồn (sàn hay sổ app).",
        "GOM TOÀN BỘ API VÀO MỘT MỤC «KẾT NỐI SÀN / API» trong Cài đặt: gập/mở khi cần, chỉ hiện khoá của sàn đang chọn, thay vì rải khắp trang.",
        "THÊM NGÔN NGỮ (Cài đặt → «Ngôn ngữ / Language»): Tiếng Việt, English, Español, Français, Deutsch, Português, Bahasa Indonesia, Русский, Türkçe, Italiano. Đã dịch các nhãn chính (tab, nút, tiêu đề hộp thoại, bảng vị thế/lệnh); mô tả dài, tên tham số bot và lời nhắn ghép số liệu VẪN tiếng Việt. Đổi xong cần khởi động lại app. CHƯA có Trung/Nhật/Hàn/Thái/Hindi/Ả Rập vì app chưa nhúng phông chữ cho các bộ chữ này (phông DejaVu đi kèm chỉ có Latinh/Kirin). Bản dịch do AI viết, chưa có người bản ngữ rà soát.",
    ]),
    ("1.9.9", "2026-11-02", [
        "SỬA LỖI GỐC LÀM APP VĂNG NGAY KHI MỞ (tìm ra nhờ màn hình báo lỗi lần trước): «Fatal Python error: Aborted» tại keystore.py (Android Keystore qua pyjnius, gọi KeyGenParameterSpec.setBlockModes) - lỗi NATIVE nên try/except không bắt được. Nay MẶC ĐỊNH dùng KHOÁ FILE trong thư mục riêng của app (không chạm Keystore). Keystore chỉ chạy khi bật tay (file `.ks_enable` trong thư mục dữ liệu) và có chốt chặn: mốc `.ks_probe` còn sót = lần thử trước chết native -> tự tắt. ĐỔI ĐÁNH ĐỔI: API key được mã hoá bằng khoá lưu trong file riêng của app (người khác không đọc được qua app khác, nhưng máy root/backup có thể lấy cả khoá lẫn dữ liệu) thay vì khoá trong phần cứng Keystore. Cách gọi Keystore sửa đúng chưa được kiểm trên máy thật.",
        "SỬA MÀN HÌNH LỖI TRỐNG: ô chữ (TextInput) hiện TRỐNG trên máy thật nên không đọc được lỗi. Nay hiện bằng nhãn chữ sáng trên nền tối tự vẽ, cuộn được; nút «Gửi / Sao chép lỗi» vẫn có.",
        "CHƯA KIỂM CHỨNG: các bước khởi động sau Keystore (Store, tab, dịch vụ nền, thông báo) CHƯA từng chạy tới trên máy thật - có thể còn lỗi khác lộ ra sau bản này. Màn hình «lần trước dừng giữa chừng» sẽ cho biết.",
    ]),
    ("1.9.8", "2026-11-02", [
        "TỰ HIỆN LỖI LẦN TRƯỚC NGAY TRÊN MÀN HÌNH (góp ý: «sao không hiện thông tin lỗi trên màn hình để người dùng copy»): nếu lần mở trước app chết giữa chừng (chưa dựng xong giao diện, hoặc có tab/import lỗi), lần mở sau app hiện NGAY màn hình «LẦN MỞ TRƯỚC APP BỊ DỪNG GIỮA CHỪNG» kèm các mốc khởi động (chết ở bước nào), có nút «Gửi / Sao chép lỗi» (Zalo/Telegram/clipboard) và nút «Mở app» để thử mở lại. Không phải đi tìm file boot.log nữa (file vẫn còn nếu cần). Mỗi lần chết chỉ báo một lần.",
        "GIỚI HẠN: khi app chết hẳn (crash gốc của Android) thì lúc đó không còn gì để hiện - nên thông tin chỉ có thể hiện ở LẦN MỞ SAU. Nút «Mở app» chạy giao diện chính ngay sau màn hình báo lỗi (hai App Kivy nối tiếp nhau trong một tiến trình) - CHƯA thử trên máy thật; nếu không lên thì đóng app và mở lại, lần này sẽ không báo lại.",
    ]),
    ("1.9.7", "2026-11-02", [
        "NHẬT KÝ KHỞI ĐỘNG boot.log (báo cáo: app vẫn văng ngay sau màn hình «Loading...» của Kivy, không kịp hiện lỗi): app ghi từng MỐC khởi động (main.py bắt đầu → import → dựng từng tab → xong) vào file boot.log; lần văng sau, dòng cuối cùng cho biết app chết ở đâu. Crash native (SIGSEGV...) cũng in ngăn xếp Python vào file nhờ faulthandler. Dịch vụ nền Botservice/Botworker cũng ghi mốc vào cùng file. Lấy file: Quản lý file → Android → data → org.pyea.pyearunner → files → boot.log (Android 10 trở xuống mở được; Android 11+ chặn thư mục data thì nối USB vào máy tính).",
        "MÀN HÌNH DỰ PHÒNG: lỗi ngay lúc import mã app (trước cả khi dựng giao diện) giờ hiện màn hình «PyEA KHÔNG KHỞI ĐỘNG ĐƯỢC» kèm traceback và đường dẫn boot.log thay vì văng im lặng. CHƯA BIẾT nguyên nhân văng thật - đây là bản để lộ nó ra.",
    ]),
    ("1.9.6", "2026-11-02", [
        "BÁO LỖI DỄ GỬI CHO NGƯỜI THỬ (tester): nút «Gửi báo lỗi» mở bảng Chia sẻ của Android (Zalo/Telegram/Gmail/Drive...) có sẵn nội dung lỗi; không mở được thì tự sao chép vào clipboard để dán. Có ở: màn hình lỗi khởi động (kèm «Sao chép»), hộp «Lần chạy trước ứng dụng bị lỗi», và «Gói chẩn đoán» (nút «Gửi»: gộp lỗi crash + nhật ký + cài đặt đã xoá khoá API thành một văn bản). Các công cụ báo lỗi có sẵn: Nhật ký, Kiểm tra hệ thống, Gói chẩn đoán, crash.log, Trợ lý AI hỏi sự cố.",
        "CHƯA KIỂM CHỨNG: bảng Chia sẻ dùng pyjnius/Intent, chưa thử trên máy thật (chỉ test phần rơi về clipboard và ghép văn bản).",
    ]),
    ("1.9.5", "2026-11-02", [
        "KHỞI ĐỘNG AN TOÀN (báo cáo: mở app là văng ra ngoài ngay, chưa kịp lên màn hình): từ nay lỗi lúc dựng giao diện KHÔNG làm app thoát. (1) Mỗi tab dựng riêng; tab nào lỗi thì chỉ tab đó thay bằng màn hình báo lỗi (có traceback chọn/sao chép được), các tab còn lại vẫn dùng bình thường. (2) Nếu cả giao diện sập thì hiện màn hình «PyEA KHÔNG KHỞI ĐỘNG ĐƯỢC» kèm traceback đầy đủ thay vì văng. Cả hai đều ghi vào crash.log. Chụp màn hình lỗi gửi người phát triển là sửa được ngay.",
        "NGUYÊN NHÂN GỐC CHƯA BIẾT: mã từ 1.1 đến 1.9 mới chỉ chạy trên Kivy GIẢ (không có Kivy thật trong môi trường làm việc), nên lỗi chỉ lộ khi chạy trên máy thật là chuyện có thể xảy ra. Bản này làm lỗi hiện ra thay vì che đi; chưa sửa được lỗi cụ thể vì chưa thấy traceback.",
    ]),
    ("1.9.4", "2026-11-02", [
        "SỬA HỘP THOẠI (popup) BỊ NỀN TRẮNG, CHỮ VÔ HÌNH trên một số máy Android: Kivy mặc định dùng ảnh nền trong atlas, máy không nạp được thì hộp trắng, tiêu đề và chữ sáng không đọc được (thấy trên ảnh chụp máy thật ở hộp «Cài lại bot mẫu»). Mọi hộp thoại nay dùng `StyledPopup`: nền tối đặc tự vẽ, không phụ thuộc ảnh, chữ/tiêu đề sáng. CHƯA kiểm trên máy thật (sandbox không có Kivy thật) - nếu còn trắng, chụp lại gửi để chỉnh tiếp.",
        "BUILD APK KHÔNG CÒN CHỌN NHẦM BẢN CŨ: workflow tìm thấy nhiều buildozer.spec (vd bản cũ còn sót trong repo) thì CHỌN BẢN CÓ version CAO NHẤT và in danh sách ứng viên trong log bước «Locate project». Ảnh chụp báo cáo cho thấy giao diện cũ chỉ 5 tab (Bot · Thông số · Giám sát · AI · Nhật ký) - đó KHÔNG phải bản hiện tại (8 tab: Thị trường · Giao dịch · Bot · Biểu đồ · Backtest · AI · Cài đặt · Nhật ký). Tên file APK có số phiên bản (pyearunner-1.9.4-...apk) để đối chiếu.",
    ]),
    ("1.9.3", "2026-11-02", [
        "TRAILING STOP VÀ HÒA VỐN NHƯ MT5 (việc «vỏ» còn thiếu): bấm vào vị thế → hộp «Sửa SL/TP / trailing» có thêm «Trailing Stop (khoảng giá)» và «Hòa vốn khi lãi ≥». Trailing: lãi đủ khoảng thì SL bám giá cách đúng khoảng đó, CHỈ dời theo chiều có lợi (mua lên, bán xuống), mỗi lần dời tối thiểu 10% khoảng và cách nhau ≥ 2 giây. Hòa vốn: lãi đạt ngưỡng thì kéo SL về giá mở (± mức bù, chỉnh được qua cấu hình luật). Cả hai bật thì lấy mức tốt hơn.",
        "AN TOÀN: luật do NGƯỜI DÙNG đặt từng vị thế (không bot/AI nào tự đặt); khoảng cách là khoảng GIÁ tuyệt đối (vd 0.0020), không phải pip; mọi lần dời SL đi qua đúng `modify_position` nên chịu kiểm tra stops_level/freeze và đồng bộ SL native như sửa tay (sàn từ chối thì thử lại tick sau, cảnh báo tối đa 1 lần/phút); luật lưu ở trails.json nên sống qua khởi động lại và tự xoá khi vị thế đóng; chạy được cả chế độ dịch vụ nền.",
        "CHƯA KIỂM CHỨNG: mới kiểm bằng sổ lệnh giả và Kivy giả; chưa chạy trên sàn/Android thật. Trailing là CLIENT-SIDE (app phải đang chạy để dời SL; SL đã dời xong thì nằm trên sàn nếu bật SL native). Chưa có ô nhập «bắt đầu/bước/bù hòa vốn» trên giao diện (chỉ khoảng trailing và ngưỡng hòa vốn).",
    ]),
    ("1.9.2", "2026-11-02", [
        "BACKTEST KIỂU STRATEGY TESTER CỦA MT5: (1) KHOẢNG NGÀY «Từ ngày/Đến ngày» (UTC, dạng 2026-10-01; «đến» gồm cả ngày đó) thay cho chỉ chọn số nến; nến warm-up lấy trước ngày bắt đầu, nguồn không đủ dữ liệu thì báo và thu nhỏ warm-up. (2) TỐC ĐỘ CHẠY («Tối đa» hoặc số nến/giây) + nút TẠM DỪNG/TIẾP TỤC + Dừng; đường vốn vẽ trực tiếp theo từng nến. Tốc độ/tạm dừng KHÔNG đổi kết quả. (3) Timeframe, mã, vốn, chi phí như trước.",
        "TỐI ƯU TỚI 3 THAM SỐ cùng lúc (tối đa 200 tổ hợp) và THỐNG KÊ SO SÁNH LỜI/LỖ TỪNG THAM SỐ: nút «So sánh từng tham số» gộp MỌI lần chạy theo giá trị của từng tham số (lãi TB, tốt nhất, tệ nhất, % lần có lãi, PF, sụt vốn), xếp hạng tham số nào đổi kết quả nhiều nhất, BẢN ĐỒ NHIỆT 2 tham số, và kiểm ĐỘ VỮNG (đỉnh nhọn so với giá trị kề = nghi quá khớp; tham số nằm mép lưới). Với một lần chạy: chia lời/lỗ theo lý do thoát, chiều lệnh, giờ, thứ.",
        "AI TƯ VẤN (dùng model bạn đã thêm ở tab AI): gửi mã bot (đã che khoá), tham số, số liệu và thống kê thật; trả về đề xuất ĐỔI THAM SỐ (kiểm tên/kiểu/khoảng, bỏ cái trùng giá trị hiện tại) và GỢI Ý LOGIC (chỉ là chữ). CHỈ ĐỀ XUẤT: nút «Áp dụng» chỉ đặt tham số cho LẦN BACKTEST KẾ TIẾP, không đụng bot đang chạy, không tự sửa mã. Dữ liệu trong prompt đã gỡ rào lệnh.",
        "CHƯA KIỂM CHỨNG: AI tư vấn mới chạy với model giả (chưa thử model thật - chất lượng lời khuyên chưa biết); chưa chạy trên Android; thống kê trên ít lệnh thì yếu, nên kiểm lại bằng walk-forward.",
    ]),
    ("1.9.1", "2026-11-02", [
        "LỊCH SỬ TỪ SÀN CHO OANDA, BINANCE FUTURES VÀ CCXT, KHÔNG HARDCODE THEO SÀN (trả lời «sao cứ hardcode, sao không làm chuẩn chung cho mọi sàn như MT5»): một BỘ MÁY CHUNG (pyea/histengine.py) lấy lịch sử về đúng khuôn của Exness/MT5 (Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư · vị thế đã đóng). Cái riêng của từng sàn chỉ là MỘT HỒ SƠ DỮ LIỆU JSON (endpoint, phân trang, ánh xạ trường, phân loại nạp/rút/phí, đổi dấu, vào/ra): OANDA, Binance Futures, ccxt là ba hồ sơ có sẵn (pyea/histprofiles.py) đi qua cùng bộ máy đó.",
        "SÀN MỚI KHÔNG CẦN VIẾT MÃ: Cài đặt → «Hồ sơ lịch sử sàn (JSON)» dán {\"tên_sàn\": {...}} (hoặc nhúng khoá history_profile trong cấu hình cầu nối REST). Hồ sơ dán thắng hồ sơ nhúng thắng hồ sơ có sẵn; hồ sơ sai bị chặn lúc bấm Áp dụng và nói rõ sai ở đâu. Bộ test chạy một sàn giả thứ ba (ZetaX: tên trường lạ, giờ ISO có múi giờ, phí số dương, phân trang con trỏ + số trang) chỉ bằng JSON.",
        "MỤC «GHI CHÚ VỀ SỐ LIỆU» dưới Lịch sử từ sàn: nói thẳng giả định của hồ sơ (vd Binance không có phí qua đêm nên funding được tính vào đó; vị thế dựng lại từ các lần khớp; phí trả bằng BNB không cộng) và CẢNH BÁO tô vàng khi số liệu có thể thiếu (nguồn không đọc được, sàn bắt hỏi theo mã mà chưa biết mã nào, dừng vì giới hạn an toàn). Không bịa số: sàn không báo lãi/lỗ đã thực hiện thì Lợi nhuận = 0.",
        "AN TOÀN: hồ sơ lịch sử CHỈ ĐỌC - POST bị chặn, đường dẫn tuyệt đối bị chặn, adapter từ chối mọi phương thức ghi; ccxt chỉ cho gọi danh sách hàm đọc (fetch_my_trades, fetch_funding_history, fetch_deposits, fetch_withdrawals, fetch_ledger).",
        "CHƯA LÀM / CHƯA KIỂM CHỨNG: cả ba hồ sơ chỉ được kiểm bằng sàn GIẢ (chưa chạy sàn thật; dấu của units trong tradesClosed của OANDA, giới hạn cửa sổ của /income Binance, trường info của ccxt từng sàn là suy từ tài liệu); Binance Spot vẫn không có lịch sử (không có lãi/lỗ đã thực hiện); Exness vẫn dùng đường riêng của nó; EA .mq4/.mq5 chưa biên dịch; mọi thứ chưa chạy trên Android.",
    ]),
    ("1.9.0", "2026-11-01", [
        "TRỢ LÝ AI TRONG APP (nút «Trợ lý» ở tab Giao dịch, Cài đặt, Nhật ký; và nút «Hỏi Trợ lý» ngay trên hộp «Lần chạy trước ứng dụng bị lỗi»): hướng dẫn CÁCH DÙNG từng tab, CÀI ĐẶT (cài APK, quyền, tắt tối ưu pin/chạy nền, kết nối sàn, thêm AI), và XỬ LÝ SỰ CỐ khi app gặp vấn đề (crash, mất kết nối, số liệu «-» hoặc lệch MT5, lệnh bị từ chối, bot lỗi/treo, AI lỗi). Dùng chính AI bạn đã thêm ở tab AI (hoặc đặt tên ở Cài đặt → «Trợ lý: dùng AI nào»). KHÔNG CÓ AI/MẤT MẠNG/AI LỖI thì Trợ lý vẫn trả lời từ SỔ TAY có sẵn trong app (23 mục viết theo đúng tên nút/mục thật; có test đối chiếu tên với giao diện để không lỗi thời).",
        "TRỢ LÝ CHỈ ĐỀ XUẤT - không bao giờ đặt lệnh: mỗi đề xuất là một thẻ «đổi gì, từ gì sang gì» với nút «Áp dụng»/«Bỏ qua» (có «Hoàn tác»). Danh sách trắng cố định 6 loại việc: đổi MỘT số cài đặt an toàn (hiển thị, nhịp làm mới, thông báo, AI, danh sách theo dõi - kiểm đúng kiểu/khoảng như form Cài đặt), ghi ánh xạ trường (khoá phải CÓ THẬT trong dữ liệu thô của sàn), chạy Kiểm tra hệ thống (chỉ đọc), tạo Gói chẩn đoán, mở hộp thoại Android «bỏ tối ưu pin», mở tab. Mặc định TỪ CHỐI mọi thứ khác: đặt/sửa/đóng lệnh, kill switch, paper↔live, khoá API/URL/số tài khoản, đòn bẩy, giới hạn lỗ, chế độ chỉ-xem, xác nhận lệnh, Dừng/Chạy lại phiên - kể cả khi model muốn hoặc bị dụ bởi nội dung trong nhật ký.",
        "RIÊNG TƯ: mọi thứ gửi cho nhà cung cấp AI đều qua bộ che bí mật và gỡ số tài khoản/URL của bạn. Số dư, vị thế, nhật ký, sự cố của app và kết quả kiểm tra CHỈ gửi khi bạn bật «Cho Trợ lý xem trạng thái» (nút ngay trong hộp Trợ lý; MẶC ĐỊNH TẮT). Dữ liệu ngoài đi trong khối <du_lieu> đã gỡ rào lệnh để không tự giả làm đề xuất. Hộp lỗi crash có nút «Hỏi Trợ lý» gửi kèm chi tiết lỗi - chỉ khi CHÍNH bạn bấm.",
        "ÁNH XẠ TRƯỜNG DÙNG CHUNG CHO MỌI SÀN (trả lời «sao phải hardcode từng sàn»): lõi chỉ biết các trường NGỮ NGHĨA (balance, equity, profit, swap, qty, position_id...) + một bảng bí danh chung; tên trường của sàn mới được dò theo thứ tự: ghi đè của bạn (Cài đặt → «Ánh xạ trường tuỳ chỉnh (JSON)», theo từng sàn hoặc «*») → bảng bí danh → vắng (hiện «-», KHÔNG bịa 0). Số/lịch sử hiện «-» vì sàn đặt tên khác thì chỉ cần khai tên khoá thật, không sửa mã, không phát hành lại. «Kiểm tra hệ thống» có mục «Ánh xạ trường» liệt kê trường nào đã khớp/chưa khớp kèm khoá số chưa dùng của bản ghi thô; Trợ lý đọc báo cáo đó và đề xuất đúng một dòng ghi đè. Exness, tài khoản (acctstate), vị thế, deal lịch sử, lệnh SLTP đều đi qua lớp này.",
        "SỬA/THÊM: tách `save_forms` thành đọc form + `_commit_settings` (nút «Áp dụng» của Trợ lý lưu mà KHÔNG đọc lại cả form nên ô bạn đang gõ dở ở tab Cài đặt không bị lưu theo hay ghi đè); `ParamForm.update_values`; Cài đặt có thêm «Trợ lý: dùng AI nào», «Cho Trợ lý xem trạng thái» và «Ánh xạ trường tuỳ chỉnh»; `assistant.jsonl` (lịch sử hội thoại, đã che bí mật) được xoay vòng.",
        "CHƯA LÀM: lịch sử đồng bộ cho OANDA/Binance Futures (đang làm ở bản kế tiếp; Binance Spot/ccxt không có khái niệm lãi/lỗ đã thực hiện nên chưa có kế hoạch); AI hub cho tài khoản phụ chạy trực tiếp; Trợ lý và sổ tay mới được kiểm bằng AI/Kivy giả - CHƯA chạy với model thật, chưa thử trên Android; mọi sàn/cầu nối vẫn chỉ kiểm bằng sàn giả; file EA .mq4/.mq5 chưa từng biên dịch.",
    ]),
    ("1.8.0", "2026-10-31", [
        "ĐỒNG BỘ SỐ LIỆU VỚI SÀN NHƯ MT5 (trả lời câu hỏi «ứng dụng có đồng bộ những thông số này không»): (1) Khung «Giao dịch» hiện Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ DO SÀN BÁO, nhãn ghi rõ «SÀN» (kèm tiền tệ); sàn không báo hoặc số đã cũ thì dùng sổ của app và ghi «sổ app», trường nào sàn không báo thì hiện «-» chứ không bịa 0. Dải an toàn cũng có lãi/lỗ thả nổi. (2) Mỗi vị thế: lãi/lỗ, swap, hoa hồng và giá hiện tại do SÀN tính (đúng ticket, đúng contract size/quy đổi tiền) thay cho «chênh giá × khối lượng» của sổ app; dòng vị thế hiện «giá mở → giá hiện tại» như MT5. (3) Mục «LỊCH SỬ TỪ SÀN» trong Lịch sử & báo cáo: chọn Hôm nay/7/30/90 ngày để xem Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư (đúng định nghĩa tab Lịch sử của MT5) và danh sách vị thế đã đóng (giá vào→ra bình quân gia quyền, lãi/lỗ, giờ đóng) - gồm cả lệnh bạn đánh tay ngoài app. Tải ở luồng nền, mất mạng/sàn chưa hỗ trợ thì báo rõ. Hiện có cho MetaApi, cổng MT5, cổng+EA (MT4/MT5), hồ sơ cầu nối có khai op `history`, và Exness (tên trường chưa kiểm chứng); OANDA/Binance/ccxt chưa có lịch sử đồng bộ (nói rõ trên giao diện). Chỉ ở chế độ chạy thật. Số của từng vị thế làm mới theo chu kỳ «account_state_interval» (15 giây).",
        "KIỂM TRA HỆ THỐNG đọc thử số của sàn: thêm các bước account_state() (số dư/tài sản/ký quỹ), position_stats() (lãi/lỗ từng vị thế, đối chiếu đúng ticket vừa mở) và account_history() (lịch sử như tab MT5, đối chiếu deal mở+đóng của lệnh thử) cho MỌI sàn có hàm này; sàn không báo trường nào thì cảnh báo nêu tên trường, kèm phản hồi thô (đã che khoá) để chỉnh tên trường.",
        "SL/TP NATIVE CHO CỔNG + EA MT4/MT5 (trước chỉ MetaApi): MT5 TRADE_ACTION_SLTP, MT4 OrderModify, gắn lên đúng ticket, chỉ vị thế có comment «pyea». Cổng báo khả năng (sltp/posdeals/comment/history) qua /v1/ping và dòng HELLO của EA; cổng/EA bản cũ thì tự giữ SL/TP và nói rõ phải chép lại + biên dịch lại EA. Giá khớp thật của đúng ticket lấy từ lịch sử deal theo vị thế. MT4 không dùng định danh theo ticket (đóng một phần tạo ticket mới). Hồ sơ cầu nối (profile) có thể khai thêm op modify_position/deals_by_position/history.",
        "SL/TP NATIVE CHO EXNESS: mỗi vị thế một lệnh SLTP (sửa PATCH, gỡ DELETE). Tên trường của thân yêu cầu không lấy được từ nguồn chính thức nên app thử các dạng thân theo tài liệu chữ và NHỚ dạng nào sàn nhận; sàn từ chối hết thì vỏ vẫn tự canh. CHƯA kiểm chứng trên tài khoản thật - thử DEMO với «Kiểm tra sàn (--trade)».",
        "DANH TÍNH VỊ THẾ: vị thế nhập từ sàn khi đối soát được khớp theo ticket (không chỉ theo tổng khối lượng); tài khoản MT NETTING được hỗ trợ: vị thế ảo chỉ nhận SL/TP native khi nó chính là cả ticket, ticket gộp không bao giờ nhận SL/TP của riêng một vị thế.",
        "CÔ LẬP BOT TRÊN ANDROID (bot_isolation = process): mỗi bot chạy trong một dịch vụ worker riêng (Botworker0..3, tối đa 4 bot đồng thời ở chế độ này), nối với dịch vụ chính bằng socket cục bộ có token; bot treo/ăn bộ nhớ không kéo cả app. Hết chỗ worker thì báo rõ. CHƯA chạy trên thiết bị thật (một số hãng có thể giết dịch vụ worker - bot đó sẽ dừng với lỗi tiến trình); giới hạn bộ nhớ theo bot không áp dụng trên Android.",
        "SỬA LỖI cổng MT5: chưa biết chênh lệch giờ máy chủ (chưa có tick nào) thì hỏi lịch sử/vị thế sai múi giờ và BỎ SÓT các lệnh vừa đóng. Nay cổng tự dò từ tick của mã đang theo dõi (thử lại mỗi 30 giây).",
        "CHƯA LÀM: AI hub cho tài khoản phụ chạy trực tiếp; lịch sử đồng bộ cho OANDA/Binance/ccxt; mọi thứ mới ở bản này chỉ được kiểm bằng sàn/Kivy giả - file EA .mq4/.mq5 chưa từng biên dịch, chưa chạy trên sàn hay Cat S52 thật. Xem HANDOFF 5h.",
    ]),
    ("1.7.0", "2026-10-30", [
        "MẤT MẠNG / APP CHẾT - TRẢ LỜI THẲNG: (1) Mất mạng: sau 30 giây (Cài đặt «Báo động khi mất kết nối giá/sàn quá») app báo động NGHIÊM TRỌNG, nói rõ bao nhiêu vị thế đang được SÀN canh SL/TP (native, vẫn chạy), bao nhiêu chỉ do APP canh (KHÔNG chạy lúc này), bao nhiêu không có SL/TP, bao nhiêu lệnh chờ do app giữ sẽ không khớp; nhắc lại mỗi 10 phút nếu vẫn mất. Có lại mạng: báo + đối soát với sàn NGAY. (2) App/điện thoại chết hoặc bị hệ thống giết: báo thức giám sát (AlarmManager) dựng lại dịch vụ, khôi phục sổ lệnh, đối soát với sàn và BÁO NGHIÊM TRỌNG nếu phiên ngừng ≥90 giây khi đang có vị thế (SL/TP do app canh đã không chạy). (3) Sổ app có khớp sàn không: app so với vị thế THẬT trên sàn; lệch (lệnh đóng/mở lúc app không chạy, SL/TP native đã khớp trên sàn...) thì mặc định TỰ ĐỔI SỔ theo sàn và ghi rõ: vị thế đóng ngoài app được đóng ở GIÁ KHỚP THẬT (lấy từ lịch sử giao dịch của sàn) chứ không phải giá hiện tại, vị thế nào bị đóng thì giữ nguyên các vị thế còn lại. Hạn chế: SL/TP/lệnh chờ do APP canh KHÔNG chạy khi app chết hoặc mất mạng - muốn sàn tự canh thì bật «SL/TP native».",
        "ĐỐI SOÁT: mặc định nay là «adopt» (tự đổi sổ theo sàn; trước là chỉ báo). Một lệch chỉ được xử lý sau khi thấy LẶP LẠI hai lần cách nhau ≥2 giây (tránh đổi sổ vì lệnh đang bay). Lệnh do chính app gửi (bao gồm SL/TP native đã khớp) được loại khỏi phép tính nên không bị coi là «đóng ngoài app». Muốn như cũ: Cài đặt «Khi lệch vị thế với sàn» = alert.",
        "KHÔNG TỰ DỪNG KHI MẤT GIÁ: trước đây mất giá 120 lần liên tiếp thì dừng phiên. Nay phiên giữ nguyên, thử lại chậm dần (tối đa 15 giây), có nhật ký khi lấy lại được giá. Muốn tự dừng sau X phút: Cài đặt «Dừng phiên nếu mất giá liên tục quá (phút)» (0 = không dừng).",
        "KHÔI PHỤC PHIÊN CHỜ MẠNG: khởi động lại sau crash mà chưa có mạng thì phiên chờ và thử lại kết nối sàn (báo động nghiêm trọng, nhắc mỗi 10 phút) thay vì bỏ cuộc; bot chờ có đủ dữ liệu rồi mới chạy.",
        "SL/TP NATIVE GIỜ CHẠY QUA MỘT HỢP ĐỒNG CHUNG (pyea/protection.py, học theo MT5): vỏ chỉ nói «vị thế này, SL này, TP này»; mỗi sàn khai phong cách (ladder/pair/position) và vài hàm nguyên thuỷ - thêm sàn mới không phải sửa vỏ. MT/MetaApi nay có SL/TP native gắn lên đúng ticket (POSITION_MODIFY) vì vị thế ảo đã lưu ticket sàn và đóng theo ticket (không còn FIFO). VẪN MẶC ĐỊNH TẮT; thử demo trước. Exness vẫn chưa có (không lấy được schema `sltp`).",
        "BÁO THỨC GIÁM SÁT (Android AlarmManager) cho dịch vụ nền: Cài đặt «Báo thức giám sát dịch vụ (AlarmManager)» (mặc định bật, chu kỳ 5 phút). CHƯA kiểm chứng trên thiết bị thật.",
        "CẢNH BÁO: có vị thế mà SL/TP chỉ do app canh và «SL/TP native» đang tắt thì app nói rõ MỘT lần mỗi phiên (thanh kết nối ở tab Giao dịch cũng hiện «MẤT KẾT NỐI/LỖI API SÀN» khi sàn không trả lời).",
        "LỊCH KINH TẾ (API bot 1.4): bạn chọn nguồn (URL hoặc file JSON/CSV, vd bản tin JSON của faireconomy) ở Cài đặt → Lịch kinh tế. App nạp nền, báo trước tin quan trọng liên quan các mã đang theo dõi, và (tuỳ chọn) CHẶN LỆNH MỚI của bot/AI quanh giờ ra tin (api.calendar(), Ret.NEWS_BLOCK). Đóng lệnh, SL/TP, kill switch và lệnh bạn bấm tay không bao giờ bị chặn; lịch lỗi/trống thì không chặn gì; backtest không áp dụng.",
        "NHIỀU TÀI KHOẢN CHẠY TRỰC TIẾP (không cần dịch vụ nền): mỗi tài khoản phụ có phiên, sổ lệnh, nhật ký, bot riêng trong thư mục riêng. Hạn chế: không có AI hub cho tài khoản phụ và chúng dừng khi app đóng (cần dịch vụ nền để chạy khi app đóng).",
        "(Lúc phát hành 1.7.0) CHƯA LÀM: SL/TP native cho Exness; cô lập bot bằng tiến trình riêng trên Android; chưa chạy trên sàn/thiết bị thật. Hai mục đầu đã làm ở 1.8.0 (xem HANDOFF 5h).",
    ]),
    ("1.6.1", "2026-10-28", [
        "SL/TP NATIVE cho BINANCE SPOT (vẫn MẶC ĐỊNH TẮT, thử testnet trước): Spot không có reduceOnly và mọi lệnh bán chờ đều khoá coin đang giữ, nên SL + TP của cùng vị thế được đặt thành MỘT lệnh OCO (chân TP = LIMIT_MAKER, chân SL = STOP_LOSS); vị thế chỉ có SL hoặc chỉ có TP dùng lệnh đơn. Sàn khớp chân nào thì vỏ ghi sổ đúng chân đó ở giá khớp thật, không gửi thêm lệnh. Mức nào sàn từ chối thì vỏ vẫn tự canh.",
        "Phí mua bằng coin làm vị thế ảo lẻ hơn bước khối lượng của sàn (vd 0.04995 → lệnh bảo vệ 0.049): khi lệnh bảo vệ khớp trọn, phần dư nhỏ hơn một bước (không bán được) được tính là đã đóng, không để lại vị thế ảo vô hình.",
        "Kiểm tra sàn (`selfcheck --trade`) trên Spot nay thử lệnh OCO thật (một cặp) thay vì hai lệnh rời; hợp đồng adapter có thêm kiểm hình dạng `protection_orders()`.",
        "(Lúc phát hành 1.6.1 còn chưa làm MT bridge và Exness. MT bridge đã làm ở 1.7.0; Exness VẪN CHƯA - không lấy được schema loại lệnh `sltp` từ nguồn chính thức. Xem HANDOFF 5f/5g.)",
    ]),
    ("1.6.0", "2026-10-28", [
        "BOT (API 1.3): kho bền api.store (riêng của bot) và api.shared (chung mọi bot, như GlobalVariable của MT5); api.oco() nối lệnh chờ thành nhóm OCO; api.stats() thống kê lệnh đã đóng của bot; on_tester() trả fitness riêng cho tối ưu hoá (MT5 OnTester).",
        "LỆNH: OCO cho lệnh chờ (một lệnh khớp thì vỏ huỷ lệnh còn lại) và FREEZE LEVEL (lệnh chờ/SL/TP gần giá quá thì không sửa/huỷ được, trả Ret.FROZEN; đóng vị thế không bị chặn).",
        "BACKTEST: chọn thứ tự giá trong nến (O→H→L→C, O→L→H→C, hoặc «xấu nhất» với lệnh đang mở) + nút «So sánh thứ tự giá trong nến» để đo độ nhạy - kết quả đổi dấu tức là chiến lược dựa vào giả định không kiểm chứng được. Xếp tối ưu/walk-forward theo Fitness (on_tester).",
        "AI: tín hiệu AI được GHI (model + dấu vân tay prompt) và backtest PHÁT LẠI đúng các tín hiệu đã ghi (không nhìn trước; không sinh lại câu trả lời của AI). Backtest không phát lại thì báo rõ bot luôn nhận None. URL các nhà cung cấp đối chiếu tài liệu chính thức; model gợi ý của Gemini cập nhật, ghi chú Cerebras sửa cho đúng.",
        "AN TOÀN: che khoá/bí mật trong nhật ký và chat AI (và không gửi khoá nằm trong mã bot cho nhà cung cấp AI); phiên bản định dạng dữ liệu (file mới hơn app thì giữ nguyên, không ghi đè); xoay vòng/cắt nhật ký; cảnh báo rủi ro lần đầu trước khi chạy LIVE; chặn chụp/quay màn hình (FLAG_SECURE) tuỳ chọn.",
        "QUYỀN MẠNG theo bot: khai báo `# @permission: network(host)` trong bot, người dùng cho phép từng bot. Chỉ CƯỠNG CHẾ khi bot chạy ở tiến trình riêng (không phải ranh giới an ninh trước mã cố tình phá).",
        "KHÔNG LÀM PHIỀN: tạm tắt âm/rung cảnh báo 1/4/8/24 giờ (Cài đặt) hoặc theo khung giờ ban đêm. Cảnh báo vẫn được ghi và hiện thông báo im lặng; sự cố nghiêm trọng (kill switch, margin call, bot/dịch vụ lỗi, lệch vị thế...) mặc định vẫn kêu.",
        "SỬA LỖI backtest: chế độ «xấu nhất» không đổi thứ tự giá cho lệnh bán (vòng lặp dùng danh sách cũ).",
        "(Lúc phát hành 1.6.0 chưa có SL/TP native cho Exness, cầu nối MT và Binance Spot: Spot làm ở 1.6.1, MT ở 1.7.0, Exness vẫn chưa.)",
    ]),
    ("1.5.1", "2026-10-26", [
        "Kiểm tra sàn CHUNG cho mọi sàn: nút «Kiểm tra hệ thống» và lệnh `python -m pyea.selfcheck` (thêm `--trade --yes` để thử lệnh thật khối lượng nhỏ nhất trên tài khoản DEMO: mua, lệnh chờ đặt/sửa/huỷ, đóng một phần, SL/TP native, đóng nốt, dọn dẹp). Báo cáo kèm phản hồi thô của sàn (đã che khoá).",
        "Hợp đồng broker/feed (pyea/contract.py): một bộ kiểm tra chữ ký + hình dạng dữ liệu chạy trên MỌI adapter - bắt lỗi kiểu gọi sai tham số trước khi chạy tiền thật.",
        "SỬA LỖI Exness: đồng bộ lịch sử gọi sai tham số (lỗi mỗi chu kỳ trên tài khoản thật); nến thiếu tham số `from` bắt buộc; lịch sử qua /v1/history có phân trang và giới hạn tuổi/độ dài; giá làm tròn theo point_digits; sửa lệnh chờ chỉ dùng PATCH.",
        "Exness: bảng mã lỗi cuối của lệnh có gợi ý tiếng Việt, đọc giới hạn từ phản hồi /limits đúng cấu trúc tài liệu, cờ tài khoản close_only/trading_disabled chặn lệnh mới, đóng MỘT PHẦN được kiểm tra lại (nếu sàn bỏ qua khối lượng và đóng hết thì app báo rõ và đổi cách gửi).",
        "SL/TP NATIVE nay có cả cho OANDA (lệnh STOP/LIMIT REDUCE_ONLY); Binance dùng chung thuật toán bậc thang. Vẫn MẶC ĐỊNH TẮT, thử demo trước.",
        "Sửa nhỏ: lệnh chờ kiểu stop của Binance báo giá kích hoạt (trước là 0); cầu nối MT/ccxt báo đủ khối lượng/giá lệnh chờ; OANDA cờ tradeable theo `status`, lý do huỷ lệnh lấy từ giao dịch huỷ.",
    ]),
    ("1.5.0", "2026-10-24", [
        "Cảnh báo theo chỉ báo: RSI cắt mức, EMA nhanh cắt EMA chậm (tính trên nến đã đóng).",
        "Nhật ký lọc theo khoảng thời gian; biểu đồ lưu/áp MẪU (bộ chỉ báo + cách hiển thị); tuỳ chọn hiển thị khối lượng theo lot/đơn vị.",
        "Backtest DANH MỤC trên giao diện: chạy nhiều bot đã gắn cùng một tài khoản và xem từng bot.",
        "THỬ NGHIỆM (mặc định tắt): SL/TP NATIVE trên Binance Futures - lệnh bảo vệ reduceOnly đặt trên sàn nên SL/TP vẫn chạy khi app/điện thoại chết. Bật ở Cài đặt, thử testnet trước.",
        "SỬA LỖI: lệnh chờ kiểu stop trên Binance Futures nay đi qua Algo Order (từ 2025-12-09 sàn từ chối STOP_MARKET qua /order, lỗi -4120).",
        "Bot có thêm api.trace() và chế độ Trace (nút «Trace» trên thẻ bot) để xem từng điều kiện bot tính ra sao.",
        "Lệnh khớp MỘT PHẦN được báo rõ (OrderResult.partial/remaining) thay vì im lặng.",
        "Đọc cờ tài khoản từ sàn: canTrade, loại ký quỹ (cross/isolated), tiền tệ. Sàn báo canTrade=false thì chặn lệnh mới.",
        "Feed mất giữa chừng: tự phát hiện khoảng trống nến và tải bù trước khi bot thấy nến mới.",
        "Bot đổi tên tham số không còn làm mất giá trị người dùng đã lưu (param_aliases) và vỏ báo tham số bị bỏ/mới.",
        "Cài đặt mới: âm thanh/rung thông báo, giờ hiển thị (giờ máy/UTC/lệch giờ), SL/TP mặc định cho lệnh tay.",
        "Backtest → nút «TRIỂN KHAI»: gắn đúng bot/mã/khung/tham số vừa thử (tài khoản thật: gắn nhưng chưa chạy).",
        "Thêm bot mẫu Breakout Donchian và DCA định kỳ.",
        "Nút «Nạp lại» trên thẻ bot: nạp mã bot mới mà không dừng bot, vị thế giữ nguyên; lỗi thì tự quay lại bản cũ.",
        "Backtest: tuỳ chọn swap x3 theo ngày (kiểu broker MT) với giờ rollover tự chọn.",
    ]),
    ("1.4.0", "2026-10-23", [
        "Exness, cầu nối MT4/MT5, ccxt, lệnh chờ native, đồng bộ sàn, giới hạn tốc độ gọi API, Keystore, backtest có chi phí.",
    ]),
]

# Lịch sử API bot: bot dùng tính năng nào thì khai báo `# @api_min: <phiên bản>` ở đầu file
API_CHANGES = [
    ("1.8", ["api.draw_hline/draw_trend/draw_rect/draw_fib/draw_text(name, ...), draw_delete(name), draw_clear(): bot vẽ đối tượng lên biểu đồ (như ObjectCreate/ObjectMove/ObjectDelete; cùng tên = di chuyển; tối đa 60/bot; chỉ để vẽ)",
             "api.order_book(depth, symbol) và api.recent_trades(count, symbol): sổ lệnh và giao dịch khớp (hiện chỉ Binance; nguồn khác/backtest trả None)"]),
    ("1.7", ["ĐA MÃ: symbol=... cho api.candles/closes/buy/sell/buy_limit/sell_limit/buy_stop/sell_stop/buy_stop_limit/sell_stop_limit/positions/orders; api.tick_of(symbol). Mã khác tự vào danh sách theo dõi giá. Backtest: đọc nến mã khác qua run_backtest(extra=)"]),
    ("1.6", ["api.ask_ai(question, include, data, schema, web, agent, key, tag, wait, cache_s, ...): hỏi AI lấy ý kiến tham khảo, không chặn bot; trả AIAnswer (status ok/pending/error/disabled/limited/no_replay, data đã kiểm theo schema)",
             "api.ask_ai_info(): hạn mức/đang bật; sdk.AIAnswer; `# @permission: ai_ask`. Backtest không gọi AI (chỉ phát lại câu đã ghi)"]),
    ("1.5", ["AccountInfo.broker_synced/broker_balance/broker_equity/broker_margin/broker_free_margin/broker_margin_level/broker_profit: số của SÀN (giống khung «Giao dịch» MT5); "
             "balance/equity/margin... vẫn là sổ riêng của app",
             "Position.adopted: True = vị thế nhập từ sàn qua đối soát (bạn mở tay), vỏ không tự sửa SL/TP gốc của nó"]),
    ("1.4", ["api.calendar(hours, min_impact): tin kinh tế sắp ra liên quan mã của bot (rỗng nếu người dùng chưa bật lịch)",
             "Ret.NEWS_BLOCK: lệnh MỚI bị vỏ chặn quanh tin quan trọng khi người dùng bật «chặn lệnh quanh tin» (đóng lệnh không bị chặn)"]),
    ("1.3", ["api.store / api.shared: kho khoá-giá trị JSON bền (get/set/incr/delete/has/keys/items/clear/size)", "api.oco(a, b, ...) và PendingOrder.oco", "api.stats()", "BaseBot.on_tester() -> fitness cho tối ưu hoá",
             "Ret.FROZEN, SymbolInfo.freeze_level", "khai báo quyền `# @permission: network(host)`", "api.ai_signal có thêm model, prompt_hash (và replayed khi backtest phát lại)"]),
    ("1.2", ["(vỏ) tuỳ chọn SL/TP native không đổi API bot - bot vẫn đặt sl=/tp= như cũ", "on_deinit(reason) nhận thêm reason='reload' khi người dùng nạp lại mã bot", "api.trace(text, **values), api.trace_enabled", "OrderResult.partial, OrderResult.remaining",
             "AccountInfo.margin_mode", "lớp bot có thể khai báo param_aliases = {tên_cũ: tên_mới}"]),
    ("1.1", ["on_trade, on_timer", "lệnh chờ (limit/stop/stop-limit)", "OrderResult có mã lỗi (Ret)", "symbol_info()/account_info()/time_info()",
             "đóng một phần"]),
    ("1.0", ["on_init, on_tick, on_bar, on_deinit", "buy/sell/close/close_all, candles(), tick"]),
]


def changelog_text(limit=3):
    out = []
    for ver, day, items in CHANGELOG[:limit]:
        out.append("v%s (%s)" % (ver, day))
        out.extend("  • " + i for i in items)
        out.append("")
    return "\n".join(out).rstrip()


def api_changes_text():
    out = []
    for ver, items in API_CHANGES:
        out.append("API %s" % ver)
        out.extend("  • " + i for i in items)
    return "\n".join(out)
