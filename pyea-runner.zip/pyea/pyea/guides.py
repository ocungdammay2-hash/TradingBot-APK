"""Hướng dẫn «dùng thông tin nào để đăng nhập» cho nút «?» cạnh các ô Cài đặt. Thuần văn bản, không import Kivy (test được).
Mọi điều chưa kiểm với sàn thật đều ghi rõ trong chữ."""

MT5_OVERVIEW = (
    "ĐĂNG NHẬP MT5 TRỰC TIẾP (mt5ws) CẦN 3 THỨ\n"
    "1) Số tài khoản (login): dãy số MT5 của bạn, thường nằm trong email khi mở tài khoản hoặc trong trang cá nhân của broker. KHÔNG phải email, KHÔNG phải ID khách hàng.\n"
    "2) Mật khẩu GIAO DỊCH của tài khoản MT5 (đặt lúc mở tài khoản). KHÔNG phải mật khẩu đăng nhập trang cá nhân của broker. Mật khẩu «investor» chỉ cho xem, không đặt lệnh được.\n"
    "3) Địa chỉ máy chủ (uri): MT5 thật chọn máy chủ bằng TÊN (vd «Broker-Real5»), còn cách này chọn bằng ĐỊA CHỈ web terminal của máy chủ đó. Để trống = tài khoản DEMO của MetaQuotes.\n\n"
    "CHƯA CÓ TÀI KHOẢN? Bấm «Mở tài khoản DEMO MT5» để tạo DEMO ngay trên điện thoại (broker có thể từ chối).\n\n"
    "BROKER KHÔNG CÓ WEB TERMINAL MT5 (nhiều broker không bật)? Cách này không dùng được. Chọn nguồn khác trong «Nguồn thị trường / sàn»: exness (API riêng của Exness), "
    "metaapi (dịch vụ đám mây trả phí, nối MT5 của hầu hết broker), mt5ea (MT5 chạy trong giả lập trên điện thoại + EA cầu nối), mt5gw/bridge (cầu nối tới MT5 chạy ở máy khác), oanda, capital, binance.\n\n"
    "LUÔN thử DEMO trước. Phần MT5 trực tiếp CHƯA được kiểm với sàn thật."
)

EA_OVERVIEW = (
    "MT5 QUA EA CẦU NỐI (mt5ea) - TUỲ CHỌN, mặc định TẮT, chỉ chạy khi bạn chọn nguồn «mt5ea».\n"
    "Dùng khi broker KHÔNG có web terminal MT5. MT5 bản đầy đủ phải chạy trong trình giả lập Windows trên điện thoại (xem docs/MT5_ON_PHONE.md, tools/mt5_phone/); "
    "một EA nhỏ chỉ làm cầu nối, toàn bộ logic bot nằm trong app.\n\n"
    "CÁC BƯỚC (hạn chế tối đa phải mở MT5): 1) Điền token (>= 8 ký tự) + cổng + tài khoản/máy chủ MT5 NGAY TRONG CÀI ĐẶT của app. "
    "2) Trong Termux chạy `PYEA_TOKEN=<token> MT5_DIR=<thư mục MT5> bash run_mt5_termux.sh setup`: script lấy PyEABridge.mq5, bridge.set, startup.ini TỪ APP, ghi vào MT5 và biên dịch EA bằng dòng lệnh - kết quả/lỗi biên dịch hiện ngay trong app. "
    "3) Chạy `bash run_mt5_termux.sh` (giám sát MT5). 4) Bấm «Kiểm tra EA cầu nối». Việc phải làm TRONG MT5 chỉ có thể là cho phép 127.0.0.1 (1 lần) nếu startup.ini không tự đặt được.\n\n"
    "BẢO VỆ: mất liên lạc với app quá N giây thì EA làm theo chính sách (hold/breakeven/close_all) với lệnh do app mở, và gửi thông báo tới MT5 mobile. App báo động khi mất cầu nối, EA đứng, "
    "hoặc công tắc đã chạy.\n\nLỖI Ở ĐÂU: KHÔNG cần mở MT5/MetaEditor. Script giám sát đẩy về app: mã thoát của MT5 (kèm lý do), lỗi biên dịch, và các dòng log MT5 (Experts/Journal) đáng chú ý; EA đẩy lỗi lệnh. "
    "Tất cả hiện thành cảnh báo và gom trong nút «Xuất chẩn đoán EA» (file văn bản, token đã che) để gửi đi. (Cách thủ công, nếu bạn không chạy script: MetaEditor F7 → Toolbox Ctrl+T → tab Errors; MT5 Toolbox tab Experts/Journal.)\n"
    "Tab «Kiểm tra EA cầu nối» trong app cũng liệt kê từng bước và cách khắc phục.\n\nCHƯA kiểm với MT5 thật; EA chưa được biên dịch thử. Chỉ dùng DEMO."
)

GUIDES = {
    "mt5ws_login": ("Số tài khoản MT5",
                    "Điền số tài khoản MT5 (chỉ chữ số).\n\nTìm ở đâu: email «tài khoản đã được tạo» của broker, hoặc trang cá nhân của broker → Tài khoản → thông tin MT5. "
                    "Một người có thể có nhiều tài khoản MT5, mỗi tài khoản một số riêng; chọn đúng tài khoản muốn chạy bot.\n\nKhông dùng: email, ID khách hàng, số tài khoản MT4.\n\n" + MT5_OVERVIEW),
    "mt5ws_password": ("Mật khẩu MT5",
                       "Điền MẬT KHẨU GIAO DỊCH của tài khoản MT5.\n\nĐây là mật khẩu đặt lúc mở tài khoản MT5, KHÁC mật khẩu đăng nhập trang cá nhân của broker. Quên thì đặt lại ngay trong trang cá nhân của broker (mục Tài khoản → đổi/đặt lại mật khẩu).\n\n"
                       "Mật khẩu investor (chỉ xem): đăng nhập được nhưng KHÔNG đặt lệnh; kết quả «Kiểm tra» sẽ cảnh báo.\n\n" + MT5_OVERVIEW),
    "mt5ws_uri": ("Địa chỉ máy chủ MT5 (uri)",
                  "MT5 thường nhập TÊN máy chủ, còn giao thức web terminal chọn máy chủ bằng ĐỊA CHỈ. Gói đăng nhập chỉ có số tài khoản + mật khẩu.\n\n"
                  "• DEMO MetaQuotes: để trống.\n• Broker: tìm tên máy chủ trong email mở tài khoản (vd «Broker-Demo»), mở web terminal MT5 của broker trên trình duyệt, đăng nhập đúng máy chủ đó rồi lấy địa chỉ web terminal "
                  "dán vào đây. Dán https://... cũng được, app tự đổi sang wss://.../terminal.\n• Mỗi máy chủ giao dịch của một broker thường có host riêng; chọn sai máy chủ sẽ báo sai tài khoản/mật khẩu.\n"
                  "• Broker không có web terminal MT5 thì không dùng được ô này.\n\nLƯU Ý: cách lấy địa chỉ từ trang web terminal của từng broker mình CHƯA kiểm; nếu «Kiểm tra» báo lỗi kết nối, hỏi hỗ trợ broker «địa chỉ WebSocket của MT5 Web Terminal».\n\n" + MT5_OVERVIEW),
    "mt5ws_url": ("Url đăng nhập (tuỳ chọn)",
                  "Host của trang web terminal, gửi kèm khi đăng nhập. Gần như luôn để TRỐNG: app tự lấy từ địa chỉ máy chủ (với web.metatrader.app thì để trống đúng như thư viện tham chiếu). "
                  "Chỉ điền khi broker yêu cầu host trang khác với host WebSocket."),
    "mt5ws_otp": ("Mã OTP",
                  "Chỉ cần khi tài khoản MT5 BẬT xác thực 2 bước (OTP) trong MT5 mobile. Điền mã 6 số hiện tại; mã đổi mỗi ~30 giây nên có thể phải điền lại trước khi bấm Kiểm tra. Không bật OTP thì để trống."),
    "mt5ea_token": ("EA cầu nối: token", "Mật khẩu chung giữa app và EA, >= 8 ký tự, không khoảng trắng, không chứa | hoặc =. Điền CÙNG giá trị vào tham số InpToken của EA. Token sai thì app từ chối và báo động.\n\n" + EA_OVERVIEW),
    "mt5ea_port": ("EA cầu nối: cổng", "Cổng app mở trên 127.0.0.1 (chỉ trong máy này, không ra mạng). Mặc định 18765. Đổi nếu bị chiếm; EA dùng cùng cổng (InpPort).\n\n" + EA_OVERVIEW),
    "mt5ea_deadman_s": ("Công tắc người chết", "Số giây EA chờ app trước khi coi là app đã chết (5-3600). Quá nhỏ dễ kích nhầm khi Android làm app chậm; quá lớn thì lâu mới bảo vệ. Gợi ý 20-60.\n\n" + EA_OVERVIEW),
    "mt5ea_policy": ("Chính sách khi mất app", "hold: giữ nguyên, chỉ dựa SL/TP sẵn trên sàn.\nbreakeven: dời SL về giá vào cho vị thế đang LỜI (vị thế lỗ giữ nguyên).\nclose_all: đóng hết vị thế và huỷ lệnh chờ do app mở.\n"
                         "Chỉ áp cho lệnh có comment bắt đầu «pyea»; lệnh đặt tay/EA khác không bị đụng.\n\n" + EA_OVERVIEW),
    "mt5ea_login": ("Số tài khoản MT5 (cho startup.ini)", "Chỉ dùng để sinh file khởi động MT5. Mật khẩu: đăng nhập tay một lần trong MT5 để terminal nhớ.\n\n" + EA_OVERVIEW),
    "mt5ea_server": ("Máy chủ MT5 (cho startup.ini)", "Tên/địa chỉ máy chủ giao dịch của broker như trong email mở tài khoản.\n\n" + EA_OVERVIEW),
    "exchange": ("Chọn nguồn thị trường / sàn",
                 "simulated: giả lập, không cần tài khoản.\npublic: giá thật, không cần tài khoản (chỉ paper/xem/backtest).\nbinance / oanda / capital / ccxt: nhập API key của sàn đó.\n"
                 "exness: API riêng của Exness (key + khoá Ed25519 + số tài khoản).\nmt5ws: MT5 trực tiếp bằng số tài khoản + mật khẩu + địa chỉ web terminal (cần broker có web terminal MT5).\n"
                 "mt5ea: MT5 bản đầy đủ chạy trong giả lập + EA cầu nối (tuỳ chọn, cho broker không có web terminal).\nmetaapi: MT5 qua dịch vụ đám mây trả phí (nhập token + id tài khoản).\nmt5gw / bridge: nối tới MT5 chạy ở máy khác.\n\nChưa chắc chọn gì: bắt đầu bằng simulated hoặc public, rồi DEMO của sàn bạn có."),
}


def guide_for(key):
    """(tiêu đề, nội dung) hoặc None nếu ô này không có hướng dẫn."""
    return GUIDES.get(key)
