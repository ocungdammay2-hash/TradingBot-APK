"""Giao diện «Chi tiết lệnh» + «Xem trên biểu đồ» (nhảy tới điểm vào/ra của đúng lệnh). Logic dữ liệu ở pyea/tradeinfo.py (test được không cần Kivy)."""
import threading

from kivy.clock import mainthread
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.utils import escape_markup

from . import tradeinfo
from .feeds import TIMEFRAMES, fetch_history, make_feed
from .ui_widgets import AMBER, BLUE, DOWN, MIN_TOUCH, MUTED, PANEL2, TEXT, UP, StyledPopup, flabel, mk_spinner, mkbtn, vbox, vscroll, wlabel


def show_detail(app, info):
    """Popup chi tiết: nguồn gốc, bot, logic vào/ra, giá/thời gian, SL/TP, phí + nút «Xem trên biểu đồ» / «Giải thích vào» / «Giải thích ra»."""
    from .ui import add_text_block
    content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    box = vbox(spacing=dp(4), padding=dp(4))
    for k, v in info["rows"]:
        r = BoxLayout(size_hint_y=None, height=dp(24))
        r.add_widget(flabel(escape_markup(k), 11, MUTED, size_hint_x=0.38))
        r.add_widget(flabel(escape_markup(str(v)), 12, TEXT, bold=True))
        box.add_widget(r)
    box.add_widget(flabel("LOGIC VÀO LỆNH", 12, AMBER, bold=True, size_hint_y=None, height=dp(26)))
    add_text_block(box, info["entry_logic"], 12)
    if info["closed"]:
        box.add_widget(flabel("LÝ DO THOÁT", 12, AMBER, bold=True, size_hint_y=None, height=dp(26)))
        add_text_block(box, info["exit_logic"] or "Không có ghi chép lý do thoát.", 12)
    content.add_widget(vscroll(box))
    pop = StyledPopup(title=info["title"], content=content, size_hint=(0.97, 0.94), auto_dismiss=False)
    r1 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
    r1.add_widget(mkbtn("Xem trên biểu đồ", BLUE, on_release=lambda *_: show_chart(app, info)))
    if info["open_event"] is not None:
        r1.add_widget(mkbtn("Chi tiết vào", PANEL2, size=12, on_release=lambda *_: app.show_event(info["open_event"])))
    if info["close_event"] is not None:
        r1.add_widget(mkbtn("Chi tiết ra", PANEL2, size=12, on_release=lambda *_: app.show_event(info["close_event"])))
    content.add_widget(r1)
    r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
    r2.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy("\n".join("%s: %s" % kv for kv in info["rows"]) + "\n\nLogic vào: " + info["entry_logic"])))
    r2.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
    content.add_widget(r2)
    pop.open()


def show_chart(app, info):
    """Biểu đồ nến quanh lệnh: khung tự chọn theo thời gian giữ lệnh (đổi được), chấm vào/ra + đường nối, đường SL/TP; tải nến ở luồng nền."""
    from .ui import ChartPanel
    t0, t1 = info["span"]
    tf0, _ = tradeinfo.pick_tf(t0, t1)
    content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    status = wlabel("Đang tải nến...", 11, MUTED, size_hint_y=None, height=dp(22))
    sp = mk_spinner(tf0, [k for k in TIMEFRAMES if k != "1mo"], size_hint_x=0.3)
    top = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
    top.add_widget(wlabel("Khung:", 12, MUTED, size_hint_x=0.2))
    top.add_widget(sp)
    content.add_widget(top)
    content.add_widget(status)
    panel = ChartPanel(app, "tradeview", height=360)
    content.add_widget(vscroll(panel))
    pop = StyledPopup(title="Biểu đồ: " + info["title"], content=content, size_hint=(0.99, 0.96), auto_dismiss=False)
    content.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
    gen = [0]

    def load(*_):
        gen[0] += 1
        token, tf = gen[0], sp.text
        status.text = "Đang tải nến %s quanh lệnh..." % tf
        step = TIMEFRAMES[tf]
        a, b = tradeinfo.window(t0, t1, step)
        n = min(tradeinfo.bars_needed(t0, t1, step), 3000)

        def work():
            try:
                feed = make_feed(app.settings["exchange"], app.settings)
                cs = fetch_history(feed, info["symbol"], tf, n, end=b + step)
                cs = [c for c in cs if c.time >= a - step]
                err = "" if cs else "Sàn không trả nến cho khoảng thời gian này (quá xa/khung quá nhỏ). Thử khung lớn hơn."
            except Exception as e:                                 # noqa: BLE001 - mọi lỗi nguồn dữ liệu đều báo người dùng
                cs, err = [], "Không tải được nến: %s" % e
            done(token, cs, err, tf)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def done(token, cs, err, tf):
        if token != gen[0]:
            return
        if err:
            status.text, status.color = err, DOWN
            return
        status.text, status.color = "%d nến %s · chấm xanh/đỏ = vào/ra, đường nét đứt = giá vào/ra/SL/TP. Chạm chấm để xem lý do." % (len(cs), tf), MUTED
        hl = []
        side_col = UP if info["side"] == "buy" else DOWN
        hl.append((info["entry"][1], side_col, "VÀO", None))
        if info["exit"]:
            hl.append((info["exit"][1], AMBER, "RA", None))
        if info["sl"]:
            hl.append((info["sl"], DOWN, "SL", None))
        if info["tp"]:
            hl.append((info["tp"], UP, "TP", None))
        panel.chart.bars = max(30, len(cs))
        panel._events = tradeinfo.marker_events(info)
        panel.update(cs, {}, panel._events, hl)
    sp.bind(text=load)
    pop.open()
    load()
