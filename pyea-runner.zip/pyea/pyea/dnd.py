"""«Không làm phiền» (DND) cho CẢNH BÁO (PDF «thiếu gì» mục 13: tạm tắt alarm trong N giờ) - thuần Python, không Kivy.

Hai cách bật, dùng chung một quy tắc:
  - Tạm hoãn N giờ (snooze): trạng thái nằm ở file `dnd.json` để UI và dịch vụ nền (hai tiến trình khác nhau) cùng thấy ngay, kể cả khi
    một bên ghi trong lúc bên kia đang chạy; hết hạn tự tắt (không cần ai tắt, không quên bật lại).
  - Khung giờ yên tĩnh hằng ngày (`dnd_from`/`dnd_to` trong cài đặt, vd 22:00 → 07:00, qua nửa đêm được) theo GIỜ MÁY của thiết bị.

Quy tắc an toàn (chọn có chủ đích): DND chỉ tắt ÂM THANH + RUNG, KHÔNG nuốt cảnh báo:
  - Cảnh báo vẫn được ghi vào nhật ký/danh sách cảnh báo và vẫn hiện thông báo IM LẶNG (người dùng nhìn vào là thấy).
  - Cảnh báo NGHIÊM TRỌNG (kill switch, margin call, bot/dịch vụ lỗi hoặc treo, lệch vị thế với sàn, phiên dừng, đặt lệnh liên tiếp thất bại...)
    mặc định VẪN kêu dù đang DND (`dnd_critical_pass`). Người dùng có thể tắt tuỳ chọn này để im lặng hoàn toàn - khi đó tự chịu rủi ro.
  - `engine.alarm(..., critical=True)` là mặc định: cảnh báo MỚI thêm sau này mà quên phân loại sẽ không bị tắt tiếng nhầm.
"""
import json
import math
import os
import threading
import time

FILE = "dnd.json"
MAX_HOURS = 72.0

_lock = threading.RLock()
_cfg = {"path": None, "from": None, "to": None, "critical_pass": True}
_cache = {"sig": None, "until": 0.0}


def configure(path):
    """Đặt file trạng thái (UI và dịch vụ nền gọi cùng một đường dẫn). path=None: chỉ giữ trong bộ nhớ (test/CLI)."""
    with _lock:
        _cfg["path"] = path
        _cache.update(sig=None, until=0.0)


def parse_hhmm(s):
    """'22:30' -> phút trong ngày (1350); rỗng/sai định dạng -> None (coi như tắt, không ném lỗi)."""
    try:
        h, m = str(s).strip().split(":")
        h, m = int(h), int(m)
    except (ValueError, AttributeError):
        return None
    return h * 60 + m if (0 <= h <= 23 and 0 <= m <= 59) else None


def problems(settings):
    """Lỗi nhập khung yên tĩnh (để UI báo khi lưu thay vì lặng lẽ coi là tắt): list chuỗi, rỗng = hợp lệ."""
    s = settings or {}
    a, b = str(s.get("dnd_from") or "").strip(), str(s.get("dnd_to") or "").strip()
    out = []
    for lbl, v in (("từ", a), ("đến", b)):
        if v and parse_hhmm(v) is None:
            out.append("Khung yên tĩnh «%s»: %r không phải giờ HH:MM (vd 22:00)" % (lbl, v))
    if bool(a) != bool(b):
        out.append("Khung yên tĩnh cần nhập CẢ «từ» và «đến» (hoặc để trống cả hai)")
    elif a and a == b:
        out.append("Khung yên tĩnh: «từ» và «đến» trùng nhau nên khung rỗng")
    return out


def apply(settings):
    """Nạp tuỳ chọn từ cài đặt (prefs.apply gọi)."""
    s = settings or {}
    with _lock:
        _cfg["from"] = parse_hhmm(s.get("dnd_from"))
        _cfg["to"] = parse_hhmm(s.get("dnd_to"))
        _cfg["critical_pass"] = bool(s.get("dnd_critical_pass", True))


def _sig(path):
    try:
        st = os.stat(path)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def _snooze_until():
    with _lock:
        path = _cfg["path"]
        if not path:
            return _cache["until"]
        sig = _sig(path)
        if sig == _cache["sig"]:
            return _cache["until"]
        until = 0.0
        if sig is not None:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    v = float(json.load(f).get("until", 0.0))
                until = v if math.isfinite(v) else 0.0
            except (OSError, ValueError, TypeError, AttributeError):
                until = 0.0
        _cache.update(sig=sig, until=until)
        return until


def snooze(hours, now=None):
    """Tạm hoãn âm thanh/rung cảnh báo `hours` giờ (0 hoặc âm = tắt). Giới hạn 72 giờ. -> epoch giây khi hết hạn (0.0 nếu đã tắt)."""
    hours = float(hours)
    if not math.isfinite(hours):
        raise ValueError("Số giờ không hợp lệ: %r" % (hours,))
    if hours <= 0:
        cancel()
        return 0.0
    now = time.time() if now is None else float(now)
    until = now + min(hours, MAX_HOURS) * 3600.0
    _write(until)
    return until


def cancel():
    _write(0.0)


def _write(until):
    with _lock:
        path = _cfg["path"]
        if not path:
            _cache["until"] = until
            return
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"until": until}, f)
            os.replace(tmp, path)
        except OSError:
            _cache["until"] = until                               # không ghi được file: ít nhất tiến trình này vẫn tôn trọng
            _cache["sig"] = None
            return
        _cache.update(sig=_sig(path), until=until)


def _window_end(now):
    """Nếu `now` đang trong khung giờ yên tĩnh hằng ngày -> epoch lúc khung kết thúc, ngược lại 0.0."""
    a, b = _cfg["from"], _cfg["to"]
    if a is None or b is None or a == b:
        return 0.0
    lt = time.localtime(now)
    m = lt.tm_hour * 60 + lt.tm_min
    inside = (a <= m < b) if a < b else (m >= a or m < b)
    if not inside:
        return 0.0
    wait_min = (b - m) if b > m else (b + 1440 - m)                 # số phút tới lúc kết thúc (tính theo phút tròn)
    return now - lt.tm_sec + wait_min * 60.0


def remaining(now=None):
    """Số giây DND còn hiệu lực (0 = không đang DND)."""
    now = time.time() if now is None else float(now)
    with _lock:
        end = max(_snooze_until(), _window_end(now))
    return max(0.0, end - now)


def active(now=None):
    return remaining(now) > 0.0


def muted(critical=True, now=None):
    """Cảnh báo này có phải phát IM LẶNG không? DND đang bật VÀ (không phải cảnh báo nghiêm trọng, hoặc người dùng đã tắt «vẫn báo nghiêm trọng»)."""
    if critical and _cfg["critical_pass"]:
        return False
    return active(now)


def describe(now=None):
    """Chuỗi hiển thị cho UI."""
    now = time.time() if now is None else float(now)
    r = remaining(now)
    if r <= 0:
        a, b = _cfg["from"], _cfg["to"]
        extra = " (khung yên tĩnh hằng ngày %02d:%02d–%02d:%02d)" % (a // 60, a % 60, b // 60, b % 60) if (a is not None and b is not None and a != b) else ""
        return "Không làm phiền: tắt" + extra
    end = now + r
    h, m = int(r // 3600), int((r % 3600) // 60)
    left = "%dg%02dp" % (h, m) if h else "%dp" % max(1, m)
    crit = "cảnh báo nghiêm trọng vẫn kêu" if _cfg["critical_pass"] else "TẮT CẢ, kể cả cảnh báo nghiêm trọng"
    return "Đang không làm phiền đến %s (còn %s) - %s" % (time.strftime("%H:%M", time.localtime(end)), left, crit)
