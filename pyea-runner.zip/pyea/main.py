"""Điểm vào của app (buildozer yêu cầu main.py ở thư mục gốc).

Khởi động có «mốc» (boot.log) + màn hình lỗi dự phòng: lỗi lúc import/dựng giao diện không làm app văng ra ngoài trong im lặng."""
import sys
import threading
import traceback

from pyea import bootlog


def _fallback(tb, title="PyEA KHÔNG KHỞI ĐỘNG ĐƯỢC - chụp màn hình này gửi người phát triển", can_continue=False):
    """Màn hình lỗi tối giản (chỉ dùng Kivy trần): hiện thông tin lỗi NGAY trên màn hình, có nút Sao chép / Gửi. Trả True nếu người dùng bấm «Mở app»."""
    from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.label import Label

    from kivy.core.clipboard import Clipboard
    from kivy.uix.button import Button
    state = {"go": False}

    class Fallback(App):
        title = "PyEA Runner - lỗi khởi động"

        def build(self):
            box = BoxLayout(orientation="vertical", padding=8, spacing=6)
            lb = Label(text=title, size_hint_y=None, height=70, color=(1, 0.75, 0.2, 1), halign="center", valign="middle")
            lb.bind(size=lambda w, s: setattr(w, "text_size", s))
            box.add_widget(lb)
            from kivy.graphics import Color, Rectangle
            from kivy.uix.scrollview import ScrollView
            sv = ScrollView(do_scroll_x=False)
            body = Label(text=tb, font_size="12sp", color=(0.95, 0.96, 0.98, 1), halign="left", valign="top", size_hint_y=None, markup=False)
            body.bind(width=lambda w, v: setattr(w, "text_size", (v - 12, None)))
            body.bind(texture_size=lambda w, v: setattr(w, "height", v[1] + 12))
            with sv.canvas.before:                           # nền TỐI tự vẽ (không phụ thuộc ảnh nền mặc định của Kivy)
                Color(0.06, 0.07, 0.10, 1)
                bg = Rectangle(pos=sv.pos, size=sv.size)
            sv.bind(pos=lambda w, v: setattr(bg, "pos", v), size=lambda w, v: setattr(bg, "size", v))
            sv.add_widget(body)
            box.add_widget(sv)
            row = BoxLayout(size_hint_y=None, height=56, spacing=6)

            def send(*_):
                try:
                    from pyea import android_utils
                    if android_utils.share_text(tb, "PyEA - lỗi khởi động"):
                        return
                except Exception:                           # noqa: BLE001
                    pass
                Clipboard.copy(tb)
            row.add_widget(Button(text="Gửi / Sao chép lỗi", on_release=send))
            if can_continue:
                def go(*_):
                    state["go"] = True
                    self.stop()
                row.add_widget(Button(text="Mở app", on_release=go))
            else:
                row.add_widget(Button(text="Thoát", on_release=lambda *_: self.stop()))
            box.add_widget(row)
            return box
    Fallback().run()
    return state["go"]


def _run():
    prev = bootlog.previous_unfinished()                     # lần trước chết giữa chừng? (đọc TRƯỚC khi ghi mốc lần này)
    if prev:
        bootlog.mark_reported()
        try:
            _fallback(prev, "LẦN MỞ TRƯỚC APP BỊ DỪNG GIỮA CHỪNG - chụp/gửi nội dung dưới đây cho người phát triển.\nBấm «Mở app» để thử mở lại.", can_continue=True)
        except BaseException:                               # noqa: BLE001
            bootlog.crumb("màn hình báo lần trước lỗi: " + traceback.format_exc())
    bootlog.crumb("=== main.py bắt đầu (Python %s) ===" % sys.version.split()[0])
    bootlog.enable_faulthandler()
    bootlog.install_excepthook()
    try:
        from pyea import __version__
        bootlog.crumb("phiên bản app %s" % __version__)
        from pyea.ui import PyEAApp
        bootlog.crumb("import pyea.ui OK")
    except BaseException:                                   # noqa: BLE001
        tb = traceback.format_exc()
        bootlog.crumb("IMPORT LỖI\n" + tb)
        try:
            _fallback(tb)
        except BaseException:                               # noqa: BLE001
            bootlog.crumb("cả màn hình dự phòng cũng lỗi\n" + traceback.format_exc())
        return
    app = PyEAApp()
    # lỗi trong thread nền của UI: ghi nhật ký, không làm sập app
    threading.excepthook = lambda a: app.note_ui_error("".join(traceback.format_exception(a.exc_type, a.exc_value, a.exc_traceback)))
    try:
        bootlog.crumb("app.run()")
        app.run()
        bootlog.crumb("app.run() trả về (thoát bình thường)")
    except Exception:
        # sắp crash: ghi file + báo động (bot nền, nếu đang chạy, vẫn sống vì ở tiến trình riêng)
        tb = traceback.format_exc()
        bootlog.crumb("app.run() LỖI\n" + tb)
        app.report_fatal(tb)
        raise


if __name__ == "__main__":
    _run()
