"""Giới hạn LỖ TRONG NGÀY («daily loss limit», kỷ luật giống quỹ prop-firm): lỗ trong ngày chạm ngưỡng thì CHẶN lệnh mới tới hết ngày (tuỳ chọn: đóng hết vị thế luôn).
Thuần Python, không Kivy, không I/O - phiên (engine) gọi `update()` mỗi vòng và lưu `state` cùng sổ tài khoản.

Định nghĩa:
  - «ngày» tính theo múi giờ HIỂN THỊ của app (prefs: giờ máy / UTC / lệch giờ), dời `reset_hour` giờ (vd 5 → ngày mới bắt đầu 05:00; hợp với forex đóng nến ngày 5h sáng giờ VN).
  - lỗ trong ngày = equity hiện tại − equity ĐẦU NGÀY (gồm lãi/lỗ thả nổi). Equity đầu ngày được chụp ở lần cập nhật đầu tiên của ngày; nếu app khởi động giữa ngày mà không có
    ảnh chụp cũ thì ước lượng = số dư hiện tại − lãi/lỗ các lệnh ĐÃ ĐÓNG hôm nay (bỏ qua lãi/lỗ thả nổi đầu ngày).
  - ngưỡng = min(vốn_đầu_ngày × pct%, money) trong các số > 0.
  - CHỐT: đã chạm thì giữ chặn tới hết ngày dù equity hồi lại (đó là mục đích). Đổi ngưỡng cao hơn hoặc tắt giới hạn trong Cài đặt thì gỡ chặn nếu lỗ hiện tại chưa tới ngưỡng mới.
Ngưỡng tính theo SỔ của app (không phải số dư sàn báo): vị thế đặt tay/EA khác bên ngoài app không nằm trong đó."""
import time

ACTIONS = ("block", "close_block")


def day_key(ts, reset_hour=0.0, fmt=None):
    """'YYYY-MM-DD' của ngày chứa `ts` (epoch giây), dời `reset_hour` giờ. `fmt(strftime_fmt, ts)` mặc định = prefs.fmt_time (giờ hiển thị của app)."""
    if fmt is None:
        from . import prefs
        fmt = prefs.fmt_time
    return fmt("%Y-%m-%d", float(ts) - float(reset_hour or 0.0) * 3600.0)


def config(settings):
    """-> (pct, money, action, reset_hour), đã ép kiểu/giới hạn; (0, 0, ...) = tắt."""
    s = settings or {}

    def f(k, lo, hi):
        try:
            v = float(s.get(k) or 0.0)
        except (TypeError, ValueError):
            v = 0.0
        return min(hi, max(lo, v)) if v == v else 0.0
    action = str(s.get("daily_loss_action") or "block")
    return f("daily_loss_pct", 0.0, 100.0), f("daily_loss_money", 0.0, 1e15), action if action in ACTIONS else "block", f("daily_reset_hour", 0.0, 23.0)


def limit_amount(start_equity, pct, money):
    """Số tiền lỗ tối đa trong ngày (>0), hoặc 0 nếu không đặt giới hạn."""
    cands = []
    if pct > 0 and start_equity > 0:
        cands.append(start_equity * pct / 100.0)
    if money > 0:
        cands.append(money)
    return min(cands) if cands else 0.0


def realised_today(trades, key, reset_hour=0.0, fmt=None):
    """Tổng lãi/lỗ các lệnh đã đóng trong ngày `key`."""
    tot = 0.0
    for t in trades or ():
        ct = getattr(t, "close_time", None)
        if ct is None and isinstance(t, dict):
            ct = t.get("close_time")
        pr = getattr(t, "profit", None) if not isinstance(t, dict) else t.get("profit")
        try:
            if ct and day_key(ct, reset_hour, fmt) == key:
                tot += float(pr or 0.0)
        except (TypeError, ValueError):
            continue
    return tot


def update(state, now, equity, balance, trades, settings, fmt=None):
    """Cập nhật `state` (dict, sửa tại chỗ, JSON được) và trả về bản mô tả:
    {on, key, start_equity, pnl, limit, tripped, newly_tripped, action, message}.
    `newly_tripped` chỉ True ĐÚNG MỘT LẦN khi vừa chạm ngưỡng (để phiên báo + đóng lệnh một lần)."""
    pct, money, action, reset = config(settings)
    on = pct > 0 or money > 0
    key = day_key(now, reset, fmt)
    equity, balance = float(equity), float(balance)
    if state.get("key") != key:                                            # ngày mới (hoặc chưa có trạng thái): chụp equity đầu ngày
        est = balance - realised_today(trades, key, reset, fmt) if state.get("key") is None else equity
        state.clear()
        state.update(key=key, start_equity=est if est > 0 else equity, tripped=False, tripped_at=0.0, limit_at_trip=0.0, pnl_at_trip=0.0)
    start = float(state.get("start_equity") or equity)
    pnl = equity - start
    lim = limit_amount(start, pct, money) if on else 0.0
    newly = False
    if state.get("tripped"):
        if not on or (abs(lim - float(state.get("limit_at_trip") or 0.0)) > 1e-9 and pnl > -lim):
            state.update(tripped=False, tripped_at=0.0, limit_at_trip=0.0, pnl_at_trip=0.0)      # người dùng tắt/nới ngưỡng: gỡ chặn
    elif on and lim > 0 and pnl <= -lim + 1e-9:
        state.update(tripped=True, tripped_at=float(now), limit_at_trip=lim, pnl_at_trip=pnl)
        newly = True
    msg = ""
    if state.get("tripped"):
        msg = ("Đã lỗ %.2f trong ngày %s (ngưỡng %.2f%s): chặn lệnh MỚI tới hết ngày. Đóng lệnh/SL/TP vẫn chạy. Muốn tiếp tục: nới hoặc tắt «giới hạn lỗ trong ngày» ở Cài đặt." % (
            -pnl, key, state.get("limit_at_trip") or lim, " - đã/đang đóng hết vị thế" if action == "close_block" else ""))
    return {"on": on, "key": key, "start_equity": start, "pnl": pnl, "limit": lim, "tripped": bool(state.get("tripped")), "newly_tripped": newly,
            "action": action, "message": msg, "used_pct": (min(999.0, -pnl / lim * 100.0) if (lim > 0 and pnl < 0) else 0.0)}


def blocks_new_orders(state, settings):
    """True nếu lệnh MỚI phải bị chặn lúc này (đã chạm ngưỡng và giới hạn còn bật)."""
    pct, money, _a, _r = config(settings)
    return bool(state.get("tripped")) and (pct > 0 or money > 0)
