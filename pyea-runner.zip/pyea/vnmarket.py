"""Giờ giao dịch và lịch nghỉ lễ thị trường chứng khoán Việt Nam (HOSE, HNX, UPCoM, phái sinh VN30F). Thuần Python (chỉ thư viện chuẩn), giờ Việt Nam cố định UTC+7 (không có giờ mùa hè).

NGUỒN & ĐỘ TIN CẬY (nói thẳng, vì ngày nghỉ lễ do Chính phủ/sở giao dịch công bố từng năm và có thể đổi):
  - Giờ phiên (kiểm chéo FPTS, KIS, HSC): HOSE ATO 9:00-9:15, liên tục 9:15-11:30 và 13:00-14:30, nghỉ trưa 11:30-13:00, ATC 14:30-14:45, sau đó chỉ còn thỏa thuận tới 15:00;
    HNX liên tục 9:00-11:30 và 13:00-14:30, ATC 14:30-14:45; UPCoM liên tục 9:00-11:30 và 13:00-15:00; phái sinh VN30F ATO 8:45-9:00, liên tục 9:00-11:30 và 13:00-14:30, ATC 14:30-14:45.
    Giờ NHẬN lệnh trước giờ mở cửa và các biến thể (lệnh thỏa thuận, giờ giao dịch ngày đáo hạn phái sinh) CHƯA kiểm: app chỉ nói «đang khớp lệnh hay không».
  - Ngày nghỉ 2026 (đã đối chiếu thông báo HNX/HOSE; HNX dẫn công văn 1403/SGDVN-THHC ngày 28/11/2025 của Sở GDCK Việt Nam): 1/1; 16-20/2 (Tết Âm lịch, giao dịch lại 23/2); 27/4 (nghỉ bù Giỗ Tổ);
    30/4 và 1/5; 31/8, 1/9 và 2/9 (Quốc khánh; KHÔNG giao dịch bù thứ Bảy 22/8). Các thông báo đọc được là của HNX/HOSE riêng lẻ; HOSE/UPCoM/phái sinh theo cùng lịch chung của hệ thống sở.
  - NĂM KHÁC 2026: app KHÔNG có lịch (Tết và Giỗ Tổ theo âm lịch, ngày nghỉ bù do Chính phủ quyết từng năm) nên `calendar_known = False`; chỉ các ngày lễ CỐ ĐỊNH luật định (1/1, 30/4, 1/5, 2/9)
    được coi là nghỉ. Bổ sung ngày nghỉ từ thông báo của sở ở Cài đặt «Ngày nghỉ lễ thêm» (định dạng YYYY-MM-DD hoặc DD/MM/YYYY, cách nhau bằng dấu phẩy/khoảng trắng/xuống dòng)."""
import datetime
import re
import time

TZ_S = 7 * 3600
VENUES = ("hose", "hnx", "upcom", "deriv")
VENUE_NAMES = {"hose": "HOSE", "hnx": "HNX", "upcom": "UPCoM", "deriv": "Phái sinh VN30F"}
_DERIV_RE = re.compile(r"^(VN30F|VN100F|41I1|41I2|GB\d)", re.I)

# (mã phiên, nhãn, bắt đầu phút, kết thúc phút, loại): loại 'auction'/'continuous' = đang khớp lệnh; 'putthrough' = chỉ thỏa thuận; 'break' = nghỉ trưa
_H = lambda h, m: h * 60 + m                                   # noqa: E731
SESSIONS = {
    "hose": [("ato", "Khớp lệnh định kỳ mở cửa (ATO)", _H(9, 0), _H(9, 15), "auction"), ("continuous", "Khớp lệnh liên tục", _H(9, 15), _H(11, 30), "continuous"),
             ("lunch", "Nghỉ trưa", _H(11, 30), _H(13, 0), "break"), ("continuous", "Khớp lệnh liên tục", _H(13, 0), _H(14, 30), "continuous"),
             ("atc", "Khớp lệnh định kỳ đóng cửa (ATC)", _H(14, 30), _H(14, 45), "auction"), ("post_close", "Sau đóng cửa (chỉ thỏa thuận)", _H(14, 45), _H(15, 0), "putthrough")],
    "hnx": [("continuous", "Khớp lệnh liên tục", _H(9, 0), _H(11, 30), "continuous"), ("lunch", "Nghỉ trưa", _H(11, 30), _H(13, 0), "break"),
            ("continuous", "Khớp lệnh liên tục", _H(13, 0), _H(14, 30), "continuous"), ("atc", "Khớp lệnh định kỳ đóng cửa (ATC)", _H(14, 30), _H(14, 45), "auction"),
            ("post_close", "Sau đóng cửa (chỉ thỏa thuận)", _H(14, 45), _H(15, 0), "putthrough")],
    "upcom": [("continuous", "Khớp lệnh liên tục", _H(9, 0), _H(11, 30), "continuous"), ("lunch", "Nghỉ trưa", _H(11, 30), _H(13, 0), "break"),
              ("continuous", "Khớp lệnh liên tục", _H(13, 0), _H(15, 0), "continuous")],
    "deriv": [("ato", "Khớp lệnh định kỳ mở cửa (ATO)", _H(8, 45), _H(9, 0), "auction"), ("continuous", "Khớp lệnh liên tục", _H(9, 0), _H(11, 30), "continuous"),
              ("lunch", "Nghỉ trưa", _H(11, 30), _H(13, 0), "break"), ("continuous", "Khớp lệnh liên tục", _H(13, 0), _H(14, 30), "continuous"),
              ("atc", "Khớp lệnh định kỳ đóng cửa (ATC)", _H(14, 30), _H(14, 45), "auction")],
}

HOLIDAYS = {                                                    # chỉ gồm ngày thường (T2-T6) nghỉ; ngày cuối tuần luôn nghỉ
    "2026-01-01": "Tết Dương lịch",
    "2026-02-16": "Tết Âm lịch", "2026-02-17": "Tết Âm lịch", "2026-02-18": "Tết Âm lịch", "2026-02-19": "Tết Âm lịch", "2026-02-20": "Tết Âm lịch",
    "2026-04-27": "Giỗ Tổ Hùng Vương (nghỉ bù)", "2026-04-30": "Ngày Giải phóng miền Nam", "2026-05-01": "Quốc tế Lao động",
    "2026-08-31": "Nghỉ lễ Quốc khánh", "2026-09-01": "Nghỉ lễ Quốc khánh", "2026-09-02": "Quốc khánh",
}
KNOWN_YEARS = frozenset({2026})
_FEED = {"holidays": {}, "years": frozenset(), "loaded_at": 0.0, "source": ""}      # lịch tải từ mạng (vncal.py); thay nguyên khối, không sửa tại chỗ -> an toàn giữa các luồng


def set_feed(holidays=None, years=(), loaded_at=0.0, source=""):
    """vncal gọi khi nạp được lịch mới (hoặc None để bỏ). Ưu tiên: ngày người dùng thêm > lịch tải từ mạng > lịch có sẵn trong app."""
    global _FEED
    _FEED = {"holidays": dict(holidays or {}), "years": frozenset(years or ()), "loaded_at": float(loaded_at or 0.0), "source": str(source or "")}


def calendar_info():
    """Lịch đang dùng: {years (đã biết đủ), feed_loaded_at, feed_source, builtin_years}."""
    f = _FEED
    return {"years": sorted(KNOWN_YEARS | f["years"]), "builtin_years": sorted(KNOWN_YEARS), "feed_loaded_at": f["loaded_at"], "feed_source": f["source"]}
FIXED = {(1, 1): "Tết Dương lịch", (4, 30): "Ngày Giải phóng miền Nam", (5, 1): "Quốc tế Lao động", (9, 2): "Quốc khánh"}
WEEKDAYS = ("Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật")


def venue_for(symbol, default="hose"):
    """'deriv' cho mã phái sinh (VN30F…), còn lại `default` (không có bảng niêm yết nên không phân biệt HOSE/HNX/UPCoM từ tên mã: giờ khớp của ba sàn này chỉ khác nhau ở 14:45-15:00)."""
    return "deriv" if _DERIV_RE.match(str(symbol or "")) else (default if default in VENUES else "hose")


_DATE_RES = ((re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$"), (0, 1, 2)), (re.compile(r"^(\d{1,2})[/.](\d{1,2})[/.](\d{4})$"), (2, 1, 0)))


def parse_extra(text):
    """-> (dict 'YYYY-MM-DD' -> lý do, danh sách ô không hiểu). Bỏ qua ngày không có thật (30/2); không ném lỗi."""
    out, bad = {}, []
    for tok in re.split(r"[\s,;]+", str(text or "").strip()):
        if not tok:
            continue
        for rx, (iy, im, idd) in _DATE_RES:
            m = rx.match(tok)
            if m:
                try:
                    d = datetime.date(int(m.group(iy + 1)), int(m.group(im + 1)), int(m.group(idd + 1)))
                    out[d.isoformat()] = "ngày nghỉ bạn thêm"
                except ValueError:
                    bad.append(tok)
                break
        else:
            bad.append(tok)
    return out, bad


def holiday_of(d, extra=None):
    """(lý do nghỉ hoặc '', lịch năm đó đã biết đầy đủ?). `extra` = dict từ parse_extra hoặc chuỗi."""
    ex = extra if isinstance(extra, dict) else parse_extra(extra)[0]
    key = d.isoformat()
    if key in ex:
        return ex[key], True
    f = _FEED
    if key in f["holidays"]:
        return f["holidays"][key], True
    if key in HOLIDAYS:
        return HOLIDAYS[key], True
    if d.year in KNOWN_YEARS or d.year in f["years"]:
        return "", True
    if (d.month, d.day) in FIXED:
        return FIXED[(d.month, d.day)] + " (lễ cố định)", False
    return "", False


def is_trading_day(d, extra=None):
    return d.weekday() < 5 and not holiday_of(d, extra)[0]


def _local(ts):
    return datetime.datetime(1970, 1, 1) + datetime.timedelta(seconds=float(ts) + TZ_S)


def _ts_of(day, minute):
    """epoch giây của (ngày giờ VN, phút trong ngày)."""
    return (datetime.datetime(day.year, day.month, day.day) - datetime.datetime(1970, 1, 1)).total_seconds() - TZ_S + minute * 60


def next_open(ts, venue="hose", extra=None):
    """epoch giây của lần thị trường BẮT ĐẦU khớp lệnh kế tiếp (đầu mỗi khối khớp lệnh liền nhau: sáng, và chiều sau nghỉ trưa), hoặc None nếu 20 ngày tới không có ngày giao dịch."""
    ex = extra if isinstance(extra, dict) else parse_extra(extra)[0]
    ss = SESSIONS[venue]
    starts = [a for i, (_c, _n, a, _b, kind) in enumerate(ss) if kind in ("auction", "continuous") and (i == 0 or ss[i - 1][4] not in ("auction", "continuous"))]
    day = _local(ts).date()
    for _ in range(21):
        if is_trading_day(day, ex):
            for a in starts:
                t = _ts_of(day, a)
                if t > ts + 1e-6:
                    return t
        day += datetime.timedelta(days=1)
    return None


def state(ts=None, venue="hose", extra=None):
    """Trạng thái thị trường lúc `ts` (epoch giây, mặc định bây giờ).
    -> dict: venue, local ('YYYY-MM-DD HH:MM'), weekday, phase (weekend|holiday|pre_open|ato|continuous|lunch|atc|post_close|closed), label, trading (đang khớp lệnh: ATO/liên tục/ATC),
    continuous (đang khớp liên tục: nơi lệnh thị trường hợp lệ), holiday (lý do nghỉ hoặc ''), calendar_known (lịch nghỉ năm đó đầy đủ?), next_open_ts, next_open_local, note."""
    if venue not in VENUES:
        raise ValueError("venue phải là một trong %s" % (VENUES,))
    ts = time.time() if ts is None else float(ts)
    lt = _local(ts)
    ex = parse_extra(extra)[0] if not isinstance(extra, dict) else extra
    reason, known = holiday_of(lt.date(), ex)
    phase, label, trading, cont = "closed", "Đã đóng cửa", False, False
    if lt.weekday() >= 5:
        phase, label = "weekend", "Cuối tuần - nghỉ"
    elif reason:
        phase, label = "holiday", "Nghỉ lễ: %s" % reason
    else:
        minute = lt.hour * 60 + lt.minute
        ss = SESSIONS[venue]
        if minute < ss[0][2]:
            phase, label = "pre_open", "Chưa mở cửa"
        else:
            for code, nm, a, b, kind in ss:
                if a <= minute < b:
                    phase, label, trading, cont = code, nm, kind in ("auction", "continuous"), kind == "continuous"
                    break
    nxt = None if trading else next_open(ts, venue, ex)
    note = ""
    if not known and phase not in ("weekend", "holiday"):
        note = "Chưa có lịch nghỉ lễ năm %d trong app: nếu hôm nay là ngày nghỉ của sở thì kết quả này sai - thêm ngày nghỉ ở Cài đặt." % lt.year
    return {"venue": venue, "local": lt.strftime("%Y-%m-%d %H:%M"), "weekday": lt.weekday(), "phase": phase, "label": label, "trading": trading, "continuous": cont,
            "holiday": reason, "calendar_known": known, "next_open_ts": nxt, "next_open_local": _local(nxt).strftime("%Y-%m-%d %H:%M") if nxt else "", "note": note}


def describe(st):
    """Một câu tiếng Việt cho nhật ký/giao diện."""
    s = "%s: %s (%s %s giờ VN)" % (VENUE_NAMES.get(st["venue"], st["venue"]), st["label"], WEEKDAYS[st["weekday"]], st["local"][11:])
    if not st["trading"] and st.get("next_open_local"):
        s += "; mở lại %s" % st["next_open_local"]
    return s + ((" · " + st["note"]) if st.get("note") else "")


def guard_message(st, order_kind, symbol=""):
    """Lý do CHẶN lệnh MỚI theo `st`, hoặc '' nếu cho qua.
    Chặn: (1) ngày nghỉ (cuối tuần/lễ) với mọi lệnh; (2) lệnh THỊ TRƯỜNG ('market') khi chưa ở phiên khớp liên tục (ATO/ATC/nghỉ trưa/ngoài giờ không có sổ để khớp).
    KHÔNG chặn lệnh giới hạn ('limit') ngoài giờ trong ngày giao dịch: nhiều công ty chứng khoán nhận lệnh chờ trước giờ mở (chưa kiểm với DNSE) - sàn sẽ tự từ chối nếu không nhận."""
    if st["phase"] in ("weekend", "holiday"):
        return "%s đóng cửa (%s) - %s. Lệnh MỚI bị chặn bởi «Chặn lệnh ngoài giờ giao dịch»; tắt ở Cài đặt nếu muốn vẫn gửi%s" % (
            VENUE_NAMES.get(st["venue"], st["venue"]), st["label"].replace("Nghỉ lễ: ", ""), describe(st), (" [%s]" % symbol) if symbol else "")
    if order_kind == "market" and not st["continuous"]:
        return "Lệnh thị trường chỉ hợp lệ khi đang khớp liên tục, nhưng %s. Dùng lệnh giới hạn (LO) hoặc đợi tới phiên liên tục; tắt «Chặn lệnh ngoài giờ giao dịch» ở Cài đặt để vẫn gửi%s" % (
            describe(st), (" [%s]" % symbol) if symbol else "")
    return ""


def quiet_symbols(symbols, now=None, extra=None, grace=120.0):
    """Tập mã mà «giá đứng» là BÌNH THƯỜNG lúc `now`: thị trường đóng (cuối tuần, nghỉ lễ, nghỉ trưa, trước/sau giờ) hoặc MỚI mở lại chưa quá `grace` giây
    (tick đầu của mã ít thanh khoản có thể tới chậm). Dùng để KHÔNG báo «mất kết nối giá» oan. Chỉ nói về lịch: mất kết nối KHÔNG suy ra được ngày nghỉ (mạng rớt, sàn bảo trì,
    token hết hạn trông giống hệt), nên hàm này chỉ trả lời «giá đứng có chấp nhận được không», không bao giờ ngược lại.
    Năm chưa có lịch nghỉ lễ: ngày thường trong giờ giao dịch vẫn tính là ĐANG GIAO DỊCH (không đoán là nghỉ) -> vẫn báo mất giá như thường."""
    now = time.time() if now is None else float(now)
    ex = parse_extra(extra)[0] if not isinstance(extra, dict) else extra
    verdict, out = {}, set()
    for sym in symbols or ():
        v = venue_for(sym)
        if v not in verdict:
            try:
                verdict[v] = (not state(now, v, ex)["trading"]) or (not state(now - float(grace), v, ex)["trading"])
            except Exception:                                      # noqa: BLE001 - lỗi lịch không được che mất cảnh báo thật
                verdict[v] = False
        if verdict[v]:
            out.add(sym)
    return out
