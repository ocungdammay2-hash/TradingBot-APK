"""
TRẠNG THÁI TÀI KHOẢN DO SÀN BÁO (giống khung «Giao dịch» của MT5: Số dư · Tài sản · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ).

Số liệu cùng tên trong sổ riêng của app (engine.Account) là số TỰ TÍNH (lãi/lỗ = Δgiá × khối lượng, ký quỹ = Σ khối lượng × giá / đòn bẩy; không có contract
size, quy đổi tiền tệ, quy tắc ký quỹ riêng từng mã) nên với sàn kiểu MT chúng KHÔNG khớp số của sàn. Hợp đồng chung để lấy số của sàn:

    broker.account_state() -> dict   (tuỳ chọn; vỏ gọi ở luồng poll, mỗi `account_state_interval` giây)

Broker trả dict theo tên gốc của sàn; `normalize()` quy về MỘT dạng (bí danh tên trường bên dưới - không viết riêng cho sàn nào):
    balance · equity · margin · free_margin · margin_level (%) · profit (lãi/lỗ thả nổi) · credit · leverage · currency
Trường sàn không báo thì để None (không bịa); margin_level/free_margin/profit chỉ được TÍNH từ các trường đã có theo định nghĩa của MT5:
    margin_level = equity / margin × 100 (None khi chưa có ký quỹ) · free_margin = equity - margin · profit = equity - balance - credit
"""
import math

ALIASES = {
    "balance": ("balance",),
    "equity": ("equity", "nav", "NAV"),
    "margin": ("margin", "used_margin", "usedMargin", "margin_used", "marginUsed"),
    "free_margin": ("free_margin", "freeMargin", "margin_free", "marginFree", "margin_available", "marginAvailable"),
    "margin_level": ("margin_level", "marginLevel", "margin_level_pct"),
    "profit": ("profit", "floating", "unrealized_pnl", "unrealizedPL"),
    "credit": ("credit",),
    "leverage": ("leverage",),
    "currency": ("currency", "accountCurrency"),
}
NUMERIC = tuple(k for k in ALIASES if k != "currency")


def _num(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _pick(d, names):
    for n in names:
        if n in d and d[n] not in (None, ""):
            return d[n]
    return None


def normalize(raw):
    """dict thô của sàn -> {balance, equity, margin, free_margin, margin_level, profit, credit, leverage, currency} (None = sàn không báo).
    Trả None nếu không có cả số dư lẫn tài sản (dữ liệu vô dụng)."""
    if not isinstance(raw, dict):
        return None
    out = {k: _num(_pick(raw, ALIASES[k])) for k in NUMERIC}
    out["currency"] = str(_pick(raw, ALIASES["currency"]) or "")
    if out["balance"] is None and out["equity"] is None:
        return None
    eq, mg = out["equity"], out["margin"]
    if out["free_margin"] is None and eq is not None and mg is not None:
        out["free_margin"] = eq - mg
    if out["margin_level"] is None and eq is not None and mg is not None and mg > 1e-12:
        out["margin_level"] = eq / mg * 100.0
    if out["profit"] is None and eq is not None and out["balance"] is not None:
        out["profit"] = eq - out["balance"] - (out["credit"] or 0.0)
    return out


# ---------------------------------------------------------------------------------------------- lãi/lỗ TỪNG VỊ THẾ do sàn báo
POS_ALIASES = {
    "profit": ("profit", "unrealizedProfit", "unrealized_profit", "unrealized_pnl", "unrealizedPL", "floating_profit", "pnl"),
    "swap": ("swap", "unrealizedSwap", "swaps"),
    "commission": ("commission", "unrealizedCommission"),
    "price": ("price_now", "currentPrice", "current_price", "price_current", "mark_price"),
}


def normalize_position_stats(rows):
    """Danh sách vị thế (mỗi dòng có `id`/`ref` + các trường lãi/lỗ của sàn) -> {ticket: {profit, swap, commission, price}}.
    `profit` = lãi/lỗ của phần đang mở KHÔNG gồm swap/hoa hồng (đúng cột «Lợi nhuận» của MT5); swap/hoa hồng riêng. Trường nào sàn không báo thì VẮNG mặt
    (không bịa 0); vị thế không có trường nào thì bỏ qua."""
    out = {}
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        ref = str(r.get("ref") or r.get("id") or "")
        if not ref:
            continue
        st = {}
        for k, names in POS_ALIASES.items():
            v = _num(_pick(r, names))
            if v is not None:
                st[k] = v
        if st:
            out[ref] = st
    return out
