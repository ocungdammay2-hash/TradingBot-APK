"""MÁY CHỦ WEBHOOK TRADINGVIEW CHẠY NGAY TRONG APP (stdlib, không Kivy). Dùng `WebhookCore` (pyea/webhook.py) để kiểm tra + đổi tín hiệu thành lệnh của phiên.

SỰ THẬT CẦN BIẾT TRƯỚC KHI BẬT (đọc docs/WEBHOOK.md):
  * Điện thoại KHÔNG có địa chỉ công khai. TradingView chỉ gọi được cổng 80/443 của một địa chỉ công khai -> cần ĐƯỜNG HẦM (cloudflared/ngrok/…) trỏ về cổng của app.
  * Máy chủ này nói HTTP thường. Secret nằm trong nội dung JSON (TradingView không ký HMAC được) nên PHẢI đi qua đường hầm HTTPS; đừng mở thẳng ra Internet.
  * Mặc định: TẮT, nghe 127.0.0.1, chế độ chỉ-kiểm-tra (dry-run), «close» chỉ đóng vị thế do webhook mở, LIVE bắt buộc có khối lượng tối đa.

Phòng thủ (mỗi lớp có test): chỉ nhận POST đúng đường dẫn · bắt buộc Content-Length ≤ 4096 TRƯỚC khi đọc thân · không nhận Transfer-Encoding · hạn chót TỔNG cho mỗi kết nối
(chống «slowloris» nhỏ giọt từng byte) · trần số kết nối đồng thời · khoá tạm IP đoán sai secret (chỉ khi phân biệt được IP thật, xem `lockout_active`) ·
cảnh báo khi dồn dập sai secret · không bao giờ ghi nội dung thân/secret vào nhật ký · executor chạy luồng riêng (TradingView chờ tối đa 3 giây)."""
import http.server
import ipaddress
import json
import socket
import socketserver
import threading
import time

from .webhook import TV_IPS, WebhookCore, session_executor

PATH = "/v1/webhook/tradingview"
MAX_BODY = 4096
MIN_SECRET = 16
LOCK_CODES = ("BAD_SECRET", "BAD_SIGNATURE", "IP_DENIED")      # chỉ lỗi xác thực mới tính vào khoá IP (JSON sai/mã bị từ chối là lỗi cấu hình alert, không phải dò mật khẩu)
_LOOPBACK = ("127.0.0.1", "localhost", "::1")


def split_list(text):
    return [x.strip() for x in str(text or "").replace(";", ",").replace("\n", ",").split(",") if x.strip()]


def parse_map(text):
    """'BINANCE:BTCUSDT=BTCUSD, XAUUSD=GOLD' -> {'BINANCE:BTCUSDT': 'BTCUSD', 'XAUUSD': 'GOLD'}; bỏ mục không có dấu '='."""
    out = {}
    for it in split_list(text):
        if "=" in it:
            a, b = it.split("=", 1)
            if a.strip() and b.strip():
                out[a.strip()] = b.strip()
    return out


def parse_ips(text):
    """Danh sách IP cho phép; mục «tradingview» = 4 IP chính thức. Trả (list, danh sách mục KHÔNG phải IP hợp lệ)."""
    out, bad = [], []
    for it in split_list(text):
        if it.lower() == "tradingview":
            out += [ip for ip in TV_IPS if ip not in out]
            continue
        try:
            ip = str(ipaddress.ip_address(it))
        except ValueError:
            bad.append(it)
            continue
        if ip not in out:
            out.append(ip)
    return out, bad


class Lockout:
    """Khoá tạm một IP sau `limit` lần sai xác thực trong `window` giây. Giới hạn bộ nhớ (≤ max_ips địa chỉ theo dõi) để kẻ giả IP không làm phình RAM."""

    def __init__(self, limit=8, window=300.0, lock_s=600.0, clock=time.time, max_ips=512):
        self.limit, self.window, self.lock_s, self.clock, self.max_ips = int(limit), float(window), float(lock_s), clock, int(max_ips)
        self._fails, self._until, self._mu = {}, {}, threading.Lock()

    def blocked(self, ip):
        """Số giây còn bị khoá (0 = không khoá)."""
        now = self.clock()
        with self._mu:
            u = self._until.get(ip)
            if u is None:
                return 0.0
            if u <= now:
                del self._until[ip]
                return 0.0
            return u - now

    def fail(self, ip):
        """Ghi một lần sai. Trả True nếu LẦN NÀY vừa kích hoạt khoá."""
        now = self.clock()
        with self._mu:
            if ip in self._until and self._until[ip] > now:
                return False
            lst = [t for t in self._fails.get(ip, ()) if now - t < self.window]
            lst.append(now)
            if len(lst) >= self.limit:
                self._fails.pop(ip, None)
                self._until[ip] = now + self.lock_s
                self._trim(now)
                return True
            self._fails[ip] = lst
            if len(self._fails) > self.max_ips:
                self._trim(now)
            return False

    def _trim(self, now):
        for k in [k for k, v in self._until.items() if v <= now]:
            del self._until[k]
        if len(self._fails) > self.max_ips:
            for k in sorted(self._fails, key=lambda k: self._fails[k][-1])[:len(self._fails) - self.max_ips]:
                del self._fails[k]
        if len(self._until) > self.max_ips:
            for k in sorted(self._until, key=self._until.get)[:len(self._until) - self.max_ips]:
                del self._until[k]

    def count(self):
        with self._mu:
            return len(self._until)


class _Srv(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16

    def __init__(self, addr, handler, owner):
        self.owner = owner
        self._sem = threading.BoundedSemaphore(max(1, owner.max_conns))
        http.server.HTTPServer.__init__(self, addr, handler)

    def process_request(self, request, client_address):
        if not self._sem.acquire(blocking=False):                # quá trần kết nối đồng thời: đóng ngay, không tạo luồng
            self.owner._count("busy")
            try:
                request.settimeout(1.0)
                request.sendall(b"HTTP/1.0 503 Service Unavailable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        socketserver.ThreadingMixIn.process_request(self, request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            socketserver.ThreadingMixIn.process_request_thread(self, request, client_address)
        finally:
            self._sem.release()

    def handle_error(self, request, client_address):             # mặc định in traceback ra stderr: im lặng (có thể chứa dữ liệu yêu cầu)
        pass


class WebhookServer:
    def __init__(self, core, host="127.0.0.1", port=8787, path=PATH, trust_proxy=False, max_conns=8, timeout=5.0, total_timeout=8.0,
                 lockout=None, attack_threshold=20, log=None, alarm=None, clock=time.time):
        self.core, self.host, self.port, self.path = core, str(host), int(port), path
        self.trust_proxy, self.max_conns, self.timeout, self.total_timeout = bool(trust_proxy), int(max_conns), float(timeout), float(total_timeout)
        self.log, self.alarm, self.clock = log or (lambda *a: None), alarm or (lambda *a: None), clock
        # Khoá IP chỉ có nghĩa khi phân biệt được người gọi. Nghe 127.0.0.1 mà không tin X-Forwarded-For thì mọi yêu cầu qua đường hầm đều có IP 127.0.0.1:
        # khoá "IP đó" = khoá luôn TradingView hợp lệ (kẻ xấu cố tình gửi sai để chặn tín hiệu thật). Khi đó chỉ CẢNH BÁO, không khoá.
        self.lockout_active = self.trust_proxy or self.host not in _LOOPBACK
        self.lockout = lockout or Lockout(clock=clock)
        self.attack_threshold = int(attack_threshold)
        self._srv, self._thread, self._mu = None, None, threading.Lock()
        self._stats = {"requests": 0, "ok": 0, "rejected": 0, "locked": 0, "busy": 0, "auth_fail": 0}
        self._last = {}
        self._auth_times, self._attack_alarm_t = [], 0.0

    # ---- vòng đời ----
    def start(self):
        """Mở cổng. Trả cổng thực (port=0 -> hệ điều hành chọn). Ném OSError nếu cổng bận/không được phép."""
        if self._srv is not None:
            return self.port
        outer = self

        class H(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"
            server_version = "PyEA"
            sys_version = ""
            timeout = outer.timeout

            def setup(self):
                http.server.BaseHTTPRequestHandler.setup(self)
                self._wd = threading.Timer(outer.total_timeout, self._kill)   # hạn chót TỔNG của kết nối (kể cả giai đoạn đọc tiêu đề)
                self._wd.daemon = True
                self._wd.start()

            def finish(self):
                try:
                    self._wd.cancel()
                finally:
                    http.server.BaseHTTPRequestHandler.finish(self)

            def _kill(self):
                try:
                    self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            def log_message(self, *a):                                       # không ghi mặc định (đường dẫn/tiêu đề)
                pass

            def log_error(self, *a):
                pass

            def _send(self, status, obj):
                body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.wfile.write(body)
                except OSError:
                    pass

            def _other(self):
                self._send(405, {"ok": False, "error": "chỉ nhận POST", "code": "METHOD"})

            do_GET = do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = _other

            def do_POST(self):
                outer._post(self)

        self._srv = _Srv((self.host, self.port), H, self)
        self.port = self._srv.server_address[1]
        self._thread = threading.Thread(target=self._srv.serve_forever, kwargs={"poll_interval": 0.3}, name="pyea-webhook", daemon=True)
        self._thread.start()
        return self.port

    def stop(self):
        srv, th = self._srv, self._thread
        self._srv = self._thread = None
        if srv is not None:
            try:
                srv.shutdown()
            finally:
                srv.server_close()
        if th is not None:
            th.join(2.0)

    @property
    def running(self):
        return self._srv is not None

    def stats(self):
        with self._mu:
            d = dict(self._stats)
            d["last"] = dict(self._last)
        d.update(running=self.running, host=self.host, port=self.port, path=self.path, locked_ips=self.lockout.count(), lockout_active=self.lockout_active)
        return d

    def _count(self, k, n=1):
        with self._mu:
            self._stats[k] = self._stats.get(k, 0) + n

    # ---- xử lý một yêu cầu ----
    def client_ip(self, h):
        sock_ip = h.client_address[0]
        if not self.trust_proxy:
            return sock_ip
        parts = [p.strip() for p in str(h.headers.get("X-Forwarded-For", "")).split(",") if p.strip()]
        if not parts:
            return sock_ip
        cand = parts[-1]                                           # mục CUỐI do proxy gần nhất (của chính bạn) thêm vào: client không giả được
        for c in (cand, cand.rsplit(":", 1)[0] if cand.count(":") == 1 else ""):
            try:
                return str(ipaddress.ip_address(c.strip("[]")))
            except ValueError:
                continue
        return sock_ip

    def _post(self, h):
        self._count("requests")
        ip = self.client_ip(h)
        if self.lockout_active:
            wait = self.lockout.blocked(ip)
            if wait > 0:
                self._count("locked")
                self._note(429, "LOCKED", ip)
                return h._send(429, {"ok": False, "error": "tạm khoá do sai xác thực nhiều lần; thử lại sau %d giây" % int(wait + 1), "code": "LOCKED"})
        if h.path.split("?", 1)[0] != self.path:
            self._note(404, "NOT_FOUND", ip)
            return h._send(404, {"ok": False, "error": "không có đường dẫn này", "code": "NOT_FOUND"})
        if h.headers.get("Transfer-Encoding"):
            self._note(411, "LENGTH_REQUIRED", ip)
            return h._send(411, {"ok": False, "error": "cần Content-Length (không nhận Transfer-Encoding)", "code": "LENGTH_REQUIRED"})
        cl = h.headers.get("Content-Length")
        try:
            n = int(str(cl).strip())
        except (TypeError, ValueError):
            n = -1
        if cl is None:
            self._note(411, "LENGTH_REQUIRED", ip)
            return h._send(411, {"ok": False, "error": "cần Content-Length", "code": "LENGTH_REQUIRED"})
        if n <= 0:
            self._note(400, "BAD_REQUEST", ip)
            return h._send(400, {"ok": False, "error": "Content-Length không hợp lệ", "code": "BAD_REQUEST"})
        if n > MAX_BODY:
            self._note(413, "TOO_LARGE", ip)
            return h._send(413, {"ok": False, "error": "nội dung quá lớn (tối đa %d byte)" % MAX_BODY, "code": "TOO_LARGE"})
        raw = self._read(h, n)
        if raw is None:
            self._note(408, "TIMEOUT", ip)
            return h._send(408, {"ok": False, "error": "đọc nội dung quá chậm/thiếu", "code": "TIMEOUT"})
        status, res = self.core.handle(raw, ip, h.headers.get("X-PyEA-Signature", ""))
        code = str(res.get("code") or ("OK" if status == 200 else ""))
        if code in LOCK_CODES:
            self._auth_failed(ip)
        self._count("ok" if status == 200 and res.get("ok") else "rejected")
        self._note(status, code, ip, res)
        h._send(status, res)

    def _read(self, h, n):
        """Đọc đúng n byte; None nếu hết hạn/đứt giữa chừng. Không đọc quá n."""
        buf, end = b"", time.monotonic() + self.total_timeout
        while len(buf) < n:
            left = end - time.monotonic()
            if left <= 0:
                return None
            try:
                h.connection.settimeout(left)
                chunk = h.rfile.read1(n - len(buf))
            except (OSError, ValueError):
                return None
            if not chunk:
                return None
            buf += chunk
        return buf

    def _note(self, status, code, ip, res=None):
        with self._mu:
            self._last = {"t": self.clock(), "status": status, "code": code, "ip": ip}
            if res and res.get("order"):
                o = res["order"]
                self._last["summary"] = "%s %s%s" % (o.get("action"), o.get("symbol", ""), (" x%s" % o["volume"]) if o.get("volume") else "")
        if status == 200 and res and res.get("order"):
            tag = " (CHỈ KIỂM TRA - không đặt lệnh)" if res.get("dry_run") else (" (trùng id - bỏ qua)" if res.get("duplicate") else "")
            o = res["order"]
            self.log("Webhook nhận: %s %s%s%s" % (o.get("action"), o.get("symbol", ""), (" x%s" % o["volume"]) if o.get("volume") else "", tag))

    def _auth_failed(self, ip):
        self._count("auth_fail")
        if self.lockout_active and self.lockout.fail(ip):
            self.log("Webhook: KHOÁ %s %d giây vì sai xác thực %d lần" % (ip, int(self.lockout.lock_s), self.lockout.limit))
        now = self.clock()
        with self._mu:
            self._auth_times = [t for t in self._auth_times if now - t < 300.0] + [now]
            storm = len(self._auth_times) >= self.attack_threshold and now - self._attack_alarm_t > 1800.0
            if storm:
                self._attack_alarm_t = now
                n = len(self._auth_times)
        if storm:
            self.log("Webhook: %d lần sai xác thực trong 5 phút" % n, "WARN")
            try:
                self.alarm("Webhook bị dò secret?", "%d lần sai secret trong 5 phút. Nếu không phải bạn: ĐỔI webhook secret ngay (Cài đặt) và cập nhật alert TradingView; cân nhắc tắt webhook." % n)
            except Exception:                                      # noqa: BLE001 - báo động lỗi không được làm sập luồng phục vụ
                pass


def build(session, clock=time.time):
    """Tạo máy chủ từ settings của phiên. -> (WebhookServer | None, thông báo). None + thông báo khi cấu hình chưa an toàn/đủ (KHÔNG ném lỗi)."""
    st = session.settings
    secret = str(st.get("webhook_secret") or "")
    if len(secret) < MIN_SECRET:
        return None, "Webhook KHÔNG bật: secret phải ≥ %d ký tự (hiện %d)." % (MIN_SECRET, len(secret))
    dry = bool(st.get("webhook_dry_run"))
    try:
        maxv = float(st.get("webhook_max_volume") or 0.0)
    except (TypeError, ValueError):
        maxv = 0.0
    if st.get("mode") == "live" and not dry and not (maxv > 0):
        return None, "Webhook KHÔNG bật: chế độ LIVE phải đặt «Khối lượng tối đa mỗi lệnh» > 0 (phòng lộ secret/gõ nhầm số lượng), hoặc bật «chỉ kiểm tra»."
    ips, bad = parse_ips(st.get("webhook_ips"))
    if bad:
        return None, "Webhook KHÔNG bật: IP nguồn không hợp lệ: %s." % ", ".join(bad[:4])
    host = str(st.get("webhook_bind") or "127.0.0.1")
    trust = bool(st.get("webhook_trust_proxy"))
    if trust and host not in _LOOPBACK:
        return None, "Webhook KHÔNG bật: «Tin X-Forwarded-For» chỉ dùng khi nghe 127.0.0.1 sau đường hầm của bạn (nghe 0.0.0.0 thì ai cũng giả được tiêu đề này)."
    owner = "webhook"
    inner = session_executor(session, owner, str(st.get("webhook_close_scope") or "own"))

    def run(o):
        r = inner(o)
        session.log("Webhook %s %s%s → %s" % (o["action"], o.get("symbol") or "(tất cả)", (" x%s" % o["volume"]) if o.get("volume") else "", r))
        return r
    try:
        core = WebhookCore(run, secret, allowed_ips=ips or None, allowed_symbols=split_list(st.get("webhook_symbols")) or None, max_volume=maxv if maxv > 0 else None,
                           rate_per_min=30, dry_run=dry, async_exec=True, log=session.log, clock=clock,
                           symbol_map=parse_map(st.get("webhook_symbol_map")), symbol_suffix=str(st.get("webhook_symbol_suffix") or ""))
        srv = WebhookServer(core, host, int(st.get("webhook_port") or 8787), trust_proxy=trust, log=session.log,
                            alarm=lambda t, x: session.alarm(t, x, critical=True), clock=clock)
    except (ValueError, TypeError) as e:
        return None, "Webhook KHÔNG bật: %s" % e
    return srv, ""


__all__ = ["WebhookServer", "Lockout", "build", "parse_map", "parse_ips", "split_list", "PATH", "MAX_BODY", "MIN_SECRET"]
