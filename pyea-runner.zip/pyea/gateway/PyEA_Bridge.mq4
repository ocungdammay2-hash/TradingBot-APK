//+------------------------------------------------------------------+
//| PyEA_Bridge.mq4 - cầu nối MT4 <-> PyEA MT Gateway (qua WebRequest)|
//|                                                                  |
//| TRẠNG THÁI: viết theo tài liệu MQL4 và đúng giao thức đã được     |
//| kiểm thử phía server (gateway/mt_gateway.py, backend 'ea').       |
//| CHƯA được biên dịch/chạy trên MetaEditor thật trong môi trường    |
//| phát triển (không có MT4). Hãy biên dịch, thử trên TÀI KHOẢN DEMO.|
//|                                                                  |
//| Khác MT5: không có lệnh stop-limit; không có "deal" nên lịch sử   |
//| được suy ra từ lệnh đã đóng (mỗi lệnh = 1 deal mở + 1 deal đóng); |
//| đóng một phần tạo ticket mới cho phần còn lại (app tự đọc lại).   |
//| Cách dùng giống PyEA_Bridge.mq5 (Allow WebRequest + AutoTrading). |
//| Thêm so với bản đầu: POS có comment; DEAL có position_id|entry|   |
//| reason (reason chỉ suy ra từ comment "[sl]"/"[tp]"/"so:" của lệnh |
//| đã đóng - MT4 không có thuộc tính reason); lệnh mới sltp/posdeals.|
//+------------------------------------------------------------------+
#property copyright "PyEA Runner"
#property version   "1.00"
#property strict

extern string GatewayURL = "http://127.0.0.1:8765";
extern string Token      = "";
extern int    PollMs     = 250;
extern int    Slippage   = 20;
extern int    MagicNo    = 7001;
extern int    DealDays   = 7;

string   g_watch[];
string   g_results = "";
string   g_lastSent = "";
datetime g_lastSyms = 0;
bool     g_busy = false;

int OnInit()
  {
   EventSetMillisecondTimer(MathMax(100, PollMs));
   Print("PyEA_Bridge (MT4): bắt đầu, gateway=", GatewayURL);
   return(INIT_SUCCEEDED);
  }
void OnDeinit(const int reason) { EventKillTimer(); }
void OnTimer() { if(!g_busy) { g_busy = true; Poll(); g_busy = false; } }

int    OffsetSec() { return (int)(TimeCurrent() - TimeGMT()); }
double Utc(datetime t) { return (double)(t - OffsetSec()); }
string D(double v, int digits = 8) { return DoubleToString(v, digits); }
string Clean(string s) { StringReplace(s, "|", "/"); StringReplace(s, "\n", " "); return s; }
void   AddResult(string line) { g_results += line + "\n"; }
bool   Watched(string sym) { for(int i = 0; i < ArraySize(g_watch); i++) if(g_watch[i] == sym) return true; return false; }

int TfFromMinutes(int m)
  {
   switch(m)
     {
      case 1: return PERIOD_M1;  case 5: return PERIOD_M5;   case 15: return PERIOD_M15; case 30: return PERIOD_M30;
      case 60: return PERIOD_H1; case 240: return PERIOD_H4; case 1440: return PERIOD_D1; case 10080: return PERIOD_W1;
      case 43200: return PERIOD_MN1;
     }
   return PERIOD_CURRENT;
  }

// Lý do đóng suy từ comment lệnh đã đóng: MT4 ghi "[sl]" / "[tp]" / "so:..." (không có thuộc tính reason chính thức -> chỉ là gợi ý)
string CloseReason(string cm)
  {
   if(StringFind(cm, "[sl]") >= 0) return "sl";
   if(StringFind(cm, "[tp]") >= 0) return "tp";
   if(StringFind(cm, "so:") >= 0) return "so";
   return "";
  }
// Deal «mở» (close=false) hoặc «đóng» (close=true) của lệnh đang được chọn: id,time,symbol,side,qty,price,fee,pnl,order,position_id,entry,reason
string HistDeal(bool close, const string sep)
  {
   int ty = OrderType();
   string t = IntegerToString(OrderTicket());
   string sd = (ty == OP_BUY ? "buy" : "sell"), od = (ty == OP_BUY ? "sell" : "buy");
   if(!close)
      return t + "o" + sep + D(Utc(OrderOpenTime()), 3) + sep + OrderSymbol() + sep + sd + sep + D(OrderLots()) + sep + D(OrderOpenPrice()) + sep + "0" + sep + "0" + sep +
             t + sep + t + sep + "IN" + sep + "";
   return t + "c" + sep + D(Utc(OrderCloseTime()), 3) + sep + OrderSymbol() + sep + od + sep + D(OrderLots()) + sep + D(OrderClosePrice()) + sep +
          D(OrderCommission() + OrderSwap()) + sep + D(OrderProfit()) + sep + t + sep + t + sep + "OUT" + sep + CloseReason(OrderComment());
  }

string BuildBody()
  {
   string b = "";
   b += "HELLO|MT4|" + IntegerToString(TerminalInfoInteger(TERMINAL_BUILD)) + "|" + IntegerToString(AccountNumber()) + "|sltp,posdeals,comment,history\n";
   b += "ACCT|" + D(AccountBalance(), 2) + "|" + D(AccountEquity(), 2) + "|" + D(AccountMargin(), 2) + "|" + D(AccountFreeMargin(), 2) + "|" +
        IntegerToString(AccountLeverage()) + "|" + AccountCurrency() + "|1|" + D(AccountCredit(), 2) + "\n";
   if(TimeCurrent() - g_lastSyms > 60)
     {
      string s = "";
      int n = SymbolsTotal(true);
      for(int i = 0; i < n; i++) s += (i ? "," : "") + SymbolName(i, true);
      b += "SYMS|" + s + "\n";
      g_lastSyms = TimeCurrent();
     }
   for(int i = 0; i < ArraySize(g_watch); i++)
     {
      string sy = g_watch[i];
      SymbolSelect(sy, true);
      double bid = MarketInfo(sy, MODE_BID), ask = MarketInfo(sy, MODE_ASK);
      if(bid > 0 && ask > 0)
         b += "TICK|" + sy + "|" + D(bid) + "|" + D(ask) + "|" + D(Utc((datetime)MarketInfo(sy, MODE_TIME)), 3) + "\n";
      b += "SPEC|" + sy + "|" + D(MarketInfo(sy, MODE_MINLOT)) + "|" + D(MarketInfo(sy, MODE_MAXLOT)) + "|" + D(MarketInfo(sy, MODE_LOTSTEP)) + "\n";
     }
   string pl = "", ol = "";
   int pc = 0, oc = 0;
   for(int i = 0; i < OrdersTotal(); i++)
     {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      int ty = OrderType();
      if(ty == OP_BUY || ty == OP_SELL)
        {
         pc++;
         pl += "POS|" + IntegerToString(OrderTicket()) + "|" + OrderSymbol() + "|" + (ty == OP_BUY ? "buy" : "sell") + "|" + D(OrderLots()) + "|" +
               D(OrderOpenPrice()) + "|" + D(OrderStopLoss()) + "|" + D(OrderTakeProfit()) + "|" + D(Utc(OrderOpenTime()), 3) + "|" + Clean(OrderComment()) + "|" +
               D(OrderProfit(), 2) + "|" + D(OrderSwap(), 2) + "|" + D(MarketInfo(OrderSymbol(), ty == OP_BUY ? MODE_BID : MODE_ASK)) + "|" + D(OrderCommission(), 2) + "\n";
        }
      else
        {
         string side = (ty == OP_BUYLIMIT || ty == OP_BUYSTOP) ? "buy" : "sell";
         string kind = (ty == OP_BUYLIMIT || ty == OP_SELLLIMIT) ? "limit" : "stop";
         oc++;
         ol += "ORD|" + IntegerToString(OrderTicket()) + "|" + OrderSymbol() + "|" + side + "|" + kind + "|" + D(OrderLots()) + "|" + D(OrderOpenPrice()) + "|" +
               D(OrderStopLoss()) + "|" + D(OrderTakeProfit()) + "\n";
        }
     }
   b += "POSALL|" + IntegerToString(pc) + "\n" + pl + "ORDALL|" + IntegerToString(oc) + "\n" + ol;
   // lịch sử: lệnh đã đóng trong DealDays ngày -> 2 deal (mở + đóng)
   datetime from = TimeCurrent() - DealDays * 86400;
   for(int i = OrdersHistoryTotal() - 1; i >= 0 && i > OrdersHistoryTotal() - 400; i--)
     {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
      int ty = OrderType();
      if(ty != OP_BUY && ty != OP_SELL) continue;
      if(OrderCloseTime() < from) continue;
      b += "DEAL|" + HistDeal(false, "|") + "\n" + "DEAL|" + HistDeal(true, "|") + "\n";
     }
   b += g_results;
   g_lastSent = g_results;
   g_results = "";
   return b;
  }

void Poll()
  {
   string body = BuildBody();
   char post[], res[];
   int n = StringToCharArray(body, post, 0, StringLen(body), CP_UTF8);
   ArrayResize(post, n);
   string headers = "Content-Type: text/plain\r\nX-PyEA-Token: " + Token + "\r\n";
   string rh;
   ResetLastError();
   int code = WebRequest("POST", GatewayURL + "/ea/poll", headers, 5000, post, res, rh);
   if(code != 200)
     {
      static datetime lastWarn = 0;
      if(TimeCurrent() - lastWarn > 30)
        {
         Print("PyEA_Bridge: gateway trả mã ", code, " lỗi ", GetLastError(), " (đã cho phép URL trong Tools>Options>Expert Advisors chưa?)");
         lastWarn = TimeCurrent();
        }
      g_results = g_lastSent + g_results;
      return;
     }
   string reply = CharArrayToString(res, 0, ArraySize(res), CP_UTF8);
   string lines[];
   int nl = StringSplit(reply, '\n', lines);
   for(int i = 0; i < nl; i++)
     {
      string f[];
      int nf = StringSplit(lines[i], '|', f);
      if(nf < 1) continue;
      if(f[0] == "WATCH" && nf > 1)
        {
         string s[];
         int k = StringSplit(f[1], ',', s);
         ArrayResize(g_watch, 0);
         for(int j = 0; j < k && j < 40; j++)
            if(StringLen(s[j]) > 0) { int z = ArraySize(g_watch); ArrayResize(g_watch, z + 1); g_watch[z] = s[j]; }
        }
      else if(f[0] == "CMD" && nf >= 3) Execute(f);
     }
  }

void ResOk(string id, int ticket, string position, double price, double vol, string msg)
  {
   AddResult("RES|" + id + "|1|10009|" + IntegerToString(ticket) + "|" + position + "|" + D(price) + "|" + D(vol) + "|" + Clean(msg));
  }
void ResFail(string id, int code, string msg) { AddResult("RES|" + id + "|0|" + IntegerToString(code) + "|||0|0|" + Clean(msg)); }

void Execute(string &f[])
  {
   string id = f[1], act = f[2];
   int n = ArraySize(f);
   if(act == "market" && n >= 7)               // sym|side|volume|comment
     {
      string sy = f[3];
      SymbolSelect(sy, true);
      bool buy = (f[4] == "buy");
      double price = buy ? MarketInfo(sy, MODE_ASK) : MarketInfo(sy, MODE_BID);
      int tk = OrderSend(sy, buy ? OP_BUY : OP_SELL, StringToDouble(f[5]), price, Slippage, 0, 0, f[6], MagicNo, 0);
      if(tk < 0) { ResFail(id, GetLastError(), "OrderSend thất bại"); return; }
      double fp = price;
      if(OrderSelect(tk, SELECT_BY_TICKET)) fp = OrderOpenPrice();
      ResOk(id, tk, IntegerToString(tk), fp, StringToDouble(f[5]), "ok");
      return;
     }
   if(act == "close" && n >= 5)                // ticket|volume(0=hết)
     {
      int tk = (int)StringToInteger(f[3]);
      if(!OrderSelect(tk, SELECT_BY_TICKET) || OrderCloseTime() != 0) { ResFail(id, 4108, "Không có vị thế " + f[3]); return; }
      double vol = StringToDouble(f[4]);
      if(vol <= 0 || vol > OrderLots()) vol = OrderLots();
      bool buy = (OrderType() == OP_BUY);
      string sy = OrderSymbol();
      double px = buy ? MarketInfo(sy, MODE_BID) : MarketInfo(sy, MODE_ASK);
      if(!OrderClose(tk, vol, px, Slippage)) { ResFail(id, GetLastError(), "OrderClose thất bại"); return; }
      ResOk(id, tk, f[3], px, vol, "ok");
      return;
     }
   if(act == "pending" && n >= 11)             // sym|side|kind|volume|price|stop_price|expiry|comment
     {
      string sy = f[3], side = f[4], kind = f[5];
      if(kind == "stop_limit") { ResFail(id, 4051, "MT4 không có lệnh stop-limit"); return; }
      bool buy = (side == "buy");
      int ty = (kind == "limit") ? (buy ? OP_BUYLIMIT : OP_SELLLIMIT) : (buy ? OP_BUYSTOP : OP_SELLSTOP);
      long expiry = StringToInteger(f[9]);
      datetime ex = (expiry > 0) ? (datetime)(expiry + OffsetSec()) : 0;
      SymbolSelect(sy, true);
      int tk = OrderSend(sy, ty, StringToDouble(f[6]), StringToDouble(f[7]), Slippage, 0, 0, f[10], MagicNo, ex);
      if(tk < 0) { ResFail(id, GetLastError(), "OrderSend (chờ) thất bại"); return; }
      ResOk(id, tk, "", 0, StringToDouble(f[6]), "placed");
      return;
     }
   if(act == "modify" && n >= 7)               // ticket|price|sl|tp
     {
      int tk = (int)StringToInteger(f[3]);
      if(!OrderSelect(tk, SELECT_BY_TICKET)) { ResFail(id, 4108, "Không có lệnh chờ " + f[3]); return; }
      double p = (f[4] == "") ? OrderOpenPrice() : StringToDouble(f[4]);
      double sl = (f[5] == "") ? OrderStopLoss() : StringToDouble(f[5]);
      double tp = (f[6] == "") ? OrderTakeProfit() : StringToDouble(f[6]);
      if(!OrderModify(tk, p, sl, tp, OrderExpiration())) { ResFail(id, GetLastError(), "OrderModify thất bại"); return; }
      ResOk(id, tk, "", 0, 0, "modified");
      return;
     }
   if(act == "cancel" && n >= 4)
     {
      int tk = (int)StringToInteger(f[3]);
      if(!OrderDelete(tk)) { ResFail(id, GetLastError(), "OrderDelete thất bại"); return; }
      ResOk(id, tk, "", 0, 0, "removed");
      return;
     }
   if(act == "sltp" && n >= 6)                 // ticket|sl|tp  (đặt CẢ HAI mức của MỘT vị thế; 0 = không đặt)
     {
      int tk = (int)StringToInteger(f[3]);
      if(!OrderSelect(tk, SELECT_BY_TICKET) || OrderCloseTime() != 0 || OrderType() > OP_SELL) { ResFail(id, 4108, "Không có vị thế " + f[3]); return; }
      int dg = (int)MarketInfo(OrderSymbol(), MODE_DIGITS);
      double sl = NormalizeDouble(StringToDouble(f[4]), dg), tp = NormalizeDouble(StringToDouble(f[5]), dg);
      // giá mở được giữ nguyên (lệnh thị trường); tài liệu MQL4: giá trị không đổi -> lỗi 1 (ERR_NO_RESULT) = SL/TP đã đúng mục tiêu, coi là thành công
      if(!OrderModify(tk, OrderOpenPrice(), sl, tp, 0))
        {
         int er = GetLastError();
         if(er != 1) { ResFail(id, er, "OrderModify SL/TP thất bại"); return; }
        }
      ResOk(id, tk, f[3], 0, 0, "sltp");
      return;
     }
   if(act == "posdeals" && n >= 4)             // ticket -> PDEALS|id|deal;deal;...  (lệnh mở: 1 deal; lệnh đã đóng: 2 deal)
     {
      int tk = (int)StringToInteger(f[3]);
      string s = "";
      if(OrderSelect(tk, SELECT_BY_TICKET) && OrderType() <= OP_SELL)
        {
         s = HistDeal(false, ",");
         if(OrderCloseTime() != 0) s += ";" + HistDeal(true, ",");
        }
      AddResult("PDEALS|" + id + "|" + s);
      return;
     }
   if(act == "history" && n >= 5)              // from_utc|to_utc(0=bây giờ) -> HIST|id|deal;deal;...  (mỗi lệnh đã đóng = deal mở + deal đóng; nạp/rút/credit = deal riêng)
     {
      datetime from = (datetime)(StringToInteger(f[3]) + OffsetSec());
      long toU = StringToInteger(f[4]);
      datetime to = (toU > 0) ? (datetime)(toU + OffsetSec()) : TimeCurrent() + 86400;
      string s = "";
      int cnt = 0;
      for(int i = OrdersHistoryTotal() - 1; i >= 0 && cnt < 5000; i--)
        {
         if(!OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)) continue;
         int ty = OrderType();
         datetime ct = OrderCloseTime();
         if(ct < from || ct > to) continue;
         string cm = OrderComment();
         StringReplace(cm, ",", " "); StringReplace(cm, ";", " ");
         string t = IntegerToString(OrderTicket());
         if(ty == OP_BUY || ty == OP_SELL)
           {
            string sd = (ty == OP_BUY ? "buy" : "sell"), od = (ty == OP_BUY ? "sell" : "buy");
            s += (StringLen(s) ? ";" : "") + t + "o," + D(Utc(OrderOpenTime()), 3) + ",trade," + OrderSymbol() + "," + sd + "," + D(OrderLots()) + "," + D(OrderOpenPrice()) +
                 ",IN," + t + "," + t + ",0,0,0,0," + Clean(cm);
            s += ";" + t + "c," + D(Utc(ct), 3) + ",trade," + OrderSymbol() + "," + od + "," + D(OrderLots()) + "," + D(OrderClosePrice()) + ",OUT," + t + "," + t + "," +
                 D(OrderProfit(), 2) + "," + D(OrderCommission(), 2) + "," + D(OrderSwap(), 2) + ",0," + Clean(cm);
            cnt += 2;
           }
         else if(ty > OP_SELLSTOP)                // MT4: OrderType() 6 = nạp/rút (balance), 7 = credit - không có hằng số tên trong MQL4
           {
            s += (StringLen(s) ? ";" : "") + t + "," + D(Utc(ct), 3) + "," + (ty == 6 ? "balance" : (ty == 7 ? "credit" : "other")) + ",,," + "0,0,," + t + "," + t + "," +
                 D(OrderProfit(), 2) + "," + D(OrderCommission(), 2) + "," + D(OrderSwap(), 2) + ",0," + Clean(cm);
            cnt++;
           }
        }
      AddResult("HIST|" + id + "|" + s);
      return;
     }
   if(act == "bars" && n >= 7)                 // sym|tf_phút|count|end_utc
     {
      string sy = f[3];
      int tf = TfFromMinutes((int)StringToInteger(f[4]));
      int cnt = (int)MathMin(StringToInteger(f[5]), 5000);
      long endUtc = StringToInteger(f[6]);
      SymbolSelect(sy, true);
      int shift = (endUtc > 0) ? iBarShift(sy, tf, (datetime)(endUtc + OffsetSec()), false) : 0;
      MqlRates rates[];
      ArraySetAsSeries(rates, false);
      int got = CopyRates(sy, tf, shift, cnt, rates);
      if(got <= 0) { ResFail(id, 4066, "CopyRates thất bại (mở biểu đồ/đồng bộ dữ liệu " + sy + " chưa?)"); return; }
      string s = "";
      for(int i = 0; i < got; i++)
         s += (i ? ";" : "") + D(Utc(rates[i].time), 0) + "," + D(rates[i].open) + "," + D(rates[i].high) + "," + D(rates[i].low) + "," +
              D(rates[i].close) + "," + D((double)rates[i].tick_volume, 0);
      AddResult("BARS|" + id + "|" + f[4] + "|" + sy + "|" + s);
      return;
     }
   if(act == "spec" && n >= 4)
     {
      if(!Watched(f[3])) { int k = ArraySize(g_watch); ArrayResize(g_watch, k + 1); g_watch[k] = f[3]; }
      AddResult("RES|" + id + "|1|0|||0|0|ok");
      return;
     }
   ResFail(id, 4051, "Lệnh không hiểu: " + act);
  }
//+------------------------------------------------------------------+
