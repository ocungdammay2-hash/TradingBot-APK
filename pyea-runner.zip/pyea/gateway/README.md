# Cầu nối MT4/MT5 cho PyEA Runner

Dùng khi tài khoản của bạn là **MetaTrader** (Exness MT4/MT5 hoặc bất kỳ broker nào) — loại tài khoản này **không** dùng được API
"Exness trading account" (xem `HANDOFF.md` mục Exness). App có 4 cách nối, chọn một ở Cài đặt → **Sàn**:

| `exchange` | Cách nối | Bạn cần | MT4 | MT5 | Trạng thái kiểm chứng |
|---|---|---|---|---|---|
| `metaapi` | Dịch vụ đám mây MetaApi (REST) | tài khoản MetaApi + Deploy tài khoản MT lên đó | ✔ | ✔ | Đường dẫn/payload đối chiếu tài liệu chính thức; test bằng máy chủ giả. **Chưa chạy với tài khoản MetaApi thật** |
| `mt5gw` + backend `mt5` | Cổng tự dựng + gói Python `MetaTrader5` | máy **Windows** chạy MT5 + Python | ✘ | ✔ | Logic test bằng module `MetaTrader5` giả. **Chưa chạy với MT5 thật** |
| `mt5gw` + backend `ea` | Cổng tự dựng + EA `PyEA_Bridge` (WebRequest) | máy Windows/VPS chạy MT4 hoặc MT5 | ✔ | ✔ | Phía server test bằng "EA giả" đúng giao thức. **File `.mq4/.mq5` chưa được biên dịch trên MetaEditor** |
| `bridge` | Dịch vụ REST bất kỳ khai báo bằng JSON | dịch vụ có API REST kiểu MT | tuỳ | tuỳ | Cơ chế ánh xạ có test; **từng dịch vụ cụ thể chưa thử** |

Thứ tự khuyên dùng: **thử trên tài khoản DEMO** → kiểm tra bằng *Nhật ký → Kiểm tra hệ thống* → đặt lệnh tay cỡ nhỏ → mới gắn bot.

## 1. Cổng PyEA (mt5gw)

Chỉ dùng thư viện chuẩn của Python 3.8+ (backend `mt5` cần thêm `pip install MetaTrader5`).

```bat
:: MT5 qua gói Python chính thức (Windows, MT5 đã cài và đã đăng nhập hoặc truyền login)
python mt_gateway.py --backend mt5 --token MAT_KHAU_DAI --login 12345678 --password "***" --server Exness-MT5Real --port 8765

:: MT4 hoặc MT5 qua EA (không cần Python gói MetaTrader5)
python mt_gateway.py --backend ea --token MAT_KHAU_DAI --port 8765
```

Trong app: `exchange = mt5gw`, `Địa chỉ cổng MT = http://<ip>:8765`, `Token cổng MT = MAT_KHAU_DAI`.

### Cài EA (backend `ea`)
1. Chép `PyEA_Bridge.mq5` (hoặc `.mq4`) vào `MQL5/Experts` (hoặc `MQL4/Experts`) → mở MetaEditor → biên dịch (F7). **Nếu báo lỗi biên dịch, hãy gửi lại nguyên văn lỗi.**
2. MT → *Tools ▸ Options ▸ Expert Advisors* → tick **Allow WebRequest for listed URL** → thêm đúng địa chỉ cổng (ví dụ `http://192.168.1.10:8765`).
3. Kéo EA vào **một** biểu đồ bất kỳ, điền `GatewayURL` và `Token`, bật nút **AutoTrading**.
4. EA chỉ gọi **ra ngoài** mỗi ~250 ms; không mở cổng nào trên máy MT. Mất kết nối > 15 giây app sẽ báo "EA chưa kết nối".

### Bảo mật (quan trọng)
- Luôn đặt `--token` dài, ngẫu nhiên. Không đặt token mà mở ra ngoài localhost là **ai cũng đặt lệnh được trên tài khoản của bạn**.
- Đừng mở cổng trần ra Internet. Dùng một trong: **Tailscale/WireGuard** (khuyên dùng), **SSH tunnel**, hoặc TLS tích hợp `--cert cert.pem --key key.pem`.
- Token và URL được lưu mã hoá trong app (Android Keystore); trên cổng token nằm trong dòng lệnh — hạn chế quyền truy cập máy chạy cổng.

### Khác biệt cần biết
- **Giờ**: cổng đổi mọi thời gian về **UTC**. Backend `mt5` tự dò chênh lệch giờ broker từ tick của mã đang theo dõi (cả khi bạn mở Lịch sử ngay sau khi cổng khởi động); nếu thị trường đóng cửa lúc khởi động nên không dò được, truyền `--server-offset-hours 3` (ví dụ UTC+3) - nếu không, giờ của lịch sử/vị thế lệch đúng bấy nhiêu giờ.
- **Kích thước lệnh** là *lot* như trên MT. App tự làm tròn xuống theo `volume_step` và từ chối nếu dưới `volume_min`.
- **Lệnh chờ native** (limit/stop/stop-limit) nằm **trên terminal**, vẫn sống nếu điện thoại/app chết. MT4 không có stop-limit → app tự theo dõi loại này (`Lệnh chờ = auto`).
- **SL/TP native (mặc định TẮT, bật ở Cài đặt, thử DEMO trước)**: cổng + EA bản MỚI gắn SL/TP lên đúng ticket (MT5 `TRADE_ACTION_SLTP`, MT4 `OrderModify`) nên vẫn chạy khi điện thoại/app chết. Chỉ đụng vị thế có comment `pyea…` (vị thế bạn bấm tay trên MT/EA khác không bao giờ bị sửa). Cổng/EA **bản cũ** không có khả năng này: app tự giữ SL/TP như trước và nói rõ lý do - **sau khi cập nhật `mt_gateway.py` phải chép lại, biên dịch lại và gắn lại EA** (nếu không, `/v1/ping` không báo `sltp`). Quy ước «0 = gỡ mức» là cách dùng thông thường của MQL (tài liệu không nói rõ) - kiểm bằng `selfcheck --trade` trên DEMO.
- **MT4**: đóng một phần tạo ticket MỚI nên app không dùng định danh theo ticket cho MT4 (tự rơi về cách cũ).
- **Tài khoản netting** (MT5) tự nhận diện: một vị thế gộp cho mỗi mã. Vị thế ảo của app chỉ được gắn SL/TP native khi nó chính là cả ticket; ticket gộp nhiều vị thế ảo không bao giờ nhận SL/TP của riêng một vị thế.
- **Số liệu do sàn báo (như MT5)**: app hiển thị Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ **của sàn** (nhãn «SÀN»; không có thì dùng sổ app và ghi «sổ app»), lãi/lỗ + swap của từng vị thế do sàn tính, và mục **Lịch sử từ sàn** (Hôm nay/7/30/90 ngày) qua `/v1/history`. MT5 python và EA MQL5 không báo hoa hồng theo VỊ THẾ (chỉ có ở deal) nên cột đó chỉ có ở lịch sử; app không điền số 0 thay cho số không biết.
- Backend `ea` cập nhật trạng thái **nhất quán dần** (mỗi nhịp poll); sau khi vị thế đổi, app có thể thấy trễ ≤ ~0,5 giây.

## 2. Hồ sơ cầu nối REST khác (`exchange = bridge`)

Cho dịch vụ có API REST kiểu MT mà không viết mã: dán JSON vào ô *Hồ sơ cầu nối*, token vào ô *Token cho hồ sơ cầu nối*.

```json
{
  "name": "vendorx",
  "base": "https://api.vendorx.example",
  "headers": {"X-Key": "{token}"},
  "side": {"buy": "BUY", "sell": "SELL"},
  "ops": {
    "account":   {"path": "/acct", "map": {"balance": "data.bal", "equity": "data.eq", "leverage": "data.lev", "hedging": "data.hedge"}},
    "symbols":   {"path": "/symbols", "list": "result"},
    "tick":      {"path": "/price/{symbol}", "map": {"bid": "data.b", "ask": "data.a", "time": "data.t"}},
    "positions": {"path": "/positions", "list": "items", "map": {"id": "ticket", "symbol": "sym", "side": "dir", "volume": "lots", "price": "open", "time": "t"}},
    "market":    {"method": "POST", "path": "/open", "body": {"sym": "{symbol}", "dir": "{side}", "lots": "{volume}"},
                  "map": {"order_id": "ticket", "position_id": "pos", "price": "fill"}},
    "close":     {"method": "POST", "path": "/close/{position_id}", "body": {"lots": "{volume}"}, "map": {"order_id": "ticket", "price": "fill"}}
  }
}
```

- Biến dùng được: `{symbol} {side} {volume} {price} {stop_price} {position_id} {order_id} {tf} {count} {end} {since} {token}`.
- `"{volume}"` đứng nguyên khối trong `body` giữ **kiểu số**. `map` dùng đường dẫn chấm (`data.items.0.price`).
- Thao tác tối thiểu để giao dịch: `account`, `tick`, `positions`, `market`, `close`. Thao tác thiếu → app báo rõ "cầu nối này không hỗ trợ …".
  Muốn lệnh chờ native thì khai báo thêm `pending`, `modify`, `cancel`, `orders` và `"native_kinds": ["limit","stop"]`.
- Tôi **chưa kiểm tra** hồ sơ nào cho dịch vụ thật (TickerAll, mt5api, …) vì chưa có tài liệu/tài khoản; cơ chế ánh xạ được test bằng một dịch vụ giả có hình dạng JSON khác hẳn.

## 3. Giao thức JSON của cổng (để tự viết backend khác)

Xem docstring đầu `mt_gateway.py`. Mọi phản hồi `{"ok": true, ...}` hoặc `{"ok": false, "error": "...", "code": "..."}`; thời gian là epoch UTC giây.
