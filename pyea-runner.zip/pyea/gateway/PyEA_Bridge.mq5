//+------------------------------------------------------------------+
//| PyEA_Bridge.mq5 - cầu nối MT5 <-> PyEA MT Gateway (qua WebRequest)|
//|                                                                  |
//| TRẠNG THÁI: viết theo tài liệu MQL5 và theo ĐÚNG giao thức đã     |
//| được kiểm thử phía server (gateway/mt_gateway.py, backend 'ea').  |
//| CHƯA được biên dịch/chạy trên MetaEditor thật trong môi trường    |
//| phát triển (không có MT5). Hãy biên dịch, chạy trên TÀI KHOẢN DEMO |
//| và báo lỗi biên dịch/hành vi nếu có.                              |
//|                                                                  |
//| CÁCH DÙNG: copy vào MQL5/Experts, biên dịch (F7), kéo vào MỘT biểu |
//| đồ bất kỳ. Tools > Options > Expert Advisors > tick "Allow        |
//| WebRequest for listed URL" và thêm địa chỉ GatewayURL. Bật nút    |
//| AutoTrading. EA chỉ gọi RA ngoài (không mở cổng nào trên máy).    |
//|                                                                  |
//| Giao thức (văn bản, dòng cách nhau \n, trường cách nhau |):       |
//|  EA -> gateway : HELLO ACCT SYMS TICK POSALL POS ORDALL ORD SPEC   |
//|                  DEAL RES BARS PDEALS                             |
//|  POS có thêm: comment|profit|swap|price_now (lãi/lỗ do MT5 tính);  |
//|  lệnh history -> HIST (mọi deal kể cả nạp/rút, tách swap/hoa hồng) |
//|  POS (cũ): comment (app nhận ra vị thế của mình);                  |
//|  DEAL có thêm position_id|entry|reason; lệnh mới: sltp, posdeals   |
//|  gateway -> EA : OK|epoch  WATCH|a,b  CMD|id|action|args...        |
//|  Mọi thời gian gửi lên là epoch UTC (EA tự đổi từ giờ broker).     |
//+------------------------------------------------------------------+
#property copyright "PyEA Runner"
#property version   "1.00"
#property strict

input string GatewayURL = "http://127.0.0.1:8765";   // địa chỉ gateway (phải nằm trong danh sách WebRequest cho phép)
input string Token      = "";                         // trùng --token của gateway
input int    PollMs     = 250;                        // chu kỳ gọi gateway (ms)
input int    Deviation  = 20;                         // trượt giá cho phép (points)
input long   MagicNo    = 7001;                       // magic number của lệnh do app đặt
input int    DealDays   = 7;                          // lần đầu: gửi lịch sử deal mấy ngày

string   g_watch[];
string   g_results = "";
string   g_lastSent = "";      // kết quả đã nhét vào lần gọi gần nhất (để gửi lại nếu lần đó thất bại)
datetime g_dealsFrom = 0;
datetime g_lastSyms  = 0;
bool     g_busy = false;

//+------------------------------------------------------------------+
int OnInit()
  {
   EventSetMillisecondTimer(MathMax(100, PollMs));
   g_dealsFrom = TimeGMT() - DealDays * 86400;
   Print("PyEA_Bridge: bắt đầu, gateway=", GatewayURL);
   return(INIT_SUCCEEDED);
  }
void OnDeinit(const int reason) { EventKillTimer(); }
void OnTimer() { if(!g_busy) { g_busy = true; Poll(); g_busy = false; } }

//--- tiện ích -------------------------------------------------------
long OffsetSec() { return (long)(TimeCurrent() - TimeGMT()); }          // giờ broker - UTC
double Utc(datetime brokerTime) { return (double)(brokerTime - OffsetSec()); }
string D(double v, int digits = 8) { return DoubleToString(v, digits); }

string SideOfType(long t)
  {
   if(t == POSITION_TYPE_BUY) return "buy";
   return "sell";
  }

bool OrderKind(long t, string &side, string &kind)
  {
   switch((int)t)
     {
      case ORDER_TYPE_BUY_LIMIT:       side = "buy";  kind = "limit";      return true;
      case ORDER_TYPE_SELL_LIMIT:      side = "sell"; kind = "limit";      return true;
      case ORDER_TYPE_BUY_STOP:        side = "buy";  kind = "stop";       return true;
      case ORDER_TYPE_SELL_STOP:       side = "sell"; kind = "stop";       return true;
      case ORDER_TYPE_BUY_STOP_LIMIT:  side = "buy";  kind = "stop_limit"; return true;
      case ORDER_TYPE_SELL_STOP_LIMIT: side = "sell"; kind = "stop_limit"; return true;
     }
   return false;
  }

ENUM_ORDER_TYPE_FILLING Filling(const string sym)
  {
   long fm = SymbolInfoInteger(sym, SYMBOL_FILLING_MODE);
   if((fm & SYMBOL_FILLING_IOC) != 0) return ORDER_FILLING_IOC;
   if((fm & SYMBOL_FILLING_FOK) != 0) return ORDER_FILLING_FOK;
   return ORDER_FILLING_RETURN;
  }

ENUM_TIMEFRAMES TfFromMinutes(int m)
  {
   switch(m)
     {
      case 1: return PERIOD_M1;   case 2: return PERIOD_M2;   case 3: return PERIOD_M3;
      case 4: return PERIOD_M4;   case 5: return PERIOD_M5;   case 6: return PERIOD_M6;
      case 10: return PERIOD_M10; case 12: return PERIOD_M12; case 15: return PERIOD_M15;
      case 20: return PERIOD_M20; case 30: return PERIOD_M30; case 60: return PERIOD_H1;
      case 120: return PERIOD_H2; case 180: return PERIOD_H3; case 240: return PERIOD_H4;
      case 360: return PERIOD_H6; case 480: return PERIOD_H8; case 720: return PERIOD_H12;
      case 1440: return PERIOD_D1; case 10080: return PERIOD_W1; case 43200: return PERIOD_MN1;
     }
   return PERIOD_CURRENT;
  }

bool Watched(const string sym)
  {
   for(int i = 0; i < ArraySize(g_watch); i++) if(g_watch[i] == sym) return true;
   return false;
  }

void AddResult(const string line) { g_results += line + "\n"; }

string Clean(string s) { StringReplace(s, "|", "/"); StringReplace(s, "\n", " "); return s; }

//--- deal -----------------------------------------------------------
string EntryName(long e)
  {
   if(e == DEAL_ENTRY_IN) return "IN";
   if(e == DEAL_ENTRY_OUT) return "OUT";
   if(e == DEAL_ENTRY_INOUT) return "INOUT";
   if(e == DEAL_ENTRY_OUT_BY) return "OUT_BY";
   return "";
  }
string ReasonName(long r)
  {
   switch((int)r)
     {
      case DEAL_REASON_CLIENT: return "client";   case DEAL_REASON_MOBILE: return "mobile";
      case DEAL_REASON_WEB:    return "web";      case DEAL_REASON_EXPERT: return "expert";
      case DEAL_REASON_SL:     return "sl";       case DEAL_REASON_TP:     return "tp";
      case DEAL_REASON_SO:     return "so";       case DEAL_REASON_ROLLOVER: return "rollover";
      case DEAL_REASON_VMARGIN: return "vmargin"; case DEAL_REASON_SPLIT: return "split";
     }
   return "";
  }
// id,time,symbol,side,qty,price,fee,pnl,order,position_id,entry,reason - ngăn cách bằng `sep` ("|" cho DEAL, "," cho PDEALS)
string DealFields(ulong dt, const string sep)
  {
   long ty = HistoryDealGetInteger(dt, DEAL_TYPE);
   datetime tm = (datetime)HistoryDealGetInteger(dt, DEAL_TIME);
   return IntegerToString((long)dt) + sep + D(Utc(tm), 3) + sep + Clean(HistoryDealGetString(dt, DEAL_SYMBOL)) + sep + (ty == DEAL_TYPE_BUY ? "buy" : "sell") + sep +
          D(HistoryDealGetDouble(dt, DEAL_VOLUME)) + sep + D(HistoryDealGetDouble(dt, DEAL_PRICE)) + sep +
          D(HistoryDealGetDouble(dt, DEAL_COMMISSION) + HistoryDealGetDouble(dt, DEAL_SWAP)) + sep + D(HistoryDealGetDouble(dt, DEAL_PROFIT)) + sep +
          IntegerToString((long)HistoryDealGetInteger(dt, DEAL_ORDER)) + sep + IntegerToString((long)HistoryDealGetInteger(dt, DEAL_POSITION_ID)) + sep +
          EntryName(HistoryDealGetInteger(dt, DEAL_ENTRY)) + sep + ReasonName(HistoryDealGetInteger(dt, DEAL_REASON));
  }

//--- dựng thân yêu cầu ---------------------------------------------
string BuildBody()
  {
   string b = "";
   b += "HELLO|MT5|" + IntegerToString((int)TerminalInfoInteger(TERMINAL_BUILD)) + "|" + IntegerToString((int)AccountInfoInteger(ACCOUNT_LOGIN)) + "|sltp,posdeals,comment,history\n";
   int hedge = (AccountInfoInteger(ACCOUNT_MARGIN_MODE) == ACCOUNT_MARGIN_MODE_RETAIL_HEDGING) ? 1 : 0;
   b += "ACCT|" + D(AccountInfoDouble(ACCOUNT_BALANCE), 2) + "|" + D(AccountInfoDouble(ACCOUNT_EQUITY), 2) + "|" +
        D(AccountInfoDouble(ACCOUNT_MARGIN), 2) + "|" + D(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + "|" +
        IntegerToString((int)AccountInfoInteger(ACCOUNT_LEVERAGE)) + "|" + AccountInfoString(ACCOUNT_CURRENCY) + "|" + IntegerToString(hedge) + "|" +
        D(AccountInfoDouble(ACCOUNT_CREDIT), 2) + "\n";
   if(TimeCurrent() - g_lastSyms > 60)
     {
      string s = "";
      int n = SymbolsTotal(true);
      for(int i = 0; i < n; i++) s += (i ? "," : "") + SymbolName(i, true);
      b += "SYMS|" + s + "\n";
      g_lastSyms = TimeCurrent();
     }
   for(int i = 0; i < ArraySize(g_watch); i++)
     {
      string sy = g_watch[i];
      SymbolSelect(sy, true);
      MqlTick t;
      if(SymbolInfoTick(sy, t))
         b += "TICK|" + sy + "|" + D(t.bid) + "|" + D(t.ask) + "|" + D(Utc(t.time), 3) + "\n";
      b += "SPEC|" + sy + "|" + D(SymbolInfoDouble(sy, SYMBOL_VOLUME_MIN)) + "|" + D(SymbolInfoDouble(sy, SYMBOL_VOLUME_MAX)) + "|" +
           D(SymbolInfoDouble(sy, SYMBOL_VOLUME_STEP)) + "\n";
     }
   int np = PositionsTotal();
   b += "POSALL|" + IntegerToString(np) + "\n";
   for(int i = 0; i < np; i++)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk)) continue;
      b += "POS|" + IntegerToString((long)tk) + "|" + PositionGetString(POSITION_SYMBOL) + "|" + SideOfType(PositionGetInteger(POSITION_TYPE)) + "|" +
           D(PositionGetDouble(POSITION_VOLUME)) + "|" + D(PositionGetDouble(POSITION_PRICE_OPEN)) + "|" + D(PositionGetDouble(POSITION_SL)) + "|" +
           D(PositionGetDouble(POSITION_TP)) + "|" + D(Utc((datetime)PositionGetInteger(POSITION_TIME)), 3) + "|" + Clean(PositionGetString(POSITION_COMMENT)) + "|" +
           D(PositionGetDouble(POSITION_PROFIT), 2) + "|" + D(PositionGetDouble(POSITION_SWAP), 2) + "|" + D(PositionGetDouble(POSITION_PRICE_CURRENT)) + "\n";
     }
   int cnt = 0;
   string ol = "";
   int no = OrdersTotal();
   for(int i = 0; i < no; i++)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0) continue;
      string side, kind;
      if(!OrderKind(OrderGetInteger(ORDER_TYPE), side, kind)) continue;
      cnt++;
      ol += "ORD|" + IntegerToString((long)tk) + "|" + OrderGetString(ORDER_SYMBOL) + "|" + side + "|" + kind + "|" + D(OrderGetDouble(ORDER_VOLUME_CURRENT)) + "|" +
            D(OrderGetDouble(ORDER_PRICE_OPEN)) + "|" + D(OrderGetDouble(ORDER_SL)) + "|" + D(OrderGetDouble(ORDER_TP)) + "\n";
     }
   b += "ORDALL|" + IntegerToString(cnt) + "\n" + ol;
   // lịch sử deal (chỉ phần mới; server khử trùng theo id)
   if(HistorySelect(g_dealsFrom, TimeCurrent() + 86400))
     {
      int nd = HistoryDealsTotal();
      datetime maxT = g_dealsFrom;
      for(int i = 0; i < nd; i++)
        {
         ulong dt = HistoryDealGetTicket(i);
         long ty = HistoryDealGetInteger(dt, DEAL_TYPE);
         if(ty != DEAL_TYPE_BUY && ty != DEAL_TYPE_SELL) continue;
         datetime tm = (datetime)HistoryDealGetInteger(dt, DEAL_TIME);
         if(tm > maxT) maxT = tm;
         b += "DEAL|" + DealFields(dt, "|") + "\n";
        }
      if(maxT > g_dealsFrom) g_dealsFrom = maxT - 3600;      // chồng 1 giờ cho chắc
     }
   b += g_results;
   g_lastSent = g_results;
   g_results = "";
   return b;
  }

//--- gọi gateway ----------------------------------------------------
void Poll()
  {
   string body = BuildBody();
   char post[], res[];
   int n = StringToCharArray(body, post, 0, StringLen(body), CP_UTF8);
   ArrayResize(post, n);
   string headers = "Content-Type: text/plain\r\nX-PyEA-Token: " + Token + "\r\n";
   string rh;
   ResetLastError();
   int code = WebRequest("POST", GatewayURL + "/ea/poll", headers, 5000, post, res, rh);
   if(code != 200)
     {
      static datetime lastWarn = 0;
      if(TimeCurrent() - lastWarn > 30)
        {
         Print("PyEA_Bridge: gateway trả mã ", code, " lỗi ", GetLastError(), " (đã cho phép URL trong Tools>Options>Expert Advisors chưa?)");
         lastWarn = TimeCurrent();
        }
      g_results = g_lastSent + g_results;     // gửi thất bại: giữ lại kết quả lệnh để lần sau gửi lại
      return;
     }
   string reply = CharArrayToString(res, 0, ArraySize(res), CP_UTF8);
   string lines[];
   int nl = StringSplit(reply, '\n', lines);
   for(int i = 0; i < nl; i++)
     {
      string f[];
      int nf = StringSplit(lines[i], '|', f);
      if(nf < 1) continue;
      if(f[0] == "WATCH" && nf > 1) ParseWatch(f[1]);
      else if(f[0] == "CMD" && nf >= 3) Execute(f);
     }
  }

void ParseWatch(const string csv)
  {
   string s[];
   int n = StringSplit(csv, ',', s);
   ArrayResize(g_watch, 0);
   for(int i = 0; i < n && i < 40; i++)
     {
      if(StringLen(s[i]) == 0) continue;
      int k = ArraySize(g_watch);
      ArrayResize(g_watch, k + 1);
      g_watch[k] = s[i];
     }
  }

//--- thực thi lệnh --------------------------------------------------
void ResOk(const string id, const MqlTradeResult &r, const string position)
  {
   AddResult("RES|" + id + "|1|" + IntegerToString((int)r.retcode) + "|" + IntegerToString((long)r.order) + "|" + position + "|" + D(r.price) + "|" +
             D(r.volume) + "|" + Clean(r.comment));
  }
void ResFail(const string id, const int code, const string msg)
  {
   AddResult("RES|" + id + "|0|" + IntegerToString(code) + "|||0|0|" + Clean(msg));
  }
bool Done(const MqlTradeResult &r) { return r.retcode == TRADE_RETCODE_DONE || r.retcode == TRADE_RETCODE_PLACED || r.retcode == TRADE_RETCODE_DONE_PARTIAL; }

void Execute(string &f[])
  {
   string id = f[1], act = f[2];
   int n = ArraySize(f);
   MqlTradeRequest rq;
   MqlTradeResult  rs;
   ZeroMemory(rq);
   ZeroMemory(rs);
   if(act == "market" && n >= 7)               // sym|side|volume|comment
     {
      string sy = f[3];
      SymbolSelect(sy, true);
      MqlTick t;
      if(!SymbolInfoTick(sy, t)) { ResFail(id, 10021, "Chưa có giá " + sy); return; }
      bool buy = (f[4] == "buy");
      rq.action = TRADE_ACTION_DEAL; rq.symbol = sy; rq.volume = StringToDouble(f[5]);
      rq.type = buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL; rq.price = buy ? t.ask : t.bid;
      rq.deviation = Deviation; rq.magic = MagicNo; rq.comment = f[6]; rq.type_filling = Filling(sy); rq.type_time = ORDER_TIME_GTC;
      if(!OrderSend(rq, rs) || !Done(rs)) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, IntegerToString((long)rs.order));        // hedging: vị thế mới có ticket = ticket lệnh mở
      return;
     }
   if(act == "close" && n >= 5)                // ticket|volume(0=hết)
     {
      ulong tk = (ulong)StringToInteger(f[3]);
      if(!PositionSelectByTicket(tk)) { ResFail(id, 10013, "Không có vị thế " + f[3]); return; }
      string sy = PositionGetString(POSITION_SYMBOL);
      bool wasBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
      double vol = StringToDouble(f[4]);
      if(vol <= 0 || vol > PositionGetDouble(POSITION_VOLUME)) vol = PositionGetDouble(POSITION_VOLUME);
      MqlTick t;
      if(!SymbolInfoTick(sy, t)) { ResFail(id, 10021, "Chưa có giá " + sy); return; }
      rq.action = TRADE_ACTION_DEAL; rq.symbol = sy; rq.position = tk; rq.volume = vol;
      rq.type = wasBuy ? ORDER_TYPE_SELL : ORDER_TYPE_BUY; rq.price = wasBuy ? t.bid : t.ask;
      rq.deviation = Deviation; rq.magic = MagicNo; rq.comment = "pyea close"; rq.type_filling = Filling(sy); rq.type_time = ORDER_TIME_GTC;
      if(!OrderSend(rq, rs) || !Done(rs)) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, f[3]);
      return;
     }
   if(act == "pending" && n >= 11)             // sym|side|kind|volume|price|stop_price|expiry|comment
     {
      string sy = f[3], side = f[4], kind = f[5];
      double price = StringToDouble(f[7]), stopP = StringToDouble(f[8]);
      long expiry = StringToInteger(f[9]);
      ENUM_ORDER_TYPE ty;
      bool buy = (side == "buy");
      if(kind == "limit") ty = buy ? ORDER_TYPE_BUY_LIMIT : ORDER_TYPE_SELL_LIMIT;
      else if(kind == "stop") ty = buy ? ORDER_TYPE_BUY_STOP : ORDER_TYPE_SELL_STOP;
      else if(kind == "stop_limit") ty = buy ? ORDER_TYPE_BUY_STOP_LIMIT : ORDER_TYPE_SELL_STOP_LIMIT;
      else { ResFail(id, 10013, "Loại lệnh chờ không hỗ trợ: " + kind); return; }
      SymbolSelect(sy, true);
      rq.action = TRADE_ACTION_PENDING; rq.symbol = sy; rq.volume = StringToDouble(f[6]); rq.type = ty;
      if(kind == "stop_limit") { rq.price = stopP; rq.stoplimit = price; }     // MT5: price = giá KÍCH HOẠT, stoplimit = giá limit
      else rq.price = price;
      rq.deviation = Deviation; rq.magic = MagicNo; rq.comment = f[10]; rq.type_filling = ORDER_FILLING_RETURN;
      if(expiry > 0) { rq.type_time = ORDER_TIME_SPECIFIED; rq.expiration = (datetime)(expiry + OffsetSec()); }
      else rq.type_time = ORDER_TIME_GTC;
      if(!OrderSend(rq, rs) || !Done(rs)) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, "");
      return;
     }
   if(act == "modify" && n >= 7)               // ticket|price|sl|tp  (rỗng = giữ nguyên)
     {
      ulong tk = (ulong)StringToInteger(f[3]);
      if(!OrderSelect(tk)) { ResFail(id, 10013, "Không có lệnh chờ " + f[3]); return; }
      rq.action = TRADE_ACTION_MODIFY; rq.order = tk;
      rq.price = (f[4] == "") ? OrderGetDouble(ORDER_PRICE_OPEN) : StringToDouble(f[4]);
      rq.sl    = (f[5] == "") ? OrderGetDouble(ORDER_SL) : StringToDouble(f[5]);
      rq.tp    = (f[6] == "") ? OrderGetDouble(ORDER_TP) : StringToDouble(f[6]);
      long ot = OrderGetInteger(ORDER_TYPE);
      if(ot == ORDER_TYPE_BUY_STOP_LIMIT || ot == ORDER_TYPE_SELL_STOP_LIMIT) rq.stoplimit = OrderGetDouble(ORDER_PRICE_STOPLIMIT);
      rq.type_time = ORDER_TIME_GTC;
      if(!OrderSend(rq, rs) || !Done(rs)) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, "");
      return;
     }
   if(act == "cancel" && n >= 4)
     {
      rq.action = TRADE_ACTION_REMOVE; rq.order = (ulong)StringToInteger(f[3]);
      if(!OrderSend(rq, rs) || !Done(rs)) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, "");
      return;
     }
   if(act == "sltp" && n >= 6)                 // ticket|sl|tp  (đặt CẢ HAI mức của MỘT vị thế; 0 = không đặt)
     {
      ulong tk = (ulong)StringToInteger(f[3]);
      if(!PositionSelectByTicket(tk)) { ResFail(id, 10036, "Không có vị thế " + f[3]); return; }
      rq.action = TRADE_ACTION_SLTP; rq.symbol = PositionGetString(POSITION_SYMBOL); rq.position = tk; rq.magic = MagicNo;
      rq.sl = StringToDouble(f[4]); rq.tp = StringToDouble(f[5]);
      bool sent = OrderSend(rq, rs);
      if(rs.retcode != TRADE_RETCODE_NO_CHANGES && (!sent || !Done(rs))) { ResFail(id, (int)rs.retcode, rs.comment); return; }
      ResOk(id, rs, f[3]);                     // NO_CHANGES (10025): SL/TP đã đúng giá trị mong muốn -> coi là thành công
      return;
     }
   if(act == "posdeals" && n >= 4)             // ticket -> PDEALS|id|deal;deal;... (mọi deal của vị thế, không phụ thuộc cửa sổ DealDays)
     {
      ulong tk = (ulong)StringToInteger(f[3]);
      string s = "";
      if(HistorySelectByPosition(tk))
        {
         int nd = HistoryDealsTotal();
         for(int i = 0; i < nd; i++)
           {
            ulong dt = HistoryDealGetTicket(i);
            long ty = HistoryDealGetInteger(dt, DEAL_TYPE);
            if(ty != DEAL_TYPE_BUY && ty != DEAL_TYPE_SELL) continue;
            s += (StringLen(s) ? ";" : "") + DealFields(dt, ",");
           }
        }
      AddResult("PDEALS|" + id + "|" + s);
      return;
     }
   if(act == "history" && n >= 5)              // from_utc|to_utc(0=bây giờ) -> HIST|id|deal;deal;... (tối đa 5000 deal mới nhất trong khoảng)
     {
      datetime from = (datetime)(StringToInteger(f[3]) + OffsetSec());
      long toU = StringToInteger(f[4]);
      datetime to = (toU > 0) ? (datetime)(toU + OffsetSec()) : TimeCurrent() + 86400;
      string s = "";
      if(HistorySelect(from, to))
        {
         int nd = HistoryDealsTotal();
         int first = MathMax(0, nd - 5000);
         for(int i = first; i < nd; i++)
           {
            ulong dt = HistoryDealGetTicket(i);
            long ty = HistoryDealGetInteger(dt, DEAL_TYPE);
            string kind = (ty == DEAL_TYPE_BUY || ty == DEAL_TYPE_SELL) ? "trade" : (ty == DEAL_TYPE_BALANCE ? "balance" : (ty == DEAL_TYPE_CREDIT ? "credit" : "other"));
            string cm = HistoryDealGetString(dt, DEAL_COMMENT);
            StringReplace(cm, ",", " "); StringReplace(cm, ";", " ");
            datetime tm = (datetime)HistoryDealGetInteger(dt, DEAL_TIME);
            s += (StringLen(s) ? ";" : "") + IntegerToString((long)dt) + "," + D(Utc(tm), 3) + "," + kind + "," + Clean(HistoryDealGetString(dt, DEAL_SYMBOL)) + "," +
                 (ty == DEAL_TYPE_BUY ? "buy" : (ty == DEAL_TYPE_SELL ? "sell" : "")) + "," + D(HistoryDealGetDouble(dt, DEAL_VOLUME)) + "," +
                 D(HistoryDealGetDouble(dt, DEAL_PRICE)) + "," + EntryName(HistoryDealGetInteger(dt, DEAL_ENTRY)) + "," +
                 IntegerToString((long)HistoryDealGetInteger(dt, DEAL_POSITION_ID)) + "," + IntegerToString((long)HistoryDealGetInteger(dt, DEAL_ORDER)) + "," +
                 D(HistoryDealGetDouble(dt, DEAL_PROFIT), 2) + "," + D(HistoryDealGetDouble(dt, DEAL_COMMISSION), 2) + "," + D(HistoryDealGetDouble(dt, DEAL_SWAP), 2) + "," +
                 D(HistoryDealGetDouble(dt, DEAL_FEE), 2) + "," + Clean(cm);
           }
        }
      AddResult("HIST|" + id + "|" + s);
      return;
     }
   if(act == "bars" && n >= 7)                 // sym|tf_phút|count|end_utc(0=bây giờ)
     {
      string sy = f[3];
      ENUM_TIMEFRAMES tf = TfFromMinutes((int)StringToInteger(f[4]));
      int cnt = (int)MathMin(StringToInteger(f[5]), 5000);
      long endUtc = StringToInteger(f[6]);
      SymbolSelect(sy, true);
      MqlRates rates[];
      ArraySetAsSeries(rates, false);
      int got = (endUtc > 0) ? CopyRates(sy, tf, (datetime)(endUtc + OffsetSec()), cnt, rates) : CopyRates(sy, tf, 0, cnt, rates);
      if(got <= 0) { ResFail(id, 10013, "CopyRates thất bại (đã mở biểu đồ/đồng bộ dữ liệu mã " + sy + " chưa?)"); return; }
      string s = "";
      for(int i = 0; i < got; i++)
         s += (i ? ";" : "") + D(Utc(rates[i].time), 0) + "," + D(rates[i].open) + "," + D(rates[i].high) + "," + D(rates[i].low) + "," +
              D(rates[i].close) + "," + D((double)rates[i].tick_volume, 0);
      AddResult("BARS|" + id + "|" + f[4] + "|" + sy + "|" + s);
      return;
     }
   if(act == "spec" && n >= 4)
     {
      int k = ArraySize(g_watch);
      if(!Watched(f[3])) { ArrayResize(g_watch, k + 1); g_watch[k] = f[3]; }
      AddResult("RES|" + id + "|1|0|||0|0|ok");
      return;
     }
   ResFail(id, 10013, "Lệnh không hiểu: " + act);
  }
//+------------------------------------------------------------------+
