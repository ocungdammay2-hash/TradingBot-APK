#!/usr/bin/env python3
"""
PyEA MT Gateway - cầu nối giữa app PyEA Runner (Android) và terminal MetaTrader 4/5 của BẠN (Exness MT4/MT5 hoặc bất kỳ broker nào).
Chạy trên máy Windows/VPS có cài MetaTrader. Chỉ dùng thư viện chuẩn của Python (backend mt5 cần thêm `pip install MetaTrader5`).

  python mt_gateway.py --backend mt5 --token MAT_KHAU --login 12345 --password '***' --server Exness-MT5Real
  python mt_gateway.py --backend ea  --token MAT_KHAU            # MT4 hoặc MT5: gắn EA PyEA_Bridge vào một biểu đồ

Giao thức JSON (app gọi, header `Authorization: Bearer <token>`):
  GET  /v1/ping /v1/symbols /v1/tick?symbol= /v1/candles?symbol&tf&count[&end] /v1/account /v1/positions /v1/orders /v1/spec?symbol= /v1/deals?since=
       /v1/deals_by_position?position_id=   mọi deal (mở + đóng) của MỘT vị thế - giá khớp THẬT của đúng ticket đó, không phụ thuộc cửa sổ thời gian
       /v1/history?since=[&until=]          mọi deal của tài khoản (giao dịch + nạp/rút + credit...) với profit/commission/swap/fee TÁCH RIÊNG và `kind`
                                            (trade|balance|credit|other) - app dựng «Lịch sử» kiểu MT5 (Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư)
  POST /v1/market {symbol,side,volume,comment} /v1/close {position_id,volume} /v1/pending {symbol,side,kind,volume,price,stop_price,expiry}
       /v1/modify {order_id,price,sl,tp} /v1/cancel {order_id}
       /v1/modify_position {position_id,sl,tp}   SL/TP gắn lên đúng ticket (MT5: TRADE_ACTION_SLTP; MT4: OrderModify). 0 = gỡ mức đó
  /v1/positions mỗi vị thế có thêm: comment (app chỉ đụng vị thế mang comment 'pyea'), profit, swap, price_now (số do SÀN tính: contract size, quy đổi tiền, swap).
  /v1/ping trả `features` (sltp, posdeals, comment, history): app chỉ bật SL/TP native khi đủ {sltp, comment}; cổng/EA bản cũ thiếu thì app tự giữ SL/TP và nói rõ.
  Mọi thời gian là epoch UTC (giây). Lỗi: {"ok": false, "error": "...", "code": "..."}.
Backend ea thêm: POST /ea/poll (EA gọi, header X-PyEA-Token) - xem PyEA_Bridge.mq5/.mq4. EA báo khả năng trong HELLO (…|sltp,posdeals,comment,history);
  lệnh cổng→EA thêm `sltp`, `posdeals`, `history`; EA→cổng thêm dòng `PDEALS|cid|…` và `HIST|cid|id,time,kind,symbol,side,qty,price,entry,position,order,profit,commission,swap,fee,comment;…`.

BẢO MẬT: đặt --token dài, chạy sau TLS (--cert/--key) hoặc qua Tailscale/WireGuard/SSH tunnel; KHÔNG mở thẳng cổng ra Internet không mã hoá.
"""
import argparse
import hmac
import json
import re
import ssl
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class GwError(Exception):
    def __init__(self, msg, code="", status=200):
        Exception.__init__(self, msg)
        self.code, self.status = code, status


def tf_name(tf):
    """'15m' -> 'M15', '1h' -> 'H1', '1d' -> 'D1', '1w' -> 'W1', '1mo' -> 'MN1'."""
    m = re.fullmatch(r"(\d+)(mo|m|h|d|w)", str(tf).strip().lower())
    if not m:
        raise GwError("khung thời gian không hợp lệ: %s" % tf, "BAD_TF", 400)
    n, u = m.group(1), m.group(2)
    return {"m": "M", "h": "H", "d": "D", "w": "W", "mo": "MN"}[u] + n


def tf_minutes(tf):
    m = re.fullmatch(r"(\d+)(mo|m|h|d|w)", str(tf).strip().lower())
    if not m:
        raise GwError("khung thời gian không hợp lệ: %s" % tf, "BAD_TF", 400)
    return int(m.group(1)) * {"m": 1, "h": 60, "d": 1440, "w": 10080, "mo": 43200}[m.group(2)]


# =========================================================================================== backend MetaTrader5 (python)
class Mt5Backend:
    DONE = (10008, 10009, 10010)

    def __init__(self, mt5=None, login=None, password=None, server=None, path=None, server_offset=None):
        if mt5 is None:
            try:
                import MetaTrader5 as mt5                    # noqa: N813
            except ImportError:
                raise GwError("Chưa cài gói MetaTrader5: pip install MetaTrader5 (chỉ chạy trên Windows, cần MT5 đã cài)")
        self.mt5 = mt5
        self.lock = threading.RLock()
        kw = {}
        if path:
            kw["path"] = path
        if login:
            kw.update(login=int(login), password=password or "", server=server or "")
        if not mt5.initialize(**kw):
            raise GwError("MT5 initialize() thất bại: %s" % (mt5.last_error(),))
        self.offset = server_offset                          # broker time - UTC (giây). None = tự dò khi có tick tươi
        self._off_retry = 0.0
        self._selected = set()

    # ---- tiện ích ----
    def _call(self, fn, *a, **k):
        with self.lock:
            return fn(*a, **k)

    def _select(self, symbol):
        if symbol not in self._selected:
            if not self._call(self.mt5.symbol_select, symbol, True):
                raise GwError("Không có mã %s trên tài khoản này" % symbol, "NO_SYMBOL", 404)
            self._selected.add(symbol)

    def _detect_offset(self, tick_time):
        d = tick_time - time.time()
        off = round(d / 900.0) * 900.0
        if abs(d - off) < 300:                               # tick tươi: phần dư nhỏ -> tin
            self.offset = off
        return self.offset or 0.0

    def _off(self):
        """broker time - UTC. Chưa biết (chưa có tick tươi nào đi qua cổng) -> tự dò MỘT lần mỗi 30 giây từ tick của mã đang theo dõi: nếu không, mở LỊCH SỬ ngay sau khi
        cổng khởi động sẽ hỏi MT5 sai múi giờ (lệch cả giờ máy chủ) và BỎ SÓT các lệnh vừa đóng. Không dò được (thị trường đóng cửa, tick cũ) -> 0; đặt cứng bằng --server-offset-hours."""
        if self.offset is None and time.time() >= self._off_retry:
            self._off_retry = time.time() + 30.0
            try:
                self._probe_offset()
            except Exception:                                # noqa: BLE001 - dò hỏng thì dùng 0, không làm hỏng yêu cầu đang làm
                pass
        return self.offset if self.offset is not None else 0.0

    def _probe_offset(self):
        names = list(self._selected)
        get = getattr(self.mt5, "symbols_get", None)
        if get is not None:
            names += [x.name for x in list(self._call(get) or ())[:200] if getattr(x, "select", True)]
        for n in names[:8]:
            t = self._call(self.mt5.symbol_info_tick, n)
            if t is not None and getattr(t, "time", 0):
                self._detect_offset(float(t.time))
                if self.offset is not None:
                    return

    def _fill_mode(self, symbol):
        info = self._call(self.mt5.symbol_info, symbol)
        fm = getattr(info, "filling_mode", 0) if info else 0
        if fm & 2:
            return self.mt5.ORDER_FILLING_IOC
        if fm & 1:
            return self.mt5.ORDER_FILLING_FOK
        return self.mt5.ORDER_FILLING_RETURN

    NO_CHANGES = 10025        # TRADE_RETCODE_NO_CHANGES: «yêu cầu không có thay đổi nào» (tài liệu MQL5) - sửa SL/TP về đúng giá trị đang có = đã đạt mục tiêu

    def _send(self, req, what, also_ok=()):
        res = self._call(self.mt5.order_send, req)
        if res is None:
            raise GwError("%s: order_send trả None (%s)" % (what, self.mt5.last_error()), "SEND_NONE")
        if res.retcode not in self.DONE and res.retcode not in also_ok:
            raise GwError("MT5 từ chối %s: retcode %s %s" % (what, res.retcode, getattr(res, "comment", "")), str(res.retcode))
        return res

    # ---- dữ liệu ----
    FEATURES = ["sltp", "posdeals", "comment", "history"]      # khả năng cổng này có: sửa SL/TP theo ticket, deal theo vị thế, comment trên vị thế

    def ping(self):
        return {"backend": "mt5", "features": self.FEATURES}

    def symbols(self):
        return {"symbols": sorted(s.name for s in (self._call(self.mt5.symbols_get) or []))}

    def tick(self, symbol):
        self._select(symbol)
        t = self._call(self.mt5.symbol_info_tick, symbol)
        if t is None or not t.bid or not t.ask:
            raise GwError("Chưa có giá %s" % symbol, "NO_TICK", 503)
        raw = getattr(t, "time_msc", 0) / 1000.0 or float(t.time)
        off = self._detect_offset(raw)
        return {"bid": t.bid, "ask": t.ask, "time": raw - off}

    def candles(self, symbol, tf, count, end=None):
        self._select(symbol)
        tfc = getattr(self.mt5, "TIMEFRAME_" + tf_name(tf), None)
        if tfc is None:
            raise GwError("MT5 không có khung %s" % tf, "BAD_TF", 400)
        count = max(1, min(int(count), 5000))
        if end is None:
            rates = self._call(self.mt5.copy_rates_from_pos, symbol, tfc, 0, count)
        else:
            from datetime import datetime, timezone
            rates = self._call(self.mt5.copy_rates_from, symbol, tfc, datetime.fromtimestamp(float(end) + self._off(), timezone.utc), count)
        if rates is None:
            raise GwError("copy_rates thất bại: %s" % (self.mt5.last_error(),), "NO_RATES", 503)
        off = self._off()
        return {"candles": [[float(r["time"]) - off, float(r["open"]), float(r["high"]), float(r["low"]), float(r["close"]),
                             float(r["tick_volume"])] for r in rates]}

    def account(self):
        a = self._call(self.mt5.account_info)
        if a is None:
            raise GwError("account_info thất bại: %s" % (self.mt5.last_error(),), "NO_ACCOUNT", 503)
        mode = getattr(a, "margin_mode", None)
        out = {"balance": a.balance, "equity": a.equity, "margin": a.margin, "free_margin": a.margin_free, "leverage": a.leverage,
               "currency": a.currency, "platform": "MT5", "hedging": None if mode is None else (mode == getattr(self.mt5, "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING", 2))}
        for k, attr in (("margin_level", "margin_level"), ("credit", "credit"), ("profit", "profit")):       # account_info(): margin_level, credit, profit (tài liệu MetaTrader5)
            if getattr(a, attr, None) is not None:
                out[k] = getattr(a, attr)
        return out

    def positions(self):
        off, out = self._off(), []
        for p in self._call(self.mt5.positions_get) or []:
            out.append({"id": str(p.ticket), "symbol": p.symbol, "side": "buy" if p.type == 0 else "sell", "volume": p.volume,
                        "price": p.price_open, "sl": p.sl, "tp": p.tp, "time": float(p.time) - off,
                        "identifier": str(getattr(p, "identifier", p.ticket)), "comment": str(getattr(p, "comment", "") or ""),
                        # lãi/lỗ do chính MT5 tính (đã gồm contract size, quy đổi tiền tệ): profit KHÔNG gồm swap; MT5 python không có hoa hồng theo vị thế
                        "profit": float(getattr(p, "profit", 0.0) or 0.0), "swap": float(getattr(p, "swap", 0.0) or 0.0),
                        "price_now": float(getattr(p, "price_current", 0.0) or 0.0)})
        return {"positions": out}

    KIND = {2: ("buy", "limit"), 3: ("sell", "limit"), 4: ("buy", "stop"), 5: ("sell", "stop"), 6: ("buy", "stop_limit"), 7: ("sell", "stop_limit")}

    def orders(self):
        out = []
        for o in self._call(self.mt5.orders_get) or []:
            if o.type not in self.KIND:
                continue
            side, kind = self.KIND[o.type]
            out.append({"id": str(o.ticket), "symbol": o.symbol, "side": side, "kind": kind, "volume": o.volume_current,
                        "price": o.price_open, "sl": o.sl, "tp": o.tp})                 # price = giá chính (giá KÍCH HOẠT với stop_limit)
        return {"orders": out}

    def spec(self, symbol):
        self._select(symbol)
        i = self._call(self.mt5.symbol_info, symbol)
        if i is None:
            raise GwError("Không có thông tin mã %s" % symbol, "NO_SYMBOL", 404)
        return {"volume_min": i.volume_min, "volume_max": i.volume_max, "volume_step": i.volume_step, "digits": i.digits}

    # ENUM_DEAL_ENTRY / ENUM_DEAL_REASON (tài liệu MQL5 «Deal Properties»)
    ENTRY = {0: "IN", 1: "OUT", 2: "INOUT", 3: "OUT_BY"}
    REASON = {0: "client", 1: "mobile", 2: "web", 3: "expert", 4: "sl", 5: "tp", 6: "so", 7: "rollover", 8: "vmargin", 9: "split", 10: "corporate_action"}

    def _deal_row(self, d, off):
        return {"id": str(d.ticket), "time": float(d.time) - off, "symbol": d.symbol, "side": "buy" if d.type == 0 else "sell",
                "qty": d.volume, "price": d.price, "fee": float(getattr(d, "commission", 0)) + float(getattr(d, "swap", 0)), "pnl": d.profit,
                "order_id": str(d.order), "position_id": str(getattr(d, "position_id", "") or ""),
                "entry": self.ENTRY.get(getattr(d, "entry", None), ""), "reason": self.REASON.get(getattr(d, "reason", None), "")}

    def deals(self, since):
        from datetime import datetime, timezone
        off = self._off()
        a = datetime.fromtimestamp(float(since) + off, timezone.utc)
        b = datetime.fromtimestamp(time.time() + off + 86400, timezone.utc)
        return {"deals": [self._deal_row(d, off) for d in self._call(self.mt5.history_deals_get, a, b) or [] if d.type in (0, 1)]}

    def deals_by_position(self, position_id):
        """history_deals_get(position=ticket): mọi deal (mở + đóng) của MỘT vị thế - không phụ thuộc cửa sổ thời gian."""
        off = self._off()
        rows = self._call(self.mt5.history_deals_get, position=int(position_id)) or []
        return {"deals": [self._deal_row(d, off) for d in rows if d.type in (0, 1)]}

    HISTORY_MAX = 20000

    def history(self, since, until=None):
        """Mọi deal từ `since` tới `until` (MT5: history_deals_get(from, to) gồm cả deal BALANCE/CREDIT...): profit/commission/swap/fee TÁCH RIÊNG và `kind`
        (trade|balance|credit|other) để app tính «Lợi nhuận / Tiền nạp / Phí qua đêm / Phí trung gian» đúng định nghĩa của MT5."""
        from datetime import datetime, timezone
        off, mt = self._off(), self.mt5
        a = datetime.fromtimestamp(float(since) + off, timezone.utc)
        b = datetime.fromtimestamp(float(until or time.time() + 86400) + off, timezone.utc)
        out = []
        for d in self._call(mt.history_deals_get, a, b) or []:
            ty = d.type
            if ty in (mt.DEAL_TYPE_BUY, mt.DEAL_TYPE_SELL):
                kind = "trade"
            elif ty == mt.DEAL_TYPE_BALANCE:
                kind = "balance"
            elif ty == mt.DEAL_TYPE_CREDIT:
                kind = "credit"
            else:
                kind = "other"
            row = self._deal_row(d, off) if kind == "trade" else {"id": str(d.ticket), "time": float(d.time) - off, "symbol": getattr(d, "symbol", "") or "", "side": "",
                                                                  "qty": 0.0, "price": 0.0, "order_id": str(getattr(d, "order", "") or ""),
                                                                  "position_id": str(getattr(d, "position_id", "") or ""), "entry": ""}
            row.update(kind=kind, profit=float(d.profit), commission=float(getattr(d, "commission", 0.0) or 0.0), swap=float(getattr(d, "swap", 0.0) or 0.0),
                       fee=float(getattr(d, "fee", 0.0) or 0.0), comment=str(getattr(d, "comment", "") or ""))
            out.append(row)
            if len(out) >= self.HISTORY_MAX:
                break
        return {"deals": out}

    # ---- giao dịch ----
    def market(self, symbol, side, volume, comment=""):
        self._select(symbol)
        t = self._call(self.mt5.symbol_info_tick, symbol)
        if t is None:
            raise GwError("Chưa có giá %s" % symbol, "NO_TICK", 503)
        mt = self.mt5
        req = {"action": mt.TRADE_ACTION_DEAL, "symbol": symbol, "volume": float(volume), "type": mt.ORDER_TYPE_BUY if side == "buy" else mt.ORDER_TYPE_SELL,
               "price": t.ask if side == "buy" else t.bid, "deviation": 20, "magic": 7001, "comment": (comment or "pyea")[:25],
               "type_time": mt.ORDER_TIME_GTC, "type_filling": self._fill_mode(symbol)}
        res = self._send(req, "lệnh thị trường")
        pid = ""
        for p in self._call(self.mt5.positions_get, symbol=symbol) or []:
            if str(p.ticket) == str(res.order) or str(getattr(p, "identifier", "")) == str(res.order):
                pid = str(p.ticket)
        return {"order_id": str(res.order), "position_id": pid, "price": res.price or None, "volume": res.volume or float(volume)}

    def close(self, position_id, volume=None):
        mt = self.mt5
        ps = self._call(mt.positions_get, ticket=int(position_id))
        if not ps:
            raise GwError("Không có vị thế #%s" % position_id, "NO_POSITION", 404)
        p = ps[0]
        t = self._call(mt.symbol_info_tick, p.symbol)
        buy = p.type == 0
        req = {"action": mt.TRADE_ACTION_DEAL, "symbol": p.symbol, "position": int(position_id), "volume": float(volume or p.volume),
               "type": mt.ORDER_TYPE_SELL if buy else mt.ORDER_TYPE_BUY, "price": t.bid if buy else t.ask, "deviation": 20, "magic": 7001,
               "comment": "pyea close", "type_time": mt.ORDER_TIME_GTC, "type_filling": self._fill_mode(p.symbol)}
        res = self._send(req, "đóng vị thế")
        return {"order_id": str(res.order), "position_id": str(position_id), "price": res.price or None, "volume": res.volume or float(volume or p.volume)}

    PTYPE = {("buy", "limit"): "ORDER_TYPE_BUY_LIMIT", ("sell", "limit"): "ORDER_TYPE_SELL_LIMIT", ("buy", "stop"): "ORDER_TYPE_BUY_STOP",
             ("sell", "stop"): "ORDER_TYPE_SELL_STOP", ("buy", "stop_limit"): "ORDER_TYPE_BUY_STOP_LIMIT",
             ("sell", "stop_limit"): "ORDER_TYPE_SELL_STOP_LIMIT"}

    def pending(self, symbol, side, kind, volume, price, stop_price=0.0, expiry=0.0, comment=""):
        self._select(symbol)
        mt = self.mt5
        name = self.PTYPE.get((side, kind))
        if not name or not hasattr(mt, name):
            raise GwError("MT5 không có lệnh chờ %s %s" % (side, kind), "BAD_KIND", 400)
        req = {"action": mt.TRADE_ACTION_PENDING, "symbol": symbol, "volume": float(volume), "type": getattr(mt, name), "deviation": 20, "magic": 7001,
               "comment": (comment or "pyea")[:25], "type_filling": mt.ORDER_FILLING_RETURN}
        if kind == "stop_limit":
            req["price"], req["stoplimit"] = float(stop_price), float(price)        # MT5: price = giá KÍCH HOẠT, stoplimit = giá limit
        else:
            req["price"] = float(price)
        if expiry:
            req["type_time"], req["expiration"] = mt.ORDER_TIME_SPECIFIED, int(float(expiry) + self._off())
        else:
            req["type_time"] = mt.ORDER_TIME_GTC
        res = self._send(req, "lệnh chờ")
        return {"order_id": str(res.order)}

    def modify(self, order_id, price=None, sl=None, tp=None):
        mt = self.mt5
        os_ = self._call(mt.orders_get, ticket=int(order_id))
        if not os_:
            raise GwError("Không có lệnh chờ #%s" % order_id, "NO_ORDER", 404)
        o = os_[0]
        req = {"action": mt.TRADE_ACTION_MODIFY, "order": int(order_id), "price": float(price) if price is not None else o.price_open,
               "sl": float(sl) if sl is not None else o.sl, "tp": float(tp) if tp is not None else o.tp, "type_time": mt.ORDER_TIME_GTC}
        self._send(req, "sửa lệnh chờ")
        return {}

    def cancel(self, order_id):
        self._send({"action": self.mt5.TRADE_ACTION_REMOVE, "order": int(order_id)}, "huỷ lệnh chờ")
        return {}

    def modify_position(self, position_id, sl, tp):
        """TRADE_ACTION_SLTP (tài liệu MQL5: cần action, symbol, position, sl, tp). 0 = không đặt mức (quy ước MT; tài liệu không nói rõ -> `selfcheck --trade`
        kiểm trên demo). Không thay đổi gì (10025) coi như thành công: SL/TP đã đúng giá trị mong muốn."""
        mt = self.mt5
        ps = self._call(mt.positions_get, ticket=int(position_id))
        if not ps:
            raise GwError("Không có vị thế #%s" % position_id, "NO_POSITION", 404)
        self._send({"action": mt.TRADE_ACTION_SLTP, "symbol": ps[0].symbol, "position": int(position_id), "sl": float(sl or 0.0), "tp": float(tp or 0.0),
                    "magic": 7001}, "sửa SL/TP vị thế", also_ok=(self.NO_CHANGES,))
        return {}


# =========================================================================================== backend EA relay (MT4/MT5)
def _f(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def _pos_stats(p):
    """POS|id|sym|side|vol|price|sl|tp|time|comment|profit|swap|price_now|commission - các trường lãi/lỗ là TUỲ CHỌN (EA bản cũ không gửi -> không có khoá)."""
    out = {}
    for k, i in (("profit", 10), ("swap", 11), ("price_now", 12), ("commission", 13)):
        if len(p) > i and p[i] != "":
            out[k] = _f(p[i])
    return out


def _deal_fields(f):
    """[id, time, symbol, side, qty, price, fee, pnl, order_id, position_id, entry, reason] (các trường sau order_id có thể vắng ở EA bản cũ)."""
    g = lambda i: f[i] if len(f) > i else ""
    return {"id": f[0], "time": _f(g(1)), "symbol": g(2), "side": g(3), "qty": _f(g(4)), "price": _f(g(5)), "fee": _f(g(6)), "pnl": _f(g(7)),
            "order_id": g(8), "position_id": g(9), "entry": g(10), "reason": g(11)}


class EaRelayBackend:
    """Terminal MT4/MT5 chạy EA PyEA_Bridge; EA gọi /ea/poll mỗi ~250ms: đẩy trạng thái lên, nhận lệnh về, trả kết quả."""
    STALE = 15.0

    def __init__(self, cmd_timeout=20.0):
        self.cv = threading.Condition()
        self.state = {"account": None, "ticks": {}, "positions": [], "orders": [], "specs": {}, "symbols": [], "deals": {}, "platform": "", "login": "", "caps": []}
        self.seen = 0.0
        self.watch = set()
        self.queue, self.results, self.n = [], {}, 0
        self.cmd_timeout = cmd_timeout

    # ---- phía EA ----
    def poll(self, body):
        out = []
        with self.cv:
            self.seen = time.time()
            st = self.state
            pos_n = ord_n = None
            new_pos, new_ord = [], []
            for line in body.splitlines():
                p = line.split("|")
                k = p[0]
                try:
                    if k == "HELLO":
                        st["platform"], st["login"] = p[1], p[3] if len(p) > 3 else ""
                        st["caps"] = sorted(x for x in (p[4] if len(p) > 4 else "").split(",") if x)       # EA bản cũ không khai -> rỗng
                    elif k == "ACCT":
                        h = int(p[7]) if len(p) > 7 else -1
                        st["account"] = {"balance": _f(p[1]), "equity": _f(p[2]), "margin": _f(p[3]), "free_margin": _f(p[4]), "leverage": _f(p[5], 1.0),
                                         "currency": p[6], "hedging": None if h < 0 else bool(h)}
                        if len(p) > 8 and p[8] != "":                              # EA bản mới gửi thêm credit (trường 9)
                            st["account"]["credit"] = _f(p[8])
                    elif k == "SYMS":
                        st["symbols"] = [s for s in p[1].split(",") if s]
                    elif k == "TICK":
                        st["ticks"][p[1]] = (_f(p[2]), _f(p[3]), _f(p[4]))
                    elif k == "POSALL":
                        pos_n, new_pos = int(p[1]), []
                    elif k == "POS":
                        new_pos.append({"id": p[1], "symbol": p[2], "side": p[3], "volume": _f(p[4]), "price": _f(p[5]), "sl": _f(p[6]), "tp": _f(p[7]),
                                        "time": _f(p[8]), "comment": p[9] if len(p) > 9 else "", **_pos_stats(p)})
                    elif k == "ORDALL":
                        ord_n, new_ord = int(p[1]), []
                    elif k == "ORD":
                        new_ord.append({"id": p[1], "symbol": p[2], "side": p[3], "kind": p[4], "volume": _f(p[5]), "price": _f(p[6]), "sl": _f(p[7]),
                                        "tp": _f(p[8])})
                    elif k == "SPEC":
                        st["specs"][p[1]] = {"volume_min": _f(p[2]), "volume_max": _f(p[3]), "volume_step": _f(p[4])}
                    elif k == "DEAL":
                        st["deals"][p[1]] = _deal_fields(p[1:])
                    elif k == "HIST":                                            # HIST|cmd_id|row;row;... (row: id,time,kind,symbol,side,qty,price,entry,position,order,profit,commission,swap,fee,comment)
                        rows = []
                        for seg in (p[2] if len(p) > 2 else "").split(";"):
                            f = seg.split(",")
                            if len(f) >= 14:
                                rows.append({"id": f[0], "time": _f(f[1]), "kind": f[2], "symbol": f[3], "side": f[4], "qty": _f(f[5]), "price": _f(f[6]),
                                             "entry": f[7], "position_id": f[8], "order_id": f[9], "profit": _f(f[10]), "commission": _f(f[11]), "swap": _f(f[12]),
                                             "fee": _f(f[13]), "comment": f[14] if len(f) > 14 else ""})
                        self.results[p[1]] = {"ok": True, "deals": rows}
                    elif k == "PDEALS":                                          # PDEALS|cmd_id|deal;deal;... (mỗi deal: trường cách nhau dấu phẩy, như DEAL)
                        rows = [_deal_fields(seg.split(",")) for seg in (p[2] if len(p) > 2 else "").split(";") if seg]
                        for r in rows:
                            st["deals"].setdefault(r["id"], r)
                        self.results[p[1]] = {"ok": True, "deals": rows}
                    elif k == "RES":
                        self.results[p[1]] = {"ok": p[2] == "1", "code": p[3], "order": p[4], "position": p[5], "price": _f(p[6]) or None, "volume": _f(p[7]),
                                              "message": p[8] if len(p) > 8 else ""}
                    elif k == "BARS":
                        rows = []
                        for seg in (p[4] if len(p) > 4 else "").split(";"):
                            f = seg.split(",")
                            if len(f) >= 6:
                                rows.append([_f(f[0]), _f(f[1]), _f(f[2]), _f(f[3]), _f(f[4]), _f(f[5])])
                        self.results[p[1]] = {"ok": True, "bars": rows}
                except (IndexError, ValueError):
                    continue                                                     # dòng hỏng: bỏ qua, không làm sập cả lượt
            if pos_n is not None and len(new_pos) == pos_n:
                st["positions"] = new_pos
            if ord_n is not None and len(new_ord) == ord_n:
                st["orders"] = new_ord
            self.cv.notify_all()
            out.append("OK|%d" % int(time.time()))
            if self.watch:
                out.append("WATCH|" + ",".join(sorted(self.watch)))
            sent, self.queue = self.queue, []
            for c in sent:
                out.append("CMD|%s|%s|%s" % (c["id"], c["action"], "|".join(str(x) for x in c["args"])))
        return "\n".join(out) + "\n"

    # ---- phía app ----
    def _alive(self):
        if time.time() - self.seen > self.STALE:
            raise GwError("EA PyEA_Bridge chưa kết nối (hoặc đã mất %d giây). Gắn EA vào biểu đồ, bật AutoTrading và cho phép WebRequest tới địa chỉ cổng." %
                          self.STALE, "EA_OFFLINE", 503)

    def _cmd(self, action, args, timeout=None):
        self._alive()
        with self.cv:
            self.n += 1
            cid = "c%d" % self.n
            self.queue.append({"id": cid, "action": action, "args": args})
            end = time.monotonic() + (timeout or self.cmd_timeout)
            while cid not in self.results:
                left = end - time.monotonic()
                if left <= 0:
                    self.queue = [c for c in self.queue if c["id"] != cid]
                    raise GwError("EA không phản hồi lệnh %s sau %.0fs" % (action, timeout or self.cmd_timeout), "EA_TIMEOUT", 504)
                self.cv.wait(min(left, 0.5))
            return self.results.pop(cid)

    def _need(self, res, what):
        if not res.get("ok"):
            raise GwError("Terminal từ chối %s: %s %s" % (what, res.get("code", ""), res.get("message", "")), str(res.get("code", "")))
        return res

    def ping(self):
        self._alive()
        return {"backend": "ea", "platform": self.state["platform"], "features": list(self.state["caps"])}

    def symbols(self):
        self._alive()
        return {"symbols": sorted(self.state["symbols"])}

    def tick(self, symbol):
        self._alive()
        with self.cv:
            if symbol not in self.watch:
                self.watch.add(symbol)
            end = time.monotonic() + 4.0
            while symbol not in self.state["ticks"]:
                left = end - time.monotonic()
                if left <= 0:
                    raise GwError("Chưa có giá %s từ EA (mã có trong Market Watch chưa?)" % symbol, "NO_TICK", 503)
                self.cv.wait(min(left, 0.5))
            b, a, t = self.state["ticks"][symbol]
        return {"bid": b, "ask": a, "time": t}

    def candles(self, symbol, tf, count, end=None):
        res = self._need(self._cmd("bars", [symbol, tf_minutes(tf), int(count), int(end or 0)]), "lấy nến")
        return {"candles": res.get("bars", [])}

    def account(self):
        self._alive()
        if not self.state["account"]:
            raise GwError("EA chưa gửi thông tin tài khoản", "NO_ACCOUNT", 503)
        return dict(self.state["account"], platform=self.state["platform"])

    def positions(self):
        self._alive()
        return {"positions": list(self.state["positions"])}

    def orders(self):
        self._alive()
        return {"orders": list(self.state["orders"])}

    def spec(self, symbol):
        self._alive()
        sp = self.state["specs"].get(symbol)
        if sp is None:
            self._need(self._cmd("spec", [symbol]), "lấy thông số mã")
            sp = self.state["specs"].get(symbol)
        if sp is None:
            raise GwError("EA không trả thông số %s" % symbol, "NO_SPEC", 503)
        return dict(sp)

    def deals(self, since):
        self._alive()
        return {"deals": sorted((d for d in self.state["deals"].values() if d["time"] >= float(since)), key=lambda d: d["time"])}

    def market(self, symbol, side, volume, comment=""):
        r = self._need(self._cmd("market", [symbol, side, volume, comment or "pyea"]), "lệnh thị trường")
        return {"order_id": r["order"], "position_id": r["position"], "price": r["price"], "volume": r["volume"] or float(volume)}

    def close(self, position_id, volume=None):
        r = self._need(self._cmd("close", [position_id, volume or 0]), "đóng vị thế")
        return {"order_id": r["order"], "position_id": str(position_id), "price": r["price"], "volume": r["volume"] or volume}

    def pending(self, symbol, side, kind, volume, price, stop_price=0.0, expiry=0.0, comment=""):
        r = self._need(self._cmd("pending", [symbol, side, kind, volume, price, stop_price or 0, int(expiry or 0), comment or "pyea"]), "lệnh chờ")
        return {"order_id": r["order"]}

    def modify(self, order_id, price=None, sl=None, tp=None):
        self._need(self._cmd("modify", [order_id, "" if price is None else price, "" if sl is None else sl, "" if tp is None else tp]), "sửa lệnh chờ")
        return {}

    def cancel(self, order_id):
        self._need(self._cmd("cancel", [order_id]), "huỷ lệnh chờ")
        return {}

    def history(self, since, until=None):
        self._alive()
        if "history" not in self.state["caps"]:
            raise GwError("EA PyEA_Bridge bản cũ chưa hỗ trợ lịch sử đầy đủ - hãy copy lại file .mq5/.mq4 mới, biên dịch (F7) và gắn lại vào biểu đồ", "EA_OLD", 501)
        r = self._need(self._cmd("history", [int(since), int(until or 0)], timeout=60.0), "lấy lịch sử")
        return {"deals": r.get("deals", [])}

    def modify_position(self, position_id, sl, tp):
        self._alive()
        if "sltp" not in self.state["caps"]:
            raise GwError("EA PyEA_Bridge bản cũ chưa hỗ trợ sửa SL/TP theo vị thế - hãy copy lại file .mq5/.mq4 mới, biên dịch (F7) và gắn lại vào biểu đồ", "EA_OLD", 501)
        self._need(self._cmd("sltp", [position_id, sl or 0, tp or 0]), "sửa SL/TP vị thế")
        return {}

    def deals_by_position(self, position_id):
        """Hỏi EA lịch sử của đúng vị thế (HistorySelectByPosition) - đủ cả deal cũ hơn cửa sổ EA đang đẩy; EA bản cũ không hiểu lệnh -> lọc từ deal đã nhận."""
        pid = str(position_id)
        rows = []
        self._alive()
        if "posdeals" in self.state["caps"]:
            rows = self._need(self._cmd("posdeals", [pid]), "lấy deal của vị thế").get("deals", [])
        have = {d["id"]: d for d in rows}
        for d in self.state["deals"].values():
            if d.get("position_id") == pid:
                have.setdefault(d["id"], d)
        return {"deals": sorted(have.values(), key=lambda d: d["time"])}


# =========================================================================================== HTTP
def make_handler(backend, token, webhook=None, trust_proxy=False):
    ea = backend if isinstance(backend, EaRelayBackend) else None

    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _json(self, obj, code=200):
            b = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def _auth(self, header, value):
            got = self.headers.get(header, "")
            if header == "Authorization" and got.lower().startswith("bearer "):
                got = got[7:]
            return (not token) or hmac.compare_digest(got.strip(), token)

        def _route(self, method):
            u = urllib.parse.urlparse(self.path)
            qs = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            if u.path == "/ea/poll" and method == "POST":
                if ea is None:
                    return self._json({"ok": False, "error": "gateway không chạy ở chế độ ea"}, 404)
                if not self._auth("X-PyEA-Token", token):
                    return self._json({"ok": False, "error": "sai token"}, 401)
                text = ea.poll(raw.decode("utf-8", "replace")).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(text)))
                self.end_headers()
                self.wfile.write(text)
                return
            if u.path == "/v1/webhook/tradingview" and method == "POST":
                # TradingView không gửi được header -> xác thực bằng secret trong JSON (xem pyea/webhook.py), KHÔNG dùng Bearer
                if webhook is None:
                    return self._json({"ok": False, "error": "webhook chưa bật (--webhook-secret)"}, 404)
                ip = self.client_address[0]
                if trust_proxy and self.headers.get("X-Forwarded-For"):
                    ip = self.headers["X-Forwarded-For"].split(",")[0].strip()
                st, res = webhook.handle(raw, ip, self.headers.get("X-PyEA-Signature", ""))
                return self._json(res, st)
            if not self._auth("Authorization", token):
                return self._json({"ok": False, "error": "sai token"}, 401)
            body = json.loads(raw) if raw else {}
            try:
                r = self._dispatch(method, u.path, qs, body)
            except GwError as e:
                return self._json({"ok": False, "error": str(e), "code": e.code}, e.status if e.status != 200 else 200)
            except (KeyError, ValueError, TypeError) as e:
                return self._json({"ok": False, "error": "yêu cầu không hợp lệ: %s" % e, "code": "BAD_REQUEST"}, 400)
            r = dict(r or {})
            r.setdefault("ok", True)
            self._json(r)

        def _dispatch(self, m, path, q, b):
            be = backend
            if m == "GET":
                if path == "/v1/ping": return be.ping()
                if path == "/v1/symbols": return be.symbols()
                if path == "/v1/tick": return be.tick(q["symbol"])
                if path == "/v1/candles": return be.candles(q["symbol"], q["tf"], int(q.get("count", 100)), float(q["end"]) if "end" in q else None)
                if path == "/v1/account": return be.account()
                if path == "/v1/positions": return be.positions()
                if path == "/v1/orders": return be.orders()
                if path == "/v1/spec": return be.spec(q["symbol"])
                if path == "/v1/deals": return be.deals(float(q.get("since", 0)))
                if path == "/v1/deals_by_position": return be.deals_by_position(q["position_id"])
                if path == "/v1/history": return be.history(float(q.get("since", 0)), float(q["until"]) if "until" in q else None)
            if m == "POST":
                if path == "/v1/market": return be.market(b["symbol"], b["side"], float(b["volume"]), b.get("comment", ""))
                if path == "/v1/close": return be.close(b["position_id"], b.get("volume"))
                if path == "/v1/pending":
                    return be.pending(b["symbol"], b["side"], b["kind"], float(b["volume"]), float(b["price"]), float(b.get("stop_price") or 0), float(b.get("expiry") or 0),
                                      b.get("comment", ""))
                if path == "/v1/modify": return be.modify(b["order_id"], b.get("price"), b.get("sl"), b.get("tp"))
                if path == "/v1/cancel": return be.cancel(b["order_id"])
                if path == "/v1/modify_position": return be.modify_position(b["position_id"], float(b.get("sl") or 0), float(b.get("tp") or 0))
            raise GwError("không có đường dẫn %s %s" % (m, path), "NOT_FOUND", 404)

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")
    return H


def serve(backend, host="127.0.0.1", port=8765, token="", cert=None, key=None, webhook=None, trust_proxy=False):
    srv = ThreadingHTTPServer((host, port), make_handler(backend, token, webhook, trust_proxy))
    if cert and key:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(cert, key)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    return srv


def main(argv=None):
    ap = argparse.ArgumentParser(description="PyEA MT Gateway")
    ap.add_argument("--backend", choices=["mt5", "ea"], required=True)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--token", default="", help="mật khẩu app dùng để gọi cổng (BẮT BUỘC khi mở ra ngoài localhost)")
    ap.add_argument("--cert")
    ap.add_argument("--key")
    ap.add_argument("--login")
    ap.add_argument("--password")
    ap.add_argument("--server")
    ap.add_argument("--path", help="đường dẫn terminal64.exe (backend mt5)")
    ap.add_argument("--server-offset-hours", type=float, default=None, help="chênh lệch giờ broker so với UTC (bỏ trống = tự dò)")
    ap.add_argument("--webhook-secret", default="", help="bật POST /v1/webhook/tradingview; secret ≥12 ký tự nằm trong JSON của alert")
    ap.add_argument("--webhook-ips", default="", help="IP cho phép, cách nhau dấu phẩy; 'tradingview' = 4 IP chính thức của TradingView")
    ap.add_argument("--webhook-symbols", default="", help="mã cho phép, cách nhau dấu phẩy (bỏ trống = mọi mã)")
    ap.add_argument("--webhook-max-volume", type=float, default=None)
    ap.add_argument("--webhook-symbol-map", default="", help="ánh xạ mã TradingView -> mã sàn, vd 'BINANCE:BTCUSDT=BTCUSD,XAUUSD=XAUUSDm' (tiền tố sàn và .P/1! tự bỏ)")
    ap.add_argument("--webhook-symbol-suffix", default="", help="hậu tố thêm vào mọi mã sau khi ánh xạ, vd '.m'")
    ap.add_argument("--webhook-dry-run", action="store_true", help="chỉ kiểm tra, KHÔNG đặt lệnh")
    ap.add_argument("--trust-proxy", action="store_true", help="lấy IP nguồn từ X-Forwarded-For (CHỈ khi đứng sau reverse proxy của bạn)")
    a = ap.parse_args(argv)
    if not a.token and a.host not in ("127.0.0.1", "localhost"):
        print("CẢNH BÁO: không đặt --token mà lại mở ra ngoài localhost - ai cũng đặt lệnh được!", file=sys.stderr)
    be = (Mt5Backend(login=a.login, password=a.password, server=a.server, path=a.path,
                     server_offset=None if a.server_offset_hours is None else a.server_offset_hours * 3600)
          if a.backend == "mt5" else EaRelayBackend())
    wh = None
    if a.webhook_secret:
        import os
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
        from pyea.webhook import WebhookCore, TV_IPS, gateway_executor
        ips = [x.strip() for x in a.webhook_ips.split(",") if x.strip()]
        ips = (list(TV_IPS) + [x for x in ips if x != "tradingview"]) if "tradingview" in ips else ips
        wh = WebhookCore(gateway_executor(be), a.webhook_secret, allowed_ips=ips or None,
                         allowed_symbols=[x for x in a.webhook_symbols.split(",") if x.strip()] or None,
                         max_volume=a.webhook_max_volume, dry_run=a.webhook_dry_run, async_exec=True,
                         symbol_map=dict(x.split("=", 1) for x in a.webhook_symbol_map.split(",") if "=" in x), symbol_suffix=a.webhook_symbol_suffix,
                         log=lambda m: print(m, file=sys.stderr))
    srv = serve(be, a.host, a.port, a.token, a.cert, a.key, wh, a.trust_proxy)
    print("PyEA MT Gateway (%s) lắng nghe %s://%s:%d" % (a.backend, "https" if a.cert else "http", a.host, a.port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
