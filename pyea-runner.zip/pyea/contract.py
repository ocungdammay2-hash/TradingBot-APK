"""
HỢP ĐỒNG giữa vỏ (engine/orders/sync/reconcile/protect) và các adapter sàn - MỘT nơi duy nhất mô tả "vỏ gọi gì, cần nhận lại gì".

Vì sao có file này: trước đây mỗi sàn được test riêng, nên lỗi kiểu `ExnBroker.history(since)` (vỏ gọi `history(since, symbols)`)
lọt qua 600 test mà chỉ lộ khi chạy tài khoản thật. Giờ:
  * `BROKER_CALLS` / `FEED_CALLS`  = các HÌNH DẠNG LỜI GỌI mà vỏ đang dùng (sao đúng từ orders.py, sync.py, reconcile.py,
    protect.py, engine.py, feeds.fetch_history). Adapter nào không nhận được một hình dạng -> `check_class` báo ngay.
  * `check_*_shape` = hình dạng DỮ LIỆU trả về (Fill, positions, pending_orders, order_result, Tick, Candle, history row).
  * tests/test_broker_contract.py chạy hai thứ trên MỌI adapter (kể cả adapter thêm sau - tự dò trong `adapters()`),
    pyea/selfcheck.py chạy lại đúng các hàm kiểm tra này trên sàn THẬT/demo bằng một lệnh.
Khi vỏ bắt đầu gọi broker theo cách mới: sửa ở ĐÂY trước, mọi adapter sẽ tự bị kiểm.
"""
import inspect

# tên hàm -> (bắt buộc?, [(args, kwargs), ...])   (self được bind là None)
BROKER_CALLS = {
    "prepare": (True, [(("BTCUSDT", 1.0), {}), (("BTCUSDT",), {})]),                              # engine.py:593
    "balance": (True, [((), {})]),                                                                # sync.py:120
    "positions": (True, [((), {})]),                                                              # reconcile.py:55
    "market_order": (True, [(("BTCUSDT", "buy", 1.0), {}),                                        # orders.py:241
                            (("BTCUSDT", "sell", 1.0), {"reduce_only": True})]),                  # orders.py:638
    "place_pending": (True, [(("BTCUSDT", "buy", "limit", 1.0, 100.0, None, 90.0, 110.0, None, "pyea-1"), {}),   # orders.py:370 (10 vị trí)
                             (("BTCUSDT", "sell", "stop", 1.0, 100.0), {})]),
    "cancel_pending": (True, [(("1", "BTCUSDT"), {}), (("1",), {})]),                             # orders.py:406
    "modify_pending": (True, [(("1", "BTCUSDT"), {"price": 1.0, "sl": 2.0, "tp": 3.0}), (("1",), {"price": 1.0})]),   # orders.py:470
    "pending_orders": (True, [(([("1", "BTCUSDT")],), {}), ((), {})]),                            # orders.py:537
    "order_result": (True, [(("1", "BTCUSDT"), {}), (("1",), {})]),                               # orders.py:553
    "history": (True, [((0.0, ["BTCUSDT"]), {}), ((0.0,), {}), ((), {})]),                        # sync.py:154  <- ExnBroker từng sai ở đây
    # tuỳ chọn: có thì phải đúng chữ ký (vỏ dùng hasattr/getattr)
    "account_flags": (False, [((), {})]),                                                         # orders.py:91
    "account_state": (False, [((), {})]),                                                         # orders.py _check_account_state: Số dư/Tài sản/Ký quỹ của SÀN
    "position_stats": (False, [((), {})]),                                                        # orders.py _check_position_stats: lãi/lỗ/swap từng vị thế của SÀN
    "account_history": (False, [((0.0,), {}), ((0.0, 1.0), {})]),                                 # brokerhist.fetch: lịch sử deal đầy đủ kiểu tab «Lịch sử» MT5
    "check_permissions": (False, [((), {})]),                                                     # engine.py:598
    "set_watch": (False, [((set(["BTCUSDT"]),), {})]),                                            # reconcile.py:53, sync.py:153
    "hedged_positions": (False, [((), {})]),
    "close_market": (False, [(("BTCUSDT", "buy", 1.0), {})]),
    "sync_protection": (False, [(("BTCUSDT", []), {})]),                                          # protect.py (_prot_apply): sync_protection(symbol, intents)
    "protection_orders": (False, [(("BTCUSDT",), {})]),                                           # protect.py:157
}

FEED_CALLS = {
    "tick": (True, [(("BTCUSDT",), {})]),                                                         # engine.py:693
    "history": (True, [(("BTCUSDT", "1m", 10), {}), (("BTCUSDT", "1m", 10, 1.7e9), {})]),        # engine.py:709, feeds.fetch_history
    "close": (True, [((), {})]),                                                                  # engine.py:664
    "symbols": (False, [((), {})]),
}

# thuộc tính khai báo khả năng (đọc bằng getattr, mặc định như vỏ dùng)
BROKER_ATTRS = {"supports_short": bool, "netting": bool, "spot_like": bool, "native_pending": (set, frozenset, list, tuple), "CLOSE_BY_REF": bool}
PENDING_KINDS = {"limit", "stop", "stop_limit"}
ORDER_STATES = {"open", "filled", "canceled", "expired", "rejected", "unknown"}
HISTORY_KEYS = ("id", "time", "symbol", "side", "qty", "price", "fee", "pnl")


def check_class(cls, calls):
    """Danh sách vấn đề chữ ký của một lớp adapter (rỗng = đạt)."""
    out = []
    for name, (required, shapes) in calls.items():
        fn = getattr(cls, name, None)
        if fn is None:
            if required:
                out.append("thiếu hàm bắt buộc %s()" % name)
            continue
        try:
            sig = inspect.signature(fn)
        except (TypeError, ValueError):
            continue
        for args, kw in shapes:
            try:
                sig.bind(None, *args, **kw)
            except TypeError as e:
                out.append("%s%s không nhận lời gọi của vỏ (%d đối số vị trí%s): %s" % (
                    name, sig, len(args), (" + " + ",".join(kw)) if kw else "", e))
    if calls is BROKER_CALLS and getattr(cls, "CLOSE_BY_REF", False):       # đóng theo ticket: orders.close_position gọi market_order(..., reduce_only=True, ref=...)
        for name, args, kw in (("market_order", ("BTCUSDT", "sell", 1.0), {"reduce_only": True, "ref": "1"}),
                               ("close_market", ("BTCUSDT", "buy", 1.0), {"ref": "1"})):
            fn = getattr(cls, name, None)
            if fn is None:
                out.append("CLOSE_BY_REF=True nhưng thiếu %s()" % name)
                continue
            try:
                inspect.signature(fn).bind(None, *args, **kw)
            except TypeError as e:
                out.append("CLOSE_BY_REF=True nhưng %s không nhận ref=: %s" % (name, e))
            except ValueError:
                pass
    return out


def check_broker_attrs(obj):
    out = []
    for k, typ in BROKER_ATTRS.items():
        if hasattr(obj, k):
            v = getattr(obj, k)
            if not isinstance(v, typ):
                out.append("thuộc tính %s phải là %s, đang là %r" % (k, typ, v))
    if hasattr(obj, "sync_protection"):
        from .protection import STYLES
        st = getattr(obj, "PROT_STYLE", None)
        if st not in STYLES:
            out.append("PROT_STYLE phải thuộc %s (có sync_protection), đang là %r" % (list(STYLES), st))
        elif st == "position":
            for fn in ("position_levels", "set_position_levels"):
                if not callable(getattr(obj, fn, None)):
                    out.append("PROT_STYLE='position' cần hàm nguyên thuỷ %s()" % fn)
        elif not callable(getattr(obj, "sync_steps", None)):
            out.append("PROT_STYLE=%r cần sync_steps(symbol, steps) và protection_orders(symbol)" % st)
    npend = getattr(obj, "native_pending", None) or ()
    bad = [k for k in npend if k not in PENDING_KINDS]
    if bad:
        out.append("native_pending chứa loại lạ %s (hợp lệ: %s)" % (bad, sorted(PENDING_KINDS)))
    return out


# ------------------------------------------------------------------------------------------ hình dạng dữ liệu trả về
def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and x == x


def check_fill(f):
    out = []
    if not (hasattr(f, "price") and hasattr(f, "qty")):
        return ["market_order phải trả Fill(price, qty), nhận %r" % (f,)]
    if not (_num(f.price) and f.price > 0):
        out.append("Fill.price phải > 0, nhận %r" % (f.price,))
    if not (_num(f.qty) and f.qty > 0):
        out.append("Fill.qty phải > 0, nhận %r" % (f.qty,))
    return out


def check_positions(d):
    if not isinstance(d, dict):
        return ["positions() phải trả dict {symbol: {qty, price}}, nhận %s" % type(d).__name__]
    out = []
    for sym, p in d.items():
        if not isinstance(p, dict) or not _num(p.get("qty")) or not _num(p.get("price")):
            out.append("positions()[%r] phải là {qty:số, price:số}, nhận %r" % (sym, p))
        elif abs(p["qty"]) < 1e-15:
            out.append("positions()[%r] có qty=0 (phải bỏ mã đã đóng hết)" % sym)
    return out


def check_pending(d):
    if not isinstance(d, dict):
        return ["pending_orders() phải trả dict {mã lệnh: thông tin}, nhận %s" % type(d).__name__]
    out = []
    for k, o in d.items():
        if not isinstance(k, str):
            out.append("khoá pending_orders() phải là str, nhận %r" % (k,))
        if not isinstance(o, dict):
            out.append("pending_orders()[%r] phải là dict" % (k,))
            continue
        miss = [f for f in ("symbol", "side", "price", "qty") if f not in o]
        if miss:
            out.append("pending_orders()[%r] thiếu khoá %s (có %s)" % (k, miss, sorted(o)))
        elif not (_num(o["price"]) and o["price"] > 0):
            out.append("pending_orders()[%r]['price'] phải là giá đặt/giá kích hoạt > 0 (lệnh stop: dùng giá kích hoạt), nhận %r" % (k, o["price"]))
    return out


def check_order_result(r):
    if r is None:
        return []                                         # None = 'không biết' -> vỏ suy từ chênh lệch vị thế (hợp lệ)
    if not isinstance(r, dict):
        return ["order_result() phải trả dict hoặc None, nhận %s" % type(r).__name__]
    st = r.get("state")
    if st not in ORDER_STATES:
        return ["order_result()['state'] phải thuộc %s, nhận %r" % (sorted(ORDER_STATES), st)]
    if st == "filled" and r.get("price") is not None and not (_num(r["price"]) and r["price"] > 0):
        return ["order_result filled có price không hợp lệ: %r" % (r["price"],)]
    return []


def check_protection_orders(rows):
    """protection_orders(): list lệnh/mức bảo vệ của vỏ đang sống [{id, side (chiều ĐÓNG), qty, + mức: (kind sl|tp|oco|pos, trigger) hoặc (sl, tp), tuỳ chọn ref}].
    protect.py chỉ dùng `levels_of` (sl, tp), `side`, `qty`, `ref`, `step` nên mọi phong cách (ladder/pair/position) cùng một định dạng."""
    from .protection import levels_of
    if not isinstance(rows, list):
        return ["protection_orders() phải trả list, nhận %s" % type(rows).__name__]
    out = []
    ids = set()
    for i, o in enumerate(rows):
        if not isinstance(o, dict):
            out.append("protection_orders()[%d] phải là dict" % i)
            continue
        miss = [k for k in ("id", "side", "qty") if k not in o]
        if miss:
            out.append("protection_orders()[%d] thiếu khoá %s (có %s)" % (i, miss, sorted(o)))
            continue
        if o["id"] in ids:
            out.append("protection_orders()[%d] id %r bị trùng" % (i, o["id"]))
        ids.add(o["id"])
        if "kind" in o and o["kind"] not in ("sl", "tp", "oco", "pos"):
            out.append("protection_orders()[%d]['kind'] phải là sl|tp|oco|pos, nhận %r" % (i, o["kind"]))
        if str(o["side"]).lower() not in ("buy", "sell"):
            out.append("protection_orders()[%d]['side'] phải là buy|sell, nhận %r" % (i, o["side"]))
        try:
            sl, tp = levels_of(o)
        except (TypeError, ValueError):
            out.append("protection_orders()[%d]: mức SL/TP không phải số: %r" % (i, o))
            continue
        if not (sl > 0 or tp > 0):
            out.append("protection_orders()[%d] phải có mức > 0 (kind sl|tp + trigger, hoặc sl/tp), nhận %r" % (i, o))
        elif o.get("kind") == "oco" and not (sl > 0 and tp > 0):
            out.append("protection_orders()[%d] kind=oco phải có sl và tp > 0, nhận sl=%r tp=%r" % (i, o.get("sl"), o.get("tp")))
        elif o.get("kind") == "pos" and not o.get("ref"):
            out.append("protection_orders()[%d] kind=pos phải có ref (ticket vị thế)" % i)
        if not (_num(o["qty"]) and o["qty"] > 0):
            out.append("protection_orders()[%d]['qty'] phải > 0: %r" % (i, o["qty"]))
    return out


def check_protection_result(res, intents):
    """sync_protection(symbol, intents) phải trả {"live": list, "covered": {pid: [legs]}, "errors": list}; covered chỉ nhắc pid/mức có trong intents."""
    if not isinstance(res, dict):
        return ["sync_protection() phải trả dict, nhận %s" % type(res).__name__]
    out = []
    for k, typ in (("live", list), ("covered", dict), ("errors", list)):
        if not isinstance(res.get(k), typ):
            out.append("sync_protection()['%s'] phải là %s, nhận %r" % (k, typ.__name__, res.get(k)))
    if out:
        return out
    out += check_protection_orders(res["live"])
    want = {it["pid"]: {k for k in ("sl", "tp") if it.get(k)} for it in intents}
    for pid, legs in res["covered"].items():
        if pid not in want:
            out.append("sync_protection()['covered'] có pid %r không nằm trong intents" % (pid,))
        elif not set(legs) <= want[pid]:
            out.append("sync_protection()['covered'][%r]=%r vượt quá mức vỏ yêu cầu %s" % (pid, legs, sorted(want[pid])))
    return out


def check_history_rows(rows):
    if not isinstance(rows, list):
        return ["history() phải trả list, nhận %s" % type(rows).__name__]
    out = []
    for i, r in enumerate(rows[:50]):
        if not isinstance(r, dict):
            out.append("history()[%d] phải là dict" % i)
            continue
        miss = [k for k in HISTORY_KEYS if k not in r]
        if miss:
            out.append("history()[%d] thiếu khoá %s" % (i, miss))
        elif not (_num(r["time"]) and r["time"] > 1e9 and _num(r["qty"]) and _num(r["price"]) and _num(r["pnl"]) and _num(r["fee"])):
            out.append("history()[%d] có giá trị số không hợp lệ: %r" % (i, {k: r[k] for k in HISTORY_KEYS}))
    ts = [r.get("time", 0) for r in rows if isinstance(r, dict)]
    if ts != sorted(ts):
        out.append("history() phải sắp xếp cũ -> mới")
    return out


def check_flags(d):
    if not isinstance(d, dict):
        return ["account_flags() phải trả dict, nhận %s" % type(d).__name__]
    out = []
    if "can_trade" in d and not isinstance(d["can_trade"], bool):
        out.append("account_flags()['can_trade'] phải là bool")
    if "currency" in d and not isinstance(d["currency"], str):
        out.append("account_flags()['currency'] phải là str")
    return out


def _isnum(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and x == x and abs(x) != float("inf")


def check_account_state(raw):
    """account_state() -> (vấn đề, đã chuẩn hoá). Chuẩn hoá bằng chính acctstate.normalize mà vỏ dùng; trường sàn không báo thì VẮNG (giao diện hiện «-»)."""
    from .acctstate import normalize
    if not isinstance(raw, dict):
        return ["account_state() phải trả dict, nhận %s" % type(raw).__name__], None
    st = normalize(raw)
    if st is None:
        return ["account_state() không có số dư/tài sản đọc được (khoá nhận: %s)" % sorted(raw)[:12]], None
    out = ["account_state()['%s'] phải là số, nhận %r" % (k, st[k]) for k in ("balance", "equity") if not _isnum(st.get(k))]
    return out, st


def check_position_stats(d):
    """position_stats() -> {ticket(str): {profit?, swap?, commission?, price?}} (trường nào sàn không báo thì VẮNG, không điền 0)."""
    if not isinstance(d, dict):
        return ["position_stats() phải trả dict {ticket: {...}}, nhận %s" % type(d).__name__]
    out = []
    for k, v in d.items():
        if not isinstance(k, str) or not k:
            out.append("position_stats() khoá phải là chuỗi ticket khác rỗng, nhận %r" % (k,))
        if not isinstance(v, dict) or not v:
            out.append("position_stats()[%r] phải là dict không rỗng" % (k,))
            continue
        bad = [f for f in v if f not in ("profit", "swap", "commission", "price") or not _isnum(v[f])]
        if bad:
            out.append("position_stats()[%r] có trường lạ/không phải số: %s" % (k, bad))
    return out[:6]


DEAL_KINDS = ("trade", "balance", "credit", "other")
DEAL_KEYS = ("id", "time", "kind", "symbol", "side", "qty", "price", "entry", "position_id", "order_id", "profit", "commission", "swap", "fee", "comment")


def check_history_deals(rows):
    """account_history() -> list deal theo hợp đồng pyea/brokerhist.py (đủ khoá, kiểu đúng, kind hợp lệ, deal giao dịch có mã + chiều)."""
    if not isinstance(rows, list):
        return ["account_history() phải trả list, nhận %s" % type(rows).__name__]
    out = []
    for i, r in enumerate(rows[:200]):
        if not isinstance(r, dict):
            out.append("account_history()[%d] phải là dict" % i)
            continue
        miss = [k for k in DEAL_KEYS if k not in r]
        if miss:
            out.append("account_history()[%d] thiếu khoá %s" % (i, miss))
            continue
        if r["kind"] not in DEAL_KINDS:
            out.append("account_history()[%d]['kind']=%r không thuộc %s" % (i, r["kind"], list(DEAL_KINDS)))
        bad = [k for k in ("time", "qty", "price", "profit", "commission", "swap", "fee") if not _isnum(r[k])]
        if bad:
            out.append("account_history()[%d] trường số sai kiểu: %s" % (i, bad))
        elif r["time"] <= 0:
            out.append("account_history()[%d]['time'] phải là epoch UTC > 0" % i)
        if r["kind"] == "trade" and (not r["symbol"] or r["side"] not in ("buy", "sell")):
            out.append("account_history()[%d] deal giao dịch thiếu symbol/side (side=%r)" % (i, r["side"]))
    return out[:6]


def check_tick(t, symbol=None):
    out = []
    for k in ("symbol", "time", "bid", "ask"):
        if not hasattr(t, k):
            return ["Tick thiếu trường %s" % k]
    if symbol and t.symbol != symbol:
        out.append("Tick.symbol=%r khác mã đã hỏi %r" % (t.symbol, symbol))
    if not (_num(t.bid) and _num(t.ask) and t.bid > 0 and t.ask > 0):
        out.append("Tick bid/ask phải > 0: %r/%r" % (t.bid, t.ask))
    elif t.ask < t.bid - 1e-12:
        out.append("Tick ask < bid (%r < %r)" % (t.ask, t.bid))
    if not (_num(t.time) and t.time > 1e9):
        out.append("Tick.time không phải epoch giây: %r" % (t.time,))
    return out


def check_candles(cs, tf_seconds, n=None, before=None):
    """Nến phải: tăng dần, không trùng, cách đều theo khung (cho phép khoảng trống cuối tuần/nghỉ phiên là bội số), OHLC hợp lệ."""
    if not isinstance(cs, list):
        return ["history() của feed phải trả list Candle, nhận %s" % type(cs).__name__]
    out = []
    if not cs:
        return ["feed.history() không trả nến nào"]
    if n is not None and len(cs) > n + 2:
        out.append("feed.history(n=%d) trả %d nến (quá nhiều)" % (n, len(cs)))
    for a, b in zip(cs, cs[1:]):
        d = b.time - a.time
        if d <= 0:
            out.append("nến không tăng dần/trùng giờ tại %s" % a.time)
            break
        if tf_seconds and abs(d / tf_seconds - round(d / tf_seconds)) > 1e-6 and tf_seconds < 86400:
            out.append("khoảng cách nến %.0fs không là bội của khung %ds" % (d, tf_seconds))
            break
    for c in cs:
        if not (c.low <= min(c.open, c.close) + 1e-12 and c.high >= max(c.open, c.close) - 1e-12 and c.low > 0):
            out.append("nến OHLC vô lý tại %s: o=%s h=%s l=%s c=%s" % (c.time, c.open, c.high, c.low, c.close))
            break
    if before is not None and cs[-1].time >= before:
        out.append("phân trang: end=%s nhưng nến cuối %s không nhỏ hơn end (feed.history phải trả nến TRƯỚC end)" % (before, cs[-1].time))
    return out


# ------------------------------------------------------------------------------------------ danh sách adapter
def adapters():
    """(tên, lớp broker hoặc None, lớp feed hoặc None) của MỌI adapter - dò theo module để adapter mới tự bị kiểm."""
    from . import bridges, broker, ccxt_adapter, exness, feeds
    return [
        ("binance_spot", broker.BinanceBroker, feeds.BinanceFeed),
        ("binance_futures", broker.BinanceFuturesBroker, feeds.BinanceFeed),
        ("oanda", broker.OandaBroker, feeds.OandaFeed),
        ("exness", exness.ExnBroker, exness.ExnFeed),
        ("mt_bridge", bridges.MtBroker, bridges.MtFeed),
        ("ccxt", ccxt_adapter.CcxtBroker, ccxt_adapter.CcxtFeed),
        ("simulated", None, feeds.SimFeed),
    ]
