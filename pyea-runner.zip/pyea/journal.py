"""NHẬT KÝ LỆNH: ghi chú, thẻ (tag) và điểm tự chấm cho từng lệnh ĐÃ ĐÓNG + thống kê lãi/lỗ THEO THẺ + xuất CSV (kèm ghi chú). Thuần Python, không Kivy.

Vì sao có: sổ lệnh (trades.csv) cho biết «lãi/lỗ bao nhiêu», nhật ký trả lời «vì sao» - thẻ như `fomo`, `đúng-kế-hoạch`, `trái-xu-hướng` cộng dồn thành thống kê (thẻ nào đang làm bạn mất tiền).
Lưu ở `trade_journal.json` trong thư mục dữ liệu (có trong sao lưu). Khoá lệnh = mã|chiều|giờ-mở|giờ-đóng|chủ-lệnh (mã số lệnh (id) của sổ app có thể lặp lại sau «Đặt lại paper»).
Giới hạn để file không phình: ghi chú ≤ 2000 ký tự, ≤ 8 thẻ/lệnh mỗi thẻ ≤ 24 ký tự, ≤ 5000 lệnh có nhật ký (xoá bản cập nhật CŨ NHẤT trước).
Xuất CSV chống «CSV injection»: ô chữ bắt đầu bằng = + - @ (hoặc tab/CR) được đặt dấu ' phía trước để Excel/Sheets không chạy nó như công thức - ghi chú là chữ người dùng gõ tự do."""
import csv
import json
import os
import re
import threading
import time

FILE = "trade_journal.json"
MAX_NOTE, MAX_TAGS, MAX_TAG_LEN, MAX_ENTRIES = 2000, 8, 24, 5000
_TAG_BAD = re.compile(r"[,;\r\n\t\"'\\|]+")
_FORMULA = ("=", "+", "-", "@", "\t", "\r")


def _g(o, name, default=""):
    return o.get(name, default) if isinstance(o, dict) else getattr(o, name, default)


def trade_key(t):
    """Khoá bền của một lệnh đã đóng (đối tượng Trade hoặc dict cùng tên trường)."""
    def n(x):
        try:
            return int(float(x or 0))
        except (TypeError, ValueError):
            return 0
    return "%s|%s|%d|%d|%s" % (str(_g(t, "symbol")).upper(), str(_g(t, "side")).lower(), n(_g(t, "open_time")), n(_g(t, "close_time")), _g(t, "owner") or "")


def clean_tags(tags):
    """Danh sách thẻ sạch: chữ thường, bỏ ký tự phân cách, không trùng, giữ thứ tự, ≤ 8 thẻ × 24 ký tự. Nhận chuỗi «a, b c» hoặc list."""
    if isinstance(tags, str):
        tags = re.split(r"[,;\n]+", tags)
    out = []
    for t in tags or []:
        t = _TAG_BAD.sub(" ", str(t)).strip().lower()
        t = re.sub(r"\s+", "-", t)[:MAX_TAG_LEN].strip("-")
        if t and t not in out:
            out.append(t)
        if len(out) >= MAX_TAGS:
            break
    return out


def _entry(note="", tags=(), rating=0, now=None):
    try:
        r = int(rating)
    except (TypeError, ValueError):
        r = 0
    try:
        upd = float(now)
        if upd != upd:                                               # NaN
            raise ValueError
    except (TypeError, ValueError):
        upd = time.time()                                            # trường `updated` hỏng không được làm mất cả file nhật ký
    return {"note": str(note or "").replace("\x00", "")[:MAX_NOTE], "tags": clean_tags(tags), "rating": min(5, max(0, r)), "updated": upd}


class Journal:
    def __init__(self, path=None, clock=time.time):
        self.path, self._clock = path, clock
        self.lock = threading.RLock()
        self.entries = {}
        self.warning = ""
        self._load()

    # ---- lưu/nạp ----
    def _load(self):
        if not self.path or not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if not isinstance(d, dict) or not isinstance(d.get("entries"), dict):
                raise ValueError("sai cấu trúc")
            if int(d.get("_schema", 1)) > 1:
                raise ValueError("định dạng mới hơn app này")
            for k, e in d["entries"].items():
                if isinstance(e, dict):
                    self.entries[str(k)[:200]] = _entry(e.get("note"), e.get("tags"), e.get("rating"), e.get("updated"))
        except Exception as e:                                       # noqa: BLE001 - file hỏng: GIỮ lại bản hỏng, bắt đầu lại, nói rõ
            self.entries = {}
            try:
                bak = self.path + ".bad-%d" % int(self._clock())
                os.replace(self.path, bak)
                self.warning = "Nhật ký lệnh bị hỏng (%s): đã giữ file cũ tại %s và bắt đầu lại." % (e, os.path.basename(bak))
            except OSError:
                self.warning = "Nhật ký lệnh bị hỏng (%s) và không sao lưu được file cũ." % e

    def _save(self):
        if not self.path:
            return
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"_schema": 1, "entries": self.entries}, f, ensure_ascii=False)
        os.replace(tmp, self.path)

    def _prune(self):
        if len(self.entries) > MAX_ENTRIES:
            for k, _ in sorted(self.entries.items(), key=lambda kv: kv[1].get("updated", 0.0))[:len(self.entries) - MAX_ENTRIES]:
                del self.entries[k]

    # ---- thao tác ----
    def get(self, trade):
        with self.lock:
            e = self.entries.get(trade_key(trade))
            return dict(e, tags=list(e["tags"])) if e else {"note": "", "tags": [], "rating": 0, "updated": 0.0}

    def set(self, trade, note="", tags=(), rating=0):
        """Ghi/cập nhật. Cả ghi chú, thẻ lẫn điểm đều trống -> xoá mục. Ném OSError nếu không ghi được file (để giao diện báo)."""
        key = trade_key(trade)
        with self.lock:
            e = _entry(note, tags, rating, self._clock())
            if not e["note"].strip() and not e["tags"] and not e["rating"]:
                self.entries.pop(key, None)
            else:
                self.entries[key] = e
                self._prune()
            self._save()
            return dict(e)

    def delete(self, trade):
        with self.lock:
            if self.entries.pop(trade_key(trade), None) is not None:
                self._save()

    def count(self):
        with self.lock:
            return len(self.entries)

    def all_tags(self):
        with self.lock:
            return sorted({t for e in self.entries.values() for t in e["tags"]})

    # ---- thống kê theo thẻ ----
    def tag_stats(self, trades):
        """-> list dict {tag, n, wins, win_rate, pnl, avg, worst} cho mỗi thẻ có ít nhất 1 lệnh trong `trades`, xếp theo pnl TĂNG dần (thẻ gây lỗ nhiều nhất lên đầu).
        Lệnh nhiều thẻ được tính vào từng thẻ (nên tổng các thẻ có thể vượt tổng lãi/lỗ). Lệnh không thẻ vào nhóm «(chưa gắn thẻ)». Mẫu nhỏ rất nhiễu: n < 5 nên coi là giai thoại."""
        acc = {}
        with self.lock:
            ents = dict(self.entries)
        for t in trades or ():
            e = ents.get(trade_key(t))
            try:
                p = float(_g(t, "profit", 0.0) or 0.0)
            except (TypeError, ValueError):
                p = 0.0
            for tag in (e["tags"] if e and e["tags"] else ["(chưa gắn thẻ)"]):
                a = acc.setdefault(tag, [0, 0, 0.0, 0.0])
                a[0] += 1
                a[1] += 1 if p > 0 else 0
                a[2] += p
                a[3] = min(a[3], p)
        out = [{"tag": k, "n": a[0], "wins": a[1], "win_rate": a[1] / a[0] * 100.0, "pnl": a[2], "avg": a[2] / a[0], "worst": a[3]} for k, a in acc.items()]
        return sorted(out, key=lambda r: (r["pnl"], r["tag"]))

    def tag_stats_text(self, trades):
        rows = self.tag_stats(trades)
        if not rows:
            return "Chưa có lệnh nào."
        lines = ["THEO THẺ (lệnh nhiều thẻ được tính vào từng thẻ; n < 5 chỉ là giai thoại):"]
        for r in rows:
            lines.append("  %-22s n=%-3d thắng %3.0f%%  tổng %+.2f  TB %+.2f  tệ nhất %+.2f%s" % (r["tag"], r["n"], r["win_rate"], r["pnl"], r["avg"], r["worst"], "  ⚠ mẫu nhỏ" if r["n"] < 5 else ""))
        return "\n".join(lines)

    # ---- xuất CSV ----
    COLUMNS = ("id", "symbol", "side", "volume", "open_time", "close_time", "open_price", "close_price", "profit", "fee", "swap", "reason", "owner", "comment", "rating", "tags", "note")

    def export_csv(self, trades, path, fmt_time=None):
        """Ghi mọi lệnh trong `trades` kèm nhật ký ra CSV (UTF-8 có BOM để Excel đọc đúng tiếng Việt). Trả số dòng đã ghi. Ghi qua file tạm rồi đổi tên (không để lại file dở)."""
        ft = fmt_time or (lambda ts: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else "")
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        tmp = path + ".tmp"
        n = 0
        with open(tmp, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(self.COLUMNS)
            for t in trades or ():
                e = self.get(t)
                w.writerow([safe_cell(x) for x in (
                    _g(t, "id"), _g(t, "symbol"), _g(t, "side"), _g(t, "volume"), ft(_g(t, "open_time", 0.0)), ft(_g(t, "close_time", 0.0)), _g(t, "open_price"), _g(t, "close_price"),
                    _g(t, "profit"), _g(t, "fee"), _g(t, "swap"), _g(t, "reason"), _g(t, "owner"), _g(t, "comment"), e["rating"] or "", ",".join(e["tags"]), e["note"])])
                n += 1
        os.replace(tmp, path)
        return n


def safe_cell(v):
    """Số giữ nguyên; chữ bắt đầu bằng ký tự công thức thì đặt ' phía trước (chống CSV injection)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v
    s = "" if v is None else str(v)
    return "'" + s if s.startswith(_FORMULA) else s
