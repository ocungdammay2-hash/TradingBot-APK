"""
Giữ nhật ký/sự kiện/chat không phình mãi trên bộ nhớ flash của điện thoại.

  prune_daily_logs : xoá file logs/AAAAMMDD.log quá `keep_days` ngày hoặc khi tổng dung lượng vượt `max_total`.
  rotate_if_big    : file vượt `max_bytes` -> đổi tên .1 (giữ `keep` bản), file mới rỗng. DÙNG cho file chỉ GHI NỐI TIẾP, không ai đọc theo offset.
  trim_jsonl       : giữ `keep_lines` dòng cuối của file JSON-lines. CHỈ gọi lúc khởi động trước khi có ai đọc theo byte offset
                     (chat.jsonl/events.jsonl được UI đọc theo offset: cắt giữa chừng sẽ làm lệch).
  maintain         : gọi một lần khi app/dịch vụ khởi động (an toàn gọi nhiều lần).
Mọi hàm nuốt lỗi OSError: bảo trì nhật ký không được làm sập app.
"""
import os
import re
import time

DAILY = re.compile(r"^\d{8}\.log$")
MB = 1024 * 1024


def prune_daily_logs(logs_dir, keep_days=14, max_total=20 * MB, now=None):
    """-> số file đã xoá."""
    now = now or time.time()
    try:
        files = []
        for n in os.listdir(logs_dir):
            if DAILY.match(n):
                p = os.path.join(logs_dir, n)
                st = os.stat(p)
                files.append((st.st_mtime, st.st_size, p))
    except OSError:
        return 0
    files.sort()
    removed, total = 0, sum(f[1] for f in files)
    keep_after = now - keep_days * 86400
    for mt, size, p in list(files):
        if mt < keep_after or total > max_total:
            try:
                os.remove(p)
                removed += 1
                total -= size
                files.remove((mt, size, p))
            except OSError:
                pass
    return removed


def rotate_if_big(path, max_bytes=5 * MB, keep=2):
    """-> True nếu đã xoay."""
    try:
        if os.path.getsize(path) <= max_bytes:
            return False
        for i in range(keep, 0, -1):
            src = path if i == 1 else "%s.%d" % (path, i - 1)
            dst = "%s.%d" % (path, i)
            if os.path.exists(src):
                os.replace(src, dst)
        return True
    except OSError:
        return False


def trim_jsonl(path, max_bytes=2 * MB, keep_lines=2000):
    """Nếu file > max_bytes: giữ `keep_lines` dòng cuối (ghi nguyên tử). -> số dòng đã bỏ."""
    try:
        if os.path.getsize(path) <= max_bytes:
            return 0
        with open(path, "rb") as f:
            lines = [ln for ln in f.read().splitlines(True) if ln.endswith(b"\n")]      # bỏ dòng cuối chưa ghi xong
        if len(lines) <= keep_lines:
            return 0
        tail = lines[-keep_lines:]
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            f.writelines(tail)
        os.replace(tmp, path)
        return len(lines) - len(tail)
    except OSError:
        return 0


def maintain(base, logs_dir=None, keep_days=14, trim=True):
    """Bảo trì khi khởi động. `trim=False` (dịch vụ nền): KHÔNG cắt chat/events vì UI đang đọc chúng theo offset - việc đó chỉ UI làm lúc khởi động.
    -> dict số liệu (để ghi nhật ký/test)."""
    logs_dir = logs_dir or os.path.join(base, "logs")
    out = {"logs_removed": prune_daily_logs(logs_dir, keep_days=keep_days)}
    jobs = (("chat.jsonl", 2 * MB, 1500), ("events.jsonl", 4 * MB, 3000), ("exchange_history.jsonl", 16 * MB, 50000), ("ai_signals.jsonl", 8 * MB, 5000)) if trim else ()
    for n, lim, keep in jobs:
        out[n] = trim_jsonl(os.path.join(base, n), lim, keep)
    for n in ("crash.log", "service_crash.log"):
        out[n] = rotate_if_big(os.path.join(base, n), 1 * MB, keep=1)
    return out
