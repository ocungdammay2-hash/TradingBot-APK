"""Nhật ký thay đổi hiển thị trong app («Có gì mới») + lịch sử API bot (để tác giả bot biết tính năng nào cần `# @api_min`)."""

# (phiên bản app, ngày, [thay đổi]) - mới nhất ở đầu
CHANGELOG = [
    ("1.8.0", "2026-10-31", [
        "ĐỒNG BỘ SỐ LIỆU VỚI SÀN NHƯ MT5 (trả lời câu hỏi «ứng dụng có đồng bộ những thông số này không»): (1) Khung «Giao dịch» hiện Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ DO SÀN BÁO, nhãn ghi rõ «SÀN» (kèm tiền tệ); sàn không báo hoặc số đã cũ thì dùng sổ của app và ghi «sổ app», trường nào sàn không báo thì hiện «-» chứ không bịa 0. Dải an toàn cũng có lãi/lỗ thả nổi. (2) Mỗi vị thế: lãi/lỗ, swap, hoa hồng và giá hiện tại do SÀN tính (đúng ticket, đúng contract size/quy đổi tiền) thay cho «chênh giá × khối lượng» của sổ app; dòng vị thế hiện «giá mở → giá hiện tại» như MT5. (3) Mục «LỊCH SỬ TỪ SÀN» trong Lịch sử & báo cáo: chọn Hôm nay/7/30/90 ngày để xem Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư (đúng định nghĩa tab Lịch sử của MT5) và danh sách vị thế đã đóng (giá vào→ra bình quân gia quyền, lãi/lỗ, giờ đóng) - gồm cả lệnh bạn đánh tay ngoài app. Tải ở luồng nền, mất mạng/sàn chưa hỗ trợ thì báo rõ. Hiện có cho MetaApi, cổng MT5, cổng+EA (MT4/MT5), hồ sơ cầu nối có khai op `history`, và Exness (tên trường chưa kiểm chứng); OANDA/Binance/ccxt chưa có lịch sử đồng bộ (nói rõ trên giao diện). Chỉ ở chế độ chạy thật. Số của từng vị thế làm mới theo chu kỳ «account_state_interval» (15 giây).",
        "KIỂM TRA HỆ THỐNG đọc thử số của sàn: thêm các bước account_state() (số dư/tài sản/ký quỹ), position_stats() (lãi/lỗ từng vị thế, đối chiếu đúng ticket vừa mở) và account_history() (lịch sử như tab MT5, đối chiếu deal mở+đóng của lệnh thử) cho MỌI sàn có hàm này; sàn không báo trường nào thì cảnh báo nêu tên trường, kèm phản hồi thô (đã che khoá) để chỉnh tên trường.",
        "SL/TP NATIVE CHO CỔNG + EA MT4/MT5 (trước chỉ MetaApi): MT5 TRADE_ACTION_SLTP, MT4 OrderModify, gắn lên đúng ticket, chỉ vị thế có comment «pyea». Cổng báo khả năng (sltp/posdeals/comment/history) qua /v1/ping và dòng HELLO của EA; cổng/EA bản cũ thì tự giữ SL/TP và nói rõ phải chép lại + biên dịch lại EA. Giá khớp thật của đúng ticket lấy từ lịch sử deal theo vị thế. MT4 không dùng định danh theo ticket (đóng một phần tạo ticket mới). Hồ sơ cầu nối (profile) có thể khai thêm op modify_position/deals_by_position/history.",
        "SL/TP NATIVE CHO EXNESS: mỗi vị thế một lệnh SLTP (sửa PATCH, gỡ DELETE). Tên trường của thân yêu cầu không lấy được từ nguồn chính thức nên app thử các dạng thân theo tài liệu chữ và NHỚ dạng nào sàn nhận; sàn từ chối hết thì vỏ vẫn tự canh. CHƯA kiểm chứng trên tài khoản thật - thử DEMO với «Kiểm tra sàn (--trade)».",
        "DANH TÍNH VỊ THẾ: vị thế nhập từ sàn khi đối soát được khớp theo ticket (không chỉ theo tổng khối lượng); tài khoản MT NETTING được hỗ trợ: vị thế ảo chỉ nhận SL/TP native khi nó chính là cả ticket, ticket gộp không bao giờ nhận SL/TP của riêng một vị thế.",
        "CÔ LẬP BOT TRÊN ANDROID (bot_isolation = process): mỗi bot chạy trong một dịch vụ worker riêng (Botworker0..3, tối đa 4 bot đồng thời ở chế độ này), nối với dịch vụ chính bằng socket cục bộ có token; bot treo/ăn bộ nhớ không kéo cả app. Hết chỗ worker thì báo rõ. CHƯA chạy trên thiết bị thật (một số hãng có thể giết dịch vụ worker - bot đó sẽ dừng với lỗi tiến trình); giới hạn bộ nhớ theo bot không áp dụng trên Android.",
        "SỬA LỖI cổng MT5: chưa biết chênh lệch giờ máy chủ (chưa có tick nào) thì hỏi lịch sử/vị thế sai múi giờ và BỎ SÓT các lệnh vừa đóng. Nay cổng tự dò từ tick của mã đang theo dõi (thử lại mỗi 30 giây).",
        "CHƯA LÀM: AI hub cho tài khoản phụ chạy trực tiếp; lịch sử đồng bộ cho OANDA/Binance/ccxt; mọi thứ mới ở bản này chỉ được kiểm bằng sàn/Kivy giả - file EA .mq4/.mq5 chưa từng biên dịch, chưa chạy trên sàn hay Cat S52 thật. Xem HANDOFF 5h.",
    ]),
    ("1.7.0", "2026-10-30", [
        "MẤT MẠNG / APP CHẾT - TRẢ LỜI THẲNG: (1) Mất mạng: sau 30 giây (Cài đặt «Báo động khi mất kết nối giá/sàn quá») app báo động NGHIÊM TRỌNG, nói rõ bao nhiêu vị thế đang được SÀN canh SL/TP (native, vẫn chạy), bao nhiêu chỉ do APP canh (KHÔNG chạy lúc này), bao nhiêu không có SL/TP, bao nhiêu lệnh chờ do app giữ sẽ không khớp; nhắc lại mỗi 10 phút nếu vẫn mất. Có lại mạng: báo + đối soát với sàn NGAY. (2) App/điện thoại chết hoặc bị hệ thống giết: báo thức giám sát (AlarmManager) dựng lại dịch vụ, khôi phục sổ lệnh, đối soát với sàn và BÁO NGHIÊM TRỌNG nếu phiên ngừng ≥90 giây khi đang có vị thế (SL/TP do app canh đã không chạy). (3) Sổ app có khớp sàn không: app so với vị thế THẬT trên sàn; lệch (lệnh đóng/mở lúc app không chạy, SL/TP native đã khớp trên sàn...) thì mặc định TỰ ĐỔI SỔ theo sàn và ghi rõ: vị thế đóng ngoài app được đóng ở GIÁ KHỚP THẬT (lấy từ lịch sử giao dịch của sàn) chứ không phải giá hiện tại, vị thế nào bị đóng thì giữ nguyên các vị thế còn lại. Hạn chế: SL/TP/lệnh chờ do APP canh KHÔNG chạy khi app chết hoặc mất mạng - muốn sàn tự canh thì bật «SL/TP native».",
        "ĐỐI SOÁT: mặc định nay là «adopt» (tự đổi sổ theo sàn; trước là chỉ báo). Một lệch chỉ được xử lý sau khi thấy LẶP LẠI hai lần cách nhau ≥2 giây (tránh đổi sổ vì lệnh đang bay). Lệnh do chính app gửi (bao gồm SL/TP native đã khớp) được loại khỏi phép tính nên không bị coi là «đóng ngoài app». Muốn như cũ: Cài đặt «Khi lệch vị thế với sàn» = alert.",
        "KHÔNG TỰ DỪNG KHI MẤT GIÁ: trước đây mất giá 120 lần liên tiếp thì dừng phiên. Nay phiên giữ nguyên, thử lại chậm dần (tối đa 15 giây), có nhật ký khi lấy lại được giá. Muốn tự dừng sau X phút: Cài đặt «Dừng phiên nếu mất giá liên tục quá (phút)» (0 = không dừng).",
        "KHÔI PHỤC PHIÊN CHỜ MẠNG: khởi động lại sau crash mà chưa có mạng thì phiên chờ và thử lại kết nối sàn (báo động nghiêm trọng, nhắc mỗi 10 phút) thay vì bỏ cuộc; bot chờ có đủ dữ liệu rồi mới chạy.",
        "SL/TP NATIVE GIỜ CHẠY QUA MỘT HỢP ĐỒNG CHUNG (pyea/protection.py, học theo MT5): vỏ chỉ nói «vị thế này, SL này, TP này»; mỗi sàn khai phong cách (ladder/pair/position) và vài hàm nguyên thuỷ - thêm sàn mới không phải sửa vỏ. MT/MetaApi nay có SL/TP native gắn lên đúng ticket (POSITION_MODIFY) vì vị thế ảo đã lưu ticket sàn và đóng theo ticket (không còn FIFO). VẪN MẶC ĐỊNH TẮT; thử demo trước. Exness vẫn chưa có (không lấy được schema `sltp`).",
        "BÁO THỨC GIÁM SÁT (Android AlarmManager) cho dịch vụ nền: Cài đặt «Báo thức giám sát dịch vụ (AlarmManager)» (mặc định bật, chu kỳ 5 phút). CHƯA kiểm chứng trên thiết bị thật.",
        "CẢNH BÁO: có vị thế mà SL/TP chỉ do app canh và «SL/TP native» đang tắt thì app nói rõ MỘT lần mỗi phiên (thanh kết nối ở tab Giao dịch cũng hiện «MẤT KẾT NỐI/LỖI API SÀN» khi sàn không trả lời).",
        "LỊCH KINH TẾ (API bot 1.4): bạn chọn nguồn (URL hoặc file JSON/CSV, vd bản tin JSON của faireconomy) ở Cài đặt → Lịch kinh tế. App nạp nền, báo trước tin quan trọng liên quan các mã đang theo dõi, và (tuỳ chọn) CHẶN LỆNH MỚI của bot/AI quanh giờ ra tin (api.calendar(), Ret.NEWS_BLOCK). Đóng lệnh, SL/TP, kill switch và lệnh bạn bấm tay không bao giờ bị chặn; lịch lỗi/trống thì không chặn gì; backtest không áp dụng.",
        "NHIỀU TÀI KHOẢN CHẠY TRỰC TIẾP (không cần dịch vụ nền): mỗi tài khoản phụ có phiên, sổ lệnh, nhật ký, bot riêng trong thư mục riêng. Hạn chế: không có AI hub cho tài khoản phụ và chúng dừng khi app đóng (cần dịch vụ nền để chạy khi app đóng).",
        "(Lúc phát hành 1.7.0) CHƯA LÀM: SL/TP native cho Exness; cô lập bot bằng tiến trình riêng trên Android; chưa chạy trên sàn/thiết bị thật. Hai mục đầu đã làm ở 1.8.0 (xem HANDOFF 5h).",
    ]),
    ("1.6.1", "2026-10-28", [
        "SL/TP NATIVE cho BINANCE SPOT (vẫn MẶC ĐỊNH TẮT, thử testnet trước): Spot không có reduceOnly và mọi lệnh bán chờ đều khoá coin đang giữ, nên SL + TP của cùng vị thế được đặt thành MỘT lệnh OCO (chân TP = LIMIT_MAKER, chân SL = STOP_LOSS); vị thế chỉ có SL hoặc chỉ có TP dùng lệnh đơn. Sàn khớp chân nào thì vỏ ghi sổ đúng chân đó ở giá khớp thật, không gửi thêm lệnh. Mức nào sàn từ chối thì vỏ vẫn tự canh.",
        "Phí mua bằng coin làm vị thế ảo lẻ hơn bước khối lượng của sàn (vd 0.04995 → lệnh bảo vệ 0.049): khi lệnh bảo vệ khớp trọn, phần dư nhỏ hơn một bước (không bán được) được tính là đã đóng, không để lại vị thế ảo vô hình.",
        "Kiểm tra sàn (`selfcheck --trade`) trên Spot nay thử lệnh OCO thật (một cặp) thay vì hai lệnh rời; hợp đồng adapter có thêm kiểm hình dạng `protection_orders()`.",
        "(Lúc phát hành 1.6.1 còn chưa làm MT bridge và Exness. MT bridge đã làm ở 1.7.0; Exness VẪN CHƯA - không lấy được schema loại lệnh `sltp` từ nguồn chính thức. Xem HANDOFF 5f/5g.)",
    ]),
    ("1.6.0", "2026-10-28", [
        "BOT (API 1.3): kho bền api.store (riêng của bot) và api.shared (chung mọi bot, như GlobalVariable của MT5); api.oco() nối lệnh chờ thành nhóm OCO; api.stats() thống kê lệnh đã đóng của bot; on_tester() trả fitness riêng cho tối ưu hoá (MT5 OnTester).",
        "LỆNH: OCO cho lệnh chờ (một lệnh khớp thì vỏ huỷ lệnh còn lại) và FREEZE LEVEL (lệnh chờ/SL/TP gần giá quá thì không sửa/huỷ được, trả Ret.FROZEN; đóng vị thế không bị chặn).",
        "BACKTEST: chọn thứ tự giá trong nến (O→H→L→C, O→L→H→C, hoặc «xấu nhất» với lệnh đang mở) + nút «So sánh thứ tự giá trong nến» để đo độ nhạy - kết quả đổi dấu tức là chiến lược dựa vào giả định không kiểm chứng được. Xếp tối ưu/walk-forward theo Fitness (on_tester).",
        "AI: tín hiệu AI được GHI (model + dấu vân tay prompt) và backtest PHÁT LẠI đúng các tín hiệu đã ghi (không nhìn trước; không sinh lại câu trả lời của AI). Backtest không phát lại thì báo rõ bot luôn nhận None. URL các nhà cung cấp đối chiếu tài liệu chính thức; model gợi ý của Gemini cập nhật, ghi chú Cerebras sửa cho đúng.",
        "AN TOÀN: che khoá/bí mật trong nhật ký và chat AI (và không gửi khoá nằm trong mã bot cho nhà cung cấp AI); phiên bản định dạng dữ liệu (file mới hơn app thì giữ nguyên, không ghi đè); xoay vòng/cắt nhật ký; cảnh báo rủi ro lần đầu trước khi chạy LIVE; chặn chụp/quay màn hình (FLAG_SECURE) tuỳ chọn.",
        "QUYỀN MẠNG theo bot: khai báo `# @permission: network(host)` trong bot, người dùng cho phép từng bot. Chỉ CƯỠNG CHẾ khi bot chạy ở tiến trình riêng (không phải ranh giới an ninh trước mã cố tình phá).",
        "KHÔNG LÀM PHIỀN: tạm tắt âm/rung cảnh báo 1/4/8/24 giờ (Cài đặt) hoặc theo khung giờ ban đêm. Cảnh báo vẫn được ghi và hiện thông báo im lặng; sự cố nghiêm trọng (kill switch, margin call, bot/dịch vụ lỗi, lệch vị thế...) mặc định vẫn kêu.",
        "SỬA LỖI backtest: chế độ «xấu nhất» không đổi thứ tự giá cho lệnh bán (vòng lặp dùng danh sách cũ).",
        "(Lúc phát hành 1.6.0 chưa có SL/TP native cho Exness, cầu nối MT và Binance Spot: Spot làm ở 1.6.1, MT ở 1.7.0, Exness vẫn chưa.)",
    ]),
    ("1.5.1", "2026-10-26", [
        "Kiểm tra sàn CHUNG cho mọi sàn: nút «Kiểm tra hệ thống» và lệnh `python -m pyea.selfcheck` (thêm `--trade --yes` để thử lệnh thật khối lượng nhỏ nhất trên tài khoản DEMO: mua, lệnh chờ đặt/sửa/huỷ, đóng một phần, SL/TP native, đóng nốt, dọn dẹp). Báo cáo kèm phản hồi thô của sàn (đã che khoá).",
        "Hợp đồng broker/feed (pyea/contract.py): một bộ kiểm tra chữ ký + hình dạng dữ liệu chạy trên MỌI adapter - bắt lỗi kiểu gọi sai tham số trước khi chạy tiền thật.",
        "SỬA LỖI Exness: đồng bộ lịch sử gọi sai tham số (lỗi mỗi chu kỳ trên tài khoản thật); nến thiếu tham số `from` bắt buộc; lịch sử qua /v1/history có phân trang và giới hạn tuổi/độ dài; giá làm tròn theo point_digits; sửa lệnh chờ chỉ dùng PATCH.",
        "Exness: bảng mã lỗi cuối của lệnh có gợi ý tiếng Việt, đọc giới hạn từ phản hồi /limits đúng cấu trúc tài liệu, cờ tài khoản close_only/trading_disabled chặn lệnh mới, đóng MỘT PHẦN được kiểm tra lại (nếu sàn bỏ qua khối lượng và đóng hết thì app báo rõ và đổi cách gửi).",
        "SL/TP NATIVE nay có cả cho OANDA (lệnh STOP/LIMIT REDUCE_ONLY); Binance dùng chung thuật toán bậc thang. Vẫn MẶC ĐỊNH TẮT, thử demo trước.",
        "Sửa nhỏ: lệnh chờ kiểu stop của Binance báo giá kích hoạt (trước là 0); cầu nối MT/ccxt báo đủ khối lượng/giá lệnh chờ; OANDA cờ tradeable theo `status`, lý do huỷ lệnh lấy từ giao dịch huỷ.",
    ]),
    ("1.5.0", "2026-10-24", [
        "Cảnh báo theo chỉ báo: RSI cắt mức, EMA nhanh cắt EMA chậm (tính trên nến đã đóng).",
        "Nhật ký lọc theo khoảng thời gian; biểu đồ lưu/áp MẪU (bộ chỉ báo + cách hiển thị); tuỳ chọn hiển thị khối lượng theo lot/đơn vị.",
        "Backtest DANH MỤC trên giao diện: chạy nhiều bot đã gắn cùng một tài khoản và xem từng bot.",
        "THỬ NGHIỆM (mặc định tắt): SL/TP NATIVE trên Binance Futures - lệnh bảo vệ reduceOnly đặt trên sàn nên SL/TP vẫn chạy khi app/điện thoại chết. Bật ở Cài đặt, thử testnet trước.",
        "SỬA LỖI: lệnh chờ kiểu stop trên Binance Futures nay đi qua Algo Order (từ 2025-12-09 sàn từ chối STOP_MARKET qua /order, lỗi -4120).",
        "Bot có thêm api.trace() và chế độ Trace (nút «Trace» trên thẻ bot) để xem từng điều kiện bot tính ra sao.",
        "Lệnh khớp MỘT PHẦN được báo rõ (OrderResult.partial/remaining) thay vì im lặng.",
        "Đọc cờ tài khoản từ sàn: canTrade, loại ký quỹ (cross/isolated), tiền tệ. Sàn báo canTrade=false thì chặn lệnh mới.",
        "Feed mất giữa chừng: tự phát hiện khoảng trống nến và tải bù trước khi bot thấy nến mới.",
        "Bot đổi tên tham số không còn làm mất giá trị người dùng đã lưu (param_aliases) và vỏ báo tham số bị bỏ/mới.",
        "Cài đặt mới: âm thanh/rung thông báo, giờ hiển thị (giờ máy/UTC/lệch giờ), SL/TP mặc định cho lệnh tay.",
        "Backtest → nút «TRIỂN KHAI»: gắn đúng bot/mã/khung/tham số vừa thử (tài khoản thật: gắn nhưng chưa chạy).",
        "Thêm bot mẫu Breakout Donchian và DCA định kỳ.",
        "Nút «Nạp lại» trên thẻ bot: nạp mã bot mới mà không dừng bot, vị thế giữ nguyên; lỗi thì tự quay lại bản cũ.",
        "Backtest: tuỳ chọn swap x3 theo ngày (kiểu broker MT) với giờ rollover tự chọn.",
    ]),
    ("1.4.0", "2026-10-23", [
        "Exness, cầu nối MT4/MT5, ccxt, lệnh chờ native, đồng bộ sàn, giới hạn tốc độ gọi API, Keystore, backtest có chi phí.",
    ]),
]

# Lịch sử API bot: bot dùng tính năng nào thì khai báo `# @api_min: <phiên bản>` ở đầu file
API_CHANGES = [
    ("1.5", ["AccountInfo.broker_synced/broker_balance/broker_equity/broker_margin/broker_free_margin/broker_margin_level/broker_profit: số của SÀN (giống khung «Giao dịch» MT5); "
             "balance/equity/margin... vẫn là sổ riêng của app",
             "Position.adopted: True = vị thế nhập từ sàn qua đối soát (bạn mở tay), vỏ không tự sửa SL/TP gốc của nó"]),
    ("1.4", ["api.calendar(hours, min_impact): tin kinh tế sắp ra liên quan mã của bot (rỗng nếu người dùng chưa bật lịch)",
             "Ret.NEWS_BLOCK: lệnh MỚI bị vỏ chặn quanh tin quan trọng khi người dùng bật «chặn lệnh quanh tin» (đóng lệnh không bị chặn)"]),
    ("1.3", ["api.store / api.shared: kho khoá-giá trị JSON bền (get/set/incr/delete/has/keys/items/clear/size)", "api.oco(a, b, ...) và PendingOrder.oco", "api.stats()", "BaseBot.on_tester() -> fitness cho tối ưu hoá",
             "Ret.FROZEN, SymbolInfo.freeze_level", "khai báo quyền `# @permission: network(host)`", "api.ai_signal có thêm model, prompt_hash (và replayed khi backtest phát lại)"]),
    ("1.2", ["(vỏ) tuỳ chọn SL/TP native không đổi API bot - bot vẫn đặt sl=/tp= như cũ", "on_deinit(reason) nhận thêm reason='reload' khi người dùng nạp lại mã bot", "api.trace(text, **values), api.trace_enabled", "OrderResult.partial, OrderResult.remaining",
             "AccountInfo.margin_mode", "lớp bot có thể khai báo param_aliases = {tên_cũ: tên_mới}"]),
    ("1.1", ["on_trade, on_timer", "lệnh chờ (limit/stop/stop-limit)", "OrderResult có mã lỗi (Ret)", "symbol_info()/account_info()/time_info()",
             "đóng một phần"]),
    ("1.0", ["on_init, on_tick, on_bar, on_deinit", "buy/sell/close/close_all, candles(), tick"]),
]


def changelog_text(limit=3):
    out = []
    for ver, day, items in CHANGELOG[:limit]:
        out.append("v%s (%s)" % (ver, day))
        out.extend("  • " + i for i in items)
        out.append("")
    return "\n".join(out).rstrip()


def api_changes_text():
    out = []
    for ver, items in API_CHANGES:
        out.append("API %s" % ver)
        out.extend("  • " + i for i in items)
    return "\n".join(out)
