"""Giao diện «Kết nối MT5 nhanh» = MT5 THẬT trong giả lập trên điện thoại (xem pyea/mt5emu.py cho logic và giới hạn).
Trang 1: nhập login + mật khẩu + server (+ link bộ cài của sàn, tuỳ chọn). Trang 2: NHÚNG (pyea/embedded.py, không Termux): tiến trình từng bước + CPU/RAM + nút Dừng/Khởi động lại/chẩn đoán;
nếu máy/APK không chạy được cách nhúng thì quay về cách Termux cũ (lệnh dán 1 lần).
Mật khẩu chỉ nằm trong ô nhập (xoá ngay khi bấm Bắt đầu) và trong RAM của máy chủ cục bộ tới khi EA nối được; KHÔNG ghi vào cài đặt."""
import functools
import time
import traceback

from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.utils import escape_markup

import threading

from . import android_utils, embedded, mt5ea, mt5emu
from .ui_widgets import AMBER, BLUE, DOWN, GREEN, MUTED, PANEL2, TEXT, UP, StyledPopup, mk_input, mkbtn, vscroll, wlabel

TONE = {"ok": UP, "fail": DOWN, "wait": AMBER}


def _open_url(url):
    try:
        from .ui_ctrader import open_url
        open_url(url)
    except Exception:                                        # noqa: BLE001 - không mở được trình duyệt: người dùng tự gõ địa chỉ
        pass


def _guarded(where):
    """Dựng trang lỗi thì hiện TRANG TỐI THIỂU (có lỗi + nút) thay vì để hộp thoại trống: log thật có ảnh hộp thoại «Kết nối MT5 nhanh» trống trơn, không nút nào, không biết vì sao."""
    def deco(fn):
        @functools.wraps(fn)
        def run(self, *a, **k):
            try:
                return fn(self, *a, **k)
            except Exception as e:                                # noqa: BLE001
                self._fallback(where, e)
        return run
    return deco


class Mt5EmuDialog:
    def __init__(self, app):
        self.app = app
        self.srv = None
        self.cmd = ""
        self.ticker = None
        self.emb_ok, self.emb_why = embedded.supported()
        self.mode = "embedded" if self.emb_ok else "termux"
        self._clear_armed = False
        self.box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8), size_hint_y=None)
        self.box.bind(minimum_height=self.box.setter("height"))
        self.pop = StyledPopup(title="Kết nối MT5 nhanh", content=vscroll(self.box), size_hint=(0.95, 0.92), auto_dismiss=False)
        self.pop.bind(on_dismiss=lambda *_: self._stop_tick())

    # ---------------------------------------------------------------- mở
    def open(self):
        try:
            self._open()
        except Exception as e:                                    # noqa: BLE001
            self._fallback("mở", e)
        self.pop.open()

    def _open(self):
        srv = None
        for s in getattr(mt5ea, "_SERVERS", {}).values():          # đã có phiên cài/đang nối thì mở thẳng trang tiến trình
            if s.install or s.connected:
                srv = s
        phase = embedded.status(self.app.data_dir)["phase"] if self.emb_ok else "idle"
        if self.emb_ok and (srv is not None or phase != "idle") and embedded.read_request(self.app.data_dir).get("want"):
            self.srv = srv or self._attach_server()
            self.show_progress_embedded()
        elif srv is not None:
            self.srv = srv
            self.cmd = mt5emu.bootstrap_command(srv.port, srv.token) if mt5emu.TOKEN_OK.match(srv.token) else ""
            self.show_progress()
        else:
            self.show_form()

    ui_err = ""

    def _fallback(self, where, err):
        """Trang tối thiểu khi trang chính lỗi: nêu lỗi + nút sao chép chẩn đoán (kèm vết lỗi), thử lại, đóng. Chính nó không được ném."""
        self.ui_err = "%s: %s\n%s" % (where, err, traceback.format_exc())[:4000]
        try:
            self._stop_tick()
            b = self.box
            b.clear_widgets()
            b.add_widget(wlabel("Không dựng được trang «%s»: %s: %s\nMT5 nhúng (nếu đang cài) vẫn chạy nền. Bấm «Sao chép chẩn đoán» rồi gửi lại để sửa." % (where, type(err).__name__, str(err)[:300]), 12, DOWN))
            row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
            row.add_widget(mkbtn("Sao chép chẩn đoán", PANEL2, size=12, on_release=self.emb_diag if self.mode == "embedded" else self.copy_diag))
            row.add_widget(mkbtn("Thử lại", BLUE, size=12, on_release=lambda *_: self._open_again()))
            b.add_widget(row)
            b.add_widget(mkbtn("Đóng", PANEL2, size=12, on_release=lambda *_: self.pop.dismiss()))
        except Exception:                                    # noqa: BLE001
            pass

    def _open_again(self):
        try:
            self._open()
        except Exception as e:                                # noqa: BLE001
            self._fallback("mở lại", e)

    def _attach_server(self):
        """App vừa mở lại trong lúc dịch vụ Emu vẫn chạy: dựng lại máy chủ cục bộ theo cài đặt đã lưu để EA/relay nối lại và tiến trình hiện đúng."""
        try:
            srv = mt5ea.ensure_server(dict(self.app.settings))
            srv.start()
            return srv
        except Exception:                                    # noqa: BLE001 - cổng đang bị bot dùng/cài đặt thiếu: vẫn hiện trạng thái từ emu/state.json
            return None

    def _stop_tick(self):
        if self.ticker is not None:
            self.ticker.cancel()
            self.ticker = None

    # ---------------------------------------------------------------- trang 1
    @_guarded("form")
    def show_form(self):
        self._stop_tick()
        self._zip_page = "form"
        b = self.box
        b.clear_widgets()
        if self.emb_ok:
            b.add_widget(wlabel("MT5 THẬT chạy trong giả lập NGAY TRONG APP (proot + Ubuntu + Box64 + Wine), KHÔNG cần cài Termux. Bạn chỉ nhập 3 thông tin dưới đây rồi bấm Bắt đầu; "
                                "tải, cài, biên dịch EA cầu nối và đăng nhập đều tự động, tiến trình hiện ngay trong app.\n"
                                "Lần đầu: tải vài trăm MB đến hơn 1 GB và có thể mất hàng chục phút (chưa đo). Các lần sau: không cài lại, chỉ bật MT5. "
                                "Chạy ở chế độ NHẸ để bớt CPU/RAM (mức giảm chưa đo).\n"
                                "CHƯA kiểm trên điện thoại thật - hãy thử bằng tài khoản DEMO trước.", 12, MUTED))
        else:
            b.add_widget(wlabel("MT5 THẬT chạy trong giả lập ngay trên điện thoại (Termux + Box64 + Wine). Bạn chỉ nhập 3 thông tin dưới đây rồi dán MỘT lệnh vào Termux; "
                                "tải, cài, biên dịch EA cầu nối và đăng nhập đều tự động, tiến trình hiện ngay trong app.\n"
                                "Lần đầu: tải vài trăm MB đến hơn 1 GB và có thể mất hàng chục phút (chưa đo). Các lần sau: không cài lại, chỉ bật MT5.\n"
                                "Cách chạy ngay trong app (không Termux) chưa dùng được ở bản này: %s.\n"
                                "CHƯA kiểm trên điện thoại thật - hãy thử bằng tài khoản DEMO trước." % self.emb_why, 12, MUTED))
        self.login = mk_input("", "Login MT5 (chữ số)", input_filter="int")
        self.pw = mk_input("", "Mật khẩu MT5 (giao dịch)", password=True)
        self.server = mk_input("", "Server (vd Exness-MT5Real8, hoặc địa chỉ:cổng trong email của sàn)")
        self.url = mk_input("", "Link bộ cài MT5 của sàn (tuỳ chọn, bỏ trống = bản chung)")
        for w in (self.login, self.pw, self.server, self.url):
            b.add_widget(w)
        if self.emb_ok:
            # v17: bộ cài .exe của MetaQuotes quay vòng trên máy thật (log v16) -> cho chọn thẳng tệp .zip thư mục MetaTrader 5 ĐÃ CÀI SẴN từ bộ nhớ điện thoại (không cần link, không chạy bộ cài)
            b.add_widget(wlabel("Hoặc cài từ tệp .zip trong bộ nhớ điện thoại (thư mục MetaTrader 5 đã cài sẵn, nén thành .zip): không cần link, KHÔNG chạy bộ cài .exe. "
                                "CHƯA kiểm trên máy thật.", 11, MUTED))
            self.imp_lbl = wlabel(self._imp_text(), 12, MUTED)
            b.add_widget(self.imp_lbl)
            row0 = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
            row0.add_widget(mkbtn("Chọn tệp .zip MT5", PANEL2, on_release=self.pick_zip))
            row0.add_widget(mkbtn("Bỏ tệp đã chọn", PANEL2, on_release=self.clear_zip))
            b.add_widget(row0)
        b.add_widget(wlabel("Bấm «Bắt đầu» = đồng ý đặt «Nguồn thị trường» = mt5ea trong Cài đặt (nguồn MT5 qua EA cầu nối). Mật khẩu chỉ nằm trong RAM của app cho tới khi MT5 đăng nhập "
                            "được, không ghi vào Cài đặt.", 11, MUTED))
        self.status = wlabel("", 12, MUTED)
        b.add_widget(self.status)
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: self.pop.dismiss()))
        self.go_btn = mkbtn("Bắt đầu", GREEN, on_release=self.start)
        row.add_widget(self.go_btn)
        b.add_widget(row)

    def _say(self, text, color=MUTED):
        self.status.text, self.status.color = text, color

    # ---- v17: chọn tệp .zip MT5 từ bộ nhớ ----
    def _imp_text(self):
        try:
            info = embedded.import_info(self.app.data_dir)
        except Exception:                                    # noqa: BLE001 - sổ hỏng: coi như chưa chọn
            info = None
        if not info:
            return "Chưa chọn tệp .zip."
        mb = max(1, int(info.get("size", 0)) >> 20)
        if getattr(self, "_zip_page", "form") == "progress":
            return "Đang chọn: %s (%d MB). Bấm «Khởi động lại» để cài từ tệp này (nếu tệp này lỗi: «Chọn tệp .zip MT5» để đổi tệp khác, hoặc «Bỏ tệp .zip»)." % (info.get("name", "?"), mb)
        return "Đã chọn: %s (%d MB). Bấm «Bắt đầu» để cài từ tệp này (ưu tiên hơn link ở trên)." % (info.get("name", "?"), mb)

    def _zip_busy(self):
        """Đang cài (dịch vụ còn ghi nhịp): đổi/xoá tệp lúc này có thể làm hỏng bước đang chạy -> bắt bấm «Dừng» trước."""
        try:
            st = embedded.status(self.app.data_dir)
        except Exception:                                    # noqa: BLE001 - không đọc được trạng thái: không chặn
            return False
        return st.get("phase") == "installing" and bool(st.get("alive"))

    def pick_zip(self, *_):
        if self._zip_busy():
            self._say("Đang cài nền: bấm «Dừng» trước rồi mới chọn tệp .zip khác (đổi giữa chừng có thể làm hỏng bước đang chạy).", AMBER)
            return
        self._say("Đang mở bộ chọn tệp...", MUTED)
        dest = embedded.import_dest(self.app.data_dir)
        android_utils.pick_file_copy(dest, lambda name, size, err: Clock.schedule_once(lambda dt: self._zip_picked(name, size, err), 0))

    def _zip_picked(self, name, size, err):
        if err == "cancelled":
            self._say("", MUTED)
            return
        if err == "copying":
            self._say("Đang chép và kiểm tra tệp %s (tệp hàng trăm MB có thể mất vài chục giây, đừng thoát app)..." % (name or ".zip"), MUTED)
            return
        if err:
            self._say("Không nhận được tệp: %s" % str(err).strip().splitlines()[-1][:300], DOWN)
            return
        try:
            embedded.import_register(self.app.data_dir, name, size, note=getattr(android_utils, "LAST_COPY_NOTE", ""))
        except Exception as e:                               # noqa: BLE001
            self._say("Không ghi nhận được tệp: %s" % e, DOWN)
            return
        self.imp_lbl.text = self._imp_text()
        if getattr(self, "_zip_page", "form") == "progress":
            self._say("Đã nhận tệp mới (đã kiểm). Bấm «Khởi động lại» để cài từ tệp này.", UP)
        else:
            self._say("Đã nhận tệp. Nhập Login/Mật khẩu/Server rồi bấm «Bắt đầu».", UP)

    def clear_zip(self, *_):
        if self._zip_busy():
            self._say("Đang cài nền: bấm «Dừng» trước rồi mới bỏ tệp .zip (xoá giữa chừng có thể làm hỏng bước đang chạy).", AMBER)
            return
        embedded.import_clear(self.app.data_dir)
        self.imp_lbl.text = self._imp_text()
        if getattr(self, "_zip_page", "form") == "progress":
            self._say("Đã xoá tệp .zip đã chọn (cả bản đã giải nén). Chọn tệp khác rồi «Khởi động lại»; nếu không chọn gì, «Khởi động lại» sẽ dùng link/bản chung.", MUTED)
        else:
            self._say("Đã bỏ tệp đã chọn.", MUTED)

    def start(self, *_):
        login, pw, server, url = self.login.text.strip(), self.pw.text, self.server.text.strip(), self.url.text.strip()
        bad = mt5emu.problems(login, pw, server, url)
        if bad:
            self._say("\n".join(bad), DOWN)
            return
        form = self.app.settings_tab.gform
        cur = dict(self.app.settings)
        try:
            vals = form.read()[0] if form else {}
            cur.update(vals or {})
        except Exception:                                    # noqa: BLE001 - ô nào đó đang sai: dùng cài đặt đã lưu
            pass
        start_err = ""
        try:
            if self.emb_ok:
                upd, srv, (started, start_err) = mt5emu.prepare_embedded(cur, login, pw, server, url, data_dir=self.app.data_dir)
                cmd = ""
                self.mode = "embedded"
            else:
                upd, srv, cmd = mt5emu.prepare(cur, login, pw, server, url)
                self.mode = "termux"
        except Exception as e:                               # ValueError nhập liệu / BridgeError không mở được cổng
            self._say(str(e), DOWN)
            return
        self.pw.text = ""                                    # xoá mật khẩu khỏi ô ngay
        try:
            form.update_values(upd)
        except Exception:                                    # noqa: BLE001 - form chưa dựng: lưu thẳng vào cài đặt
            self.app.settings.update(upd)
        saved = self.app.save_forms(False)
        self.srv, self.cmd = srv, cmd
        if self.mode == "embedded":
            self.show_progress_embedded(saved_ok=bool(saved), start_err=start_err if not started else "")
        else:
            self.show_progress(saved_ok=bool(saved))

    # ---------------------------------------------------------------- trang 2
    @_guarded("tiến trình")
    def show_progress(self, saved_ok=True):
        self._stop_tick()
        b = self.box
        b.clear_widgets()
        self.head = wlabel("", 13, TEXT, bold=True)
        self.steps = wlabel("", 12, TEXT)
        b.add_widget(self.head)
        b.add_widget(self.steps)
        if not saved_ok:
            b.add_widget(wlabel("Chưa lưu được cài đặt: mở tab Cài đặt, sửa ô báo lỗi rồi bấm Lưu.", 12, AMBER))
        b.add_widget(wlabel("BƯỚC 1 - Cài Termux (app riêng, 1 lần): bản F-Droid hoặc GitHub, KHÔNG dùng bản Google Play (đã cũ, không cài được gói).\n"
                            "BƯỚC 2 - Bấm «Sao chép lệnh», mở Termux, giữ ngón tay trên màn hình → Dán → Enter. Xong, chỉ việc đợi.", 12, MUTED))
        r1 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r1.add_widget(mkbtn("Cài Termux (F-Droid)", PANEL2, size=12, on_release=lambda *_: _open_url(mt5emu.TERMUX_URL)))
        r1.add_widget(mkbtn("Mở Termux", PANEL2, size=12, on_release=self.open_termux))
        b.add_widget(r1)
        b.add_widget(mkbtn("Sao chép lệnh", BLUE, h=52, on_release=self.copy_cmd))
        box = TextInput(text=self.cmd, readonly=True, multiline=True, font_size=dp(11), size_hint_y=None, height=dp(96), background_color=PANEL2, foreground_color=TEXT)
        b.add_widget(box)
        b.add_widget(wlabel("Đã cài xong trước đó, chỉ muốn bật lại MT5? Trong Termux gõ: " + mt5emu.START_CMD + "   (dừng: " + mt5emu.STOP_CMD + ")", 11, MUTED))
        r2 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r2.add_widget(mkbtn("Sao chép lệnh bật lại", PANEL2, size=12, on_release=lambda *_: self.copy(mt5emu.START_CMD, "Đã sao chép lệnh bật lại MT5.")))
        r2.add_widget(mkbtn("Sao chép chẩn đoán", PANEL2, size=12, on_release=self.copy_diag))
        b.add_widget(r2)
        r3 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r3.add_widget(mkbtn("Nhập lại thông tin", PANEL2, size=12, on_release=lambda *_: self.show_form()))
        r3.add_widget(mkbtn("Đóng", BLUE, size=12, on_release=lambda *_: self.pop.dismiss()))
        b.add_widget(r3)
        self.tick()
        self.ticker = Clock.schedule_interval(self.tick, 1.0)

    # ---------------------------------------------------------------- trang 2 (nhúng)
    @_guarded("tiến trình nhúng")
    def show_progress_embedded(self, saved_ok=True, start_err=""):
        self._stop_tick()
        self.mode = "embedded"
        self._clear_armed = False
        self._rm_armed = None
        self._rm_btns = {}
        b = self.box
        b.clear_widgets()
        self.head = wlabel("", 13, TEXT, bold=True)
        self.steps = wlabel("", 12, TEXT)
        b.add_widget(self.head)
        b.add_widget(self.steps)
        if not saved_ok:
            b.add_widget(wlabel("Chưa lưu được cài đặt: mở tab Cài đặt, sửa ô báo lỗi rồi bấm Lưu.", 12, AMBER))
        if start_err:
            b.add_widget(wlabel("Không bật được dịch vụ MT5 nhúng: %s" % str(start_err)[:400], 12, DOWN))
        b.add_widget(wlabel("Không cần Termux và không cần làm gì thêm: để app mở, đợi các bước ✓. Nên tắt «tối ưu pin» cho PyEA. Android 12-14 có thể tự giết tiến trình con của app: "
                            "nếu MT5 hay bị tắt, vào Tuỳ chọn nhà phát triển → bật «Disable child process restrictions» (Tắt giới hạn tiến trình con).", 11, MUTED))
        r1 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r1.add_widget(mkbtn("Dừng", PANEL2, size=12, on_release=self.emb_stop))
        r1.add_widget(mkbtn("Khởi động lại", BLUE, size=12, on_release=self.emb_restart))
        b.add_widget(r1)
        r2 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r2.add_widget(mkbtn("Sao chép chẩn đoán", PANEL2, size=12, on_release=self.emb_diag))
        self.clear_btn = mkbtn("Xoá MT5 nhúng", PANEL2, size=12, on_release=self.emb_clear)
        r2.add_widget(self.clear_btn)
        b.add_widget(r2)
        # tệp .zip MT5: đổi/xoá NGAY trên trang này (lúc tệp lỗi người dùng không tìm thấy chỗ nào để nhập lại hay xoá tệp cũ)
        self._zip_page = "progress"
        b.add_widget(wlabel("Tệp .zip MT5 (cài từ bộ nhớ điện thoại, không chạy bộ cài .exe). App chỉ giữ MỘT tệp: tệp chọn gần nhất. «Bỏ tệp .zip» chỉ xoá bản app đã chép, KHÔNG xoá tệp trong «Tải xuống» và không đụng MT5 đã cài xong. Có nhiều tệp zip trong máy thì cứ chọn tệp mới nhất ở «Chọn tệp .zip MT5».", 11, MUTED))
        self.imp_lbl = wlabel(self._imp_text(), 12, MUTED)
        b.add_widget(self.imp_lbl)
        rz = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        rz.add_widget(mkbtn("Chọn tệp .zip MT5", PANEL2, size=12, on_release=self.pick_zip))
        rz.add_widget(mkbtn("Bỏ tệp .zip", PANEL2, size=12, on_release=self.clear_zip))
        b.add_widget(rz)
        self.status = wlabel("", 12, MUTED)
        b.add_widget(self.status)
        b.add_widget(wlabel("Mỗi link bộ cài, và mỗi tệp .zip mới chọn, tạo một thư mục MT5 riêng trong Ubuntu (mỗi sàn một bản). App KHÔNG tự xoá bản nào: bấm «Xem các bản MT5 đã cài», rồi tự chọn bản cần xoá. Xoá một bản là mất luôn tài khoản/EA trong bản đó; dùng lại sàn đó phải cài lại. Bản «ĐANG DÙNG» không xoá ở đây.", 11, MUTED))
        self.list_btn = mkbtn(self.LIST_TEXT, PANEL2, size=12, on_release=self.emb_list_mt5)
        b.add_widget(self.list_btn)
        self.mt5_msg = wlabel("", 12, MUTED)
        b.add_widget(self.mt5_msg)
        self.mt5_list = BoxLayout(orientation="vertical", size_hint_y=None, height=0, spacing=dp(6))
        self.mt5_list.bind(minimum_height=lambda w, v: setattr(w, "height", v))
        b.add_widget(self.mt5_list)
        r3 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        r3.add_widget(mkbtn("Nhập lại thông tin", PANEL2, size=12, on_release=lambda *_: self.show_form()))
        r3.add_widget(mkbtn("Đóng", BLUE, size=12, on_release=lambda *_: self.pop.dismiss()))
        b.add_widget(r3)
        self.tick()
        self.ticker = Clock.schedule_interval(self.tick, 1.0)

    def _toast(self, msg):
        try:
            self.app.toast(msg)
        except Exception:                                    # noqa: BLE001
            pass

    def emb_stop(self, *_):
        threading.Thread(target=embedded.stop, args=(self.app.data_dir,), daemon=True).start()
        self._toast("Đang dừng MT5 nhúng (tắt dịu, có thể mất vài chục giây)...")

    def emb_restart(self, *_):
        data_dir = self.app.data_dir
        req = embedded.read_request(data_dir)
        srv = self.srv or self._attach_server()
        if srv is None:
            self._toast("Không mở được cổng cục bộ (đang bị dùng?). Bấm «Nhập lại thông tin».")
            return
        self.srv = srv
        srv.install_reset()                                  # dòng ✗ của lần trước không được nằm lại khi đang chạy lại
        ok, err = embedded.launch(data_dir, srv.port, srv.token, str(req.get("profile") or "lean"), mt5_url=str(req.get("mt5_url") or ""))
        self._toast("Đã bật lại dịch vụ MT5 nhúng." if ok else "Không bật được dịch vụ: %s" % str(err)[:160])

    def emb_diag(self, *_):
        a = self.srv.diagnostics_text() if self.srv is not None else ""
        ui = ("\n--- lỗi giao diện ---\n" + self.ui_err) if self.ui_err else ""
        self.copy(a + "\n\n" + embedded.diagnostics_text(self.app.data_dir, getattr(self.srv, "token", "")) + ui, "Đã sao chép chẩn đoán (token đã che).")

    def emb_clear(self, *_):
        if not self._clear_armed:                            # bấm 2 lần mới xoá: mất cả Ubuntu/Wine/MT5 (phải tải cài lại từ đầu)
            self._clear_armed = True
            self.clear_btn.text = "Bấm lại để XOÁ HẲN"
            return
        self._clear_armed = False
        self.clear_btn.text = "Xoá MT5 nhúng"

        def work():
            embedded.stop(self.app.data_dir)
            embedded.clear_all(self.app.data_dir)
        threading.Thread(target=work, daemon=True).start()
        self._toast("Đang xoá MT5 nhúng (hệ Ubuntu, Wine, MT5 đã tải).")

    LIST_TEXT = "Xem các bản MT5 đã cài"
    RM_TEXT = "Xoá bản này"
    RM_SURE = "Xoá thật? Bấm lại (mất tài khoản/EA trong bản này)"

    def emb_list_mt5(self, *_, note="", note_ok=True):
        """Liệt kê từng bản MT5 (chạy nền vì phải đếm dung lượng). Người dùng tự chọn xoá bản nào; app không xoá hàng loạt. `note`: kết quả lần xoá vừa rồi, in kèm danh sách mới."""
        data_dir = self.app.data_dir
        self._mt5_say((note + "\n" if note else "") + "Đang xem các bản MT5 đã cài...", MUTED)

        def scan():
            info = embedded.mt5_installs(data_dir)
            Clock.schedule_once(lambda *_: self._show_mt5_list(info, note, note_ok), 0)
        threading.Thread(target=scan, daemon=True).start()

    def _mt5_say(self, msg, color=MUTED):
        try:
            self.mt5_msg.text = msg
            self.mt5_msg.color = color
        except Exception:                                    # noqa: BLE001 - trang đã đóng
            pass

    @staticmethod
    def _mt5_when(ts):
        try:
            return time.strftime("%d/%m/%Y", time.localtime(int(ts))) if ts else "?"
        except (ValueError, OverflowError, OSError):
            return "?"

    def _show_mt5_list(self, info, note="", note_ok=True):
        box = self.mt5_list
        box.clear_widgets()
        self._rm_armed, self._rm_btns = None, {}
        pre = (note + "\n") if note else ""
        if not info["ok"]:
            self._mt5_say(pre + "Không liệt kê được: %s." % info["why"], AMBER)
            return
        items = info["items"]
        if not items:
            self._mt5_say(pre + "Chưa có bản MT5 nào trong thư mục riêng (MT5 đang dùng, nếu có, nằm ở chỗ khác nên không xoá được ở đây).", MUTED)
            return
        self._mt5_say(pre + "Có %d bản MT5 (tổng %s). Bấm «%s» ở bản muốn bỏ." % (len(items), embedded.human(sum(i["size"] for i in items)), self.RM_TEXT),
                      (UP if note_ok else AMBER) if note else MUTED)
        for it in items:
            head = "[b]%s[/b]" % escape_markup(it["label"])
            line = "%s · tạo %s" % (embedded.human(it["size"]), self._mt5_when(it.get("added")))
            if it["active"]:
                box.add_widget(wlabel("%s\n%s\n[b]ĐANG DÙNG[/b] (không xoá ở đây)" % (head, line), 12, UP))
                continue
            box.add_widget(wlabel("%s\n%s" % (head, line), 12, TEXT))
            btn = mkbtn(self.RM_TEXT, PANEL2, size=12)
            btn.bind(on_release=lambda w, k=it["key"]: self._rm_click(k))
            self._rm_btns[it["key"]] = btn
            box.add_widget(btn)

    def _rm_click(self, key):
        """Bấm lần 1: hỏi lại (10 giây); bấm lần 2 đúng bản đó: xoá bản đó, các bản khác không đụng."""
        if self._rm_armed != key:
            self._rm_disarm()
            self._rm_armed = key
            btn = self._rm_btns.get(key)
            if btn is not None:
                btn.text = self.RM_SURE
            Clock.schedule_once(lambda *_: self._rm_disarm(key), 10)
            return
        self._rm_disarm()
        data_dir = self.app.data_dir
        self._mt5_say("Đang xoá bản MT5 đã chọn...", MUTED)

        def work():
            r = embedded.remove_mt5(data_dir, key)
            Clock.schedule_once(lambda *_: self._rm_done(r), 0)
        threading.Thread(target=work, daemon=True).start()

    def _rm_done(self, r):
        self._toast(r["msg"])
        self.emb_list_mt5(note=r["msg"], note_ok=r["ok"])    # vẽ lại danh sách còn lại, kèm kết quả lần xoá

    def _rm_disarm(self, only_key=None):
        if only_key is not None and self._rm_armed != only_key:
            return                                           # đã bấm sang bản khác hoặc đã xoá
        self._rm_armed = None
        for b in self._rm_btns.values():
            try:
                b.text = self.RM_TEXT
            except Exception:                                # noqa: BLE001
                pass

    def tick(self, *_):
        try:
            self._tick()
        except Exception as e:                                    # noqa: BLE001 - một lần đọc tiến trình lỗi không được làm trống hộp thoại hay ném vào Clock
            self.ui_err = "tick: %s\n%s" % (e, traceback.format_exc())[:4000]
            try:
                self.head.text, self.head.color = "Không đọc được tiến trình lúc này (%s: %s). Sẽ thử lại sau 1 giây." % (type(e).__name__, str(e)[:160]), AMBER
            except Exception:                                # noqa: BLE001
                pass

    def _tick(self):
        if self.srv is None and self.mode != "embedded":
            return
        if self.mode == "embedded":
            p = mt5emu.progress_embedded(self.srv, self.app.data_dir)
            text, tone = mt5emu.headline_embedded(p)
            self.head.text, self.head.color = text, TONE.get(tone, TEXT)
            self.steps.text = "" if p["connected"] else mt5emu.render(p)
            return                                           # nhúng: vẫn tick tiếp để thấy CPU/RAM và trạng thái dừng/lỗi
        p = mt5emu.progress(self.srv)
        text, tone = mt5emu.headline(p)
        self.head.text, self.head.color = text, TONE.get(tone, TEXT)
        self.steps.text = "" if p["connected"] else mt5emu.render(p)      # đã nối thật thì danh sách bước (có thể còn dấu · của lần cài cũ) chỉ gây rối
        if p["connected"]:
            self._stop_tick()

    # ---------------------------------------------------------------- nút
    def copy(self, text, msg):
        Clipboard.copy(text)
        try:
            self.app.toast(msg)
        except Exception:                                    # noqa: BLE001
            pass

    def copy_cmd(self, *_):
        self.copy(self.cmd, "Đã sao chép lệnh. Mở Termux, giữ ngón tay trên màn hình → Dán.")

    def copy_diag(self, *_):
        text = self.srv.diagnostics_text() if self.srv is not None else ""
        self.copy(text, "Đã sao chép chẩn đoán (token đã che).")

    def open_termux(self, *_):
        if not android_utils.open_termux():
            try:
                self.app.toast("Không mở được Termux: chưa cài, hoặc hãy mở nó từ màn hình chính.")
            except Exception:                                # noqa: BLE001
                pass


def mt5emu_dialog(app):
    Mt5EmuDialog(app).open()
