"""Giao diện NHẬT KÝ LỆNH (logic ở pyea/journal.py): hộp thoại ghi chú/thẻ/điểm cho một lệnh đã đóng, thống kê theo thẻ, xuất CSV."""
import os
import time

from kivy.core.clipboard import Clipboard
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.utils import escape_markup

from . import journal
from .ui_widgets import AMBER, BLUE, GREEN, MIN_TOUCH, MUTED, PANEL2, RED, TEXT, StyledPopup, flabel, mk_input, mk_spinner, mkbtn, vbox, vscroll, wlabel

RATINGS = ["0 - chưa chấm", "1 ★ tệ", "2 ★★", "3 ★★★ tạm", "4 ★★★★", "5 ★★★★★ đúng kế hoạch"]


def ref_text(app, ref):
    """Một dòng tóm tắt nhật ký của lệnh `ref` (rỗng nếu chưa có)."""
    e = app.journal.get(ref)
    if not (e["note"] or e["tags"] or e["rating"]):
        return ""
    bits = []
    if e["rating"]:
        bits.append("★" * e["rating"])
    if e["tags"]:
        bits.append(" ".join("#" + t for t in e["tags"]))
    if e["note"]:
        bits.append(e["note"][:120] + ("…" if len(e["note"]) > 120 else ""))
    return " · ".join(bits)


def show_entry(app, ref, title, on_saved=None):
    """Hộp thoại sửa nhật ký của MỘT lệnh đã đóng."""
    j = app.journal
    e = j.get(ref)
    content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    box = vbox(spacing=dp(6), padding=dp(4))
    box.add_widget(wlabel("Ghi chú: vì sao vào, có theo kế hoạch không, bài học. Chỉ lưu trên máy này (có trong sao lưu).", 11, MUTED))
    note = TextInput(text=e["note"], hint_text="Ghi chú (tối đa %d ký tự)" % journal.MAX_NOTE, multiline=True, font_size=dp(14), size_hint_y=None, height=dp(150),
                     background_color=PANEL2, foreground_color=TEXT, cursor_color=TEXT, hint_text_color=MUTED)
    box.add_widget(note)
    known = j.all_tags()
    tags = mk_input(", ".join(e["tags"]), "Thẻ, cách nhau bằng dấu phẩy: fomo, đúng-kế-hoạch, trái-xu-hướng")
    box.add_widget(tags)
    if known:
        box.add_widget(wlabel("Đã dùng: " + ", ".join(known[:30]), 11, MUTED))
    sp = mk_spinner(RATINGS[e["rating"]], RATINGS)
    box.add_widget(sp)
    content.add_widget(vscroll(box))
    pop = StyledPopup(title=title, content=content, size_hint=(0.97, 0.9), auto_dismiss=False)
    row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

    def save(*_):
        try:
            rating = RATINGS.index(sp.text) if sp.text in RATINGS else 0
            j.set(ref, note.text, tags.text, rating)
        except OSError as ex:
            app.toast("Không lưu được nhật ký: %s" % ex)
            return
        pop.dismiss()
        app.toast("Đã lưu nhật ký lệnh")
        if on_saved:
            on_saved()

    def clear(*_):
        try:
            j.delete(ref)
        except OSError as ex:
            app.toast("Không xoá được: %s" % ex)
            return
        pop.dismiss()
        if on_saved:
            on_saved()
    row.add_widget(mkbtn("Lưu", GREEN, on_release=save))
    row.add_widget(mkbtn("Xoá mục", RED, on_release=clear))
    row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
    content.add_widget(row)
    pop.open()


def _trades(app):
    return list((app.last_snap or {}).get("trades") or [])


def show_stats(app):
    """Thống kê lãi/lỗ theo thẻ của các lệnh đang có trong sổ app."""
    trades = _trades(app)
    text = app.journal.tag_stats_text(trades) if trades else "Chưa có lệnh đã đóng trong sổ của phiên hiện tại (hãy kết nối phiên)."
    if app.journal.warning:
        text = app.journal.warning + "\n\n" + text
    content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
    box = vbox(spacing=dp(4))
    for ln in text.split("\n"):
        box.add_widget(wlabel(escape_markup(ln), 12, TEXT))
    box.add_widget(wlabel("Gắn thẻ ở: Giao dịch → bấm một lệnh trong LỊCH SỬ → «Nhật ký».", 11, MUTED))
    content.add_widget(vscroll(box))
    pop = StyledPopup(title="Nhật ký theo thẻ", content=content, size_hint=(0.97, 0.8), auto_dismiss=True)
    r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
    r.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(text)))
    r.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
    content.add_widget(r)
    pop.open()


def export(app):
    """Ghi nhật ký + lệnh ra CSV trong thư mục exports của app."""
    trades = _trades(app)
    if not trades:
        app.toast("Chưa có lệnh đã đóng để xuất (kết nối phiên trước).")
        return
    try:
        d = app.store.exports_dir
        path = os.path.join(d, "trade-journal-%s.csv" % time.strftime("%Y%m%d-%H%M%S"))
        n = app.journal.export_csv(trades, path)
    except OSError as ex:
        app.toast("Không xuất được: %s" % ex)
        return
    app.toast("Đã xuất %d lệnh: %s" % (n, path))
