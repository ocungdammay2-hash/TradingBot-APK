package org.pyea.pyearunner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.io.File;
import java.lang.reflect.Method;

/**
 * Tự dựng lại dịch vụ bot sau khi máy khởi động lại / app vừa được cập nhật.
 * Chỉ chạy khi dịch vụ Python đã đặt cờ files/boot_resume.flag (phiên đang chạy + bật «Tự chạy lại khi mở máy»).
 * Dịch vụ foreground dùng foregroundServiceType=specialUse nên Android 15 KHÔNG chặn khi khởi động từ BOOT_COMPLETED.
 * Nếu vẫn bị chặn (ROM tuỳ biến), phát thông báo để người dùng chạm mở app.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        NotificationManager nm0 = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if ("android.intent.action.LOCKED_BOOT_COMPLETED".equals(a)) {
            // Máy vừa bật, CHƯA mở khoá: Python/dữ liệu app (kho credential) chưa dùng được -> chỉ nhắc người dùng mở khoá.
            // Cờ được dịch vụ sao thêm vào kho device-protected (đọc được khi chưa mở khoá).
            try {
                boolean unlocked = Build.VERSION.SDK_INT < 24 || ((android.os.UserManager) ctx.getSystemService(Context.USER_SERVICE)).isUserUnlocked();
                File dflag = new File(ctx.createDeviceProtectedStorageContext().getFilesDir(), "boot_resume.flag");
                if (!unlocked && dflag.exists()) tellLocked(ctx);
            } catch (Throwable ignored) {
            }
            return;
        }
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) && nm0 != null) nm0.cancel(7302);
        if (!(Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || "android.intent.action.QUICKBOOT_POWERON".equals(a))) return;
        try {
            File flag = new File(ctx.getFilesDir(), "boot_resume.flag");
            if (!flag.exists()) return;
            Class<?> svc = Class.forName(ctx.getPackageName() + ".ServiceBotservice");
            Method m = svc.getMethod("getDefaultIntent", Context.class, String.class, String.class, String.class, String.class);
            Intent si = (Intent) m.invoke(null, ctx, "icon", "PyEA Runner", "Đang khôi phục bot sau khi khởi động lại máy", "");
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(si); else ctx.startService(si);
            if (Intent.ACTION_BOOT_COMPLETED.equals(a))
                alert(ctx, 7303, "Máy vừa khởi động lại - đang khôi phục bot", "Bot được tự chạy lại với sổ lệnh đã lưu; hãy kiểm tra phiên trong app." + WHY, true);
        } catch (Throwable t) {
            if (!Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) tell(ctx, t);
        }
    }

    /** Thông báo kiểu BÁO THỨC: kênh riêng âm báo thức (USAGE_ALARM), rung, lặp tới khi bạn vuốt bỏ (FLAG_INSISTENT), hiện cả trên màn hình khoá. */
    private void alert(Context ctx, int id, String title, String text, boolean tapOpensApp) {
        if (!loud(ctx)) { quiet(ctx, id, title, text); return; }
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            android.net.Uri snd = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM);
            long[] vib = new long[]{0, 700, 400, 700, 400, 700};
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("pyea_boot_alarm", "Cảnh báo máy khởi động lại", NotificationManager.IMPORTANCE_HIGH);
                ch.setSound(snd, new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                ch.enableVibration(true);
                ch.setVibrationPattern(vib);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                try { ch.setBypassDnd(true); } catch (Throwable ignored) { }
                nm.createNotificationChannel(ch);
                b = new Notification.Builder(ctx, "pyea_boot_alarm");
            } else {
                b = new Notification.Builder(ctx).setSound(snd, android.media.AudioManager.STREAM_ALARM).setVibrate(vib)
                        .setPriority(Notification.PRIORITY_MAX);
            }
            if (tapOpensApp) {
                Intent li = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
                if (li != null) b.setContentIntent(PendingIntent.getActivity(ctx, 0, li, fl));
            }
            b.setSmallIcon(ctx.getApplicationInfo().icon).setAutoCancel(true).setContentTitle(title).setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text)).setCategory(Notification.CATEGORY_ALARM)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
            Notification n = b.build();
            n.flags |= Notification.FLAG_INSISTENT;
            nm.notify(id, n);
        } catch (Throwable ignored) {
        }
    }

    /** Đọc ký tự đầu của cờ: «Q» = người dùng tắt báo động (chỉ thông báo thường). Đọc cả kho thường lẫn device-protected. */
    private boolean loud(Context ctx) {
        File[] fs = new File[]{new File(ctx.getFilesDir(), "boot_resume.flag"),
                new File(ctx.createDeviceProtectedStorageContext().getFilesDir(), "boot_resume.flag")};
        for (File f : fs) {
            try {
                if (!f.exists()) continue;
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                int c = in.read();
                in.close();
                return c != 'Q';
            } catch (Throwable ignored) {
            }
        }
        return true;
    }

    private void quiet(Context ctx, int id, String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("pyea_boot", "Khôi phục sau khởi động", NotificationManager.IMPORTANCE_DEFAULT));
                b = new Notification.Builder(ctx, "pyea_boot");
            } else {
                b = new Notification.Builder(ctx);
            }
            Intent li = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            if (li != null) b.setContentIntent(PendingIntent.getActivity(ctx, 0, li, fl));
            b.setSmallIcon(ctx.getApplicationInfo().icon).setAutoCancel(true).setContentTitle(title).setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text));
            nm.notify(id, b.build());
        } catch (Throwable ignored) {
        }
    }

    private static final String WHY = " Máy tự khởi động lại là do hết pin/cúp điện, treo máy hoặc hệ thống tự khởi động (cập nhật, lỗi).";

    private void tellLocked(Context ctx) {
        alert(ctx, 7302, "⚠ MÁY VỪA KHỞI ĐỘNG LẠI - BOT ĐANG DỪNG",
                "Hãy mở khoá màn hình, bot sẽ tự chạy lại." + WHY, false);
    }

    private void tell(Context ctx, Throwable t) {
        alert(ctx, 7301, "⚠ MÁY VỪA KHỞI ĐỘNG LẠI - BOT CHƯA TỰ CHẠY LẠI",
                "Chạm để mở app và khôi phục phiên." + WHY, true);
    }
}
