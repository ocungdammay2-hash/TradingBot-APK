# Giấy phép / License

**Chưa chọn giấy phép.** Khi chưa có lựa chọn rõ ràng, mặc định mọi quyền được bảo lưu cho chủ sở hữu mã nguồn:
không ai khác được sao chép, sửa đổi hay phân phối lại mã này nếu chưa được chủ sở hữu cho phép bằng văn bản.

Việc chọn giấy phép là quyết định của chủ dự án (không phải của công cụ viết mã). Gợi ý để cân nhắc:

| Mục tiêu | Giấy phép thường dùng |
|---|---|
| Cho dùng/sửa/phân phối thoải mái, kể cả thương mại | MIT hoặc Apache-2.0 |
| Ai sửa rồi phân phối phải mở mã tương tự | GPL-3.0 / AGPL-3.0 |
| Bán bản quyền, không mở mã | Thương mại (EULA riêng; bản mẫu ở `pyea/legal.py` cần luật sư rà soát) |

Khi đã chọn: thay nội dung tệp này bằng văn bản giấy phép đầy đủ và điền tên chủ sở hữu trong `pyea/legal.py` (mục 7 của Điều khoản sử dụng).
Thư viện bên thứ ba (Kivy - MIT, python-for-android - MIT, certifi - MPL-2.0, DejaVu Sans - giấy phép Bitstream Vera) có giấy phép riêng của chúng.
