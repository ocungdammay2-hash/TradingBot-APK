"""Lịch nghỉ lễ thị trường VN TỰ CẬP NHẬT từ mạng (cho vnmarket.py). Không import Kivy.

Vì sao là một file JSON chứ không cào trang của sở: HOSE/HNX chỉ công bố ngày nghỉ dưới dạng thông báo (trang tin/PDF), không có API máy đọc được mà ta kiểm chứng được; cào chữ tự do sẽ sai
âm thầm, mà lịch sai trong app giao dịch là nguy hiểm (báo «mở cửa» khi sàn nghỉ, hoặc chặn nhầm). Nên: MỘT file JSON do bạn (hoặc ai bạn tin) cập nhật mỗi khi sở ra thông báo, mọi máy
tự tải về - không phải build lại APK. Mặc định `auto` lấy file `docs/vn_holidays.json` trong kho GitHub đã nhập ở «Kho GitHub chứa bản phát hành» (kho công khai; kho riêng tư trả 404 -> dùng lịch có sẵn).

Định dạng (version 1):
  {"version": 1, "updated": "2026-11-24", "source": "ghi chú nguồn thông báo của sở",
   "years": [2026, 2027],                       <- các năm danh sách DƯỚI ĐÂY đã ĐẦY ĐỦ (năm không khai báo => app báo «chưa biết lịch»)
   "holidays": {"2027-01-01": "Tết Dương lịch", "2027-02-08": "Tết Âm lịch", ...}}      <- chỉ ngày thường (T2-T6) sở nghỉ; ngày cuối tuần không cần ghi
KIỂM TRA (file lỗi/bị sửa bậy bị TỪ CHỐI cả khối, giữ lịch cũ): HTTPS (hoặc file cục bộ), <= 64 KB, version == 1, ngày hợp lệ trong 2020-2100, <= 400 ngày và <= 40 ngày/năm, <= 10 năm khai báo,
mỗi năm khai báo đủ phải có ĐỦ các lễ cố định luật định rơi vào ngày thường (1/1, 30/4, 1/5, 2/9) - thiếu thì danh sách chắc chắn cắt cụt.
AN TOÀN: file này chỉ làm app biết thêm ngày nghỉ; nó KHÔNG được phép gửi lệnh hay đổi cài đặt. Kẻ sửa được file chỉ có thể làm bộ chặn «lệnh ngoài giờ» (mặc định TẮT) chặn nhầm một số ngày."""
import datetime
import json
import os
import re
import threading
import time
import urllib.request

from . import vnmarket

MAX_BYTES = 64 * 1024
MIN_YEAR, MAX_YEAR = 2020, 2100
MAX_HOLIDAYS, MAX_PER_YEAR, MAX_YEARS = 400, 40, 10
DEFAULT_PATH = "docs/vn_holidays.json"
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")
_KEY_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


class FeedError(ValueError):
    pass


def resolve_source(value, update_repo=""):
    """'' / 'off' -> '' (tắt) · 'auto' -> raw.githubusercontent.com/<kho>/HEAD/docs/vn_holidays.json nếu đã nhập kho hợp lệ, còn không '' · khác -> nguyên văn (URL https hoặc đường dẫn file)."""
    v = str(value or "").strip()
    if v.lower() in ("", "off", "tắt"):
        return ""
    if v.lower() == "auto":
        repo = str(update_repo or "").strip()
        return "https://raw.githubusercontent.com/%s/HEAD/%s" % (repo, DEFAULT_PATH) if REPO_RE.match(repo) else ""
    return v


def validate(doc):
    """doc (dict đã parse JSON) -> (holidays {iso: lý do}, years {int}); ném FeedError nếu có BẤT KỲ điểm đáng ngờ nào."""
    if not isinstance(doc, dict):
        raise FeedError("không phải đối tượng JSON")
    if doc.get("version") != 1:
        raise FeedError("phiên bản định dạng %r chưa được hỗ trợ (cần 1)" % (doc.get("version"),))
    hol, yrs = doc.get("holidays"), doc.get("years")
    if not isinstance(hol, dict) or not isinstance(yrs, list):
        raise FeedError("thiếu «holidays» (đối tượng) hoặc «years» (danh sách)")
    if len(hol) > MAX_HOLIDAYS or len(yrs) > MAX_YEARS:
        raise FeedError("quá nhiều mục (holidays %d > %d hoặc years %d > %d)" % (len(hol), MAX_HOLIDAYS, len(yrs), MAX_YEARS))
    years = set()
    for y in yrs:
        if isinstance(y, bool) or not isinstance(y, int) or not MIN_YEAR <= y <= MAX_YEAR:
            raise FeedError("năm không hợp lệ: %r" % (y,))
        years.add(y)
    out, per_year = {}, {}
    for k, v in hol.items():
        m = _KEY_RE.match(str(k))
        if not m:
            raise FeedError("khoá ngày sai định dạng YYYY-MM-DD: %r" % (k,))
        try:
            d = datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            raise FeedError("ngày không có thật: %s" % k)
        if not MIN_YEAR <= d.year <= MAX_YEAR:
            raise FeedError("năm ngoài khoảng %d-%d: %s" % (MIN_YEAR, MAX_YEAR, k))
        if not isinstance(v, str):
            raise FeedError("lý do của %s phải là chuỗi" % k)
        out[d.isoformat()] = _CTRL_RE.sub(" ", v).strip()[:80] or "Ngày nghỉ lễ"
        per_year[d.year] = per_year.get(d.year, 0) + 1
    for y, n in per_year.items():
        if n > MAX_PER_YEAR:
            raise FeedError("năm %d có %d ngày nghỉ (> %d) - bất thường" % (y, n, MAX_PER_YEAR))
    for y in years:                                         # năm khai báo ĐỦ: các lễ cố định luật định rơi vào ngày thường phải có mặt
        miss = [("%d-%02d-%02d" % (y, m, dd)) for (m, dd) in sorted(vnmarket.FIXED)
                if datetime.date(y, m, dd).weekday() < 5 and ("%d-%02d-%02d" % (y, m, dd)) not in out]
        if miss:
            raise FeedError("năm %d khai báo đủ nhưng thiếu lễ cố định %s - danh sách có vẻ cụt" % (y, ", ".join(miss)))
    return out, years


def fetch_text(source, timeout=10):
    src = str(source or "").strip()
    if not src:
        raise FeedError("chưa cấu hình nguồn lịch")
    if re.match(r"^https?://", src, re.I):
        if not src.lower().startswith("https://"):
            raise FeedError("nguồn lịch phải dùng HTTPS")
        from .feeds import ssl_context
        req = urllib.request.Request(src, headers={"User-Agent": "PyEA-Runner/vn-holidays", "Accept": "application/json,*/*"})
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            raw = r.read(MAX_BYTES + 1)
    else:
        path = src[7:] if src.lower().startswith("file://") else src
        with open(path, "rb") as f:
            raw = f.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise FeedError("file lịch quá lớn (> %d KB)" % (MAX_BYTES // 1024))
    return raw.decode("utf-8", "strict")


class HolidayFeed:
    def __init__(self, source, cache_path=None, ttl=24 * 3600.0, fetch=None, clock=time.time):
        self.source, self.cache_path, self.ttl = str(source or "").strip(), cache_path, float(ttl)
        self._fetch, self._clock = fetch or fetch_text, clock
        self.lock = threading.RLock()
        self.holidays, self.years, self.updated = {}, frozenset(), ""
        self.loaded_at, self.tried_at, self.error, self._busy = 0.0, 0.0, "", False
        self._load_cache()

    def _load_cache(self):
        if not self.cache_path or not os.path.exists(self.cache_path):
            return
        try:
            with open(self.cache_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("source") == self.source:
                hol, yrs = validate(d.get("doc"))               # bộ đệm cũng qua kiểm tra: file đệm bị sửa/hỏng không được lọt vào
                self.holidays, self.years, self.loaded_at, self.updated = hol, frozenset(yrs), float(d.get("loaded_at", 0.0)), str((d.get("doc") or {}).get("updated", ""))[:20]
        except Exception:                                          # noqa: BLE001
            self.holidays, self.years, self.loaded_at = {}, frozenset(), 0.0

    def _save_cache(self, doc):
        if not self.cache_path:
            return
        try:
            tmp = self.cache_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"source": self.source, "loaded_at": self.loaded_at, "doc": doc}, f, ensure_ascii=False)
            os.replace(tmp, self.cache_path)
        except OSError:
            pass

    def apply(self):
        """Đẩy dữ liệu hiện có vào vnmarket (rỗng thì bỏ lịch tải ngoài)."""
        with self.lock:
            if self.holidays or self.years:
                vnmarket.set_feed(self.holidays, self.years, self.loaded_at, self.source)
            else:
                vnmarket.set_feed(None)

    def stale(self):
        now = self._clock()
        return now - self.loaded_at > self.ttl and now - self.tried_at > min(3600.0, self.ttl)      # lỗi thì thử lại sau tối đa 1 giờ

    def refresh(self, force=False):
        """-> (nạp mới thành công?, thông báo lỗi). Lỗi mạng/định dạng: GIỮ lịch cũ, ghi `error`. Không bao giờ ném lỗi."""
        with self.lock:
            if self._busy or not (force or self.stale()):
                return False, self.error
            self._busy, self.tried_at = True, self._clock()
        try:
            doc = json.loads(self._fetch(self.source))
            hol, yrs = validate(doc)
            with self.lock:
                self.holidays, self.years, self.loaded_at, self.error = hol, frozenset(yrs), self._clock(), ""
                self.updated = str(doc.get("updated", ""))[:20]
            self._save_cache(doc)
            self.apply()
            return True, ""
        except Exception as e:                                     # noqa: BLE001 - mạng/định dạng hỏng: giữ lịch cũ
            with self.lock:
                self.error = ("%s" % e)[:200]
            return False, self.error
        finally:
            with self.lock:
                self._busy = False

    def status(self):
        with self.lock:
            return {"source": self.source, "loaded_at": self.loaded_at, "updated": self.updated, "years": sorted(self.years), "holidays": len(self.holidays), "error": self.error}


_CUR = {"src": None, "feed": None, "thread": None}
_CUR_LOCK = threading.Lock()


def ensure(settings, data_dir=None, fetch=None, clock=time.time, background=True):
    """Gọi định kỳ (rẻ): dựng nguồn theo Cài đặt, nạp bộ đệm ngay, và nếu đã cũ thì tải lại NỀN (luồng riêng, không chặn). Trả HolidayFeed hoặc None khi tắt/không có nguồn."""
    src = resolve_source(settings.get("vn_holidays_source", "auto"), settings.get("update_repo", ""))
    with _CUR_LOCK:
        if _CUR["src"] != src:
            _CUR["src"] = src
            _CUR["feed"] = HolidayFeed(src, os.path.join(data_dir, "vn_holidays_cache.json") if data_dir else None, fetch=fetch, clock=clock) if src else None
            if _CUR["feed"] is not None:
                _CUR["feed"].apply()
            else:
                vnmarket.set_feed(None)
        feed = _CUR["feed"]
    if feed is None or not feed.stale():
        return feed
    if not background:
        feed.refresh()
        return feed
    with _CUR_LOCK:
        t = _CUR["thread"]
        if t is None or not t.is_alive():
            _CUR["thread"] = threading.Thread(target=feed.refresh, name="pyea-vn-holidays", daemon=True)
            _CUR["thread"].start()
    return feed


def reset():
    """Chỉ cho test: quên nguồn hiện tại và bỏ lịch tải ngoài."""
    with _CUR_LOCK:
        _CUR.update(src=None, feed=None, thread=None)
    vnmarket.set_feed(None)
