"""
Chạy nền: dịch vụ (ServiceHost) chạy BotRunner trong tiến trình riêng; giao diện (ServiceHandle)
giao tiếp qua các file JSON trong <data>/ipc/ (không cần thư viện ngoài, không phụ thuộc Kivy).

  UI  --cmd/*.json-->  Host      lệnh: start | stop | close_all | ai_auto | ping
  UI  <--state.json--  Host      ảnh chụp trạng thái (publish 1s khi UI đang mở, 10s khi UI ở nền)
  UI  <--events.jsonl- Host      điểm vào/ra lệnh kèm lý do (đọc nối tiếp theo offset)
      host.hb                    host chạm file này liên tục -> UI biết dịch vụ còn sống
      desired.json               "bot đang được yêu cầu chạy" -> dùng để TỰ KHÔI PHỤC sau crash
"""
import json
import os
import threading
import time
import traceback
import uuid

from .ai import AIHub
from .controller import legacy_view
from .engine import STATUS_TEXT, TradingSession, _atomic_write, _mk
from . import dnd, prefs
from .loader import build_params, inspect_bot
from .sdk import Candle, PendingOrder, Position, Trade, TradeEvent, jsonable
from .shell import PriceAlert
from .storage import ChatLog, Store

HB_FRESH = 8.0          # giây: host được coi là còn sống nếu host.hb mới hơn mức này
PENDING_GRACE = 25.0    # giây chờ host nhận lệnh start


# --------------------------------------------------------------------------
# (de)serialize snapshot
# --------------------------------------------------------------------------
def snapshot_to_json(snap, chart=None):
    d = jsonable(snap)
    if chart:
        c = jsonable(chart)
        c.pop("events", None)                 # sự kiện đọc từ events.jsonl
        # nến dạng mảng [t,o,h,l,c,v] (gọn ~2 lần so với dict) - state.json ghi mỗi giây nên cần nhỏ
        c["candles"] = [[x["time"], x["open"], x["high"], x["low"], x["close"], x["volume"]] for x in c.get("candles", [])]
        d["chart"] = c
    return d


def _chart_from_json(c):
    if not c:
        return None
    c = dict(c)
    c["candles"] = [Candle(*x) if isinstance(x, (list, tuple)) else _mk(Candle, x) for x in c.get("candles", [])]
    c["positions"] = [_mk(Position, p) for p in c.get("positions", [])]
    c["pending"] = [_mk(PendingOrder, o) for o in c.get("pending", [])]
    c["plots"] = {n: [(p[0], p[1]) for p in pts] for n, pts in c.get("plots", {}).items()}
    c["events"] = []
    return c


def snapshot_from_json(d):
    if not d:
        return None
    s = dict(d)
    s["positions"] = [_mk(Position, p) for p in d.get("positions", [])]
    s["trades"] = [_mk(Trade, t) for t in d.get("trades", [])]
    s["pending"] = [_mk(PendingOrder, o) for o in d.get("pending", [])]
    s["alerts"] = [_mk(PriceAlert, a) for a in d.get("alerts", [])]
    s["chart"] = _chart_from_json(d.get("chart"))
    return s


def notification_text(snap):
    """(tiêu đề, nội dung) cho thông báo trên thanh trạng thái."""
    if not snap:
        return "PyEA Runner", "Đang chờ phiên giao dịch..."
    inst = snap.get("instances", [])
    run = [i for i in inst if i.get("status") == "running"]
    title = "PyEA • %d bot đang chạy" % len(run) if inst else "PyEA • giao dịch thủ công"
    if not snap.get("ready"):
        return title, snap.get("status_text", "")
    return title, "%s · %s · Equity %s (%+.2f%%) · %d lệnh mở" % (
        snap["status_text"], snap["mode"].upper(), "{:,.2f}".format(snap["equity"]), snap["pnl_pct"], len(snap["positions"]))


# --------------------------------------------------------------------------
# Client (dùng ở cả 2 phía)
# --------------------------------------------------------------------------
class ServiceClient:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.dir = os.path.join(data_dir, "ipc")
        self.cmd_dir = os.path.join(self.dir, "cmd")
        os.makedirs(self.cmd_dir, exist_ok=True)
        self.state_path = os.path.join(self.dir, "state.json")
        self.desired_path = os.path.join(self.dir, "desired.json")
        self.host_hb = os.path.join(self.dir, "host.hb")
        self.ui_hb = os.path.join(self.dir, "ui.hb")
        self._seq = 0

    # ---- lệnh ----
    def _box(self):
        from .keystore import box_for
        return box_for(self.data_dir)

    def send(self, cmd, **kw):
        if isinstance(kw.get("config"), dict):                 # khoá API KHÔNG nằm bản rõ trong ipc/cmd/*.json
            kw["config"] = self._box().seal_config(kw["config"])
        self._seq += 1
        name = "%017d_%04d.json" % (int(time.time() * 1e6), self._seq)
        _atomic_write(os.path.join(self.cmd_dir, name), json.dumps(dict(kw, cmd=cmd, t=time.time()), ensure_ascii=False))

    def pop_commands(self):
        out = []
        try:
            names = sorted(n for n in os.listdir(self.cmd_dir) if n.endswith(".json"))
        except OSError:
            return out
        for n in names:
            p = os.path.join(self.cmd_dir, n)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    c = json.load(f)
                if isinstance(c, dict) and isinstance(c.get("config"), dict):
                    c["config"] = self._box().open_config(c["config"])
                out.append(c)
            except Exception:
                pass
            try:
                os.remove(p)
            except OSError:
                pass
        return out

    # ---- trạng thái ----
    def write_state(self, d):
        _atomic_write(self.state_path, json.dumps(d, ensure_ascii=False, separators=(",", ":")))

    def read_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def read_desired(self):
        try:
            with open(self.desired_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict) and isinstance(d.get("config"), dict):
                d["config"] = self._box().open_config(d["config"])
            if isinstance(d, dict) and isinstance(d.get("extra"), dict):
                for v in d["extra"].values():
                    if isinstance(v, dict) and isinstance(v.get("config"), dict):
                        v["config"] = self._box().open_config(v["config"])
            return d
        except Exception:
            return None

    def write_desired(self, d):
        if isinstance(d, dict) and isinstance(d.get("config"), dict):
            d = dict(d, config=self._box().seal_config(d["config"]))
        if isinstance(d, dict) and isinstance(d.get("extra"), dict):
            d = dict(d, extra={k: (dict(v, config=self._box().seal_config(v["config"])) if isinstance(v, dict) and isinstance(v.get("config"), dict) else v)
                               for k, v in d["extra"].items()})
        _atomic_write(self.desired_path, json.dumps(d, ensure_ascii=False))

    # ---- heartbeat ----
    @staticmethod
    def _touch(path):
        with open(path, "a"):
            pass
        os.utime(path, None)

    def touch_host(self):
        self._touch(self.host_hb)

    def touch_ui(self):
        self._touch(self.ui_hb)

    @staticmethod
    def _age(path):
        try:
            return time.time() - os.path.getmtime(path)
        except OSError:
            return 1e9

    def host_alive(self, max_age=HB_FRESH):
        return self._age(self.host_hb) < max_age

    def ui_age(self):
        return self._age(self.ui_hb)

    def remove_host_hb(self):
        try:
            os.remove(self.host_hb)
        except OSError:
            pass


# --------------------------------------------------------------------------
# Handle phía UI: cùng giao diện với LocalController
# --------------------------------------------------------------------------
class _TaggedClient:
    """Bọc ServiceClient: mọi lệnh gửi đi tự thêm `account` (để dịch vụ nền chuyển đúng phiên)."""

    def __init__(self, client, account):
        self._c, self.account = client, account

    def send(self, cmd, **kw):
        kw["account"] = self.account
        return self._c.send(cmd, **kw)

    def __getattr__(self, name):
        return getattr(self._c, name)


class ServiceHandle:
    kind = "service"

    def __init__(self, client, events_path, token=None, pending=False):
        self.client = client
        self.token = token or uuid.uuid4().hex
        self._pending_since = time.time() if pending else 0.0
        self._state = None
        self._snap = None
        self._snap_pub = None
        self.events_log = ChatLog(events_path)
        self._ev_pos = 0
        self._events = []
        self._chart_sent = None
        self.expect_running = pending

    @classmethod
    def attach_running(cls, client, events_path):
        """Gắn vào phiên đang chạy nền (nếu có) khi mở lại app."""
        st = client.read_state()
        if st and st.get("session_alive") and client.host_alive():
            h = cls(client, events_path, token=st.get("token"))
            h.expect_running = True
            return h
        return None

    # ---- vòng đời ----
    def start(self, config):
        self.client.send("session_start", config=dict(config, token=self.token))
        self._pending_since = time.time()
        self.expect_running = True
        self._ev_pos, self._events = 0, []

    def stop(self):
        self.expect_running = False
        self.client.send("session_stop", token=self.token)

    def _refresh(self):
        st = self.client.read_state()
        if st:
            self._state = st
        return self._state

    def _mine(self, st):
        return st is not None and st.get("token") == self.token

    def pending(self):
        return bool(self._pending_since) and (time.time() - self._pending_since) < PENDING_GRACE

    def is_alive(self):
        st = self._refresh()
        if self._mine(st):
            return bool(st.get("session_alive")) and self.client.host_alive()
        return self.pending()

    def crashed(self):
        st = self._refresh()
        return self._mine(st) and bool(st.get("session_alive")) and not self.client.host_alive()

    def failed_to_start(self):
        st = self._refresh()
        return (not self._mine(st)) and bool(self._pending_since) and not self.pending() and not self.client.host_alive()

    def finished_state(self):
        st = self._refresh()
        if self._mine(st) and not st.get("session_alive"):
            return st.get("status"), st.get("message", "")
        return None

    # ---- dữ liệu ----
    def snapshot(self):
        st = self._refresh()
        if not self._mine(st):
            return None
        if st.get("pub") != self._snap_pub:
            self._snap_pub = st.get("pub")
            self._snap = snapshot_from_json(st.get("snapshot"))
            if isinstance(self._snap, dict):
                v = st.get("view", "main")
                self._snap["_account"] = v
                self._snap["_account_name"] = next((r.get("name") for r in st.get("accounts", []) if r.get("id") == v), v)
        return self._snap

    # ---- nhiều tài khoản ----
    def accounts(self):
        """Tóm tắt MỌI tài khoản đang có phiên trong dịch vụ (id, tên, trạng thái, vốn, số lệnh...)."""
        st = self._refresh() or {}
        return list(st.get("accounts", []))

    def view_account(self):
        return (self._refresh() or {}).get("view", "main")

    def set_view(self, account):
        """Chọn tài khoản mà snapshot/biểu đồ/nhật ký hiển thị (dịch vụ chạy song song tất cả, chỉ đổi cái được XEM)."""
        self.client.send("view_account", account=account)

    def for_account(self, account, events_path, token=None, pending=False):
        """Handle điều khiển MỘT tài khoản phụ: mọi lệnh tự gắn nhãn `account`."""
        return ServiceHandle(_TaggedClient(self.client, account), events_path, token=token, pending=pending)

    def set_chart(self, symbol, tf):
        if self._chart_sent != (symbol, tf):
            self._chart_sent = (symbol, tf)
            self.client.send("chart", symbol=symbol, tf=tf)

    def chart(self, symbol, tf, bars=None):
        snap = self.snapshot()
        c = (snap or {}).get("chart")
        if c and c["symbol"] == symbol and c["timeframe"] == tf:
            return c
        return None

    def get_logs(self, after=0):
        st = self._refresh()
        if not self._mine(st):
            return []
        return [tuple(x) for x in st.get("logs", []) if x[0] > after]

    def events(self):
        msgs, newpos = self.events_log.read_from(self._ev_pos)
        if newpos < self._ev_pos:
            self._events = []
        self._ev_pos = newpos
        for m in msgs:
            self._events.append(_mk(TradeEvent, m))
        del self._events[:-600]
        return list(self._events)

    def market_view(self, symbol=None, tf=None):
        snap = self.snapshot()
        return legacy_view(snap, (snap or {}).get("chart"))

    # ---- giao dịch thủ công (bất đồng bộ: kết quả thấy ở Giao dịch / Nhật ký) ----
    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment=""):
        self.client.send("order", symbol=symbol, side=side, volume=volume, sl=sl, tp=tp, comment=comment)
        return ("sent", None)

    def place_pending(self, symbol, side, kind, volume, price, stop_price=0.0, sl=0.0, tp=0.0, comment="", expiration=0.0):
        self.client.send("pending", symbol=symbol, side=side, kind=kind, volume=volume, price=price, stop_price=stop_price,
                         sl=sl, tp=tp, comment=comment, expiration=expiration)
        return ("sent", None)

    def cancel_order(self, order_id):
        self.client.send("cancel_order", order_id=order_id)
        return True

    def modify_order(self, order_id, price=None, sl=None, tp=None, expiration=None):
        self.client.send("modify_order", order_id=order_id, price=price, sl=sl, tp=tp, expiration=expiration)
        return True

    def close_position(self, pos_id, volume=None):
        self.client.send("close", pos_id=pos_id, volume=volume)
        return True

    def request_close_all(self, symbol=None):
        self.client.send("close_all", symbol=symbol)

    # ---- an toàn ----
    def kill_switch(self, reason="Người dùng bấm Kill switch"):
        self.client.send("kill", reason=reason)

    def resume_trading(self):
        self.client.send("resume")

    def sync_exchange_now(self):
        self.client.send("sync_now")
        return True

    def exchange_trades(self, limit=200):
        # lịch sử đã lưu trong thư mục dữ liệu của phiên (file jsonl) - đọc trực tiếp, không cần hỏi dịch vụ
        p = os.path.join(self.client.data_dir, "exchange_history.jsonl")
        out = []
        try:
            with open(p, "r", encoding="utf-8") as f:
                for ln in f.readlines()[-max(1, int(limit)):]:
                    try:
                        out.append(json.loads(ln))
                    except ValueError:
                        pass
        except OSError:
            pass
        return out[::-1]

    def reset_paper(self):
        self.client.send("reset_paper")

    # ---- cảnh báo giá ----
    def alert_add(self, symbol, kind, value, note="", repeat=False, tf="", period=14, period2=0):
        self.client.send("alert_add", symbol=symbol, kind=kind, value=value, note=note, repeat=repeat, tf=tf, period=period, period2=period2)
        return True

    def alert_remove(self, alert_id):
        self.client.send("alert_remove", alert_id=alert_id)
        return True

    def modify_position(self, pos_id, sl=None, tp=None):
        self.client.send("modify", pos_id=pos_id, sl=sl, tp=tp)
        return True

    def set_watch(self, symbols):
        self.client.send("watch", symbols=list(symbols))

    # ---- bot gắn vào tài sản ----
    def attach(self, cfg, start=True):
        self.client.send("attach", cfg=dict(cfg), start=bool(start))

    def detach(self, iid):
        self.client.send("detach", iid=iid)

    def set_params(self, iid, params):
        self.client.send("params", iid=iid, params=dict(params))
        return True

    def set_trace(self, iid, on):
        self.client.send("trace", iid=iid, on=bool(on))
        return True

    def reload_bot(self, iid):
        self.client.send("reload", iid=iid)
        return True

    def inst_start(self, iid):
        self.client.send("inst_start", iid=iid)

    def inst_stop(self, iid):
        self.client.send("inst_stop", iid=iid)

    # ---- AI ----
    def ai_info(self):
        st = self._refresh()
        return (st or {}).get("ai") or {}

    def set_ai_auto(self, on):
        self.client.send("ai_auto", on=bool(on))

    def alarms(self):
        st = self._refresh()
        return (st or {}).get("alarms") or []


# --------------------------------------------------------------------------
# Host (chạy trong dịch vụ nền)
# --------------------------------------------------------------------------
MAIN = "main"


class _Runtime:
    """Một phiên giao dịch của một tài khoản trong dịch vụ nền (tài khoản chính hoặc phụ)."""

    def __init__(self, rid, store, name=""):
        self.id, self.store, self.name = rid, store, name or rid
        self.session = None
        self.hub = None
        self.config = None
        self.settings = {}
        self.token = None
        self.finished_at = None


def _delegate(name):
    return property(lambda self: getattr(self._cur, name), lambda self, v: setattr(self._cur, name, v))


class ServiceHost:
    """Dịch vụ nền. Chạy MỘT phiên cho tài khoản chính và thêm một phiên cho MỖI tài khoản phụ (song song).
    Các thuộc tính cũ (session/config/hub/settings/token/store) trỏ vào phiên "hiện hành" `_cur` để mã xử lý lệnh dùng chung."""

    def __init__(self, data_dir, alarm=None, set_notification=None, sleep=0.25, exit_grace=6.0, idle_exit=20.0, watchdog=None):
        self.data_dir = data_dir
        self.watchdog = watchdog                   # pyea.watchdog.Watchdog (báo thức AlarmManager dựng lại dịch vụ nếu bị giết) hoặc None
        self._wd_next = 0.0
        self.rt = {MAIN: _Runtime(MAIN, Store(data_dir), "Chính")}
        self.rt[MAIN].store.maintain(trim=False)
        dnd.configure(os.path.join(self.rt[MAIN].store.base, dnd.FILE))        # cùng file với UI: bấm «tạm hoãn» bên UI là dịch vụ thấy ngay
        self._cur = self.rt[MAIN]
        self.view = MAIN
        self.client = ServiceClient(data_dir)
        self.alarm_fn = alarm
        self.set_notification = set_notification
        self.sleep = sleep
        self.exit_grace = exit_grace
        self.idle_exit = idle_exit
        self.alarms = []
        self._pub = 0
        self._last_pub = 0.0
        self._last_notif = 0.0
        self._idle_since = time.time()
        self._exit = False
        self._exit_posted = False

    # ---- thuộc tính ủy quyền tới phiên hiện hành ----
    session = _delegate("session")
    hub = _delegate("hub")
    config = _delegate("config")
    settings = _delegate("settings")
    token = _delegate("token")
    store = _delegate("store")
    _finished_at = _delegate("finished_at")

    def _runtime(self, rid, create=False, name=""):
        rt = self.rt.get(rid)
        if rt is None and create and rid != MAIN:
            from .accounts import AccountBook
            rt = self.rt[rid] = _Runtime(rid, Store(AccountBook(self.data_dir).data_dir_for(rid)), name)
        if rt is not None and name:
            rt.name = name
        return rt

    # ---- cảnh báo ----
    def alarm(self, title, text):
        self._alarm_for(self._cur, title, text)

    def _alarm_for(self, rt, title, text, quiet=False):
        """Báo động của MỘT phiên: gắn nhãn tài khoản phụ (luồng phiên gọi từ thread riêng nên không dựa vào `_cur`).
        quiet=True («Không làm phiền»): vẫn ghi vào danh sách + đăng thông báo, nhưng IM LẶNG và UI không bật popup."""
        if rt.id != MAIN:
            title = "[%s] %s" % (rt.name, title)
        self.alarms.append({"t": time.time(), "title": title, "text": text, "quiet": bool(quiet)})
        del self.alarms[:-20]
        if self.alarm_fn:
            try:
                if quiet:
                    self.alarm_fn(title, text, quiet=True)
                else:
                    self.alarm_fn(title, text)
            except Exception:
                pass

    # ---- AI hub ----
    def _hub_snapshot(self):
        s = self.session
        if s is None:
            return None
        i = next(iter(s.instances.values()), None)
        sym, tf = (i.symbol, i.tf) if i else (s.chart_req or (None, None))
        return legacy_view(s.snapshot(), s.chart(sym, tf, 80) if sym else None)

    def _hub_bot(self):
        s = self.session
        i = next(iter(s.instances.values()), None) if s else None
        if i is None:
            return None
        info = inspect_bot(i.bot_path)
        try:
            with open(i.bot_path, "r", encoding="utf-8") as f:
                src = f.read()
        except OSError:
            return None
        params = build_params(info.inputs, i.params) if info.ok else {}
        return (info.name if info.ok else i.iid, src, params)

    # ---- phiên ----
    def _save_desired(self, running=True):
        d = self.client.read_desired() or {}
        if self._cur.id == MAIN:
            d["running"] = running
            if self.config is not None:
                d["config"] = self.config
        else:
            ex = d.setdefault("extra", {})
            ent = ex.setdefault(self._cur.id, {})
            ent["running"] = running
            ent["name"] = self._cur.name
            if self.config is not None:
                ent["config"] = self.config
        self.client.write_desired(d)

    def start_session(self, config):
        if self.session is not None and self.session.is_alive():
            self.session.stop(wait=True)
        self.config = config
        self.settings = config["settings"]
        self.token = config["token"]
        resume = bool(config.get("resume"))
        if not resume:                      # phiên mới: xoá sổ lệnh + sự kiện của phiên cũ
            try:
                os.remove(self.store.state_path)
            except OSError:
                pass
            try:
                open(self.store.events_path, "w").close()
            except OSError:
                pass
        self.hub = AIHub(self.store, self._hub_snapshot, self._hub_bot, lambda: self.settings)
        log_file, trades_csv = config.get("log_file"), config.get("trades_csv")
        if self._cur.id != MAIN:            # tài khoản phụ: nhật ký + lịch sử lệnh riêng trong thư mục của nó
            log_file = os.path.join(self.store.logs_dir, time.strftime("%Y%m%d") + ".log")
            trades_csv = self.store.trades_csv
        prefs.apply(self.settings)                  # giờ hiển thị + âm/rung thông báo theo cài đặt của phiên
        self.session = TradingSession(
            self.settings, log_file=log_file, trades_csv=trades_csv,
            state_file=self.store.state_path, events_file=self.store.events_path, resume=resume, alerts_file=self.store.alerts_path,
            alarm_cb=lambda t, x, rt=self._cur, **kw: self._alarm_for(rt, t, x, **kw),
            notify_cb=lambda t, x, rt=self._cur: self._post_notification(t if rt.id == MAIN else "[%s] %s" % (rt.name, t), x), ai_hub=self.hub)
        self.session.interval_override = None
        for cfg in config.get("instances", []):
            self._attach(cfg, cfg.get("running", True), save=False)
        self.session.start()
        self._finished_at = None
        self._save_desired(True)
        if config.get("ai_auto"):
            self.hub.start_auto()
        self._publish(force=True)

    def _attach(self, cfg, start, save=True):
        inst = self.session.attach(cfg["bot_path"], cfg["symbol"], cfg["tf"], cfg.get("params", {}), iid=cfg["iid"])
        inst.trace_on = bool(cfg.get("trace"))
        if start:
            inst.start()
        if save and self.config is not None:
            lst = [c for c in self.config.get("instances", []) if c["iid"] != cfg["iid"]]
            self.config["instances"] = lst + [dict(cfg, running=bool(start))]
            self._save_desired(True)

    def _set_running(self, iid, running):
        for c in (self.config or {}).get("instances", []):
            if c["iid"] == iid:
                c["running"] = running
        self._save_desired(True)

    def _post_notification(self, title, text):
        if self.set_notification:
            try:
                self.set_notification(title, text)
            except Exception:
                pass

    def _consume(self):
        for c in self.client.pop_commands():
            cmd = c.get("cmd")
            rid = c.get("account") or MAIN
            if cmd == "view_account":
                if rid in self.rt and self.rt[rid].session is not None:
                    self.view = rid
                    self._publish(force=True)
                continue
            rt = self._runtime(rid, create=(cmd == "session_start"), name=(c.get("config") or {}).get("account_name", "") if cmd == "session_start" else "")
            if rt is None:
                continue
            self._cur = rt
            try:
                self._handle(cmd, c)
            finally:
                self._cur = self.rt[MAIN]

    def _handle(self, cmd, c):
        s = self.session
        try:
            if cmd == "session_start":
                self.start_session(c["config"])
            elif s is None:
                return
            elif cmd == "session_stop" and c.get("token") in (None, self.token):
                s.stop()
                for i in list(s.instances.values()):
                    i.stop()
            elif cmd == "order":
                s.place_order(c["symbol"], c["side"], c["volume"], c.get("sl", 0), c.get("tp", 0), c.get("comment", ""))
            elif cmd == "pending":
                s.place_pending(c["symbol"], c["side"], c["kind"], c["volume"], c["price"], c.get("stop_price", 0), c.get("sl", 0),
                                c.get("tp", 0), c.get("comment", ""), "manual", c.get("expiration", 0), "Đặt lệnh chờ thủ công từ ứng dụng")
            elif cmd == "cancel_order":
                s.cancel_order(int(c["order_id"]), "manual", "Người dùng huỷ lệnh chờ #%s" % c["order_id"])
            elif cmd == "modify_order":
                s.modify_order(int(c["order_id"]), c.get("price"), c.get("sl"), c.get("tp"), c.get("expiration"))
            elif cmd == "kill":
                s.request_kill(c.get("reason") or "Người dùng bấm Kill switch")
                for x in (self.config or {}).get("instances", []):
                    x["running"] = False                 # để lần resume sau KHÔNG tự bật lại các bot đã bị Kill
                self._save_desired(True)
            elif cmd == "resume":
                s._cmds.put(("resume",))
            elif cmd == "sync_now":
                threading.Thread(target=lambda: s.sync_exchange(force=True), name="sync-now", daemon=True).start()
            elif cmd == "reset_paper":
                s._cmds.put(("reset_paper",))
            elif cmd == "alert_add":
                s.alert_add(c["symbol"], c["kind"], c["value"], c.get("note", ""), bool(c.get("repeat")),
                            c.get("tf", ""), int(c.get("period") or 14), int(c.get("period2") or 0))
            elif cmd == "alert_remove":
                s.alert_remove(int(c["alert_id"]))
            elif cmd == "close":
                s.close_position(int(c["pos_id"]), "manual", "Người dùng đóng lệnh #%s" % c["pos_id"], volume=c.get("volume"))
            elif cmd == "close_all":
                s.request_close_all(c.get("symbol"))
            elif cmd == "modify":
                s.modify_position(int(c["pos_id"]), c.get("sl"), c.get("tp"))
            elif cmd == "watch":
                s.set_watch(c.get("symbols", []))
            elif cmd == "chart":
                s.set_chart(c["symbol"], c["tf"])
            elif cmd == "attach":
                self._attach(c["cfg"], c.get("start", True))
            elif cmd == "detach":
                s.detach(c["iid"])
                self.config["instances"] = [x for x in self.config.get("instances", []) if x["iid"] != c["iid"]]
                self._save_desired(True)
            elif cmd == "params" and c["iid"] in s.instances:
                s.instances[c["iid"]].apply_params(c["params"])
                for x in (self.config or {}).get("instances", []):
                    if x["iid"] == c["iid"]:
                        x["params"] = dict(c["params"])
                self._save_desired(True)
            elif cmd == "reload" and c["iid"] in s.instances:
                s.instances[c["iid"]].reload_code()
            elif cmd == "trace" and c["iid"] in s.instances:
                s.instances[c["iid"]].set_trace(c.get("on"))
                for x in (self.config or {}).get("instances", []):
                    if x["iid"] == c["iid"]:
                        x["trace"] = bool(c.get("on"))
                self._save_desired(True)
            elif cmd == "inst_start" and c["iid"] in s.instances:
                i = s.instances[c["iid"]]
                if not i.is_alive():
                    i.status = "idle"
                    i.start()
                self._set_running(c["iid"], True)
            elif cmd == "inst_stop" and c["iid"] in s.instances:
                s.instances[c["iid"]].stop()
                self._set_running(c["iid"], False)
            elif cmd == "ai_auto" and self.hub:
                (self.hub.start_auto if c.get("on") else self.hub.stop_auto)()
        except Exception:
            self.alarm("Lỗi dịch vụ nền", traceback.format_exc(limit=2).strip().splitlines()[-1])

    def _maybe_resume(self):
        """Khởi động lại sau crash/bị hệ thống giết: các phiên đang 'cần chạy' (chính + phụ) -> chạy lại + khôi phục sổ lệnh."""
        d = self.client.read_desired()
        if not d:
            return
        todo = []
        if self.rt[MAIN].session is None and d.get("running") and d.get("config"):
            todo.append((MAIN, dict(d["config"]), "Chính"))
        for rid, ent in (d.get("extra") or {}).items():
            rt = self.rt.get(rid)
            if (rt is None or rt.session is None) and isinstance(ent, dict) and ent.get("running") and ent.get("config"):
                todo.append((rid, dict(ent["config"]), ent.get("name") or rid))
        if not todo:
            return
        keep = []
        for rid, cfg, name in todo:
            if not cfg.get("settings", {}).get("auto_resume", True):
                if rid == MAIN:
                    d["running"] = False
                else:
                    d["extra"][rid]["running"] = False
                self.client.write_desired(d)
            else:
                keep.append((rid, cfg, name))
        if not keep:
            return
        now = time.time()
        restarts = [t for t in d.get("restarts", []) if now - t < 300]
        if len(restarts) >= 3:
            d["running"], d["restarts"] = False, restarts
            for ent in (d.get("extra") or {}).values():
                if isinstance(ent, dict):
                    ent["running"] = False
            self.client.write_desired(d)
            self.alarm("Dịch vụ crash liên tục", "Đã tự khởi động lại 3 lần trong 5 phút. Phiên KHÔNG được chạy lại - hãy mở app kiểm tra.")
            return
        restarts.append(now)
        d["restarts"] = restarts
        self.client.write_desired(d)
        self.alarm("Phiên được khôi phục sau sự cố", "Dịch vụ nền bị dừng đột ngột và đã tự chạy lại (khôi phục sổ lệnh và các bot).")
        for rid, cfg, name in keep:
            rt = self._runtime(rid, create=True, name=name)
            self._cur = rt
            try:
                cfg["resume"] = True
                self.start_session(cfg)
            finally:
                self._cur = self.rt[MAIN]

    # ---- publish ----
    def _summary(self, rt):
        s = rt.session
        row = {"id": rt.id, "name": rt.name, "token": rt.token, "alive": bool(s and s.is_alive()), "status": s.status if s else "idle", "message": s.message if s else "",
               "exchange": (rt.settings or {}).get("exchange", ""), "mode": (rt.settings or {}).get("mode", "")}
        if s is not None:
            try:
                snap = s.snapshot()
                row.update(equity=snap.get("equity"), balance=snap.get("balance"), positions=len(snap.get("positions", []) or []),
                           pending=len(snap.get("pending", []) or []), bots=len(snap.get("instances", []) or []))
            except Exception:                                                  # noqa: BLE001 - tóm tắt hỏng không được chặn publish
                pass
        return row

    def _publish(self, force=False, phase="running"):
        now = time.time()
        visible = self.client.ui_age() < 5.0
        every = 1.0 if visible else 10.0
        if not force and now - self._last_pub < every:
            return
        self._last_pub = now
        self._pub += 1
        vrt = self.rt.get(self.view)
        if vrt is None or vrt.session is None:
            self.view, vrt = MAIN, self.rt[MAIN]
        self._cur = vrt
        try:
            st = {"pub": self._pub, "hb": now, "pid": os.getpid(), "phase": phase, "token": self.token,
                  "ui_visible": visible, "alarms": self.alarms[-20:], "session_alive": False,
                  "status": "idle", "message": "", "snapshot": None, "logs": [], "ai": {}, "view": vrt.id}
            s = self.session
            if s is not None:
                st["session_alive"] = s.is_alive()
                st["status"], st["message"] = s.status, s.message
                chart = s.chart(*s.chart_req, bars=int(s.settings.get("chart_bars", 400))) if s.chart_req else None
                st["snapshot"] = snapshot_to_json(s.snapshot(), chart)
                st["logs"] = [list(x) for x in s.get_logs(0)[-150:]]
            if self.hub is not None:
                st["ai"] = {"auto_on": self.hub.auto_on, "signal": jsonable(self.hub.get_signal()),
                            "status": self.hub.status_text, "busy": self.hub.busy}
            st["accounts"] = [self._summary(rt) for rt in self.rt.values() if rt.session is not None]
        finally:
            self._cur = self.rt[MAIN]
        self.client.write_state(st)

    def _update_notification(self, force=False):
        now = time.time()
        if not force and now - self._last_notif < 12.0:
            return
        self._last_notif = now
        main = self.rt[MAIN].session
        if main is not None and self.set_notification:
            t, x = notification_text(main.snapshot())
            extra = [r for r in self.rt.values() if r.id != MAIN and r.session is not None and r.session.is_alive()]
            if extra:
                x = "%s  |  +%d tài khoản phụ: %s" % (x, len(extra), ", ".join(r.name for r in extra[:3]))
            self._post_notification(t, x)
        elif main is None and self.set_notification:
            extra = [r for r in self.rt.values() if r.session is not None and r.session.is_alive()]
            if extra:
                self._post_notification("PyEA Runner", "%d tài khoản đang chạy: %s" % (len(extra), ", ".join(r.name for r in extra[:3])))

    # ---- vòng chính ----
    def _watchdog_want(self):
        """(cần giữ báo thức?, chu kỳ giây). Cần khi có phiên đang chạy hoặc `desired` còn ghi «cần chạy» VÀ người dùng bật `watchdog_alarm` + `auto_resume`."""
        d = self.client.read_desired() or {}
        want = bool(d.get("running") and d.get("config")) or any(isinstance(e, dict) and e.get("running") and e.get("config") for e in (d.get("extra") or {}).values())
        want = want or any(rt.session is not None and rt.session.is_alive() for rt in self.rt.values())
        st = self.rt[MAIN].settings or ((d.get("config") or {}).get("settings") or {})
        enabled = bool(st.get("watchdog_alarm", True)) and bool(st.get("auto_resume", True))
        try:
            secs = float(st.get("watchdog_minutes", 5.0)) * 60.0
        except (TypeError, ValueError):
            secs = 300.0
        return want and enabled, secs

    def _watchdog_tick(self):
        wd = self.watchdog
        now = time.time()
        if wd is None or now < self._wd_next:
            return
        self._wd_next = now + 5.0
        try:
            want, secs = self._watchdog_want()
            wd.set_interval(secs)
            wd.tick(want)
        except Exception:                                                      # noqa: BLE001 - giám sát hỏng không được làm sập dịch vụ
            pass

    def run(self):
        self.client.touch_host()
        self._consume()
        self._maybe_resume()
        try:
            while not self._exit:
                self.client.touch_host()
                self._consume()
                self._watchdog_tick()
                sessions = [rt for rt in self.rt.values() if rt.session is not None]
                if sessions:
                    visible = self.client.ui_age() < 5.0
                    alive_any, newly_done = False, False
                    for rt in sessions:
                        s = rt.session
                        s.interval_override = 3.0 if ((rt.settings or {}).get("power_mode") == "saver" and not visible) else None
                        if not s.is_alive() and rt.finished_at is None:
                            rt.finished_at = time.time()
                            self._cur = rt
                            try:
                                self._save_desired(False)
                                if rt.hub:
                                    rt.hub.stop_auto()
                            finally:
                                self._cur = self.rt[MAIN]
                            newly_done = True
                        elif s.is_alive():
                            alive_any = True
                    if alive_any:
                        self._idle_since = time.time()
                        self._exit_posted = False
                        self._publish()
                        self._update_notification()
                    elif newly_done or not self._exit_posted:
                        self._exit_posted = True
                        self._publish(force=True, phase="exiting")
                        self._update_notification(force=True)
                    if not alive_any:
                        last = max((rt.finished_at or 0.0) for rt in sessions)
                        if last and time.time() - last > self.exit_grace:
                            self._exit = True
                elif time.time() - self._idle_since > self.idle_exit:
                    self._exit = True
                time.sleep(self.sleep)
        finally:
            try:
                self._publish(force=True, phase="exited")
            finally:
                self.client.remove_host_hb()
                if self.watchdog is not None:
                    self.watchdog.stop()                                       # dịch vụ thoát có chủ đích -> huỷ báo thức (không để nó dựng lại vô cớ)
