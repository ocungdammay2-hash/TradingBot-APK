"""
CẦU NỐI MT4/MT5 (và mọi dịch vụ REST giống MT). Dùng cho tài khoản Exness MT4/MT5 và MỌI broker MetaTrader.

Kiến trúc: một giao diện backend CHUẨN HOÁ (MtBackend) + một MtBroker/MtFeed dùng chung. Mỗi cách nối chỉ cần viết backend:
  MetaApiBackend  : dịch vụ đám mây MetaApi (REST). Đã đối chiếu tài liệu chính thức (trade, giá, nến, vị thế, lịch sử deal).
  GatewayBackend  : "PyEA MT Gateway" tự dựng (thư mục gateway/): chạy trên Windows/VPS, có 2 cách nối với terminal:
                      - gói Python chính thức `MetaTrader5` (MT5)             -> gateway/mt_gateway.py --backend mt5
                      - Expert Advisor PyEA_Bridge.mq5 / .mq4 qua WebRequest   -> gateway/mt_gateway.py --backend ea   (MT4 + MT5)
  ProfileBackend  : dịch vụ REST khác (TickerAll, mt5api, ...): khai báo bằng JSON (đường dẫn + ánh xạ trường), không cần viết mã.
Cài đặt: exchange = metaapi | mt5gw | bridge.
"""
import json
import re
import time
import urllib.parse
from datetime import datetime, timezone

from .acctstate import normalize_position_stats
from .brokerhist import classify
from .broker import BrokerError, Fill
from .protection import POS_PREFIX, ProtectionAPI, close_from_deals
from .exness import _dig, _find_list, _num, _side, _ts
from .feeds import FeedError, HttpError, TIMEFRAMES, history_resampled, http_json
from .ratelimit import limiter_for
from .sdk import Candle, Tick


def _iso(t):
    return datetime.fromtimestamp(float(t), timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _opt(d, *names):
    """Giá trị số đầu tiên có mặt (không None) trong d theo các tên; None nếu sàn không báo trường nào."""
    for n in names:
        if d.get(n) is not None and d.get(n) != "":
            return _num(d[n])
    return None


def _stats(d, **spec):
    """{khoá: số} cho các trường lãi/lỗ vị thế mà sàn CÓ báo (vắng thì bỏ khoá - không bịa 0)."""
    out = {}
    for k, names in spec.items():
        v = _opt(d, *names)
        if v is not None:
            out[k] = v
    return out


class BridgeError(BrokerError):
    def __init__(self, msg, status=0, code=""):
        BrokerError.__init__(self, msg)
        self.status, self.code = status, code


# =========================================================================================== giao diện chuẩn
class MtBackend:
    """Mọi backend trả dữ liệu ĐÃ CHUẨN HOÁ:
       tick -> (bid, ask, epoch) · candles -> [Candle] · account -> dict(balance, equity, margin, free_margin, leverage, currency, hedging)
       positions -> [dict(id, symbol, side, volume, price, sl, tp, time)] · orders -> [dict(id, symbol, side, kind, volume, price, sl, tp)]
       market/close_position -> dict(order_id, position_id, price, volume) (price có thể None) · deals -> [dict(id,time,symbol,side,qty,price,fee,pnl,order_id)]
       spec -> dict(volume_min, volume_max, volume_step)"""
    name = "mt"
    max_chunk = 1000
    native_kinds = {"limit", "stop", "stop_limit"}
    limiter_kind = "generic"

    def ping(self):
        return self.account()

    def symbols(self): raise NotImplementedError
    def tick(self, symbol): raise NotImplementedError
    def candles(self, symbol, tf, count, end=None): raise NotImplementedError
    def account(self): raise NotImplementedError
    def positions(self): raise NotImplementedError
    def orders(self): raise NotImplementedError
    def spec(self, symbol): raise NotImplementedError
    def market(self, symbol, side, volume, comment=""): raise NotImplementedError
    def close_position(self, position_id, volume=None): raise NotImplementedError
    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""): raise NotImplementedError
    def modify_pending(self, order_id, price=None, sl=None, tp=None): raise NotImplementedError
    def cancel_pending(self, order_id): raise NotImplementedError
    def deals(self, since): raise NotImplementedError
    can_modify_position = False        # True: backend sửa được SL/TP của MỘT vị thế đang mở (modify_position) -> SL/TP native theo ticket

    def modify_position(self, position_id, sl, tp):
        """Đặt SL/TP của vị thế `position_id` (CẢ HAI mức; 0 = không đặt). Mặc định: backend không hỗ trợ."""
        raise BridgeError("Backend %s chưa hỗ trợ sửa SL/TP theo vị thế" % self.name)

    def history(self, since, until=None):
        """Lịch sử ĐẦY ĐỦ của tài khoản từ `since` tới `until` (epoch UTC) theo hợp đồng pyea/brokerhist.py: mọi loại deal (giao dịch, nạp/rút, credit...) với
        profit/commission/swap/fee tách riêng. Mặc định: backend không hỗ trợ."""
        raise BridgeError("Backend %s chưa hỗ trợ lịch sử đồng bộ từ sàn" % self.name)

    def deals_by_position(self, position_id):
        """Các deal của MỘT vị thế (mở + đóng) -> cùng dạng `deals()` (có thêm position_id, entry). Mặc định: lọc từ deals() 30 ngày."""
        pid = str(position_id)
        return [d for d in self.deals(time.time() - 30 * 86400) if str(d.get("position_id", "")) == pid]

    def close(self): pass


# =========================================================================================== MetaApi (cloud)
class MetaApiBackend(MtBackend):
    name = "metaapi"
    limiter_kind = "metaapi"
    TF = {"1m": "1m", "2m": "2m", "3m": "3m", "5m": "5m", "10m": "10m", "15m": "15m", "30m": "30m", "1h": "1h", "2h": "2h", "4h": "4h",
          "6h": "6h", "12h": "12h", "1d": "1d", "1w": "1w", "1mo": "1mn"}
    ACTION = {("buy", "limit"): "ORDER_TYPE_BUY_LIMIT", ("sell", "limit"): "ORDER_TYPE_SELL_LIMIT", ("buy", "stop"): "ORDER_TYPE_BUY_STOP",
              ("sell", "stop"): "ORDER_TYPE_SELL_STOP", ("buy", "stop_limit"): "ORDER_TYPE_BUY_STOP_LIMIT",
              ("sell", "stop_limit"): "ORDER_TYPE_SELL_STOP_LIMIT"}

    def __init__(self, token, account_id, region="new-york", client_url="", data_url="", timeout=20):
        if not str(token or "").strip():
            raise BridgeError("Thiếu MetaApi token")
        if not str(account_id or "").strip():
            raise BridgeError("Thiếu MetaApi account id")
        self.token, self.acc = str(token).strip(), str(account_id).strip()
        region = (region or "new-york").strip()
        self.url = (client_url or "https://mt-client-api-v1.%s.agiliumtrade.ai" % region).rstrip("/")
        self.data_url = (data_url or "https://mt-market-data-client-api-v1.%s.agiliumtrade.ai" % region).rstrip("/")
        self.timeout = timeout
        self.lim = limiter_for("metaapi", self.url)

    def _req(self, method, path, params=None, body=None, data=False, cost=1):
        base = self.data_url if data else self.url
        try:
            return http_json(base + "/users/current/accounts/%s%s" % (self.acc, path), params, headers={"auth-token": self.token, "Accept": "application/json"},
                             method=method, timeout=self.timeout, body=body, limiter=self.lim, cost=cost)
        except HttpError as e:
            hint = {401: " - kiểm tra token MetaApi", 404: " - tài khoản chưa được triển khai/kết nối trên MetaApi (hãy Deploy trong web MetaApi)",
                    429: " - vượt giới hạn MetaApi, app tự giãn nhịp", 400: " - payload không hợp lệ"}.get(e.status, "")
            raise BridgeError("MetaApi HTTP %s: %s%s" % (e.status, (e.body or "")[:160], hint), e.status)
        except FeedError as e:
            raise BridgeError(str(e))

    # ---- dữ liệu ----
    def symbols(self):
        d = self._req("GET", "/symbols")
        return sorted(s if isinstance(s, str) else str(_dig(s, ("symbol", "name"), 0) or "") for s in (d if isinstance(d, list) else d.get("symbols", [])))

    def tick(self, symbol):
        d = self._req("GET", "/symbols/%s/current-price" % urllib.parse.quote(symbol, safe=""), {"keepSubscription": "true"})
        return _num(d.get("bid")), _num(d.get("ask")), _ts(d.get("time") or d.get("brokerTime"))

    def candles(self, symbol, tf, count, end=None):
        name = self.TF.get(tf)
        if name is None:
            raise BridgeError("MetaApi không có khung %s" % tf)
        params = {"limit": int(min(count, self.max_chunk))}
        params["startTime"] = _iso(end if end is not None else time.time() + 60)
        d = self._req("GET", "/historical-market-data/symbols/%s/timeframes/%s/candles" % (urllib.parse.quote(symbol, safe=""), name), params, data=True, cost=2)
        out = []
        for c in (d if isinstance(d, list) else []):
            out.append(Candle(_ts(c.get("time")), _num(c.get("open")), _num(c.get("high")), _num(c.get("low")), _num(c.get("close")),
                              _num(c.get("tickVolume", c.get("volume")))))
        out.sort(key=lambda c: c.time)
        return out

    def account(self):
        d = self._req("GET", "/accountInformation")
        hedge = None
        m = str(d.get("marginMode", ""))
        if m:
            hedge = "HEDGING" in m.upper()
        return {"balance": _num(d.get("balance")), "equity": _num(d.get("equity")), "margin": _num(d.get("margin")),
                "free_margin": _num(d.get("freeMargin")), "leverage": _num(d.get("leverage"), 1.0), "currency": d.get("currency", ""), "hedging": hedge,
                "margin_level": _num(d.get("marginLevel"), None), "credit": _num(d.get("credit"), None)}      # MetatraderAccountInformation: marginLevel (không bắt buộc), credit

    def positions(self):
        out = []
        for p in self._req("GET", "/positions") or []:
            out.append({"id": str(p.get("id")), "symbol": p.get("symbol"), "side": _side(p.get("type")), "volume": _num(p.get("volume")),
                        "price": _num(p.get("openPrice")), "sl": _num(p.get("stopLoss")), "tp": _num(p.get("takeProfit")), "time": _ts(p.get("time")),
                        "comment": str(p.get("comment") or ""),
                        # MetatraderPosition: unrealized* = phần ĐANG MỞ (profit không gồm swap/hoa hồng); `profit`/`swap`/`commission` là tổng cả phần đã đóng
                        **_stats(p, profit=("unrealizedProfit", "profit"), swap=("unrealizedSwap", "swap"), commission=("unrealizedCommission", "commission"),
                                 price_now=("currentPrice",))})
        return out

    def orders(self):
        out = []
        for o in self._req("GET", "/orders") or []:
            t = str(o.get("type", "")).upper()
            kind = "stop_limit" if "STOP_LIMIT" in t else ("limit" if "LIMIT" in t else ("stop" if "STOP" in t else ""))
            out.append({"id": str(o.get("id")), "symbol": o.get("symbol"), "side": _side(t), "kind": kind,
                        "volume": _num(o.get("currentVolume", o.get("volume"))), "price": _num(o.get("openPrice")), "sl": _num(o.get("stopLoss")),
                        "tp": _num(o.get("takeProfit"))})
        return out

    def spec(self, symbol):
        d = self._req("GET", "/symbols/%s/specification" % urllib.parse.quote(symbol, safe=""))
        return {"volume_min": _num(d.get("minVolume")), "volume_max": _num(d.get("maxVolume")), "volume_step": _num(d.get("volumeStep"))}

    # ---- giao dịch (MetaApi trả HTTP 200 cả khi MT từ chối -> đọc mã) ----
    def _trade(self, body):
        d = self._req("POST", "/trade", body=body)
        code = int(_num(d.get("numericCode"), 0))
        if code not in (10008, 10009, 10010):
            raise BridgeError("MT từ chối lệnh: %s (%s) %s" % (d.get("stringCode", code), code, d.get("message", "")), 200, str(d.get("stringCode", code)))
        return d

    def market(self, symbol, side, volume, comment=""):
        body = {"actionType": "ORDER_TYPE_BUY" if side == "buy" else "ORDER_TYPE_SELL", "symbol": symbol, "volume": float(volume)}
        if comment:
            body["comment"] = comment[:26]
        d = self._trade(body)
        return {"order_id": str(d.get("orderId", "")), "position_id": str(d.get("positionId", "")), "price": None, "volume": float(volume)}

    def close_position(self, position_id, volume=None):
        body = ({"actionType": "POSITION_PARTIAL", "positionId": str(position_id), "volume": float(volume)} if volume
                else {"actionType": "POSITION_CLOSE_ID", "positionId": str(position_id)})
        d = self._trade(body)
        return {"order_id": str(d.get("orderId", "")), "position_id": str(position_id), "price": None, "volume": volume}

    can_modify_position = True

    def modify_position(self, position_id, sl, tp):
        """POSITION_MODIFY (tài liệu MetaApi: `positionId` bắt buộc cho lệnh sửa vị thế; stopLoss/takeProfit là GIÁ, min 0). Gửi CẢ HAI mức vì tài liệu
        không nói mức bị bỏ trống được giữ hay xoá. Giá trị 0 = không đặt là quy ước MT, tài liệu MetaApi KHÔNG nói rõ - `selfcheck --trade` kiểm trên demo."""
        self._trade({"actionType": "POSITION_MODIFY", "positionId": str(position_id), "stopLoss": float(sl or 0.0), "takeProfit": float(tp or 0.0)})

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        act = self.ACTION.get((side, kind))
        if not act:
            raise BridgeError("MetaApi không có lệnh chờ %s %s" % (side, kind))
        body = {"actionType": act, "symbol": symbol, "volume": float(volume)}
        if kind == "stop_limit":
            body["openPrice"], body["stopLimitPrice"] = float(stop_price), float(price)       # MT: openPrice = giá KÍCH HOẠT, stopLimitPrice = giá limit
        else:
            body["openPrice"] = float(price)
        if expiry:
            body["expiration"] = {"type": "ORDER_TIME_SPECIFIED", "time": _iso(expiry)}
        if comment:
            body["comment"] = comment[:26]
        return str(self._trade(body).get("orderId", ""))

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        body = {"actionType": "ORDER_MODIFY", "orderId": str(order_id)}
        if price is not None:
            body["openPrice"] = float(price)
        if sl is not None:
            body["stopLoss"] = float(sl)
        if tp is not None:
            body["takeProfit"] = float(tp)
        self._trade(body)

    def cancel_pending(self, order_id):
        self._trade({"actionType": "ORDER_CANCEL", "orderId": str(order_id)})

    @staticmethod
    def _norm_deals(rows):
        out = []
        for r in rows:
            t = str(r.get("type", "")).upper()
            if "BUY" not in t and "SELL" not in t:
                continue                                       # bỏ BALANCE/CREDIT...
            out.append({"id": str(r.get("id")), "time": _ts(r.get("time")), "symbol": r.get("symbol"), "side": _side(t), "qty": _num(r.get("volume")),
                        "price": _num(r.get("price")), "fee": _num(r.get("commission")) + _num(r.get("swap")), "pnl": _num(r.get("profit")),
                        "order_id": str(r.get("orderId", r.get("positionId", ""))), "position_id": str(r.get("positionId", "")),
                        "entry": str(r.get("entryType", "")), "reason": str(r.get("reason", "")).replace("DEAL_REASON_", "").lower()})
        return out

    def deals(self, since):
        d = self._req("GET", "/history-deals/time/%s/%s" % (_iso(since), _iso(time.time() + 3600)), cost=2)
        return self._norm_deals(d if isinstance(d, list) else (d.get("deals") or []))

    @staticmethod
    def _norm_history(rows):
        out = []
        for r in rows:
            t = str(r.get("type", ""))
            kind = classify(t)
            out.append({"id": str(r.get("id")), "time": _ts(r.get("time")), "kind": kind, "symbol": r.get("symbol") or "",
                        "side": _side(t) if kind == "trade" else "", "qty": _num(r.get("volume")), "price": _num(r.get("price")),
                        "entry": str(r.get("entryType", "")).replace("DEAL_ENTRY_", ""), "position_id": str(r.get("positionId", "") or ""),
                        "order_id": str(r.get("orderId", "") or ""), "profit": _num(r.get("profit")), "commission": _num(r.get("commission")),
                        "swap": _num(r.get("swap")), "fee": _num(r.get("fee")), "comment": str(r.get("comment") or "")})
        return out

    def history(self, since, until=None):
        d = self._req("GET", "/history-deals/time/%s/%s" % (_iso(since), _iso(until or time.time() + 3600)), cost=3)
        return self._norm_history(d if isinstance(d, list) else (d.get("deals") or []))

    def deals_by_position(self, position_id):
        """GET /history-deals/position/:positionId (tài liệu MetaApi: mảng MetatraderDeal có positionId, entryType, price, volume, profit, time)."""
        d = self._req("GET", "/history-deals/position/%s" % urllib.parse.quote(str(position_id), safe=""), cost=2)
        return self._norm_deals(d if isinstance(d, list) else (d.get("deals") or []))


# =========================================================================================== Gateway (cổng PyEA tự dựng)
class GatewayBackend(MtBackend):
    """Nói chuyện với gateway/mt_gateway.py (giao thức JSON của chính dự án; xem gateway/README.md)."""
    name = "mt5gw"
    limiter_kind = "mt5gw"

    def __init__(self, url, token="", timeout=20):
        if not str(url or "").strip():
            raise BridgeError("Thiếu địa chỉ cổng MT (vd http://192.168.1.10:8765)")
        self.url = str(url).strip().rstrip("/")
        if not re.match(r"^https?://", self.url):
            self.url = "http://" + self.url
        self.token, self.timeout = str(token or "").strip(), timeout
        self.lim = limiter_for("mt5gw", self.url)

    def _req(self, method, path, params=None, body=None):
        h = {"Authorization": "Bearer " + self.token} if self.token else {}
        try:
            d = http_json(self.url + path, params, headers=h, method=method, timeout=self.timeout, body=body, limiter=self.lim)
        except HttpError as e:
            try:
                msg = json.loads(e.body).get("error") or e.body
            except (ValueError, AttributeError):
                msg = e.body
            hint = " - sai token cổng" if e.status == 401 else ""
            raise BridgeError("Cổng MT HTTP %s: %s%s" % (e.status, str(msg)[:200], hint), e.status)
        except FeedError as e:
            raise BridgeError(str(e))
        if isinstance(d, dict) and d.get("ok") is False:
            raise BridgeError("Cổng MT báo lỗi: %s" % d.get("error", "?"), 200, str(d.get("code", "")))
        return d

    def symbols(self):
        return list(self._req("GET", "/v1/symbols").get("symbols", []))

    def tick(self, symbol):
        d = self._req("GET", "/v1/tick", {"symbol": symbol})
        return _num(d["bid"]), _num(d["ask"]), _num(d.get("time"), time.time())

    def candles(self, symbol, tf, count, end=None):
        p = {"symbol": symbol, "tf": tf, "count": int(count)}
        if end is not None:
            p["end"] = float(end)
        return sorted((Candle(_num(c[0]), _num(c[1]), _num(c[2]), _num(c[3]), _num(c[4]), _num(c[5]) if len(c) > 5 else 0.0)
                       for c in self._req("GET", "/v1/candles", p).get("candles", [])), key=lambda c: c.time)

    def account(self):
        d = self._req("GET", "/v1/account")
        return {"balance": _num(d.get("balance")), "equity": _num(d.get("equity")), "margin": _num(d.get("margin")),
                "free_margin": _num(d.get("free_margin")), "leverage": _num(d.get("leverage"), 1.0), "currency": d.get("currency", ""),
                "hedging": d.get("hedging"), "platform": d.get("platform", ""), "margin_level": _num(d.get("margin_level"), None),
                "credit": _num(d.get("credit"), None), "profit": _num(d.get("profit"), None)}

    def positions(self):
        return list(self._req("GET", "/v1/positions").get("positions", []))

    def orders(self):
        return list(self._req("GET", "/v1/orders").get("orders", []))

    def spec(self, symbol):
        return self._req("GET", "/v1/spec", {"symbol": symbol})

    def market(self, symbol, side, volume, comment=""):
        return self._req("POST", "/v1/market", body={"symbol": symbol, "side": side, "volume": float(volume), "comment": comment})

    def close_position(self, position_id, volume=None):
        return self._req("POST", "/v1/close", body={"position_id": str(position_id), "volume": volume})

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        return str(self._req("POST", "/v1/pending", body={"symbol": symbol, "side": side, "kind": kind, "volume": float(volume), "price": float(price),
                                                          "stop_price": float(stop_price or 0), "expiry": expiry or 0, "comment": comment}).get("order_id", ""))

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        self._req("POST", "/v1/modify", body={"order_id": str(order_id), "price": price, "sl": sl, "tp": tp})

    def cancel_pending(self, order_id):
        self._req("POST", "/v1/cancel", body={"order_id": str(order_id)})

    def deals(self, since):
        return list(self._req("GET", "/v1/deals", {"since": float(since)}).get("deals", []))

    def history(self, since, until=None):
        f = self.features()
        if f and "history" not in f:
            raise BridgeError("Cổng/EA bản cũ chưa hỗ trợ lịch sử đầy đủ từ sàn - cập nhật gateway/mt_gateway.py và EA PyEA_Bridge mới nhất")
        p = {"since": float(since)}
        if until:
            p["until"] = float(until)
        return list(self._req("GET", "/v1/history", p).get("deals", []))

    # ---- SL/TP native theo ticket: chỉ khi cổng/EA khai đủ khả năng (cổng/EA bản cũ -> tắt, vỏ tự canh SL/TP) ----
    _features = None
    NEED_FEATURES = {"sltp", "comment"}       # sửa SL/TP theo ticket + comment trên vị thế (nhận ra vị thế của app)

    def features(self):
        """Khả năng cổng khai ở /v1/ping (`features`). Lỗi mạng -> rỗng và KHÔNG nhớ (lần sau hỏi lại)."""
        if self._features is None:
            try:
                f = set(self._req("GET", "/v1/ping").get("features") or [])
            except BridgeError:
                return set()
            self._features = f
        return self._features

    @property
    def can_modify_position(self):
        return self.NEED_FEATURES <= self.features()

    def modify_position(self, position_id, sl, tp):
        self._req("POST", "/v1/modify_position", body={"position_id": str(position_id), "sl": float(sl or 0.0), "tp": float(tp or 0.0)})

    def deals_by_position(self, position_id):
        if "posdeals" in self.features():
            return list(self._req("GET", "/v1/deals_by_position", {"position_id": str(position_id)}).get("deals", []))
        return MtBackend.deals_by_position(self, position_id)


# =========================================================================================== Profile (REST bất kỳ, khai báo bằng JSON)
def _path_get(obj, path):
    """'a.b.0.c' -> obj['a']['b'][0]['c'] (None nếu thiếu)."""
    cur = obj
    for part in str(path).split("."):
        if part == "":
            continue
        if isinstance(cur, dict):
            cur = cur.get(part)
        elif isinstance(cur, list) and part.lstrip("-").isdigit() and -len(cur) <= int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return None
    return cur


def _fill_template(s, ctx):
    return re.sub(r"\{(\w+)\}", lambda m: urllib.parse.quote(str(ctx.get(m.group(1), "")), safe=""), s) if isinstance(s, str) else s


class ProfileBackend(MtBackend):
    """Dịch vụ REST bất kỳ. Hồ sơ JSON:
    {"name": "mybridge", "base": "https://host", "headers": {"X-Token": "{token}"},
     "ops": {"tick":   {"method":"GET","path":"/price/{symbol}","map":{"bid":"data.bid","ask":"data.ask","time":"data.t"}},
             "account":{"path":"/account","map":{"balance":"balance","equity":"equity"}},
             "positions":{"path":"/positions","list":"items","map":{"id":"ticket","symbol":"symbol","side":"type","volume":"lots","price":"open"}},
             "market": {"method":"POST","path":"/order","body":{"symbol":"{symbol}","type":"{side}","lots":"{volume}"},"map":{"order_id":"ticket","price":"price"}}, ...},
     "side": {"buy":"BUY","sell":"SELL"}}
    Thao tác thiếu trong hồ sơ => báo rõ 'cầu nối này không hỗ trợ ...'."""
    name = "profile"
    limiter_kind = "generic"

    def __init__(self, profile, token="", timeout=20):
        if isinstance(profile, str):
            try:
                profile = json.loads(profile)
            except ValueError as e:
                raise BridgeError("Hồ sơ cầu nối không phải JSON hợp lệ: %s" % e)
        if not isinstance(profile, dict) or not profile.get("base"):
            raise BridgeError("Hồ sơ cầu nối thiếu 'base'")
        self.p, self.token, self.timeout = profile, token, timeout
        self.name = str(profile.get("name") or "profile")
        self.base = str(profile["base"]).rstrip("/")
        self.native_kinds = set(profile.get("native_kinds", []))
        self.lim = limiter_for("generic", self.base)
        self.sidemap = profile.get("side", {"buy": "buy", "sell": "sell"})

    def _call(self, op, **ctx):
        spec = (self.p.get("ops") or {}).get(op)
        if not spec:
            raise BridgeError("Cầu nối '%s' không hỗ trợ thao tác '%s'" % (self.name, op))
        ctx = dict(ctx, token=self.token)
        if "side" in ctx:
            ctx["side"] = self.sidemap.get(ctx["side"], ctx["side"])
        hdrs = {k: _fill_template(v, ctx) for k, v in (self.p.get("headers") or {}).items()}
        path = _fill_template(spec.get("path", ""), ctx)
        body = None
        if spec.get("body") is not None:
            body = {k: self._cast(_fill_template(v, ctx), v, ctx) for k, v in spec["body"].items()}
        params = {k: _fill_template(v, ctx) for k, v in (spec.get("params") or {}).items()} or None
        try:
            d = http_json(self.base + path, params, headers=hdrs, method=spec.get("method", "GET"), timeout=self.timeout, body=body, limiter=self.lim)
        except HttpError as e:
            raise BridgeError("%s HTTP %s: %s" % (self.name, e.status, (e.body or "")[:160]), e.status)
        except FeedError as e:
            raise BridgeError(str(e))
        return d, spec

    @staticmethod
    def _cast(val, tmpl, ctx):
        # "{volume}" nguyên khối -> giữ kiểu số của ctx
        m = re.fullmatch(r"\{(\w+)\}", tmpl) if isinstance(tmpl, str) else None
        return ctx.get(m.group(1)) if m and isinstance(ctx.get(m.group(1)), (int, float)) else val

    @staticmethod
    def _map(item, mp):
        return {k: _path_get(item, v) for k, v in (mp or {}).items()}

    def _rows(self, op, **ctx):
        d, spec = self._call(op, **ctx)
        rows = _path_get(d, spec["list"]) if spec.get("list") else d
        return [self._map(r, spec.get("map")) for r in (rows if isinstance(rows, list) else [])]

    def _one(self, op, **ctx):
        d, spec = self._call(op, **ctx)
        return self._map(d, spec.get("map"))

    def symbols(self):
        d, spec = self._call("symbols")
        rows = _path_get(d, spec["list"]) if spec.get("list") else d
        return sorted(str(r if isinstance(r, str) else _dig(r, ("symbol", "name"), 0)) for r in (rows if isinstance(rows, list) else []))

    def tick(self, symbol):
        m = self._one("tick", symbol=symbol)
        return _num(m.get("bid")), _num(m.get("ask")), _ts(m.get("time"))

    def candles(self, symbol, tf, count, end=None):
        d, spec = self._call("candles", symbol=symbol, tf=tf, count=int(count), end=end or "")
        rows = _path_get(d, spec["list"]) if spec.get("list") else d
        out = []
        for r in rows if isinstance(rows, list) else []:
            m = self._map(r, spec.get("map")) if isinstance(r, dict) else dict(zip(("time", "open", "high", "low", "close", "volume"), r))
            out.append(Candle(_ts(m.get("time")), _num(m.get("open")), _num(m.get("high")), _num(m.get("low")), _num(m.get("close")), _num(m.get("volume"))))
        return sorted(out, key=lambda c: c.time)

    def account(self):
        m = self._one("account")
        return {"balance": _num(m.get("balance")), "equity": _num(m.get("equity")), "margin": _num(m.get("margin")),
                "free_margin": _num(m.get("free_margin")), "leverage": _num(m.get("leverage"), 1.0), "currency": m.get("currency", ""), "hedging": m.get("hedging"),
                "margin_level": _num(m.get("margin_level"), None), "credit": _num(m.get("credit"), None), "profit": _num(m.get("profit"), None)}

    def positions(self):
        return [{"id": str(r.get("id")), "symbol": r.get("symbol"), "side": _side(r.get("side")), "volume": _num(r.get("volume")),
                 "price": _num(r.get("price")), "sl": _num(r.get("sl")), "tp": _num(r.get("tp")), "time": _ts(r.get("time")),
                 "comment": str(r.get("comment") or ""), **_stats(r, profit=("profit",), swap=("swap",), commission=("commission",), price_now=("price_now",))}
                for r in self._rows("positions")]

    def orders(self):
        return [{"id": str(r.get("id")), "symbol": r.get("symbol"), "side": _side(r.get("side")), "kind": str(r.get("kind") or "limit").lower(),
                 "volume": _num(r.get("volume")), "price": _num(r.get("price")), "sl": _num(r.get("sl")), "tp": _num(r.get("tp"))} for r in self._rows("orders")]

    def spec(self, symbol):
        m = self._one("spec", symbol=symbol)
        return {"volume_min": _num(m.get("volume_min")), "volume_max": _num(m.get("volume_max")), "volume_step": _num(m.get("volume_step"))}

    def market(self, symbol, side, volume, comment=""):
        m = self._one("market", symbol=symbol, side=side, volume=float(volume), comment=comment)
        return {"order_id": str(m.get("order_id") or ""), "position_id": str(m.get("position_id") or ""), "price": _num(m.get("price"), None) or None,
                "volume": float(volume)}

    def close_position(self, position_id, volume=None):
        m = self._one("close", position_id=str(position_id), volume=volume if volume else "")
        return {"order_id": str(m.get("order_id") or ""), "position_id": str(position_id), "price": _num(m.get("price"), None) or None, "volume": volume}

    def place_pending(self, symbol, side, kind, volume, price, stop_price, expiry, comment=""):
        m = self._one("pending", symbol=symbol, side=side, kind=kind, volume=float(volume), price=float(price), stop_price=float(stop_price or 0),
                      expiry=expiry or 0, comment=comment)
        return str(m.get("order_id") or "")

    def modify_pending(self, order_id, price=None, sl=None, tp=None):
        self._call("modify", order_id=str(order_id), price=price if price is not None else "", sl=sl if sl is not None else "", tp=tp if tp is not None else "")

    def cancel_pending(self, order_id):
        self._call("cancel", order_id=str(order_id))

    @staticmethod
    def _deal(r):
        return {"id": str(r.get("id")), "time": _ts(r.get("time")), "symbol": r.get("symbol"), "side": _side(r.get("side")), "qty": _num(r.get("qty")),
                "price": _num(r.get("price")), "fee": _num(r.get("fee")), "pnl": _num(r.get("pnl")), "order_id": str(r.get("order_id") or ""),
                "position_id": str(r.get("position_id") or ""), "entry": str(r.get("entry") or ""), "reason": str(r.get("reason") or "").lower()}

    def deals(self, since):
        return [self._deal(r) for r in self._rows("deals", since=float(since))]

    def history(self, since, until=None):
        """Op `history` (tuỳ chọn) với {since}/{until}; map: id,time,type(loại deal gốc),symbol,side,qty,price,entry,position_id,order_id,profit,commission,swap,fee,comment.
        Không có `type` thì coi mọi dòng là deal giao dịch; có `type` thì phân loại (balance/credit/...) theo tên."""
        out = []
        for r in self._rows("history", since=float(since), until=float(until or time.time() + 3600)):
            kind = classify(r.get("type")) if r.get("type") is not None else "trade"
            out.append({"id": str(r.get("id")), "time": _ts(r.get("time")), "kind": kind, "symbol": r.get("symbol") or "",
                        "side": _side(r.get("side") or r.get("type")) if kind == "trade" else "", "qty": _num(r.get("qty")), "price": _num(r.get("price")),
                        "entry": str(r.get("entry") or ""), "position_id": str(r.get("position_id") or ""), "order_id": str(r.get("order_id") or ""),
                        "profit": _num(r.get("profit")), "commission": _num(r.get("commission")), "swap": _num(r.get("swap")), "fee": _num(r.get("fee")),
                        "comment": str(r.get("comment") or "")})
        return out

    # ---- SL/TP native theo ticket (tuỳ chọn): hồ sơ khai op `modify_position` VÀ trường `comment` của positions (để nhận ra vị thế của app) ----
    @property
    def can_modify_position(self):
        ops = self.p.get("ops") or {}
        return "modify_position" in ops and "comment" in ((ops.get("positions") or {}).get("map") or {})

    def modify_position(self, position_id, sl, tp):
        self._call("modify_position", position_id=str(position_id), sl=float(sl or 0.0), tp=float(tp or 0.0))

    def deals_by_position(self, position_id):
        if "deals_by_position" in (self.p.get("ops") or {}):
            return [self._deal(r) for r in self._rows("deals_by_position", position_id=str(position_id))]
        return MtBackend.deals_by_position(self, position_id)


# =========================================================================================== Feed + Broker dùng chung
class MtFeed:
    def __init__(self, backend):
        self.b = backend
        self.name = backend.name
        self.max_chunk = backend.max_chunk
        self._syms, self._syms_t = None, 0.0

    def symbols(self):
        if self._syms is None or time.time() - self._syms_t > 600:
            try:
                self._syms = sorted(self.b.symbols())
            except BridgeError as e:
                raise FeedError(str(e))
            self._syms_t = time.time()
        return list(self._syms)

    def tick(self, symbol):
        try:
            bid, ask, ts = self.b.tick(symbol)
        except BridgeError as e:
            raise FeedError(str(e))
        if bid <= 0 or ask <= 0:
            raise FeedError("Chưa có giá %s" % symbol)
        return Tick(symbol, ts, bid, ask, tradeable=(time.time() - ts) < 300)

    def history(self, symbol, tf, n, end=None):
        try:
            return self.b.candles(symbol, tf, min(int(n), self.max_chunk), end)
        except BridgeError as e:
            raise FeedError(str(e))

    def close(self):
        self.b.close()


class MtBroker(ProtectionAPI):
    supports_short = True
    OP_WAIT = 8.0
    OWN_TAG = "pyea"            # comment của MỌI lệnh app gửi -> nhận ra vị thế của app (không đụng vị thế đặt tay/EA khác)
    CLOSE_BY_REF = True         # vỏ đóng theo ticket đã lưu (Position.ref) thay vì FIFO
    PROT_STYLE = "position"     # SL/TP native gắn lên TỪNG ticket (pyea/protection.py)
    OWNER_BY_TAG = True         # vị thế của app nhận ra bằng comment 'pyea' ghi trên sàn
    PROT_LABEL = {"sl": "SL của vị thế MT", "tp": "TP của vị thế MT"}

    def __init__(self, backend):
        self.b = backend
        self.native_pending = set(backend.native_kinds)
        self.netting = False
        self._spec = {}
        self._watch = set()

    # ---- chuẩn bị ----
    def prepare(self, symbol, leverage=1.0):
        a = self.b.account()
        if a.get("hedging") is not None:
            self.netting = not a["hedging"]
        if str(a.get("platform", "")).upper() == "MT4":
            self.native_pending.discard("stop_limit")                     # MT4 không có lệnh stop-limit: để vỏ tự theo dõi (pending_mode=auto)
            self.CLOSE_BY_REF = False                                     # MT4: đóng MỘT PHẦN tạo ticket MỚI cho phần còn lại -> ticket lưu không bền, đóng/đối soát theo khối lượng
        return a["balance"]

    def balance(self):
        return self.b.account()["balance"]

    def account_state(self):
        return self.b.account()

    def set_watch(self, symbols):
        self._watch = set(symbols or ())

    def _norm_volume(self, symbol, qty):
        sp = self._spec.get(symbol)
        if sp is None:
            try:
                sp = self.b.spec(symbol)
            except BridgeError:
                sp = {}
            self._spec[symbol] = sp
        step, vmin, vmax = _num(sp.get("volume_step")), _num(sp.get("volume_min")), _num(sp.get("volume_max"))
        q = float(qty)
        if step > 0:
            q = int(q / step + 1e-9) * step
            q = round(q, max(0, len(("%.8f" % step).rstrip("0").split(".")[1]) if "." in ("%.8f" % step).rstrip("0") else 0))
        if q <= 0 or (vmin and q < vmin - 1e-12):
            raise BridgeError("Khối lượng %.8g nhỏ hơn mức tối thiểu %.8g của %s" % (qty, vmin, symbol))
        if vmax and q > vmax:
            raise BridgeError("Khối lượng %.8g lớn hơn mức tối đa %.8g của %s" % (q, vmax, symbol))
        return q

    # ---- vị thế ----
    def hedged_positions(self):
        return self.b.positions()

    # ---- số liệu do SÀN báo (giống MT5): lãi/lỗ từng vị thế + lịch sử (pyea/acctstate.py, pyea/brokerhist.py) ----
    def position_stats(self):
        """{ticket: {profit, swap, commission, price}} - chỉ trường sàn có báo."""
        return normalize_position_stats(self.b.positions())

    def account_history(self, since, until=None):
        return self.b.history(since, until)

    def positions(self):
        net = {}
        for p in self.b.positions():
            n = net.setdefault(p["symbol"], {"buy": 0.0, "sell": 0.0, "bp": 0.0, "sp": 0.0})
            n[p["side"]] += p["volume"]
            n["bp" if p["side"] == "buy" else "sp"] += p["volume"] * p["price"]
        out = {}
        for sym, n in net.items():
            q = n["buy"] - n["sell"]
            if abs(q) > 1e-12:
                out[sym] = {"qty": q, "price": (n["bp"] / n["buy"]) if q > 0 else (n["sp"] / n["sell"])}
        return out

    def _price_of_new_position(self, res, symbol, side, qty):
        pid = str(res.get("position_id") or "")
        oid = str(res.get("order_id") or "")
        self.note_own_ref(pid)
        if res.get("price"):
            return Fill(float(res["price"]), float(res.get("volume") or qty), pid, oid)
        end = time.monotonic() + self.OP_WAIT
        while True:                                                      # đợi vị thế xuất hiện để lấy giá khớp thật
            for p in self.b.positions():
                if (pid and p["id"] == pid) or (not pid and p["symbol"] == symbol and p["side"] == side):
                    return Fill(p["price"], p["volume"] if pid else qty, pid, oid)
            if time.monotonic() > end:
                break
            time.sleep(0.25)
        t = self.b.tick(symbol)
        return Fill(t[1] if side == "buy" else t[0], float(qty), pid, oid)

    def market_order(self, symbol, side, qty, reduce_only=False, ref=None):
        if reduce_only:
            return self.close_market(symbol, "sell" if side == "buy" else "buy", qty, ref=ref)
        vol = self._norm_volume(symbol, qty)
        res = self.b.market(symbol, side, vol, self.OWN_TAG)
        return self._price_of_new_position(res, symbol, side, vol)

    def close_market(self, symbol, pos_side, qty, ref=None):
        """Đóng `qty` của `symbol` phía `pos_side`. Có `ref` (ticket do vỏ lưu lúc mở): đóng ĐÚNG vị thế đó - nếu nó không còn trên sàn (vừa bị SL/TP/đóng tay)
        thì BÁO LỖI chứ KHÔNG đóng nhầm vị thế khác. Không có `ref`: đóng theo thứ tự cũ nhất trước (FIFO) như trước đây."""
        todo, total, notional, oids = float(qty), 0.0, 0.0, []
        if ref:
            one = [p for p in self.b.positions() if p["id"] == str(ref)]
            if not one:
                raise BridgeError("Vị thế sàn #%s (%s %s) không còn trên sàn - có thể vừa bị SL/TP hoặc đóng tay; app KHÔNG đóng vị thế khác thay thế" % (ref, pos_side, symbol))
            cands = one
        else:
            cands = sorted((p for p in self.b.positions() if p["symbol"] == symbol and p["side"] == pos_side), key=lambda p: p["time"])
        if not cands:
            raise BridgeError("Không có vị thế %s %s trên sàn để đóng" % (pos_side, symbol))
        for p in cands:
            if todo <= 1e-12:
                break
            take = min(todo, p["volume"])
            full = take >= p["volume"] - 1e-12
            res = self.b.close_position(p["id"], None if full else self._norm_volume(symbol, take))
            px = res.get("price") or self._close_price(res, symbol, pos_side)
            if res.get("order_id"):
                oids.append(str(res["order_id"]))
            total += take
            notional += px * take
            todo -= take
        if total <= 0:
            raise BridgeError("Đóng vị thế không khớp khối lượng nào")
        return Fill(notional / total, total, "", ",".join(oids))

    def _close_price(self, res, symbol, pos_side):
        oid = str(res.get("order_id") or "")
        if oid:
            try:
                for d in self.b.deals(time.time() - 300):
                    if str(d.get("order_id")) == oid and d.get("price"):
                        return float(d["price"])
            except BridgeError:
                pass
        t = self.b.tick(symbol)
        return t[0] if pos_side == "buy" else t[1]

    # ---- lệnh chờ native ----
    def place_pending(self, symbol, side, kind, volume, price, stop_price=None, sl=None, tp=None, expiry=None, client_id=None):
        if kind not in self.native_pending:
            raise BridgeError("Cầu nối %s không hỗ trợ lệnh chờ native '%s'" % (self.b.name, kind))
        vol = self._norm_volume(symbol, volume)
        oid = self.b.place_pending(symbol, side, kind, vol, price, stop_price, expiry, "pyea")
        if not oid:
            raise BridgeError("Cầu nối nhận lệnh chờ nhưng không trả mã lệnh")
        return str(oid)

    def cancel_pending(self, native_id, symbol=None):
        self.b.cancel_pending(native_id)
        return True

    def modify_pending(self, native_id, symbol=None, price=None, sl=None, tp=None):
        self.b.modify_pending(native_id, price, sl, tp)
        return True

    def pending_orders(self, known=None):
        return {o["id"]: dict(o, qty=float(o.get("volume") or 0), type=o.get("kind", "")) for o in self.b.orders()}      # hợp đồng: symbol/side/price/qty

    # ---- SL/TP NATIVE (pyea/protection.py, phong cách "position" - giống MT5: SL/TP là thuộc tính của VỊ THẾ) ----
    # Mỗi vị thế ảo mang `ref` = ticket MT lúc mở; SL/TP đặt LÊN ĐÚNG ticket đó (POSITION_MODIFY) nên không có chuyện gộp/FIFO nhầm. Chỉ đụng vị thế có
    # comment bắt đầu 'pyea' (app mở); vị thế đặt tay/EA khác không bao giờ bị sửa. Backend phải có `can_modify_position`. Tài khoản NETTING (một vị thế/mã gộp
    # mọi vị thế ảo) vẫn dùng được nhưng AN TOÀN: protection.sync_position_levels chỉ gắn mức khi vị thế ảo là TOÀN BỘ ticket (cùng khối lượng và chiều); gộp nhiều
    # vị thế ảo thì không gắn (app tự canh) - đúng với việc SL/TP trên sàn là của cả vị thế gộp.
    PROT = POS_PREFIX

    def prot_supported(self):
        return bool(getattr(self.b, "can_modify_position", False))

    def _owned(self, p):
        return str(p.get("comment") or "").startswith(self.OWN_TAG)

    def position_levels(self, symbol):
        """Hàm nguyên thuỷ #1 của phong cách position: vị thế sàn của mã [{ref, side, qty, sl, tp, owned}]."""
        return [{"ref": p["id"], "side": p["side"], "qty": float(p["volume"]), "sl": float(p.get("sl") or 0.0), "tp": float(p.get("tp") or 0.0),
                 "owned": self._owned(p)} for p in self.b.positions() if p["symbol"] == symbol]

    def set_position_levels(self, ref, sl, tp):
        """Hàm nguyên thuỷ #2: đặt SL/TP của MỘT vị thế (0 = bỏ mức)."""
        self.b.modify_position(ref, sl, tp)

    def _prot_result(self, ticket):
        if any(p["id"] == ticket for p in self.b.positions()):
            return {"state": "canceled"}                                 # vị thế còn nhưng không còn SL/TP của app (bị xoá/sửa tay)
        res = self.position_close(ticket, raising=False)
        if res is None:
            return {"state": "unknown"}                                  # chưa đọc được lịch sử / chưa có deal đóng (đồng bộ chậm): hỏi lại vòng sau
        return res

    def position_close(self, ref, raising=True):
        """Kết quả đóng của MỘT ticket từ deal của chính nó (hợp đồng tuỳ chọn, đối soát dùng để lấy GIÁ RA thật): {state, price, qty, time, deals} hoặc None.
        price/qty = deal đóng CUỐI; `deals` = mọi deal đóng của ticket (kể cả các lần đóng một phần do vỏ gửi) để vỏ tự chọn đúng phần còn lại."""
        try:
            deals = self.b.deals_by_position(str(ref))
        except BrokerError:
            if raising:
                raise
            return None
        return close_from_deals(deals)

    def order_result(self, native_id, symbol=None):
        nid = str(native_id)
        if nid.startswith(self.PROT):
            return self._prot_result(nid[len(self.PROT):])
        if any(o["id"] == nid for o in self.b.orders()):
            return {"state": "open"}
        for p in self.b.positions():                                      # MT5: lệnh chờ khớp -> vị thế có identifier = mã lệnh
            if p["id"] == nid:
                return {"state": "filled", "price": p["price"], "qty": p["volume"], "ref": p["id"]}
        try:
            fills = [d for d in self.b.deals(time.time() - 7 * 86400) if str(d.get("order_id")) == nid]
        except BridgeError:
            fills = []
        if fills:
            q = sum(d["qty"] for d in fills)
            return {"state": "filled", "price": sum(d["price"] * d["qty"] for d in fills) / q, "qty": q}
        return None                                                       # không biết -> engine suy luận từ chênh lệch vị thế

    # ---- lịch sử ----
    def history(self, since=0.0, symbols=None):
        rows = self.b.deals(since or (time.time() - 7 * 86400))
        if symbols:
            rows = [r for r in rows if r.get("symbol") in set(symbols)]
        return sorted(rows, key=lambda r: r["time"])


# =========================================================================================== tạo từ cài đặt
def make_backend(settings):
    kind = settings.get("exchange")
    if kind == "metaapi":
        return MetaApiBackend(settings.get("metaapi_token", ""), settings.get("metaapi_account", ""), settings.get("metaapi_region", "new-york"))
    if kind == "mt5gw":
        return GatewayBackend(settings.get("mt5gw_url", ""), settings.get("mt5gw_token", ""))
    if kind == "bridge":
        return ProfileBackend(settings.get("bridge_profile", ""), settings.get("bridge_token", ""))
    raise BridgeError("exchange '%s' không phải cầu nối" % kind)


_BACKENDS = {}


def _shared(settings):
    key = json.dumps({k: settings.get(k) for k in ("exchange", "metaapi_token", "metaapi_account", "metaapi_region", "mt5gw_url", "mt5gw_token",
                                                  "bridge_profile", "bridge_token")}, sort_keys=True)
    if key not in _BACKENDS:
        _BACKENDS[key] = make_backend(settings)
    return _BACKENDS[key]


def make_bridge_feed(settings):
    return MtFeed(_shared(settings))


def make_bridge_broker(settings):
    return MtBroker(_shared(settings))
