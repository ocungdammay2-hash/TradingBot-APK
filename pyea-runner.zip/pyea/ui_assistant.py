"""Giao diện TRỢ LÝ (mixin của PyEAApp). Lõi ở assistant.py (không Kivy) + assistant_kb.py (sổ tay ngoại tuyến).

Quy ước giao diện: Trợ lý chỉ ĐỀ XUẤT -> mỗi đề xuất là một THẺ nói rõ «đổi gì, từ gì sang gì» với nút «Áp dụng» / «Bỏ qua»; chỉ nút «Áp dụng» (bạn bấm) mới gọi
`assistant.apply(id, confirmed=True)`. Việc có thể chờ mạng (Kiểm tra hệ thống, tạo gói chẩn đoán) chạy ở luồng nền; việc đụng widget chạy ở luồng chính.
`AppEnv` là toàn bộ những gì Trợ lý nhìn/làm được trong app."""
import os
import threading
import time

from kivy.clock import Clock
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.utils import escape_markup

from . import android_native as native
from . import assistant, diagnostics, fieldmap
from .storage import ChatLog
from .ui_widgets import (AMBER, BLUE, DOWN, GREEN, MIN_TOUCH, MUTED, PANEL, PANEL2, TEXT, UP, Panel, mkbtn, vbox, vscroll, wlabel)

QUICK = (("App bị lỗi", "App bị lỗi hoặc thoát đột ngột, tôi cần làm gì?"),
         ("Số liệu hiện «-»", "Tại sao số liệu trên khung Giao dịch hiện dấu «-» hoặc lệch so với MT5?"),
         ("Chạy nền / pin", "Làm sao để app chạy nền không bị Android giết?"),
         ("Kết nối sàn mới", "Hướng dẫn kết nối một sàn mới và kiểm tra nó hoạt động ổn định."))


def text_block(box, text, size=12, color=TEXT, chunk=24):
    """Văn bản dài -> nhiều nhãn (mỗi nhãn một cụm dòng) để không vượt giới hạn texture của Label."""
    lines = str(text).split("\n")
    for i in range(0, len(lines), chunk):
        box.add_widget(wlabel(escape_markup("\n".join(lines[i:i + chunk])), size, color))


def tail_file(path, n=1500):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()[-n:]
    except OSError:
        return ""


class AppEnv(assistant.Env):
    """Cầu nối giữa lõi Trợ lý và app (PyEAApp). Mọi truy cập của Trợ lý vào app đi qua các hàm dưới đây."""

    def __init__(self, app):
        self.app = app

    def settings(self):
        return dict(self.app.settings)

    def save_settings(self, new):
        app = self.app
        errs = fieldmap.parse_overrides(new.get("field_overrides"))[1]
        if errs:
            return errs
        changed = {k: v for k, v in new.items() if app.settings.get(k) != v}
        app.settings = dict(new)                                   # KHÔNG đọc lại cả form: ô bạn đang gõ dở ở tab Cài đặt không bị lưu theo / ghi đè
        form = app.settings_tab.gform
        if form:
            form.update_values(changed)
        return [] if app._commit_settings(False) is not False else ["không lưu được"]

    def agents(self):
        return list(self.app.hub.agents)

    def snapshot(self):
        return self.app.last_snap

    def log_lines(self, n=30):
        try:
            return list(self.app.log_tab.lines)[-n:]
        except Exception:                                          # noqa: BLE001
            return []

    def last_selfcheck(self):
        return getattr(self.app, "_last_diag", "") or ""

    def app_problems(self):
        app = self.app
        out = []
        for label, path in (("crash.log (app)", app.store.crash_path), ("crash.log.old (lần trước)", app.store.crash_path + ".old"),
                            ("service_crash.log (dịch vụ nền)", os.path.join(app.data_dir, "service_crash.log"))):
            t = tail_file(path)
            if t.strip():
                out.append("[%s] %s" % (label, t.strip()))
        n = len([t for t in getattr(app, "_ui_errors", []) if time.time() - t < 600])
        if n:
            out.append("Lỗi giao diện trong 10 phút qua: %d lần" % n)
        try:
            out.append("Dịch vụ nền đang chạy: %s" % ("có" if app.client.host_alive() else "không"))
        except Exception:                                          # noqa: BLE001
            pass
        if native.IS_ANDROID:
            out.append("Đã loại khỏi tối ưu pin: %s" % ("có" if native.is_ignoring_battery_optimizations() else "CHƯA"))
        return "\n".join(out)

    def run_selfcheck(self):
        app = self.app
        res = diagnostics.run_checks(app.data_dir, app.settings, app.store)
        text = diagnostics.format_report(res)
        app._last_diag = text
        return text

    def open_screen(self, name):
        app = self.app
        app.root_panel.switch_to(app.tabs[name])

    def version(self):
        return self.app._app_version()

    def export_diag(self):
        snap = self.app.last_snap or {}
        extra = "status=%s mode=%s exchange=%s halted=%s\nversion=%s" % (snap.get("status"), self.app.settings.get("mode"), self.app.settings.get("exchange"),
                                                                       snap.get("halted"), self.app._app_version())
        return self.app.store.export_diagnostics(extra)

    def battery_opt(self):
        return bool(native.request_ignore_battery_optimizations())

    def audit(self, text):
        try:
            self.app.log_tab.append([(0, time.time(), "INFO", text)])
        except Exception:                                          # noqa: BLE001
            pass


class AssistantUIMixin:
    def assistant(self):
        if getattr(self, "_assistant", None) is None:
            self._assistant = assistant.Assistant(AppEnv(self), log=ChatLog(os.path.join(self.store.base, "assistant.jsonl")))
        return self._assistant

    def open_assistant_dialog(self, *_, question="", data="", autosend=False):
        """Hộp hội thoại Trợ lý. `question`+`data`+`autosend`: mở sẵn với câu hỏi (vd từ hộp «Lần chạy trước ứng dụng bị lỗi») - `data` do CHÍNH bạn bấm gửi."""
        app = self
        a = self.assistant()
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        pop = Popup(title="Trợ lý", content=content, size_hint=(0.97, 0.95), auto_dismiss=False)
        l_mode = wlabel("", 11, MUTED)
        content.add_widget(l_mode)
        state = {"busy": False}

        def refresh_mode():
            ag = assistant.pick_agent(a.env.agents(), app.settings.get("assistant_agent"))
            l_mode.text = ("AI: %s · chỉ ĐỀ XUẤT, bạn bấm «Áp dụng» mới đổi · không bao giờ đặt lệnh" % ag.get("name", "?")) if ag else \
                "Chưa có AI: trả lời từ SỔ TAY có sẵn trong app (vẫn chạy khi mất mạng). Thêm AI: tab AI → Quản lý AI."
        refresh_mode()
        share = mkbtn("", PANEL2, h=36, size=11)

        def paint_share():
            on = bool(app.settings.get("assistant_share_state"))
            share.text = "Cho Trợ lý xem số dư/nhật ký/sự cố: %s (chạm để đổi)" % ("BẬT" if on else "TẮT")
            share.background_color = AMBER if on else PANEL2

        def toggle_share(*_):
            new = dict(app.settings)
            new["assistant_share_state"] = not bool(app.settings.get("assistant_share_state"))
            errs = a.env.save_settings(new)
            if errs:
                self.toast("; ".join(str(e) for e in errs))
            paint_share()
        share.bind(on_release=toggle_share)
        paint_share()
        content.add_widget(share)
        for pair in (QUICK[:2], QUICK[2:]):
            r = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(6))
            for label, q in pair:
                r.add_widget(mkbtn(label, PANEL2, h=36, size=11, on_release=lambda *_, t=q: send(t)))
            content.add_widget(r)
        box = vbox(spacing=dp(6))
        content.add_widget(vscroll(box))

        def say(who, text, color=TEXT):
            box.add_widget(wlabel("[b]%s[/b]" % escape_markup(who), 11, MUTED))
            text_block(box, text, 13, color)
            Clock.schedule_once(lambda dt: setattr(box.parent, "scroll_y", 0) if box.parent is not None else None, 0.05)

        def finish_apply(p, status, row, res):
            status.text, status.color = res.text, (UP if res.ok else DOWN)
            row.clear_widgets()
            if res.ok and a.can_undo(p.id):
                row.add_widget(mkbtn("Hoàn tác", PANEL2, h=36, size=11, on_release=lambda *_: undo(p, status, row)))
            if res.ok and p.kind == "open_screen":
                pop.dismiss()
            if res.ok and res.followup:
                if app.settings.get("assistant_share_state"):
                    send("Đây là kết quả vừa chạy. Hãy giải thích ngắn gọn, chỉ chỗ bất thường và nói bước tiếp theo.", data=res.text)
                else:
                    text_block(box, res.text, 11, MUTED)
                    say("Trợ lý", "Mình không đọc được kết quả này vì «Cho Trợ lý xem số dư/nhật ký/sự cố» đang TẮT. Bật nó (nút phía trên) hoặc dán đoạn cần hỏi vào ô chat.", AMBER)

        def undo(p, status, row):
            res = a.undo(p.id)
            status.text, status.color = res.text, (UP if res.ok else DOWN)
            if res.ok:
                row.clear_widgets()

        def do_apply(p, status, row):
            for b in list(row.children):
                b.disabled = True
            if p.kind in ("run_selfcheck", "export_diag"):
                status.text, status.color = "Đang chạy (vài giây)...", MUTED

                def work():
                    try:
                        res = a.apply(p.id, confirmed=True)
                    except Exception as e:                         # noqa: BLE001
                        res = assistant.Result(False, "Lỗi: %s: %s" % (type(e).__name__, str(e)[:200]))
                    Clock.schedule_once(lambda dt: finish_apply(p, status, row, res), 0)
                threading.Thread(target=work, daemon=True).start()
            else:
                finish_apply(p, status, row, a.apply(p.id, confirmed=True))

        def card(p):
            c = Panel(orientation="vertical", size_hint_y=None, padding=dp(6), spacing=dp(4))
            c.bind(minimum_height=c.setter("height"))
            c.add_widget(wlabel("[b]Đề xuất:[/b] " + escape_markup(p.summary), 12, TEXT if p.valid else MUTED))
            if p.why:
                c.add_widget(wlabel(escape_markup("Lý do: " + p.why), 11, MUTED))
            if p.warning:
                c.add_widget(wlabel(escape_markup("Lưu ý: " + p.warning), 11, AMBER))
            status = wlabel("", 11, MUTED)
            if not p.valid:
                status.text, status.color = "Không áp dụng được: " + p.problem, DOWN
                c.add_widget(status)
                box.add_widget(c)
                return
            c.add_widget(status)
            row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH - 6), spacing=dp(6))
            row.add_widget(mkbtn("Bỏ qua", PANEL2, h=MIN_TOUCH - 6, size=12, on_release=lambda *_: (row.clear_widgets(), setattr(status, "text", "Đã bỏ qua."))))
            row.add_widget(mkbtn("Áp dụng", GREEN, h=MIN_TOUCH - 6, size=12, on_release=lambda *_: do_apply(p, status, row)))
            c.add_widget(row)
            box.add_widget(c)

        def show_reply(rep):
            state["busy"] = False
            send_btn.disabled = False
            refresh_mode()
            if rep.error:
                say("Lưu ý", rep.error, AMBER)
            if rep.text:
                say("Trợ lý" + (" (sổ tay có sẵn, không qua AI)" if rep.source == "local" else (" · " + rep.agent if rep.agent else "")), rep.text)
            for p in rep.proposals:
                card(p)

        def send(text, data=""):
            text = (text or "").strip()
            if not text or state["busy"]:
                return
            state["busy"] = True
            send_btn.disabled = True
            say("Bạn", text, MUTED)
            inp.text = ""
            a.ask_async(text, lambda rep: Clock.schedule_once(lambda dt: show_reply(rep), 0), data=data)

        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        inp = TextInput(text="", hint_text="Hỏi về cách dùng, cài đặt hoặc sự cố...", multiline=False, write_tab=False, font_size=sp(14),
                        background_color=PANEL2, foreground_color=TEXT, cursor_color=TEXT, hint_text_color=MUTED)
        inp.bind(on_text_validate=lambda *_: send(inp.text))
        send_btn = mkbtn("Gửi", GREEN, on_release=lambda *_: send(inp.text), size_hint_x=0.25)
        row.add_widget(inp)
        row.add_widget(send_btn)
        content.add_widget(row)
        bottom = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))

        def clear(*_):
            a.reset()
            box.clear_widgets()
            say("Trợ lý", "Đã xoá hội thoại. Hỏi gì đó, hoặc bấm một gợi ý phía trên.", MUTED)
        bottom.add_widget(mkbtn("Xoá hội thoại", PANEL2, size=12, on_release=clear))
        bottom.add_widget(mkbtn("Đóng", BLUE, size=12, on_release=lambda *_: pop.dismiss()))
        content.add_widget(bottom)
        if a.history:
            for m in a.history[-6:]:
                say("Bạn" if m["role"] == "user" else "Trợ lý", m["content"], MUTED if m["role"] == "user" else TEXT)
        else:
            say("Trợ lý", "Mình hướng dẫn cách dùng app, cài đặt, xử lý khi app gặp sự cố, và ĐỀ XUẤT chỉnh cài đặt an toàn (bạn bấm «Áp dụng» mới đổi). "
                          "Mình KHÔNG đặt/sửa/đóng lệnh. Bấm một gợi ý phía trên hoặc gõ câu hỏi.", TEXT)
        self._assistant_ui = {"pop": pop, "send": send, "input": inp, "box": box}
        pop.open()
        if question:
            if autosend:
                send(question, data=data)
            else:
                inp.text = question
