# MT5 qua EA cầu nối (`exchange = mt5ea`) - TUỲ CHỌN, mặc định TẮT

Dành cho broker KHÔNG có web terminal MT5 (nên dùng `mt5ws` nếu broker có). MT5 bản đầy đủ chạy trong trình giả lập Windows trên điện thoại; EA `PyEABridge` chỉ nối socket về app. **Toàn bộ logic bot ở app.**
Trạng thái: giao thức/máy chủ/backend/giám sát đã test với EA giả và lệnh giả. **EA MQL5 chưa được biên dịch hay chạy trên MT5 thật; MT5 trong Box64/Wine chưa được đo.** Chỉ dùng DEMO.

## Không tự bật
Không có gì mở cổng hay chạy khi bạn không chọn «mt5ea» ở «Nguồn thị trường / sàn». Cổng chỉ nghe trên 127.0.0.1; EA phải gửi đúng token trong 5 giây.

## Cài đặt (trong app)
`mt5ea_token` (>= 8 ký tự) · `mt5ea_port` (18765) · `mt5ea_login`, `mt5ea_server`, `mt5ea_symbol` (chỉ để sinh startup.ini) · `mt5ea_deadman_s` (20) · `mt5ea_policy` (hold|breakeven|close_all) · `mt5ea_deviation` · `mt5ea_filling`.
Nút: «Tạo file cấu hình EA» (ghi PyEABridge.mq5, bridge.set, startup.ini vào thư mục app) và «Kiểm tra EA cầu nối» (mở cổng, đợi EA, đọc tài khoản/giá/vị thế; không đặt lệnh). Dấu «?» cạnh các ô có hướng dẫn.

## Ba lớp chống «app chết»
1. App tự hồi phục (dịch vụ nền sticky, BootReceiver, AlarmManager, đối soát) - có sẵn từ trước.
2. Giám sát phía giả lập `tools/mt5_phone/run_mt5_termux.sh`: tự chạy lại MT5, lùi dần, bỏ cuộc khi chết nhanh liên tiếp, báo bằng termux-notification nếu có.
3. Công tắc người chết trong EA: mất liên lạc quá N giây → hold / breakeven (chỉ vị thế đang lời) / close_all (đóng vị thế + huỷ lệnh chờ), CHỈ với lệnh comment bắt đầu «pyea»; gửi `SendNotification` tới MT5 mobile. EA báo `dead_fired` khi app nối lại để app báo động.

## Báo động cho người dùng
Qua cơ chế cảnh báo sẵn có (`engine.alarm`, tôn trọng Không làm phiền): MẤT cầu nối EA (nghiêm trọng) · EA nối lại · EA im lặng (MT5 đứng/giả lập bị đóng băng) · công tắc người chết đã chạy (kèm chính sách) · token sai · sai phiên bản giao thức · kết nối lạ không HELLO. Mất cầu nối thì mọi yêu cầu báo lỗi rõ «chưa nối» (bot không đặt được lệnh mới); sau khi nối lại, sự kiện kích đối soát sớm.

## Giao thức PyEA-EA v1
Dòng UTF-8 `LOẠI|k=v|k=v\n`, giá trị mã hoá phần trăm cho `% | = CR LF`.
- EA→app: `HELLO(v,token,ea,login,server,company,build,hedging,demo[,dead_fired,dead_policy,dead_at])`, `HB`, `TICK(s,b,a,t)`, `EVT(k=trade)`, `ROW(rid,...)`, `RES(rid,ok[,err,code,...])`.
- app→EA: `WELCOME(v,dead_s,policy,hb_s)` / `DENY(err)`, `PING`, `SUB(s=A,B)`, `CFG(dead_s,policy,hb_s)`, `REQ(rid,op,...)`.
- op: info, account, symbols, tick, spec, candles(s,tf[phút],n[,end]), positions, orders, history(frm,to), notify(text), market(s,side,vol,comment,dev,fill), close(id[,vol,comment]), modify_pos(id,sl,tp), pending(s,side,kind,vol,price[,stop,exp],comment), modify_pending(id[,price,sl,tp,stop,exp]), cancel(id).
- Giờ luôn là UTC (EA đổi bằng `TimeTradeServer()-TimeGMT()`). Stop-limit: app `price`=giá limit, `stop`=giá kích hoạt (EA đổi sang `price`/`stoplimit` của MT5).
- Mất trả lời khi gửi lệnh: app KHÔNG gửi lại, đọc lại vị thế/lệnh theo nhãn `~nonce`; không thấy thì báo «KIỂM TRA trên MT5».

## Việc phải làm trên MT5 (chưa kiểm)
Biên dịch EA (F7) → gắn ĐÚNG MỘT biểu đồ → bật Algo Trading → Tools > Options > Expert Advisors: cho phép 127.0.0.1 (SocketConnect cần địa chỉ trong danh sách cho phép) → nhập cổng/token. Nếu MetaEditor báo lỗi biên dịch, gửi nguyên văn.

## Chưa làm / không chắc
Service (không biểu đồ) chưa thử vì SocketConnect có thể không dùng được trong Service. Sổ lệnh (DOM), lịch sử lệnh huỷ/hết hạn, close-by, kiểm luật trước giao dịch (precheck) CHƯA có cho mt5ea. 127.0.0.1 trong giả lập có trỏ đúng tới app Android hay không phụ thuộc giả lập: chưa kiểm. Định dạng .set và khoá [Experts] trong startup.ini chưa xác nhận.


## Danh mục cảnh báo (mọi cảnh báo theo khuôn: chuyện gì / Tự khắc phục / Bạn cần)
| Cảnh báo | Nghiêm trọng | Tự hồi phục? | Ghi chú |
|---|---|---|---|
| MẤT cầu nối EA / MT5 (ngắt đột ngột, không BYE) | có | EA tự nối lại mỗi 2 giây nếu MT5 còn sống; MT5 chết thì chỉ sống lại nếu chạy script giám sát (đặt `mt5ea_supervised=yes` để lời khuyên nói đúng) | nhắc lại sau 5 phút rồi mỗi 30 phút |
| EA đã dừng: <lý do> (BYE) | có, trừ khi chỉ khởi tạo lại | đổi tham số/biên dịch lại/đổi mã khung/đổi tài khoản/mẫu: EA tự nối lại. Gỡ EA, đóng biểu đồ, đóng MT5, khởi tạo lỗi: KHÔNG | |
| VẪN mất cầu nối (n phút) | có | KHÔNG | cần người mở lại giả lập/MT5 |
| Cầu nối EA đã nối lại | không | đã hồi phục | ghi thời gian mất |
| EA không phản hồi (im lặng) | có | KHÔNG (MT5 treo; công tắc người chết cũng không chạy vì EA đứng) | thoát hẳn MT5 mở lại |
| MT5 MẤT kết nối tới máy chủ broker (HB.conn=0) | có | MT5 tự thử nối lại | bot bị chặn đặt lệnh, báo lỗi rõ |
| MT5 không cho EA giao dịch (HB.ta=0: Algo Trading tắt/investor) | có | KHÔNG | bật Algo Trading, dùng mật khẩu giao dịch |
| Công tắc người chết đã chạy | có | app đã hồi phục; nói rõ EA đã làm gì (số vị thế) | luôn kiểm tra vị thế |
| Token sai / sai phiên bản / kết nối lạ | không / có / không | KHÔNG / KHÔNG / có | |
Giới hạn trung thực: app KHÔNG phân biệt được «Android giết giả lập» với «MT5 sập» (cả hai đều là ngắt đột ngột); script giám sát chạy trong Termux là app khác nên không gửi được trạng thái về app.

## Lỗi lấy ở đâu - KHÔNG cần mở MT5/MetaEditor (Update15)
Nguyên tắc: thông số nhập ở Cài đặt của app; lỗi chảy NGƯỢC về app. Kênh «giám sát» (`SUPHELLO|v=1|token=...`, cùng cổng/token, KHÔNG thay kết nối EA) do `run_mt5_termux.sh` dùng:
| Chuyện | Cách lỗi tới app |
|---|---|
| MT5/giả lập thoát | `SEVT kind=mt5_exit` (mã + lý do: 137=Android giết/hết RAM, 139=sập SIGSEGV, 132=SIGILL...) -> cảnh báo; script tự khởi động lại; bỏ cuộc -> `gave_up` |
| Biên dịch EA | `bash run_mt5_termux.sh compile` chạy `metaeditor64.exe /compile:"..." /log` (cờ theo tài liệu MetaEditor), đọc file `.log` cạnh nguồn + kiểm `.ex5` mới (tài liệu KHÔNG nêu mã thoát) -> `SEVT kind=compile` kèm dòng lỗi |
| Chép EA/.set/startup.ini | `bash run_mt5_termux.sh provision` lấy từ app qua `GET` (base64) ghi vào MT5_DIR; `setup` = provision + compile |
| Log MT5 (Experts `MQL5/Logs`, Journal `logs`, UTF-16) | script đọc mỗi `LOG_POLL` giây, đẩy dòng có từ khoá (pyea, fail, error, invalid, authoriz, not allowed, 4014...) -> `LOGLINE`; app khớp `LOG_RULES`: đăng nhập thất bại, MT5 chặn socket tới 127.0.0.1, không nạp được EA |
| Lỗi lệnh/EA | EA gửi `LOG|lvl|m` (từ chối lệnh = W, lỗi = E -> cảnh báo) |
Tất cả vào nhật ký vòng 600 dòng; nút «Xuất chẩn đoán EA» ghi `mt5_bridge/chan_doan_ea.txt` (token che) để gửi đi. Khi script giám sát vừa báo trong 120 giây app tự coi là «có giám sát» (không phụ thuộc cài đặt) và phân biệt «MT5 chết» với «EA ngắt nhưng MT5 còn chạy».
Chưa kiểm / hạn chế: từ khoá log là TIẾNG ANH theo trí nhớ (MT5 đổi ngôn ngữ log theo giao diện); mã hoá log UTF-16 giả định; đường dẫn MQL5/Profiles/Tester và Presets cho .set chưa xác nhận; dòng log bị cắt giữa chừng hiếm khi bỏ lỡ; script chỉ báo được khi chạy trong Termux cùng máy với app; **MT5 vẫn phải được cho phép 127.0.0.1 một lần nếu startup.ini không đặt được** (đó là việc duy nhất có thể buộc mở MT5).
Cách thủ công cũ (nếu không dùng script): MetaEditor F7 → Toolbox (Ctrl+T) → tab Errors; MT5 Toolbox tab Experts/Journal.
