# Tài liệu lập trình bot PyEA (dành cho người viết bot)

Bản API: `1.8` (xem `pyea/sdk.py`, hằng `API_VERSION`). Bot PyEA là **một file Python** có đúng một lớp kế thừa `BaseBot` — vai trò giống một file EA `.mq5`.
Tài liệu này là quy tắc để ai cũng viết được bot tương tự EA MQL5. Tham số: `docs/BOT_INPUTS.md`. Hỏi AI: `docs/BOT_AI.md`. Ví dụ chạy được: `pyea/examples/*.py.txt`.

> Nói thẳng: các quy tắc dưới đây đã được kiểm bằng test tự động trong PC/stub, **chưa kiểm trên điện thoại thật hay sàn thật**. Luôn chạy thử ở chế độ giả lập (paper) / demo trước.

## 1. Cấu trúc file bot

```python
# @api_min: 1.8                         # (tuỳ chọn) bản API tối thiểu bot cần (1.7 nếu dùng symbol=, 1.8 nếu dùng draw_*/order_book)
# @permission: network(api.example.com) # (tuỳ chọn) xin quyền, xem mục 6
# @mtf: 1h, 1d                          # (tuỳ chọn) các khung KHÁC mà bot sẽ hỏi, để backtest nạp sẵn nến

from pyea import BaseBot, Input, Group, ta     # CHỈ import từ pyea những tên này

class MaCross(BaseBot):
    name = "MA cross"
    inputs = {"lot": Input(0.01, "Khối lượng", min=0.01), "fast": Input(10, "SMA nhanh", min=2)}

    def on_init(self):                  # như OnInit
        self.api.set_timer(30)

    def on_bar(self, candle):           # nến vừa ĐÓNG
        c = self.api.closes(200)
        ...
```

Quy tắc:
- Một file = một lớp bot (kế thừa `BaseBot`). Tham số khai báo bằng `inputs = {...}` (hoặc `Input` làm thuộc tính lớp) — app tự sinh ô nhập, bot đọc bằng `self.lot`, `self.fast`.
- Mọi giao tiếp với app/sàn đi qua **`self.api`**. Không có đường nào khác tới sàn.
- Dòng khai báo `# @...` phải nằm trong **40 dòng đầu** của file.
- Một bot có **một mã + một khung chính** (đặt khi bấm chạy), nhưng từ API 1.7 bot **đọc và giao dịch mã khác** bằng `symbol=` (mục 3b). Có thể chạy thêm bản bot khác và phối hợp qua `self.api.shared`.
- Bot chỉ thấy/sửa được **lệnh và vị thế của chính nó** (gắn `owner`).

## 2. Vòng đời & hàm sự kiện (đối chiếu MQL5)

| PyEA | MQL5 | Khi nào gọi |
|---|---|---|
| `on_init()` | `OnInit` | 1 lần khi chạy; trả `False` = huỷ chạy (INIT_FAILED) |
| `on_tick(tick)` | `OnTick` | mỗi lần có giá mới (mặc định thăm dò giá ~1 giây, không phải từng tick của sàn) |
| `on_bar(candle)` | (kiểm `iTime` trong OnTick) | khi 1 nến **đóng**; `candle` là nến đã đóng |
| `on_trade(update)` | `OnTradeTransaction` | lệnh chờ khớp/huỷ/hết hạn, vị thế mở/đóng/sửa/chạm SL-TP — của bot này |
| `on_timer()` | `OnTimer` (+`EventSetTimer`) | sau `self.api.set_timer(giây)`, kể cả khi không có tick |
| `on_tester()` | `OnTester` | chỉ backtest/tối ưu; trả số = fitness tuỳ chọn |
| `on_deinit(reason)` | `OnDeinit` | `'user' \| 'error' \| 'max_loss' \| 'params' \| 'reload'…` |

Quy tắc chạy:
- Các hàm sự kiện chạy **tuần tự trong một luồng của bot**, không chồng nhau. `on_trade` chạy sau khi `on_tick/on_bar` hiện tại xong.
- Hàm chạy **nhanh** (mục tiêu < vài chục ms). Không `time.sleep` dài, không vòng lặp vô hạn: app đo thời gian từng callback và có watchdog.
- Ném exception trong callback → bot bị **tắt** (mặc định); nếu người dùng đặt `bot_error_tolerance = N`, bot chịu N lỗi/giờ rồi mới tự tắt (circuit breaker).
- Đổi tham số lúc chạy → `on_deinit('params')` rồi `on_init()` với tham số mới (như `REASON_PARAMETERS`). Nạp lại mã nóng → `on_deinit('reload')`, lệnh đang mở giữ nguyên.
- Trạng thái cần sống qua lần khởi động lại: dùng `self.api.store`, **không** chỉ biến `self.x`.

## 3. Tham chiếu `self.api`

**Thông tin:** `symbol`, `timeframe`, `mode`, `tick`, `balance`, `equity`, `version`, `data_dir()`, `account_info()`, `symbol_info(symbol=None)`, `time_info()`.

**Dữ liệu nến:** `candles(count=100, include_current=False, timeframe=None)` → list `Candle(time, open, high, low, close, volume)` cũ→mới; mặc định chỉ nến đã đóng; `closes(...)`. Khung khác: `timeframe="4h"`. Khung hợp lệ: 1m 2m 3m 4m 5m 6m 10m 12m 15m 20m 30m 1h 2h 3h 4h 6h 8h 12h 1d 1w 1mo. **Không sửa** các object trả về.

**Đa mã (API 1.7):** thêm `symbol="ETHUSD"` (không phân biệt hoa/thường) vào `candles`, `closes`, `buy/sell`, `buy_limit/…/sell_stop_limit`, `positions`, `orders`; `tick_of(symbol)` lấy tick mã khác. Mã khác tự được thêm vào danh sách theo dõi giá, `symbol_info(sym)` dùng cho quy tắc khối lượng/stops của mã đó. Vị thế/lệnh vẫn thuộc về bot (`owner`). Backtest: đọc được nến mã khác nếu nạp dữ liệu (`run_backtest(..., extra={"ETHUSD": {"5m": candles}})`), chưa có thì báo lỗi rõ; giao dịch mã khác trong backtest một bot dùng **backtest danh mục nhiều mã** của app.

**Vẽ lên biểu đồ (API 1.8, như ObjectCreate/ObjectMove/ObjectDelete):** `draw_hline(name, price, text, color)`, `draw_trend/draw_rect/draw_fib(name, t1, p1, t2, p2, ...)`, `draw_text(name, time, price, text)`, `draw_delete(name)`, `draw_clear()`. Cùng `name` = di chuyển đối tượng cũ; mặc định tối đa 300 đối tượng/bot (chỉnh trong Cài đặt, tới 5000; trần chỉ để biểu đồ không chậm và bot lỗi vòng lặp không tràn RAM); chỉ để vẽ, không đặt lệnh; không lưu vào nét vẽ tay của người dùng.

**Độ sâu thị trường (API 1.8):** `order_book(depth=20, symbol=None)` → `{"bids": [[giá, KL]...], "asks": [...]}` hoặc `None`; `recent_trades(count=100, symbol=None)` → danh sách giao dịch khớp hoặc `None`. Hiện chỉ Binance có; sàn khác và backtest trả `None` — bot phải kiểm `None`. Mỗi lần gọi là một yêu cầu mạng.

**Giao dịch** (đều trả `OrderResult`; `if res:` đúng khi thành công; `res.retcode`, `res.message`, `res.price`, `res.volume`, `res.position/order`, `res.ticket`):
`buy/sell(volume, sl, tp, comment, reason, details, ai, request_id)`, `buy_limit/sell_limit`, `buy_stop/sell_stop`, `buy_stop_limit/sell_stop_limit`, `oco(*orders)`, `positions(side=None)`, `orders(side=None)`, `cancel_order`, `modify_order`, `close(position, ..., volume=None)` (đóng một phần), `close_all(side=None)`, `modify(position, sl, tp)`.

**Trạng thái / lưu trữ:** `store` (kho JSON riêng của bot, bền; ≤64 KB/giá trị, 256 KB/kho), `shared` (như `GlobalVariable`, dùng chung giữa các bot của tài khoản), `stats()` (thống kê lệnh đã đóng), `set_timer(giây)`.

**Hiển thị / chẩn đoán:** `log(...)`, `status(text)`, `plot(name, value)` (vẽ đường lên biểu đồ), `signal(text, price, side)` (đánh dấu), `trace(text, **values)` + `trace_enabled`.

**Khác:** `calendar(hours, min_impact)` (tin kinh tế), `ai_signal`, `ask_ai(...)` (xem `BOT_AI.md`).

**Chỉ báo:** `from pyea import ta` — sma/ema/smma/lwma/dema/tema, rsi, stdev, bollinger, atr, macd, stochastic, adx, cci, momentum, roc, wpr, mfi, obv, ad, ao, ac, rvi, trix, parabolic SAR, ichimoku, fractals, donchian, envelopes… (bản `*_series` trả cả chuỗi, khớp cách tính của MT5).

**Mã kết quả** `Ret`: OK, PLACED, INVALID_VOLUME, INVALID_PRICE, INVALID_STOPS, INVALID_EXPIRATION, INSUFFICIENT_MARGIN, TRADE_DISABLED, SYMBOL_MODE, MARKET_CLOSED, NO_QUOTES, NOT_SUPPORTED, HEDGE_NOT_ALLOWED, REJECTED, NOT_FOUND, FROZEN, NEWS_BLOCK, ERROR. Mọi sàn quy về bộ mã này.

## 4. Quy tắc viết bot an toàn (nên theo — vỏ có thể ép)

1. **Luôn kiểm kết quả lệnh**: `res = self.api.buy(...)`; `if not res: self.log(res.retcode, res.message)`. Đừng giả định lệnh đã khớp.
2. **Chống gửi trùng**: lệnh quan trọng dùng `request_id="<khoá cố định>"`; retry trong 2 phút trả lại kết quả cũ thay vì gửi lệnh thứ hai. Vỏ **không tự retry** lệnh giao dịch.
3. **Không nhìn trước tương lai**: dùng nến **đã đóng** (mặc định). `include_current=True` chỉ khi hiểu rõ nến đang chạy thay đổi theo tick — backtest sẽ khác live.
4. **Đặt SL/TP đúng phía và ≥ `symbol_info().stops_level`**; khối lượng theo `volume_min/step/max`. Vỏ chuẩn hoá khối lượng nhưng có thể trả `INVALID_*`.
5. **Không tự giữ trạng thái quan trọng chỉ trong RAM** — dùng `store`; khi khởi động lại, đọc `positions()` để đồng bộ.
6. **Không chặn luồng** (sleep/mạng chậm). Gọi mạng phải có timeout ngắn; ưu tiên `ask_ai` (không chặn, trả `pending`).
7. **Không sửa Candle/Tick đã nhận**, không giữ tham chiếu `self.api` ra luồng khác.
8. Đừng dựa vào khoảng giữa các lần `on_tick` (≈1 s, có thể dài hơn khi mất mạng): mọi logic theo thời gian dùng `tick.time`/`time_info()`.

## 5. Những thứ bị chặn khi nạp bot (kiểm tra tĩnh)

- Import: `subprocess`, `ctypes`, `pty`, `_socket`, `_ssl`, `_posixsubprocess`, `multiprocessing`, `pexpect`, `jnius`, `android`.
- Module nội bộ của vỏ: `pyea.keystore`, `pyea.storage`, `pyea.ipc`, `pyea.broker`, `pyea.exness`, `pyea.bridges`, `pyea.ccxt_adapter` (chứa khoá API / gửi lệnh bỏ qua vỏ). Bot chỉ dùng `from pyea import BaseBot, Input, Group, ta` và `pyea.sdk`.
- Lời gọi: `eval`, `exec`, `compile`, `__import__`; `os.system/popen/exec*/spawn*/fork/kill…`.
- Cảnh báo (không chặn): `requests`, `urllib`, `socket`, `websocket(s)`, `aiohttp`, `shutil`, `pathlib` → cần khai báo quyền.
- Bot lỗi cú pháp / vi phạm → **không nạp**; khi nạp lại nóng mà lỗi thì giữ bản cũ chạy tiếp.

Nói thẳng về an ninh: đây là kiểm tra tĩnh để chặn lỗi vô ý và hành vi «tự tiện», **không phải ranh giới an ninh trước mã cố tình phá**. Chỉ chạy bot từ nguồn bạn tin.

## 6. Quyền (manifest)

```
# @permission: network(api.my-model.com, *.example.org)
# @permission: file(read:data/*.csv)      # chỉ khai báo, chưa cưỡng chế
# @permission: ai_signal                  # chỉ khai báo
# @permission: ai_ask                     # chỉ khai báo
```
Người dùng được hỏi «Cho phép / Từ chối» theo **tên file** bot; thêm/đổi host thì hỏi lại. Quyền mạng **chỉ cưỡng chế khi bot chạy ở tiến trình riêng** (Cài đặt → «Bot chạy ở» = process); ở chế độ luồng (mặc định, và Android) chỉ để hiển thị.

## 7. Backtest, tối ưu, đa khung

- Cùng một file chạy cho live và backtest; `self.api.mode` cho biết chế độ. `on_tester()` chỉ gọi trong backtest/tối ưu.
- Đa khung: khai `# @mtf: 1h, 1d` hoặc gọi `candles(timeframe="1h")` với **chuỗi chữ cố định** (app đọc được); khung qua biến vẫn chạy nhưng backtest chỉ phát hiện khi chạy.
- `store`/`shared` trong backtest chỉ nằm trong bộ nhớ, không rò giữa các lần chạy.
- `ask_ai` ở backtest: trả `disabled`/`no_replay` trừ khi dùng bản phát lại đã ghi (xem `BOT_AI.md`).
- Kết quả backtest là **mô phỏng** (nến, spread/phí theo cấu hình), không bảo đảm khớp sàn thật.

## 8. Đối chiếu nhanh MQL5 → PyEA

| MQL5 | PyEA |
|---|---|
| `input double Lot=0.01;` | `Input(0.01, "Lot", min=0)` |
| `OrderSend / CTrade.Buy` | `self.api.buy(vol, sl, tp)` → `OrderResult` |
| `PositionsTotal/PositionGet*` | `self.api.positions()` (chỉ của bot) |
| `OrderGet*`, `OrderDelete` | `orders()`, `cancel_order()` |
| `PositionModify` | `modify(pos, sl, tp)` |
| `PositionClosePartial` | `close(pos, volume=...)` |
| `iMA/iRSI/iATR…` | `ta.sma/rsi/atr…` (+ `*_series`) |
| `iClose(sym, tf, i)` | `self.api.closes(n, timeframe=tf)` |
| `SymbolInfo*` | `symbol_info()` |
| `AccountInfo*` | `account_info()` |
| `GlobalVariable*` | `api.shared` ; `api.store` cho riêng bot |
| `EventSetTimer` | `api.set_timer(s)` |
| `Comment()` | `api.status(text)` |
| `Print()` | `api.log(...)` |
| `OnTester()` | `on_tester()` |
| `OnTradeTransaction` | `on_trade(update)` (`TradeUpdate.kind`) |
| `retcode TRADE_RETCODE_*` | `Ret.*` |
| `WebRequest` | cần `# @permission: network(host)`; thư viện HTTP của Python |

## 9. Giới hạn so với EA MQL5 (nói thẳng)

| Hạng mục | EA MQL5 | Bot PyEA |
|---|---|---|
| Số mã mỗi bot | nhiều mã trong một EA | **có** từ API 1.7 (`symbol=`): đọc nến/giá và đặt lệnh mã khác ngay trong live; backtest một bot chỉ ĐỌC mã khác (cần nạp dữ liệu), giao dịch nhiều mã trong backtest dùng chế độ danh mục |
| Tốc độ tick | từng tick của máy chủ | Binance: giá ĐẨY qua WebSocket (mặc định bật, dự phòng REST); sàn khác: thăm dò, mặc định 1 s, chỉnh tới 0,2 s; **vẫn không phù hợp scalping/HFT** |
| Nến | tick volume, real volume, spread từng nến | `Candle` có OHLC + `volume`: là **tick volume** với MT/Exness (cầu nối MetaApi) và OANDA, là **khối lượng giao dịch** với Binance; không có real volume và spread từng nến; không có volume từng tick |
| Chỉ báo tự viết (`.ex5` iCustom) | có | không nạp được; viết bằng Python/`ta` |
| Đối tượng đồ thị | có | **có** (API 1.8): đường ngang/xu hướng/chữ nhật/Fibonacci/chữ qua `draw_*`; **không** có mũi tên/nhãn giá/nút bấm, và **không có** `OnChartEvent` (chuột/phím trên chart) |
| Sổ lệnh sâu | có (`OnBookEvent`) | **một phần** (API 1.8): `order_book()` lấy theo yêu cầu, chỉ Binance; không có sự kiện đẩy |
| Chiến lược nhiều khung | có | có (`timeframe=`), nhưng nạp nến khung phụ có độ trễ |
| Lệnh chờ / OCO / stop-limit | có (OCO phải tự lập trình) | có; lệnh native trên sàn đồng bộ chậm (`native_sync_s`), OCO có độ trễ lý thuyết |
| Hedging / netting | theo tài khoản | theo sàn; sàn gộp trả `HEDGE_NOT_ALLOWED` |
| Backtest | tick thật, đại lý nhiều lõi, forward | mô phỏng theo nến với nhiều chế độ khớp (open / OHLC / xấu nhất…) + chế độ `real` nếu bạn nạp dữ liệu tick; có tối ưu + walk-forward + danh mục nhiều mã; **chưa kiểm so với sàn** |
| Độ trễ / khớp lệnh | máy chủ MT gần broker | phụ thuộc mạng điện thoại + API sàn; có thể bị Android hạn chế nền |
| Chạy khi tắt máy | cần VPS | cần điện thoại bật; Android có thể dừng app nền |
| Thư viện | MQL5 std | Python stdlib (không `subprocess/ctypes/...`), không cài pip tuỳ ý trong app |
| Sửa lệnh/vị thế của bot khác hoặc lệnh tay | có (theo magic) | **không**: chỉ của chính bot |
| Kiểm thử trên thiết bị thật | trưởng thành | **chưa** — mọi tính năng mới mới chỉ qua test giả lập |

Ưu thế đối lại: bot Python, dùng được thư viện chuẩn, AI (`ask_ai`), ghi log/trace, hot-reload mã, `store/shared` bền, đa sàn qua cùng một API, lệnh chuẩn hoá `Ret`.

## 10. Quy trình khuyến nghị

1. Copy `pyea/examples/template_bot.py.txt`, đặt tên, khai `inputs`.
2. Chạy **Backtest** → kiểm số lệnh, drawdown (đừng tin lợi nhuận tuyệt đối).
3. Chạy **paper/demo** vài ngày, xem nhật ký và `Ret` bị từ chối.
4. Chỉ sau đó mới tài khoản thật với khối lượng nhỏ và `max_loss` bật.
