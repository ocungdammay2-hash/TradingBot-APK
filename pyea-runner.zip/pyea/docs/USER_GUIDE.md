# PyEA Runner - Hướng dẫn người dùng

> App chạy bot giao dịch (EA) + biểu đồ trên điện thoại. **Mặc định là PAPER (giả lập, không tiền thật).** Kết quả backtest/paper không đảm bảo kết quả thật. Đọc «Cảnh báo rủi ro» trong app trước khi dùng tiền thật.

## 1. Bắt đầu trong 5 phút
1. Mở app lần đầu → đọc và đồng ý Điều khoản/Riêng tư → làm theo hướng dẫn 6 bước (xem lại: **Cài đặt → Hướng dẫn · điều khoản · riêng tư · cập nhật**).
2. Muốn thử ngay không cần tài khoản: **Cài đặt → … → Dùng cài đặt mẫu an toàn** (paper + nguồn «simulated»).
3. Tab **Thị trường → KẾT NỐI** → thấy giá các mã.
4. Tab **Bot** → chọn `ma_cross.py` → gắn vào mã + khung → chạy.
5. Chạm chấm ▲▼ trên **Biểu đồ** để xem *lý do* mỗi lệnh.

## 2. Kết nối sàn thật
Cài đặt → «Nguồn thị trường / sàn» → chọn sàn → dán khoá API ở mục «KẾT NỐI SÀN / API».
- Dùng khoá **demo/testnet** trước; khoá chỉ có quyền giao dịch, **không bật quyền rút tiền**.
- Binance Futures: hỗ trợ cả **One-way** và **Hedge mode** (tự nhận). Trong Hedge mode app vẫn chỉ giữ một chiều mỗi mã.
- Lịch sử từ sàn: tab Giao dịch/Lịch sử (OANDA, Binance Spot, Binance Futures, ccxt, MT, Exness). Binance Spot không báo lãi/lỗ nên cột lãi/lỗ = 0 (app không tự bịa).
- Sau khi bật chế độ **live**, kiểm tra bằng Nhật ký → *Kiểm tra hệ thống* với lệnh nhỏ nhất.

## 3. Biểu đồ
- Kéo ngang = lướt · chụm = thu/phóng · chạm nến = xem giá/chỉ báo · chạm 2 lần = về mặc định.
- **＋** = đặt lệnh ngay trên biểu đồ: kéo đường vào/SL/TP, bấm → để gửi.
- **Vẽ** = công cụ vẽ: đường ngang, đường xu hướng, hình chữ nhật, Fibonacci, chữ. Chạm 1-2 điểm; chạm vào hình đã vẽ để xoá; «Danh sách đối tượng» để xoá từng cái/tất cả. Hình lưu theo từng mã. Hình vẽ **không** tự đặt lệnh.
- 33 chỉ báo MT5, 21 khung thời gian.

## 4. Backtest
Tab Backtest: chọn bot, mã, khung, số nến hoặc khoảng ngày → CHẠY. «Tốc độ chạy» ≠ Tối đa = xem từng nến như Visual mode (có Tạm dừng).
- **Báo cáo HTML**: biểu đồ tăng trưởng/sụt vốn + phân tích theo mã/phiên/giờ/thứ; mở bằng trình duyệt, in ra PDF được. Cũng có ở tab Lịch sử (từ sổ app).
- **Debug bot**: đặt «Debug bot» = *Từng dòng* hoặc *Chỉ điểm dừng* (+ «Điểm dừng», vd `42, 57:rsi < 30`), chạy, rồi bấm «Nhật ký debug». Ghi 5 lần gọi đầu của on_bar/on_tick; không đổi kết quả backtest.
- Tối ưu hoá, walk-forward, danh mục, độ nhạy thứ tự giá trong nến: các nút bên dưới.

## 5. An toàn
- «Dừng bot nếu lỗ quá (%)», «Chế độ CHỈ-XEM», SL/TP native (sàn canh khi app tắt, nếu sàn hỗ trợ).
- Cài đặt → **Sao lưu** định kỳ; Gói chẩn đoán đã che khoá API.
- Một số hãng điện thoại giết app nền: tắt tối ưu pin cho app, bật dịch vụ nền.

## 6. Cập nhật & báo lỗi (mặc định TẮT)
- **Kiểm tra cập nhật**: Cài đặt → «Hỗ trợ & cập nhật» → nhập kho GitHub `chủ/tên` (cần Releases có file .apk). App chỉ báo có bản mới; bạn tự cài.
- **Tự gửi báo lỗi**: bật + nhập địa chỉ `https://...` của máy chủ BẠN nhận. Chỉ gửi nhật ký lỗi đã che bí mật. App không có máy chủ của tác giả và không có telemetry.

## 7. Hỏi đáp
- **Không thấy giá?** Kiểm tra mạng/khoá API; Nhật ký → Kiểm tra hệ thống. Binance có thể bị chặn theo vùng (đổi `base_url`).
- **Bot không vào lệnh?** Chạm chấm ghi chú trên biểu đồ/Nhật ký để xem bot nói gì; xem tab Bot (trạng thái), bật Debug khi backtest.
- **App chậm/nóng?** Cài đặt → «Tải thiết bị» xem CPU/RAM và thời gian callback của từng bot (Profiler); giảm số chỉ báo/bot, bật «Tiết kiệm pin».
- **Hỏi Trợ lý** (tab AI/Cài đặt → Trợ lý) trả lời cả khi không có mạng.

## Mới ở 1.9.15
- **Dùng thử 90 ngày** (chỉ bản cài từ Google Play): Cài đặt → «Hướng dẫn · điều khoản · riêng tư · cập nhật» → «Bản quyền». Gửi «ID thiết bị» cho người cấp khoá để kích hoạt sau khi hết hạn. Bản cài ngoài Play không bị giới hạn.
- **Giao diện sáng**: Cài đặt → Giao diện (dark / light / auto), mở lại app.
- **Biểu đồ**: nút «Kiểu» (Renko, Range, gộp N nến), «Sổ lệnh (DOM)» và «Thông số mã» (Binance).
- **Backtest tick thật**: ô «Mô phỏng tick» → «Tick thật (Binance aggTrades)». Futures chỉ có 48 giờ gần nhất.
- **Phiên bản bot**: tab Bot → «Phiên bản bot (hoàn tác / khôi phục)».
