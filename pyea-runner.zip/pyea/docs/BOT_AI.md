# Bot gọi AI: `self.api.ask_ai(...)`

Chuẩn **tổng quát**: vỏ lo phần chung (gửi, kiểm schema, chạy nền, hạn mức, ghi/phát lại); **bot** quyết định hỏi gì, kèm dữ liệu gì, nhận dạng trả lời nào và làm gì. Vỏ không có kịch bản dựng sẵn (giữ/đóng/hoà vốn/tin...).

## Bật (người dùng)
Cài đặt → nhóm **Bot gọi AI**: `Cho bot gọi AI` (mặc định tắt), AI mặc định, hạn mức mỗi giờ/ngày, dùng lại câu trả lời, cỡ ngữ cảnh tối đa, `Cho phép AI tra web`, chỉ dẫn chung, ghi để backtest phát lại. Cần ít nhất một AI đang bật ở tab AI. Dữ liệu bot gửi **rời khỏi máy** tới nhà cung cấp AI và có thể tốn tiền.

## Gọi
```python
a = self.api.ask_ai(
    "Vị thế này nên giữ hay đóng?",                     # câu hỏi tự do
    include=["positions", "candles:1d:30", "calendar:12:high"],   # nguồn ngữ cảnh dựng sẵn
    data={"ghi_chu": "bot lưới, đang lỗ 1.2%"},          # dict bất kỳ bot tự dựng
    schema={"action": ["hold", "close"], "confidence": "0..1", "why?": "str"},
    web=False, agent=None,                               # web=True: cho AI tra web; agent: tên AI
    key="giu_hay_dong", cache_s=900, tag="giu_hay_dong", wait=0)
if a.pending: return                                     # đang hỏi nền - gọi lại cùng key ở tick sau
if a.ok and a.data["action"] == "close" and a.data["confidence"] >= 0.7:
    self.api.close_all(reason="AI tham khảo: " + a.get("why", ""))
```
Không chặn bot: lần đầu trả `pending`; gọi lại cùng `key` để nhận kết quả (`wait=giây` để chờ có giới hạn). Khai `# @permission: ai_ask` đầu file.

`AIAnswer`: `status` (`ok` · `pending` · `error` · `disabled` · `limited` · `no_replay`), `ok`, `pending`, `data`, `text`, `error`, `cached`, `age_s`, `retry_after_s`, `agent`, `model`, `web`; `a.get("khoá", mặc_định)`.
`self.api.ask_ai_info()` → `enabled, used_hour, limit_hour, used_day, limit_day, web_allowed, pending`.

## `include`: nguồn ngữ cảnh
`positions[:buy|sell]`, `orders`, `account`, `symbol`, `tick`, `candles:<khung>:<n>` (tối đa 300 nến, gọn dạng bảng), `calendar:<giờ>:<mức>`, `stats`, `store` (kho riêng của bot), `time`. Nguồn lạ → `status="error"` kèm danh sách nguồn có. Mọi thứ khác bot tự đưa vào `data`. Cỡ tổng vượt «Cỡ ngữ cảnh tối đa» thì bị từ chối kèm lý do (không cắt ngầm).

## `schema` (do bot khai)
Khoá → đặc tả: `["a","b"]` chỉ nhận các giá trị đó · `"number"` `"int"` `"bool"` `"str"` · `"0..1"` (khoảng) · `{"type":"int","min":1,"max":5,"maxlen":80,"choices":[...],"desc":"..."}`. Khoá có `?` là không bắt buộc. Vỏ dặn AI chỉ trả một JSON đúng schema, rồi **kiểm lại**: sai kiểu/ngoài khoảng/thiếu khoá → `status="error"` (giữ `text`), không đoán ý AI. Không khai schema thì đọc `a.text`.

## Tra web (không gắn nhà cung cấp nào)
Cách bật tìm kiếm khác nhau theo nhà cung cấp, nên cấu hình **theo từng AI** (tab AI → sửa AI): `Model tra web` (model riêng có sẵn tìm kiếm) và/hoặc `Tham số thêm khi tra web (JSON)` (gộp vào yêu cầu `/chat/completions`, theo tài liệu nhà cung cấp). Cần thêm `Cho phép AI tra web` ở Cài đặt. Thiếu một trong hai → `status="error"` nói rõ thiếu gì, **không** âm thầm hỏi không-web. Ngoài ra mọi AI có ô `Tham số thêm (JSON)` chung (không riêng tra web).

## Chi phí & an toàn
Mặc định tắt · hạn mức giờ/ngày (hết → `limited` + `retry_after_s`) · dùng lại câu trả lời trong `cache_s` · lỗi mạng nhớ ≤30 s để không gọi dồn · bí mật (key/token) bị che trước khi gửi · lỗi AI không bao giờ làm sập bot (chỉ trả status). AI chỉ **tham khảo**: bot tự đặt ngưỡng, khối lượng, SL.

## Xem lịch sử
Tab AI → nút **Bot hỏi AI**: mọi lần bot gọi `ask_ai` (bot nào, mã, AI/model, tra web, trạng thái, câu hỏi, kết quả, nguyên văn), cùng số lần đã dùng so với hạn mức. Nhật ký `ai_ask_history.jsonl` (500 dòng gần nhất, đã che bí mật).

## Backtest
Không gọi AI. Chạy paper/live trước (câu trả lời được ghi vào `ai_asks.jsonl`, đã che bí mật), rồi backtest cùng giai đoạn với «Phát lại tín hiệu AI đã ghi»: `ask_ai` trả lại câu trả lời thật gần nhất **không muộn hơn** thời điểm đang chạy, khớp theo `tag` (mặc định băm câu hỏi - đặt `tag` ổn định nếu câu hỏi thay đổi theo dữ liệu). Không có bản ghi → `no_replay`; không bật phát lại → `disabled`. Báo cáo ghi rõ số lần hỏi và số lần có câu trả lời. Không sinh lại câu trả lời của AI.

Mẫu tổng quát: bot **AI Advisor (mẫu tổng quát)** — toàn bộ câu hỏi, dữ liệu, schema và ánh xạ hành động là tham số.
