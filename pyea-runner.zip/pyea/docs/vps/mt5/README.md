# Server MT5 headless nhỏ cho PyEA (Wine + EA PyEA_Bridge + mt_gateway)

**Trạng thái: CHƯA CHẠY THẬT.** Viết theo tài liệu (MetaQuotes: tham số dòng lệnh/ini; WineHQ; bài «Compiling MQL4 and MQL5 with Docker» trên mql5.com; TradingView webhooks). Chưa build Docker, chưa chạy Wine/MT5, `PyEA_Bridge.mq5` chưa từng biên dịch. Thử bằng tài khoản **DEMO**.

## Chọn phương án
| | A. Docker Wine + EA (gói này) | B. Windows VPS + `mt5gw` backend `mt5` | C. MetaApi đám mây |
|---|---|---|---|
| Máy chủ | Linux 2 vCPU / 2–4 GB RAM (~5–8 USD/tháng) | Windows 2 vCPU / 4 GB (~12–20 USD) | không (trả phí dịch vụ) |
| Độ ổn định | thấp–vừa (Wine) | **cao nhất** (MT5 chạy native) | cao |
| MT4 | có (EA .mq4) | không | có |
| Công sức | trung bình, cần bước thủ công 1 lần | thấp | thấp nhất |
Khuyến nghị: thử A để rẻ; nếu Wine/MT5 treo thường xuyên hoặc dùng tiền thật → chuyển B (cùng `mt_gateway.py`, app không đổi gì).
Backend `mt5` (gói Python `MetaTrader5`) chỉ chạy trên Windows; trên Linux cần Wine + Python Windows + cầu rpyc — mong manh hơn EA nên gói này dùng backend `ea` (EA gọi RA ngoài, cổng Linux thuần stdlib).

## Kiến trúc
`app Android --(Tailscale/TLS, Bearer token)--> mt_gateway (container, :8765) <--WebRequest 250ms-- EA PyEA_Bridge trong terminal64 (Wine, Xvfb) --> broker`
TradingView → Caddy (443, TLS) → chỉ đường `/v1/webhook/tradingview` → cổng. Mọi đường khác không ra Internet.

## Cài đặt
1. VPS Linux có Docker. Chép dự án lên, `cd docs/vps/mt5 && cp .env.example .env`, điền (login/server **demo**, `GW_TOKEN` dài ≥32 ký tự), đặt `VNC=1`.
2. `docker compose up -d --build` rồi `docker compose logs -f`. Lần đầu: tạo prefix Wine → tải & cài MT5 → biên dịch EA (`/data/compile.log.txt`). Nếu báo lỗi biên dịch **gửi lại nguyên văn** (EA chưa từng biên dịch).
3. **Bước thủ công 1 lần (WebRequest):** tài liệu MetaQuotes không có khoá ini cho danh sách URL cho phép (nơi lưu thực tế nằm trong `Config\common.ini`/`experts.ini`, dạng không sửa tay được). Dùng SSH tunnel `ssh -L 5900:127.0.0.1:5900 user@vps`, mở VNC tới `localhost:5900`: *Tools ▸ Options ▸ Expert Advisors* → tick **Allow WebRequest for listed URL** → thêm `http://127.0.0.1:8765`; bật **Algo Trading**; kiểm EA `PyEA_Bridge` đang gắn trên biểu đồ (nếu chưa: kéo vào, điền GatewayURL/Token). Cấu hình lưu trong volume `mt5data` nên chỉ làm 1 lần. Sau đó đặt `VNC=0`, `docker compose up -d`.
4. Kiểm tra: `curl -H "Authorization: Bearer $GW_TOKEN" http://127.0.0.1:8765/v1/ping` (phải thấy EA kết nối). Trong app: `exchange = mt5gw`, địa chỉ = URL Tailscale `http://<tên-máy>:8765`, token = `GW_TOKEN`. Chạy *Nhật ký → Kiểm tra hệ thống*, đặt lệnh tay nhỏ trên demo, rồi mới gắn bot.
5. Chưa chắc: tệp `MQL5/Presets/pyea_bridge.set` mà `entrypoint.sh` ghi cho `[StartUp] ExpertParameters` — nếu EA khởi động với Token rỗng thì nhập tay ở bước 3.

## Webhook TradingView (tuỳ chọn)
`.env`: `WEBHOOK_SECRET` (≥12 ký tự), `WEBHOOK_IPS=tradingview` (4 IP chính thức), `WEBHOOK_SYMBOLS`, `WEBHOOK_MAX_VOLUME`, **để `WEBHOOK_DRY_RUN=1` ban đầu**. Dùng Caddyfile mẫu + domain; đặt `TRUST_PROXY=1`.
Tin nhắn của alert TradingView:
```
{"secret":"<WEBHOOK_SECRET>","id":"{{strategy.order.id}}-{{timenow}}","action":"{{strategy.order.action}}","symbol":"{{ticker}}","volume":0.01}
```
`action`: buy | sell | close | close_all. TradingView **không ký được HMAC** nên bảo vệ = secret + danh sách IP + chống trùng `id` + giới hạn 30 tín hiệu/phút + mã/khối lượng tối đa. Giới hạn của TradingView: chỉ cổng 80/443, timeout 3 giây (cổng trả lời ngay, đặt lệnh chạy nền), không IPv6, cần bật 2FA. Tên `{{ticker}}` có thể khác tên mã của broker (ví dụ hậu tố `.m`) → chưa có bảng ánh xạ, hãy gõ thẳng mã broker trong `symbol`.

## An ninh
Không mở `:8765` trần ra Internet (compose đã gắn 127.0.0.1). `.env` chứa mật khẩu giao dịch: `chmod 600`, không commit. Khoá riêng bản quyền (`license_private.key`) tuyệt đối không đưa vào repo/ảnh Docker.

## Vận hành
`restart: unless-stopped` + entrypoint thoát khi terminal/cổng chết ⇒ tự khởi động lại. Sao lưu volume `mt5data`. Cập nhật MT5: xoá `terminal64.exe` trong volume để cài lại (hoặc để MT5 tự cập nhật). Theo dõi RAM (Wine+MT5 ~0,7–1,5 GB).
