#!/bin/bash
# Biên dịch PyEA_Bridge.mq5 bằng MetaEditor trong Wine. Trạng thái thoát của MetaEditor là SỐ FILE biên dịch được (không phải pass/fail) -> đọc dòng "Result:" trong log.
MT5_DIR="$1"; SRC=/opt/pyea/gateway/PyEA_Bridge.mq5; DST="$MT5_DIR/MQL5/Experts/PyEA_Bridge.mq5"; LOG=/data/compile.log
mkdir -p "$MT5_DIR/MQL5/Experts"
# MetaEditor đọc file không BOM là ANSI; đường dẫn có khoảng trắng dễ lỗi -> chép sang tên ngắn, thêm BOM UTF-8
{ printf '\xef\xbb\xbf'; cat "$SRC"; } > "$DST"
rm -f "$MT5_DIR/MQL5/Experts/PyEA_Bridge.ex5"
(cd "$MT5_DIR" && timeout 300 wine MetaEditor64.exe /compile:"MQL5\\Experts\\PyEA_Bridge.mq5" /log:"Z:$LOG") >/dev/null 2>&1
iconv -f UTF-16 -t UTF-8 "$LOG" 2>/dev/null | tr -d '\r' > "$LOG.txt"
grep -E "Result:|error" "$LOG.txt" | tail -5
grep -qE "Result: 0 errors" "$LOG.txt" && [ -f "$MT5_DIR/MQL5/Experts/PyEA_Bridge.ex5" ]
