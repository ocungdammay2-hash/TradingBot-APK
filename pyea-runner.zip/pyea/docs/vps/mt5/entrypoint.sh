#!/bin/bash
# Khởi động: Xvfb -> prefix Wine -> cài MT5 (lần đầu, lưu trong volume /data) -> biên dịch EA -> cổng PyEA -> terminal64.
# Thoát (code != 0) khi terminal hoặc cổng chết để Docker `restart: unless-stopped` khởi động lại.
set -u
: "${GW_TOKEN:?Phải đặt GW_TOKEN (chuỗi dài, ngẫu nhiên)}"
MT5_DIR="${MT5_DIR:-$WINEPREFIX/drive_c/Program Files/MetaTrader 5}"
log() { echo "[mt5-gw $(date -u +%H:%M:%S)] $*"; }

Xvfb :99 -screen 0 1280x800x24 -nolisten tcp &
sleep 2
if [ "${VNC:-0}" = "1" ]; then       # CHỈ để làm bước thủ công 1 lần (cho phép WebRequest). Cổng 5900 chỉ nghe localhost trong container.
  x11vnc -display :99 -localhost -forever -shared ${VNC_PASSWORD:+-passwd "$VNC_PASSWORD"} -rfbport 5900 -bg -quiet
fi

if [ ! -d "$WINEPREFIX/drive_c" ]; then
  log "tạo prefix Wine (lần đầu)"; timeout 300 wineboot --init || { log "wineboot lỗi/quá 300s"; exit 1; }
fi
if [ ! -f "$MT5_DIR/terminal64.exe" ]; then
  log "tải & cài MetaTrader 5 (lần đầu)"
  curl -fsSL -o /tmp/mt5setup.exe "${MT5_URL:-https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe}" || { log "không tải được mt5setup.exe"; exit 1; }
  timeout 600 wine /tmp/mt5setup.exe /auto; wineserver -w
  [ -f "$MT5_DIR/terminal64.exe" ] || { log "cài MT5 thất bại (trạng thái thoát của installer không đáng tin - kiểm file)"; exit 1; }
  # Lần chạy đầu tạo thư mục MQL5/Include (cài /auto chưa có) - cần cho biên dịch
  (cd "$MT5_DIR" && wine terminal64.exe /portable &) ; for i in $(seq 1 60); do [ -f "$MT5_DIR/MQL5/Include/Trade/Trade.mqh" ] && break; sleep 5; done
  wineserver -k; sleep 2
fi

/opt/pyea-mt5/compile_ea.sh "$MT5_DIR" || { log "BIÊN DỊCH EA LỖI - xem /data/compile.log (gửi lại nguyên văn lỗi)"; exit 1; }

# Cổng PyEA: nghe 0.0.0.0 trong container; docker-compose chỉ publish ra 127.0.0.1 của máy chủ (truy cập từ xa qua Tailscale/Caddy TLS).
python3 /opt/pyea/gateway/mt_gateway.py --backend ea --host 0.0.0.0 --port 8765 --token "$GW_TOKEN" \
  ${WEBHOOK_SECRET:+--webhook-secret "$WEBHOOK_SECRET" --webhook-ips "${WEBHOOK_IPS:-tradingview}" ${WEBHOOK_SYMBOLS:+--webhook-symbols "$WEBHOOK_SYMBOLS"} ${WEBHOOK_MAX_VOLUME:+--webhook-max-volume "$WEBHOOK_MAX_VOLUME"} ${WEBHOOK_DRY_RUN:+--webhook-dry-run} ${TRUST_PROXY:+--trust-proxy}} &
GW_PID=$!

# Tệp cấu hình khởi động (mật khẩu nằm ở /run, mất khi container dừng). KHÔNG hỗ trợ khoá WebRequest trong ini (tài liệu MetaQuotes không có) -> bước thủ công, xem README.
INI=/run/mt5start.ini
umask 077
cat > "$INI" <<EOT
[Common]
Login=${MT5_LOGIN:?Phải đặt MT5_LOGIN}
Password=${MT5_PASSWORD:?Phải đặt MT5_PASSWORD}
Server=${MT5_SERVER:?Phải đặt MT5_SERVER}
NewsEnable=0
[Experts]
AllowLiveTrading=${ALLOW_LIVE:-1}
AllowDllImport=0
Enabled=1
[StartUp]
Expert=PyEA_Bridge
Symbol=${CHART_SYMBOL:-EURUSD}
Period=M1
ExpertParameters=pyea_bridge.set
EOT
# Tham số EA (GatewayURL/Token) viết thành tệp .set trong MQL5/Profiles/Tester? -> với [StartUp] ExpertParameters, tệp nằm ở MQL5/Presets
mkdir -p "$MT5_DIR/MQL5/Presets"
printf 'GatewayURL=http://127.0.0.1:8765\nToken=%s\n' "$GW_TOKEN" > "$MT5_DIR/MQL5/Presets/pyea_bridge.set"

log "khởi động terminal64"
cd "$MT5_DIR" && wine terminal64.exe /portable /config:"Z:$INI" &
TM_PID=$!
wait -n "$GW_PID" "$TM_PID"; RC=$?
log "một tiến trình đã thoát (mã $RC) -> dừng để Docker khởi động lại"
kill "$GW_PID" "$TM_PID" 2>/dev/null; wineserver -k 2>/dev/null
exit 1
