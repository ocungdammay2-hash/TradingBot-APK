# MT5 trên đám mây MetaApi (TUỲ CHỌN KHÁC - không phải «Kết nối MT5 nhanh»)

> «Kết nối MT5 nhanh» trong app là **MT5 thật chạy trong giả lập trên điện thoại**, tự cài (xem `docs/MT5_QUICK.md`). Tài liệu này chỉ nói về nút phụ MetaApi (dịch vụ đám mây bên thứ ba, có thể tính phí), giữ lại cho ai muốn dùng.

**Mục tiêu**: người dùng chỉ nhập thông tin tài khoản MT5; không PC, không VPS, không emulator, không EA.
**Cách làm**: MT5 chạy sẵn trên đám mây của **MetaApi** (dịch vụ bên thứ ba). App dùng API cấp phát của họ để tạo/bật tài khoản hộ bạn rồi dùng nguồn `metaapi` có sẵn.

## Dùng
1. Một lần: đăng ký ở metaapi.cloud → *Tokens* → tạo token (có gói miễn phí/dùng thử; sau đó tính phí, xem trang giá của họ).
2. App → **Cài đặt** → nút **«MT5 trên đám mây MetaApi»** → nhập **Login**, **Mật khẩu**, **Server**, dán **Token** → **Kết nối**.
3. App tự: tìm tài khoản đã có (không tạo trùng) → tạo mới nếu chưa có (đợi MetaApi tự dò cấu hình broker, có thể 1-2 phút) → bật (deploy) → đợi `CONNECTED` → đặt `exchange=metaapi`, `metaapi_account`, `metaapi_region`, `metaapi_token` trong Cài đặt và lưu.
4. Bấm **Kết nối** ở màn hình chính như mọi nguồn khác. **Thử bằng tài khoản DEMO trước.**

Lần sau chỉ cần nhập lại nếu đổi tài khoản. Token đã dán được nhớ trong Cài đặt (mã hoá bằng khoá thiết bị như các khoá API khác).

## Bảo mật
- Mật khẩu MT5 **không** lưu trong app/cài đặt/sao lưu; ô nhập bị xoá ngay khi xong (có test). Nó được gửi (HTTPS) tới MetaApi, nên **MetaApi giữ mật khẩu của bạn** để đăng nhập hộ. Nếu ngại: dùng mật khẩu **investor** (chỉ xem, không đặt lệnh) hoặc tài khoản demo.
- Token MetaApi cho phép tạo/xoá tài khoản trong tài khoản MetaApi của bạn: giữ bí mật như khoá API.

## Lỗi thường gặp (app dịch sang tiếng Việt)
| Thông báo | Ý nghĩa / cách xử lý |
|---|---|
| Broker từ chối đăng nhập (`E_AUTH`) | Sai login/mật khẩu/server. Thử đăng nhập đúng thông tin đó trong MT5. Phân biệt mật khẩu giao dịch ↔ investor, Real ↔ Demo |
| Không tìm thấy server (`E_SRV_NOT_FOUND`) | Gõ sai tên server; app in các tên gần giống do MetaApi gợi ý |
| Chưa dò được cấu hình broker (`E_SERVER_TIMEZONE`) | Thử lại sau; broker lạ có thể cần «provisioning profile» thủ công trên web MetaApi (app CHƯA làm phần này) |
| Token sai/hết hạn | Tạo token mới |
| «ĐÃ LƯU nhưng CHƯA NỐI» | Tài khoản đã tạo/bật nhưng MT5 chưa nối được broker sau ~4 phút (sai mật khẩu muộn phát hiện, broker đóng cửa…). Cài đặt vẫn lưu; kiểm tra rồi bấm lại (app dùng lại tài khoản đã tạo) |

## Giới hạn — nói thẳng
- **CHƯA chạy với MetaApi thật** (sandbox chặn). Logic dựa trên tài liệu chính thức; test dùng máy chủ giả đúng tài liệu (`tests/fake_prov.py`) và Kivy thật chạy từ đầu đến cuối với máy chủ giả. Chỗ còn đoán: trường `region` có trong phản hồi đọc tài khoản; `magic=0` được nhận; định dạng danh sách tài khoản (mảng; app cũng chấp nhận `{items:[…]}`).
- Phụ thuộc bên thứ ba: giá, giới hạn số tài khoản/mức dùng và việc broker nào được hỗ trợ do MetaApi quyết định; MetaApi sập = app mất dữ liệu MT5 (đường khác: gateway `mt5gw`, EA, `mt5ws`).
- Chưa có: cập nhật mật khẩu của tài khoản đã tồn tại (đổi mật khẩu → sửa trên web MetaApi hoặc xoá rồi tạo lại), xoá tài khoản MetaApi từ app, provisioning profile thủ công.
- Muốn **không** qua bên thứ ba: nguồn «MT5 trực tiếp (Web Terminal)» `mt5ws` (chưa kiểm với sàn thật, chọn broker bằng địa chỉ WebSocket) hoặc gateway/EA (cần PC/VPS) — xem `docs/MT5_GAPS.md`.

## Cho nhà phát hành (muốn người dùng cuối không phải tự đăng ký MetaApi)
Cần một dịch vụ do bạn vận hành giữ token MetaApi của bạn và gọi cùng API cấp phát thay cho từng người dùng (kèm thanh toán/giới hạn). Chưa có trong dự án: nhúng token vào APK là LỘ token. Mô-đun `pyea/mt5quick.py` chỉ cần đổi `prov_url` + token là dùng lại được ở phía dịch vụ đó.
