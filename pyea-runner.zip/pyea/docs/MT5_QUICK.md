# Kết nối MT5 nhanh = MT5 THẬT trong giả lập trên điện thoại, cài tự động

**Yêu cầu**: người dùng chỉ nhập thông tin đăng nhập (login, mật khẩu, server); không phải tự cài Box64/Wine/MT5, tự chép EA, tự biên dịch hay tự gõ cấu hình.
**Cách làm**: chính MetaTrader 5 chạy trong giả lập ngay trên điện thoại (proot + Ubuntu + Box64 + Wine + Xvfb), có EA cầu nối `PyEABridge` nối về app (`docs/MT5_EA_BRIDGE.md`). Một bộ script làm hết các bước và báo tiến trình về app.
Có **hai cách chạy**, cùng một đường cài/giám sát/báo tiến trình:
1. **NHÚNG (ưu tiên) - chạy ngay trong app PyEA, KHÔNG cần cài Termux** (mục ngay dưới).
2. **Termux (dự phòng)** - khi máy/APK không hợp cách 1 (app tự phát hiện và hiện lý do trong hộp thoại). Xem mục «Cách Termux».

> **Nói thẳng**: logic + script + bộ chạy nhúng đã test bằng lệnh giả, proot GIẢ và máy chủ cục bộ thật của app (`tests/test_embedded.py`, `tests/test_mt5emu_embedded.py`, `tests/test_mt5_install.py`, `tests/test_mt5emu.py`, `tests/test_mt5_phone_tools.py`) và Kivy thật dưới xvfb. **CHƯA TỪNG chạy proot/Box64/Wine/MT5 trên điện thoại thật** (sandbox là x86 và chặn một số máy chủ). Hãy thử bằng tài khoản **DEMO** trước. Các URL tải, tên gói, mẫu câu log MT5 là theo tài liệu/trí nhớ, có thể sai ở máy thật; script dừng ở đúng bước lỗi và báo về app để sửa.

## Cách NHÚNG (không Termux)
**Vì sao làm được ở mọi targetSdk**: Android 10+ cấm app nhắm API ≥ 29 chạy (`execve`) file nằm trong thư mục DỮ LIỆU của chính nó (SELinux chỉ cấm `execute_no_trans` trên `app_data_file`; nạp/mmap code vẫn được - [tài liệu Android 10](https://developer.android.com/about/versions/10/behavior-changes-10), [commit sepolicy](https://android.googlesource.com/platform/system/sepolicy/)). Thư mục thư viện gốc của APK thì được phép chạy trực tiếp. Nên `proot` + `loader` được **đóng gói trong APK** (`native_libs/arm64-v8a/lib*.so`, buildozer `android.add_libs_arm64_v8a`; p4a đã bật `extractNativeLibs`/`useLegacyPackaging`), và proot tự chạy chương trình khách bằng loader + mmap, không `execve` file trong thư mục dữ liệu (mã nguồn proot `src/execve/enter.c`). UserLAnd (cũng proot) làm đúng cách này ở targetSdk 37. Nhờ đó APK **nhắm API mới (36)**: **không** bị Google Play Protect chặn kiểu «được xây dựng cho phiên bản Android cũ» (Play Protect cảnh báo/chặn khi targetSdk thấp hơn Android của máy quá 2 mức - [hướng dẫn nhà phát triển](https://developers.google.com/android/play-protect/warning-dev-guidance); bản APK nhắm targetSdk 28 từng bị chặn thật trên máy người dùng). Vẫn **chỉ cài ngoài (sideload), không lên Google Play**, nhưng lý do là chính sách Play cấm app tải mã chạy được (Box64/Wine/Ubuntu) từ ngoài Play, không phải targetSdk. Dung lượng ổ đĩa không quan trọng, ưu tiên tải CPU/RAM thấp.

**Cái gì chạy trong app**: dịch vụ nền riêng `Emu` (`service_emu.py` → `pyea/embedded.py`, foreground + sticky, giữ wake-lock) làm tuần tự:
1. `precheck`: CPU ARM 64-bit, dung lượng trống (≥ ~4 GB, ước lượng chưa đo), kiểm proot trong APK (nếu APK cũ không có proot thì **thử thật** việc chạy một file tải về; Android chặn thì báo rõ lý do, không cài dở).
2. `proot`: dùng proot ARM64 **đã nằm sẵn trong APK** (UserLAnd-Assets-Support v1.4.33; không tải gì, mã băm từng file ghi ở `native_libs/SHA256SUMS`); chọn bản `.a10` (Android 10+) hay bản thường, tự thử bản còn lại nếu bản đầu không chạy. (APK cũ không có proot trong thư viện gốc thì quay lại cách tải về ~9 MB, kiểm SHA256 đã ghim, cần targetSdk 28.)
3. `rootfs`: tải Ubuntu Base 22.04 arm64 (`.tar.gz`) **kiểm theo `SHA256SUMS` cùng thư mục** (tự chọn bản 22.04.x mới nhất), giải nén bằng bộ giải nén an toàn (cấm đường dẫn tuyệt đối/`..`, cấm ghi xuyên symlink, bỏ thiết bị, bỏ setuid), chỉnh cho apt chạy được trong proot (DNS, nguồn `ports.ubuntu.com`, tắt sandbox `_apt`, không tự bật dịch vụ). Thử chạy một lệnh trong Ubuntu; lỗi seccomp/ptrace thì tự thử lại với `PROOT_NO_SECCOMP=1`.
4. `apt → box64 → wine → prefix → mt5 → provision → compile`: **chính các script đã có** (`install_mt5_termux.sh inner`) chạy bên trong proot, báo tiến trình về app qua cổng cục bộ `127.0.0.1` như cách Termux (nên màn hình tiến trình dùng lại).
5. `login`: `run_mt5_termux.sh run` bật Xvfb + MT5, đăng nhập, nối EA; dịch vụ giám sát script này (chết thì dựng lại, lùi dần; chết nhanh nhiều lần thì dừng và báo).

**Dùng**: Cài đặt → **«Kết nối MT5 nhanh»** → nhập Login, Mật khẩu, Server (+ link bộ cài của sàn nếu có) → **Bắt đầu**. Hết. Không Termux, không dán lệnh. Hộp thoại hiện từng bước ✓/▶/✗, **CPU/RAM thật** của giả lập (mỗi ~10 giây), và các nút: **Dừng** (dịu: script tự tắt Wine rồi mới tắt dịch vụ), **Khởi động lại** (làm tiếp từ bước dở, không tải lại phần đã xong), **Sao chép chẩn đoán** (token đã che), **Xoá MT5 nhúng** (bấm 2 lần; xoá cả Ubuntu/Wine/MT5), **Nhập lại thông tin**. Đóng app giữa chừng: dịch vụ vẫn chạy; mở lại thì hộp thoại vào thẳng trang tiến trình.

**Giảm tải CPU/RAM (ưu tiên của người dùng)** - hồ sơ `lean` là mặc định của cách nhúng:
- Box64: để mặc định của Box64 thay vì ép `BOX64_DYNAREC_STRONGMEM=1`/`SAFEFLAGS=2` (hồ sơ `stable` cũ), `BOX64_DYNAREC_BIGBLOCK=3` (khối lớn, hợp chương trình Wine), `BOX64_MAXCPU=2`. Tên biến lấy từ `docs/USAGE.md` của Box64.
- Nhường CPU: tiến trình trong giả lập chạy với `nice` cao hơn (dịch vụ hạ ưu tiên cả cây tiến trình, quét mỗi ~10 s).
- EA ở chế độ nhẹ (`InpLean`): tắt vẽ biểu đồ (`CHART_SHOW=false` + các thuộc tính hiển thị khác), bỏ symbol mặc định khỏi Market Watch sau khi nối được máy chủ (mỗi symbol đang chọn là một luồng tick), quét mỗi 200 ms thay vì 100 ms.
- Tự lùi: nếu MT5 chết nhanh 3 lần liên tiếp ở `lean`, dịch vụ chuyển sang `stable` (ổn định hơn, tốn hơn), nhớ lựa chọn và báo trong app.
- **Chưa đo** mức giảm thật trên máy thật. Số CPU/RAM hiển thị trong app là số đo thật từ `/proc` (CPU: 100% = 1 nhân; RAM: tổng RSS, có thể tính trùng trang dùng chung của Wine) để bạn tự so `lean` với `stable` (đặt `PYEA_PROFILE`).

**Điều kiện/giới hạn**:
- ARM 64-bit (aarch64), Android ≥ 7 (minapi 24). Máy 32-bit không chạy được Box64.
- APK phải có dịch vụ `Emu` và proot trong thư viện gốc (`lib/arm64-v8a/libproot.so`...); CI kiểm cả hai và kiểm targetSdk không bị hạ (`.github/workflows/build-apk.yml`). Bản không đủ điều kiện thì hộp thoại tự dùng cách Termux và ghi lý do. Bản APK nhắm targetSdk thấp (vd 28, đặt `PYEA_TARGET_SDK=28`) sẽ bị Play Protect chặn cài - chỉ để thử.
- **Android 12-14 có thể tự giết tiến trình con của app** (phantom process killer): vào Tuỳ chọn nhà phát triển bật «Disable child process restrictions», và tắt «tối ưu pin» cho PyEA. Nếu dịch vụ bị giết, `state.json` ngừng ghi nhịp và hộp thoại báo «CHƯA thấy dịch vụ nền báo nhịp».
- Mật khẩu **không** đi qua dịch vụ hay ghi file: ô nhập → RAM của app → cổng cục bộ → `startup.ini` (script trong Ubuntu lấy qua GET), như cách Termux; token nằm trong `emu/request.json` (quyền 0600) và file `token` trong Ubuntu, không nằm trên dòng lệnh.

**Đã kiểm / chưa kiểm nguồn tải** (kiểm bằng sandbox có GitHub, ngày 2026-11-16):
| Nguồn | Trạng thái |
|---|---|
| proot UserLAnd `v1.4.33/arm64-v8a-assets.zip` | Tải được, đã băm SHA256 và ghim trong code; có đủ `proot`, `loader`, `loader32`, `libtalloc.so.2` (+ bản `.a10`). Chưa chạy trên Android |
| Ubuntu Base 22.04 arm64 (`cdimage.ubuntu.com`) | **Chưa kiểm được** (sandbox chặn). Hash kiểm lúc chạy theo `SHA256SUMS`; tên tệp tự chọn từ `SHA256SUMS` |
| Box64 `box64-android` (kho `ryanfortner/box64-debs`) | Đã kiểm trong kho GitHub: gói `box64-android` arm64 có trong chỉ mục `Packages`, tệp `box64.list` đúng. Máy chủ `ryanfortner.github.io` (nơi apt tải) chưa kiểm được |
| Wine 9.7 amd64 (Kron4ek/Wine-Builds) | Có thật (HTTP 200, ~56 MB) |
| Bộ cài MT5 `download.mql5.com` | **Chưa kiểm được** (sandbox chặn) |

## Cách Termux (dự phòng)
Dùng khi hộp thoại báo cách nhúng chưa dùng được (APK không có proot trong thư viện gốc/dịch vụ Emu, CPU không phải ARM64...). Phần Android không cho tự động:
1. **Cài Termux** - app riêng, bản **F-Droid hoặc GitHub** (không dùng bản Google Play: đã cũ, kho gói không còn hoạt động). Một app không thể tự cài app khác.
2. **Dán MỘT lệnh vào Termux** (app tạo sẵn và có nút «Sao chép lệnh»). Android không cho app chạy file đã tải trong thư mục của chính nó (W^X), nên việc chạy phải nằm trong Termux. (Nâng cấp sau: Termux có cơ chế RUN_COMMAND để app tự gửi lệnh, nhưng người dùng phải bật `allow-external-apps` một lần và app cần thêm quyền; chưa làm.)

Mọi thứ còn lại (gói, Debian, Box64, Wine, MT5, EA, biên dịch, đăng nhập) là tự động.

### Dùng (cách Termux)
1. App → **Cài đặt** → nút xanh đầu trang **«Kết nối MT5 nhanh»** → nhập **Login**, **Mật khẩu**, **Server** → **Bắt đầu**.
   - Server: tên (vd `Exness-MT5Real8`) hoặc `địa chỉ:cổng` như email của sàn. Sàn có bộ cài MT5 riêng thì dán link vào ô cuối (tuỳ chọn; bỏ trống = bản chung của MetaQuotes).
   - Bấm Bắt đầu = đồng ý đặt «Nguồn thị trường» = `mt5ea` trong Cài đặt. Mật khẩu **không** ghi vào Cài đặt.
2. Cài Termux (nút «Cài Termux (F-Droid)»), bấm **«Sao chép lệnh»**, **«Mở Termux»**, giữ ngón tay trên màn hình → Dán → Enter.
3. Đợi. Hộp thoại trong app hiện từng bước (✓ xong · ▶ đang chạy · ✗ lỗi) và cuối cùng **«ĐÃ NỐI: MT5 đã đăng nhập tài khoản ... và EA đang nối với app»**. Giữ Termux mở, đừng tắt app PyEA lúc cài.
4. Bấm **Kết nối** ở màn hình chính như mọi nguồn khác.

## Chỉ lần đầu hay mỗi lần đều như vậy? (cách Termux; cách nhúng thì «bật lại» = nút Khởi động lại, không cài lại)
| | Làm gì | Mất bao lâu |
|---|---|---|
| **Lần đầu** | Cài Termux (1 lần), dán lệnh, script tải + cài tất cả | Lâu, tốn dung lượng (cần ≥ ~3 GB trống, ước lượng chưa đo; tải Wine + MT5 vài trăm MB đến hơn 1 GB). Chưa đo thời gian thật |
| **Các lần sau** | Không cài lại gì. Bật MT5: `bash ~/pyea-start-mt5.sh` (hoặc dán lại lệnh cũ - các bước đã xong tự bỏ qua) | Chỉ khởi động Xvfb + MT5 + đăng nhập, dự kiến vài chục giây (chưa đo) |
| **Sau khi khởi động lại điện thoại** | Tự bật nếu có **Termux:Boot** (cài + mở 1 lần; script đã tạo sẵn `~/.termux/boot/pyea-mt5.sh`); nếu không, gõ `bash ~/pyea-start-mt5.sh` | |
| **Đổi tài khoản** | Mở lại hộp thoại, «Nhập lại thông tin», dán lại lệnh (hoặc dùng lệnh bật lại sau khi cập nhật) | Nhanh: không cài lại |

Chạy lại lệnh cài bất cứ lúc nào là an toàn: mỗi bước kiểm **trạng thái thật** (có `box64` chạy được không, có `wine64` không, có `terminal64.exe` không, EA đã biên dịch chưa) chứ không chỉ cờ «đã làm», bước nào đủ thì bỏ qua, bước lỗi làm tiếp. Ép làm lại một bước: `PYEA_REDO=wine,mt5 bash ...`.

## Các bước (hiện trong app, theo đúng thứ tự)
`precheck` (CPU 64-bit ARM, dung lượng) → `termux_pkgs` (proot-distro, curl, wget) → `rootfs` (Debian) → `fetch` (lấy script + cấu hình từ app) → `apt` (Xvfb, thư viện X11/font) → `box64` (kho ryanfortner.github.io/box64-debs, gói `box64-android`) → `wine` (Wine 64-bit của Kron4ek, mặc định 9.7) → `prefix` (`wineboot`) → `mt5` (bộ cài MT5 chạy với cờ `/auto`) → `provision` (chép `PyEABridge.mq5`, `bridge.set`, `startup.ini` từ app) → `compile` (MetaEditor `/portable /compile`) → `launcher` (tạo `~/pyea-start-mt5.sh`, boot script) → `login` (bật MT5, đăng nhập, EA nối vào app).

Lỗi ở bước nào thì bước đó hiện ✗ kèm lý do + đuôi nhật ký, app báo động «Cài MT5 trong giả lập: lỗi ở bước ...», và «Xuất chẩn đoán EA» có đủ chi tiết. Sửa nguyên nhân (mạng, dung lượng...) rồi **chạy lại cùng lệnh**.

## Mật khẩu
- Đi đường: ô nhập → RAM của app → cổng cục bộ `127.0.0.1` (có token) → `startup.ini` trong thư mục MT5 trong Debian → MT5. Không qua mạng ngoài, không vào Cài đặt, không vào nhật ký/chẩn đoán (có test).
- `startup.ini` dùng `KeepPrivate=1` (tài liệu MetaTrader: lưu mật khẩu giữa các lần kết nối) nên MT5 tự nhớ tài khoản sau lần đăng nhập đầu.
- Khi EA nối được và báo đã có tài khoản, **app quên mật khẩu** (xoá khỏi RAM) và script cứ vài giây lấy lại `startup.ini` mới từ app → dòng `Password=` **tự biến mất** khỏi máy (đã test, kể cả kiểm đột biến). Mật khẩu chờ quá 2 giờ cũng tự bị quên.
- Hệ quả: nếu app bị tắt trước khi MT5 đăng nhập được, phải nhập lại (hộp thoại hiện lại ô nhập).
- Mật khẩu có xuống dòng bị từ chối (tránh chèn thêm khoá vào file `.ini`).

## Lệnh trong Termux
- `bash ~/pyea-start-mt5.sh` - bật MT5 + giám sát (nền); `status`; `stop`.
- Nhật ký: `~/.pyea/run.out` (giám sát), `~/.pyea/install.log` (cài, phần Termux), trong Debian: `.../root/.pyea/install.log`.

## Điều chưa biết / có thể sai ở máy thật (đừng tin cho tới khi thử)
- Box64 + Wine 9.7 có chạy MT5 ổn trên máy của bạn không (cộng đồng báo kết quả lẫn lộn: có máy thiếu tick, có máy báo «no connection»). Cờ `/auto` của bộ cài MT5, và việc có tắt tiến trình bộ cài đúng lúc không.
- **Danh sách địa chỉ cho phép của MT5** (MT5 chỉ cho EA mở socket tới địa chỉ nằm trong Tools → Options → Expert Advisors): theo tài liệu và các bài trên diễn đàn MQL5, danh sách này KHÔNG có khoá trong file ini (nó nằm trong file nhị phân của MT5), nên script **không** đặt trước được. Cách giải: xem mục «Đường tệp dự phòng» bên dưới. Khoá `[Experts]` của `startup.ini` chỉ còn `Enabled`, `AllowLiveTrading` (có trong tài liệu); `WebRequest`/`WebRequestUrl` đã bỏ vì không có trong tài liệu.
- Server theo tài liệu là `địa chỉ:cổng`; **tên** server có được nhận trong `startup.ini` hay không chưa kiểm. Nếu không đăng nhập được, dùng `địa chỉ:cổng` hoặc bộ cài riêng của sàn.
- Mẫu câu log «authorized on» (để báo «đăng nhập ổn») theo trí nhớ log tiếng Anh; kết luận cuối cùng của app luôn là EA nối được và có số tài khoản, không phải dòng log.
- Android 12+ có thể giết tiến trình con của Termux (phantom process killer): tắt hạn chế trong Tuỳ chọn nhà phát triển, cho Termux không bị tối ưu pin. Đã có `termux-wake-lock`.
- Dung lượng/thời gian ở bảng trên là ước lượng.

## Nếu bước «Cài MT5» báo «could not load kernel32.dll, status c0000135»
Đây là lỗi thật đã gặp trên một điện thoại. Từ bản này script tự: kiểm tiền tố Wine bằng cách chạy thử `cmd.exe`, dựng lại tiền tố nếu hỏng, đổi sang Wine wow64 nếu bộ cài MT5 là 32-bit, dừng ngay khi gặp lỗi và thử lại đúng một lần. Nếu vẫn lỗi, app dừng (không tự lặp) và mục **«Chẩn đoán»** có thêm phần «chẩn đoán Wine»: bản Wine, kích thước trang nhớ, loại bộ cài (x64/x86), có `kernel32.dll` trong tiền tố hay không. Gửi phần đó cho người phát triển. **Chưa xác minh trên máy thật**; nếu «trang_nhớ» khác 4096 thì Box64/Wine có thể không chạy được trên máy đó.

## Đường tệp dự phòng (khi MT5 chặn socket)
MT5 chặn EA mở socket tới 127.0.0.1 nếu địa chỉ chưa nằm trong danh sách cho phép, mà danh sách đó không đặt được bằng ini. Để người dùng vẫn **chỉ nhập đăng nhập**:
1. EA `PyEABridge` (`InpTransport = auto`) thử socket trước. Nếu nối được thì đi thẳng như thiết kế gốc.
2. Nếu MT5 chặn, EA tự ghi các dòng giao thức ra tệp `MQL5/Files/pyea_o_<sid>_<seq>.txt` (EA luôn được phép ghi ở đó) và đọc trả lời ở `pyea_i_<sid>_<seq>.txt`.
3. `pyea_relay.py` (Python, chạy trong Debian, do script giám sát tự bật và dựng lại nếu chết; trình cài tự cài `python3`) là một tiến trình Linux bình thường nên nối được 127.0.0.1 của app; nó chỉ chuyển byte qua lại, không hiểu nội dung.
4. Tệp chia đoạn 256 KB, đọc hết đoạn nào thì xoá đoạn đó; mỗi phiên EA có `sid` riêng, phiên mới nhất thắng; `RELAYCLOSE` báo EA mở phiên mới khi app đóng/không nối được.
5. EA báo `HELLO ... link=file` nên app biết đang đi đường tệp. Nếu cả hai đường đều tịt, EA ghi log `no link to app` và app báo động kèm gợi ý (nhật ký `PYEA-RELAY` trong `~/.pyea/run.out`; hoặc làm tay một lần: thêm `127.0.0.1` vào danh sách của MT5, khi đó EA nối thẳng).
**Nói thẳng:** relay + quy tắc tệp đã test với máy chủ thật của app (`tests/test_mt5_relay.py`, 15 ca, có kiểm đột biến). Phần MQL5 đọc/ghi tệp trong EA **chưa từng biên dịch hay chạy** trên MT5 (không có MetaEditor ở đây): nếu MetaEditor báo lỗi biên dịch, bước «Biên dịch EA cầu nối» sẽ hiện ✗ kèm dòng lỗi để sửa. Độ trễ đường tệp cao hơn socket (vài chục đến ~200 ms mỗi chiều), chưa đo.

## Khác với MetaApi
Nút phụ **«MT5 trên đám mây MetaApi»** (dịch vụ bên thứ ba, có thể tính phí) vẫn còn cho ai muốn, xem `docs/METAAPI_CLOUD.md`. Nó **không** phải «Kết nối MT5 nhanh».

## Cho người phát triển
- Nhúng: `pyea/embedded.py` (tải/kiểm hash/giải nén an toàn/dựng lệnh proot/cài/giám sát/`Sampler` CPU-RAM/`launch`-`stop`-`status`-`supported`), `service_emu.py` (dịch vụ p4a `Emu`), `native_libs/arm64-v8a` (proot + loader trong APK, `SHA256SUMS`), `tools/p4a_hook.py` (chỉ còn tuỳ chọn hạ targetSdk, mặc định KHÔNG), `mt5emu.prepare_embedded/progress_embedded/headline_embedded`, `mt5ea.EMBED_STAGES`, sự kiện `SEVT kind=res|emu_exit|profile`, EA `InpLean`, script `PYEA_PROFILE/PYEA_ENV_OVERRIDE/PYEA_STOP_FILE`. Test: `tests/test_embedded.py` (45 ca, proot giả), `tests/test_mt5emu_embedded.py` (18), `TestProfileAndStop` trong `tests/test_mt5_phone_tools.py`; Kivy thật: `tools/ui_smoke/smoke_embedded.py`.
- Logic: `pyea/mt5emu.py` (`problems/plan/prepare/bootstrap_command/progress/render/headline`), giao diện `pyea/ui_mt5emu.py`; phía máy chủ: `pyea/mt5ea.py` (`INSTALL_STAGES`, `ensure_server`, `make_startup_ini(settings, password)`, `Mt5EaServer.first_login_password/install`, sự kiện `SEVT kind=install`).
- Script: `tools/mt5_phone/install_mt5_termux.sh` (outer = Termux, inner = Debian) + `pyea_relay.py` (relay tệp dự phòng) + `run_mt5_termux.sh` (giám sát; theo dõi đăng nhập và đồng bộ cấu hình bật bằng `PYEA_LOGIN_WATCH/PYEA_SYNC_CFG` trong `~/.pyea_env.sh`). APK đóng gói bản sao `pyea/assets/*.sh.txt` (đuôi `.sh` không được nhận); test kiểm hai bản giống nhau + khối helper chung giống nhau.
- Test: `tests/test_mt5_install.py` (20 ca: bước cài, chạy lại bỏ qua, lỗi → báo app → chạy tiếp, mật khẩu biến mất, lệnh dán), `tests/test_mt5emu.py` (18 ca), `tests/test_mt5_relay.py` (15 ca: đường tệp + relay thật + máy chủ app thật). Kivy thật dưới xvfb: `tools/ui_smoke/smoke_emu.py`.
