# mt5ws so với «vỏ» MT5 — rà soát những gì CÒN THIẾU

Tất cả bên dưới dựa trên giao thức Web Terminal chưa kiểm với sàn thật. Mục «Đã có» chỉ nghĩa là có code + test với máy chủ giả.

## Đã có
Giá đẩy · nến 9 khung gốc + **ghép các khung còn lại (M2/M3/M4/M6/M10/M12/M20, H2/H3/H6/H8/H12)** · tài khoản (số dư, tín dụng, đòn bẩy, tiền tệ, hedging/netting, quyền giao dịch) · vị thế/lệnh chờ kèm **comment, magic, nguồn gốc** · mua/bán thị trường, đóng (một phần), sửa SL/TP theo ticket, lệnh chờ limit/stop (đặt, sửa, huỷ) · lịch sử giao dịch (kèm lý do SL/TP/stop-out nếu sàn dùng bảng DEAL_REASON chuẩn) · không tự gửi lại lệnh, xác minh kết quả bằng đọc lại sàn · nhãn lệnh gọn ≤31 ký tự (mã bot + logic + nonce) · nhận ra lệnh app/tay/EA khác · khôi phục bot cho vị thế khi mất sổ.

## Còn thiếu / hạn chế (nói thẳng) — cập nhật sau update6
Đã xử lý ở update6 (có code + test với máy chủ giả; bố cục dữ liệu lấy từ pymt5, riêng khối «trade» của lệnh 18 khớp ĐÚNG 628 byte; **chưa kiểm với sàn thật**):
- **Ký quỹ**: sàn không báo trong lệnh tài khoản → app ƯỚC TÍNH theo công thức pymt5 (forex/CFD/futures, đổi sang tiền tài khoản bằng tỷ giá đang có). Không ước tính (để trống) khi có lệnh chờ, loại mã chưa hỗ trợ, hoặc không có cặp quy đổi. Chưa tính bù trừ hedge, bậc đòn bẩy, tỷ lệ ký quỹ theo bậc. Ký quỹ còn dư và mức ký quỹ suy ra từ số này.
- **Stop-limit native**: đặt thẳng lên sàn (price = giá limit, trigger = giá stop, theo pymt5). Đặt xong app đọc lại; nếu sàn ghi giá khác thì HUỶ lệnh ngay và tắt native (app tự theo dõi). Chưa hỗ trợ sửa giá stop của stop-limit đã đặt.
- **Chặn sớm theo luật mã**: chế độ giao dịch (cấm/chỉ đóng/chỉ mua/chỉ bán), stops level (SL/TP mới, lệnh chờ), freeze level (sửa/huỷ lệnh chờ) được kiểm TRƯỚC khi gửi, báo rõ lý do, lệnh không đến sàn. Giá trị đọc ra vô lý thì không chặn. Tắt được bằng `mt5ws_precheck=off`.
- **Giờ phiên giao dịch**: đọc lịch phiên của sàn để biết «thị trường đang mở/đóng» (ngày 0 = Chủ nhật theo MT5, chưa xác minh); lịch trống thì quay về suy đoán theo độ tươi của giá.
- **Đặc tả mã**: đã đọc thêm tick value, swap dài/ngắn, ký quỹ ban đầu, tiền tệ cơ sở/lãi/ký quỹ, freeze level.

Vẫn còn thiếu:
1. **Close By** (đóng bằng lệnh đối ứng) và hết hạn kiểu «trong ngày»: chưa làm vì vỏ app không dùng đến (đóng từng vị thế theo ticket vẫn chạy đủ).
2. Kiểm freeze cho SL/TP của vị thế; kiểm giá lệnh chờ so với giá stop của stop-limit chỉ theo stops level.
3. **Không có dữ liệu**: lệnh chờ đã huỷ/hết hạn trong lịch sử, sổ lệnh (DOM), tin tức, lịch kinh tế, thông báo máy chủ.
4. **Không có đẩy sự kiện vị thế/lệnh**: app hỏi lại sàn định kỳ → SL/TP chạm trên sàn được app biết trễ vài giây.
5. **Nguồn gốc lệnh là suy luận**: comment «pyea…» = app; magic ≠ 0 hoặc comment lạ = EA khác; rỗng + magic 0 = tay. Lệnh tay có ghi chú sẽ bị xếp «EA khác». Bảng DEAL_REASON chưa xác minh.
6. **Khung ghép** có thể lệch ở nến đầu/cuối so với nến native của sàn.
7. **Lý do vào/ra lệnh** lấy từ sổ sự kiện của app; lệnh mở tay hoặc trước khi cài app thì ghi «không có ghi chép».
8. **Một tài khoản MT5 mỗi lần chạy**; chưa kiểm tình huống sàn đóng phiên (hết hạn token) ngoài cơ chế kết nối lại.
