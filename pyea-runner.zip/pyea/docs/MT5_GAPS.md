# mt5ws so với «vỏ» MT5 — rà soát những gì CÒN THIẾU

Tất cả bên dưới dựa trên giao thức Web Terminal chưa kiểm với sàn thật. Mục «Đã có» chỉ nghĩa là có code + test với máy chủ giả.

## Đã có
Giá đẩy · nến 9 khung gốc + **ghép các khung còn lại (M2/M3/M4/M6/M10/M12/M20, H2/H3/H6/H8/H12)** · tài khoản (số dư, tín dụng, đòn bẩy, tiền tệ, hedging/netting, quyền giao dịch) · vị thế/lệnh chờ kèm **comment, magic, nguồn gốc** · mua/bán thị trường, đóng (một phần), sửa SL/TP theo ticket, lệnh chờ limit/stop (đặt, sửa, huỷ) · lịch sử giao dịch (kèm lý do SL/TP/stop-out nếu sàn dùng bảng DEAL_REASON chuẩn) · không tự gửi lại lệnh, xác minh kết quả bằng đọc lại sàn · nhãn lệnh gọn ≤31 ký tự (mã bot + logic + nonce) · nhận ra lệnh app/tay/EA khác · khôi phục bot cho vị thế khi mất sổ.

## Còn thiếu / hạn chế (nói thẳng) — cập nhật sau update6
Đã xử lý ở update6 (có code + test với máy chủ giả; bố cục dữ liệu lấy từ pymt5, riêng khối «trade» của lệnh 18 khớp ĐÚNG 628 byte; **chưa kiểm với sàn thật**):
- **Ký quỹ**: sàn không báo trong lệnh tài khoản → app ƯỚC TÍNH theo công thức pymt5 (forex/CFD/futures, đổi sang tiền tài khoản bằng tỷ giá đang có). Không ước tính (để trống) khi có lệnh chờ, loại mã chưa hỗ trợ, hoặc không có cặp quy đổi. Chưa tính bù trừ hedge, bậc đòn bẩy, tỷ lệ ký quỹ theo bậc. Ký quỹ còn dư và mức ký quỹ suy ra từ số này.
- **Stop-limit native**: đặt thẳng lên sàn (price = giá limit, trigger = giá stop, theo pymt5). Đặt xong app đọc lại; nếu sàn ghi giá khác thì HUỶ lệnh ngay và tắt native (app tự theo dõi). Chưa hỗ trợ sửa giá stop của stop-limit đã đặt.
- **Chặn sớm theo luật mã**: chế độ giao dịch (cấm/chỉ đóng/chỉ mua/chỉ bán), stops level (SL/TP mới, lệnh chờ), freeze level (sửa/huỷ lệnh chờ) được kiểm TRƯỚC khi gửi, báo rõ lý do, lệnh không đến sàn. Giá trị đọc ra vô lý thì không chặn. Tắt được bằng `mt5ws_precheck=off`.
- **Giờ phiên giao dịch**: đọc lịch phiên của sàn để biết «thị trường đang mở/đóng» (ngày 0 = Chủ nhật theo MT5, chưa xác minh); lịch trống thì quay về suy đoán theo độ tươi của giá.
- **Đặc tả mã**: đã đọc thêm tick value, swap dài/ngắn, ký quỹ ban đầu, tiền tệ cơ sở/lãi/ký quỹ, freeze level.

Đã xử lý thêm ở update7 (cũng chỉ kiểm với máy chủ giả; bố cục theo pymt5):
- **Close By**: `api.close_by(vị_thế, vị_thế_đối_ứng)` cho bot (chỉ MT5 hedging, cả hai vị thế phải của bot và có ticket sàn). Lãi/lỗ do SÀN tính; sổ app ghi nhận qua đối soát.
- **Sửa giá stop của stop-limit** và **sửa hạn** lệnh chờ native (`modify_pending(..., stop_price=, expiry=)`).
- **Kiểu hết hạn theo mã**: đọc cờ hết hạn cho phép của mã (GTC / trong ngày / thời điểm / thời điểm-trong-ngày) và chọn kiểu hợp lệ; mã chỉ cho «trong ngày» mà hạn chót khác ngày thì báo lỗi rõ, không gửi.
- **Sổ lệnh (DOM)**: `api.order_book()` chạy được với MT5 trực tiếp (đăng ký lệnh 22, nhận lệnh 23); sàn không đẩy độ sâu thì trả None như các nguồn không hỗ trợ. Đơn vị khối lượng của sổ lệnh chưa xác minh.
- **Đối soát sớm khi sàn đẩy sự kiện**: trước đây app chỉ hỏi lại sàn theo chu kỳ đối soát (mặc định 60 giây) nên SL/TP chạm trên sàn có thể được biết trễ tới ~60 giây (mình đã nói «vài giây» là SAI). Giờ sàn đẩy sự kiện lệnh/vị thế (lệnh 10/19) thì app đối soát sau ~3 giây (chờ vỏ ghi sổ xong lệnh của chính mình, và hoãn khi đang gửi lệnh).

Vẫn còn thiếu:
1. ~~Lịch sử lệnh chờ đã huỷ/hết hạn~~ **ĐÃ LÀM ở update8** (mình từng nói «giao thức không có» - SAI: lệnh 5 trả cả giao dịch lẫn lệnh): tab «Lệnh» của lịch sử hiện lệnh khớp, huỷ, hết hạn, bị từ chối (`history_orders`). Bảng trạng thái lệnh chưa xác minh với sàn thật.
2. **Tin tức, lịch kinh tế, thư/thông báo máy chủ**: không có lệnh tương ứng trong giao thức → không làm được trực tiếp trên MT5 (app có nguồn tin riêng).
3. **Ký quỹ ước tính** chưa gồm lệnh chờ, bù trừ hedge, bậc đòn bẩy; mã loại CFD-chỉ số/trái phiếu... để trống.
4. **Nguồn gốc lệnh là suy luận**: comment «pyea…» = app; magic ≠ 0 hoặc comment lạ = EA khác; rỗng + magic 0 = tay. Lệnh tay có ghi chú sẽ bị xếp «EA khác». Bảng DEAL_REASON chưa xác minh.
5. **Khung ghép** có thể lệch ở nến đầu/cuối so với nến native của sàn.
6. **Lý do vào/ra lệnh** lấy từ sổ sự kiện của app; lệnh mở tay hoặc trước khi cài app thì ghi «không có ghi chép».
7. **Một tài khoản MT5 mỗi lần chạy**; chưa kiểm tình huống sàn đóng phiên (hết hạn token) ngoài cơ chế kết nối lại.

## Update9: lệnh giao thức đã làm nốt (chỉ kiểm với máy chủ giả, bố cục theo pymt5 - CHƯA kiểm trên sàn thật)
- Nhóm mã (lệnh 9) `symbol_groups`, spread cấu hình (20) `spreads`, liên kết sàn (44) `corporate_links`, tham số trader (41) `trader_params` (không tự gọi định kỳ vì gọi dồn dập có thể bị sàn ngắt).
- Thông báo tới MT5 mobile (42): `api.notify_mobile(text)` cho bot (trả True/False, không ném lỗi) + nút «Gửi thông báo thử» trong Cài đặt. Giao thức không báo lại thông báo đã tới máy hay chưa.
- Đẩy tài khoản (14) → `account_live()`; đẩy chi tiết mã (17) → `symbol_details(symbol)`. Đẩy tài khoản cũng kích đối soát sớm.
- Đổi mật khẩu (24) `change_password`; đăng xuất (2) `logout`.
- Mở tài khoản DEMO (29 rồi 30) `open_demo_account(...)` + nút «Mở tài khoản DEMO MT5». Chỉ dùng được trên kết nối mới (chưa đăng nhập); broker bắt xác minh email/SMS sẽ từ chối. App chỉ HIỆN thông tin tài khoản mới, không tự lưu.
- Cách thay thế cho thứ giao thức KHÔNG có: lịch sử tick → `tick_history(symbol)` (bộ đệm tick đã nhận, 5000/mã, mất khi tắt app); lịch kinh tế → `calendar_source` (econcal.py, nguồn do người dùng chọn); tin tức/thư máy chủ → không có lệnh nào, không có cách thay thế đáng tin ngoài nguồn tin web.
- Chọn máy chủ broker: bằng ĐỊA CHỈ WebSocket (mt5ws_uri), không có ô tên server trong gói đăng nhập.

## Lệnh của giao thức mà app vẫn CHƯA dùng
- Mở tài khoản THẬT (39), mã xác minh (27/40), bật/tắt OTP (43): cần giấy tờ/xác minh danh tính, làm bừa có rủi ro nên cố ý chưa làm.
- Đường dẫn mã `Forex\Majors\EURUSD` đã đọc nhưng chưa dùng để phân nhóm danh sách mã trên giao diện.
