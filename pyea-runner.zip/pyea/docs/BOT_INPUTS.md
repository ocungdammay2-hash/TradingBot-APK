# Chuẩn tham số bot (PyEA Inputs)

Giống `input` của MQL5: bạn **khai báo** tham số trong code bot, app **tự sinh form** (nút «Tham số») và kiểm giá trị người dùng nhập.
Python không có từ khoá `input` cho việc này, nên PyEA định nghĩa chuẩn riêng gồm `Input(...)` và `Group(...)` (import từ `pyea`).
Bot nào tuân theo chuẩn thì form luôn đúng; bot không theo chuẩn thì nhờ AI chuyển (xem cuối trang).

## Khai báo cơ bản

```python
from pyea import BaseBot, Group, Input

class MyBot(BaseBot):
    g1 = Group("Tín hiệu")                       # tiêu đề nhóm (như `input group` của MQL5)
    fast = Input(10, "SMA nhanh", min=2, max=200)
    g2 = Group("Quản lý vốn")
    lot = Input(0.01, "Khối lượng", min=0.01, step=0.01)
    use_sl = Input(True, "Dùng stop loss")

    def on_init(self):
        if self.fast < 2:
            return False                         # INIT_PARAMETERS_INCORRECT
```
Trong code đọc bằng `self.fast` hoặc `self.p.fast`.

## Bảng kiểu ô nhập

| Khai báo | Ô trên giao diện | MQL5 tương đương |
|---|---|---|
| `Input(10, ...)` | ô số nguyên | `input int` |
| `Input(0.01, ...)` | ô số thực | `input double` |
| `Input(True, ...)` | công tắc | `input bool` |
| `Input("abc", ...)` | ô chữ | `input string` |
| `Input("a", choices=["a","b"])` | ô chọn xổ xuống | `input enum` |
| `Input("long", choices={"long":"Chỉ mua","short":"Chỉ bán"})` | ô chọn có **nhãn hiển thị** | `enum` với chú thích |
| `Input(Side.X, choices=Side)` (`enum.Enum`) | ô chọn từ lớp enum | `enum` |
| `Input("#FF8800", subtype="color")` | ô màu `#RRGGBB` | `input color` |
| `Input("09:30", subtype="time")` | ô giờ `HH:MM` | `input datetime` (giờ) |
| `Input("2026-12-31 23:59", subtype="datetime")` | ô ngày-giờ | `input datetime` |
| `Input("", subtype="text")` | ô văn bản nhiều dòng | `input string` |

Tuỳ chọn: `min=`, `max=`, `step=` (số) · `help="chú thích"` · `secret=True` (che ký tự) · `group="Tên nhóm"` (nếu không dùng `Group(...)`).

## Cách viết gọn (tự nhận dạng)

Nếu bot **không** khai báo `Input`, app vẫn nhận các thuộc tính lớp có giá trị literal làm tham số:

```python
class MyBot(BaseBot):
    # == Tín hiệu ==                 <- dòng này đặt nhóm
    fast: int = 10                   # SMA nhanh {2..200}
    lot: float = 0.01                # Khối lượng {0.01..10 step 0.01}
    mode: str = "a"                  # Chế độ [a|b|c]
    use_sl = True                    # (không chú thích kiểu vẫn được)
```
Chú thích sau `#` là nhãn; `[a|b|c]` là ô chọn; `{min..max}` hoặc `{min..max step s}` là giới hạn. Cách gọn **không** có ô màu/giờ/ngày-giờ/enum có nhãn - dùng `Input(...)` cho các kiểu đó.
Khi đã có `Input(...)` hoặc `inputs = {...}` thì cách gọn bị bỏ qua.

## Đổi tên tham số mà không mất giá trị người dùng đã lưu

```python
param_aliases = {"lot_size": "lot"}
```

## Bot cũ không theo chuẩn?

Ở tab Bot chọn bot rồi bấm **«Nhờ AI chuyển sang chuẩn tham số»**: app soạn sẵn yêu cầu (kèm quy tắc chuẩn và code bot) vào khung chat của tab AI để bạn xem lại và gửi.
AI trả về bản bot đã khai báo `Input`/`Group` - bạn xem so sánh, đồng ý thì ghi đè (bản cũ được lưu trong «Phiên bản bot»).
