# Mã/giao thức bên thứ ba

## pymt5 (cloudQuant) — giấy phép MIT
`pyea/mt5ws.py` là bản **viết lại bằng thư viện chuẩn** của phần giao thức MT5 Web Terminal mà dự án mã nguồn mở **pymt5**
(https://github.com/cloudQuant/pymt5, © cloudQuant, MIT) đã dịch ngược: khung truyền, bố cục byte của tài khoản/vị thế/lệnh/deal/mã/tick/nến/yêu cầu giao dịch,
mã lệnh và khoá AES khởi tạo. Không sao chép nguyên mã; bố cục byte và hằng số được lấy từ pymt5 nên theo yêu cầu giấy phép MIT, ghi nhận tại đây:

> MIT License — Copyright (c) cloudQuant. Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge,
> publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the
> following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

Giao thức này **không chính thức** (MetaQuotes không công bố, có thể đổi bất cứ lúc nào) và việc dùng nó có thể trái điều khoản của broker/MetaQuotes —
người dùng tự chịu trách nhiệm; luôn thử tài khoản demo.
