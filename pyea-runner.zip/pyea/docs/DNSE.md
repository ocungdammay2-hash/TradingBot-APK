# DNSE — chứng khoán / phái sinh Việt Nam (1.9.49)

Chọn **Cài đặt → Nguồn thị trường = dnse**. Dùng API **LightSpeed V1** (tài khoản Entrade X của bạn). **CHƯA thử với tài khoản thật** — mọi thứ mới qua máy chủ giả. Thử bằng lệnh nhỏ, tài khoản ít tiền.

## Cách dùng
1. Nhập `DNSE tên đăng nhập` + `mật khẩu`, `gói vay (loanPackageId)` (bắt buộc khi đặt lệnh).
2. Lấy trading token (8 giờ): Smart OTP → nhập mã vào «DNSE OTP», loại `smart`, bấm **Lấy trading token DNSE**. Email OTP → bấm **Gửi Email OTP DNSE**, nhập mã (hiệu lực 2 phút), loại `email`, bấm **Lấy trading token DNSE**.
3. Chỉ xem giá/backtest thì không cần OTP; đặt/huỷ lệnh mới cần.

## Đã làm
| Thành phần | Chi tiết | Nguồn |
|---|---|---|
| Đăng nhập | `POST api.dnse.com.vn/auth-service/login` → JWT 8 giờ (tự đăng nhập lại) | hdsd.dnse.com.vn «Tài liệu LightSpeed API V1» |
| Tài khoản/số dư | `GET /order-service/accounts`, `/account-balances/{acc}` | như trên |
| Đặt lệnh | `POST /order-service/v2/orders` (cổ phiếu), `/derivative/orders` (VN30F...), header `Trading-Token`; LO, MP (cổ phiếu), MTL (phái sinh) | như trên |
| Sổ lệnh / huỷ | `GET/DELETE /order-service/v2/orders[/{id}]?accountNo=` | như trên |
| Vị thế | `GET /deal-service/deals?accountNo=` (deal OPEN) | như trên |
| Giá realtime | MQTT 5 qua WebSocket `wss://datafeed-lts.dnse.com.vn/wss`, user = investorId, pass = JWT; topic `plaintext/quotes/{stock\|derivative}/{tick\|TP}/{mã}` | mã mẫu + đặc tả MDDS DNSE (bạn gửi), repo chienazazaz/dnse-lightspeed-api |
| MQTT client | `pyea/mqttws.py` (thư viện chuẩn, không paho) | — |
| V2 (API key, HMAC) | `pyea/dnse.py` phần đầu: ký request + client mức thấp, chưa nối bot | README PyPI, thanhdat-phung/dnse_openapi, pskho/dnse-mt5-connector |

## Còn ĐOÁN / chưa xác minh (chỉnh được trong Cài đặt)
1. **Khoá JSON thực tế** của tick/top price: parser không phân biệt hoa/thường, nhận `matchPrice/matchQtty`, `bid/ask[].price`. Nếu sai: không có giá, app báo «Chưa có giá» (không bịa giá).
2. **Đơn vị giá**: feed có thể trả nghìn đồng trong khi lệnh cần đồng (hoặc ngược lại) → chỉnh `DNSE hệ số giá`. Kiểm bằng lệnh nhỏ.
3. **Nến lịch sử**: không có trong tài liệu chính thức; mặc định `services.entrade.com.vn/chart-api/v2/ohlcs/{stock|derivative}` (đường dẫn phổ biến, chưa xác minh) → chỉnh `DNSE đường dẫn nến`. Khung hỗ trợ: 1m 5m 15m 30m 1h 1d. Sai đường dẫn: bot vẫn chạy được từ giá realtime nhưng thiếu lịch sử lúc khởi động.
4. Topic phái sinh `derivative/tick|TP` là suy ra từ topic OHLC phái sinh trong mã mẫu (đăng ký topic không tồn tại thì vô hại).
5. Không có sửa lệnh trong V1 (app huỷ + đặt lại); stop/stop-limit do app mô phỏng; chưa có lịch sử deal đồng bộ.

## Đặc thù thị trường VN
Cổ phiếu cơ sở chỉ mua trước bán sau, lô 100, T+2, bước giá theo sàn; phái sinh VN30F có Long/Short và ký quỹ. Lệnh bán cổ phiếu vừa mua có thể bị từ chối do T+2 (sàn trả lỗi, app báo nguyên văn).
