# Chạy «máy chủ MT5 tối giản» ngay trên điện thoại - nghiên cứu (chưa làm, chưa thử)

Mục tiêu: broker KHÔNG có web terminal MT5 (nghi ngờ: Exness) mà vẫn nối được MT5 từ app, không cần PC/VPS.

## Kết luận ngắn
1. **Không có chế độ «headless» thật của MT5.** Terminal là file .exe Windows đóng nguồn, gắn với giao diện. Trên Linux người ta chạy bằng Wine + màn hình ảo (Xvfb); trên Android phải thêm lớp giả lập x86 (Box64) - nặng, và không tách riêng được «chỉ phần kết nối».
2. **Giả lập đã có người thử (Winlator):** một người báo MT5 cài được, đăng nhập đúng, thấy số dư; nhưng người khác báo không có tick/lịch sử (lỗi timeout 1460) và «no connection» khi đặt lệnh; gợi ý do Box64 dịch gói mạng lỗi, cần Box64 ≥ 0.3.7. Tức chưa ổn định để chạy bot bằng tiền thật. (mql5.com/en/forum/502591)
3. **«Bóc phần kết nối ra»** = tự viết lại giao thức gốc TCP của MT5. Giao thức này độc quyền, mã hoá, không có tài liệu công khai đáng tin; mình không có cách kiểm. Cái gần nhất hiện có chính là giao thức web terminal (mt5ws) - nhưng broker phải bật cổng web.
4. **Hướng khả thi nhất nếu bắt buộc phải dùng MT5 thật: EA cầu nối.** MT5 chạy trong Winlator (hoặc máy khác); một EA nhỏ (.mq5) gọi `SocketConnect` tới máy chủ cục bộ do PyEA mở (cổng 127.0.0.1) và chuyển lệnh/giá qua JSON. MQL5 chỉ làm **client** socket được (tài liệu chỉ có SocketCreate/SocketConnect; địa chỉ phải thêm vào danh sách cho phép ở Tools → Options → Expert Advisors; chạy được trong EA/script, không phải indicator) nên máy chủ phải nằm phía PyEA. Cầu nối `bridge`/`mt5gw` có sẵn trong app là loại này cho PC.
5. Rào cản của mọi hướng chạy MT5 trong app: Android 10+ chặn thực thi file trong thư mục dữ liệu của app (W^X), Android giết tiến trình nền, dung lượng Wine/Box64 hàng trăm MB, giấy phép. APK build từ python-for-android không đóng gói nổi.

## Nên làm gì với broker không có web terminal
- Kiểm tra lại với broker: nhiều broker có web terminal MT5 nhưng ẩn trong trang cá nhân (bài tradersunion nói Exness có web terminal MT5 qua trang cá nhân → Terminal → MT5 → Web Terminal; MÌNH CHƯA XÁC MINH, nguồn phụ). Nếu có, hỏi hỗ trợ «địa chỉ WebSocket của MT5 Web Terminal».
- Dùng nguồn khác sẵn trong app: `exness` (API riêng), `metaapi` (đám mây), `oanda`/`capital`/`binance`.
- Thử MT5 thật trong Winlator như một thí nghiệm THỦ CÔNG, chưa nên dùng tiền thật.

## Nếu muốn làm tiếp (cần bạn đồng ý, vì không kiểm được ở đây)
EA cầu nối + máy chủ cục bộ trong PyEA + backend `mt5ea` cùng giao diện broker. Chỉ kiểm được bằng MT5 thật; mình viết được code và test với EA giả, không bảo đảm chạy được trong Winlator.

---
# Phần 2: công thức «tải nhỏ nhất» để chạy MT5 + EA cầu nối ổn định (nghiên cứu, CHƯA đo trên máy thật)

Nhãn: [NGUỒN] có nguồn đã đọc · [BIẾT] kiến thức chung mình chưa kiểm lại trong phiên này · [THỬ] giả thuyết cần đo.

## A. Tầng giả lập Windows: bỏ tối đa
- Bỏ giao diện Winlator/desktop. Dùng Termux (hoặc proot Debian) + Box64 + Wine 64-bit, KHÔNG cài Box86/Wine 32-bit (MT5 hiện đại là 64-bit) [NGUỒN: ivonblog, termux-box mô tả cách dùng Box64+Wine trong Termux/proot].
- Wine vẫn cần một X server dù chỉ để tạo cửa sổ ẩn (lỗi Wine #57965 «hidden windows cannot be created without an X server») → dùng **Xvfb** (màn hình ảo, không GPU) thay vì Termux-X11 [NGUỒN: winehq bug list]. Không cần DXVK/Vulkan/Mesa: MT5 vẽ biểu đồ bằng CPU, chạy EA không cần đồ hoạ [THỬ].
- Prefix Wine riêng, 64-bit: `WINEARCH=win64`, tắt tải Mono/Gecko và menu builder: `WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=d"`, `WINEDEBUG=-all` (bớt ghi log) [BIẾT].
- Box64: ưu tiên ỔN ĐỊNH hơn tốc độ vì báo cáo lỗi «không có tick/no connection» nghi do dịch gói mạng: dùng Box64 ≥ 0.3.7 [NGUỒN: mql5 forum 502591], thử `BOX64_DYNAREC_STRONGMEM=1`, `BOX64_DYNAREC_SAFEFLAGS=2` [BIẾT tên biến, hiệu quả cần đo]; chấp nhận chậm hơn vì EA cầu nối nhẹ.
- Nếu Winlator chạy được thì dùng nó làm đường dự phòng: bật chế độ nền nhỏ nhất, độ phân giải thấp nhất, không bật DXVK [THỬ].

## B. Phía MT5: chỉ giữ thứ EA cầu nối cần
- Chạy bằng `terminal64.exe /portable /config:startup.ini` [NGUỒN: metatrader5.com start]. Trong startup.ini: `[Common] Login= Server=` (Server = địa chỉ:cổng của máy chủ giao dịch broker), `[StartUp] Expert=PyEABridge Symbol=<1 mã> Period=H1 ExpertParameters=bridge.set` [NGUỒN]. (`ShutdownTerminal` chỉ áp dụng cho script, EA thì không.)
- Đúng 1 biểu đồ, 1 EA, không chỉ báo, Market Watch ẩn hết (EA tự `SymbolSelect` mã cần) [NGUỒN: mql5 blog 774255 khuyến nghị ẩn Market Watch].
- Tools → Options: Max bars in chart xuống mức thấp nhất đủ dùng (blog khuyên 5.000-10.000; EA cầu nối có thể đặt thấp hơn), tắt âm thanh, tắt tin tức/cộng đồng/tự cập nhật [NGUỒN một phần; mục tin tức/cộng đồng blog KHÔNG nêu giá trị - mình chưa kiểm].
- Ngân sách RAM trên Windows thật: terminal ~200-500 MB + mỗi EA ~50-150 MB [NGUỒN: blog 774255 cho VPS Windows]. Qua Box64 + Wine sẽ cao hơn, chưa có số liệu.

## C. Giữ sống trên Android
- `termux-wake-lock`, miễn tối ưu pin cho Termux/app, chạy dưới dịch vụ foreground (thông báo cố định) [BIẾT].
- Android 12+ có «phantom process killer» có thể giết tiến trình con của Termux (Wine/Box64 là tiến trình con): cần tắt giới hạn tiến trình con (Android 14+: Tuỳ chọn nhà phát triển → «Tắt hạn chế tiến trình con»; bản cũ hơn cần adb) [BIẾT, mỗi hãng một kiểu].
- PyEA phải tự giám sát: mất cầu nối thì KHÔNG mở lệnh mới, báo người dùng, và đối soát lại khi nối lại (cơ chế đối soát có sẵn).

## D. Kế hoạch đo (để biết giá tải thật, trước khi dùng tiền)
1. RSS của `box64`/`wine`/`terminal64.exe` sau 30 phút (MB). 2. % CPU khi nhàn rỗi và khi có tick dày. 3. Pin hao mỗi giờ khi tắt màn hình. 4. Độ trễ vòng lệnh PyEA→EA→sàn→về (ms), độ mất kết nối sau 6/12/24 giờ. 5. Có mất tick/«no connection» như báo cáo không.

## E. So sánh hướng (kết luận thận trọng)
- Giảm tải ở MT5: được một phần (1 biểu đồ, 1 EA, ít bar) nhưng không bỏ được giao diện/lõi terminal.
- Giảm tải ở giả lập: lớn hơn nhiều (bỏ GUI Winlator, Xvfb thay màn hình thật, 64-bit thuần, không GPU) nhưng càng bóc nhiều càng do mình tự dựng, ít người đã thử; Termux-box đã bị chủ kho lưu trữ (archived 06/2025) - nên dựa vào Box64+Wine gốc, không dựa vào script đó.
- Chưa có nguồn nào chứng minh MT5 chạy ổn định lâu dài qua Box64. Đây là rủi ro lớn nhất, quyết định phải đo (mục D) trước khi làm tiếp phần backend.

---
# Phần 3: cầu nối mỏng (logic ở app) so với EA đầy đủ logic bot trong MT5 (phân tích, CHƯA đo)

Tải gồm phần CỐ ĐỊNH (giống nhau ở cả hai cách: Box64 + Wine + terminal64 + kết nối sàn + đồng bộ lịch sử) và phần BIẾN ĐỔI (CPU chạy logic bot).
- **EA đầy đủ logic**: mã MQL5 biên dịch ra x86-64 nên CŨNG bị Box64 dịch từng lệnh sang ARM khi chạy → logic càng nặng (chỉ báo mỗi tick, vòng lặp, nhiều mã) càng tốn qua giả lập, chậm hơn chạy gốc (mức cụ thể chưa đo). Sửa bot phải biên dịch/gắn lại trong MT5; bot MQL5 phải viết lại, không dùng lại được code Python của app (backtest, AI, lịch kinh tế...).
- **Cầu nối mỏng**: EA chỉ chuyển giá/sự kiện và thực thi lệnh; logic chạy trong app Python ở tốc độ ARM gốc. Phần biến đổi trong giả lập gần như bằng 0 và không phụ thuộc độ phức tạp bot. Chi phí thêm: một vòng socket nội bộ (loopback, rất nhỏ) và tuần tự hoá JSON mỗi tick (có thể gộp/giới hạn tần suất).
- **Kết luận**: cầu nối mỏng nhẹ hơn, và khoảng cách càng lớn khi bot càng nặng. Với bot rất nhẹ (vài chỉ báo, tính theo nến đóng) chênh lệch nhỏ vì phần cố định chiếm phần lớn. Phần cố định mới là thứ quyết định giá tải, và là thứ phải đo.
- **Đổi lại**: EA đầy đủ vẫn chạy khi app bị Android giết; cầu nối mỏng thì app chết là hết logic. Giảm rủi ro bằng cách luôn đặt SL/TP phía sàn kèm lệnh, và cầu nối tự báo mất kết nối với app (không mở lệnh mới).

## «Bỏ hết, chỉ giữ kết nối» - bỏ được tới đâu
- Không bỏ được terminal. Nhưng MQL5 có loại chương trình **Service** (không gắn biểu đồ, chạy nền, một OnStart với vòng lặp vô hạn, tự nạp lại khi MT5 khởi động nếu đang chạy lúc tắt) [mql5.com/en/docs/runtime/running] → bỏ được cả biểu đồ. NHƯNG tài liệu SocketConnect nói chỉ gọi được từ EA và script [mql5.com/en/docs/network/socketconnect]; Service có dùng được socket/hàm giao dịch hay không tài liệu KHÔNG xác nhận → phải thử trên MT5 thật. Nếu không được: quay về EA gắn một biểu đồ duy nhất, không chỉ báo, số nến tối thiểu.
- Cấu hình «điền thông số trong Cài đặt»: PyEA sinh startup.ini từ ô số tài khoản/máy chủ (tài liệu chỉ nêu Login và Server trong [Common]; chỗ lưu MẬT KHẨU chưa xác nhận - có thể phải đăng nhập tay một lần để terminal tự nhớ).

---
# Phần 4: đã làm (Update13)
Cầu nối EA + máy chủ cục bộ + backend `mt5ea` + báo động + giám sát giả lập: xem `docs/MT5_EA_BRIDGE.md`. Công cụ: `tools/mt5_phone/` (run_mt5_termux.sh có tự khởi động lại, setup_check.sh, wine_minimal.reg, startup.ini). Tuỳ chọn, mặc định tắt.


---
# Phần 5: đo, và «viết lại giả lập» - nói thẳng (cập nhật Update15)
## Đã đo được gì (trong môi trường đám mây x86, KHÔNG phải điện thoại)
`python3 -I tools/bench_bridge.py` đo PHẦN PYTHON của cầu nối với EA giả qua loopback (Xeon 2.3GHz, 2 lõi, Python 3.13; EA giả cùng tiến trình nên đây là chặn trên):
- Rảnh (có nhịp HB/PING): ~0.15% CPU; RAM tiến trình ~31-33 MB (phần lớn là bản thân Python).
- Gọi yêu cầu (account) khứ hồi: p50 0.14 ms, p95 0.18 ms, p99 0.27 ms (có lần chậm 43 ms - nhiễu lập lịch).
- Tick: 51 byte/dòng; xử lý ~296.000 tick/giây, ~3 µs CPU/tick (tick thật chỉ vài chục/giây).
=> Phía app/cầu nối gần như không đáng kể so với MT5+giả lập. Trên điện thoại chậm hơn vài lần vẫn không đổi kết luận; nhưng con số điện thoại thật CHƯA có.
## Chưa đo được và lý do
Box64/Wine/MT5: RAM, CPU, pin, độ bền. Cần ARM64 + MT5 thật; sandbox này là x86, không cài được gói, không có MT5. Mình không bịa số. Chạy `tools/mt5_phone/measure.sh` 30 phút trên máy bạn (nó lấy thông số bình thường, không hardcode) rồi gửi `~/pyea_measure_summary.txt`.
## Giả lập đã lược tới đâu - thật thà
Đã bỏ (bằng cấu hình, không phải viết lại): giao diện Winlator (dùng Termux + Xvfb), Wine 32-bit/Box86, Mono/Gecko, driver âm thanh, hộp thoại crash, log debug, đồ hoạ DXVK/Vulkan, chạy một biểu đồ một EA.
CHƯA bỏ được: toàn bộ Wine (hàng trăm DLL, nạp khi cần), wineserver, lớp dịch CPU Box64, lớp tương thích Android (proot) và chính terminal MT5 (GUI, không có chế độ headless).
## «Viết lại giả lập chỉ có chức năng MT5 cần» - đã cân nhắc lại
Bạn đúng ở chỗ: MT5 đóng nguồn thì chấp nhận, còn giả lập (Wine LGPL, Box64 MIT - mã mở) là phần CÓ THỂ sửa. Hai mức:
1. Viết mới từ đầu (tự cài lại Win32 + dịch CPU): vẫn không thực tế - bề mặt Win32 MT5 gọi chưa biết (không ai liệt kê được nếu chưa chạy), và bộ dịch x86-64→ARM64 là nhiều năm công sức; sai một API là MT5 sập ở chỗ khó đoán.
2. Tự BUILD tối giản từ mã mở (khả thi): Wine bỏ mô-đun không dùng (in ấn, âm thanh, OpenGL, HTML...), Box64 build theo CPU. Cần DỮ LIỆU để biết bỏ gì: `WINEDEBUG=+loaddll` + `tools/mt5_phone/list_dlls.sh` cho ra danh sách DLL MT5 thật sự nạp (đã làm, test với log mẫu; định dạng log Wine ghi theo trí nhớ). Rồi build trong GitHub Actions (cần máy ARM64 để thử).
Hướng «Wine ARM64 gốc, Box64 chỉ dịch mã MT5» (README Box64 chỉ nói «Wine WOW64 build chạy x86 Windows trong môi trường chỉ có Box64, còn thử nghiệm, chạy được trong đa số trường hợp»; không nhắc wowbox64): CHƯA xác minh, chỉ thử sau khi có số đo.
Thứ tự đúng: đo (measure.sh) → xem thành phần nào ăn tải → chỉ khi Wine/wineserver chiếm lớn mới build tối giản. Nếu chính MT5 chiếm phần lớn thì giả lập mỏng hơn không đáng.
