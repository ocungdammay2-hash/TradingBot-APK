"""Khối lượng lệnh THEO RỦI RO («đặt SL ở đâu thì vào bao nhiêu để nếu dính SL chỉ mất đúng X%/X tiền»). Thuần Python, không Kivy, không I/O.

Công thức:  khối_lượng = tiền_chịu_lỗ / (|giá_vào − giá_SL| × contract_size)
  - tiền_chịu_lỗ = risk_money (số tiền) và/hoặc risk_pct × vốn (balance mặc định); nếu có cả hai lấy số NHỎ hơn.
  - luôn làm tròn XUỐNG theo step (làm tròn lên sẽ vượt rủi ro đã định); dưới volume_min thì trả 0 (không ép lên mức tối thiểu, trừ khi bật `round_up_to_min`).
  - các trần: volume_max của mã, max_volume người dùng đặt, và ký quỹ khả dụng (margin_per_unit).
GIỚI HẠN (nói thẳng): số tiền lỗ tính theo đơn vị YẾT GIÁ của mã. Mã có yết giá khác đồng tiền tài khoản (vd tài khoản USD giao dịch USDJPY, hay chỉ số bằng tiền khác) thì
số tiền thật sẽ lệch theo tỷ giá - truyền `loss_per_unit` (số tiền lỗ của 1 đơn vị khối lượng khi giá chạy 1 đơn vị giá, theo ĐỒNG TIỀN TÀI KHOẢN) để chính xác. Phí/trượt giá/gap
qua đêm KHÔNG nằm trong công thức: lỗ thật khi dính SL có thể lớn hơn số đã định."""
import math

EPS = 1e-9


def _num(x, default=0.0):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


def floor_to_step(volume, step):
    """Làm tròn XUỐNG theo bước (step <= 0: giữ nguyên). Chịu được sai số số thực (0.3/0.1)."""
    v, st = _num(volume), _num(step)
    if st <= 0:
        return v
    return round(math.floor(v / st + EPS) * st, 10)


def size_for_risk(entry, stop, risk_pct=None, risk_money=None, base_amount=0.0, contract_size=1.0, volume_min=0.0, volume_max=0.0,
                  volume_step=0.0, user_max=0.0, margin_per_unit=0.0, free_margin=0.0, loss_per_unit=0.0, round_up_to_min=False):
    """-> dict: ok, volume, raw_volume, risk_money (số tiền chịu lỗ đã định), actual_risk (lỗ thật nếu dính SL ở khối lượng đã chọn),
    risk_per_unit (lỗ của 1 đơn vị khối lượng nếu dính SL), capped_by (None|'volume_max'|'max_volume'|'margin'|'min_volume'), reason (rỗng nếu ok).
    Không bao giờ ném lỗi; không tính được thì volume = 0.0 và `reason` giải thích."""
    out = {"ok": False, "volume": 0.0, "raw_volume": 0.0, "risk_money": 0.0, "actual_risk": 0.0, "risk_per_unit": 0.0, "capped_by": None, "reason": ""}
    e, s = _num(entry), _num(stop)
    if e <= 0 or s <= 0:
        out["reason"] = "giá vào hoặc giá SL không hợp lệ (phải > 0)"
        return out
    dist = abs(e - s)
    if dist <= 0:
        out["reason"] = "giá SL trùng giá vào - không có khoảng chịu lỗ"
        return out
    # tiền chịu lỗ
    budgets = []
    rm, rp = _num(risk_money), _num(risk_pct)
    if rm > 0:
        budgets.append(rm)
    if rp > 0:
        base = _num(base_amount)
        if base <= 0:
            out["reason"] = "dùng risk_pct nhưng không biết vốn (base_amount <= 0)"
            return out
        budgets.append(base * rp / 100.0)
    if not budgets:
        out["reason"] = "cần risk_pct hoặc risk_money > 0"
        return out
    budget = min(budgets)
    out["risk_money"] = budget
    cs = _num(contract_size)
    per_price = _num(loss_per_unit) if _num(loss_per_unit) > 0 else (cs if cs > 0 else 1.0)   # tiền lỗ của 1 đơn vị khối lượng khi giá chạy 1 đơn vị giá
    lpu = dist * per_price
    out["risk_per_unit"] = lpu
    raw = budget / lpu
    out["raw_volume"] = raw
    vol = raw
    caps = []
    vmax, umax = _num(volume_max), _num(user_max)
    if vmax > 0:
        caps.append((vmax, "volume_max"))
    if umax > 0:
        caps.append((umax, "max_volume"))
    mpu, fm = _num(margin_per_unit), _num(free_margin)
    if mpu > 0 and fm > 0:
        caps.append((fm / mpu, "margin"))
    for cap, name in caps:
        if vol > cap + EPS:
            vol, out["capped_by"] = cap, name
    vol = floor_to_step(vol, volume_step)
    vmin = _num(volume_min)
    if vmin > 0 and vol < vmin - 1e-12:
        if round_up_to_min and (vmax <= 0 or vmin <= vmax):
            vol, out["capped_by"] = vmin, "min_volume"
        else:
            out["volume"] = 0.0
            out["reason"] = "khối lượng tính được %.8g nhỏ hơn mức tối thiểu %.8g của mã: lệnh nhỏ nhất đã rủi ro %.2f > %.2f đã định (nới SL, tăng vốn/rủi ro, hoặc bật round_up_to_min)" % (
                vol, vmin, vmin * lpu, budget)
            return out
    if vol <= 0:
        out["reason"] = "khối lượng sau khi làm tròn bằng 0 (rủi ro %.2f quá nhỏ so với khoảng SL)" % budget
        return out
    out.update(ok=True, volume=vol, actual_risk=vol * lpu)
    return out
