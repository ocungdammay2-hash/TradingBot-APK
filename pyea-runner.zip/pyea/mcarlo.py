"""
Thống kê nâng cao + Monte Carlo cho danh sách lệnh đã đóng (theo PDF «thiếu gì»: Sortino/Calmar/R-multiple/theo tháng, Monte Carlo).
Chỉ thư viện chuẩn, tất định khi cho `seed`. Đầu vào: danh sách đối tượng có `.profit` (và `.close_time` cho phần theo tháng).
Nói thẳng: Monte Carlo trộn/lấy mẫu lại CHÍNH các lệnh đã có -> chỉ cho biết độ nhạy với THỨ TỰ lệnh, không dự báo tương lai.
"""
import math
import random
import statistics
import time


def _profits(trades):
    return [float(getattr(t, "profit", t)) for t in trades]


def max_drawdown(profits, start_balance):
    """(sụt tuyệt đối, sụt %) trên đường vốn theo từng lệnh."""
    eq = peak = float(start_balance)
    dd = ddp = 0.0
    for p in profits:
        eq += p
        peak = max(peak, eq)
        dd = max(dd, peak - eq)
        if peak > 0:
            ddp = max(ddp, (peak - eq) / peak * 100.0)
    return dd, ddp


def sortino(profits, start_balance, target=0.0):
    """Sortino theo lợi suất từng lệnh (so với vốn đầu kỳ chạy), chỉ phạt phần dưới `target`. None nếu không có lệnh lỗ/ít dữ liệu."""
    if len(profits) < 3:
        return None
    eq = float(start_balance)
    rets = []
    for p in profits:
        if eq <= 0:
            break
        rets.append(p / eq)
        eq += p
    if len(rets) < 3:
        return None
    m = sum(rets) / len(rets)
    dsq = sum(min(0.0, r - target) ** 2 for r in rets) / len(rets)
    if dsq <= 0:
        return None
    return (m - target) / math.sqrt(dsq) * math.sqrt(len(rets))


def calmar(trades, start_balance):
    """Lợi suất quy năm / sụt vốn tối đa (%). None nếu thiếu thời gian hoặc không sụt."""
    ps = _profits(trades)
    ts = [getattr(t, "close_time", 0) or 0 for t in trades]
    if len(ps) < 2 or not any(ts):
        return None
    _, ddp = max_drawdown(ps, start_balance)
    span = max(ts) - min(getattr(t, "open_time", 0) or min(ts) for t in trades)
    if ddp <= 0 or span <= 0 or start_balance <= 0:
        return None
    ret = sum(ps) / start_balance
    years = span / (365.25 * 86400)
    ann = ((1 + ret) ** (1 / years) - 1) if (1 + ret) > 0 and years >= 1 / 365 else ret / max(years, 1e-9)
    return ann * 100.0 / ddp


def r_multiples(trades, risk_per_trade=None):
    """R-multiple = lợi nhuận / rủi ro 1 lệnh. Không biết SL từng lệnh -> dùng `risk_per_trade` (tiền) hoặc LỖ TRUNG BÌNH làm 1R (ghi rõ trong kết quả)."""
    ps = _profits(trades)
    losses = [-p for p in ps if p < 0]
    if risk_per_trade and risk_per_trade > 0:
        one_r, src = float(risk_per_trade), "rủi ro cho trước"
    elif losses:
        one_r, src = sum(losses) / len(losses), "lỗ trung bình"
    else:
        return {"one_r": None, "nguồn 1R": "không có lệnh lỗ", "kỳ vọng (R)": None, "R TB lãi": None, "R TB lỗ": None, "R": []}
    rs = [p / one_r for p in ps]
    w = [r for r in rs if r > 0]
    l = [r for r in rs if r < 0]
    return {"one_r": one_r, "nguồn 1R": src, "kỳ vọng (R)": sum(rs) / len(rs) if rs else None,
            "R TB lãi": sum(w) / len(w) if w else 0.0, "R TB lỗ": sum(l) / len(l) if l else 0.0, "R": rs}


def monthly(trades):
    """[{'thang': '2026-10', 'n', 'net'}] theo tháng ĐÓNG lệnh (UTC)."""
    acc = {}
    for t in trades:
        ct = getattr(t, "close_time", 0) or 0
        k = time.strftime("%Y-%m", time.gmtime(ct))
        a = acc.setdefault(k, [0, 0.0])
        a[0] += 1
        a[1] += float(t.profit)
    return [{"thang": k, "n": v[0], "net": v[1]} for k, v in sorted(acc.items())]


def extra_stats(trades, start_balance, risk_per_trade=None):
    ps = _profits(trades)
    r = r_multiples(trades, risk_per_trade)
    return {"Sortino (theo lệnh)": sortino(ps, start_balance), "Calmar": calmar(trades, start_balance),
            "Kỳ vọng (R)": r["kỳ vọng (R)"], "1R (nguồn)": "%s (%s)" % (r["one_r"], r["nguồn 1R"]), "Theo tháng": monthly(trades),
            "Rủi ro": risk_stats(trades, start_balance)}


def _pct(sorted_xs, q):
    if not sorted_xs:
        return None
    i = min(len(sorted_xs) - 1, max(0, int(round(q * (len(sorted_xs) - 1)))))
    return sorted_xs[i]


def monte_carlo(trades, start_balance, runs=1000, mode="shuffle", seed=None, ruin_level=0.5):
    """Mô phỏng `runs` đường vốn.
    mode='shuffle': hoán vị thứ tự lệnh (cùng tổng lãi, đổi sụt vốn) · mode='bootstrap': lấy mẫu có hoàn lại (đổi cả tổng lãi).
    ruin_level: tỷ lệ vốn đầu còn lại bị coi là «cháy» (0.5 = mất một nửa)."""
    ps = _profits(trades)
    if not ps:
        return {"ok": False, "runs": 0, "message": "Không có lệnh để mô phỏng."}
    if mode not in ("shuffle", "bootstrap"):
        raise ValueError("mode phải là shuffle|bootstrap")
    runs = max(1, int(runs))
    rng = random.Random(seed)
    finals, dds, ruin = [], [], 0
    floor = start_balance * ruin_level
    for _ in range(runs):
        seq = ps[:]
        if mode == "shuffle":
            rng.shuffle(seq)
        else:
            seq = [rng.choice(ps) for _ in ps]
        eq = float(start_balance)
        peak, dd, hit = eq, 0.0, False
        for p in seq:
            eq += p
            peak = max(peak, eq)
            if peak > 0:
                dd = max(dd, (peak - eq) / peak * 100.0)
            if eq <= floor:
                hit = True
        finals.append(eq)
        dds.append(dd)
        ruin += hit
    fs, ds = sorted(finals), sorted(dds)
    return {"ok": True, "runs": runs, "mode": mode, "n_trades": len(ps), "seed": seed,
            "final_p5": _pct(fs, 0.05), "final_p50": _pct(fs, 0.5), "final_p95": _pct(fs, 0.95),
            "dd_p50": _pct(ds, 0.5), "dd_p95": _pct(ds, 0.95), "dd_max": ds[-1],
            "prob_loss": sum(1 for f in finals if f < start_balance) / runs,
            "prob_ruin": ruin / runs, "ruin_level": ruin_level,
            "message": "Chỉ cho biết độ nhạy với thứ tự/mẫu lệnh đã có, không phải dự báo."}


# ---------------------------------------------------------------- Kelly / VaR / CVaR (rủi ro theo từng lệnh)
MIN_TRADES_RISK = 30                     # dưới mức này ước lượng quá nhiễu: vẫn tính nhưng gắn cảnh báo


def wilson_lower(wins, n, z=1.96):
    """Cận DƯỚI khoảng tin cậy Wilson (~95%) của tỷ lệ thắng - dùng để Kelly «thận trọng» khi mẫu nhỏ."""
    if n <= 0:
        return 0.0
    p = wins / n
    den = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt(max(0.0, p * (1 - p) / n + z * z / (4 * n * n)))
    return max(0.0, (centre - margin) / den)


def kelly(trades):
    """Kelly cho chuỗi lệnh thắng/thua: f* = p − (1−p)/b, p = tỷ lệ thắng, b = lãi TB / lỗ TB (tỷ lệ lãi-lỗ). f* là PHẦN VỐN nên RỦI RO mỗi lệnh (mất cả `lỗ TB` ở mức đó).
    -> dict: n, p, b, full (f*), half, quarter, p_low, conservative (Kelly dùng cận dưới của p), edge (True nếu có lợi thế), warning.
    Không tính được (thiếu lệnh thắng hoặc thua) -> full = None và `warning` nói lý do. Kelly đầy đủ NHẠY với sai số ước lượng: người ta thường dùng 1/2 hoặc 1/4 Kelly."""
    ps = _profits(trades)
    n = len(ps)
    out = {"n": n, "p": None, "b": None, "full": None, "half": None, "quarter": None, "p_low": None, "conservative": None, "edge": None, "warning": ""}
    if n == 0:
        out["warning"] = "chưa có lệnh nào"
        return out
    wins = [x for x in ps if x > 0]
    losses = [-x for x in ps if x < 0]
    out["p"] = len(wins) / n
    if not wins or not losses:
        out["warning"] = "cần có cả lệnh thắng lẫn lệnh thua để tính Kelly (hiện %d thắng, %d thua)" % (len(wins), len(losses))
        return out
    b = (sum(wins) / len(wins)) / (sum(losses) / len(losses))
    f = out["p"] - (1 - out["p"]) / b
    out["b"], out["full"], out["edge"] = b, f, f > 0
    out["half"], out["quarter"] = f / 2.0, f / 4.0
    out["p_low"] = wilson_lower(len(wins), n)
    out["conservative"] = out["p_low"] - (1 - out["p_low"]) / b
    warn = []
    if n < MIN_TRADES_RISK:
        warn.append("chỉ %d lệnh (< %d): ước lượng rất nhiễu, đừng dựa vào" % (n, MIN_TRADES_RISK))
    if f <= 0:
        warn.append("Kelly ≤ 0: KHÔNG có lợi thế theo mẫu này - Kelly bảo đặt 0")
    elif out["conservative"] <= 0:
        warn.append("với cận dưới tin cậy của tỷ lệ thắng thì Kelly ≤ 0: lợi thế chưa vững")
    out["warning"] = "; ".join(warn)
    return out


def var_cvar(trades, start_balance, level=0.95):
    """VaR/CVaR LỊCH SỬ theo TỪNG LỆNH (lỗ là số dương): VaR = lệnh xấu thứ k (k = ⌊(1−level)·n⌋, tối thiểu 1) - cách BẢO THỦ trên mẫu rời rạc (không nội suy, không làm nhẹ); CVaR = lỗ trung bình của k lệnh xấu nhất (≥ VaR).
    Kèm VaR tham số (giả định phân phối chuẩn) để đối chiếu - đuôi lệnh thật thường DÀY hơn chuẩn nên VaR chuẩn có thể đánh giá thấp rủi ro đuôi.
    -> dict: n, level, var, cvar, var_pct, cvar_pct (% vốn đầu), var_normal, worst, warning. Dưới 2 lệnh: var = None."""
    ps = _profits(trades)
    n = len(ps)
    sb = float(start_balance or 0.0)
    out = {"n": n, "level": level, "var": None, "cvar": None, "var_pct": None, "cvar_pct": None, "var_normal": None, "worst": None, "warning": ""}
    if not 0.5 <= level < 1.0:
        raise ValueError("level phải trong [0.5, 1)")
    if n < 2:
        out["warning"] = "cần ít nhất 2 lệnh"
        return out
    xs = sorted(ps)                                         # tăng dần: lỗ nặng nhất ở đầu
    k = max(1, int(math.floor((1.0 - level) * n + 1e-9)))   # số lệnh nằm trong đuôi
    var = -xs[k - 1] if k - 1 < n else -xs[0]               # lệnh thứ k xấu nhất = ngưỡng VaR (lịch sử)
    tail = xs[:k]
    cvar = -sum(tail) / len(tail)
    out["var"], out["cvar"], out["worst"] = max(0.0, var), max(0.0, cvar), max(0.0, -xs[0])
    if sb > 0:
        out["var_pct"], out["cvar_pct"] = out["var"] / sb * 100.0, out["cvar"] / sb * 100.0
    try:
        sd = statistics.pstdev(ps)
        out["var_normal"] = max(0.0, -(statistics.fmean(ps) - statistics.NormalDist().inv_cdf(level) * sd))
    except statistics.StatisticsError:
        pass
    warn = []
    if n < MIN_TRADES_RISK:
        warn.append("chỉ %d lệnh (< %d): VaR/CVaR rất nhiễu" % (n, MIN_TRADES_RISK))
    if k < 5:
        warn.append("đuôi chỉ có %d lệnh: CVaR gần như là lệnh xấu nhất" % k)
    out["warning"] = "; ".join(warn)
    return out


def risk_stats(trades, start_balance, level=0.95):
    return {"kelly": kelly(trades), "var": var_cvar(trades, start_balance, level)}


def risk_text(trades, start_balance, level=0.95):
    """Đoạn chữ cho giao diện/báo cáo; nói thẳng giới hạn của phương pháp."""
    k, v = kelly(trades), var_cvar(trades, start_balance, level)
    lines = []
    if k["full"] is None:
        lines.append("Kelly: không tính được - %s." % k["warning"])
    else:
        lines.append("Kelly: tỷ lệ thắng %.1f%%, lãi/lỗ TB = %.2f → Kelly đầy đủ %.1f%% vốn rủi ro mỗi lệnh (½ Kelly %.1f%%, ¼ Kelly %.1f%%; theo cận dưới tin cậy của tỷ lệ thắng: %s)." % (
            k["p"] * 100, k["b"], k["full"] * 100, k["half"] * 100, k["quarter"] * 100,
            "≤ 0%" if k["conservative"] <= 0 else "%.1f%%" % (k["conservative"] * 100)))
        if k["warning"]:
            lines.append("  ⚠ " + k["warning"])
    if v["var"] is None:
        lines.append("VaR/CVaR: không tính được - %s." % v["warning"])
    else:
        pc = (" (%.2f%% / %.2f%% vốn đầu)" % (v["var_pct"], v["cvar_pct"])) if v["var_pct"] is not None else ""
        lines.append("VaR %.0f%% mỗi lệnh = %.2f, CVaR = %.2f%s; lệnh lỗ nặng nhất %.2f; VaR theo phân phối chuẩn = %s (để đối chiếu; đuôi lệnh thật thường dày hơn phân phối chuẩn)." % (
            v["level"] * 100, v["var"], v["cvar"], pc, v["worst"], "%.2f" % v["var_normal"] if v["var_normal"] is not None else "-"))
        if v["warning"]:
            lines.append("  ⚠ " + v["warning"])
    lines.append("Giả định: các lệnh độc lập và tương lai giống quá khứ; VaR/CVaR ở đây là theo TỪNG LỆNH (không phải theo ngày), không gồm gap/trượt giá ngoài mẫu. Kelly chỉ là cận trên tham khảo, không phải lời khuyên đặt cược.")
    return "\n".join(lines)


def monte_carlo_text(mc):
    if not mc.get("ok"):
        return mc.get("message", "")
    return ("Monte Carlo %d lần (%s, %d lệnh): vốn cuối P5/P50/P95 = %.2f / %.2f / %.2f · sụt vốn P50/P95/tối đa = %.1f%% / %.1f%% / %.1f%% · "
            "xác suất lỗ %.1f%% · xác suất mất ≥%.0f%% vốn %.1f%%. %s") % (
        mc["runs"], mc["mode"], mc["n_trades"], mc["final_p5"], mc["final_p50"], mc["final_p95"], mc["dd_p50"], mc["dd_p95"], mc["dd_max"],
        mc["prob_loss"] * 100, (1 - mc["ruin_level"]) * 100, mc["prob_ruin"] * 100, mc["message"])
