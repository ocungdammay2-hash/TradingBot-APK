"""
Điểm vào của DỊCH VỤ WORKER cô lập bot trên Android (python-for-android: services = Botworker0:service_botworker.py,... - xem buildozer.spec).

Mỗi dịch vụ p4a chạy ở MỘT TIẾN TRÌNH Android riêng với trình thông dịch Python riêng. Vỏ (dịch vụ chính hoặc UI) khởi động dịch vụ này kèm
PYTHON_SERVICE_ARGUMENT = {"port", "token", "slot", "data_dir"}; worker nối vào cổng loopback đó, trình mã bí mật, rồi phục vụ ĐÚNG giao thức của
pyea.botproc.child_main (JSON theo dòng) - chỉ khác đường truyền (socket thay cho pipe). Không import Kivy; không có khoá/phiên của app trong tiến trình này.
Kết thúc (vỏ đóng kết nối / yêu cầu dừng) -> hàm main trả về -> p4a tự stopSelf() -> onDestroy -> killProcess: không để sót tiến trình.
"""
import json
import os
import socket
import sys


def main(argument=None):
    try:
        from pyea import bootlog
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        bootlog.crumb("--- Botworker bắt đầu ---")
    except Exception:                                       # noqa: BLE001
        pass
    arg = json.loads(argument if argument is not None else (os.environ.get("PYTHON_SERVICE_ARGUMENT") or "{}"))
    port, token = int(arg["port"]), str(arg["token"])
    wd = arg.get("data_dir") or os.getcwd()
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        os.makedirs(wd, exist_ok=True)
        os.chdir(wd)                                            # như pipe-mode: cwd = thư mục dữ liệu riêng của bot
        os.environ["HOME"] = os.environ["TMPDIR"] = wd
        log = open(os.path.join(wd, "child.log"), "w", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log                           # print() của bot -> child.log (kênh giao thức là socket, không phải stdout)
    except OSError:
        pass
    sock = socket.create_connection(("127.0.0.1", port), timeout=15)
    sock.settimeout(None)
    rf = sock.makefile("r", encoding="utf-8", newline="\n")
    wf = sock.makefile("w", encoding="utf-8", newline="\n")
    wf.write(json.dumps({"t": "hello", "token": token, "slot": arg.get("slot")}) + "\n")
    wf.flush()
    from pyea.botproc import child_main
    try:
        child_main(rf, wf)
    finally:
        for f in (wf, rf, sock):
            try:
                f.close()
            except OSError:
                pass


if __name__ == "__main__":
    main()
