"""
Điểm vào của DỊCH VỤ «MT5 NHÚNG» (python-for-android: services = Emu:service_emu.py:foreground:sticky - xem buildozer.spec).
Chạy trong tiến trình riêng (tách khỏi UI và Botservice): tải/cài/chạy MT5 thật trong proot + Ubuntu + Box64 + Wine bên trong app, xem pyea/embedded.py.
Không import Kivy. Khi Android dựng lại dịch vụ sticky thì KHÔNG có tham số -> đọc lại cấu hình từ <files>/emu/request.json (do UI ghi).
Dừng: UI ghi cờ emu/stop.flag (dịu: script giám sát trong Ubuntu tự tắt Wine) rồi gọi stop_service('Emu').
"""
import json
import os
import sys
import time
import traceback


def _data_dir():
    arg = os.environ.get("PYTHON_SERVICE_ARGUMENT", "")
    try:
        d = json.loads(arg).get("data_dir")
        if d:
            return d
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from pyea import android_native as an
        d = an.files_dir()
        if d:
            return d
    except Exception:                                       # noqa: BLE001
        pass
    return os.path.join(os.environ.get("ANDROID_PRIVATE", "."), "app_data")


def main():
    from pyea import bootlog
    bootlog.crumb("--- Emu bắt đầu ---")
    bootlog.enable_faulthandler()
    try:
        _main()
    except BaseException:                                   # noqa: BLE001
        bootlog.crumb("Emu LỖI\n" + traceback.format_exc())
        raise


def _main():
    from pyea import android_native as an
    from pyea import embedded

    data_dir = _data_dir()
    os.makedirs(data_dir, exist_ok=True)
    an.set_service_notification("PyEA Runner - MT5 nhúng", "Đang chuẩn bị...", an.NOTIF_EMU)
    an.acquire_wakelocks()
    arg = os.environ.get("PYTHON_SERVICE_ARGUMENT", "")
    try:
        a = json.loads(arg) if arg else {}
    except ValueError:
        a = {}
    a["data_dir"] = data_dir
    crash_log = os.path.join(data_dir, "emu", "service_crash.log")
    failures = []
    while True:
        try:
            ok = embedded.service_main(json.dumps(a))
            st = embedded.read_state(data_dir)
            an.set_service_notification("PyEA Runner - MT5 nhúng", "Đã dừng" if ok else "Lỗi: %s" % (st.get("error") or st.get("failed_stage") or "xem app"), an.NOTIF_EMU)
            break
        except Exception:                                   # noqa: BLE001
            tb = traceback.format_exc()
            try:
                os.makedirs(os.path.dirname(crash_log), exist_ok=True)
                with open(crash_log, "a", encoding="utf-8") as f:
                    f.write("%s\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
            except OSError:
                pass
            now = time.time()
            failures = [t for t in failures if now - t < 300] + [now]
            if len(failures) >= 5:
                an.notify_alarm("MT5 nhúng dừng hẳn", "Dịch vụ Emu lỗi liên tiếp 5 lần: " + tb.strip().splitlines()[-1][:160])
                break
            time.sleep(5)
    an.release_wakelocks()


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
