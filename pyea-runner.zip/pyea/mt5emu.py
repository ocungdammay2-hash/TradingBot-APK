"""«Kết nối MT5 nhanh» = chính MT5 THẬT chạy trong giả lập trên điện thoại (proot + Ubuntu + Box64 + Wine), cài và đăng nhập TỰ ĐỘNG.
HAI cách chạy, cùng một đường cài/giám sát/báo tiến trình:
  1. NHÚNG (ưu tiên, pyea/embedded.py): chạy ngay trong app, KHÔNG cần Termux. Người dùng chỉ nhập login + mật khẩu + server. Cần APK có proot trong thư viện gốc (native_libs/, xem docs/MT5_QUICK.md); chạy ở mọi targetSdk.
  2. TERMUX (dự phòng khi máy/APK không hợp cách 1): dán MỘT lệnh vào Termux; tools/mt5_phone/install_mt5_termux.sh làm phần còn lại.
Cả hai báo tiến trình về app qua cổng cục bộ (cầu nối EA, pyea/mt5ea.py). Module này là phần LOGIC (không Kivy): kiểm nhập liệu, tạo cài đặt + lệnh dán, đọc tiến trình.
Giao diện ở pyea/ui_mt5emu.py.

THẬT THÀ: phần logic và script đã test bằng lệnh giả (tests/test_mt5_install.py, tests/test_mt5emu.py). CHƯA từng chạy Box64/Wine/MT5 trên điện thoại thật.
Cách Termux: việc KHÔNG tự động hoá được là cài Termux (app riêng, bản F-Droid/GitHub) và dán lệnh 1 lần - Android không cho một app tự cài app khác hay tự chạy file tải về
(cách nhúng tránh được điều này nhờ proot đóng gói trong APK - nativeLibraryDir được phép chạy trực tiếp; chỉ cài ngoài, không lên Google Play).
Mật khẩu: chỉ trong RAM, chỉ đi qua cổng 127.0.0.1 tới script, và app quên ngay khi EA đã nối được (xem Mt5EaServer.first_login_password)."""
import re
import secrets
import shlex
import time

from . import mt5ea

TOKEN_OK = re.compile(r"^[A-Za-z0-9_.-]{8,64}$")
TERMUX_URL = "https://f-droid.org/packages/com.termux/"
START_CMD = "bash ~/pyea-start-mt5.sh"
STOP_CMD = "bash ~/pyea-start-mt5.sh stop"

_BOOT = r'''rm -f ~/pyea_install.sh; exec 3<>/dev/tcp/127.0.0.1/@PORT@ || { echo "Không nối được app PyEA: hãy mở app và bấm Bắt đầu"; exit 1; }; printf "SUPHELLO|v=1|token=@TOKEN@\nGET|name=install_mt5_termux.sh\n" >&3; while IFS= read -r -t 20 -u 3 l; do case $l in *b64=*) b=${l#*b64=}; b=${b%%|*}; printf %s "${b//%3D/=}" | base64 -d > ~/pyea_install.sh; break;; FILE*) break;; esac; done; [ -s ~/pyea_install.sh ] && @ENV@ bash ~/pyea_install.sh || echo "Không lấy được script từ app PyEA (sai token? app chưa mở?)"'''


def problems(login, password, server, installer_url=""):
    out = []
    if not re.fullmatch(r"\d{4,12}", str(login or "").strip()):
        out.append("Login MT5 là một dãy số (4-12 chữ số)")
    if not password:
        out.append("Chưa nhập mật khẩu")
    elif not mt5ea.ini_safe(password):
        out.append("Mật khẩu không được chứa ký tự xuống dòng")
    sv = str(server or "").strip()
    if not sv:
        out.append("Chưa nhập server (vd Exness-MT5Real8, hoặc địa chỉ:cổng như trong email của sàn)")
    elif len(sv) > 100 or not mt5ea.ini_safe(sv):
        out.append("Tên server không hợp lệ")
    url = str(installer_url or "").strip()
    if url and (not url.startswith("https://") or re.search(r"\s", url) or len(url) > 400):
        out.append("Link bộ cài MT5 của sàn phải bắt đầu bằng https:// và không có khoảng trắng (hoặc để trống)")
    return out


def plan(settings, login, server, lean=False):
    """Cài đặt cần đặt cho nguồn mt5ea. Giữ token cũ nếu hợp lệ (để file cũ trong Debian vẫn dùng được), không thì sinh token mới. lean = chế độ nhẹ của EA (MT5 nhúng)."""
    tok = str(settings.get("mt5ea_token") or "")
    if not TOKEN_OK.match(tok):
        tok = secrets.token_hex(12)
    out = {"exchange": "mt5ea", "mt5ea_token": tok, "mt5ea_port": str(settings.get("mt5ea_port") or mt5ea.DEFAULT_PORT),
           "mt5ea_login": str(login).strip(), "mt5ea_server": str(server).strip(), "mt5ea_supervised": "yes"}
    if lean:
        out["mt5ea_lean"] = "yes"
    return out


def bootstrap_command(port, token, installer_url=""):
    """MỘT dòng dán vào Termux: nối cổng cục bộ của app, tải install_mt5_termux.sh qua giao thức PyEA-EA (không cần curl/wget), rồi chạy nó."""
    if not TOKEN_OK.match(str(token)):
        raise ValueError("token chứa ký tự không an toàn để dán vào dòng lệnh")
    env = "PYEA_PORT=%d PYEA_TOKEN=%s" % (int(port), token)
    if installer_url:
        env += " MT5_SETUP_URL=%s" % shlex.quote(installer_url)
    inner = _BOOT.replace("@PORT@", str(int(port))).replace("@TOKEN@", token).replace("@ENV@", env)
    return "bash -c " + shlex.quote(inner)


def prepare(settings, login, password, server, installer_url=""):
    """Gom việc phía app: kiểm nhập liệu, đặt cài đặt, mở cổng cục bộ, cấp sẵn file + mật khẩu (chỉ RAM). Trả (cài đặt cần lưu, máy chủ, lệnh dán).
    Ném ValueError (lỗi nhập liệu) hoặc BridgeError (không mở được cổng)."""
    bad = problems(login, password, server, installer_url)
    if bad:
        raise ValueError("\n".join(bad))
    upd = plan(settings, login, server)
    srv = mt5ea.ensure_server(dict(settings, **upd))
    srv.start()
    srv.install_reset()
    srv.set_first_login_password(password)
    return upd, srv, bootstrap_command(int(upd["mt5ea_port"]), upd["mt5ea_token"], installer_url)


def prepare_embedded(settings, login, password, server, installer_url="", data_dir="", launcher=None, profile="lean"):
    """Như prepare() nhưng cho MT5 NHÚNG: mở cổng cục bộ + cấp file/mật khẩu (RAM), rồi bật dịch vụ Emu. Trả (cài đặt cần lưu, máy chủ, (ok, lỗi bật dịch vụ)).
    Mật khẩu KHÔNG đi qua dịch vụ/ghi file: script trong Ubuntu lấy qua cổng cục bộ (GET startup.ini)."""
    from . import embedded
    bad = problems(login, password, server, installer_url)
    if bad:
        raise ValueError("\n".join(bad))
    upd = plan(settings, login, server, lean=True)
    srv = mt5ea.ensure_server(dict(settings, **upd))
    srv.start()
    srv.install_reset()
    srv.set_first_login_password(password)
    res = embedded.launch(data_dir, int(upd["mt5ea_port"]), upd["mt5ea_token"], profile, mt5_url=str(installer_url or "").strip(), starter=launcher)
    return upd, srv, res


# ----------------------------------------------------------------------------------------------- tiến trình
def _row_state(rec):
    st = (rec or {}).get("state", "")
    return {"start": "run", "progress": "run", "ok": "ok", "skip": "ok", "fail": "fail", "wait": "run"}.get(st, "todo")


def _newest(*recs):
    """Bản ghi bước MỚI NHẤT (theo «t») trong các nguồn: RAM của cầu nối cục bộ, state.json của dịch vụ, stages.log do script ghi."""
    recs = [r for r in recs if r]
    return max(recs, key=lambda r: float(r.get("t") or 0)) if recs else None


def _rows(install, stages, extra=None, infer=False):
    """(rows, nok, nrun). `install` = máy chủ cục bộ (chỉ trong RAM: mở lại app là mất), `extra` = bản trên đĩa (state.json + stages.log). infer=True (MT5 nhúng): các bước chạy TUẦN TỰ,
    nên khi một bước sau đã chạy/xong/lỗi thì mọi bước trước mà không ai báo được coi là ĐÃ XONG (log thật: mở lại app giữa chừng thì hiện «Đang cài (0%)» dù đã qua 5/11 bước)."""
    extra = extra or {}
    recs = [(sid, label, _newest(install.get(sid), extra.get(sid))) for sid, label in stages]
    states = [_row_state(r) for _, _, r in recs]
    inferred = set()
    if infer:
        last = max((i for i, st in enumerate(states) if st != "todo"), default=-1)
        for i in range(last):
            if states[i] == "todo":
                states[i] = "ok"
                inferred.add(i)
        # Bước trước còn «đang chạy» (bản ghi progress/start đến muộn) trong khi một bước SAU đã xong hoặc lỗi thì không thể còn chạy: log thật bản v14 - tìm bản Wine tải lại Wine
        # (sự kiện «Tải Wine… 485 MB, vẫn đang chạy») NGAY TRONG bước prefix, nên sự kiện wine muộn hơn «wine ok» và dòng ▶ kẹt ở «Tải Wine» dù bước MT5 đã báo lỗi.
        done_after = [i for i, st in enumerate(states) if st in ("ok", "fail")]
        if done_after:
            for i in range(max(done_after)):
                if states[i] == "run":
                    states[i] = "ok"
                    inferred.add(i)
    rows = [(sid, label, states[i], "(đã xong - suy ra từ bước sau)" if i in inferred else (rec or {}).get("detail", "")) for i, (sid, label, rec) in enumerate(recs)]
    return rows, sum(1 for st in states if st == "ok"), sum(1 for st in states if st == "run")


def _pct(nok, nrun, n):
    """Mỗi bước xong = 1 phần; bước đang chạy tính nửa phần (để không đứng yên hàng chục phút ở một con số); tối đa 99 cho tới khi EA nối thật."""
    return min(99, int(100 * (nok + (0.5 if nrun else 0.0)) / max(1, n)))


def progress(srv, stages=None, extra=None, infer=False):
    """Đọc tiến trình từ máy chủ cục bộ. rows = [(id, nhãn, trạng_thái, chi_tiết)] với trạng thái todo|run|ok|fail. stages: INSTALL_STAGES (Termux, mặc định) hoặc EMBED_STAGES.
    connected = EA đã nối VÀ báo có tài khoản đăng nhập (kết luận thật); done = connected hoặc script báo đăng nhập ổn."""
    stages = tuple(stages or mt5ea.INSTALL_STAGES)
    rows, nok, nrun = _rows(srv.install, stages, extra, infer)
    info = dict(srv.info or {})
    try:
        login = int(info.get("login") or 0)
    except (TypeError, ValueError):
        login = 0
    connected = bool(srv.connected and login)
    login_rec = srv.install.get("login") or {}
    failed = [r for r in rows if r[2] == "fail"]
    done = connected or login_rec.get("state") == "ok"
    pct = 100 if connected else _pct(nok, nrun, len(rows))
    return {"rows": rows, "pct": pct, "failed": failed, "connected": connected, "done": done, "started": bool(srv.install) or any(r[2] != "todo" for r in rows),
            "login": login, "server": str(info.get("server") or ""), "demo": str(info.get("demo") or ""), "link": str(info.get("link") or "socket"),
            "log_ok": login_rec.get("state") == "ok"}


def progress_embedded(srv, data_dir):
    """progress() cho MT5 nhúng + trạng thái dịch vụ Emu đọc từ emu/state.json (phase, lỗi, số đo CPU/RAM). Không cần máy chủ cục bộ có báo gì để biết dịch vụ chết/lỗi.
    Trạng thái từng bước còn được đọc từ ĐĨA (state.json + stages.log do script ghi) nên mở lại app giữa chừng không làm % tụt về 0."""
    from . import embedded
    disk = embedded.read_stages(data_dir)
    if srv is not None:
        p = progress(srv, mt5ea.EMBED_STAGES, extra=disk, infer=True)
    else:
        rows, nok, nrun = _rows({}, tuple(mt5ea.EMBED_STAGES), disk, True)
        p = {"rows": rows, "pct": _pct(nok, nrun, len(rows)), "failed": [r for r in rows if r[2] == "fail"], "connected": False,
             "done": False, "started": any(r[2] != "todo" for r in rows), "login": 0, "server": "", "demo": "", "link": "socket", "log_ok": False}
    st = embedded.status(data_dir)
    p["emu"] = st
    p["skip_compile"] = embedded.skip_compile_on(data_dir)       # v27: cờ «bỏ qua biên dịch EA, chạy MT5 thử»
    if st["phase"] == "failed" and not p["failed"]:           # lỗi do dịch vụ gặp mà chưa kịp báo qua cổng (hoặc app không nhận được)
        sid = st.get("failed_stage") or "precheck"
        rows = [(i, l, "fail" if i == sid else s, d if i != sid else (st.get("error") or d)) for (i, l, s, d) in p["rows"]]
        p["rows"], p["failed"] = rows, [r for r in rows if r[2] == "fail"]
    # Mật khẩu đăng nhập lần đầu chỉ ở RAM của app (không ghi đĩa). Android tắt tiến trình giao diện lúc chạy nền lâu rồi người dùng mở lại: máy chủ cục bộ dựng lại (_attach_server) NHƯNG KHÔNG còn mật khẩu,
    # trong khi cài chưa xong và EA chưa từng nối -> MT5 sẽ mở lên mà không đăng nhập được. Báo sớm để người dùng «Nhập lại thông tin» thay vì bấm «Khởi động lại» vô ích.
    p["pw_lost"] = bool(srv is not None and srv.first_login_password() is None and not srv.ever_connected() and not p["connected"]
                        and st["phase"] in ("installing", "failed", "installed", "idle") and (p["started"] or st["phase"] != "idle"))
    res = (srv.res if srv is not None else {}) or {}
    if res and (time.monotonic() - res.get("t", 0)) < 60:
        p["res"] = res
    elif st.get("res"):
        p["res"] = dict(st["res"])
    return p


PHANTOM_LIMIT = 32          # giới hạn tiến trình con (phantom) của Android 12+, tính chung mọi app (tài liệu agnostic-apollo/Android-Docs)
PHANTOM_WARN = 24           # cảnh báo sớm khi số tiến trình con của riêng MT5 nhúng đã gần ngưỡng đó


def headline_embedded(p):
    emu = p.get("emu") or {}
    ph = emu.get("phase", "idle")
    res = p.get("res") or {}
    cost = (" CPU %.0f%% (100%% = 1 nhân), RAM %d MB, %d tiến trình con." % (res.get("cpu", 0), res.get("rss_mb", 0), res.get("procs", 0))) if res else ""
    if res and res.get("procs", 0) >= PHANTOM_WARN:
        cost += (" CẢNH BÁO: Android 12+ giết tiến trình con khi cả máy vượt ~%d (tính chung mọi app); bật «Tắt giới hạn tiến trình con» trong Tuỳ chọn nhà phát triển."
                 % PHANTOM_LIMIT)
    if p["connected"]:
        via = " (qua đường tệp + relay vì MT5 chặn socket)" if p.get("link") == "file" else ""
        return ("ĐÃ NỐI: MT5 nhúng đã đăng nhập tài khoản %s%s và EA đang nối với app%s.%s" % (p["login"], (" @ " + p["server"]) if p["server"] else "", via, cost), "ok")
    skip = (" [CHẾ ĐỘ THỬ: đã BỎ QUA biên dịch EA, MT5 chạy KHÔNG có EA cầu nối nên app sẽ không nối được; muốn có EA, bấm «Bật lại biên dịch EA».]") if p.get("skip_compile") else ""
    pw = (" MẬT KHẨU đăng nhập MT5 không còn trong app (app đã bị hệ thống tắt rồi mở lại giữa chừng; mật khẩu chỉ giữ trong RAM, không ghi đĩa): "
          "bấm «Nhập lại thông tin», nhập lại 3 ô rồi «Bắt đầu». Phần đã cài xong KHÔNG phải làm lại.") if p.get("pw_lost") else ""
    if p["failed"]:
        sid, label, _, detail = p["failed"][0]
        if sid == "provision" and "không nối được app" in (detail or ""):
            return ("LỖI ở bước «%s»: app PyEA không mở cổng cục bộ lúc cần cấp file (thường do Android tắt app khi chạy nền lâu). Mở lại hộp thoại này (app tự mở lại cổng), rồi bấm "
                    "«Nhập lại thông tin» → nhập lại 3 ô → «Bắt đầu». Phần đã cài xong KHÔNG phải làm lại." % label, "fail")
        if sid == "compile" and "không thấy file log" in (detail or ""):
            return ("LỖI ở bước «%s»: MetaEditor (trình biên dịch EA) đã khởi chạy nhưng không ra kết quả trong thời hạn - điện thoại chạy Wine/Box64 rất chậm hoặc nó bị kẹt. "
                    "Bấm «Sao chép chẩn đoán» gửi lại (có CPU từng tiến trình, tên cửa sổ và ảnh màn hình ảo lúc nó đứng). Muốn xem MT5 có chạy được không trước: "
                    "«Bỏ qua biên dịch, chạy MT5 thử» (chưa có EA nên chưa nối với app).%s" % (label, pw), "fail")
        return ("LỖI ở bước «%s». Xem chi tiết bên dưới, sửa nguyên nhân rồi bấm «Khởi động lại» (làm tiếp từ bước lỗi, không tải lại phần đã xong).%s" % (label, pw), "fail")
    if ph == "stopped":
        return ("MT5 nhúng đang DỪNG. Bấm «Khởi động lại» để bật.%s" % skip, "wait")
    if ph == "idle" and not p["started"]:
        return ("Đang bật dịch vụ MT5 nhúng...", "wait")
    if ph in ("installing", "installed") or not p["done"]:
        if ph == "running":
            return ("MT5 đang chạy, đang đăng nhập và đợi EA nối vào app...%s%s" % (cost, skip), "wait")
        alive = "" if (emu.get("alive", True) or ph == "idle") else " (CHƯA thấy dịch vụ nền báo nhịp - Android có thể đã tắt nó; bấm «Khởi động lại»)"
        return ("Đang cài (%d%%). Lần đầu có thể mất hàng chục phút; cứ để app mở, không cần làm gì khác.%s%s%s" % (p["pct"], alive, pw, skip), "wait")
    return ("MT5 báo đã đăng nhập; đang đợi EA nối vào app...%s%s" % (cost, skip), "wait")


MARK = {"todo": "·", "run": "▶", "ok": "✓", "fail": "✗"}


def render(p):
    lines = []
    for sid, label, stt, detail in p["rows"]:
        line = "%s %s" % (MARK[stt], label)
        if stt in ("run", "fail") and detail:
            line += "\n    " + detail[:300]
        lines.append(line)
    return "\n".join(lines)


def headline(p):
    if p["connected"]:
        via = " (qua đường tệp + relay vì MT5 chặn socket)" if p.get("link") == "file" else ""
        return ("ĐÃ NỐI: MT5 trong giả lập đã đăng nhập tài khoản %s%s và EA đang nối với app%s." % (p["login"], (" @ " + p["server"]) if p["server"] else "", via), "ok")
    if p["failed"]:
        sid, label, _, detail = p["failed"][0]
        return ("LỖI ở bước «%s». Sửa theo gợi ý rồi chạy lại CÙNG lệnh trong Termux (nó làm tiếp từ bước lỗi)." % label, "fail")
    if not p["started"]:
        return ("Chưa thấy Termux báo về. Làm lần lượt: (1) cài Termux, (2) bấm «Sao chép lệnh», (3) mở Termux, giữ ngón tay trên màn hình → Dán, Enter.", "wait")
    if p["log_ok"]:
        return ("MT5 báo đã đăng nhập; đang đợi EA nối vào app...", "wait")
    return ("Đang cài (%d%%). Có thể mất hàng chục phút ở lần đầu; giữ Termux mở và đừng tắt app PyEA." % p["pct"], "wait")
