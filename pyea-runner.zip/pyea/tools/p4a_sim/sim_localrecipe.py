"""Kiểm recipe vá với MÃ p4a thật: nạp qua --local-recipes, giải đồ thị recipe, thử chuỗi hai kiến trúc."""
import os, sys, types, tempfile
os.environ["ANDROIDSDK"] = os.environ["ANDROIDNDK"] = "/tmp/x"
from pythonforandroid.build import Context
from pythonforandroid import build as B
from pythonforandroid.graph import get_recipe_order_and_bootstrap
from pythonforandroid.recipe import Recipe
orig = B.run_pymodules_install
ctx = Context(); ctx.setup_dirs(sys.argv[1]); ctx.ndk_api = 24
ctx.local_recipes = sys.argv[2]
reqs = ["python3", "kivy", "certifi", "pyjnius", "android", "pyeapipfix"]
order, mods, bs = get_recipe_order_and_bootstrap(ctx, reqs, None)
print("ORDER", order); print("MODULES", mods)
assert "pyeapipfix" in order and "pyeapipfix" not in mods
r = Recipe.get_recipe("pyeapipfix", ctx)
print("recipe", r, "url", r.url, "patched:", getattr(B.run_pymodules_install, "_pyea_fresh_venv", False))
assert B.run_pymodules_install is not orig
# giả lập chuỗi 2 kiến trúc: lần 1 tạo venv, lần 2 phải thấy venv đã bị xoá
calls = []
def fake_orig(ctx, arch, modules, project_dir=None, ignore_setup_py=False):
    v = os.path.join(ctx.build_dir, "venv")
    calls.append((arch.arch, os.path.exists(v)))
    os.makedirs(os.path.join(v, "lib"), exist_ok=True)
B.run_pymodules_install = B.run_pymodules_install.__wrapped__ if False else B.run_pymodules_install
# thay hàm gốc BÊN TRONG wrapper
inner = B.run_pymodules_install
inner.__wrapped__ = fake_orig
# make_wrapper đóng gói 'orig' qua closure -> dựng lại wrapper quanh fake_orig để thử đúng logic
import importlib.util
spec = importlib.util.spec_from_file_location("pf", os.path.join(sys.argv[2], "pyeapipfix", "__init__.py"))
pf = importlib.util.module_from_spec(spec); spec.loader.exec_module(pf)
w = pf.make_wrapper(fake_orig)
for a in ("arm64-v8a", "armeabi-v7a"):
    w(ctx, types.SimpleNamespace(arch=a), [], None, ignore_setup_py=True)
print("CALLS", calls)
assert calls == [("arm64-v8a", False), ("armeabi-v7a", False)], calls
print("OK")
