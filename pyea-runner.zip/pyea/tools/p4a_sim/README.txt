Mô phỏng p4a bằng MÃ NGUỒN THẬT từ PyPI (không cần SDK/NDK/GitHub). Cách dùng:
  python -m venv v && v/bin/pip install python-for-android==2026.5.9 sh packaging
  mkdir ctx && v/bin/python tools/p4a_sim/sim_resolver.py ctx             # dò module pip + wheel Android (HANDOFF 5bk)
  v/bin/python tools/p4a_sim/sim_localrecipe.py ctx tools/p4a_recipes     # recipe pyeapipfix nạp được + vá đúng (5bl)
  v/bin/python tools/p4a_sim/sim_lifecycle.py ctx tools/p4a_recipes       # vòng đời recipe url=None
Không chạy được: biên dịch/Gradle (cần NDK/SDK).
