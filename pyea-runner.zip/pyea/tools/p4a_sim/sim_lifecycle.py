import os, sys
os.environ["ANDROIDSDK"] = os.environ["ANDROIDNDK"] = "/tmp/x"
from pythonforandroid.build import Context
from pythonforandroid.recipe import Recipe
from pythonforandroid.util import ensure_dir
from pythonforandroid.archs import ArchAarch_64
ctx = Context(); ctx.setup_dirs(sys.argv[1]); ctx.ndk_api = 24; ctx.local_recipes = sys.argv[2]
r = Recipe.get_recipe("pyeapipfix", ctx)
arch = ArchAarch_64(ctx)
r.download_if_necessary()
ensure_dir(r.get_build_container_dir(arch.arch))
r.prepare_build_dir(arch.arch)
r.prebuild_arch(arch)
r.apply_patches(arch)
print("should_build", r.should_build(arch))
r.build_arch(arch)
r.install_libraries(arch)
r.postbuild_arch(arch)
print("LIFECYCLE OK")
