import os, sys, types
os.environ["ANDROIDSDK"] = os.environ["ANDROIDNDK"] = "/tmp/x"
from pythonforandroid.build import Context, process_python_modules
from pythonforandroid.graph import get_recipe_order_and_bootstrap
ctx = Context(); ctx.setup_dirs(sys.argv[1]); ctx.ndk_api = 24
reqs = ["python3", "kivy", "certifi", "pyjnius", "android"] + sys.argv[2:]
order, mods, bs = get_recipe_order_and_bootstrap(ctx, reqs, None)
ctx.recipe_build_order = order
print("MODULES_IN", mods)
out = process_python_modules(ctx, mods, types.SimpleNamespace(arch="arm64-v8a"))
print("MODULES_OUT"); [print("  ", m.rsplit("/", 1)[-1]) for m in out]
