#!/usr/bin/env python3
"""Công cụ NGƯỜI BÁN bot: tạo khoá ký, đóng gói bot thành .pyeabot có chữ ký, kiểm tra gói, dựng danh mục.

  python3 tools/bot_pack.py new-key seller.key                       # in khoá công khai + vân tay (giữ bí mật seller.key)
  python3 tools/bot_pack.py pack my_bot.py seller.key --name "Bot RSI" --version 1.2 --author "Tên" --desc "Mô tả" -o rsi.pyeabot
  python3 tools/bot_pack.py verify rsi.pyeabot
  python3 tools/bot_pack.py index rsi.pyeabot other.pyeabot --base-url https://example.com/bots/ -o index.json
"""
import argparse
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import ed25519, market                                   # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    n = sub.add_parser("new-key")
    n.add_argument("out")
    p = sub.add_parser("pack")
    p.add_argument("bot")
    p.add_argument("key")
    p.add_argument("--name", required=True)
    p.add_argument("--version", default="1.0")
    p.add_argument("--author", default="")
    p.add_argument("--desc", default="")
    p.add_argument("-o", required=True)
    v = sub.add_parser("verify")
    v.add_argument("pkg")
    ix = sub.add_parser("index")
    ix.add_argument("pkgs", nargs="+")
    ix.add_argument("--base-url", required=True)
    ix.add_argument("-o", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "new-key":
        seed = os.urandom(32)
        with open(a.out, "w") as f:
            f.write(ed25519.b64u(seed) + "\n")
        try:
            os.chmod(a.out, 0o600)
        except OSError:
            pass
        pub = ed25519.b64u(ed25519.public_key(seed))
        print("Khoá công khai:", pub, "\nVân tay:", market.fingerprint(pub))
    elif a.cmd == "pack":
        seed = ed25519.load_private_seed(open(a.key).read())
        blob = market.pack(open(a.bot, encoding="utf-8").read(), seed, a.name, a.version, a.author, a.desc)
        open(a.o, "wb").write(blob)
        print("Đã tạo", a.o, "·", market.verify(blob)["fingerprint"])
    elif a.cmd == "verify":
        d = market.verify(open(a.pkg, "rb").read())
        print("HỢP LỆ:", d["name"], d["version"], "· nhà phát hành", d["fingerprint"], "· quyền:", d["perms"] or "không xin quyền")
    else:
        rows = []
        for pth in a.pkgs:
            blob = open(pth, "rb").read()
            d = market.verify(blob)
            rows.append({"name": d["name"], "version": d.get("version", ""), "author": d.get("author", ""), "description": d.get("description", ""),
                         "url": a.base_url.rstrip("/") + "/" + os.path.basename(pth), "pub": d["pub"], "sha256": hashlib.sha256(blob).hexdigest()})
        json.dump({"bots": rows}, open(a.o, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("Đã ghi", a.o, "(%d bot)" % len(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
