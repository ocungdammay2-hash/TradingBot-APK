#!/usr/bin/env python3
"""Mã băm cho cache của CI (.github/workflows/build-apk.yml). Chỉ dùng thư viện chuẩn.

VÌ SAO CẦN: trước đây khoá cache = hashFiles('**/buildozer.spec'). File đó chứa dòng `version = ...` nên MỖI lần
tăng phiên bản (hoặc sửa danh sách dịch vụ, quyền...) khoá đổi => KHÔNG khôi phục được gì => build lại từ đầu
(tải SDK/NDK + biên dịch lại python/kivy/SDL2 cho 2 kiến trúc). Ở đây chỉ băm những khoá thật sự quyết định
phần ĐÃ BIÊN DỊCH, nên đổi phiên bản/mã nguồn của app KHÔNG làm mất cache.

Hai mã (in ra dạng `tool=...` và `comp=...`, có thể ghi thẳng vào $GITHUB_OUTPUT):
  tool  = công cụ tải về (SDK, NDK, python-for-android):  api, minapi, ndk, ndk_api, sdk, build-tools, p4a.*
  comp  = phần đã biên dịch (recipe): tool + android.archs + requirements + recipe cục bộ + file ràng buộc pip

Dùng:  python tools/ci_fingerprint.py [buildozer.spec] [--github-output $GITHUB_OUTPUT]
"""
import hashlib
import os
import re
import sys

TOOL_KEYS = ("android.api", "android.minapi", "android.ndk", "android.ndk_api", "android.sdk",
             "android.build_tools_version", "android.ndk_path", "android.sdk_path")
COMP_KEYS = ("android.archs", "android.arch", "requirements", "android.skip_update")
EXTRA_FILES = ("tools/p4a_constraints.txt",)           # ràng buộc pip: đổi => cài lại module
_KV = re.compile(r"^([A-Za-z0-9_.\-]+)\s*=\s*(.*?)\s*$")


def parse_spec(text):
    """{khoá: giá trị} của các dòng `khoá = giá trị` (bỏ dòng chú thích/trống, khoá trùng: dòng sau thắng)."""
    out = {}
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        m = _KV.match(line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def _norm(key, val):
    if key in ("android.archs", "android.arch"):          # thứ tự/khoảng trắng không quan trọng
        return ",".join(sorted(x.strip() for x in val.split(",") if x.strip()))
    if key == "requirements":
        return ",".join(sorted(x.strip() for x in val.split(",") if x.strip()))
    return val.strip()


def _hash_tree(path):
    """Mã băm nội dung mọi file trong thư mục (theo đường dẫn tương đối, bỏ __pycache__)."""
    h = hashlib.sha256()
    if not os.path.isdir(path):
        return h.hexdigest()
    for root, dirs, files in os.walk(path):
        dirs[:] = sorted(d for d in dirs if d != "__pycache__")
        for fn in sorted(files):
            if fn.endswith((".pyc", ".pyo")):
                continue
            fp = os.path.join(root, fn)
            h.update(os.path.relpath(fp, path).replace(os.sep, "/").encode())
            h.update(b"\0")
            with open(fp, "rb") as f:
                h.update(f.read())
            h.update(b"\0")
    return h.hexdigest()


def _hash_file(path):
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return "-"


def fingerprints(spec_path):
    """(tool, comp, chi_tiet) - tool/comp là chuỗi hex 12 ký tự; chi_tiet là danh sách dòng để in ra log."""
    base = os.path.dirname(os.path.abspath(spec_path))
    with open(spec_path, encoding="utf-8") as f:
        kv = parse_spec(f.read())
    tool_parts = ["%s=%s" % (k, _norm(k, kv[k])) for k in TOOL_KEYS if k in kv]
    tool_parts += ["%s=%s" % (k, kv[k].strip()) for k in sorted(kv) if k.startswith("p4a.") and k != "p4a.hook" and k != "p4a.local_recipes"]
    comp_parts = list(tool_parts)
    comp_parts += ["%s=%s" % (k, _norm(k, kv[k])) for k in COMP_KEYS if k in kv]
    rec = kv.get("p4a.local_recipes", "").strip()
    if rec:
        comp_parts.append("local_recipes=%s" % _hash_tree(os.path.join(base, rec)))
    for rel in EXTRA_FILES:
        comp_parts.append("%s=%s" % (rel, _hash_file(os.path.join(base, rel))))
    tool = hashlib.sha256("\n".join(tool_parts).encode()).hexdigest()[:12]
    comp = hashlib.sha256("\n".join(comp_parts).encode()).hexdigest()[:12]
    detail = ["tool %s <- %s" % (tool, "; ".join(tool_parts) or "(trống)")]
    detail.append("comp %s <- %d khoá (archs, requirements, recipe cục bộ, ràng buộc pip, + tool)" % (comp, len(comp_parts)))
    return tool, comp, detail


def main(argv):
    args = list(argv)
    out = None
    if "--github-output" in args:
        i = args.index("--github-output")
        out = args[i + 1] if i + 1 < len(args) else None
        del args[i:i + 2]
    spec = args[0] if args else "buildozer.spec"
    tool, comp, detail = fingerprints(spec)
    for line in detail:
        print(line, file=sys.stderr)
    print("tool=%s" % tool)
    print("comp=%s" % comp)
    if out:
        with open(out, "a", encoding="utf-8") as f:
            f.write("tool=%s\ncomp=%s\n" % (tool, comp))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
