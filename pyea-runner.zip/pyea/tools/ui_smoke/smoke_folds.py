"""Chạy Kivy THẬT (xvfb): tab Cài đặt gồm các mục SỔ XUỐNG - mở tab, bấm mở «Giao dịch & an toàn», sửa một ô, bấm Lưu (cả khi nhiều mục chưa dựng), đóng mục, kiểm widget.
Dùng: xvfb-run -a python3 -I tools/ui_smoke/smoke_folds.py [<gốc dự án>]   (mặc định: thư mục chứa tools/)
Tuỳ chọn: PYEA_SCRATCH=<thư mục> để chỉ nơi lưu dữ liệu tạm + ảnh chụp (mặc định: thư mục tạm mới)."""
import json, os, sys, time, traceback
os.environ.setdefault("KIVY_NO_ARGS", "1")
import tempfile
ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
S = os.environ.get("PYEA_SCRATCH") or tempfile.mkdtemp(prefix="pyea_smoke_")
os.environ["KIVY_HOME"] = os.path.join(S, "kivyhome_f")
os.environ["PYEA_DATA_DIR"] = os.path.join(S, "data_f")
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tests"))
from kivy.config import Config
Config.set("graphics", "width", "540"); Config.set("graphics", "height", "960")
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import pyea.ui as U
out = os.path.join(S, "shots_f"); os.makedirs(out, exist_ok=True)
app = U.PyEAApp(); errs = []; log = []
def walk(w):
    yield w
    for c in w.children: yield from walk(c)
def btns(text):
    return [x for x in walk(Window) if isinstance(x, Button) and text in (x.text or "")]
def n_widgets(root): return sum(1 for _ in walk(root))
def shot(n): Window.screenshot(name=os.path.join(out, n + ".png"))
def dismiss():
    for t in ("ồng ý", "Bỏ qua"):
        for b in btns(t): b.dispatch("on_release")
def step(fn, delay):
    def w(dt):
        try: fn()
        except Exception: errs.append(traceback.format_exc()); app.stop()
    Clock.schedule_once(w, delay)
st = None
def s1():
    global st
    tp = next(w for w in walk(app.root) if w.__class__.__name__ == "TabbedPanel")
    tabs = list(reversed(tp.tab_list)); dismiss(); dismiss()
    tab = [t for t in tabs if "ài đặt" in t.text][0]; tp.switch_to(tab)
    st = app.settings_tab
    step(s2, 1.5)
def s2():
    dismiss()
    log.append(("fold_headers", [b.text for b in btns("▶")]))
    log.append(("widgets_collapsed", n_widgets(st)))
    log.append(("inputs_collapsed", sum(1 for w in walk(st) if isinstance(w, TextInput))))
    shot("1_collapsed")
    b = btns("Giao dịch & an toàn"); assert b, "không thấy mục Giao dịch & an toàn"
    b[0].dispatch("on_release")
    step(s3, 2.5)
def s3():
    log.append(("header_after_open", [b.text for b in btns("Giao dịch & an toàn")]))
    log.append(("inputs_open_trade", sum(1 for w in walk(st) if isinstance(w, TextInput))))
    log.append(("widgets_open_trade", n_widgets(st)))
    shot("2_trade_open")
    form = st.gform
    c = form.ctrl.get("tick_interval")
    log.append(("tick_interval_built", c is not None))
    # sửa một ô trong mục đang mở, các mục khác CHƯA dựng; bấm Lưu thật
    target = None
    for k, inp in form.inputs.items():
        if inp.group == "Giao dịch & an toàn" and form.ctrl.get(k) is not None and inp.kind not in ("bool", "choice") and getattr(inp, "subtype", None) != "text":
            target = k; break
    log.append(("edit_key", target))
    old = app.settings.get(target)
    log.append(("old", old))
    ctl = form.ctrl[target]
    ctl.text = ctl.text            # giữ nguyên để không phá hợp lệ; kiểm lưu không làm hỏng ô chưa dựng
    before = {k: v for k, v in app.settings.items()}
    for b in btns("Lưu"):
        if b.parent is st.top_row: b.dispatch("on_release")
    log.append(("save_changes", sorted(k for k in app.settings if before.get(k) != app.settings.get(k))))
    log.append(("unbuilt_after_save", sum(1 for k in form.inputs if form.ctrl.get(k) is None)))
    b = btns("DNSE")
    log.append(("dnse_header", [x.text for x in b][:2]))
    [x for x in b if "▶" in x.text][0].dispatch("on_release")
    step(s4, 2.0)
def s4():
    shot("3_dnse_open")
    log.append(("dnse_buttons", [b.text for b in btns("DNSE")]))
    for b in btns("Giao dịch & an toàn"): b.dispatch("on_release")      # đóng mục
    step(s5, 0.6)
def s5():
    log.append(("inputs_after_close_trade", sum(1 for w in walk(st) if isinstance(w, TextInput))))
    log.append(("header_closed", [b.text for b in btns("Giao dịch & an toàn")]))
    shot("4_trade_closed")
    app.stop()
Clock.schedule_once(lambda dt: step(s1, 0), 3)
try: app.run()
except Exception: errs.append(traceback.format_exc())
for l in log: print("LOG", l)
print("ERRS", len(errs)); [print(e) for e in errs]
