"""Chạy Kivy THẬT (xvfb): «Kết nối MT5 nhanh» ở chế độ NHÚNG (không Termux): form -> Bắt đầu -> trang tiến trình nhúng (nút Dừng/Khởi động lại/chẩn đoán/Xoá), tiến trình theo sự kiện,
lỗi thật từ emu/state.json, CPU/RAM, «ĐÃ NỐI», mật khẩu không lọt ra đĩa, bấm 2 lần mới xoá. Dịch vụ Emu được thay bằng hàm giả (không có Android ở đây).
Chạy: PYEA_SCRATCH=<thư mục tạm> xvfb-run -a python tools/ui_smoke/smoke_embedded.py <thư mục dự án>"""
import json, os, sys, time, traceback
os.environ.setdefault("KIVY_NO_ARGS", "1")
S = os.environ["PYEA_SCRATCH"]
os.environ["KIVY_HOME"] = os.path.join(S, "kivyhome_m_%d" % os.getpid())
os.environ["PYEA_DATA_DIR"] = os.path.join(S, "data_m")
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, os.path.join(sys.argv[1], "tests"))
from kivy.config import Config
Config.set("graphics", "width", "720"); Config.set("graphics", "height", "1440")
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
import pyea.ui as U
from pyea import embedded, mt5ea
from fake_ea import FakeEA
from test_mt5emu import sup_exchange
embedded.supported = lambda *a, **k: (True, "")                      # máy desktop: coi như đủ điều kiện (APK có proot trong thư viện gốc + Emu)
started = []
embedded._start_service = lambda a: started.append(a) or (True, "")
embedded._stop_service = lambda: True
PW = "Sm0ke#Embedded-PW-555"
out = os.path.join(S, "shots_m"); os.makedirs(out, exist_ok=True)
app = U.PyEAApp(); errs = []; log = []; ea = []
def walk(w):
    yield w
    for c in w.children: yield from walk(c)
def btns(text): return [x for x in walk(Window) if isinstance(x, Button) and text in (x.text or "")]
def shot(n): Window.screenshot(name=os.path.join(out, n + ".png"))
def dismiss():
    for t in ("ồng ý", "Bỏ qua"):
        for b in btns(t): b.dispatch("on_release")
def pop():
    from pyea.ui_widgets import StyledPopup
    p = [x for x in walk(Window) if isinstance(x, StyledPopup) and "Kết nối MT5 nhanh" in (x.title or "")]
    return p[0] if p else None
def inputs(): return list(reversed([w for w in walk(pop()) if isinstance(w, TextInput)]))
def labels(): return " | ".join((x.text or "").replace("\n", " ")[:2000] for x in walk(pop()) if isinstance(x, Label) and x.text)
def bt(text): return [b for b in walk(pop()) if isinstance(b, Button) and text in (b.text or "")][0]
def has_bt(text): return bool([b for b in walk(pop()) if isinstance(b, Button) and text in (b.text or "")])
def fail(e): errs.append(e); app.stop()
def srv(): return [v for v in mt5ea._SERVERS.values()][0]
def run(dt):
    try:
        embedded.clear_all(app.data_dir)                                   # lần chạy trước để lại emu/request.json -> hộp thoại sẽ vào thẳng trang tiến trình
        tp = next(w for w in walk(app.root) if w.__class__.__name__ == "TabbedPanel")
        tabs = list(reversed(tp.tab_list)); dismiss(); dismiss()
        tp.switch_to([t for t in tabs if "ài đặt" in t.text or "etting" in t.text][0])
        Clock.schedule_once(open_dlg, 1.5)
    except Exception: fail(traceback.format_exc())
def open_dlg(dt):
    try:
        dismiss(); main = btns("Kết nối MT5 nhanh"); assert main, "thiếu nút"
        main[0].dispatch("on_release"); Clock.schedule_once(form, 0.8)
    except Exception: fail(traceback.format_exc())
def form(dt):
    try:
        shot("1_form"); t = labels()
        log.append(("form_noi_dung_nhung", "KHÔNG cần cài Termux" in t))
        ins = inputs(); ins[0].text, ins[1].text, ins[2].text, ins[3].text = "5550123", PW, "Demo-1", ""
        bt("Bắt đầu").dispatch("on_release"); Clock.schedule_once(p1, 1.4)
    except Exception: fail(traceback.format_exc())
def p1(dt):
    try:
        shot("2_progress"); t = labels(); s = app.settings
        log.append(("dich_vu_duoc_bat", len(started) == 1 and "data_dir" in started[0]))
        log.append(("cai_dat", (s.get("exchange"), s.get("mt5ea_login"), s.get("mt5ea_lean"), s.get("mt5ea_supervised"))))
        log.append(("co_nut", all(has_bt(x) for x in ("Dừng", "Khởi động lại", "Sao chép chẩn đoán", "Xoá MT5 nhúng", "Dọn bản MT5 không dùng", "Nhập lại thông tin"))))
        log.append(("khong_co_buoc_termux", not has_bt("Cài Termux") and not has_bt("Sao chép lệnh") and "Termux" not in t.split("Không cần Termux")[0]))
        log.append(("tieu_de", "Đang bật dịch vụ MT5 nhúng" in t or "Đang cài" in t))
        sup_exchange(srv().port, s["mt5ea_token"], "SEVT|kind=install|stage=precheck|state=ok|detail=x", "SEVT|kind=install|stage=proot|state=ok|detail=x", "SEVT|kind=install|stage=rootfs|state=progress|detail=đang giải nén")
        Clock.schedule_once(p2, 1.6)
    except Exception: fail(traceback.format_exc())
def p2(dt):
    try:
        t = labels(); shot("3_installing")
        log.append(("tien_trinh_hien", "✓ Kiểm tra máy" in t and "✓ Tải proot" in t and "▶ Tải và giải nén Ubuntu" in t and "Đang cài" in t))
        log.append(("khong_co_dong_termux", "Cài công cụ nền cho Termux" not in t))
        lo = embedded.Layout(app.data_dir); os.makedirs(lo.root, exist_ok=True)
        open(lo.state, "w").write(json.dumps({"phase": "failed", "failed_stage": "proot", "error": "proot không chạy được trên máy này", "t": time.time()}))
        Clock.schedule_once(p3, 1.6)
    except Exception: fail(traceback.format_exc())
def p3(dt):
    try:
        t = labels(); shot("4_failed")
        log.append(("loi_tu_state", "LỖI ở bước" in t and "proot không chạy được" in t and "Khởi động lại" in t))
        bt("Khởi động lại").dispatch("on_release")
        log.append(("khoi_dong_lai_bat_dich_vu", len(started) == 2))
        lo = embedded.Layout(app.data_dir)
        open(lo.state, "w").write(json.dumps({"phase": "running", "t": time.time()}))
        sup_exchange(srv().port, app.settings["mt5ea_token"], "SEVT|kind=res|cpu=22.5|rss=380|procs=11|top=terminal64.exe:20%25/250MB")
        ea.append(FakeEA(srv().port, token=app.settings["mt5ea_token"]).start())
        Clock.schedule_once(p4, 3.2)
    except Exception: fail(traceback.format_exc())
def p4(dt):
    try:
        t = labels(); shot("5_connected")
        log.append(("da_noi_kem_cpu_ram", "ĐÃ NỐI" in t and "CPU 22%" in t.replace("23%", "22%") and "RAM 380 MB" in t))
        btn = bt("Xoá MT5 nhúng"); btn.dispatch("on_release")
        log.append(("xoa_can_bam_hai_lan", "Bấm lại" in bt("Bấm lại").text))
        blob = json.dumps(app.settings, ensure_ascii=False)
        for base in {os.environ["PYEA_DATA_DIR"], app.data_dir}:
            for root, _, fs in os.walk(base):
                for f in fs:
                    try: blob += open(os.path.join(root, f), errors="ignore").read()
                    except Exception: pass
        blob += " ".join(started)
        log.append(("mat_khau_lot_ra_dia_hoac_tham_so", PW in blob))
        log.append(("app_quen_mat_khau_sau_khi_noi", srv().first_login_password() is None))
        # «Dọn bản MT5 không dùng»: dựng 2 bản (111 đang dùng, 222 không dùng) trong hệ khách giả
        lo = embedded.Layout(app.data_dir); home = os.path.join(lo.host_root, ".wine-mt5", "drive_c", "pyea-mt5")
        for k in ("111", "222"):
            os.makedirs(os.path.join(home, k)); open(os.path.join(home, k, "terminal64.exe"), "wb").write(b"x" * 2048)
        os.symlink("/root/.wine-mt5/drive_c/pyea-mt5/111", os.path.join(lo.host_root, "mt5"))
        bt("Dọn bản MT5 không dùng").dispatch("on_release"); Clock.schedule_once(pr1, 1.0)
    except Exception: fail(traceback.format_exc())
def pr1(dt):
    try:
        lo = embedded.Layout(app.data_dir); home = os.path.join(lo.host_root, ".wine-mt5", "drive_c", "pyea-mt5")
        log.append(("don_lan1_chua_xoa_gi_va_hoi_lai", os.path.isdir(os.path.join(home, "222")) and has_bt("Xoá 1 bản") and has_bt("Bấm lại")))
        bt("Xoá 1 bản").dispatch("on_release"); Clock.schedule_once(pr2, 1.0)
    except Exception: fail(traceback.format_exc())
def pr2(dt):
    try:
        lo = embedded.Layout(app.data_dir); home = os.path.join(lo.host_root, ".wine-mt5", "drive_c", "pyea-mt5")
        log.append(("don_lan2_xoa_ban_khong_dung_giu_ban_dang_dung", not os.path.exists(os.path.join(home, "222")) and os.path.exists(os.path.join(home, "111", "terminal64.exe"))))
        log.append(("nut_tro_lai_ten_cu", has_bt("Dọn bản MT5 không dùng")))
        bt("Dọn bản MT5 không dùng").dispatch("on_release"); Clock.schedule_once(pr3, 1.0)
    except Exception: fail(traceback.format_exc())
def pr3(dt):
    try:
        log.append(("don_khi_het_ban_khong_dung_khong_hoi_xoa", has_bt("Dọn bản MT5 không dùng") and not has_bt("Xoá 1 bản")))   # (nút «Xoá MT5 nhúng» đang ở trạng thái «Bấm lại» từ bước trước nên không dùng chữ đó để kiểm)
        pop().dismiss(); Clock.schedule_once(reopen, 0.6)
    except Exception: fail(traceback.format_exc())
def reopen(dt):
    try:
        btns("Kết nối MT5 nhanh")[0].dispatch("on_release"); Clock.schedule_once(after, 1.2)
    except Exception: fail(traceback.format_exc())
def after(dt):
    try:
        shot("6_reopen")
        log.append(("mo_lai_vao_thang_tien_trinh_nhung", has_bt("Dừng") and not [w for w in walk(pop()) if isinstance(w, TextInput) and w.password]))
    except Exception: errs.append(traceback.format_exc())
    for e in ea: e.close()
    for s in list(mt5ea._SERVERS.values()): s.close()
    app.stop()
Clock.schedule_once(run, 3)
try: app.run()
except Exception: errs.append(traceback.format_exc())
for l in log: print("LOG", l)
print("ERRS", len(errs)); [print(e) for e in errs]
