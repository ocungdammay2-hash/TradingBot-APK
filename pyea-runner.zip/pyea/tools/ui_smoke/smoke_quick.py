"""Chạy Kivy THẬT (xvfb): mở tab Cài đặt -> bấm «Kết nối MT5 nhanh» -> điền -> Kết nối với API cấp phát GIẢ -> kiểm cài đặt đã lưu + mật khẩu không lọt."""
import json, os, sys, time, traceback
os.environ.setdefault("KIVY_NO_ARGS", "1")
S = os.environ["PYEA_SCRATCH"]
os.environ["KIVY_HOME"] = os.path.join(S, "kivyhome_q")
os.environ["PYEA_DATA_DIR"] = os.path.join(S, "data_q")
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, os.path.join(sys.argv[1], "tests"))
from kivy.config import Config
Config.set("graphics", "width", "720"); Config.set("graphics", "height", "1440")
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
import pyea.ui as U
from pyea import mt5quick
from fake_prov import FakeProvisioning
fp = FakeProvisioning(detect_polls=1, connect_after=2)
_orig = mt5quick.connect
def patched(*a, **k):
    k.update(prov_url=fp.base, verify=False, timeout=30.0)
    return _orig(*a, **k)
mt5quick.connect = patched
out = os.path.join(S, "shots_q"); os.makedirs(out, exist_ok=True)
app = U.PyEAApp(); errs = []; log = []
def walk(w):
    yield w
    for c in w.children: yield from walk(c)
def btns(text):
    return [x for x in walk(Window) if isinstance(x, Button) and text in (x.text or "")]
def shot(n): Window.screenshot(name=os.path.join(out, n + ".png"))
def dismiss():
    for t in ("ồng ý", "Bỏ qua"):
        for b in btns(t): b.dispatch("on_release")
def popup_inputs():
    from pyea.ui_widgets import StyledPopup
    pops = [x for x in walk(Window) if isinstance(x, StyledPopup) and "nhanh" in (x.title or "")]
    return pops[0] if pops else None, (list(reversed([w for w in walk(pops[0]) if isinstance(w, TextInput)])) if pops else [])   # children của Kivy xếp NGƯỢC thứ tự thêm
def go_btn():
    pop, _ = popup_inputs()
    return [b for b in walk(pop) if isinstance(b, Button) and (b.text or "").strip() == "Kết nối"][0]
def texts():
    return " | ".join((x.text or "").replace("\n", " ")[:200] for x in walk(Window) if isinstance(x, Label) and x.text)
def run(dt):
    try:
        tp = next(w for w in walk(app.root) if w.__class__.__name__ == "TabbedPanel")
        tabs = list(reversed(tp.tab_list)); print("TABS", [t.text for t in tabs], flush=True)
        dismiss(); dismiss()
        st = [t for t in tabs if "ài đặt" in t.text or "etting" in t.text][0]
        tp.switch_to(st)
        Clock.schedule_once(open_dlg, 1.5)
    except Exception: errs.append(traceback.format_exc()); app.stop()
def open_dlg(dt):
    try:
        dismiss()
        b = btns("MT5 nhanh"); print("NÚT", len(b), [x.text for x in btns("MT5")][:8], [x.text for x in btns("Lưu")][:3], flush=True); assert b, "không thấy nút"
        shot("1_settings_top"); b[0].dispatch("on_release")
        Clock.schedule_once(fill_bad, 0.8)
    except Exception: errs.append(traceback.format_exc()); app.stop()
def fill_bad(dt):
    try:
        pop, ins = popup_inputs(); assert pop and len(ins) == 4, (pop, len(ins))
        shot("2_dialog_empty")
        # 1) bấm Kết nối khi trống -> báo lỗi nhập liệu, KHÔNG gọi mạng
        go_btn().dispatch("on_release")
        n0 = len(fp.requests); log.append(("empty_requests", n0))
        Clock.schedule_once(wrong_pw, 0.5)
    except Exception: errs.append(traceback.format_exc()); app.stop()
def wrong_pw(dt):
    try:
        pop, ins = popup_inputs(); log.append(("status_empty", [x.text for x in walk(popup_inputs()[0]) if isinstance(x, Label) and x.text and "Login MT5" in x.text][:1]))
        shot("3_dialog_validation")
        ins[0].text, ins[1].text, ins[2].text, ins[3].text = fp.GOOD["login"], "SAI-MAT-KHAU", fp.GOOD["server"], fp.TOKEN
        go_btn().dispatch("on_release")
        Clock.schedule_once(after_wrong, 3.0)
    except Exception: errs.append(traceback.format_exc()); app.stop()
def after_wrong(dt):
    try:
        pop, ins = popup_inputs(); log.append(("dialog_still_open_after_wrong", pop is not None)); log.append(("pw_cleared", ins[1].text == ""))
        log.append(("status_wrong", any("sai login" in (x.text or "") for x in walk(popup_inputs()[0]) if isinstance(x, Label)))); log.append(("status_text", [x.text for x in walk(popup_inputs()[0]) if isinstance(x, Label) and x.text and "Broker" in x.text][:1]))
        shot("4_wrong_password")
        ins[1].text = fp.GOOD["password"]
        go_btn().dispatch("on_release")
        Clock.schedule_once(check, 0.3)
        Clock.schedule_once(final, 12.0)
    except Exception: errs.append(traceback.format_exc()); app.stop()
def check(dt):
    try: shot("5_progress")
    except Exception: errs.append(traceback.format_exc())
def final(dt):
    try:
        shot("6_result")
        log.append(("result_popup", "ĐÃ NỐI" in texts()))
        s = app.settings
        log.append(("settings", (s.get("exchange"), s.get("metaapi_account"), s.get("metaapi_region"), bool(s.get("metaapi_token")))))
        blob = json.dumps(s, ensure_ascii=False)
        for root, _, fs in os.walk(os.environ["PYEA_DATA_DIR"]):
            for f in fs:
                try: blob += open(os.path.join(root, f), errors="ignore").read()
                except Exception: pass
        log.append(("password_leak", fp.GOOD["password"] in blob))
        log.append(("accounts_on_fake", len(fp.accounts)))
        log.append(("creates", len([1 for m, p, _, _ in fp.requests if m == "POST" and p == "/users/current/accounts"])))
    except Exception: errs.append(traceback.format_exc())
    app.stop()
Clock.schedule_once(run, 3)
try: app.run()
except Exception: errs.append(traceback.format_exc())
for l in log: print("LOG", l)
print("ERRS", len(errs)); [print(e) for e in errs]
# Chạy: PYEA_SCRATCH=<thư mục tạm> xvfb-run -a python tools/ui_smoke/smoke_quick.py <thư mục dự án>   (cần kivy; ảnh chụp ở $PYEA_SCRATCH/shots_q)
