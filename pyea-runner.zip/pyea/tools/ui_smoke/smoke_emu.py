"""Chạy Kivy THẬT (xvfb): tab Cài đặt -> «Kết nối MT5 nhanh» (MT5 thật trong giả lập) -> nhập -> Bắt đầu -> trang lệnh dán + tiến trình.
Kiểm: nút đúng tên + nút MetaApi riêng; kiểm nhập liệu; cài đặt đã lưu (exchange=mt5ea, login, server, token); MẬT KHẨU KHÔNG lọt vào cài đặt/ổ đĩa;
lệnh dán có token + cổng; tiến trình trong app đổi theo sự kiện script báo về; «ĐÃ NỐI» khi EA nối với tài khoản.
Chạy: PYEA_SCRATCH=<thư mục tạm> xvfb-run -a python tools/ui_smoke/smoke_emu.py <thư mục dự án>   (cần kivy; ảnh ở $PYEA_SCRATCH/shots_e)"""
import json, os, sys, time, traceback
os.environ.setdefault("KIVY_NO_ARGS", "1")
S = os.environ["PYEA_SCRATCH"]
os.environ["KIVY_HOME"] = os.path.join(S, "kivyhome_e_%d" % os.getpid())
os.environ["PYEA_DATA_DIR"] = os.path.join(S, "data_e")          # (app thật lưu ở ~/.config/pyea; cần đã qua màn hình điều khoản lần đầu như smoke_quick)
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, os.path.join(sys.argv[1], "tests"))
from kivy.config import Config
Config.set("graphics", "width", "720"); Config.set("graphics", "height", "1440")
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
import pyea.ui as U
from pyea import mt5ea
from fake_ea import FakeEA
from test_mt5emu import sup_exchange
PW = "Sm0ke#Test-PW-777"
out = os.path.join(S, "shots_e"); os.makedirs(out, exist_ok=True)
app = U.PyEAApp(); errs = []; log = []; ea = []
def walk(w):
    yield w
    for c in w.children: yield from walk(c)
def btns(text): return [x for x in walk(Window) if isinstance(x, Button) and text in (x.text or "")]
def shot(n): Window.screenshot(name=os.path.join(out, n + ".png"))
def dismiss():
    for t in ("ồng ý", "Bỏ qua"):
        for b in btns(t): b.dispatch("on_release")
def pop():
    from pyea.ui_widgets import StyledPopup
    p = [x for x in walk(Window) if isinstance(x, StyledPopup) and "Kết nối MT5 nhanh" in (x.title or "")]
    return p[0] if p else None
def inputs(): return list(reversed([w for w in walk(pop()) if isinstance(w, TextInput)]))      # children của Kivy xếp NGƯỢC thứ tự thêm
def labels(): return " | ".join((x.text or "").replace("\n", " ")[:2000] for x in walk(pop()) if isinstance(x, Label) and x.text)
def bt(text): return [b for b in walk(pop()) if isinstance(b, Button) and text in (b.text or "")][0]
def fail(e): errs.append(e); app.stop()
def run(dt):
    try:
        tp = next(w for w in walk(app.root) if w.__class__.__name__ == "TabbedPanel")
        tabs = list(reversed(tp.tab_list)); dismiss(); dismiss()
        tp.switch_to([t for t in tabs if "ài đặt" in t.text or "etting" in t.text][0])
        Clock.schedule_once(open_dlg, 1.5)
    except Exception: fail(traceback.format_exc())
def open_dlg(dt):
    try:
        dismiss()
        main = btns("Kết nối MT5 nhanh"); cloud = btns("MetaApi")
        log.append(("nut_nhanh", len(main), [b.text for b in main][:1])); log.append(("nut_metaapi_rieng", len(cloud), [b.text for b in cloud][:1]))
        assert main and cloud and main[0] is not cloud[0], "thiếu nút"
        assert "MetaApi" not in main[0].text, "nút «nhanh» không được là MetaApi"
        shot("1_settings"); main[0].dispatch("on_release")
        Clock.schedule_once(bad_input, 0.8)
    except Exception: fail(traceback.format_exc())
def bad_input(dt):
    try:
        assert pop() is not None and len(inputs()) == 4, (pop(), len(inputs()))
        app.settings["exchange"] = "simulated"                              # đặt lại để kiểm «bấm Bắt đầu mới đổi nguồn»
        shot("2_form"); bt("Bắt đầu").dispatch("on_release")
        log.append(("loi_nhap_lieu", "Login MT5" in labels()))
        log.append(("chua_doi_nguon", app.settings.get("exchange") != "mt5ea"))
        ins = inputs(); ins[0].text, ins[1].text, ins[2].text, ins[3].text = "5550123", PW, "Demo-1", ""
        log.append(("o_mat_khau_che", ins[1].password is True))
        bt("Bắt đầu").dispatch("on_release")
        Clock.schedule_once(progress1, 1.2)
    except Exception: fail(traceback.format_exc())
def progress1(dt):
    try:
        shot("3_progress")
        s = app.settings
        log.append(("settings", (s.get("exchange"), s.get("mt5ea_login"), s.get("mt5ea_server"), s.get("mt5ea_supervised"), bool(s.get("mt5ea_token")))))
        cmdbox = [w for w in walk(pop()) if isinstance(w, TextInput) and "/dev/tcp" in (w.text or "")]
        log.append(("lenh_dan", bool(cmdbox) and s.get("mt5ea_token", "?") in cmdbox[0].text and str(s.get("mt5ea_port")) in cmdbox[0].text))
        log.append(("lenh_khong_chua_mat_khau", bool(cmdbox) and PW not in cmdbox[0].text))
        log.append(("tieu_de_cho", "Chưa thấy Termux" in labels()))
        srv = [v for v in mt5ea._SERVERS.values()][0]
        sup_exchange(srv.port, s["mt5ea_token"], "SEVT|kind=install|stage=precheck|state=ok|detail=x", "SEVT|kind=install|stage=wine|state=progress|detail=đang tải")
        Clock.schedule_once(progress2, 1.6)
    except Exception: fail(traceback.format_exc())
def progress2(dt):
    try:
        t = labels(); shot("4_running")
        log.append(("tien_trinh_hien", "✓ Kiểm tra máy" in t and "▶ Tải Wine" in t and "Đang cài" in t))
        srv = [v for v in mt5ea._SERVERS.values()][0]
        sup_exchange(srv.port, app.settings["mt5ea_token"], "SEVT|kind=install|stage=wine|state=fail|detail=GitHub bị chặn")
        Clock.schedule_once(progress3, 1.6)
    except Exception: fail(traceback.format_exc())
def progress3(dt):
    try:
        t = labels(); shot("5_failed")
        log.append(("loi_hien", "LỖI ở bước" in t and "GitHub bị chặn" in t))
        srv = [v for v in mt5ea._SERVERS.values()][0]
        ea.append(FakeEA(srv.port, token=app.settings["mt5ea_token"]).start())
        Clock.schedule_once(final, 3.0)
    except Exception: fail(traceback.format_exc())
def final(dt):
    try:
        shot("6_connected")
        log.append(("da_noi", "ĐÃ NỐI" in labels()))
        blob = json.dumps(app.settings, ensure_ascii=False)
        for root, _, fs in os.walk(os.environ["PYEA_DATA_DIR"]):
            for f in fs:
                try: blob += open(os.path.join(root, f), errors="ignore").read()
                except Exception: pass
        log.append(("mat_khau_lot_vao_dia_hoac_cai_dat", PW in blob))
        srv = [v for v in mt5ea._SERVERS.values()][0]
        log.append(("app_quen_mat_khau", srv.first_login_password() is None))
        # mở lại hộp thoại: phải vào thẳng trang tiến trình (đã có phiên), không bắt nhập lại
        pop().dismiss(); Clock.schedule_once(reopen, 0.6)
    except Exception: fail(traceback.format_exc())
def reopen(dt):
    try:
        btns("Kết nối MT5 nhanh")[0].dispatch("on_release"); Clock.schedule_once(after_reopen, 0.8)
    except Exception: fail(traceback.format_exc())
def after_reopen(dt):
    try:
        shot("7_reopen"); log.append(("mo_lai_vao_thang_tien_trinh", "ĐÃ NỐI" in labels() and not [w for w in walk(pop()) if isinstance(w, TextInput) and w.password]))
    except Exception: errs.append(traceback.format_exc())
    for e in ea: e.close()
    for s in list(mt5ea._SERVERS.values()): s.close()
    app.stop()
Clock.schedule_once(run, 3)
try: app.run()
except Exception: errs.append(traceback.format_exc())
for l in log: print("LOG", l)
print("ERRS", len(errs)); [print(e) for e in errs]
