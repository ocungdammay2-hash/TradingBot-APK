#!/usr/bin/env python3
"""Đo phần PYTHON của cầu nối EA (máy chủ cục bộ + backend) bằng EA giả qua loopback: thông lượng tick, độ trễ gọi, CPU/RAM.
KHÔNG đo Box64/Wine/MT5 (cần phần cứng ARM64 - dùng tools/mt5_phone/measure.sh). Chạy từ thư mục gốc dự án:  python3 -I tools/bench_bridge.py  (xem --help)
Số đo phụ thuộc máy chạy; in kèm thông tin CPU để người đọc biết ngữ cảnh. In JSON một dòng cuối cùng nếu có --json."""
import argparse
import json
import os
import platform
import resource
import statistics
import sys
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from pyea import mt5ea                      # noqa: E402
from pyea.mt5ea import enc                  # noqa: E402
from tests.fake_ea import FakeEA            # noqa: E402


def rss_mb():
    with open("/proc/self/status") as f:
        for ln in f:
            if ln.startswith("VmRSS"):
                return int(ln.split()[1]) / 1024.0
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0


def cpu_model():
    try:
        with open("/proc/cpuinfo") as f:
            for ln in f:
                if ln.startswith("model name") or ln.startswith("Hardware"):
                    return ln.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticks", type=int, default=100000, help="số tick đẩy hết tốc lực")
    ap.add_argument("--calls", type=int, default=1000, help="số lần gọi REQ->RES để đo độ trễ")
    ap.add_argument("--idle", type=float, default=10.0, help="giây đo CPU khi rảnh (có nhịp HB/PING)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    tok = "bench-token-1"
    srv = mt5ea.Mt5EaServer(0, tok)
    srv.start()
    ea = FakeEA(srv.port, tok).start()
    end = time.time() + 5
    while not srv.alive() and time.time() < end:
        time.sleep(0.02)
    assert srv.alive(), "EA giả không nối được"
    back = mt5ea.Mt5EaBackend(srv)
    out = {"cpu": cpu_model(), "cores": os.cpu_count(), "python": platform.python_version(), "rss_start_mb": round(rss_mb(), 1)}

    # 1) rảnh
    c0, w0 = time.process_time(), time.time()
    time.sleep(a.idle)
    c1, w1 = time.process_time(), time.time()
    out["idle_cpu_pct"] = round(100.0 * (c1 - c0) / (w1 - w0), 3)

    # 2) độ trễ gọi (EA giả cùng tiến trình nên con số gồm cả thời gian EA giả xử lý -> CHẬN TRÊN cho phần Python của app, chưa tính MT5)
    lat = []
    for _ in range(a.calls):
        t = time.perf_counter()
        back.account()
        lat.append((time.perf_counter() - t) * 1000.0)
    lat.sort()
    out["call_ms"] = {"p50": round(statistics.median(lat), 3), "p95": round(lat[int(0.95 * len(lat))], 3), "p99": round(lat[int(0.99 * len(lat)) - 1], 3), "max": round(lat[-1], 3)}

    # 3) thông lượng tick: gửi N dòng TICK từ EA giả, đợi máy chủ xử lý hết (dòng cuối mang giá đặc biệt)
    line = enc("TICK", s="EURUSD", b=1.10001, a=1.10003, t=1700000000.123)
    out["bytes_per_tick"] = len(line)
    blob = line * 1000
    sentinel = enc("TICK", s="SENT", b=9.0, a=9.5, t=1.0)
    c0, w0 = time.process_time(), time.time()
    sent = 0
    while sent < a.ticks:
        ea.sock.sendall(blob)
        sent += 1000
    ea.sock.sendall(sentinel)
    end = time.time() + 120
    while "SENT" not in srv.ticks and time.time() < end:
        time.sleep(0.005)
    c1, w1 = time.process_time(), time.time()
    ok = "SENT" in srv.ticks
    out["tick_burst"] = {"ticks": sent, "ok": ok, "seconds": round(w1 - w0, 3), "ticks_per_s": round(sent / max(w1 - w0, 1e-9)),
                         "cpu_us_per_tick_total_process": round(1e6 * (c1 - c0) / sent, 2)}
    out["rss_end_mb"] = round(rss_mb(), 1)
    out["note"] = ("process_time gồm CẢ EA giả chạy cùng tiến trình (gửi + trả lời) nên phần của máy chủ app thật thấp hơn; đây là chặn trên của PHẦN PYTHON, "
                   "chưa gồm MT5/Box64/Wine và chưa phải số trên điện thoại.")
    ea.close()
    srv.close()
    if a.json:
        print(json.dumps(out, ensure_ascii=False))
    else:
        for k, v in out.items():
            print("%-18s %s" % (k, v))


if __name__ == "__main__":
    main()
