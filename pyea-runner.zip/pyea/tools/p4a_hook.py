"""Hook python-for-android (buildozer: p4a.hook): chèn <receiver> khởi động-máy vào AndroidManifest của bản build.

buildozer không có tuỳ chọn nào chèn <receiver> vào <application>, nên vá mẫu manifest ngay trước khi p4a dựng APK.
Idempotent. Nếu không tìm thấy mẫu thì báo lỗi rõ ràng (CI cũng kiểm tra lại manifest cuối cùng)."""
import glob
import os

MARKER = "org.pyea.pyearunner.BootReceiver"
RECEIVER = (
    '    <receiver android:name="org.pyea.pyearunner.BootReceiver" android:enabled="true" android:exported="true" android:directBootAware="true">\n'
    '      <intent-filter>\n'
    '        <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED"/>\n'
    '        <action android:name="android.intent.action.BOOT_COMPLETED"/>\n'
    '        <action android:name="android.intent.action.QUICKBOOT_POWERON"/>\n'
    '        <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>\n'
    '      </intent-filter>\n'
    '    </receiver>\n'
)


def patch_manifest_text(text):
    """Trả về (văn bản mới, đã_đổi). Không đổi nếu đã có receiver."""
    if MARKER in text:
        return text, False
    i = text.rfind("</application>")
    if i < 0:
        raise ValueError("không thấy </application> trong mẫu manifest")
    return text[:i] + RECEIVER + text[i:], True


def patch_file(path):
    with open(path, "r", encoding="utf-8") as f:
        t = f.read()
    new, changed = patch_manifest_text(t)
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new)
    return changed


def _candidates(toolchain):
    out = []
    for attr in ("_dist", "dist"):
        d = getattr(toolchain, attr, None)
        dd = getattr(d, "dist_dir", None)
        if dd:
            out.append(dd)
    ctx = getattr(toolchain, "ctx", None)
    for attr in ("dist_dir", "bootstrap_build_dir"):
        v = getattr(ctx, attr, None)
        if v:
            out.append(v)
    roots = [r for r in out if os.path.isdir(r)]
    files = []
    for r in roots:
        files += glob.glob(os.path.join(r, "**", "AndroidManifest.tmpl.xml"), recursive=True)
    if not files:                                               # dự phòng: quét thư mục build của buildozer
        base = os.path.join(os.getcwd(), ".buildozer", "android", "platform")
        files = glob.glob(os.path.join(base, "**", "dists", "**", "AndroidManifest.tmpl.xml"), recursive=True)
    return sorted(set(files))


def before_apk_build(toolchain):
    files = _candidates(toolchain)
    if not files:
        raise RuntimeError("p4a_hook: không tìm thấy AndroidManifest.tmpl.xml để chèn BootReceiver")
    for f in files:
        print("p4a_hook: %s BootReceiver -> %s" % ("chèn" if patch_file(f) else "đã có", f))
