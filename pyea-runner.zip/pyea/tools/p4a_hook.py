"""Hook python-for-android (buildozer: p4a.hook): (1) chèn <receiver> khởi động-máy vào AndroidManifest của bản build; (2) đặt targetSdkVersion.

(1) buildozer không có tuỳ chọn nào chèn <receiver> vào <application>, nên vá mẫu manifest ngay trước khi p4a dựng APK.
(2) targetSdkVersion (TÙY CHỌN, mặc định KHÔNG vá): biến môi trường PYEA_TARGET_SDK. Mặc định «api» = giữ targetSdk = android.api (36). Vì sao không còn hạ về 28:
    Google Play Protect CHẶN cài APK có targetSdk thấp hơn Android của máy quá 2 mức («được xây dựng cho phiên bản Android cũ»; xác nhận trên máy thật: APK targetSdk 28 không cài được).
    MT5 nhúng nay chạy proot từ thư viện gốc của APK (native_libs/, buildozer android.add_libs_arm64_v8a) nên chạy được ở mọi targetSdk. Đặt PYEA_TARGET_SDK=<số 23..40>
    chỉ để thử/dự phòng (vd 28 cho đường tải proot về thư mục dữ liệu - Play Protect sẽ chặn cài). Nếu đã đặt số mà không vá được thì BÁO LỖI (không im lặng build sai).
Idempotent. Nếu không tìm thấy mẫu thì báo lỗi rõ ràng (CI cũng kiểm tra lại manifest cuối cùng)."""
import glob
import os
import re

MARKER = "org.pyea.pyearunner.BootReceiver"
RECEIVER = (
    '    <receiver android:name="org.pyea.pyearunner.BootReceiver" android:enabled="true" android:exported="true" android:directBootAware="true">\n'
    '      <intent-filter>\n'
    '        <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED"/>\n'
    '        <action android:name="android.intent.action.BOOT_COMPLETED"/>\n'
    '        <action android:name="android.intent.action.QUICKBOOT_POWERON"/>\n'
    '        <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>\n'
    '      </intent-filter>\n'
    '    </receiver>\n'
)


def patch_manifest_text(text):
    """Trả về (văn bản mới, đã_đổi). Không đổi nếu đã có receiver."""
    if MARKER in text:
        return text, False
    i = text.rfind("</application>")
    if i < 0:
        raise ValueError("không thấy </application> trong mẫu manifest")
    return text[:i] + RECEIVER + text[i:], True


def patch_file(path):
    with open(path, "r", encoding="utf-8") as f:
        t = f.read()
    new, changed = patch_manifest_text(t)
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new)
    return changed


DEFAULT_TARGET_SDK = "api"
GRADLE_RE = re.compile(r"(targetSdkVersion\s+)\{\{\s*android_api\s*\}\}")
MANIFEST_RE = re.compile(r'(android:targetSdkVersion=")\{\{\s*android_api\s*\}\}(")')


def target_sdk():
    """Giá trị targetSdk cần đặt, hoặc None = giữ nguyên android.api."""
    v = os.environ.get("PYEA_TARGET_SDK", DEFAULT_TARGET_SDK).strip().lower()
    if v in ("", "api", "off", "keep", "none"):
        return None
    if not v.isdigit() or not (23 <= int(v) <= 40):
        raise ValueError("PYEA_TARGET_SDK phải là số 23..40 (hoặc «api» để giữ nguyên): %r" % v)
    return v


def patch_gradle_text(text, sdk):
    """(văn bản mới, đã_đổi). Không đổi nếu đã đặt rồi; lỗi nếu mẫu không có dòng targetSdkVersion {{ android_api }}."""
    new, n = GRADLE_RE.subn(lambda m: m.group(1) + sdk, text)
    if n == 0:
        if re.search(r"targetSdkVersion\s+%s\b" % re.escape(sdk), text):
            return text, False
        raise ValueError("không thấy «targetSdkVersion {{ android_api }}» trong build.tmpl.gradle")
    return new, True


def patch_manifest_target(text, sdk):
    new, n = MANIFEST_RE.subn(lambda m: m.group(1) + sdk + m.group(2), text)
    return new, n > 0


def patch_target_file(path, sdk, kind):
    with open(path, "r", encoding="utf-8") as f:
        t = f.read()
    new, changed = patch_gradle_text(t, sdk) if kind == "gradle" else patch_manifest_target(t, sdk)
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new)
    return changed


def _candidates(toolchain, pattern="AndroidManifest.tmpl.xml"):
    out = []
    for attr in ("_dist", "dist"):
        d = getattr(toolchain, attr, None)
        dd = getattr(d, "dist_dir", None)
        if dd:
            out.append(dd)
    ctx = getattr(toolchain, "ctx", None)
    for attr in ("dist_dir", "bootstrap_build_dir"):
        v = getattr(ctx, attr, None)
        if v:
            out.append(v)
    roots = [r for r in out if os.path.isdir(r)]
    files = []
    for r in roots:
        files += glob.glob(os.path.join(r, "**", pattern), recursive=True)
    if not files:                                               # dự phòng: quét thư mục build của buildozer
        base = os.path.join(os.getcwd(), ".buildozer", "android", "platform")
        files = glob.glob(os.path.join(base, "**", "dists", "**", pattern), recursive=True)
    return sorted(set(files))


def before_apk_build(toolchain):
    files = _candidates(toolchain)
    if not files:
        raise RuntimeError("p4a_hook: không tìm thấy AndroidManifest.tmpl.xml để chèn BootReceiver")
    for f in files:
        print("p4a_hook: %s BootReceiver -> %s" % ("chèn" if patch_file(f) else "đã có", f))
    sdk = target_sdk()
    if sdk is None:
        print("p4a_hook: giữ targetSdkVersion = android.api (mặc định); MT5 nhúng chạy proot từ thư viện gốc của APK")
        return
    gradles = _candidates(toolchain, "build.tmpl.gradle")
    if not gradles:
        raise RuntimeError("p4a_hook: không tìm thấy build.tmpl.gradle để đặt targetSdkVersion=%s" % sdk)
    for g in gradles:
        print("p4a_hook: targetSdkVersion=%s %s -> %s" % (sdk, "đặt" if patch_target_file(g, sdk, "gradle") else "đã đặt", g))
    for m in files:                                             # uses-sdk trong manifest (Gradle ghi đè, nhưng giữ cho khớp)
        patch_target_file(m, sdk, "manifest")
