#!/usr/bin/env python3
"""Công cụ của CHỦ DỰ ÁN (không nằm trong APK): tạo cặp khoá và cấp khoá kích hoạt PyEA Runner.

  python3 tools/license_keygen.py new-keypair private.key        # in khoá công khai -> dán vào PUBLIC_KEY trong pyea/license.py
  python3 tools/license_keygen.py issue private.key --iid ABC123DEF456 --days 365 --plan full --note "ten nguoi dung"
  python3 tools/license_keygen.py issue private.key --iid "*" --days 0          # khoá chung, vĩnh viễn (days 0 = vĩnh viễn)
GIỮ BÍ MẬT file private.key; không commit lên GitHub. Mất khoá riêng = không cấp được khoá mới (phải phát hành bản app với khoá công khai mới).
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import ed25519, license as lic                      # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    n = sub.add_parser("new-keypair")
    n.add_argument("out")
    i = sub.add_parser("issue")
    i.add_argument("private")
    i.add_argument("--iid", default="*")
    i.add_argument("--days", type=int, default=365)
    i.add_argument("--plan", default="full")
    i.add_argument("--note", default="")
    a = ap.parse_args(argv)
    if a.cmd == "new-keypair":
        seed = os.urandom(32)
        with open(a.out, "w") as f:
            f.write(ed25519.b64u(seed) + "\n")
        try:
            os.chmod(a.out, 0o600)
        except OSError:
            pass
        print("Khoá công khai (dán vào PUBLIC_KEY):", ed25519.b64u(ed25519.public_key(seed)))
        return 0
    seed = ed25519.load_private_seed(open(a.private).read())
    exp = 0 if a.days <= 0 else int(time.time() + a.days * 86400)
    print(lic.make_key(seed, exp, a.iid, a.plan, a.note))
    return 0


if __name__ == "__main__":
    sys.exit(main())
