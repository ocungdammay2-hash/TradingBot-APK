"""Recipe python-for-android «rỗng» chỉ để VÁ một lỗi của p4a 2026.5.x (HANDOFF 5bl). Không biên dịch, không thêm gì vào APK.

LỖI: p4a cài module Python thuần cho TỪNG kiến trúc (arm64-v8a rồi armeabi-v7a) nhưng dùng CHUNG một venv (<storage>/build/venv).
Mỗi lần nó chạy `python -m venv venv` (ensurepip đã vá của hostpython 3.14.2 cài pip 25.3 đóng gói sẵn, KHÔNG nhìn thấy pip đã có
trong venv) rồi `pip install -U pip`. Lần 2 (hoặc venv cũ khôi phục từ cache), pip 25.3 bị chép ĐÈ lên pip 26.x đã nâng cấp
=> pip "lai" phiên bản: `ImportError: cannot import name 'capture_logging' from 'pip._internal.utils.logging'`.
VÁ: trước mỗi lần chạy run_pymodules_install, xoá venv cũ để lần nào cũng bắt đầu từ venv mới tinh.
Chỉ xoá <storage>/build/venv (công cụ tạm). Module đã cài nằm ở thư mục riêng từng kiến trúc nên không bị ảnh hưởng.
Bật bằng: buildozer.spec -> p4a.local_recipes = tools/p4a_recipes và thêm `pyeapipfix` vào requirements."""
import os
import shutil

from pythonforandroid.recipe import Recipe

_FLAG = "_pyea_fresh_venv"


def make_wrapper(orig):
    def run_pymodules_install(ctx, arch, *args, **kwargs):
        venv = os.path.join(ctx.build_dir, "venv")
        try:
            if os.path.lexists(venv):
                shutil.rmtree(venv, ignore_errors=True)
        except Exception:                                   # không bao giờ để việc dọn dẹp làm hỏng build
            pass
        return orig(ctx, arch, *args, **kwargs)

    setattr(run_pymodules_install, _FLAG, True)
    run_pymodules_install.__wrapped__ = orig
    return run_pymodules_install


def apply_patch():
    """Gắn bản vá vào pythonforandroid.build. Idempotent. Trả về True nếu vừa gắn."""
    try:
        from pythonforandroid import build
    except Exception:
        return False
    fn = getattr(build, "run_pymodules_install", None)
    if fn is None or getattr(fn, _FLAG, False):
        return False
    build.run_pymodules_install = make_wrapper(fn)
    return True


apply_patch()


class PyeaPipFixRecipe(Recipe):
    name = "pyeapipfix"
    version = "1"
    url = None
    depends = []

    def prebuild_arch(self, arch):
        apply_patch()
        return super().prebuild_arch(arch)


recipe = PyeaPipFixRecipe()
