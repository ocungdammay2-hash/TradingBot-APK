#!/usr/bin/env bash
# PyEA - CÀI TỰ ĐỘNG MT5 THẬT chạy trong giả lập trên điện thoại (Termux + proot Debian + Box64 + Wine + MT5 + EA cầu nối PyEABridge).
# Người dùng chỉ nhập login/mật khẩu/server trong app, dán MỘT lệnh vào Termux; mọi bước còn lại do script này làm và báo tiến trình về app.
# CHƯA KIỂM TRÊN ĐIỆN THOẠI THẬT (sandbox x86, chặn mạng ra ngoài). Phần LOGIC (các bước, chạy lại làm tiếp, báo lỗi về app, cấp file, xoá mật khẩu)
# đã test bằng lệnh giả: tests/test_mt5_install.py. Phần Box64/Wine/MT5 chạy thật hay không CHỈ biết khi chạy trên máy thật.
#
# Dùng (trong Termux, bản F-Droid/GitHub - KHÔNG dùng bản Google Play đã cũ):   PYEA_TOKEN=... bash install_mt5_termux.sh
#   (app tạo sẵn lệnh dán 1 lần: nó tự lấy script này từ app qua cổng cục bộ 127.0.0.1 rồi chạy)
# Chạy lại cùng lệnh được: các bước đã xong tự bỏ qua (kiểm bằng trạng thái thật, không chỉ cờ), bước lỗi làm tiếp.
#   outer (mặc định) = phần chạy trong Termux: kiểm máy, gói Termux, tạo Debian, lấy file từ app, GỌI phần trong, tạo lệnh khởi động, bật MT5
#   inner            = phần chạy BÊN TRONG Debian (do outer gọi): thư viện, Box64, Wine, tiền tố Wine, cài MT5, chép + biên dịch EA
# Biến (đều tuỳ chọn):
#   PYEA_TOKEN / PYEA_TOKEN_FILE / PYEA_HOST / PYEA_PORT   kênh về app (token = «mt5ea_token»)
#   PYEA_REDO=wine,mt5 (hoặc all)   ép làm lại các bước đó dù đã có
#   WINE_VER (mặc định 9.7) / WINE_URL      bản Wine 64-bit của Kron4ek dùng với Box64
#   MT5_SETUP_URL   bộ cài MT5 (mặc định bản chung của MetaQuotes; sàn có bộ cài riêng thì đặt link của sàn)
#   BOX64_PKG       gói Box64 (mặc định box64-android)
#   MIN_FREE_KB     dung lượng trống tối thiểu (mặc định 3000000 ≈ 3 GB, ƯỚC LƯỢNG chưa đo)
#   HB_EVERY        giây giữa các lần báo «còn chạy» về app (mặc định 10)
set -u

MODE="${1:-outer}"
PYEA_HOST="${PYEA_HOST:-127.0.0.1}"; PYEA_PORT="${PYEA_PORT:-18765}"
if [ -z "${PYEA_TOKEN:-}" ] && [ -n "${PYEA_TOKEN_FILE:-}" ] && [ -r "$PYEA_TOKEN_FILE" ]; then PYEA_TOKEN="$(tr -d '\r\n' < "$PYEA_TOKEN_FILE")"; fi
PYEA_TOKEN="${PYEA_TOKEN:-}"

# >>> pyea-common (BẢN SAO y hệt trong run_mt5_termux.sh; tests/test_mt5_install.py kiểm hai bản giống nhau)
pesc() { local v="$1"; v=${v//%/%25}; v=${v//|/%7C}; v=${v//=/%3D}; v=${v//$'\r'/%0D}; v=${v//$'\n'/%0A}; printf '%s' "$v"; }
punesc() { local v="$1"; v=${v//%0A/$'\n'}; v=${v//%0D/$'\r'}; v=${v//%3D/=}; v=${v//%7C/|}; v=${v//%25/%}; printf '%s' "$v"; }
# sup_send "SEVT|kind=x|..." ...   (mỗi lần mở một kết nối ngắn; thất bại thì bỏ qua, không làm hỏng giám sát)
sup_send() {
  [ -n "$PYEA_TOKEN" ] || return 0
  ( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" || exit 1
    printf 'SUPHELLO|v=1|token=%s\n' "$PYEA_TOKEN" >&3
    for l in "$@"; do printf '%s\n' "$l" >&3; done
    sleep 0.2 ) 2>/dev/null
  return 0
}
sup_event() { local kind="$1"; shift; local m="SEVT|kind=$kind" kv; for kv in "$@"; do m="$m|${kv%%=*}=$(pesc "${kv#*=}")"; done; sup_send "$m"; }
sup_log() { sup_send "SLOG|lvl=$1|m=$(pesc "$2")"; }
# sup_get tên_file đích  -> 0 nếu lấy và ghi được
sup_get() {
  local name="$1" dest="$2" line b64 err
  [ -n "$PYEA_TOKEN" ] || { echo "thiếu PYEA_TOKEN"; return 2; }
  line=$( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" 2>/dev/null || exit 1
          printf 'SUPHELLO|v=1|token=%s\nGET|name=%s\n' "$PYEA_TOKEN" "$name" >&3
          while IFS= read -r -t 10 -u 3 l; do case "$l" in FILE\|*) printf '%s' "$l"; break;; esac; done ) || { echo "không nối được app ($PYEA_HOST:$PYEA_PORT)"; return 1; }
  [ -n "$line" ] || { echo "app không trả lời (sai token? app chưa bật nguồn mt5ea?)"; return 1; }
  err=""; b64=""
  case "$line" in *"|err="*) err="${line#*|err=}"; err="${err%%|*}";; esac
  case "$line" in *"|b64="*) b64="${line#*|b64=}"; b64="${b64%%|*}"; b64="$(punesc "$b64")";; esac
  [ -z "$err" ] || { echo "app từ chối: $(punesc "$err")"; return 1; }
  mkdir -p "$(dirname "$dest")" && printf '%s' "$b64" | base64 -d > "$dest.tmp" && mv "$dest.tmp" "$dest" || { echo "không ghi được $dest"; return 1; }
  return 0
}
# <<< pyea-common

# ---------------------------------------------------------------------------------------------- đường dẫn
DISTRO="${PYEA_DISTRO:-debian}"
PREFIX_DIR="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="${PYEA_ROOTFS:-$PREFIX_DIR/var/lib/proot-distro/installed-rootfs/$DISTRO}"
GUEST_ROOT="${PYEA_GUEST_ROOT:-/root}"             # thư mục root như Debian-bên-trong thấy
HOST_ROOT="${PYEA_HOST_ROOT:-$ROOTFS/root}"        # cùng thư mục đó nhìn từ Termux
if [ "$MODE" = inner ]; then BASE="$GUEST_ROOT"; else BASE="${PYEA_BASE:-$HOME}"; fi
STATE_DIR="$BASE/.pyea"; LOGF="${PYEA_INSTALL_LOG:-$STATE_DIR/install.log}"
HB_EVERY="${HB_EVERY:-10}"
WINE_VER="${WINE_VER:-9.7}"
WINE_FALLBACK_VERS="${WINE_FALLBACK_VERS-8.19 10.12}"   # bản Wine thử lần lượt khi bản chính lỗi vùng nhớ ảo (xem prefix_rebuild_fallback); đặt rỗng để tắt
WINE_WOW64_VER="${WINE_WOW64_VER:-9.19}"           # bản Wine «wow64» (chạy được file .exe 32-bit không cần thư viện 32-bit); chỉ tải khi bộ cài MT5 là 32-bit
WINE_DIR="$GUEST_ROOT/wine64"; WINEPREFIX_DIR="$GUEST_ROOT/.wine-mt5"; DL="$GUEST_ROOT/dl"; ENVF="$GUEST_ROOT/.pyea_env.sh"; MT5_LINK="$GUEST_ROOT/mt5"
PFX_OK="$STATE_DIR/prefix.ok"; DIAGF="$STATE_DIR/wine_diag.txt"; WB_OUT="$DL/wineboot.out"
MT5_URL_DEFAULT="https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe"
ERR=""; HB_WATCH=""

mkdir -p "$STATE_DIR" 2>/dev/null
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOGF" 2>/dev/null; }
say() { printf '%s\n' "$*"; log "$*"; }
redo() { case ",${PYEA_REDO:-}," in *",$1,"*|*",all,"*) return 0;; esac; return 1; }

die_stage() {   # id lý_do   - báo lỗi về app (kèm đuôi nhật ký) rồi thoát; chạy lại cùng lệnh sẽ làm tiếp từ bước này
  local id="$1" msg="$2" tl
  tl=$(tail -n 12 "$LOGF" 2>/dev/null | tr -d '\r' | tr '\n' ';' | cut -c1-700)
  say "✗ LỖI ở bước «$id»: $msg"
  say "  Chạy lại CÙNG lệnh để làm tiếp từ bước này. Nhật ký: $LOGF"
  [ -z "$tl" ] || say "  đuôi nhật ký: $tl"
  sup_event install stage="$id" state=fail detail="$msg | $tl"
  exit 1
}

# retry N lệnh...   (mạng di động hay đứt: thử lại, chờ lâu dần)
retry() { local n="$1" i=1; shift; while true; do "$@" && return 0; [ "$i" -ge "$n" ] && return 1; log "lệnh lỗi (lần $i/$n): $*"; sleep "$(awk -v i="$i" -v b="${RETRY_SLEEP:-4}" 'BEGIN{print i*b}')"; i=$(( i + 1 )); done; }

# hb id lệnh...   chạy lệnh (đầu ra vào nhật ký), cứ HB_EVERY giây báo «còn chạy» về app + in dấu chấm; trả mã thoát của lệnh.
# HB_WATCH=<file/thư mục> thì báo kèm dung lượng hiện có (để thấy tiến độ tải).
hb() {
  local id="$1" pid rc last now sz=""; shift
  "$@" >>"$LOGF" 2>&1 &
  pid=$!; last=$(date +%s)
  while kill -0 "$pid" 2>/dev/null; do
    sleep 0.2
    now=$(date +%s)
    if [ $(( now - last )) -ge "$HB_EVERY" ]; then
      last=$now; sz=""
      if [ -n "$HB_WATCH" ] && [ -e "$HB_WATCH" ]; then sz="$(du -sk "$HB_WATCH" 2>/dev/null | awk '{printf "%d MB", $1/1024}')"; fi
      printf '.'
      sup_event install stage="$id" state=progress detail="${sz:+đã có $sz, }vẫn đang chạy"
    fi
  done
  wait "$pid"; rc=$?
  HB_WATCH=""
  return $rc
}

# stage id nhãn hàm [hàm_kiểm_đã_xong]
stage() {
  local id="$1" label="$2" fn="$3" chk="${4:-}"
  if [ -n "$chk" ] && ! redo "$id" && "$chk" >/dev/null 2>&1; then
    say "✓ $label - đã có sẵn, bỏ qua"; sup_event install stage="$id" state=skip detail="$label"; return 0
  fi
  say "▶ $label ..."; sup_event install stage="$id" state=start detail="$label"
  ERR=""
  "$fn" || die_stage "$id" "${ERR:-không rõ lý do}"
  say "✓ $label"; sup_event install stage="$id" state=ok detail="$label"
  return 0
}

# ---------------------------------------------------------------------------------------------- OUTER (Termux)
st_precheck_do() {
  local arch free need="${MIN_FREE_KB:-3000000}"
  arch="${PYEA_ARCH:-$(uname -m)}"
  case "$arch" in
    aarch64|arm64) ;;
    *) ERR="CPU báo «$arch». Cần Termux bản 64-bit ARM (aarch64) trên điện thoại 64-bit; máy 32-bit/x86 không chạy được Box64. Tải Termux arm64-v8a ở F-Droid/GitHub."; return 1;;
  esac
  free=$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2{print $4}')
  if [ -n "$free" ] && [ "$free" -lt "$need" ] 2>/dev/null; then
    ERR="Còn trống $(( free / 1024 )) MB, cần tối thiểu khoảng $(( need / 1024 )) MB (ước lượng cho Debian + Wine + MT5). Dọn bớt rồi chạy lại."; return 1
  fi
  if [ -z "$PYEA_TOKEN" ]; then ERR="thiếu PYEA_TOKEN: hãy dùng đúng lệnh app tạo sẵn (nó đã kèm token)."; return 1; fi
  return 0
}
termux_pkgs_do() {
  pkg update -y && pkg install -y -o Dpkg::Options::=--force-confold proot-distro curl wget procps
}
st_termux_pkgs() {
  hb termux_pkgs retry 3 termux_pkgs_do || { ERR="pkg lỗi: kiểm tra Wi-Fi/4G. Nếu báo không tải được gói: chạy «termux-change-repo», chọn kho khác, rồi chạy lại lệnh."; return 1; }
}
chk_termux_pkgs() { command -v proot-distro && command -v curl && command -v wget; }
st_rootfs() {
  hb rootfs retry 2 proot-distro install "$DISTRO" || { ERR="proot-distro không cài được Debian (thiếu dung lượng/mạng?)."; return 1; }
  chk_rootfs || { ERR="proot-distro báo xong nhưng không thấy hệ Debian ở $ROOTFS."; return 1; }
}
chk_rootfs() { [ -d "$ROOTFS/root" ] && { [ -e "$ROOTFS/bin/bash" ] || [ -e "$ROOTFS/usr/bin/bash" ]; }; }
st_fetch() {
  local r
  mkdir -p "$HOST_ROOT/pyea" || { ERR="không tạo được $HOST_ROOT/pyea"; return 1; }
  for f in install_mt5_termux.sh run_mt5_termux.sh pyea_relay.py; do
    r=$(sup_get "$f" "$HOST_ROOT/pyea/$f") || { ERR="Không lấy được «$f» từ app: $r. App phải đang mở, đã bấm «Bắt đầu» trong «Kết nối MT5 nhanh»; đừng tắt app trong lúc cài."; return 1; }
  done
  ( umask 077; printf '%s' "$PYEA_TOKEN" > "$HOST_ROOT/pyea/token" ) || { ERR="không ghi được token"; return 1; }
  chmod 600 "$HOST_ROOT/pyea/token" 2>/dev/null
  return 0
}
run_inner() {
  local rc=0
  say "Bước tiếp theo chạy BÊN TRONG Debian (lâu nhất: tải Wine + MT5, có thể hàng chục phút; cứ để màn hình sáng, app báo tiến trình)."
  proot-distro login "$DISTRO" --shared-tmp -- env PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT" PYEA_GUEST_ROOT="$GUEST_ROOT" \
    PYEA_REDO="${PYEA_REDO:-}" HB_EVERY="$HB_EVERY" WINE_VER="$WINE_VER" WINE_URL="${WINE_URL:-}" MT5_SETUP_URL="${MT5_SETUP_URL:-}" BOX64_PKG="${BOX64_PKG:-}" \
    PYEA_INSTALL_LOG="$GUEST_ROOT/.pyea/install.log" \
    bash "$GUEST_ROOT/pyea/install_mt5_termux.sh" inner || rc=$?
  return $rc
}
st_launcher() {
  local home="$BASE" sh_bash="${PREFIX_DIR}/bin/bash"
  mkdir -p "$home/.pyea" "$home/.termux/boot" 2>/dev/null
  cat > "$home/pyea-start-mt5.sh" <<EOF
#!/usr/bin/env bash
# Khởi động / dừng MT5 trong giả lập + giám sát (do trình cài PyEA tạo). Dùng: bash ~/pyea-start-mt5.sh [start|stop|status]
PIDF="\$HOME/.pyea/run.pid"; OUT="\$HOME/.pyea/run.out"
mkdir -p "\$HOME/.pyea"
alive() { [ -f "\$PIDF" ] && kill -0 "\$(cat "\$PIDF" 2>/dev/null)" 2>/dev/null; }
case "\${1:-start}" in
  status) if alive; then echo "MT5: đang chạy (pid \$(cat "\$PIDF"))"; else echo "MT5: không chạy"; exit 1; fi ;;
  stop)
    alive && kill "\$(cat "\$PIDF")" 2>/dev/null
    proot-distro login $DISTRO -- bash -c 'pkill -TERM -f "run_mt5_[t]ermux.sh"; pkill -TERM -f "pyea_[r]elay.py"; sleep 2; pkill -KILL -f "[t]erminal64.exe"; pkill -KILL -x wineserver' >/dev/null 2>&1
    rm -f "\$PIDF"; echo "đã dừng MT5" ;;
  *)
    if alive; then echo "MT5 đã đang chạy (pid \$(cat "\$PIDF"))"; exit 0; fi
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    nohup proot-distro login $DISTRO --shared-tmp -- env PYEA_ENV="$GUEST_ROOT/.pyea_env.sh" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" run >> "\$OUT" 2>&1 &
    echo \$! > "\$PIDF"; disown 2>/dev/null
    echo "đã bật MT5 (nhật ký: \$OUT). Tiến trình đăng nhập hiện trong app PyEA." ;;
esac
EOF
  cat > "$home/.termux/boot/pyea-mt5.sh" <<EOF
#!$sh_bash
# Chỉ chạy khi đã cài và mở Termux:Boot ít nhất 1 lần. Bật MT5 sau khi khởi động lại điện thoại.
termux-wake-lock 2>/dev/null
bash "\$HOME/pyea-start-mt5.sh" start
EOF
  chmod +x "$home/pyea-start-mt5.sh" "$home/.termux/boot/pyea-mt5.sh" 2>/dev/null
  [ -x "$home/pyea-start-mt5.sh" ] || { ERR="không tạo được lệnh khởi động"; return 1; }
  return 0
}

# ---------------------------------------------------------------------------------------------- INNER (Debian)
write_env() {   # $1 = thư mục MT5 (có thể rỗng khi chưa cài)
  cat > "$ENVF" <<EOF
# do install_mt5_termux.sh tạo; run_mt5_termux.sh nạp file này
export WINE_DIR="$WINE_DIR"
export BOX64_PATH="$WINE_DIR/bin"
export BOX64_LD_LIBRARY_PATH="$WINE_DIR/lib:$WINE_DIR/lib64:$WINE_DIR/lib/wine/x86_64-unix"
export BOX64_LOG=0 BOX64_NOBANNER=1
export WINEPREFIX="$WINEPREFIX_DIR" WINEARCH=win64 WINEDEBUG=-all
export DISPLAY=:99
export PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT"
export PYEA_LOGIN_WATCH=1 PYEA_SYNC_CFG=1
export MT5_DIR="${1:-}"
EOF
  # shellcheck disable=SC1090
  . "$ENVF"
}
start_xvfb() {
  [ "${NO_XVFB:-}" = "1" ] && return 0
  pgrep -x Xvfb >/dev/null 2>&1 && return 0
  ( Xvfb "$DISPLAY" -screen 0 800x600x16 -nolisten tcp >/dev/null 2>&1 & )
  sleep 1
  return 0
}
ws_kill() { box64 "$WINE_DIR/bin/wineserver" -k >/dev/null 2>&1; return 0; }
find_terminal() { find "$WINEPREFIX_DIR/drive_c" -maxdepth 4 -iname terminal64.exe 2>/dev/null | head -1; }

apt_all() { apt-get update && apt-get install -y --no-install-recommends ca-certificates wget gnupg xz-utils xvfb xauth procps; }
APT_OPT="cabextract libx11-6 libxext6 libxrender1 libxcursor1 libxi6 libxrandr2 libxfixes3 libxcomposite1 libxinerama1 libxxf86vm1 libfreetype6 libfontconfig1 libgnutls30 libglib2.0-0 libdbus-1-3 libasound2 libasound2t64 libpulse0 libgl1 fonts-dejavu-core python3"
apt_opt() {   # gói tuỳ chọn: cài cả loạt; hỏng thì thử từng gói, gói không có (tên khác theo bản Debian) thì bỏ qua
  # shellcheck disable=SC2086
  apt-get install -y --no-install-recommends $APT_OPT && return 0
  local p; for p in $APT_OPT; do apt-get install -y --no-install-recommends "$p" || log "gói tuỳ chọn không cài được: $p"; done
  return 0
}
st_apt() {
  export DEBIAN_FRONTEND=noninteractive
  hb apt retry 3 apt_all || { ERR="apt không cài được gói nền (Xvfb, wget, gnupg...). Thường do mạng đứt hoặc hết dung lượng."; return 1; }
  hb apt apt_opt
  return 0
}
chk_apt() { command -v Xvfb && command -v wget && command -v gpg && command -v xz && command -v pgrep; }

box64_do() {
  wget -q -O /etc/apt/sources.list.d/box64.list "${BOX64_LIST_URL:-https://ryanfortner.github.io/box64-debs/box64.list}" || return 1
  wget -q -O "$DL/box64.gpg" "${BOX64_KEY_URL:-https://ryanfortner.github.io/box64-debs/KEY.gpg}" || return 1
  gpg --batch --yes --dearmor -o /etc/apt/trusted.gpg.d/box64-debs-archive-keyring.gpg "$DL/box64.gpg" || return 1
  apt-get update || return 1
  apt-get install -y "${BOX64_PKG:-box64-android}" || { [ -z "${BOX64_PKG:-}" ] && apt-get install -y box64; }
}
st_box64() {
  mkdir -p "$DL"
  hb box64 retry 2 box64_do || { ERR="Không cài được Box64 từ kho ryanfortner.github.io/box64-debs (kho tạm hỏng/mạng đứt?)."; return 1; }
  box64 --version >>"$LOGF" 2>&1 || { ERR="Box64 đã cài nhưng không chạy được («box64 --version» lỗi). CPU/Android của máy này có thể không hợp."; return 1; }
}
chk_box64() { command -v box64 && box64 --version 2>&1 | grep -qi box64; }

wine_variant() { cat "$WINE_DIR/.pyea_variant" 2>/dev/null || echo "amd64-$WINE_VER"; }
wine_wow64() { case "$(wine_variant)" in *wow64*) return 0;; esac; return 1; }

wine_get() {   # $1 = amd64 | amd64-wow64, $2 = phiên bản: tải + giải nén THAY bản cũ ở $WINE_DIR, ghi dấu bản vào $WINE_DIR/.pyea_variant
  local var="$1" ver="$2" tb url
  tb="$DL/wine-$ver-$var.tar.xz"
  url="https://github.com/Kron4ek/Wine-Builds/releases/download/$ver/wine-$ver-$var.tar.xz"
  [ "$var" = amd64 ] && [ -n "${WINE_URL:-}" ] && url="$WINE_URL"
  retry 3 wget -c -O "$tb" "$url" || return 1
  rm -rf "$WINE_DIR.new"; mkdir -p "$WINE_DIR.new"
  tar -xJf "$tb" -C "$WINE_DIR.new" --strip-components=1 || return 1
  [ -e "$WINE_DIR.new/bin/wine64" ] || { [ -e "$WINE_DIR.new/bin/wine" ] && ln -s wine "$WINE_DIR.new/bin/wine64"; }   # bản wow64 có thể chỉ có «wine»
  [ -e "$WINE_DIR.new/bin/wine64" ] || return 2
  echo "$var-$ver" > "$WINE_DIR.new/.pyea_variant"
  rm -rf "$WINE_DIR"; mv "$WINE_DIR.new" "$WINE_DIR"; rm -f "$tb"
}
wine_do() { wine_get amd64 "$WINE_VER"; }
st_wine() {
  local rc=0
  mkdir -p "$DL"; write_env ""
  HB_WATCH="$DL"; hb wine wine_do || rc=$?
  case "$rc" in
    0) ;;
    2) ERR="Giải nén Wine xong nhưng không thấy bin/wine64 (file tải về sai bản?)."; return 1;;
    *) ERR="Không tải/giải nén được Wine $WINE_VER (GitHub bị chặn/mạng đứt/hết dung lượng?)."; return 1;;
  esac
  box64 wine64 --version >>"$LOGF" 2>&1 || { ERR="Wine đã giải nén nhưng «box64 wine64 --version» lỗi: thiếu thư viện hoặc Box64 không chạy được Wine này. Xem nhật ký."; return 1; }
}
chk_wine() { [ -e "$WINE_DIR/bin/wine64" ] && write_env "${MT5_DIR:-}" && box64 wine64 --version; }

# pe_kind file -> x64 (PE32+ AMD64) | x86 (PE32, 32-bit) | arm64 | ? (không phải PE / không đọc được). Đọc IMAGE_FILE_HEADER.Machine bằng od.
pe_kind() {
  local f="$1" off sig m
  off=$(od -An -t u4 -j 60 -N 4 "$f" 2>/dev/null | tr -d ' \n')
  case "$off" in ''|*[!0-9]*) echo "?"; return 0;; esac
  sig=$(od -An -t x4 -j "$off" -N 4 "$f" 2>/dev/null | tr -d ' \n')
  [ "$sig" = "00004550" ] || { echo "?"; return 0; }
  m=$(od -An -t x2 -j $(( off + 4 )) -N 2 "$f" 2>/dev/null | tr -d ' \n')
  case "$m" in 8664) echo x64;; 014c) echo x86;; aa64) echo arm64;; *) echo "?($m)";; esac
}

# Tiền tố Wine phải có đủ file hệ thống VÀ chạy thử được một lệnh Windows thật. Trước đây chỉ kiểm có system.reg nên tiền tố làm dở
# (thiếu kernel32.dll -> «wine: could not load kernel32.dll, status c0000135») vẫn bị coi là «đã có sẵn» và vòng cài lặp mãi.
prefix_files_ok() {
  local w="$WINEPREFIX_DIR/drive_c/windows"
  [ -s "$WINEPREFIX_DIR/system.reg" ] && [ -s "$WINEPREFIX_DIR/user.reg" ] && [ -s "$w/system32/kernel32.dll" ] && [ -s "$w/system32/ntdll.dll" ] || return 1
  if wine_wow64; then [ -s "$w/syswow64/kernel32.dll" ] || return 1; fi
  return 0
}
wine_probe() {   # chạy THẬT cmd.exe 64-bit; lỗi gốc của Wine (err+all) nằm trong PROBE_OUT
  PROBE_OUT=$(WINEDEBUG=err+all,fixme-all timeout "${PROBE_TIMEOUT:-180}" box64 wine64 cmd /c "echo PYEA_PROBE_OK" 2>&1)
  printf '%s\n' "$PROBE_OUT" | grep -q PYEA_PROBE_OK
}
logsize() { local n; n=$(wc -c < "$LOGF" 2>/dev/null); n="${n//[^0-9]/}"; echo "${n:-0}"; }
# Lỗi gốc ở log thật (Cat S52, Android 10, nhân 4.9): «err:virtual:map_fixed_area out of memory ... try_map_free_area mmap() error Cannot allocate memory ...
# map_image_into_view failed to set 60500020 protection on ntdll.dll» = Wine không dựng được ntdll.dll ở địa chỉ cao. Box64 ghi nhận «Didn't detect 48bits of
# address space, considering it's 39bits»: nhân Android chỉ có không gian địa chỉ ảo 39-bit; tác giả Box64 nói chỗ sửa nằm ở Wine (bản Wine cũ hơn/mới hơn có thể khác).
addr_err() { printf '%s' "${1:-}" | grep -qE 'map_fixed_area out of memory|try_map_free_area|map_image_into_view failed'; }
probe_tail() { printf '%s' "${PROBE_OUT:-}" | tr -d '\r' | grep -v '^$' | tail -n 4 | tr '\n' ';' | cut -c1-400; }
wine_diag() {   # ghi $DIAGF (chi tiết, app đưa vào «chẩn đoán») và in MỘT dòng gọn cho thông báo lỗi
  local w="$WINEPREFIX_DIR/drive_c/windows" pg k32s k32w k32b n hint=""
  pg=$(getconf PAGESIZE 2>/dev/null); pg="${pg:-?}"
  if [ -s "$w/system32/kernel32.dll" ]; then k32s=có; else k32s=THIẾU; fi
  if [ -s "$w/syswow64/kernel32.dll" ]; then k32w=có; else k32w=không; fi
  if [ -s "$WINE_DIR/lib/wine/x86_64-windows/kernel32.dll" ]; then k32b=có; else k32b=THIẾU; fi
  n=$(ls "$w/system32" 2>/dev/null | wc -l | tr -d ' ')
  case "$pg" in 4096|"?") ;; *) hint=" Máy dùng trang nhớ $pg byte (không phải 4096): Box64/Wine có thể không chạy được." ;; esac
  {
    echo "== $(date '+%F %T') =="
    echo "wine=$(wine_variant) nhân=$(uname -r) trang_nhớ=$pg"
    echo "box64: $(BOX64_NOBANNER=0 BOX64_LOG=1 timeout 30 box64 --version 2>&1 | tr -d '\r' | grep -v '^$' | head -n 4 | tr '\n' ';')"
    echo "lỗi vùng nhớ ảo của Wine (map_fixed_area): $(addr_err "$(cat "$WB_OUT" 2>/dev/null)${PROBE_OUT:-}" && echo CÓ || echo không)"
    echo "bộ_cài=${DIAG_INSTALLER:-?} loại_PE=${DIAG_KIND:-?} cỡ=$(wc -c < "${DIAG_INSTALLER:-/dev/null}" 2>/dev/null)"
    echo "system32/kernel32=$k32s ($n file); syswow64/kernel32=$k32w; thư_mục_wine/x86_64-windows/kernel32=$k32b"
    echo "lệnh_thử_cmd: $(probe_tail)"
    echo "tiền_tố: $(ls "$WINEPREFIX_DIR" 2>/dev/null | tr '\n' ' ')"
  } >> "$DIAGF" 2>/dev/null
  printf 'Chẩn đoán: wine=%s, trang_nhớ=%s, system32/kernel32=%s (%s file), bộ cài=%s.%s' "$(wine_variant)" "$pg" "$k32s" "$n" "${DIAG_KIND:-?}" "$hint"
}

prefix_do() {
  local rc=0
  WINEDEBUG=err+all,fixme-all timeout "${PREFIX_TIMEOUT:-900}" box64 wine64 wineboot -i >"$WB_OUT" 2>&1 || rc=$?
  cat "$WB_OUT"
  [ "$rc" = 0 ] || return 1
  box64 wine64 reg add 'HKCU\Software\Wine\WineDbg' /v ShowCrashDialog /t REG_DWORD /d 0 /f
}
prefix_rebuild() {   # xoá tiền tố cũ, tạo lại từ đầu, kiểm file + chạy thử; lỗi thì đặt ERR
  mkdir -p "$DL"; ws_kill; rm -rf "$WINEPREFIX_DIR"; rm -f "$PFX_OK" "$WB_OUT"; PROBE_OUT=""
  hb prefix prefix_do || { ws_kill; ERR="Khởi tạo tiền tố Wine (wineboot) lỗi hoặc quá ${PREFIX_TIMEOUT:-900}s. $(wine_diag)"; return 1; }
  ws_kill
  prefix_files_ok || { ERR="wineboot xong nhưng tiền tố thiếu file hệ thống (kernel32.dll/ntdll.dll...). $(wine_diag)"; return 1; }
  wine_probe || { ws_kill; ERR="Tiền tố mới tạo xong nhưng chạy thử cmd.exe lỗi: $(probe_tail). $(wine_diag)"; return 1; }
  ws_kill; wine_variant > "$PFX_OK"
  return 0
}
prefix_rebuild_fallback() {   # như prefix_rebuild; nếu lỗi là vùng nhớ ảo (addr_err) thì lần lượt thử các bản Wine ở WINE_FALLBACK_VERS
  local v tried="$(wine_variant)"
  prefix_rebuild && return 0
  addr_err "$(cat "$WB_OUT" 2>/dev/null)${PROBE_OUT:-}" || return 1
  for v in $WINE_FALLBACK_VERS; do
    case " $tried " in *" amd64-$v "*) continue;; esac
    say "Wine $(wine_variant) không nạp được ntdll.dll (lỗi vùng nhớ ảo - nghi nhân Android chỉ có không gian địa chỉ 39-bit) -> thử Wine $v (tải thêm)"
    ws_kill
    HB_WATCH="$DL"; hb wine wine_get amd64 "$v" || { log "không tải được Wine $v - bỏ qua"; continue; }
    tried="$tried amd64-$v"
    write_env ""
    box64 wine64 --version >>"$LOGF" 2>&1 || { log "Wine $v không chạy được --version - bỏ qua"; continue; }
    if prefix_rebuild; then say "Wine $v chạy được -> dùng bản này"; return 0; fi
    addr_err "$(cat "$WB_OUT" 2>/dev/null)${PROBE_OUT:-}" || return 1          # lỗi khác (không phải vùng nhớ): thử bản khác cũng vô ích
  done
  ERR="$ERR | Đã thử các bản Wine: $tried - đều không nạp được ntdll.dll vì vùng nhớ ảo. Máy này (nhân Android có không gian địa chỉ 39-bit?) rất có thể không chạy được Wine 64-bit qua Box64."
  return 1
}
st_prefix() {
  write_env ""; start_xvfb
  if ! redo prefix && prefix_files_ok && wine_probe; then
    log "tiền tố Wine có sẵn và chạy thử cmd.exe được -> giữ nguyên"; ws_kill; wine_variant > "$PFX_OK"; return 0
  fi
  ws_kill; log "tiền tố Wine thiếu/hỏng (hoặc chạy thử lỗi) -> dựng lại từ đầu"
  prefix_rebuild_fallback
}
chk_prefix() { prefix_files_ok && [ "$(cat "$PFX_OK" 2>/dev/null)" = "$(wine_variant)" ]; }

mt5_install_do() {   # chạy bộ cài MT5 (cờ /auto), đợi terminal64.exe + metaeditor64.exe xuất hiện và ngừng tăng, rồi tắt. WHY=kernel32 khi Wine không nạp được kernel32.dll
  local exe="$1" tmo="${MT5_INSTALL_TIMEOUT:-2400}" t0 now last_ev=0 t sz="" prev=-1 stable=0 inst off bad
  WHY=""
  off=$(wc -c < "$LOGF" 2>/dev/null); off="${off//[^0-9]/}"; off="${off:-0}"
  t0=$(date +%s)
  ( cd "$DL" && export WINEDEBUG=err+all,fixme-all && exec box64 wine64 "$exe" /auto ) >>"$LOGF" 2>&1 &
  inst=$!
  while true; do
    sleep "${MT5_POLL:-5}"; now=$(date +%s)
    t=$(find_terminal)
    if [ -n "$t" ] && [ -e "$(dirname "$t")/metaeditor64.exe" ]; then
      sz=$(du -sk "$(dirname "$t")" 2>/dev/null | awk '{print $1}')
      if [ "$sz" = "$prev" ]; then stable=$(( stable + 1 )); else stable=0; prev="$sz"; fi
      [ "$stable" -ge "${MT5_STABLE:-4}" ] && break
    fi
    if [ -z "$t" ]; then   # lỗi nạp DLL thì Wine không tự thoát nhanh (log thật: ~300 s mỗi lần) -> dừng ngay, khỏi đợi
      bad=$(tail -c +"$(( off + 1 ))" "$LOGF" 2>/dev/null | grep -m1 'could not load kernel32')
      [ -n "$bad" ] && { WHY=kernel32; ERR="Wine không nạp được kernel32.dll (c0000135 = thiếu DLL): $bad"; kill "$inst" 2>/dev/null; return 1; }
    fi
    kill -0 "$inst" 2>/dev/null || { [ -n "$t" ] && break; ERR="bộ cài MT5 thoát mà chưa thấy terminal64.exe"; kill "$inst" 2>/dev/null; return 1; }
    [ $(( now - t0 )) -ge "$tmo" ] && { ERR="quá ${tmo}s mà MT5 chưa cài xong"; kill "$inst" 2>/dev/null; return 1; }
    if [ $(( now - last_ev )) -ge "$HB_EVERY" ]; then
      last_ev=$now; printf '.'
      sup_event install stage=mt5 state=progress detail="bộ cài MT5 đang chạy $(( now - t0 ))s${sz:+, đã ghi $(( ${sz:-0} / 1024 )) MB}"
    fi
  done
  kill "$inst" 2>/dev/null; ws_kill
  return 0
}
st_mt5() {
  local url="${MT5_SETUP_URL:-$MT5_URL_DEFAULT}" exe="$DL/mt5setup.exe" t kind heals=0
  mkdir -p "$DL"
  HB_WATCH="$exe"; hb mt5 retry 3 wget -c -O "$exe" "$url" || { ERR="Không tải được bộ cài MT5 từ $url"; return 1; }
  [ "$(head -c2 "$exe" 2>/dev/null)" = "MZ" ] || { ERR="File tải về không phải chương trình .exe (link hỏng hoặc bị chặn): $url"; return 1; }
  write_env ""; start_xvfb
  kind=$(pe_kind "$exe"); DIAG_KIND="$kind"; DIAG_INSTALLER="$exe"
  log "bộ cài MT5: loại PE=$kind (x64=64-bit, x86=32-bit, ?=không rõ); Wine=$(wine_variant)"
  if [ "$kind" = x86 ] && ! wine_wow64; then   # bản Wine thường chỉ chạy .exe 32-bit khi có thư viện 32-bit (Box64 không có) -> cần bản wow64
    say "Bộ cài MT5 là chương trình 32-bit mà Wine hiện tại ($(wine_variant)) không chạy được file 32-bit -> đổi sang Wine wow64 $WINE_WOW64_VER (tải thêm, làm 1 lần)"
    ws_kill
    HB_WATCH="$DL"; hb wine wine_get amd64-wow64 "$WINE_WOW64_VER" || { ERR="Không tải/giải nén được Wine wow64 $WINE_WOW64_VER (GitHub chặn/mạng đứt?)."; return 1; }
    write_env ""
    box64 wine64 --version >>"$LOGF" 2>&1 || { ERR="Wine wow64 đã giải nén nhưng «box64 wine64 --version» lỗi."; return 1; }
    prefix_rebuild || return 1
  fi
  while true; do
    ERR=""
    mt5_install_do "$exe" && break
    ws_kill
    if [ "$WHY" = kernel32 ] && [ "$heals" -lt 1 ]; then   # tự chữa MỘT lần: tiền tố có thể hỏng -> dựng lại rồi cài lại
      heals=$(( heals + 1 ))
      say "Wine không nạp được kernel32.dll -> dựng lại tiền tố Wine rồi cài MT5 lại (lần $heals)"
      prefix_rebuild || return 1
      continue
    fi
    ERR="$ERR. $(wine_diag)"
    return 1
  done
  t=$(find_terminal); [ -n "$t" ] || { ERR="cài xong nhưng không thấy terminal64.exe"; return 1; }
  rm -f "$MT5_LINK"; ln -s "$(dirname "$t")" "$MT5_LINK" || { ERR="không tạo được liên kết $MT5_LINK"; return 1; }
  write_env "$MT5_LINK"
}
chk_mt5() { [ -n "$(find_terminal)" ] && [ -d "$MT5_LINK" ] && write_env "$MT5_LINK"; }

st_provision() {
  local out
  write_env "$MT5_LINK"
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" provision 2>&1) || { ERR="Cấp file từ app lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; return 1; }
}
st_compile() {
  local out ed="$MT5_LINK/MQL5/Experts"
  start_xvfb
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" compile 2>&1) || { ERR="Biên dịch EA lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; ws_kill; return 1; }
  ws_kill
  cp "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5" 2>/dev/null
  return 0
}
chk_compile() { local ed="$MT5_LINK/MQL5/Experts"; [ -f "$ed/PyEABridge.ex5" ] && cmp -s "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5"; }

# ---------------------------------------------------------------------------------------------- điều phối
LOCK="$STATE_DIR/install.pid"
take_lock() {
  if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null && [ "$(cat "$LOCK")" != "$$" ]; then
    say "Đang có một lần cài khác chạy (pid $(cat "$LOCK")). Đợi nó xong, hoặc đóng nó rồi chạy lại."; exit 3
  fi
  echo $$ > "$LOCK"; trap 'rm -f "$LOCK"' EXIT
}

case "$MODE" in
  outer)
    take_lock
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    say "PyEA - cài MT5 trong giả lập. CHƯA kiểm trên điện thoại thật; hãy thử bằng tài khoản DEMO trước."
    stage precheck "Kiểm tra máy (CPU 64-bit, dung lượng, mạng)" st_precheck_do
    stage termux_pkgs "Cài công cụ nền cho Termux (proot-distro, curl, wget)" st_termux_pkgs chk_termux_pkgs
    stage rootfs "Tạo môi trường Debian" st_rootfs chk_rootfs
    stage fetch "Lấy script và cấu hình từ app PyEA" st_fetch
    run_inner || exit $?
    stage launcher "Tạo lệnh khởi động MT5 (và tự chạy khi mở máy nếu có Termux:Boot)" st_launcher
    sup_event install stage=login state=start detail="bật MT5, đăng nhập tài khoản và nối EA vào app"
    bash "$BASE/pyea-start-mt5.sh" start || die_stage login "không bật được MT5 bằng pyea-start-mt5.sh"
    say ""
    say "XONG PHẦN CÀI. MT5 đang khởi động và đăng nhập; app PyEA sẽ báo «Đã nối» (hoặc lý do nếu lỗi)."
    say "Từ nay muốn bật lại MT5: bash ~/pyea-start-mt5.sh   (dừng: bash ~/pyea-start-mt5.sh stop)."
    say "Muốn tự chạy sau khi khởi động lại điện thoại: cài Termux:Boot (F-Droid) và mở nó một lần. Android 12+: tắt hạn chế tiến trình con trong Tuỳ chọn nhà phát triển."
    ;;
  inner)
    take_lock
    export DEBIAN_FRONTEND=noninteractive
    stage apt "Cài thư viện nền trong Debian (Xvfb, X11, font...)" st_apt chk_apt
    stage box64 "Cài Box64 (lớp dịch x86-64 sang ARM)" st_box64 chk_box64
    stage wine "Tải Wine 64-bit $WINE_VER" st_wine chk_wine
    stage prefix "Khởi tạo Wine (lần đầu hơi lâu)" st_prefix chk_prefix
    stage mt5 "Tải và cài MetaTrader 5" st_mt5 chk_mt5
    stage provision "Chép EA cầu nối và cấu hình từ app" st_provision
    stage compile "Biên dịch EA cầu nối" st_compile chk_compile
    ;;
  *) echo "chế độ không rõ: $MODE (outer|inner)"; exit 64 ;;
esac
exit 0
