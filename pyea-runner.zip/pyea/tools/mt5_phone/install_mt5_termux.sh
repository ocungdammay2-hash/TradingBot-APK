#!/usr/bin/env bash
# PyEA - CÀI TỰ ĐỘNG MT5 THẬT chạy trong giả lập trên điện thoại (Termux + proot Debian + Box64 + Wine + MT5 + EA cầu nối PyEABridge).
# Người dùng chỉ nhập login/mật khẩu/server trong app, dán MỘT lệnh vào Termux; mọi bước còn lại do script này làm và báo tiến trình về app.
# CHƯA KIỂM TRÊN ĐIỆN THOẠI THẬT (sandbox x86, chặn mạng ra ngoài). Phần LOGIC (các bước, chạy lại làm tiếp, báo lỗi về app, cấp file, xoá mật khẩu)
# đã test bằng lệnh giả: tests/test_mt5_install.py. Phần Box64/Wine/MT5 chạy thật hay không CHỈ biết khi chạy trên máy thật.
#
# Dùng (trong Termux, bản F-Droid/GitHub - KHÔNG dùng bản Google Play đã cũ):   PYEA_TOKEN=... bash install_mt5_termux.sh
#   (app tạo sẵn lệnh dán 1 lần: nó tự lấy script này từ app qua cổng cục bộ 127.0.0.1 rồi chạy)
# Chạy lại cùng lệnh được: các bước đã xong tự bỏ qua (kiểm bằng trạng thái thật, không chỉ cờ), bước lỗi làm tiếp.
#   outer (mặc định) = phần chạy trong Termux: kiểm máy, gói Termux, tạo Debian, lấy file từ app, GỌI phần trong, tạo lệnh khởi động, bật MT5
#   inner            = phần chạy BÊN TRONG Debian (do outer gọi): thư viện, Box64, Wine, tiền tố Wine, cài MT5, chép + biên dịch EA
# Biến (đều tuỳ chọn):
#   PYEA_TOKEN / PYEA_TOKEN_FILE / PYEA_HOST / PYEA_PORT   kênh về app (token = «mt5ea_token»)
#   PYEA_REDO=wine,mt5 (hoặc all)   ép làm lại các bước đó dù đã có
#   WINE_VER (mặc định 9.7) / WINE_URL      bản Wine 64-bit của Kron4ek dùng với Box64
#   MT5_SETUP_URL   bộ cài MT5 (mặc định bản chung của MetaQuotes; sàn có bộ cài riêng thì đặt link của sàn)
#   BOX64_PKG       gói Box64 (mặc định box64-android)
#   MIN_FREE_KB     dung lượng trống tối thiểu (mặc định 3000000 ≈ 3 GB, ƯỚC LƯỢNG chưa đo)
#   HB_EVERY        giây giữa các lần báo «còn chạy» về app (mặc định 10)
set -u

MODE="${1:-outer}"
PYEA_HOST="${PYEA_HOST:-127.0.0.1}"; PYEA_PORT="${PYEA_PORT:-18765}"
if [ -z "${PYEA_TOKEN:-}" ] && [ -n "${PYEA_TOKEN_FILE:-}" ] && [ -r "$PYEA_TOKEN_FILE" ]; then PYEA_TOKEN="$(tr -d '\r\n' < "$PYEA_TOKEN_FILE")"; fi
PYEA_TOKEN="${PYEA_TOKEN:-}"

# >>> pyea-common (BẢN SAO y hệt trong run_mt5_termux.sh; tests/test_mt5_install.py kiểm hai bản giống nhau)
pesc() { local v="$1"; v=${v//%/%25}; v=${v//|/%7C}; v=${v//=/%3D}; v=${v//$'\r'/%0D}; v=${v//$'\n'/%0A}; printf '%s' "$v"; }
punesc() { local v="$1"; v=${v//%0A/$'\n'}; v=${v//%0D/$'\r'}; v=${v//%3D/=}; v=${v//%7C/|}; v=${v//%25/%}; printf '%s' "$v"; }
# sup_send "SEVT|kind=x|..." ...   (mỗi lần mở một kết nối ngắn; thất bại thì bỏ qua, không làm hỏng giám sát)
sup_send() {
  [ -n "$PYEA_TOKEN" ] || return 0
  ( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" || exit 1
    printf 'SUPHELLO|v=1|token=%s\n' "$PYEA_TOKEN" >&3
    for l in "$@"; do printf '%s\n' "$l" >&3; done
    sleep 0.2 ) 2>/dev/null
  return 0
}
sup_event() { local kind="$1"; shift; local m="SEVT|kind=$kind" kv; for kv in "$@"; do m="$m|${kv%%=*}=$(pesc "${kv#*=}")"; done; sup_send "$m"; }
sup_log() { sup_send "SLOG|lvl=$1|m=$(pesc "$2")"; }
# sup_get tên_file đích  -> 0 nếu lấy và ghi được
sup_get() {
  local name="$1" dest="$2" line b64 err
  [ -n "$PYEA_TOKEN" ] || { echo "thiếu PYEA_TOKEN"; return 2; }
  line=$( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" 2>/dev/null || exit 1
          printf 'SUPHELLO|v=1|token=%s\nGET|name=%s\n' "$PYEA_TOKEN" "$name" >&3
          while IFS= read -r -t 10 -u 3 l; do case "$l" in FILE\|*) printf '%s' "$l"; break;; esac; done ) || { echo "không nối được app ($PYEA_HOST:$PYEA_PORT)"; return 1; }
  [ -n "$line" ] || { echo "app không trả lời (sai token? app chưa bật nguồn mt5ea?)"; return 1; }
  err=""; b64=""
  case "$line" in *"|err="*) err="${line#*|err=}"; err="${err%%|*}";; esac
  case "$line" in *"|b64="*) b64="${line#*|b64=}"; b64="${b64%%|*}"; b64="$(punesc "$b64")";; esac
  [ -z "$err" ] || { echo "app từ chối: $(punesc "$err")"; return 1; }
  mkdir -p "$(dirname "$dest")" && printf '%s' "$b64" | base64 -d > "$dest.tmp" && mv "$dest.tmp" "$dest" || { echo "không ghi được $dest"; return 1; }
  return 0
}
# <<< pyea-common

# ---------------------------------------------------------------------------------------------- đường dẫn
DISTRO="${PYEA_DISTRO:-debian}"
PREFIX_DIR="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="${PYEA_ROOTFS:-$PREFIX_DIR/var/lib/proot-distro/installed-rootfs/$DISTRO}"
GUEST_ROOT="${PYEA_GUEST_ROOT:-/root}"             # thư mục root như Debian-bên-trong thấy
HOST_ROOT="${PYEA_HOST_ROOT:-$ROOTFS/root}"        # cùng thư mục đó nhìn từ Termux
if [ "$MODE" = inner ]; then BASE="$GUEST_ROOT"; else BASE="${PYEA_BASE:-$HOME}"; fi
STATE_DIR="$BASE/.pyea"; LOGF="${PYEA_INSTALL_LOG:-$STATE_DIR/install.log}"
HB_EVERY="${HB_EVERY:-10}"
WINE_VER="${WINE_VER:-9.7}"
WINE_DIR="$GUEST_ROOT/wine64"; WINEPREFIX_DIR="$GUEST_ROOT/.wine-mt5"; DL="$GUEST_ROOT/dl"; ENVF="$GUEST_ROOT/.pyea_env.sh"; MT5_LINK="$GUEST_ROOT/mt5"
MT5_URL_DEFAULT="https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe"
ERR=""; HB_WATCH=""

mkdir -p "$STATE_DIR" 2>/dev/null
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOGF" 2>/dev/null; }
say() { printf '%s\n' "$*"; log "$*"; }
redo() { case ",${PYEA_REDO:-}," in *",$1,"*|*",all,"*) return 0;; esac; return 1; }

die_stage() {   # id lý_do   - báo lỗi về app (kèm đuôi nhật ký) rồi thoát; chạy lại cùng lệnh sẽ làm tiếp từ bước này
  local id="$1" msg="$2" tl
  tl=$(tail -n 12 "$LOGF" 2>/dev/null | tr -d '\r' | tr '\n' ';' | cut -c1-700)
  say "✗ LỖI ở bước «$id»: $msg"
  say "  Chạy lại CÙNG lệnh để làm tiếp từ bước này. Nhật ký: $LOGF"
  [ -z "$tl" ] || say "  đuôi nhật ký: $tl"
  sup_event install stage="$id" state=fail detail="$msg | $tl"
  exit 1
}

# retry N lệnh...   (mạng di động hay đứt: thử lại, chờ lâu dần)
retry() { local n="$1" i=1; shift; while true; do "$@" && return 0; [ "$i" -ge "$n" ] && return 1; log "lệnh lỗi (lần $i/$n): $*"; sleep "$(awk -v i="$i" -v b="${RETRY_SLEEP:-4}" 'BEGIN{print i*b}')"; i=$(( i + 1 )); done; }

# hb id lệnh...   chạy lệnh (đầu ra vào nhật ký), cứ HB_EVERY giây báo «còn chạy» về app + in dấu chấm; trả mã thoát của lệnh.
# HB_WATCH=<file/thư mục> thì báo kèm dung lượng hiện có (để thấy tiến độ tải).
hb() {
  local id="$1" pid rc last now sz=""; shift
  "$@" >>"$LOGF" 2>&1 &
  pid=$!; last=$(date +%s)
  while kill -0 "$pid" 2>/dev/null; do
    sleep 0.2
    now=$(date +%s)
    if [ $(( now - last )) -ge "$HB_EVERY" ]; then
      last=$now; sz=""
      if [ -n "$HB_WATCH" ] && [ -e "$HB_WATCH" ]; then sz="$(du -sk "$HB_WATCH" 2>/dev/null | awk '{printf "%d MB", $1/1024}')"; fi
      printf '.'
      sup_event install stage="$id" state=progress detail="${sz:+đã có $sz, }vẫn đang chạy"
    fi
  done
  wait "$pid"; rc=$?
  HB_WATCH=""
  return $rc
}

# stage id nhãn hàm [hàm_kiểm_đã_xong]
stage() {
  local id="$1" label="$2" fn="$3" chk="${4:-}"
  if [ -n "$chk" ] && ! redo "$id" && "$chk" >/dev/null 2>&1; then
    say "✓ $label - đã có sẵn, bỏ qua"; sup_event install stage="$id" state=skip detail="$label"; return 0
  fi
  say "▶ $label ..."; sup_event install stage="$id" state=start detail="$label"
  ERR=""
  "$fn" || die_stage "$id" "${ERR:-không rõ lý do}"
  say "✓ $label"; sup_event install stage="$id" state=ok detail="$label"
  return 0
}

# ---------------------------------------------------------------------------------------------- OUTER (Termux)
st_precheck_do() {
  local arch free need="${MIN_FREE_KB:-3000000}"
  arch="${PYEA_ARCH:-$(uname -m)}"
  case "$arch" in
    aarch64|arm64) ;;
    *) ERR="CPU báo «$arch». Cần Termux bản 64-bit ARM (aarch64) trên điện thoại 64-bit; máy 32-bit/x86 không chạy được Box64. Tải Termux arm64-v8a ở F-Droid/GitHub."; return 1;;
  esac
  free=$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2{print $4}')
  if [ -n "$free" ] && [ "$free" -lt "$need" ] 2>/dev/null; then
    ERR="Còn trống $(( free / 1024 )) MB, cần tối thiểu khoảng $(( need / 1024 )) MB (ước lượng cho Debian + Wine + MT5). Dọn bớt rồi chạy lại."; return 1
  fi
  if [ -z "$PYEA_TOKEN" ]; then ERR="thiếu PYEA_TOKEN: hãy dùng đúng lệnh app tạo sẵn (nó đã kèm token)."; return 1; fi
  return 0
}
termux_pkgs_do() {
  pkg update -y && pkg install -y -o Dpkg::Options::=--force-confold proot-distro curl wget procps
}
st_termux_pkgs() {
  hb termux_pkgs retry 3 termux_pkgs_do || { ERR="pkg lỗi: kiểm tra Wi-Fi/4G. Nếu báo không tải được gói: chạy «termux-change-repo», chọn kho khác, rồi chạy lại lệnh."; return 1; }
}
chk_termux_pkgs() { command -v proot-distro && command -v curl && command -v wget; }
st_rootfs() {
  hb rootfs retry 2 proot-distro install "$DISTRO" || { ERR="proot-distro không cài được Debian (thiếu dung lượng/mạng?)."; return 1; }
  chk_rootfs || { ERR="proot-distro báo xong nhưng không thấy hệ Debian ở $ROOTFS."; return 1; }
}
chk_rootfs() { [ -d "$ROOTFS/root" ] && { [ -e "$ROOTFS/bin/bash" ] || [ -e "$ROOTFS/usr/bin/bash" ]; }; }
st_fetch() {
  local r
  mkdir -p "$HOST_ROOT/pyea" || { ERR="không tạo được $HOST_ROOT/pyea"; return 1; }
  for f in install_mt5_termux.sh run_mt5_termux.sh pyea_relay.py; do
    r=$(sup_get "$f" "$HOST_ROOT/pyea/$f") || { ERR="Không lấy được «$f» từ app: $r. App phải đang mở, đã bấm «Bắt đầu» trong «Kết nối MT5 nhanh»; đừng tắt app trong lúc cài."; return 1; }
  done
  ( umask 077; printf '%s' "$PYEA_TOKEN" > "$HOST_ROOT/pyea/token" ) || { ERR="không ghi được token"; return 1; }
  chmod 600 "$HOST_ROOT/pyea/token" 2>/dev/null
  return 0
}
run_inner() {
  local rc=0
  say "Bước tiếp theo chạy BÊN TRONG Debian (lâu nhất: tải Wine + MT5, có thể hàng chục phút; cứ để màn hình sáng, app báo tiến trình)."
  proot-distro login "$DISTRO" --shared-tmp -- env PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT" PYEA_GUEST_ROOT="$GUEST_ROOT" \
    PYEA_REDO="${PYEA_REDO:-}" HB_EVERY="$HB_EVERY" WINE_VER="$WINE_VER" WINE_URL="${WINE_URL:-}" MT5_SETUP_URL="${MT5_SETUP_URL:-}" BOX64_PKG="${BOX64_PKG:-}" \
    PYEA_INSTALL_LOG="$GUEST_ROOT/.pyea/install.log" \
    bash "$GUEST_ROOT/pyea/install_mt5_termux.sh" inner || rc=$?
  return $rc
}
st_launcher() {
  local home="$BASE" sh_bash="${PREFIX_DIR}/bin/bash"
  mkdir -p "$home/.pyea" "$home/.termux/boot" 2>/dev/null
  cat > "$home/pyea-start-mt5.sh" <<EOF
#!/usr/bin/env bash
# Khởi động / dừng MT5 trong giả lập + giám sát (do trình cài PyEA tạo). Dùng: bash ~/pyea-start-mt5.sh [start|stop|status]
PIDF="\$HOME/.pyea/run.pid"; OUT="\$HOME/.pyea/run.out"
mkdir -p "\$HOME/.pyea"
alive() { [ -f "\$PIDF" ] && kill -0 "\$(cat "\$PIDF" 2>/dev/null)" 2>/dev/null; }
case "\${1:-start}" in
  status) if alive; then echo "MT5: đang chạy (pid \$(cat "\$PIDF"))"; else echo "MT5: không chạy"; exit 1; fi ;;
  stop)
    alive && kill "\$(cat "\$PIDF")" 2>/dev/null
    proot-distro login $DISTRO -- bash -c 'pkill -TERM -f "run_mt5_[t]ermux.sh"; pkill -TERM -f "pyea_[r]elay.py"; sleep 2; pkill -KILL -f "[t]erminal64.exe"; pkill -KILL -x wineserver' >/dev/null 2>&1
    rm -f "\$PIDF"; echo "đã dừng MT5" ;;
  *)
    if alive; then echo "MT5 đã đang chạy (pid \$(cat "\$PIDF"))"; exit 0; fi
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    nohup proot-distro login $DISTRO --shared-tmp -- env PYEA_ENV="$GUEST_ROOT/.pyea_env.sh" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" run >> "\$OUT" 2>&1 &
    echo \$! > "\$PIDF"; disown 2>/dev/null
    echo "đã bật MT5 (nhật ký: \$OUT). Tiến trình đăng nhập hiện trong app PyEA." ;;
esac
EOF
  cat > "$home/.termux/boot/pyea-mt5.sh" <<EOF
#!$sh_bash
# Chỉ chạy khi đã cài và mở Termux:Boot ít nhất 1 lần. Bật MT5 sau khi khởi động lại điện thoại.
termux-wake-lock 2>/dev/null
bash "\$HOME/pyea-start-mt5.sh" start
EOF
  chmod +x "$home/pyea-start-mt5.sh" "$home/.termux/boot/pyea-mt5.sh" 2>/dev/null
  [ -x "$home/pyea-start-mt5.sh" ] || { ERR="không tạo được lệnh khởi động"; return 1; }
  return 0
}

# ---------------------------------------------------------------------------------------------- INNER (Debian)
write_env() {   # $1 = thư mục MT5 (có thể rỗng khi chưa cài)
  cat > "$ENVF" <<EOF
# do install_mt5_termux.sh tạo; run_mt5_termux.sh nạp file này
export WINE_DIR="$WINE_DIR"
export BOX64_PATH="$WINE_DIR/bin"
export BOX64_LD_LIBRARY_PATH="$WINE_DIR/lib:$WINE_DIR/lib64:$WINE_DIR/lib/wine/x86_64-unix"
export BOX64_LOG=0 BOX64_NOBANNER=1
export WINEPREFIX="$WINEPREFIX_DIR" WINEARCH=win64 WINEDEBUG=-all
export DISPLAY=:99
export PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT"
export PYEA_LOGIN_WATCH=1 PYEA_SYNC_CFG=1
export MT5_DIR="${1:-}"
EOF
  # shellcheck disable=SC1090
  . "$ENVF"
}
start_xvfb() {
  [ "${NO_XVFB:-}" = "1" ] && return 0
  pgrep -x Xvfb >/dev/null 2>&1 && return 0
  ( Xvfb "$DISPLAY" -screen 0 800x600x16 -nolisten tcp >/dev/null 2>&1 & )
  sleep 1
  return 0
}
ws_kill() { box64 "$WINE_DIR/bin/wineserver" -k >/dev/null 2>&1; return 0; }
find_terminal() { find "$WINEPREFIX_DIR/drive_c" -maxdepth 4 -iname terminal64.exe 2>/dev/null | head -1; }

apt_all() { apt-get update && apt-get install -y --no-install-recommends ca-certificates wget gnupg xz-utils xvfb xauth procps; }
APT_OPT="cabextract libx11-6 libxext6 libxrender1 libxcursor1 libxi6 libxrandr2 libxfixes3 libxcomposite1 libxinerama1 libxxf86vm1 libfreetype6 libfontconfig1 libgnutls30 libglib2.0-0 libdbus-1-3 libasound2 libasound2t64 libpulse0 libgl1 fonts-dejavu-core python3"
apt_opt() {   # gói tuỳ chọn: cài cả loạt; hỏng thì thử từng gói, gói không có (tên khác theo bản Debian) thì bỏ qua
  # shellcheck disable=SC2086
  apt-get install -y --no-install-recommends $APT_OPT && return 0
  local p; for p in $APT_OPT; do apt-get install -y --no-install-recommends "$p" || log "gói tuỳ chọn không cài được: $p"; done
  return 0
}
st_apt() {
  export DEBIAN_FRONTEND=noninteractive
  hb apt retry 3 apt_all || { ERR="apt không cài được gói nền (Xvfb, wget, gnupg...). Thường do mạng đứt hoặc hết dung lượng."; return 1; }
  hb apt apt_opt
  return 0
}
chk_apt() { command -v Xvfb && command -v wget && command -v gpg && command -v xz && command -v pgrep; }

box64_do() {
  wget -q -O /etc/apt/sources.list.d/box64.list "${BOX64_LIST_URL:-https://ryanfortner.github.io/box64-debs/box64.list}" || return 1
  wget -q -O "$DL/box64.gpg" "${BOX64_KEY_URL:-https://ryanfortner.github.io/box64-debs/KEY.gpg}" || return 1
  gpg --batch --yes --dearmor -o /etc/apt/trusted.gpg.d/box64-debs-archive-keyring.gpg "$DL/box64.gpg" || return 1
  apt-get update || return 1
  apt-get install -y "${BOX64_PKG:-box64-android}" || { [ -z "${BOX64_PKG:-}" ] && apt-get install -y box64; }
}
st_box64() {
  mkdir -p "$DL"
  hb box64 retry 2 box64_do || { ERR="Không cài được Box64 từ kho ryanfortner.github.io/box64-debs (kho tạm hỏng/mạng đứt?)."; return 1; }
  box64 --version >>"$LOGF" 2>&1 || { ERR="Box64 đã cài nhưng không chạy được («box64 --version» lỗi). CPU/Android của máy này có thể không hợp."; return 1; }
}
chk_box64() { command -v box64 && box64 --version 2>&1 | grep -qi box64; }

wine_do() {
  local url="${WINE_URL:-https://github.com/Kron4ek/Wine-Builds/releases/download/$WINE_VER/wine-$WINE_VER-amd64.tar.xz}" tb="$DL/wine-$WINE_VER-amd64.tar.xz"
  retry 3 wget -c -O "$tb" "$url" || return 1
  rm -rf "$WINE_DIR.new"; mkdir -p "$WINE_DIR.new"
  tar -xJf "$tb" -C "$WINE_DIR.new" --strip-components=1 || return 1
  [ -e "$WINE_DIR.new/bin/wine64" ] || return 2
  rm -rf "$WINE_DIR"; mv "$WINE_DIR.new" "$WINE_DIR"; rm -f "$tb"
}
st_wine() {
  local rc=0
  mkdir -p "$DL"; write_env ""
  HB_WATCH="$DL"; hb wine wine_do || rc=$?
  case "$rc" in
    0) ;;
    2) ERR="Giải nén Wine xong nhưng không thấy bin/wine64 (file tải về sai bản?)."; return 1;;
    *) ERR="Không tải/giải nén được Wine $WINE_VER (GitHub bị chặn/mạng đứt/hết dung lượng?)."; return 1;;
  esac
  box64 wine64 --version >>"$LOGF" 2>&1 || { ERR="Wine đã giải nén nhưng «box64 wine64 --version» lỗi: thiếu thư viện hoặc Box64 không chạy được Wine này. Xem nhật ký."; return 1; }
}
chk_wine() { [ -e "$WINE_DIR/bin/wine64" ] && write_env "${MT5_DIR:-}" && box64 wine64 --version; }

prefix_do() {
  timeout "${PREFIX_TIMEOUT:-900}" box64 wine64 wineboot -i && box64 wine64 reg add 'HKCU\Software\Wine\WineDbg' /v ShowCrashDialog /t REG_DWORD /d 0 /f
}
st_prefix() {
  write_env ""; start_xvfb
  hb prefix prefix_do || { ws_kill; ERR="Khởi tạo tiền tố Wine (wineboot) lỗi hoặc quá ${PREFIX_TIMEOUT:-900}s."; return 1; }
  ws_kill
  [ -f "$WINEPREFIX_DIR/system.reg" ] || { ERR="wineboot xong nhưng không thấy system.reg trong $WINEPREFIX_DIR."; return 1; }
}
chk_prefix() { [ -f "$WINEPREFIX_DIR/system.reg" ]; }

mt5_install_do() {   # chạy bộ cài MT5 (cờ /auto), đợi terminal64.exe + metaeditor64.exe xuất hiện và ngừng tăng, rồi tắt
  local exe="$1" tmo="${MT5_INSTALL_TIMEOUT:-2400}" t0 now last_ev=0 t sz="" prev=-1 stable=0 inst
  t0=$(date +%s)
  ( cd "$DL" && exec box64 wine64 "$exe" /auto ) >>"$LOGF" 2>&1 &
  inst=$!
  while true; do
    sleep "${MT5_POLL:-5}"; now=$(date +%s)
    t=$(find_terminal)
    if [ -n "$t" ] && [ -e "$(dirname "$t")/metaeditor64.exe" ]; then
      sz=$(du -sk "$(dirname "$t")" 2>/dev/null | awk '{print $1}')
      if [ "$sz" = "$prev" ]; then stable=$(( stable + 1 )); else stable=0; prev="$sz"; fi
      [ "$stable" -ge "${MT5_STABLE:-4}" ] && break
    fi
    kill -0 "$inst" 2>/dev/null || { [ -n "$t" ] && break; ERR="bộ cài MT5 thoát mà chưa thấy terminal64.exe"; kill "$inst" 2>/dev/null; return 1; }
    [ $(( now - t0 )) -ge "$tmo" ] && { ERR="quá ${tmo}s mà MT5 chưa cài xong"; kill "$inst" 2>/dev/null; return 1; }
    if [ $(( now - last_ev )) -ge "$HB_EVERY" ]; then
      last_ev=$now; printf '.'
      sup_event install stage=mt5 state=progress detail="bộ cài MT5 đang chạy $(( now - t0 ))s${sz:+, đã ghi $(( ${sz:-0} / 1024 )) MB}"
    fi
  done
  kill "$inst" 2>/dev/null; ws_kill
  return 0
}
st_mt5() {
  local url="${MT5_SETUP_URL:-$MT5_URL_DEFAULT}" exe="$DL/mt5setup.exe" t
  mkdir -p "$DL"
  HB_WATCH="$exe"; hb mt5 retry 3 wget -c -O "$exe" "$url" || { ERR="Không tải được bộ cài MT5 từ $url"; return 1; }
  [ "$(head -c2 "$exe" 2>/dev/null)" = "MZ" ] || { ERR="File tải về không phải chương trình .exe (link hỏng hoặc bị chặn): $url"; return 1; }
  write_env ""; start_xvfb
  ERR=""; mt5_install_do "$exe" || { ws_kill; return 1; }
  t=$(find_terminal); [ -n "$t" ] || { ERR="cài xong nhưng không thấy terminal64.exe"; return 1; }
  rm -f "$MT5_LINK"; ln -s "$(dirname "$t")" "$MT5_LINK" || { ERR="không tạo được liên kết $MT5_LINK"; return 1; }
  write_env "$MT5_LINK"
}
chk_mt5() { [ -n "$(find_terminal)" ] && [ -d "$MT5_LINK" ] && write_env "$MT5_LINK"; }

st_provision() {
  local out
  write_env "$MT5_LINK"
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" provision 2>&1) || { ERR="Cấp file từ app lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; return 1; }
}
st_compile() {
  local out ed="$MT5_LINK/MQL5/Experts"
  start_xvfb
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" compile 2>&1) || { ERR="Biên dịch EA lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; ws_kill; return 1; }
  ws_kill
  cp "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5" 2>/dev/null
  return 0
}
chk_compile() { local ed="$MT5_LINK/MQL5/Experts"; [ -f "$ed/PyEABridge.ex5" ] && cmp -s "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5"; }

# ---------------------------------------------------------------------------------------------- điều phối
LOCK="$STATE_DIR/install.pid"
take_lock() {
  if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null && [ "$(cat "$LOCK")" != "$$" ]; then
    say "Đang có một lần cài khác chạy (pid $(cat "$LOCK")). Đợi nó xong, hoặc đóng nó rồi chạy lại."; exit 3
  fi
  echo $$ > "$LOCK"; trap 'rm -f "$LOCK"' EXIT
}

case "$MODE" in
  outer)
    take_lock
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    say "PyEA - cài MT5 trong giả lập. CHƯA kiểm trên điện thoại thật; hãy thử bằng tài khoản DEMO trước."
    stage precheck "Kiểm tra máy (CPU 64-bit, dung lượng, mạng)" st_precheck_do
    stage termux_pkgs "Cài công cụ nền cho Termux (proot-distro, curl, wget)" st_termux_pkgs chk_termux_pkgs
    stage rootfs "Tạo môi trường Debian" st_rootfs chk_rootfs
    stage fetch "Lấy script và cấu hình từ app PyEA" st_fetch
    run_inner || exit $?
    stage launcher "Tạo lệnh khởi động MT5 (và tự chạy khi mở máy nếu có Termux:Boot)" st_launcher
    sup_event install stage=login state=start detail="bật MT5, đăng nhập tài khoản và nối EA vào app"
    bash "$BASE/pyea-start-mt5.sh" start || die_stage login "không bật được MT5 bằng pyea-start-mt5.sh"
    say ""
    say "XONG PHẦN CÀI. MT5 đang khởi động và đăng nhập; app PyEA sẽ báo «Đã nối» (hoặc lý do nếu lỗi)."
    say "Từ nay muốn bật lại MT5: bash ~/pyea-start-mt5.sh   (dừng: bash ~/pyea-start-mt5.sh stop)."
    say "Muốn tự chạy sau khi khởi động lại điện thoại: cài Termux:Boot (F-Droid) và mở nó một lần. Android 12+: tắt hạn chế tiến trình con trong Tuỳ chọn nhà phát triển."
    ;;
  inner)
    take_lock
    export DEBIAN_FRONTEND=noninteractive
    stage apt "Cài thư viện nền trong Debian (Xvfb, X11, font...)" st_apt chk_apt
    stage box64 "Cài Box64 (lớp dịch x86-64 sang ARM)" st_box64 chk_box64
    stage wine "Tải Wine 64-bit $WINE_VER" st_wine chk_wine
    stage prefix "Khởi tạo Wine (lần đầu hơi lâu)" st_prefix chk_prefix
    stage mt5 "Tải và cài MetaTrader 5" st_mt5 chk_mt5
    stage provision "Chép EA cầu nối và cấu hình từ app" st_provision
    stage compile "Biên dịch EA cầu nối" st_compile chk_compile
    ;;
  *) echo "chế độ không rõ: $MODE (outer|inner)"; exit 64 ;;
esac
exit 0
