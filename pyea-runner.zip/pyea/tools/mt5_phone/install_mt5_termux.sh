#!/usr/bin/env bash
# PyEA - CÀI TỰ ĐỘNG MT5 THẬT chạy trong giả lập trên điện thoại (Termux + proot Debian + Box64 + Wine + MT5 + EA cầu nối PyEABridge).
# Người dùng chỉ nhập login/mật khẩu/server trong app, dán MỘT lệnh vào Termux; mọi bước còn lại do script này làm và báo tiến trình về app.
# CHƯA KIỂM TRÊN ĐIỆN THOẠI THẬT (sandbox x86, chặn mạng ra ngoài). Phần LOGIC (các bước, chạy lại làm tiếp, báo lỗi về app, cấp file, xoá mật khẩu)
# đã test bằng lệnh giả: tests/test_mt5_install.py. Phần Box64/Wine/MT5 chạy thật hay không CHỈ biết khi chạy trên máy thật.
#
# Dùng (trong Termux, bản F-Droid/GitHub - KHÔNG dùng bản Google Play đã cũ):   PYEA_TOKEN=... bash install_mt5_termux.sh
#   (app tạo sẵn lệnh dán 1 lần: nó tự lấy script này từ app qua cổng cục bộ 127.0.0.1 rồi chạy)
# Chạy lại cùng lệnh được: các bước đã xong tự bỏ qua (kiểm bằng trạng thái thật, không chỉ cờ), bước lỗi làm tiếp.
#   outer (mặc định) = phần chạy trong Termux: kiểm máy, gói Termux, tạo Debian, lấy file từ app, GỌI phần trong, tạo lệnh khởi động, bật MT5
#   inner            = phần chạy BÊN TRONG Debian (do outer gọi): thư viện, Box64, Wine, tiền tố Wine, cài MT5, chép + biên dịch EA
# Biến (đều tuỳ chọn):
#   PYEA_TOKEN / PYEA_TOKEN_FILE / PYEA_HOST / PYEA_PORT   kênh về app (token = «mt5ea_token»)
#   PYEA_REDO=wine,mt5 (hoặc all)   ép làm lại các bước đó dù đã có
#   WINE_VER (mặc định 11.19; tự lùi về 10.12 nếu 11.19 không chạy được) / WINE_URL    bản Wine 64-bit của Kron4ek dùng với Box64 (xem docs/MT5_QUICK.md)
#   WINE_FLAVOR     vanilla | staging (mặc định: vanilla; chỉ đổi khi BẠN đặt - script KHÔNG tự đổi; bản staging cùng số WINE_VER phải có sẵn ở Kron4ek, chưa kiểm với 11.19)
#   WIN_VER         Windows mà Wine khai báo cho bộ cài (mặc định win11; ghi vào HKCU\Software\Wine\Version)
#   MT5_SETUP_URL   bộ cài MT5 (mặc định bản chung của MetaQuotes; sàn có bộ cài riêng thì đặt link của sàn)
#   BOX64_PKG       gói Box64 (mặc định box64-android)
#   MIN_FREE_KB     dung lượng trống tối thiểu (mặc định 3000000 ≈ 3 GB, ƯỚC LƯỢNG chưa đo)
#   HB_EVERY        giây giữa các lần báo «còn chạy» về app (mặc định 10)
#   PREFIX_TIMEOUT  tổng giây tối đa cho bước tạo tiền tố Wine (mặc định 900); WINE_STALL_S = giây CPU Wine đứng im thì thôi chờ (mặc định 120); PS_EVERY = giây giữa các mẫu tiến trình (30)
set -u

MODE="${1:-outer}"
PYEA_HOST="${PYEA_HOST:-127.0.0.1}"; PYEA_PORT="${PYEA_PORT:-18765}"
if [ -z "${PYEA_TOKEN:-}" ] && [ -n "${PYEA_TOKEN_FILE:-}" ] && [ -r "$PYEA_TOKEN_FILE" ]; then PYEA_TOKEN="$(tr -d '\r\n' < "$PYEA_TOKEN_FILE")"; fi
PYEA_TOKEN="${PYEA_TOKEN:-}"

# >>> pyea-common (BẢN SAO y hệt trong run_mt5_termux.sh; tests/test_mt5_install.py kiểm hai bản giống nhau)
pesc() { local v="$1"; v=${v//%/%25}; v=${v//|/%7C}; v=${v//=/%3D}; v=${v//$'\r'/%0D}; v=${v//$'\n'/%0A}; printf '%s' "$v"; }
punesc() { local v="$1"; v=${v//%0A/$'\n'}; v=${v//%0D/$'\r'}; v=${v//%3D/=}; v=${v//%7C/|}; v=${v//%25/%}; printf '%s' "$v"; }
# sup_send "SEVT|kind=x|..." ...   (mỗi lần mở một kết nối ngắn; thất bại thì bỏ qua, không làm hỏng giám sát)
sup_send() {
  [ -n "$PYEA_TOKEN" ] || return 0
  ( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" || exit 1
    printf 'SUPHELLO|v=1|token=%s\n' "$PYEA_TOKEN" >&3
    for l in "$@"; do printf '%s\n' "$l" >&3; done
    sleep 0.2 ) 2>/dev/null
  return 0
}
sup_event() { local kind="$1"; shift; local m="SEVT|kind=$kind" kv; for kv in "$@"; do m="$m|${kv%%=*}=$(pesc "${kv#*=}")"; done; sup_send "$m"; }
sup_log() { sup_send "SLOG|lvl=$1|m=$(pesc "$2")"; }
# sup_get tên_file đích  -> 0 nếu lấy và ghi được
sup_get() {
  local name="$1" dest="$2" line b64 err
  [ -n "$PYEA_TOKEN" ] || { echo "thiếu PYEA_TOKEN"; return 2; }
  line=$( exec 3<>"/dev/tcp/$PYEA_HOST/$PYEA_PORT" 2>/dev/null || exit 1
          printf 'SUPHELLO|v=1|token=%s\nGET|name=%s\n' "$PYEA_TOKEN" "$name" >&3
          while IFS= read -r -t 10 -u 3 l; do case "$l" in FILE\|*) printf '%s' "$l"; break;; esac; done ) || { echo "không nối được app ($PYEA_HOST:$PYEA_PORT)"; return 1; }
  [ -n "$line" ] || { echo "app không trả lời (sai token? app chưa bật nguồn mt5ea?)"; return 1; }
  err=""; b64=""
  case "$line" in *"|err="*) err="${line#*|err=}"; err="${err%%|*}";; esac
  case "$line" in *"|b64="*) b64="${line#*|b64=}"; b64="${b64%%|*}"; b64="$(punesc "$b64")";; esac
  [ -z "$err" ] || { echo "app từ chối: $(punesc "$err")"; return 1; }
  mkdir -p "$(dirname "$dest")" && printf '%s' "$b64" | base64 -d > "$dest.tmp" && mv "$dest.tmp" "$dest" || { echo "không ghi được $dest"; return 1; }
  return 0
}
# <<< pyea-common

# ---------------------------------------------------------------------------------------------- đường dẫn
DISTRO="${PYEA_DISTRO:-debian}"
PREFIX_DIR="${PREFIX:-/data/data/com.termux/files/usr}"
ROOTFS="${PYEA_ROOTFS:-$PREFIX_DIR/var/lib/proot-distro/installed-rootfs/$DISTRO}"
GUEST_ROOT="${PYEA_GUEST_ROOT:-/root}"             # thư mục root như Debian-bên-trong thấy
HOST_ROOT="${PYEA_HOST_ROOT:-$ROOTFS/root}"        # cùng thư mục đó nhìn từ Termux
if [ "$MODE" = inner ]; then BASE="$GUEST_ROOT"; else BASE="${PYEA_BASE:-$HOME}"; fi
STATE_DIR="$BASE/.pyea"; LOGF="${PYEA_INSTALL_LOG:-$STATE_DIR/install.log}"
HB_EVERY="${HB_EVERY:-10}"
# MỘT bản Wine mặc định, không thử-và-đoán theo từng máy: 11.19 (Kron4ek). Lý do là BẰNG CHỨNG THẬT trên máy Cat S52 (Android 10, nhân 4.9): với Wine 10.12 bộ cài MT5 dừng ở hộp thoại
# «A debugger has been found running in your system...» (ảnh chụp màn hình ảo, log v11). Lớp bảo vệ MetaQuotes gọi syscall Windows TRỰC TIẾP; Wine chỉ xử lý được từ 11.5 (Syscall User Dispatch,
# sửa bug WineHQ 58043 từ 11.6), còn Box64 từ 0.4.4 giả lập phần SUD đó. 11.19 là bản một dự án khác đã kiểm trên bộ cài MT5 (build 6266); 11.20 có lỗi văng khi khởi động nên không dùng.
# CHƯA biết 11.19 có chạy được trên nhân 4.9/39-bit không (8.19 và 9.7 từng lỗi «map_fixed_area out of memory», 10.12 thì chạy) -> nếu 11.19 không khởi động nổi, script lùi MỘT lần về WINE_SAFE_VER
# (10.12, đã chạy được trên máy thật), nhớ lại trong $WINEVER_F và ghi lý do vào chẩn đoán. Người dùng đặt WINE_VER/WINE_URL thì giữ nguyên, không tự lùi.
WINE_DEFAULT_VER="${WINE_DEFAULT_VER:-11.19}"; WINE_SAFE_VER="${WINE_SAFE_VER:-10.12}"
WINEVER_F="$STATE_DIR/wine_ver"; WINEFB_F="$STATE_DIR/wine_fallback.txt"       # bản Wine đã chốt sau khi lùi / lý do lùi
WINE_VER_USER="${WINE_VER:-}"
if [ -n "$WINE_VER_USER" ]; then WINE_VER="$WINE_VER_USER"
elif [ -s "$WINEVER_F" ]; then WINE_VER="$(head -1 "$WINEVER_F")"
else WINE_VER="$WINE_DEFAULT_VER"; fi
WINE_WOW64_VER="${WINE_WOW64_VER:-$WINE_VER}"      # bản Wine «wow64» (chạy được file .exe 32-bit không cần thư viện 32-bit); chỉ tải khi bộ cài MT5 là 32-bit. Cùng số bản với WINE_VER
WINE_DIR="$GUEST_ROOT/wine64"; WINEPREFIX_DIR="$GUEST_ROOT/.wine-mt5"; DL="$GUEST_ROOT/dl"; ENVF="$GUEST_ROOT/.pyea_env.sh"; MT5_LINK="$GUEST_ROOT/mt5"
WRAP_DIR="$GUEST_ROOT/.pyea_bin"      # 2 script nhỏ (wineserver, wine) để Wine tìm đúng chương trình qua Box64
PFX_OK="$STATE_DIR/prefix.ok"; DIAGF="$STATE_DIR/wine_diag.txt"; WB_OUT="$DL/wineboot.out"
MT5_PS_F="$STATE_DIR/mt5_ps.txt"; MT5_TRACE="$DL/mt5setup.out"; MT5_STAMP="$STATE_DIR/mt5_start.stamp"   # mẫu theo thời gian / vết đầy đủ / mốc thời gian của bộ cài MT5
MT5_PROBE_F="$STATE_DIR/mt5_probe.txt"; MT5_SHOT_F="$STATE_DIR/mt5_screen.b64"; FLAVOR_F="$STATE_DIR/wine_flavor"   # kết quả «thăm dò» bộ cài lúc đứng im (chữ trong cửa sổ, luồng chờ) / ảnh màn hình ảo (xwd.gz.b64) / kiểu Wine đã chọn (staging|vanilla)
MT5_BEFORE="$STATE_DIR/mt5_before.txt"; MT5_REG="$STATE_DIR/mt5_dir"; MT5_HOME_DIR="$WINEPREFIX_DIR/drive_c/pyea-mt5"   # chữ ký terminal64.exe trước khi cài / sổ «link bộ cài -> thư mục MT5» (mt5_dir.<khoá>) / nơi giữ MỖI link một thư mục riêng
# Lớp đệm LD_PRELOAD cho Box64 (app chép file vào $SHIM_SO; mã nguồn tools/mt5_phone/shim/pyea_noexec.c). Chỉ BẬT khi chính lỗi «failed to set ... protection ...
# noexec filesystem?» của Wine xuất hiện (PYEA_SHIM=auto, mặc định); PYEA_SHIM=1 luôn bật, PYEA_SHIM=0 tắt hẳn. Khi bật, `box64` trong PATH là script bọc.
SHIM_SO="$GUEST_ROOT/pyea/pyea_noexec.so"; SHIM_BIN="$GUEST_ROOT/.pyea_shim"; SHIM_FLAG="$STATE_DIR/shim.on"; SHIM_LOG="$STATE_DIR/shim.log"; PROBE_F="$STATE_DIR/exec_probe.txt"
PS_F="$STATE_DIR/wineboot_ps.txt"      # mẫu tiến trình Wine theo thời gian lúc tạo tiền tố (bận tính toán hay đứng im?)
# Tắt hộp thoại cài Wine Mono / Wine Gecko và bộ tạo menu. Khi tạo tiền tố MỚI mà có màn hình (Xvfb), Wine bật các hộp thoại «tải Mono/Gecko?» và CHỜ NGƯỜI BẤM nút:
# trong Xvfb không ai bấm nên wineboot đứng, tiến trình đầu bỏ chờ sau đúng 300 s («run_wineboot boot event wait timed out») rồi chết «could not load kernel32.dll c0000135».
# Cách tắt chuẩn trong tài liệu Wine/winetricks cho môi trường không người dùng; MT5 chạy EA không cần .NET hay trình duyệt IE nhúng. run_mt5_termux.sh đã đặt đúng giá trị này.
WINE_DLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=d"
MT5_URL_DEFAULT="https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe"
ERR=""; HB_WATCH=""

mkdir -p "$STATE_DIR" 2>/dev/null
log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOGF" 2>/dev/null; }
say() { printf '%s\n' "$*"; log "$*"; }
redo() { case ",${PYEA_REDO:-}," in *",$1,"*|*",all,"*) return 0;; esac; return 1; }

die_stage() {   # id lý_do   - báo lỗi về app (kèm đuôi nhật ký) rồi thoát; chạy lại cùng lệnh sẽ làm tiếp từ bước này
  local id="$1" msg="$2" tl
  tl=$(tail -n 12 "$LOGF" 2>/dev/null | tr -d '\r' | tr '\n' ';' | cut -c1-700)
  say "✗ LỖI ở bước «$id»: $msg"
  say "  Chạy lại CÙNG lệnh để làm tiếp từ bước này. Nhật ký: $LOGF"
  [ -z "$tl" ] || say "  đuôi nhật ký: $tl"
  sup_event install stage="$id" state=fail detail="$msg | $tl"
  exit 1
}

# retry N lệnh...   (mạng di động hay đứt: thử lại, chờ lâu dần)
retry() { local n="$1" i=1; shift; while true; do "$@" && return 0; [ "$i" -ge "$n" ] && return 1; log "lệnh lỗi (lần $i/$n): $*"; sleep "$(awk -v i="$i" -v b="${RETRY_SLEEP:-4}" 'BEGIN{print i*b}')"; i=$(( i + 1 )); done; }

# hb id lệnh...   chạy lệnh (đầu ra vào nhật ký), cứ HB_EVERY giây báo «còn chạy» về app + in dấu chấm; trả mã thoát của lệnh.
# HB_WATCH=<file/thư mục> thì báo kèm dung lượng hiện có (để thấy tiến độ tải).
hb() {
  local id="$1" pid rc last now sz=""; shift
  "$@" >>"$LOGF" 2>&1 &
  pid=$!; last=$(date +%s)
  while kill -0 "$pid" 2>/dev/null; do
    sleep 0.2
    now=$(date +%s)
    if [ $(( now - last )) -ge "$HB_EVERY" ]; then
      last=$now; sz=""
      if [ -n "$HB_WATCH" ] && [ -e "$HB_WATCH" ]; then sz="$(du -sk "$HB_WATCH" 2>/dev/null | awk '{printf "%d MB", $1/1024}')"; fi
      printf '.'
      sup_event install stage="$id" state=progress detail="${sz:+đã có $sz, }vẫn đang chạy"
    fi
  done
  wait "$pid"; rc=$?
  HB_WATCH=""
  return $rc
}

# stage id nhãn hàm [hàm_kiểm_đã_xong]
stage() {
  local id="$1" label="$2" fn="$3" chk="${4:-}"
  if [ -n "$chk" ] && ! redo "$id" && "$chk" >/dev/null 2>&1; then
    say "✓ $label - đã có sẵn, bỏ qua"; sup_event install stage="$id" state=skip detail="$label"; return 0
  fi
  say "▶ $label ..."; sup_event install stage="$id" state=start detail="$label"
  ERR=""
  "$fn" || die_stage "$id" "${ERR:-không rõ lý do}"
  say "✓ $label"; sup_event install stage="$id" state=ok detail="$label"
  return 0
}

# ---------------------------------------------------------------------------------------------- OUTER (Termux)
st_precheck_do() {
  local arch free need="${MIN_FREE_KB:-3000000}"
  arch="${PYEA_ARCH:-$(uname -m)}"
  case "$arch" in
    aarch64|arm64) ;;
    *) ERR="CPU báo «$arch». Cần Termux bản 64-bit ARM (aarch64) trên điện thoại 64-bit; máy 32-bit/x86 không chạy được Box64. Tải Termux arm64-v8a ở F-Droid/GitHub."; return 1;;
  esac
  free=$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2{print $4}')
  if [ -n "$free" ] && [ "$free" -lt "$need" ] 2>/dev/null; then
    ERR="Còn trống $(( free / 1024 )) MB, cần tối thiểu khoảng $(( need / 1024 )) MB (ước lượng cho Debian + Wine + MT5). Dọn bớt rồi chạy lại."; return 1
  fi
  if [ -z "$PYEA_TOKEN" ]; then ERR="thiếu PYEA_TOKEN: hãy dùng đúng lệnh app tạo sẵn (nó đã kèm token)."; return 1; fi
  return 0
}
termux_pkgs_do() {
  pkg update -y && pkg install -y -o Dpkg::Options::=--force-confold proot-distro curl wget procps
}
st_termux_pkgs() {
  hb termux_pkgs retry 3 termux_pkgs_do || { ERR="pkg lỗi: kiểm tra Wi-Fi/4G. Nếu báo không tải được gói: chạy «termux-change-repo», chọn kho khác, rồi chạy lại lệnh."; return 1; }
}
chk_termux_pkgs() { command -v proot-distro && command -v curl && command -v wget; }
st_rootfs() {
  hb rootfs retry 2 proot-distro install "$DISTRO" || { ERR="proot-distro không cài được Debian (thiếu dung lượng/mạng?)."; return 1; }
  chk_rootfs || { ERR="proot-distro báo xong nhưng không thấy hệ Debian ở $ROOTFS."; return 1; }
}
chk_rootfs() { [ -d "$ROOTFS/root" ] && { [ -e "$ROOTFS/bin/bash" ] || [ -e "$ROOTFS/usr/bin/bash" ]; }; }
st_fetch() {
  local r
  mkdir -p "$HOST_ROOT/pyea" || { ERR="không tạo được $HOST_ROOT/pyea"; return 1; }
  for f in install_mt5_termux.sh run_mt5_termux.sh pyea_relay.py; do
    r=$(sup_get "$f" "$HOST_ROOT/pyea/$f") || { ERR="Không lấy được «$f» từ app: $r. App phải đang mở, đã bấm «Bắt đầu» trong «Kết nối MT5 nhanh»; đừng tắt app trong lúc cài."; return 1; }
  done
  ( umask 077; printf '%s' "$PYEA_TOKEN" > "$HOST_ROOT/pyea/token" ) || { ERR="không ghi được token"; return 1; }
  chmod 600 "$HOST_ROOT/pyea/token" 2>/dev/null
  return 0
}
run_inner() {
  local rc=0
  say "Bước tiếp theo chạy BÊN TRONG Debian (lâu nhất: tải Wine + MT5, có thể hàng chục phút; cứ để màn hình sáng, app báo tiến trình)."
  proot-distro login "$DISTRO" --shared-tmp -- env PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT" PYEA_GUEST_ROOT="$GUEST_ROOT" \
    PYEA_REDO="${PYEA_REDO:-}" HB_EVERY="$HB_EVERY" WINE_VER="$WINE_VER_USER" WINE_URL="${WINE_URL:-}" WINE_FLAVOR="${WINE_FLAVOR:-}" WIN_VER="${WIN_VER:-}" MT5_SETUP_URL="${MT5_SETUP_URL:-}" BOX64_PKG="${BOX64_PKG:-}" \
    PYEA_INSTALL_LOG="$GUEST_ROOT/.pyea/install.log" \
    bash "$GUEST_ROOT/pyea/install_mt5_termux.sh" inner || rc=$?
  return $rc
}
st_launcher() {
  local home="$BASE" sh_bash="${PREFIX_DIR}/bin/bash"
  mkdir -p "$home/.pyea" "$home/.termux/boot" 2>/dev/null
  cat > "$home/pyea-start-mt5.sh" <<EOF
#!/usr/bin/env bash
# Khởi động / dừng MT5 trong giả lập + giám sát (do trình cài PyEA tạo). Dùng: bash ~/pyea-start-mt5.sh [start|stop|status]
PIDF="\$HOME/.pyea/run.pid"; OUT="\$HOME/.pyea/run.out"
mkdir -p "\$HOME/.pyea"
alive() { [ -f "\$PIDF" ] && kill -0 "\$(cat "\$PIDF" 2>/dev/null)" 2>/dev/null; }
case "\${1:-start}" in
  status) if alive; then echo "MT5: đang chạy (pid \$(cat "\$PIDF"))"; else echo "MT5: không chạy"; exit 1; fi ;;
  stop)
    alive && kill "\$(cat "\$PIDF")" 2>/dev/null
    proot-distro login $DISTRO -- bash -c 'pkill -TERM -f "run_mt5_[t]ermux.sh"; pkill -TERM -f "pyea_[r]elay.py"; sleep 2; pkill -KILL -f "[t]erminal64.exe"; pkill -KILL -x wineserver' >/dev/null 2>&1
    rm -f "\$PIDF"; echo "đã dừng MT5" ;;
  *)
    if alive; then echo "MT5 đã đang chạy (pid \$(cat "\$PIDF"))"; exit 0; fi
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    nohup proot-distro login $DISTRO --shared-tmp -- env PYEA_ENV="$GUEST_ROOT/.pyea_env.sh" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" run >> "\$OUT" 2>&1 &
    echo \$! > "\$PIDF"; disown 2>/dev/null
    echo "đã bật MT5 (nhật ký: \$OUT). Tiến trình đăng nhập hiện trong app PyEA." ;;
esac
EOF
  cat > "$home/.termux/boot/pyea-mt5.sh" <<EOF
#!$sh_bash
# Chỉ chạy khi đã cài và mở Termux:Boot ít nhất 1 lần. Bật MT5 sau khi khởi động lại điện thoại.
termux-wake-lock 2>/dev/null
bash "\$HOME/pyea-start-mt5.sh" start
EOF
  chmod +x "$home/pyea-start-mt5.sh" "$home/.termux/boot/pyea-mt5.sh" 2>/dev/null
  [ -x "$home/pyea-start-mt5.sh" ] || { ERR="không tạo được lệnh khởi động"; return 1; }
  return 0
}

# ---------------------------------------------------------------------------------------------- INNER (Debian)
# Wine tự tìm wineserver (và «wine» để mở tiến trình Windows mới) theo đường dẫn của chính nó rồi execv(). Qua Box64+proot cách đó có thể hỏng
# («wine: could not exec wineserver» - log thật với Wine 10.12). Tài liệu wine(1) có hai biến WINESERVER và WINELOADER đúng để chỉ đường: trỏ chúng vào
# 2 script bash nhỏ (chạy native, không phụ thuộc cách Box64 tự chặn execve) gọi `box64 <chương trình>`. Hợp lệ với MỌI máy, không phải mẹo riêng một máy.
write_wrappers() {
  mkdir -p "$WRAP_DIR" || return 1
  printf '#!/bin/sh\nexec box64 "%s/bin/wineserver" "$@"\n' "$WINE_DIR" > "$WRAP_DIR/wineserver"
  printf '#!/bin/sh\nexec box64 "%s/bin/wine64" "$@"\n' "$WINE_DIR" > "$WRAP_DIR/wine"
  chmod 755 "$WRAP_DIR/wineserver" "$WRAP_DIR/wine"
}
shim_avail() { [ -s "$SHIM_SO" ] && [ "$(elf_kind "$SHIM_SO")" = aarch64 ]; }
shim_active() { case "${PYEA_SHIM:-auto}" in 0) return 1;; 1) shim_avail;; *) [ -e "$SHIM_FLAG" ] && shim_avail;; esac; }
write_shim_wrapper() {   # bật: tạo $SHIM_BIN/box64 (đặt LD_PRELOAD rồi chạy box64 thật); tắt: xoá
  local real clean
  if shim_active; then
    clean=$(printf '%s' "$PATH" | tr ':' '\n' | grep -vxF "$SHIM_BIN" | tr '\n' ':'); clean="${clean%:}"
    real=$(PATH="$clean" command -v box64 2>/dev/null); [ -n "$real" ] || real=/usr/local/bin/box64
    mkdir -p "$SHIM_BIN" && printf '#!/bin/sh\nPYEA_SHIM_LOG="%s" LD_PRELOAD="%s${LD_PRELOAD:+:$LD_PRELOAD}" exec "%s" "$@"\n' "$SHIM_LOG" "$SHIM_SO" "$real" > "$SHIM_BIN/box64" && chmod 755 "$SHIM_BIN/box64"
  else
    rm -f "$SHIM_BIN/box64" 2>/dev/null
  fi
  return 0
}
shim_env_lines() {   # dòng thêm vào file môi trường khi lớp đệm đang bật (PATH chỉ thêm một lần)
  shim_active || return 0
  printf 'case ":$PATH:" in *":%s:"*) ;; *) export PATH="%s:$PATH";; esac\nexport PYEA_SHIM_LOG="%s"\n' "$SHIM_BIN" "$SHIM_BIN" "$SHIM_LOG"
}
write_env() {   # $1 = thư mục MT5 (có thể rỗng khi chưa cài)
  write_wrappers
  write_shim_wrapper
  cat > "$ENVF" <<EOF
# do install_mt5_termux.sh tạo; run_mt5_termux.sh nạp file này
export WINE_DIR="$WINE_DIR"
export BOX64_PATH="$WINE_DIR/bin"
export BOX64_LD_LIBRARY_PATH="$WINE_DIR/lib:$WINE_DIR/lib64:$WINE_DIR/lib/wine/x86_64-unix"
export BOX64_LOG=0 BOX64_NOBANNER=1
export WINEPREFIX="$WINEPREFIX_DIR" WINEARCH=win64 WINEDEBUG=-all
export WINEDLLOVERRIDES="$WINE_DLLOVERRIDES"
export WINESERVER="$WRAP_DIR/wineserver" WINELOADER="$WRAP_DIR/wine"
$(shim_env_lines)
export DISPLAY=:99
export PYEA_TOKEN_FILE="$GUEST_ROOT/pyea/token" PYEA_HOST="$PYEA_HOST" PYEA_PORT="$PYEA_PORT"
export PYEA_LOGIN_WATCH=1 PYEA_SYNC_CFG=1
export MT5_DIR="${1:-}"
EOF
  # shellcheck disable=SC1090
  . "$ENVF"
}
start_xvfb() {
  [ "${NO_XVFB:-}" = "1" ] && return 0
  pgrep -x Xvfb >/dev/null 2>&1 && return 0
  ( Xvfb "$DISPLAY" -screen 0 800x600x16 -nolisten tcp >/dev/null 2>&1 & )
  sleep 1
  return 0
}
ws_kill() { box64 "$WINE_DIR/bin/wineserver" -k >/dev/null 2>&1; return 0; }
find_terminal() { find "$WINEPREFIX_DIR/drive_c" -maxdepth 4 -iname terminal64.exe 2>/dev/null | head -1; }
# ---- MỖI link bộ cài MỘT thư mục MT5 riêng (không ghi đè nhau). Sổ: $MT5_REG.<khoá của link> chứa đường dẫn thư mục. Chế độ /portable nên mọi thứ của một MT5 (tài khoản, server đã biết, EA, startup.ini) nằm gọn trong thư mục đó.
url_key() { printf '%s' "$1" | cksum | awk '{print $1}'; }
want_url() { printf '%s' "${MT5_SETUP_URL:-$MT5_URL_DEFAULT}"; }
reg_file() { printf '%s.%s' "$MT5_REG" "$(url_key "$(want_url)")"; }
reg_dir() { cat "$(reg_file)" 2>/dev/null | head -1; }
has_terminal() { [ -n "$1" ] && [ -n "$(find "$1" -maxdepth 1 -iname terminal64.exe 2>/dev/null | head -1)" ]; }
terminal_sigs() { find "$WINEPREFIX_DIR/drive_c" -maxdepth 4 -iname terminal64.exe -printf '%p|%s|%T@\n' 2>/dev/null | sort; }
# terminal64.exe MỚI hoặc VỪA BỊ GHI ĐÈ so với ảnh chụp $MT5_BEFORE (bản của link khác đã có sẵn thì không tính là «bộ cài này xong rồi»)
new_terminal() { terminal_sigs | grep -vxFf "$MT5_BEFORE" 2>/dev/null | head -1 | cut -d'|' -f1; }

apt_all() { apt-get update && apt-get install -y --no-install-recommends ca-certificates wget gnupg xz-utils xvfb xauth procps; }
APT_OPT="cabextract libx11-6 libxext6 libxrender1 libxcursor1 libxi6 libxrandr2 libxfixes3 libxcomposite1 libxinerama1 libxxf86vm1 libfreetype6 libfontconfig1 libgnutls30 libglib2.0-0 libdbus-1-3 libasound2 libasound2t64 libpulse0 libgl1 fonts-dejavu-core python3 x11-utils"
apt_opt() {   # gói tuỳ chọn: cài cả loạt; hỏng thì thử từng gói, gói không có (tên khác theo bản Debian) thì bỏ qua
  # shellcheck disable=SC2086
  apt-get install -y --no-install-recommends $APT_OPT && return 0
  local p; for p in $APT_OPT; do apt-get install -y --no-install-recommends "$p" || log "gói tuỳ chọn không cài được: $p"; done
  return 0
}
st_apt() {
  export DEBIAN_FRONTEND=noninteractive
  hb apt retry 3 apt_all || { ERR="apt không cài được gói nền (Xvfb, wget, gnupg...). Thường do mạng đứt hoặc hết dung lượng."; return 1; }
  hb apt apt_opt
  return 0
}
chk_apt() { command -v Xvfb && command -v wget && command -v gpg && command -v xz && command -v pgrep; }

box64_do() {
  wget -q -O /etc/apt/sources.list.d/box64.list "${BOX64_LIST_URL:-https://ryanfortner.github.io/box64-debs/box64.list}" || return 1
  wget -q -O "$DL/box64.gpg" "${BOX64_KEY_URL:-https://ryanfortner.github.io/box64-debs/KEY.gpg}" || return 1
  gpg --batch --yes --dearmor -o /etc/apt/trusted.gpg.d/box64-debs-archive-keyring.gpg "$DL/box64.gpg" || return 1
  apt-get update || return 1
  apt-get install -y "${BOX64_PKG:-box64-android}" || { [ -z "${BOX64_PKG:-}" ] && apt-get install -y box64; }
}
st_box64() {
  mkdir -p "$DL"
  hb box64 retry 2 box64_do || { ERR="Không cài được Box64 từ kho ryanfortner.github.io/box64-debs (kho tạm hỏng/mạng đứt?)."; return 1; }
  box64 --version >>"$LOGF" 2>&1 || { ERR="Box64 đã cài nhưng không chạy được («box64 --version» lỗi). CPU/Android của máy này có thể không hợp."; return 1; }
}
chk_box64() { command -v box64 && box64 --version 2>&1 | grep -qi box64; }

# has_re 'mẫu' 'văn bản' -> 0 nếu khớp. KHÔNG dùng `printf | grep -q`: grep -q thoát ngay khi thấy khớp, printf còn đang ghi dở thì in «printf: write error: Broken pipe» (log thật v9). Ở đây grep -c đọc hết đầu vào.
has_re() { local n; n=$(printf '%s' "${2:-}" | grep -cE -- "$1"); [ "${n:-0}" -gt 0 ] 2>/dev/null; }
wine_variant() { cat "$WINE_DIR/.pyea_variant" 2>/dev/null || echo "amd64-$WINE_VER"; }
# Kiểu Wine: vanilla = Kron4ek «wine-<bản>-amd64»; staging = «wine-<bản>-staging-amd64» (Wine Staging, có thêm bản vá ntdll-Syscall_Emulation). WINE_FLAVOR ép cố định; không thì theo tệp $FLAVOR_F (script tự ghi khi chuyển).
wine_flavor() {
  case "${WINE_FLAVOR:-}" in staging|vanilla) echo "$WINE_FLAVOR"; return 0;; esac
  if [ "$(head -1 "$FLAVOR_F" 2>/dev/null)" = staging ]; then echo staging; else echo vanilla; fi
}
wine_var_want() { if [ "$(wine_flavor)" = staging ]; then echo staging-amd64; else echo amd64; fi; }
# Bản Wine đang cài có đúng kiểu mong muốn không (bản wow64 để nguyên: nó chỉ có khi bộ cài là 32-bit)
wine_flavor_ok() {
  case "$(wine_variant)" in
    *wow64*) return 0;;
    *staging*) [ "$(wine_flavor)" = staging ];;
    *) [ "$(wine_flavor)" != staging ];;
  esac
}
wine_wow64() { case "$(wine_variant)" in *wow64*) return 0;; esac; return 1; }
# Bản Wine đang cài có đúng BẢN đã chọn không (đổi WINE_VER, hoặc nâng mặc định 10.12 -> 11.19, thì phải tải bản mới và dựng lại tiền tố)
wine_version_ok() {
  case "$(wine_variant)" in
    *wow64*) [ "$(wine_variant)" = "amd64-wow64-$WINE_WOW64_VER" ];;
    *) [ "$(wine_variant)" = "$(wine_var_want)-$WINE_VER" ];;
  esac
}
# Lùi về WINE_SAFE_VER khi bản mặc định không chạy được trên máy này (chỉ khi KHÔNG phải người dùng tự chọn; không lùi lần hai)
wine_can_fall_back() {
  [ -z "$WINE_VER_USER" ] && [ -z "${WINE_URL:-}" ] && [ "$WINE_VER" != "$WINE_SAFE_VER" ] && ! wine_wow64
}
wine_fall_back() {   # $1 = lý do
  local why="${1:-không rõ}" old="$WINE_VER"
  log "Wine $old không chạy được trên máy này -> lùi về Wine $WINE_SAFE_VER (bản đã chạy được trên máy thật). Lý do: $(printf '%s' "$why" | cut -c1-400)"
  { printf 'Wine %s: ' "$old"; printf '%s' "$why" | tr '\n' ' ' | cut -c1-900; echo; } > "$WINEFB_F" 2>/dev/null
  ws_kill; echo "$WINE_SAFE_VER" > "$WINEVER_F"
  [ "$WINE_WOW64_VER" = "$old" ] && WINE_WOW64_VER="$WINE_SAFE_VER"
  WINE_VER="$WINE_SAFE_VER"
  HB_WATCH="$DL"
  if ! hb wine wine_do; then ERR="Wine $old không chạy được và không tải lại được Wine $WINE_SAFE_VER (mạng/dung lượng?). Lý do ban đầu: $(printf '%s' "$why" | cut -c1-300)"; return 1; fi
  write_env ""
  if ! box64 wine64 --version >>"$LOGF" 2>&1; then ERR="Wine $old không chạy được; Wine $WINE_SAFE_VER cũng không (box64 wine64 --version lỗi). Lý do ban đầu: $(printf '%s' "$why" | cut -c1-300)"; return 1; fi
  return 0
}

wine_get() {   # $1 = amd64 | amd64-wow64, $2 = phiên bản: tải + giải nén THAY bản cũ ở $WINE_DIR, ghi dấu bản vào $WINE_DIR/.pyea_variant
  local var="$1" ver="$2" tb url
  tb="$DL/wine-$ver-$var.tar.xz"
  url="https://github.com/Kron4ek/Wine-Builds/releases/download/$ver/wine-$ver-$var.tar.xz"
  if [ "$var" = amd64 ] && [ -n "${WINE_URL:-}" ]; then url="$WINE_URL"; tb="$DL/wine-custom-$var.tar.xz"; fi
  # Tệp tải về được GIỮ LẠI làm cache (dung lượng không đáng kể so với 20+ phút tải lại): làm lại bước Wine / đổi qua lại amd64 <-> wow64 không tải lại.
  retry 3 wget -c -O "$tb" "$url" || return 1
  rm -rf "$WINE_DIR.new"; mkdir -p "$WINE_DIR.new"
  tar -xJf "$tb" -C "$WINE_DIR.new" --strip-components=1 || { rm -f "$tb"; return 1; }       # tệp cache hỏng/cụt -> xoá để lần sau tải lại sạch
  [ -e "$WINE_DIR.new/bin/wine64" ] || { [ -e "$WINE_DIR.new/bin/wine" ] && ln -s wine "$WINE_DIR.new/bin/wine64"; }   # bản wow64 có thể chỉ có «wine»
  [ -e "$WINE_DIR.new/bin/wine64" ] || return 2
  echo "$var-$ver" > "$WINE_DIR.new/.pyea_variant"
  rm -rf "$WINE_DIR"; mv "$WINE_DIR.new" "$WINE_DIR"
}
wine_do() { wine_get "$(wine_var_want)" "$WINE_VER"; }
st_wine() {
  local rc=0
  mkdir -p "$DL"; write_env ""
  HB_WATCH="$DL"; hb wine wine_do || rc=$?
  case "$rc" in
    0) ;;
    2) ERR="Giải nén Wine xong nhưng không thấy bin/wine64 (file tải về sai bản?)."; return 1;;
    *) ERR="Không tải/giải nén được Wine $WINE_VER (GitHub bị chặn/mạng đứt/hết dung lượng?)."; return 1;;
  esac
  if ! box64 wine64 --version >>"$LOGF" 2>&1; then
    if wine_can_fall_back; then wine_fall_back "«box64 wine64 --version» lỗi (thiếu thư viện hoặc Box64 không chạy được Wine này)"; return $?; fi
    ERR="Wine đã giải nén nhưng «box64 wine64 --version» lỗi: thiếu thư viện hoặc Box64 không chạy được Wine này. Xem nhật ký."; return 1
  fi
}
chk_wine() { [ -e "$WINE_DIR/bin/wine64" ] && wine_flavor_ok && wine_version_ok && write_env "${MT5_DIR:-}" && box64 wine64 --version; }

# pe_kind file -> x64 (PE32+ AMD64) | x86 (PE32, 32-bit) | arm64 | ? (không phải PE / không đọc được). Đọc IMAGE_FILE_HEADER.Machine bằng od.
pe_kind() {
  local f="$1" off sig m
  off=$(od -An -t u4 -j 60 -N 4 "$f" 2>/dev/null | tr -d ' \n')
  case "$off" in ''|*[!0-9]*) echo "?"; return 0;; esac
  sig=$(od -An -t x4 -j "$off" -N 4 "$f" 2>/dev/null | tr -d ' \n')
  [ "$sig" = "00004550" ] || { echo "?"; return 0; }
  m=$(od -An -t x2 -j $(( off + 4 )) -N 2 "$f" 2>/dev/null | tr -d ' \n')
  case "$m" in 8664) echo x64;; 014c) echo x86;; aa64) echo arm64;; *) echo "?($m)";; esac
}

# Tiền tố Wine phải có đủ file hệ thống VÀ chạy thử được một lệnh Windows thật. Trước đây chỉ kiểm có system.reg nên tiền tố làm dở
# (thiếu kernel32.dll -> «wine: could not load kernel32.dll, status c0000135») vẫn bị coi là «đã có sẵn» và vòng cài lặp mãi.
prefix_files_ok() {
  local w="$WINEPREFIX_DIR/drive_c/windows"
  [ -s "$WINEPREFIX_DIR/system.reg" ] && [ -s "$WINEPREFIX_DIR/user.reg" ] && [ -s "$w/system32/kernel32.dll" ] && [ -s "$w/system32/ntdll.dll" ] || return 1
  if wine_wow64; then [ -s "$w/syswow64/kernel32.dll" ] || return 1; fi
  return 0
}
wine_probe() {   # chạy THẬT cmd.exe 64-bit; lỗi gốc của Wine (err+all) nằm trong PROBE_OUT
  PROBE_OUT=$(WINEDEBUG=err+all,fixme-all timeout "${PROBE_TIMEOUT:-180}" box64 wine64 cmd /c "echo PYEA_PROBE_OK" 2>&1)
  has_re 'PYEA_PROBE_OK' "$PROBE_OUT"
}
logsize() { local n; n=$(wc -c < "$LOGF" 2>/dev/null); n="${n//[^0-9]/}"; echo "${n:-0}"; }
# Lỗi gốc ở log thật (Cat S52, Android 10, nhân 4.9): «err:virtual:map_fixed_area out of memory ... try_map_free_area mmap() error Cannot allocate memory ...
# map_image_into_view failed to set 60500020 protection on ntdll.dll» = Wine không dựng được ntdll.dll ở địa chỉ cao. Box64 ghi nhận «Didn't detect 48bits of
# address space, considering it's 39bits»: nhân Android chỉ có không gian địa chỉ ảo 39-bit. Chỉ dùng để CHẨN ĐOÁN (không đổi bản Wine tự động).
addr_err() { has_re 'map_fixed_area out of memory|try_map_free_area' "${1:-}"; }
# Lỗi gốc ở log thật thứ hai (Cat S52, Wine 10.12 + wrapper wineserver): wineserver đã chạy được, rồi
# «err:virtual:map_image_into_view failed to set 60000020 protection on ... ntdll.dll section .text, noexec filesystem?» = mprotect(PROT_EXEC) bị từ chối
# (KHÔNG có dòng map_fixed_area). Trước đây addr_err gộp cả hai nên báo nhầm «39-bit». Giờ tách riêng.
exec_err() { has_re 'failed to set [0-9a-fA-F]+ protection|noexec filesystem|failed to set PROT_EXEC' "${1:-}"; }
probe_tail() { printf '%s' "${PROBE_OUT:-}" | tr -d '\r' | grep -v '^$' | tail -n 4 | tr '\n' ';' | cut -c1-400; }
wb_tail() { tr -d '\r' < "$WB_OUT" 2>/dev/null | grep -v ':trace:' | grep -v '^$' | tail -n 4 | tr '\n' ';' | cut -c1-400; }   # bỏ dòng vết (+loaddll/+process) để thấy lỗi thật
# ELF máy của file: x86_64 | aarch64 | script | ? (đọc e_machine bằng od)
elf_kind() {
  local f="$1" m
  [ -e "$f" ] || { echo "không-có"; return 0; }
  [ "$(head -c2 "$f" 2>/dev/null)" = "#!" ] && { echo script; return 0; }
  [ "$(head -c4 "$f" 2>/dev/null | od -An -c | tr -d ' \n')" = '177ELF' ] || { echo "?"; return 0; }
  m=$(od -An -t x2 -j 18 -N 2 "$f" 2>/dev/null | tr -d ' \n')
  case "$m" in 003e) echo x86_64;; 00b7) echo aarch64;; *) echo "?($m)";; esac
}
# Đo THẬT (không đoán) xem hệ thống có cho mmap/mprotect kèm quyền thực thi không, ngay trong proot (cùng ngữ cảnh SELinux với Box64/Wine).
# Dùng python3 + ctypes của rootfs (apt_opt đã cài). Thử trên: file PE thật của Wine, file tạm do ta ghi, và bộ nhớ ẩn danh. In MỘT dòng.
exec_probe() {   # $1 = file thử (ntdll.dll của Wine), $2 = file tạm sẽ ghi
  command -v python3 >/dev/null 2>&1 || { echo "không có python3 trong rootfs (chưa đo được)"; return 0; }
  timeout 40 python3 - "${1:-}" "${2:-}" 2>&1 <<'PY' | tr '\r\n' '  ' | cut -c1-1100
import ctypes, errno, os, sys
try:
    libc = ctypes.CDLL(None, use_errno=True)
    libc.mmap.restype = ctypes.c_void_p
    libc.mmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_long]
    libc.mprotect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libc.munmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
except Exception as e:
    print("không nạp được libc:", e); sys.exit(0)
R, W, X, PRIV, ANON = 1, 2, 4, 2, 0x20
BAD = ctypes.c_void_p(-1).value
def err():
    e = ctypes.get_errno()
    return errno.errorcode.get(e, str(e))
def mm(prot, flags, fd):
    ctypes.set_errno(0)
    a = libc.mmap(None, 4096, prot, flags, fd, 0)
    return (None, err()) if a in (None, BAD) else (a, "ok")
def mp(a, prot):
    ctypes.set_errno(0)
    return "ok" if libc.mprotect(a, 4096, prot) == 0 else err()
def un(a):
    if a: libc.munmap(a, 4096)
def on_file(path):
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError as e:
        return "không-mở-được(%s)" % errno.errorcode.get(e.errno, e.errno)
    r = []
    try:
        a, s = mm(R | X, PRIV, fd); r.append("map_RX:" + s); un(a)
        a, s = mm(R, PRIV, fd); r.append("R->RX:" + (mp(a, R | X) if a else s)); un(a)
        a, s = mm(R | W, PRIV, fd); r.append("RW->RX:" + (mp(a, R | X) if a else s)); un(a)
        a, s = mm(R | W, PRIV, fd)
        if a:
            c = ctypes.c_ubyte.from_address(a); c.value = c.value          # ghi thật -> trang bị sao chép (COW)
            r.append("đã-ghi->RX:" + mp(a, R | X))
        else:
            r.append("đã-ghi->RX:" + s)
        un(a)
    finally:
        os.close(fd)
    return " ".join(r)
out = []
real, tmp = sys.argv[1], sys.argv[2]
if real: out.append("[file Wine] " + on_file(real))
if tmp:
    try:
        with open(tmp, "wb") as f: f.write(os.urandom(8192))
        out.append("[file tạm] " + on_file(tmp))
    except OSError as e:
        out.append("[file tạm] không ghi được(%s)" % errno.errorcode.get(e.errno, e.errno))
a, s = mm(R | W, PRIV | ANON, -1)
anon = ["RW->RX:" + (mp(a, R | X) if a else s)]; un(a)
a, s = mm(R | W | X, PRIV | ANON, -1); anon.append("RWX:" + s); un(a)
out.append("[bộ nhớ ẩn danh] " + " ".join(anon))
try:
    nx = []
    for line in open("/proc/self/mountinfo"):
        f = line.split(" ")
        if len(f) > 5 and "noexec" in f[5].split(","):
            nx.append(f[4])
    out.append("[mount noexec] " + (",".join(nx[:8]) or "không có") + (" (+%d)" % (len(nx) - 8) if len(nx) > 8 else ""))
except OSError as e:
    out.append("[mount noexec] không đọc được")
try:
    ctx = open("/proc/self/attr/current").read().strip("\0\n ")
except OSError:
    ctx = "?"
try:
    enf = open("/sys/fs/selinux/enforce").read().strip()
except OSError:
    enf = "?"
out.append("[selinux] %s enforce=%s" % (ctx, enf))
print(" | ".join(out))
PY
}
exec_probe_log() {   # đo rồi ghi vào $PROBE_F và nhật ký (mỗi lần chạy bước prefix; rẻ, vài giây)
  local r
  r=$(exec_probe "$WINE_DIR/lib/wine/x86_64-windows/ntdll.dll" "$STATE_DIR/probe.bin"); rm -f "$STATE_DIR/probe.bin"
  printf '%s\n' "$r" > "$PROBE_F" 2>/dev/null
  log "đo quyền thực thi: $r"
}
shim_state_msg() {
  if [ "${PYEA_SHIM:-auto}" = 0 ]; then echo "Lớp đệm pyea_noexec đang bị tắt (PYEA_SHIM=0)."
  elif ! shim_avail; then echo "Không có file lớp đệm $SHIM_SO (APK cũ?)."
  elif shim_active; then echo "Đã bật lớp đệm pyea_noexec (thử lại không PROT_EXEC) mà vẫn lỗi: xem shim.log và «đo quyền thực thi» trong $DIAGF."
  else echo "Lớp đệm pyea_noexec chưa bật."; fi
}
wine_trace() {   # chạy lại wineboot ngắn với kênh «virtual» của Wine để thấy lời gọi nào hỏng (chỉ khi đang chẩn đoán lỗi)
  WINEDEBUG=err+all,warn+virtual timeout 45 box64 wine64 wineboot -i 2>&1 | tr -d '\r' | grep -E 'virtual|err:' | head -n 12 | cut -c1-260 | tr '\n' ';'
  ws_kill
}
# ---- quan sát tiến trình Wine (log thật: wineboot chờ đúng 300 s rồi chết; cần biết con của nó đang BẬN hay ĐỨNG IM, và nó đã mở chương trình gì) ----
# In mỗi tiến trình Wine/Box64 một dòng: pid ppid trạng_thái cpu=<giây CPU tích luỹ> ram=<MB> lệnh. Rỗng nếu không có `ps` hoặc không có tiến trình nào.
wine_ps_line() {
  local o
  command -v ps >/dev/null 2>&1 || return 0
  o=$(ps -eo pid=,ppid=,stat=,cputimes=,rss=,args= 2>/dev/null) || o=$(ps -eo pid=,ppid=,stat=,times=,rss=,args= 2>/dev/null) || return 0
  printf '%s\n' "$o" | awk '($0 ~ /wine|box64/) && ($0 !~ /awk|ps -eo|install_mt5|proot/) { a=$0; sub(/^ *[0-9]+ +[0-9]+ +[^ ]+ +[0-9]+ +[0-9]+ +/, "", a); printf "%s %s %s cpu=%ss ram=%dMB %s\n", $1, $2, $3, $4, int($5/1024), substr(a, 1, 110) }'
}
wine_cpu_total() { wine_ps_line | awk '{ v=$4; sub(/^cpu=/, "", v); sub(/s$/, "", v); s += v; n++ } END { if (n) print s + 0 }'; }
wine_ps_watch() {   # chạy nền: mỗi PS_EVERY giây (30) ghi một mẫu vào $PS_F (tối đa 40 mẫu, mỗi mẫu 8 tiến trình)
  local t0 n=0
  t0=$(date +%s)
  while [ "$n" -lt 40 ]; do
    sleep "${PS_EVERY:-30}"; n=$(( n + 1 ))
    { echo "[+$(( $(date +%s) - t0 ))s]"; wine_ps_line | awk 'NR<=8'; } >> "$PS_F" 2>/dev/null
  done
}
# Wine tự bỏ chờ sau 300 s CỨNG («boot event wait timed out»), nhưng tiến trình wineboot con có thể vẫn đang làm (máy chậm). Đừng giết nó ngay: chờ cho tới khi
# (a) không còn tiến trình Wine nào, (b) hết $1 giây, hoặc (c) tổng CPU của các tiến trình Wine không tăng suốt WINE_STALL_S giây (đứng im = kẹt thật, chờ thêm vô ích).
wait_wine_idle() {
  local t_end cpu last="" quiet=0 q0 now alive step="${WINE_POLL_S:-10}" stall="${WINE_STALL_S:-120}"
  command -v ps >/dev/null 2>&1 || { log "rootfs không có lệnh ps -> không theo dõi được tiến trình Wine con"; return 0; }
  t_end=$(( $(date +%s) + $1 )); q0=$(date +%s)
  while true; do
    now=$(date +%s)
    alive=$(wine_ps_line)
    [ -n "$alive" ] || { log "mọi tiến trình Wine đã thoát"; return 0; }
    [ "$now" -lt "$t_end" ] || { log "hết thời gian chờ mà tiến trình Wine con vẫn chạy"; return 0; }
    cpu=$(wine_cpu_total)
    if [ "$cpu" != "$last" ]; then q0=$now; last="$cpu"; fi
    quiet=$(( now - q0 ))
    [ "$quiet" -lt "$stall" ] || { log "tiến trình Wine con đứng im ${quiet}s (tổng CPU ${cpu:-?}s không tăng) -> không chờ nữa"; return 0; }
    sleep "$step"
  done
}
# Chương trình Windows mà wineboot đã mở (đếm theo tên, lấy từ vết +loaddll/+process; rỗng nếu chưa bật vết). Thấy appwiz.cpl = trình cài Mono/Gecko đang chạy.
wb_children() {
  tr -d '\r' < "$WB_OUT" 2>/dev/null | grep -E 'trace:(loaddll|process):' | grep -ioE '(wineboot|services|rundll32|appwiz|plugplay|winedevice|explorer|msiexec|rpcss|mscoree|mshtml|start|cmd|conhost)\.(exe|dll|cpl)' \
    | tr 'A-Z' 'a-z' | sort | uniq -c | sort -rn | awk '{ printf "%s×%s ", $2, $1 }' | cut -c1-400
}
# Mô tả ngắn một file trong tiền tố: liên kết / cỡ / loại PE / giữ-chỗ (file giả của Wine, ~4 KB, chỉ là chỗ để nạp bản dựng sẵn)
fmeta() {
  local f="$1" b; b=$(basename "$f")
  if [ -L "$f" ]; then echo "$b: liên-kết -> $(readlink "$f")"
  elif [ -e "$f" ]; then echo "$b: $(wc -c < "$f" | tr -d ' ')B $(pe_kind "$f")$(grep -qa 'Wine placeholder' "$f" 2>/dev/null && echo ' giữ-chỗ')"
  else echo "$b: không có"; fi
}
# Chỉ khi lệnh thử cmd.exe chưa chạy được: nạp kernel32 trên CHÍNH tiền tố hỏng với vết +loaddll/+module để thấy đường tìm file và lỗi gốc của c0000135 (tối đa TRACE_TIMEOUT giây)
wine_load_trace() {
  WINEDEBUG=err+all,+loaddll,+module timeout "${TRACE_TIMEOUT:-90}" box64 wine64 cmd /c ver 2>&1 | tr -d '\r' | grep -iE 'kernel32|kernelbase|c0000135|err:|not found' | head -n 14 | cut -c1-230 | tr '\n' ';'
  ws_kill
}
# ---- quan sát bộ cài MT5 (log thật bản v8: chạy 2400 s không ra terminal64.exe, không dòng lỗi nào; cần biết nó BẬN hay ĐỨNG, đang HIỆN cửa sổ gì, đã nạp DLL gì) ----
x_windows() {   # tên các cửa sổ đang có trên màn hình ảo (rỗng nếu không có xwininfo)
  command -v xwininfo >/dev/null 2>&1 || return 0
  xwininfo -root -tree 2>/dev/null | grep -E '^ +0x' | grep -v '(has no name)' | cut -c1-120 | awk 'NR<=8' | tr '\n' ';'
}
mt5_snapshot() {   # một mẫu: số tiến trình, tổng giây CPU Wine, cỡ drive_c, vài file mới lớn nhất từ lúc chạy bộ cài, cửa sổ X
  local n cpu sz newest
  n=$(wine_ps_line | grep -c .); cpu=$(wine_cpu_total)
  sz=$(du -sk "$WINEPREFIX_DIR/drive_c" 2>/dev/null | awk '{print $1}')
  newest=$(find "$WINEPREFIX_DIR/drive_c" -type f -newer "$MT5_STAMP" -printf '%s %P\n' 2>/dev/null | sort -rn | awk 'NR<=4 { printf "%s | ", $0 }' | cut -c1-320)
  echo "tiến_trình=$n cpu=${cpu:-?}s drive_c=${sz:-?}KB file_mới_lớn_nhất=[$newest] cửa_sổ=[$(x_windows)]"
}
mt5_watch() {   # chạy nền: mỗi MT5_SAMPLE_S giây (60) ghi một mẫu vào $MT5_PS_F (tối đa 120 mẫu). Không để sót tiến trình: gặp TERM thì tắt luôn lệnh `sleep` đang đợi; script cài chính mất thì tự thoát
  local t0 n=0 sp=""
  trap '[ -n "$sp" ] && kill "$sp" 2>/dev/null; exit 0' TERM
  t0=$(date +%s)
  while [ "$n" -lt 120 ]; do
    sleep "${MT5_SAMPLE_S:-60}" & sp=$!
    wait "$sp" 2>/dev/null; sp=""; n=$(( n + 1 ))
    kill -0 $$ 2>/dev/null || exit 0
    echo "[+$(( $(date +%s) - t0 ))s] $(mt5_snapshot)" >> "$MT5_PS_F" 2>/dev/null
  done
}
# ---- «thăm dò» bộ cài lúc đứng im: log thật v9 cho thấy mt5setup.exe chỉ hiện cửa sổ 312x102 rồi đứng (CPU ~20 s, không ghi gì). Cần BIẾT cửa sổ đó nói gì, không đoán.
# Ba nguồn độc lập (mỗi nguồn lỗi thì bỏ qua): tên cửa sổ X, các luồng đang chờ gì, ảnh màn hình ảo (xwd, nén, base64; giải bằng tools/mt5_phone/xwd_decode.py). KHÔNG dùng winedbg: Box64 chặn nó («winedbg detected, not launching it!», log thật v11). ẢNH là nguồn quyết định: nó cho thấy chữ trong hộp thoại.
proc_wchan() {   # mỗi tiến trình Wine: các luồng đang chờ ở đâu trong nhân (đếm theo tên); rỗng nếu máy không cho đọc
  local p t
  wine_ps_line | awk '{ print $1 }' | while read -r p; do
    [ -d "/proc/$p/task" ] || continue
    printf '%s:' "$p"
    for t in /proc/"$p"/task/*; do cat "$t/wchan" 2>/dev/null; echo; done | grep -v '^$' | sort | uniq -c | awk '{ printf "%s×%s,", $2, $1 }'
    printf ' '
  done | cut -c1-600
}
screen_b64() {   # ảnh toàn màn hình ảo -> xwd | gzip | base64 (một dòng); quá lớn hoặc không chụp được thì in lý do ngắn
  local b
  command -v xwd >/dev/null 2>&1 || { echo "không-có-xwd"; return 0; }
  b=$(xwd -root -silent 2>/dev/null | gzip -9 2>/dev/null | base64 -w0 2>/dev/null)
  if [ -z "$b" ]; then echo "chụp-không-được"
  elif [ "${#b}" -gt "${MT5_SHOT_MAX:-60000}" ]; then echo "quá-lớn(${#b})"
  else printf '%s' "$b"; fi
}
mt5_probe() {   # $1 = nhãn (idle|stall), $2 = «shot» thì chụp cả ảnh. Ghi vào $MT5_PROBE_F (chữ) và $MT5_SHOT_F (ảnh, chỉ giữ lần mới nhất)
  local lab="$1" shot="${2:-}" t0; t0=$(date +%s)
  {
    echo "== thăm dò [$lab] $(date '+%T') wine=$(wine_variant) =="
    echo "cửa_sổ_X: $(x_windows)"
    echo "luồng_chờ(wchan): $(proc_wchan)"
  } >> "$MT5_PROBE_F" 2>/dev/null
  [ "$shot" = shot ] && screen_b64 > "$MT5_SHOT_F" 2>/dev/null
  log "thăm dò bộ cài [$lab] xong sau $(( $(date +%s) - t0 ))s: $(grep -c . "$MT5_PROBE_F" 2>/dev/null) dòng trong $MT5_PROBE_F"
  return 0
}
# Phần diag riêng cho bước MT5: Windows mà Wine khai báo, DLL bộ cài đã nạp, 12 dòng cuối của vết, mẫu theo thời gian
mt5_diag_lines() {
  [ -s "$MT5_TRACE" ] || [ -s "$MT5_PS_F" ] || [ -s "$MT5_PROBE_F" ] || return 0
  echo "windows_khai_báo (system.reg): $(grep -a -m4 -E '^\"(ProductName|CurrentVersion|CurrentBuildNumber|CSDVersion)\"' "$WINEPREFIX_DIR/system.reg" 2>/dev/null | tr -d '\r' | tr '\n' ' ')"
  echo "windows_chọn (HKCU\\Software\\Wine\\Version trong user.reg): $(win_chosen)"
  echo "kiểu_wine=$(wine_flavor) (tệp $FLAVOR_F=$(head -1 "$FLAVOR_F" 2>/dev/null || echo không-có)) bản=$(wine_variant) mặc_định=$WINE_DEFAULT_VER chốt=$(head -1 "$WINEVER_F" 2>/dev/null || echo không-có)"
  [ -s "$WINEFB_F" ] && echo "wine_lùi_về=$WINE_SAFE_VER, lý do: $(head -c 700 "$WINEFB_F" | tr '\n' ' ')"
  echo "bộ_cài_thăm_dò (tên cửa sổ X, luồng chờ): $(grep -v '^xwd_gz_b64' "$MT5_PROBE_F" 2>/dev/null | tr '\n' ';' | cut -c1-3500)"
  echo "ảnh_màn_hình: $( [ -s "$MT5_SHOT_F" ] && echo "có $(wc -c < "$MT5_SHOT_F" | tr -d ' ') ký tự trong $MT5_SHOT_F (app đính kèm cuối chẩn đoán)" || echo không-có )"
  echo "bộ_cài_DLL_đã_nạp (số lần): $(tr -d '\r' < "$MT5_TRACE" 2>/dev/null | grep -ioE '(webview2loader|msedgewebview2|mshtml|wininet|winhttp|schannel|urlmon|d3d11|dxgi|gdiplus|riched20|comctl32|gnutls)[a-z0-9_]*\.(dll|so|exe)' | tr 'A-Z' 'a-z' | sort | uniq -c | sort -rn | awk '{ printf "%s×%s ", $2, $1 }' | cut -c1-500)"
  echo "bộ_cài_mẫu_theo_thời_gian: $(tr '\n' ';' < "$MT5_PS_F" 2>/dev/null | cut -c1-2200)"
  echo "bộ_cài_12_dòng_cuối_vết: $(tr -d '\r' < "$MT5_TRACE" 2>/dev/null | tail -n 12 | cut -c1-190 | tr '\n' ';')"
}
wine_diag() {   # ghi $DIAGF (chi tiết, app đưa vào «chẩn đoán») và in MỘT dòng gọn cho thông báo lỗi
  local w="$WINEPREFIX_DIR/drive_c/windows" pg k32s k32w k32b n hint="" out first="" f ch
  out="$(cat "$WB_OUT" 2>/dev/null)${PROBE_OUT:-}"
  [ -s "$WB_OUT.first" ] && first=$(tr -d '\r' < "$WB_OUT.first" | grep -v '^$' | tail -n 4 | tr '\n' ';' | cut -c1-400)
  pg=$(getconf PAGESIZE 2>/dev/null); pg="${pg:-?}"
  if [ -s "$w/system32/kernel32.dll" ]; then k32s=có; else k32s=THIẾU; fi
  if [ -s "$w/syswow64/kernel32.dll" ]; then k32w=có; else k32w=không; fi
  if [ -s "$WINE_DIR/lib/wine/x86_64-windows/kernel32.dll" ]; then k32b=có; else k32b=THIẾU; fi
  n=$(ls "$w/system32" 2>/dev/null | wc -l | tr -d ' ')
  case "$pg" in 4096|"?") ;; *) hint=" Máy dùng trang nhớ $pg byte (không phải 4096): Box64/Wine có thể không chạy được." ;; esac
  if addr_err "$out"; then
    hint="$hint Wine không nạp được ntdll.dll vì vùng nhớ ảo (nhân Android có thể chỉ 39-bit): đây là giới hạn của máy/Box64, không phải lỗi mạng."
  elif exec_err "$out"; then
    hint="$hint Android (nhân/SELinux) từ chối quyền thực thi mprotect(PROT_EXEC) cho vùng nhớ Wine vừa nạp (ntdll.dll): đây KHÔNG phải lỗi 39-bit hay lỗi mạng. $(shim_state_msg)"
  fi
  if has_re 'could not exec wineserver' "$out"; then hint="$hint Wine không chạy được wineserver (xem dòng wineserver trong $DIAGF)."; fi
  ch=$(wb_children)
  case "$ch" in *appwiz*) hint="$hint Wine đã mở trình cài Mono/Gecko (appwiz.cpl): hộp thoại chờ người bấm nên wineboot đứng; kiểm biến WINEDLLOVERRIDES trong $DIAGF.";; esac
  if has_re 'boot event wait timed out' "$out"; then hint="$hint Tiến trình wineboot con không xong trong 300 s (giới hạn cứng của Wine): xem «wineboot_mẫu_CPU» để biết máy chỉ chậm (CPU tăng) hay kẹt (CPU đứng im)."; fi
  {
    echo "== $(date '+%F %T') =="
    echo "wine=$(wine_variant) nhân=$(uname -r) trang_nhớ=$pg"
    echo "box64: $(BOX64_NOBANNER=0 BOX64_LOG=1 timeout 30 box64 --version 2>&1 | tr -d '\r' | grep -v '^$' | head -n 4 | tr '\n' ';')"
    echo "lỗi vùng nhớ ảo (map_fixed_area/try_map_free_area): $(addr_err "$out" && echo CÓ || echo không)"
    echo "lỗi quyền thực thi (failed to set ... protection / noexec): $(exec_err "$out" && echo CÓ || echo không)"
    echo "đo quyền thực thi: $(cat "$PROBE_F" 2>/dev/null || echo chưa-đo)"
    echo "lớp đệm: chế_độ=${PYEA_SHIM:-auto} có_file=$(shim_avail && echo có || echo không) đang_bật=$(shim_active && echo có || echo không) loại_file=$(elf_kind "$SHIM_SO")"
    echo "shim.log (đuôi): $(tail -n 10 "$SHIM_LOG" 2>/dev/null | tr -d '\r' | tr '\n' ';' | cut -c1-900)"
    echo "bộ_cài=${DIAG_INSTALLER:-?} loại_PE=${DIAG_KIND:-?} cỡ=$(wc -c < "${DIAG_INSTALLER:-/dev/null}" 2>/dev/null)"
    echo "system32/kernel32=$k32s ($n file); syswow64/kernel32=$k32w; thư_mục_wine/x86_64-windows/kernel32=$k32b"
    echo "lệnh_thử_cmd: $(probe_tail)"
    echo "wineboot_lần_1 (trước khi bật lớp đệm): ${first:-không có}"
    echo "wineboot_cuối: $(wb_tail)"
    echo "wineserver: tệp=$(elf_kind "$WINE_DIR/bin/wineserver") bọc=$(elf_kind "$WRAP_DIR/wineserver") WINESERVER=${WINESERVER:-chưa-đặt}"
    echo "wineserver --version (qua box64 trực tiếp): $(timeout 60 box64 "$WINE_DIR/bin/wineserver" --version 2>&1 | tr -d '\r' | head -n 2 | tr '\n' ';')"
    echo "wineserver --version (qua WINESERVER): $(timeout 60 "${WINESERVER:-$WRAP_DIR/wineserver}" --version 2>&1 | tr -d '\r' | head -n 2 | tr '\n' ';')"
    echo "tiền_tố: $(ls "$WINEPREFIX_DIR" 2>/dev/null | tr '\n' ' ')"
    echo "tiền_tố (ls -a): $(ls -a "$WINEPREFIX_DIR" 2>/dev/null | tr '\n' ' ') | hive: $(for f in system.reg user.reg userdef.reg; do printf '%s=%sB ' "$f" "$(wc -c < "$WINEPREFIX_DIR/$f" 2>/dev/null | tr -d ' ')"; done)"
    echo "dosdevices: $(ls -l "$WINEPREFIX_DIR/dosdevices" 2>/dev/null | awk 'NF>=9 { s=$9; if (NF>=11) s=s " -> " $11; printf "%s; ", s }')"
    echo "system32 (mẫu): $(for f in kernel32 kernelbase ntdll win32u user32; do fmeta "$w/system32/$f.dll"; done | tr '\n' ';')"
    echo "WINEDLLOVERRIDES=${WINEDLLOVERRIDES:-chưa-đặt} WINESERVER=${WINESERVER:-chưa-đặt} DISPLAY=${DISPLAY:-chưa-đặt} Xvfb=$(pgrep -x Xvfb >/dev/null 2>&1 && echo đang-chạy || echo không-thấy)"
    echo "wineboot_chương_trình_đã_mở (số lần được nhắc trong vết +loaddll/+process): ${ch:-không-có-vết}"
    echo "wineboot_dòng_process: $(tr -d '\r' < "$WB_OUT" 2>/dev/null | grep 'trace:process:' | head -n 8 | cut -c1-200 | tr '\n' ';')"
    echo "wineboot_mẫu_CPU (cách nhau ${PS_EVERY:-30}s; cpu = giây CPU tích luỹ, tăng = đang làm, không đổi = kẹt): $(tr '\n' ';' < "$PS_F" 2>/dev/null | cut -c1-1500)"
    echo "wineboot_20_dòng_cuối (có giờ): $(tr -d '\r' < "$WB_OUT" 2>/dev/null | tail -n 20 | cut -c1-170 | tr '\n' ';')"
    mt5_diag_lines
    if exec_err "$out" || addr_err "$out"; then echo "wine kênh virtual (cảnh báo): $(wine_trace)"; fi
    if [ -z "${PROBE_OUT:-}" ] && [ -d "$WINEPREFIX_DIR/drive_c" ] && ! exec_err "$out" && ! addr_err "$out"; then echo "vết_nạp_kernel32 (cmd /c ver, +loaddll+module): $(wine_load_trace)"; fi
  } >> "$DIAGF" 2>/dev/null
  printf 'Chẩn đoán: wine=%s, trang_nhớ=%s, system32/kernel32=%s (%s file), bộ cài=%s.%s' "$(wine_variant)" "$pg" "$k32s" "$n" "${DIAG_KIND:-?}" "$hint"
}

wb_known_fatal() { local o; o="$(cat "$WB_OUT" 2>/dev/null)"; exec_err "$o" || addr_err "$o"; }
# Vết nhẹ (+loaddll +process +timestamp) luôn bật khi tạo tiền tố: cho biết wineboot đã mở chương trình nào và mỗi tiến trình dừng ở đâu lúc kẹt; vào nhật ký chỉ lỗi (bỏ dòng ':trace:').
prefix_do() {
  local rc=0 t0 left sp
  t0=$(date +%s); : > "$PS_F" 2>/dev/null
  wine_ps_watch >/dev/null 2>&1 & sp=$!
  WINEDEBUG="${PREFIX_DEBUG:-err+all,fixme-all,+timestamp,+process,+loaddll}" timeout "${PREFIX_TIMEOUT:-900}" box64 wine64 wineboot -i >"$WB_OUT" 2>&1 || rc=$?
  if [ "$rc" != 0 ] && ! wb_known_fatal; then
    left=$(( ${PREFIX_TIMEOUT:-900} - ($(date +%s) - t0) ))
    log "wineboot (tiến trình chính) thoát mã $rc sau $(( $(date +%s) - t0 ))s; xem tiến trình Wine con còn làm việc không (chờ tối đa ${left}s)"
    wait_wine_idle "$left"
  fi
  kill "$sp" 2>/dev/null; wait "$sp" 2>/dev/null
  grep -v ':trace:' "$WB_OUT" | cut -c1-500
  if [ "$rc" != 0 ]; then
    wb_known_fatal && return 1
    prefix_files_ok || return 1
    log "wineboot chính báo lỗi nhưng sau khi chờ tiền tố đã đủ file -> để lệnh thử cmd.exe quyết định"
    timeout "${REG_TIMEOUT:-120}" box64 wine64 reg add 'HKCU\Software\Wine\WineDbg' /v ShowCrashDialog /t REG_DWORD /d 0 /f >/dev/null 2>&1
    return 0
  fi
  box64 wine64 reg add 'HKCU\Software\Wine\WineDbg' /v ShowCrashDialog /t REG_DWORD /d 0 /f
}
# Gặp lỗi quyền thực thi của Wine (exec_err) thì bật lớp đệm pyea_noexec MỘT lần rồi làm lại. Trả 0 = vừa bật xong (nên thử lại); 1 = không cần/không bật được/đã bật rồi.
shim_heal() {
  local out; out="$(cat "$WB_OUT" 2>/dev/null)${PROBE_OUT:-}"
  exec_err "$out" || return 1
  addr_err "$out" && return 1                  # hết vùng nhớ ảo (39-bit) cũng kèm dòng «failed to set ... protection» nhưng lớp đệm không giúp được
  [ "${PYEA_SHIM:-auto}" = 0 ] && return 1
  shim_active && return 1
  shim_avail || { log "Wine bị từ chối quyền thực thi nhưng không có $SHIM_SO (APK cũ?) -> không bật được lớp đệm"; return 1; }
  log "Android từ chối quyền thực thi (PROT_EXEC) cho vùng nhớ Wine -> bật lớp đệm pyea_noexec (thử lại không PROT_EXEC; Box64 tự dịch mã nên không cần bit thực thi của phần cứng) rồi làm lại tiền tố MỘT lần"
  cp -f "$WB_OUT" "$WB_OUT.first" 2>/dev/null
  : > "$SHIM_LOG"; touch "$SHIM_FLAG"; write_env ""
  return 0
}
prefix_rebuild() {   # xoá tiền tố cũ, tạo lại từ đầu, kiểm file + chạy thử; lỗi thì đặt ERR. Tối đa 2 vòng: vòng 2 chỉ khi vừa bật lớp đệm vì lỗi quyền thực thi
  mkdir -p "$DL"; rm -f "$WB_OUT.first"
  while true; do
    ws_kill; rm -rf "$WINEPREFIX_DIR"; rm -f "$PFX_OK" "$WB_OUT"; PROBE_OUT=""
    if hb prefix prefix_do; then
      ws_kill
      prefix_files_ok || { ERR="wineboot xong nhưng tiền tố thiếu file hệ thống (kernel32.dll/ntdll.dll...). $(wine_diag)"; return 1; }
      wine_probe && break
      ws_kill
      shim_heal && continue
      ERR="Tiền tố mới tạo xong nhưng chạy thử cmd.exe lỗi: $(probe_tail). $(wine_diag)"; return 1
    fi
    ws_kill
    shim_heal && continue
    ERR="Khởi tạo tiền tố Wine (wineboot) lỗi hoặc quá ${PREFIX_TIMEOUT:-900}s. $(wine_diag)"; return 1
  done
  ws_kill; wine_variant > "$PFX_OK"
  return 0
}
st_prefix() {
  write_env ""; start_xvfb
  exec_probe_log
  if ! redo prefix && prefix_files_ok && wine_probe; then
    log "tiền tố Wine có sẵn và chạy thử cmd.exe được -> giữ nguyên"; ws_kill; wine_variant > "$PFX_OK"; return 0
  fi
  ws_kill; log "tiền tố Wine thiếu/hỏng (hoặc chạy thử lỗi) -> dựng lại từ đầu"
  prefix_rebuild && return 0
  if wine_can_fall_back; then               # Wine mặc định mới không dựng nổi tiền tố trên máy này -> thử đúng MỘT lần với bản đã chạy được
    local why="$ERR"
    wine_fall_back "$why" || return 1
    prefix_rebuild || { ERR="Wine lùi về $WINE_SAFE_VER cũng không dựng được tiền tố: $ERR. Lỗi lúc đầu: $(printf '%s' "$why" | cut -c1-300)"; return 1; }
    return 0
  fi
  return 1
}
chk_prefix() { prefix_files_ok && [ "$(cat "$PFX_OK" 2>/dev/null)" = "$(wine_variant)" ]; }

# Đẩy các dòng KHÔNG phải vết (:trace:) mới có trong $MT5_TRACE sang nhật ký cài (vết đầy đủ ở $MT5_TRACE, chỉ dùng để chẩn đoán)
mt5_flush_log() {
  local size; size=$(wc -c < "$MT5_TRACE" 2>/dev/null); size="${size//[^0-9]/}"; size="${size:-0}"
  [ "$size" -gt "${MT5_FLUSHED:-0}" ] || return 0
  tail -c +"$(( ${MT5_FLUSHED:-0} + 1 ))" "$MT5_TRACE" 2>/dev/null | tr -d '\r' | grep -v ':trace:' | cut -c1-500 >> "$LOGF"
  MT5_FLUSHED=$size
}
# Windows mà Wine khai báo cho MỌI chương trình trong tiền tố = giá trị Version của khoá HKCU\Software\Wine (đúng chỗ `winecfg -v=` ghi vào). Ghi thẳng bằng reg.exe: bản v9 gọi
# `winecfg -v=win10` (chương trình có cửa sổ) và log thật cho thấy nó bị «Killed» sau ~35 s. Mặc định win11 (không phải win10 như script Linux của MetaQuotes) vì báo cáo trên
# WineHQ (bug 58043) và diễn đàn mql5: bộ cài MT5 trên Wine ≥ 10.3 hiện thông báo «debugger» giả và đứng. Log thật v11 (Cat S52) cho thấy đặt Windows 11 KHÔNG đủ để qua (vẫn hiện hộp
# thoại đó); giữ win11 vì vô hại và là mặc định hiện đại, KHÔNG coi nó là cách sửa. Cách sửa thật được thử ở v12 là Wine ≥ 11.6 (Syscall User Dispatch) - xem WINE_DEFAULT_VER ở đầu tệp.
win_set() {
  local v="${WIN_VER:-win11}"
  timeout "${REG_TIMEOUT:-120}" box64 wine64 reg add 'HKCU\Software\Wine' /v Version /t REG_SZ /d "$v" /f >>"$LOGF" 2>&1 || log "đặt Windows $v (reg add) không thành công (bỏ qua)"
  ws_kill
  log "Windows khai báo cho tiền tố: $(win_chosen) (muốn đặt: $v)"
}
win_chosen() {   # giá trị Version đã ghi trong user.reg (rỗng nếu chưa ghi)
  awk '/^\[Software\\\\Wine\] / { s = 1; next } /^\[/ { s = 0 } s && /^"Version"=/ { print; exit }' "$WINEPREFIX_DIR/user.reg" 2>/dev/null | tr -d '\r'
}
mt5_install_run() {   # chạy bộ cài MT5 (cờ /auto), đợi terminal64.exe + metaeditor64.exe xuất hiện và ngừng tăng, rồi tắt. WHY=kernel32 khi Wine không nạp được kernel32.dll; WHY=stall khi bộ cài đứng im
  local exe="$1" tmo="${MT5_INSTALL_TIMEOUT:-2400}" t0 now last_ev=0 last_chk=0 t sz="" prev=-1 stable=0 inst bad cpu dsz d base_cpu="" base_sz="" q0 nprobe=0
  WHY=""
  t0=$(date +%s); q0=$t0
  ( cd "$DL" && export WINEDEBUG="${MT5_DEBUG:-err+all,fixme-all,+timestamp,+loaddll}" && exec box64 wine64 "$exe" /auto ) >"$MT5_TRACE" 2>&1 &
  inst=$!
  while true; do
    sleep "${MT5_POLL:-5}"; now=$(date +%s)
    mt5_flush_log
    t=$(new_terminal)
    if [ -n "$t" ] && [ -e "$(dirname "$t")/metaeditor64.exe" ]; then
      sz=$(du -sk "$(dirname "$t")" 2>/dev/null | awk '{print $1}')
      if [ "$sz" = "$prev" ]; then stable=$(( stable + 1 )); else stable=0; prev="$sz"; fi
      [ "$stable" -ge "${MT5_STABLE:-4}" ] && break
    fi
    if [ -z "$t" ]; then   # lỗi nạp DLL thì Wine không tự thoát nhanh (log thật: ~300 s mỗi lần) -> dừng ngay, khỏi đợi
      bad=$(grep -m1 'could not load kernel32' "$MT5_TRACE" 2>/dev/null)
      [ -n "$bad" ] && { WHY=kernel32; ERR="Wine không nạp được kernel32.dll (c0000135 = thiếu DLL): $bad"; kill "$inst" 2>/dev/null; return 1; }
      # Đứng im: log thật bản v8 chạy 2400 s không một dòng lỗi và không ra terminal64.exe. «Có việc» = tổng CPU Wine tăng ≥ MT5_CPU_MIN giây (6) HOẶC drive_c đổi ≥ 64 KB kể từ mốc gần nhất.
      if [ $(( now - last_chk )) -ge "${MT5_CHECK_S:-30}" ]; then
        last_chk=$now; cpu=$(wine_cpu_total); dsz=$(du -sk "$WINEPREFIX_DIR/drive_c" 2>/dev/null | awk '{print $1}')
        if [ -n "$cpu$dsz" ]; then
          if [ -z "$base_cpu$base_sz" ]; then base_cpu="$cpu"; base_sz="$dsz"; q0=$now
          else
            d=$(( ${dsz:-0} - ${base_sz:-0} )); [ "$d" -ge 0 ] || d=$(( -d ))
            if [ $(( ${cpu:-0} - ${base_cpu:-0} )) -ge "${MT5_CPU_MIN:-6}" ] || [ "$d" -ge 64 ]; then base_cpu="$cpu"; base_sz="$dsz"; q0=$now; fi
          fi
          # Đứng im từ MT5_PROBE_S giây (90): xem cửa sổ của bộ cài đang nói gì (một lần/lượt chạy, thêm một lần nữa kèm ảnh lúc dừng vì đứng im). Thăm dò tự tốn CPU/ghi file -> đặt lại mốc để nó không bị tính là «có việc».
          if [ "$nprobe" -lt 1 ] && [ $(( now - q0 )) -ge "${MT5_PROBE_S:-90}" ]; then
            nprobe=$(( nprobe + 1 )); mt5_probe idle
            base_cpu=$(wine_cpu_total); base_sz=$(du -sk "$WINEPREFIX_DIR/drive_c" 2>/dev/null | awk '{print $1}')
          fi
          if [ $(( now - q0 )) -ge "${MT5_STALL_S:-300}" ]; then
            WHY=stall; ERR="bộ cài MT5 đứng im $(( now - q0 ))s (CPU Wine tăng chưa tới ${MT5_CPU_MIN:-6}s và drive_c không đổi) -> dừng sớm thay vì chờ hết ${tmo}s (ảnh màn hình ảo nằm cuối chẩn đoán: cho biết bộ cài đang chờ gì)"
            mt5_probe stall shot
            kill "$inst" 2>/dev/null; return 1
          fi
        fi
      fi
    fi
    kill -0 "$inst" 2>/dev/null || { [ -n "$t" ] && break; mt5_flush_log; ERR="bộ cài MT5 thoát mà chưa thấy terminal64.exe"; kill "$inst" 2>/dev/null; return 1; }
    [ $(( now - t0 )) -ge "$tmo" ] && { ERR="quá ${tmo}s mà MT5 chưa cài xong"; kill "$inst" 2>/dev/null; return 1; }
    if [ $(( now - last_ev )) -ge "$HB_EVERY" ]; then
      last_ev=$now; printf '.'
      sup_event install stage=mt5 state=progress detail="bộ cài MT5 đang chạy $(( now - t0 ))s${sz:+, đã ghi $(( ${sz:-0} / 1024 )) MB}"
    fi
  done
  kill "$inst" 2>/dev/null; ws_kill
  return 0
}
mt5_install_do() {   # bọc mt5_install_run: bật bộ lấy mẫu nền, dọn và đẩy nốt dòng lỗi vào nhật ký dù thành công hay thất bại
  local rc watcher
  : > "$MT5_PS_F" 2>/dev/null; : > "$MT5_TRACE"; touch "$MT5_STAMP"; MT5_FLUSHED=0; terminal_sigs > "$MT5_BEFORE" 2>/dev/null
  mt5_watch >/dev/null 2>&1 & watcher=$!
  mt5_install_run "$1"; rc=$?
  kill "$watcher" 2>/dev/null; wait "$watcher" 2>/dev/null
  mt5_flush_log
  return $rc
}
st_mt5() {
  local url="${MT5_SETUP_URL:-$MT5_URL_DEFAULT}" exe="$DL/mt5setup.exe" t kind heals=0 d shared
  mkdir -p "$DL"
  if redo mt5; then   # «làm lại MT5»: chỉ bỏ thư mục của CHÍNH link này (thư mục của link khác giữ nguyên), rồi cài sạch
    d=$(reg_dir); shared=$(grep -lxF "$d" "$MT5_REG".* 2>/dev/null | grep -vxF "$(reg_file)")
    case "$d" in "$MT5_HOME_DIR"/?*) [ -z "$shared" ] && rm -rf "$d";; esac
    rm -f "$(reg_file)"
  fi
  # Tệp tải về nhớ theo link: `wget -c` với link KHÁC sẽ nối đuôi vào bản tải dở (hỏng) hoặc giữ nguyên bản cũ đã tải đủ (thử thật), nên link đổi thì tải lại từ đầu
  [ "$(cat "$DL/mt5setup.url" 2>/dev/null)" = "$url" ] || rm -f "$exe"
  printf '%s' "$url" > "$DL/mt5setup.url"
  HB_WATCH="$exe"; hb mt5 retry 3 wget -c -O "$exe" "$url" || { ERR="Không tải được bộ cài MT5 từ $url"; return 1; }
  [ "$(head -c2 "$exe" 2>/dev/null)" = "MZ" ] || { ERR="File tải về không phải chương trình .exe (link hỏng hoặc bị chặn): $url"; return 1; }
  write_env ""; start_xvfb
  kind=$(pe_kind "$exe"); DIAG_KIND="$kind"; DIAG_INSTALLER="$exe"
  log "bộ cài MT5: loại PE=$kind (x64=64-bit, x86=32-bit, ?=không rõ); Wine=$(wine_variant)"
  if [ "$kind" = x86 ] && ! wine_wow64; then   # bản Wine thường chỉ chạy .exe 32-bit khi có thư viện 32-bit (Box64 không có) -> cần bản wow64
    say "Bộ cài MT5 là chương trình 32-bit mà Wine hiện tại ($(wine_variant)) không chạy được file 32-bit -> đổi sang Wine wow64 $WINE_WOW64_VER (tải thêm, làm 1 lần)"
    ws_kill
    HB_WATCH="$DL"; hb wine wine_get amd64-wow64 "$WINE_WOW64_VER" || { ERR="Không tải/giải nén được Wine wow64 $WINE_WOW64_VER (GitHub chặn/mạng đứt?)."; return 1; }
    write_env ""
    box64 wine64 --version >>"$LOGF" 2>&1 || { ERR="Wine wow64 đã giải nén nhưng «box64 wine64 --version» lỗi."; return 1; }
    prefix_rebuild || return 1
  fi
  { command -v xwininfo >/dev/null 2>&1 && command -v xwd >/dev/null 2>&1; } || apt-get install -y --no-install-recommends x11-utils x11-apps >>"$LOGF" 2>&1 || log "không cài được x11-utils/x11-apps (chỉ dùng để liệt kê cửa sổ và chụp ảnh màn hình khi chẩn đoán)"
  : > "$MT5_PROBE_F" 2>/dev/null; rm -f "$MT5_SHOT_F"
  while true; do
    ERR=""
    win_set
    mt5_install_do "$exe" && break
    ws_kill
    if [ "$WHY" = kernel32 ] && [ "$heals" -lt 1 ]; then   # tự chữa MỘT lần: tiền tố có thể hỏng -> dựng lại rồi cài lại
      heals=$(( heals + 1 ))
      say "Wine không nạp được kernel32.dll -> dựng lại tiền tố Wine rồi cài MT5 lại (lần $heals)"
      prefix_rebuild || return 1
      continue
    fi
    ERR="$ERR. $(wine_diag)"
    return 1
  done
  t=$(new_terminal); [ -n "$t" ] || { ERR="cài xong nhưng không thấy terminal64.exe"; return 1; }
  d=$(keep_dir "$(dirname "$t")") || { ERR="không chuyển được thư mục MT5 vừa cài vào chỗ riêng $MT5_HOME_DIR"; return 1; }
  reg_set "$d"
  mt5_point "$d" || { ERR="không tạo được liên kết $MT5_LINK"; return 1; }
}
# Chuyển thư mục MT5 vừa cài vào chỗ riêng của link này: bộ cài của link KẾ TIẾP (kể cả khi nó chọn trùng tên thư mục) không thể ghi đè lên nó
keep_dir() {
  local src="$1" dst; dst="$MT5_HOME_DIR/$(url_key "$(want_url)")"
  case "$src" in "$dst") printf '%s' "$dst"; return 0;; esac
  case "$src" in "$WINEPREFIX_DIR/drive_c/"?*/*) ;; *) return 1;; esac   # chỉ chuyển thư mục con của một thư mục (vd Program Files/<tên>), không chuyển cả «Program Files»
  mkdir -p "$MT5_HOME_DIR" && rm -rf "$dst" && mv "$src" "$dst" && has_terminal "$dst" || return 1
  printf '%s' "$dst"
}
reg_set() { printf '%s\n' "$1" > "$(reg_file)"; }
mt5_point() { rm -f "$MT5_LINK"; ln -s "$1" "$MT5_LINK" || return 1; write_env "$MT5_LINK"; }
# Xong khi sổ có thư mục của ĐÚNG link này và trong đó còn terminal64.exe (link khác -> chưa xong, cài bản của link đó). Bản cài từ trước khi có sổ: nhận cho link hiện tại, như cũ.
chk_mt5() {
  local d d2; d=$(reg_dir)
  if [ -z "$d" ] && ! ls "$MT5_REG".* >/dev/null 2>&1 && [ -n "$(find_terminal)" ]; then   # bản cài của phiên bản cũ: nhận, rồi chuyển vào thư mục riêng để bộ cài của link khác không ghi đè được
    d=$(dirname "$(find_terminal)"); d2=$(keep_dir "$d") && d="$d2"; reg_set "$d"
  fi
  has_terminal "$d" || return 1
  [ "$(readlink "$MT5_LINK" 2>/dev/null)" = "$d" ] && [ -d "$MT5_LINK" ] && { write_env "$MT5_LINK"; return 0; }
  mt5_point "$d"
}

st_provision() {
  local out
  write_env "$MT5_LINK"
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" provision 2>&1) || { ERR="Cấp file từ app lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; return 1; }
}
st_compile() {
  local out ed="$MT5_LINK/MQL5/Experts"
  start_xvfb
  out=$(MT5_DIR="$MT5_LINK" bash "$GUEST_ROOT/pyea/run_mt5_termux.sh" compile 2>&1) || { ERR="Biên dịch EA lỗi: $(printf '%s' "$out" | tail -n 4 | tr '\n' ';')"; ws_kill; return 1; }
  ws_kill
  cp "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5" 2>/dev/null
  return 0
}
chk_compile() { local ed="$MT5_LINK/MQL5/Experts"; [ -f "$ed/PyEABridge.ex5" ] && cmp -s "$ed/PyEABridge.mq5" "$STATE_DIR/compiled.mq5"; }

# ---------------------------------------------------------------------------------------------- điều phối
LOCK="$STATE_DIR/install.pid"
take_lock() {
  if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null && [ "$(cat "$LOCK")" != "$$" ]; then
    say "Đang có một lần cài khác chạy (pid $(cat "$LOCK")). Đợi nó xong, hoặc đóng nó rồi chạy lại."; exit 3
  fi
  echo $$ > "$LOCK"; trap 'rm -f "$LOCK"' EXIT
}

case "$MODE" in
  outer)
    take_lock
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
    say "PyEA - cài MT5 trong giả lập. CHƯA kiểm trên điện thoại thật; hãy thử bằng tài khoản DEMO trước."
    stage precheck "Kiểm tra máy (CPU 64-bit, dung lượng, mạng)" st_precheck_do
    stage termux_pkgs "Cài công cụ nền cho Termux (proot-distro, curl, wget)" st_termux_pkgs chk_termux_pkgs
    stage rootfs "Tạo môi trường Debian" st_rootfs chk_rootfs
    stage fetch "Lấy script và cấu hình từ app PyEA" st_fetch
    run_inner || exit $?
    stage launcher "Tạo lệnh khởi động MT5 (và tự chạy khi mở máy nếu có Termux:Boot)" st_launcher
    sup_event install stage=login state=start detail="bật MT5, đăng nhập tài khoản và nối EA vào app"
    bash "$BASE/pyea-start-mt5.sh" start || die_stage login "không bật được MT5 bằng pyea-start-mt5.sh"
    say ""
    say "XONG PHẦN CÀI. MT5 đang khởi động và đăng nhập; app PyEA sẽ báo «Đã nối» (hoặc lý do nếu lỗi)."
    say "Từ nay muốn bật lại MT5: bash ~/pyea-start-mt5.sh   (dừng: bash ~/pyea-start-mt5.sh stop)."
    say "Muốn tự chạy sau khi khởi động lại điện thoại: cài Termux:Boot (F-Droid) và mở nó một lần. Android 12+: tắt hạn chế tiến trình con trong Tuỳ chọn nhà phát triển."
    ;;
  inner)
    take_lock
    export DEBIAN_FRONTEND=noninteractive
    stage apt "Cài thư viện nền trong Debian (Xvfb, X11, font...)" st_apt chk_apt
    stage box64 "Cài Box64 (lớp dịch x86-64 sang ARM)" st_box64 chk_box64
    stage wine "Tải Wine 64-bit $WINE_VER" st_wine chk_wine
    stage prefix "Khởi tạo Wine (lần đầu hơi lâu)" st_prefix chk_prefix
    stage mt5 "Tải và cài MetaTrader 5" st_mt5 chk_mt5
    stage provision "Chép EA cầu nối và cấu hình từ app" st_provision
    stage compile "Biên dịch EA cầu nối" st_compile chk_compile
    ;;
  *) echo "chế độ không rõ: $MODE (outer|inner)"; exit 64 ;;
esac
exit 0
