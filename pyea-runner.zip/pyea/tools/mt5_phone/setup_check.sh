#!/usr/bin/env bash
# Kiểm tra máy đã có đủ thành phần để chạy MT5 + EA cầu nối chưa (KHÔNG tự cài gì). Chưa kiểm trên máy thật.
miss=0
for c in box64 wine64 Xvfb; do
  if command -v "$c" >/dev/null 2>&1; then echo "OK   $c: $(command -v "$c")"; else echo "THIẾU $c"; miss=1; fi
done
command -v termux-wake-lock >/dev/null 2>&1 && echo "OK   termux-wake-lock" || echo "CHÚ Ý chưa có termux-wake-lock (cài Termux:API) - máy có thể ngủ làm MT5 chết"
command -v termux-notification >/dev/null 2>&1 && echo "OK   termux-notification" || echo "CHÚ Ý chưa có termux-notification: giám sát chỉ ghi log, không báo lên màn hình"
[ -f "${1:-terminal64.exe}" ] && echo "OK   terminal64.exe" || echo "CHÚ Ý chưa thấy ${1:-terminal64.exe} (truyền đường dẫn làm tham số)"
echo
echo "Nhớ: tắt hạn chế tiến trình con (Android 12+: Tuỳ chọn nhà phát triển), miễn tối ưu pin cho Termux. Xem docs/MT5_ON_PHONE.md."
exit $miss
