#!/bin/sh
# Dựng lớp đệm aarch64 (glibc) từ pyea_noexec.c và đặt vào pyea/assets làm tài sản của app. Cần clang + lld (chạy ở máy dev/CI, KHÔNG phải trên điện thoại).
#   sh tools/mt5_phone/shim/build_shim.sh          -> ghi pyea/assets/pyea_noexec_aarch64.so.txt và cập nhật BUILD_INFO.txt
set -eu
here=$(cd "$(dirname "$0")" && pwd)
root=$(cd "$here/../../.." && pwd)
out="$root/pyea/assets/pyea_noexec_aarch64.so.txt"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
clang --target=aarch64-linux-gnu -O2 -fPIC -shared -nostdlib -ffreestanding -fno-builtin -fuse-ld=lld \
  -Wl,-soname,pyea_noexec.so -Wl,--build-id=none -Wl,-z,now -Wl,-z,norelro -o "$tmp/pyea_noexec.so" "$here/pyea_noexec.c"
llvm-strip --strip-all "$tmp/pyea_noexec.so" 2>/dev/null || true
cp "$tmp/pyea_noexec.so" "$out"; chmod 644 "$out"
{
  echo "nguon_sha256=$(sha256sum "$here/pyea_noexec.c" | cut -d' ' -f1)"
  echo "asset_sha256=$(sha256sum "$out" | cut -d' ' -f1)"
  echo "clang=$(clang --version | head -n1)"
} > "$here/BUILD_INFO.txt"
cat "$here/BUILD_INFO.txt"
