/* pyea_noexec.c - lớp đệm LD_PRELOAD cho Box64 (aarch64, glibc) chạy trong proot trên Android.

   VẤN ĐỀ: Wine qua Box64 nạp ntdll.dll rồi gọi mprotect(PROT_READ|PROT_EXEC) lên vùng .text. Nếu nhân/SELinux của máy từ chối quyền
   thực thi cho vùng nhớ ánh xạ từ file (mount noexec, hoặc luật SELinux), Wine báo
       «err:virtual:map_image_into_view failed to set 60000020 protection on ... ntdll.dll section .text, noexec filesystem?»
   rồi chết. Box64 KHÔNG chạy mã x86-64 bằng CPU mà DỊCH nó, nên bit thực thi của phần cứng trên vùng đó là thừa; Box64 chỉ cần
   BIẾT vùng đó "được phép thực thi" (nó ghi nhận theo đối số prot của lời gọi, không theo kết quả nhân).

   CÁCH LÀM: bọc mprotect/mmap/mmap64. Gọi thật trước; CHỈ KHI nhân trả EACCES/EPERM cho lời gọi có PROT_EXEC thì thử lại không có PROT_EXEC
   và nếu lần thử lại thành công thì báo thành công. Nếu lời gọi đầu đã thành công (máy bình thường) thì không làm gì thêm.
   mmap chỉ thử lại với vùng ánh xạ TỪ FILE (vùng ẩn danh là bộ nhớ JIT của chính Box64, phải thực thi thật nên không đụng tới).

   GHI NHẬT KÝ: nếu biến môi trường PYEA_SHIM_LOG trỏ tới một file thì mỗi lời gọi CÓ PROT_EXEC mà lỗi (tối đa 24 dòng mỗi tiến trình; lỗi mmap/mprotect không đòi exec là chuyện thường của Box64 nên không ghi) được ghi một dòng
   «hàm addr=... len=... prot=... errno=... -> thử-lại-không-exec:ok|lỗi», kèm một dòng «tải pid=...» khi nạp. Nhờ vậy lần sau có bằng chứng
   thật (errno) thay vì đoán, kể cả khi lớp đệm không cứu được.

   Không dùng thư viện chuẩn khi biên dịch (-nostdlib); chỉ gọi syscall(), __errno_location(), getenv() của glibc đã có trong tiến trình lúc nạp.
   Biên dịch (xem build_shim.sh):
     clang --target=aarch64-linux-gnu -O2 -fPIC -shared -nostdlib -ffreestanding -fno-builtin -fuse-ld=lld -Wl,-soname,pyea_noexec.so -Wl,--build-id=none -Wl,-z,now -Wl,-z,norelro -o pyea_noexec.so pyea_noexec.c
*/

typedef unsigned long size_t;

extern long syscall(long number, ...);
extern int *__errno_location(void);
extern char *getenv(const char *name);

#if defined(__aarch64__)
# define NR_mmap 222
# define NR_mprotect 226
# define NR_openat 56
# define NR_write 64
# define NR_getpid 172
#elif defined(__x86_64__)
# define NR_mmap 9
# define NR_mprotect 10
# define NR_openat 257
# define NR_write 1
# define NR_getpid 39
#else
# error "chỉ hỗ trợ aarch64 và x86_64 (x86_64 chỉ để kiểm thử trong sandbox)"
#endif

#define EPERM 1
#define EACCES 13
#define PROT_EXEC 4
#define MAP_ANONYMOUS 0x20
#define MAX_LOG 24

static int g_logged;
static int g_fd = -2;                        /* -2 chưa mở, -1 không có log */

static char *put_s(char *p, const char *s) { while (*s) *p++ = *s++; return p; }
static char *put_n(char *p, unsigned long v, unsigned base, int prefix) {
    char tmp[24]; int n = 0;
    if (prefix) p = put_s(p, "0x");
    if (v == 0) { *p++ = '0'; return p; }
    while (v) { unsigned d = (unsigned)(v % base); tmp[n++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); v /= base; }
    while (n) *p++ = tmp[--n];
    return p;
}

static int log_fd(void) {
    if (g_fd == -2) {
        const char *path = getenv("PYEA_SHIM_LOG");
        g_fd = -1;
        if (path && *path) {
            long fd = syscall(NR_openat, -100, path, 0x441 /* O_WRONLY|O_CREAT|O_APPEND */, 0644);
            if (fd >= 0) g_fd = (int)fd;
        }
    }
    return g_fd;
}

static void log_line(const char *fn, void *addr, unsigned long len, int prot, int flags, int fd, int err, int retried, int retry_ok) {
    char buf[200], *p = buf;
    int lf = log_fd(), saved = *__errno_location();
    if (lf < 0 || g_logged >= MAX_LOG) return;
    g_logged++;
    p = put_s(p, fn); p = put_s(p, " addr="); p = put_n(p, (unsigned long)addr, 16, 1);
    p = put_s(p, " len="); p = put_n(p, len, 16, 1);
    p = put_s(p, " prot="); p = put_n(p, (unsigned long)prot, 16, 1);
    if (flags >= 0) { p = put_s(p, " flags="); p = put_n(p, (unsigned long)flags, 16, 1); p = put_s(p, " fd="); p = put_n(p, (unsigned long)(fd < 0 ? 0 : fd), 10, 0); if (fd < 0) p = put_s(p, "(anon)"); }
    p = put_s(p, " errno="); p = put_n(p, (unsigned long)err, 10, 0);
    p = put_s(p, retried ? (retry_ok ? " -> thu-lai-khong-exec:ok" : " -> thu-lai-khong-exec:loi") : " -> khong-thu-lai");
    *p++ = '\n';
    syscall(NR_write, lf, buf, (unsigned long)(p - buf));
    *__errno_location() = saved;
}

__attribute__((constructor)) static void shim_loaded(void) {
    int lf = log_fd(), saved = *__errno_location();
    char buf[64], *p = buf;
    if (lf >= 0) {
        p = put_s(p, "tai pid="); p = put_n(p, (unsigned long)syscall(NR_getpid), 10, 0); *p++ = '\n';
        syscall(NR_write, lf, buf, (unsigned long)(p - buf));
    }
    *__errno_location() = saved;
}

int mprotect(void *addr, size_t len, int prot) {
    long r = syscall(NR_mprotect, addr, len, prot);
    int e;
    if (r == 0) return 0;
    e = *__errno_location();
    if ((prot & PROT_EXEC) && (e == EACCES || e == EPERM)) {
        long r2 = syscall(NR_mprotect, addr, len, prot & ~PROT_EXEC);
        log_line("mprotect", addr, len, prot, -1, -1, e, 1, r2 == 0);
        if (r2 == 0) return 0;
        *__errno_location() = e;
        return -1;
    }
    if (prot & PROT_EXEC) log_line("mprotect", addr, len, prot, -1, -1, e, 0, 0);     /* lỗi khác (vd ENOMEM) của lời gọi có exec: chỉ ghi, không thử lại */
    *__errno_location() = e;
    return -1;
}

static void *do_mmap(void *addr, size_t len, int prot, int flags, int fd, long off) {
    long r = syscall(NR_mmap, addr, len, prot, flags, fd, off);
    int e;
    if (r != -1) return (void *)r;
    e = *__errno_location();
    if ((prot & PROT_EXEC) && !(flags & MAP_ANONYMOUS) && fd >= 0 && (e == EACCES || e == EPERM)) {
        long r2 = syscall(NR_mmap, addr, len, prot & ~PROT_EXEC, flags, fd, off);
        log_line("mmap", addr, len, prot, flags, fd, e, 1, r2 != -1);
        if (r2 != -1) return (void *)r2;
        *__errno_location() = e;
        return (void *)-1;
    }
    if ((prot & PROT_EXEC) && !(flags & MAP_ANONYMOUS)) log_line("mmap", addr, len, prot, flags, fd, e, 0, 0);
    *__errno_location() = e;
    return (void *)-1;
}

void *mmap(void *addr, size_t len, int prot, int flags, int fd, long off) { return do_mmap(addr, len, prot, flags, fd, off); }
void *mmap64(void *addr, size_t len, int prot, int flags, int fd, long off) { return do_mmap(addr, len, prot, flags, fd, off); }
