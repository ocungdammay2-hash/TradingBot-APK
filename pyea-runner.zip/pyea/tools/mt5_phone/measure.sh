#!/usr/bin/env bash
# Đo giá tải THẬT của MT5/giả lập trên điện thoại, ghi CSV để gửi lại phân tích. Chạy song song với run_mt5_termux.sh trong 1 phiên Termux khác.
# Dùng:  bash measure.sh [số_phút=30] [giây_giữa_các_lần=15]   ->  ~/pyea_measure.csv  và  ~/pyea_measure_summary.txt
# Cột CSV: thời điểm, RSS tiến trình (MB) theo nhóm, %CPU theo nhóm, tổng RAM trống (MB), pin %, nhiệt pin (nếu termux-battery-status có).
# Nhóm tiến trình: box64 (lớp dịch CPU), wine (wine/wineserver/services/explorer...), mt5 (terminal64/metaeditor), xvfb, khác không đo.
# Biến: PROC_ROOT=/proc (để test), OUT=đường dẫn CSV. KHÔNG cần quyền root; trên Android tuỳ máy/phiên bản có thể thấy ít tiến trình hơn - ghi rõ trong tóm tắt.
set -u
MIN="${1:-30}"; GAP="${2:-15}"
OUT="${OUT:-$HOME/pyea_measure.csv}"; SUM="${SUM:-$HOME/pyea_measure_summary.txt}"; PROC="${PROC_ROOT:-/proc}"
CLK=$(getconf CLK_TCK 2>/dev/null || echo 100)
echo "time,box64_mb,wine_mb,mt5_mb,xvfb_mb,total_mb,box64_cpu,wine_cpu,mt5_cpu,xvfb_cpu,mem_avail_mb,battery_pct,battery_temp" > "$OUT"

group_of() {   # tên tiến trình -> nhóm
  case "$1" in
    box64*|box86*) echo box64;;
    wine*|wineserver|services.exe|explorer.exe|winedevice.exe|plugplay.exe|rpcss.exe|svchost.exe) echo wine;;
    terminal64*|terminal.exe|metaeditor*|metatester*) echo mt5;;
    Xvfb|Xvfb*) echo xvfb;;
    *) echo "";;
  esac
}

declare -A prev_ticks; prev_t=0
sample() {
  local now rss_box=0 rss_wine=0 rss_mt5=0 rss_xvfb=0 tk_box=0 tk_wine=0 tk_mt5=0 tk_xvfb=0 d name g rss ticks
  now=$(date +%s)
  for d in "$PROC"/[0-9]*; do
    [ -r "$d/stat" ] || continue
    name=$(awk '{print $2}' "$d/stat" 2>/dev/null | tr -d '()'); g=$(group_of "$name")
    [ -z "$g" ] && continue
    rss=$(awk '/^VmRSS:/{print int($2/1024)}' "$d/status" 2>/dev/null); rss=${rss:-0}
    ticks=$(awk '{print $14+$15}' "$d/stat" 2>/dev/null); ticks=${ticks:-0}
    case "$g" in
      box64) rss_box=$((rss_box+rss)); tk_box=$((tk_box+ticks));;
      wine) rss_wine=$((rss_wine+rss)); tk_wine=$((tk_wine+ticks));;
      mt5) rss_mt5=$((rss_mt5+rss)); tk_mt5=$((tk_mt5+ticks));;
      xvfb) rss_xvfb=$((rss_xvfb+rss)); tk_xvfb=$((tk_xvfb+ticks));;
    esac
  done
  local dt=$(( now - prev_t )); [ "$dt" -le 0 ] && dt=1
  cpu() { local cur=$1 key=$2 old=${prev_ticks[$2]:-$1}; prev_ticks[$key]=$cur; awk -v c="$cur" -v o="$old" -v dt="$dt" -v clk="$CLK" 'BEGIN{printf "%.1f", (c-o)/clk/dt*100}'; }
  local cb cw cm cx
  if [ "$prev_t" -eq 0 ]; then prev_t=$now; cb=0; cw=0; cm=0; cx=0; cpu "$tk_box" b >/dev/null; cpu "$tk_wine" w >/dev/null; cpu "$tk_mt5" m >/dev/null; cpu "$tk_xvfb" x >/dev/null
  else cb=$(cpu "$tk_box" b); cw=$(cpu "$tk_wine" w); cm=$(cpu "$tk_mt5" m); cx=$(cpu "$tk_xvfb" x); prev_t=$now; fi
  local avail pct temp
  avail=$(awk '/^MemAvailable:/{print int($2/1024)}' "$PROC/meminfo" 2>/dev/null); avail=${avail:-0}
  pct=""; temp=""
  if command -v termux-battery-status >/dev/null 2>&1; then
    local j; j=$(termux-battery-status 2>/dev/null)
    pct=$(printf '%s' "$j" | sed -n 's/.*"percentage": *\([0-9.]*\).*/\1/p'); temp=$(printf '%s' "$j" | sed -n 's/.*"temperature": *\([0-9.]*\).*/\1/p')
  fi
  echo "$now,$rss_box,$rss_wine,$rss_mt5,$rss_xvfb,$((rss_box+rss_wine+rss_mt5+rss_xvfb)),$cb,$cw,$cm,$cx,$avail,$pct,$temp" >> "$OUT"
}

end=$(awk -v n="$(date +%s)" -v m="$MIN" 'BEGIN{printf "%d", n+m*60}')
echo "Đo $MIN phút, mỗi $GAP giây -> $OUT (Ctrl+C để dừng sớm)"
trap 'summary; exit 0' INT TERM
summary() {
  awk -F, 'NR>1 && $6>0 { n++; t+=$6; if($6>mx)mx=$6; b+=$2; w+=$3; m+=$4; x+=$5; c+=$7+$8+$9+$10; if(NR==2||first=="")first=$12; last=$12 }
           END { if(!n){print "KHÔNG thấy tiến trình box64/wine/MT5 nào (chưa chạy MT5? hoặc Android ẩn /proc của tiến trình khác)."; exit}
                 printf "Số mẫu: %d\nRAM trung bình (MB): tổng %.0f | box64 %.0f | wine %.0f | MT5 %.0f | xvfb %.0f\nRAM đỉnh (MB): %d\nCPU trung bình tổng (%% của 1 lõi): %.1f\n", n, t/n, b/n, w/n, m/n, x/n, mx, c/n;
                 if(first!=""&&last!="") printf "Pin: %s%% -> %s%% (xem cột thời gian để quy ra %%/giờ)\n", first, last }' "$OUT" > "$SUM"
  echo "Tóm tắt -> $SUM"; cat "$SUM"
}
while true; do sample; [ "$(date +%s)" -ge "$end" ] && break; sleep "$GAP"; done
summary
