#!/usr/bin/env bash
# Liệt kê DLL mà MT5 THỰC SỰ nạp trong Wine - dữ liệu để quyết định bỏ gì khi tự build Wine tối giản (thay vì đoán).
#   Bước 1 (trên điện thoại):  WINEDEBUG=+loaddll box64 wine64 terminal64.exe /portable /config:startup.ini 2> loaddll.log     (chạy ~2 phút rồi thoát)
#   Bước 2:                    bash list_dlls.sh loaddll.log          -> mỗi dòng "số_lần tên_dll", nhiều nhất trước
# Định dạng dòng log +loaddll của Wine ghi theo trí nhớ (chứa chữ «loaddll» và tên *.dll): script chỉ lấy các dòng như vậy, chưa kiểm với log thật.
set -u
f="${1:-}"; [ -r "$f" ] || { echo "cách dùng: list_dlls.sh <file log +loaddll>"; exit 64; }
grep -ai 'loaddll' "$f" | grep -aoiE '[A-Za-z0-9_.+-]+\.(dll|exe|drv|sys|ocx)' | tr 'A-Z' 'a-z' | sort | uniq -c | sort -rn | awk '{print $1, $2}'
