#!/usr/bin/env python3
"""Giải ảnh màn hình ảo mà script cài MT5 chụp khi bộ cài đứng im (xwd | gzip | base64) thành tệp PNG để xem.

Dùng:   python3 tools/mt5_phone/xwd_decode.py <tệp> [ra.png]
  <tệp> là tệp chẩn đoán dán/gửi từ app (có phần «ảnh màn hình») HOẶC chính tệp mt5_screen.b64. Công cụ tự tìm chuỗi base64 dài nhất, giải gzip, đọc định dạng XWD, ghi PNG.
Chỉ dùng thư viện chuẩn (struct, zlib, base64). Hỗ trợ ảnh TrueColor/DirectColor 16/24/32 bit (Xvfb của script: 16 bit) và PseudoColor 8 bit.
"""
import base64
import gzip
import re
import struct
import sys
import zlib


def find_b64(text):
    runs = re.findall(r"[A-Za-z0-9+/=]{200,}", text)
    if not runs:
        raise ValueError("không thấy chuỗi base64 dài nào trong tệp (ảnh không được chụp: thiếu xwd, quá lớn, hoặc bộ cài không đứng im)")
    return max(runs, key=len)


def parse_xwd(raw):
    """-> (rộng, cao, [byte RGB mỗi pixel...]) từ nội dung tệp XWD (header 25 số 32-bit big-endian, tên cửa sổ, bảng màu, điểm ảnh)."""
    if len(raw) < 100:
        raise ValueError("tệp XWD quá ngắn")
    h = struct.unpack(">25I", raw[:100])
    (header_size, version, _fmt, depth, width, height, _xoff, byte_order, _unit, _bitorder, _pad, bpp, bpl, vclass, rmask, gmask, bmask,
     _bits_rgb, _cmap_entries, ncolors, _ww, _wh, _wx, _wy, _bw) = h
    if version != 7:
        raise ValueError("phiên bản XWD %d (chỉ hỗ trợ 7)" % version)
    off = header_size
    colors = {}
    for i in range(ncolors):
        pix, r, g, b, _fl, _p = struct.unpack(">IHHHBB", raw[off + i * 12: off + i * 12 + 12])
        colors[pix] = (r >> 8, g >> 8, b >> 8)
    off += ncolors * 12
    little = byte_order == 0
    rgb = bytearray()
    shifts = []
    for m in (rmask, gmask, bmask):
        if m:
            sh = (m & -m).bit_length() - 1
            shifts.append((m >> sh, sh))
        else:
            shifts.append((0, 0))
    for y in range(height):
        row = raw[off + y * bpl: off + y * bpl + bpl]
        step = bpp // 8
        for x in range(width):
            px = int.from_bytes(row[x * step:(x + 1) * step], "little" if little else "big")
            if vclass in (3, 5) and colors:           # PseudoColor / DirectColor có bảng màu
                rgb += bytes(colors.get(px, (0, 0, 0)))
                continue
            for (mx, sh) in shifts:
                v = (px >> sh) & mx if mx else 0
                rgb.append(v * 255 // mx if mx else 0)
    return width, height, bytes(rgb)


def write_png(path, width, height, rgb):
    raw = b"".join(b"\x00" + rgb[y * width * 3:(y + 1) * width * 3] for y in range(height))

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    text = open(argv[1], encoding="utf-8", errors="replace").read()
    out = argv[2] if len(argv) > 2 else "mt5_screen.png"
    w, h, rgb = parse_xwd(gzip.decompress(base64.b64decode(find_b64(text))))
    write_png(out, w, h, rgb)
    print("đã ghi %s (%dx%d)" % (out, w, h))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
