#!/usr/bin/env python3
"""pyea_relay.py - cầu nối TỆP giữa EA PyEABridge (trong MT5) và máy chủ cục bộ của app PyEA.

VÌ SAO CÓ: MT5 chỉ cho EA mở socket tới địa chỉ nằm trong danh sách «Allow WebRequest for listed URL» (Tools > Options > Expert Advisors), và danh sách đó
KHÔNG đặt được bằng file ini (nó nằm trong file nhị phân của MT5). Để người dùng chỉ phải nhập đăng nhập, EA tự thử socket trước; nếu MT5 chặn thì EA ghi
dòng lệnh ra TỆP trong MQL5/Files (EA luôn được phép ghi tệp ở đó) và relay này chuyển các dòng đó tới app qua TCP 127.0.0.1 (relay là tiến trình Linux
bình thường nên không bị MT5 chặn), rồi chuyển trả lời của app ngược lại vào tệp cho EA đọc. Giao thức PyEA-EA v1 đi nguyên văn, relay KHÔNG hiểu nội dung.

Tệp (trong <thư mục MT5>/MQL5/Files), mỗi PHIÊN có số hiệu sid (giây UTC lúc EA mở phiên), mỗi hướng chia nhiều đoạn theo seq để tệp không phình mãi:
  pyea_o_<sid>_<seq>.txt   EA ghi, relay đọc (EA -> app). Đoạn mới khi đoạn cũ > SEG_BYTES; relay đọc hết đoạn cũ rồi XOÁ nó và sang đoạn kế.
  pyea_i_<sid>_<seq>.txt   relay ghi, EA đọc (app -> EA). Cùng quy tắc; EA xoá đoạn đã đọc hết.
Dòng điều khiển do relay chèn vào hướng app -> EA:  RELAYCLOSE  (không nối được app, hoặc app đã đóng) -> EA đóng phiên và mở phiên mới sau vài giây.
Phiên mới nhất (sid lớn nhất) thắng: thấy sid mới thì relay đóng kết nối app của phiên cũ và mở kết nối mới khi có dòng đầu tiên (HELLO).

Chạy:  python3 pyea_relay.py --dir <MT5>/MQL5/Files [--host 127.0.0.1] [--port 18765]
CHƯA kiểm trên điện thoại thật; phía relay đã test với máy chủ thật của app (tests/test_mt5_relay.py) cùng một EA giả nói đúng quy tắc tệp trên."""
import argparse
import os
import re
import select
import socket
import sys
import time

OUT_RE = re.compile(r"^pyea_o_(\d+)_(\d+)\.txt$")
CLOSE_LINE = b"RELAYCLOSE\n"
CHUNK = 65536
SEG_BYTES = 262144


def out_name(sid, seq):
    return "pyea_o_%s_%d.txt" % (sid, seq)


def in_name(sid, seq):
    return "pyea_i_%s_%d.txt" % (sid, seq)


class Relay:
    def __init__(self, files_dir, host="127.0.0.1", port=18765, log=None, connect_timeout=3.0, stale_s=300.0, seg_bytes=SEG_BYTES):
        self.dir, self.host, self.port = files_dir, host, int(port)
        self.log_fn = log or (lambda m: print("%s PYEA-RELAY %s" % (time.strftime("%F %T"), m), file=sys.stderr, flush=True))
        self.connect_timeout, self.stale_s, self.seg_bytes = connect_timeout, stale_s, seg_bytes
        self.cur = None                       # phiên đang chuyển tiếp
        self._last_log = {}
        self.stats = {"sessions": 0, "to_app": 0, "to_ea": 0, "closed": 0}

    # ------------------------------------------------------------------------------------------ tiện ích
    def log(self, key, msg, every=30.0):
        now = time.monotonic()
        if now - self._last_log.get(key, -1e9) >= every:
            self._last_log[key] = now
            self.log_fn(msg)

    def _p(self, name):
        return os.path.join(self.dir, name)

    def _sessions(self):
        """{sid: sorted list seq} của các tệp pyea_o_* đang có."""
        out = {}
        try:
            names = os.listdir(self.dir)
        except OSError:
            return out
        for n in names:
            m = OUT_RE.match(n)
            if m:
                out.setdefault(int(m.group(1)), []).append(int(m.group(2)))
        for v in out.values():
            v.sort()
        return out

    # ------------------------------------------------------------------------------------------ phiên
    def _begin(self, sid, seqs):
        self.cur = {"sid": str(sid), "oseq": seqs[0], "off": 0, "iseq": 0, "ibytes": 0, "sock": None, "dead": False}
        self.stats["sessions"] += 1
        self.log("begin", "phiên mới sid=%s" % sid, every=0)

    def _end(self):
        c, self.cur = self.cur, None
        if c and c["sock"] is not None:
            try:
                c["sock"].close()
            except OSError:
                pass

    def _append_in(self, data):
        c = self.cur
        path = self._p(in_name(c["sid"], c["iseq"]))
        with open(path, "ab") as f:
            f.write(data)
        c["ibytes"] += len(data)
        if c["ibytes"] >= self.seg_bytes:                       # sang đoạn mới: tạo tệp rỗng NGAY để EA thấy đoạn kế đã tồn tại
            c["iseq"] += 1
            c["ibytes"] = 0
            open(self._p(in_name(c["sid"], c["iseq"])), "ab").close()

    def _die(self, why):
        c = self.cur
        if c["sock"] is not None:
            try:
                c["sock"].close()
            except OSError:
                pass
            c["sock"] = None
        c["dead"] = True
        self.stats["closed"] += 1
        self.log("die", "đóng phiên %s: %s" % (c["sid"], why), every=5)
        try:
            self._append_in(CLOSE_LINE)
        except OSError:
            pass

    def _connect(self):
        c = self.cur
        try:
            s = socket.create_connection((self.host, self.port), timeout=self.connect_timeout)
            s.setblocking(False)
            c["sock"] = s
            return True
        except OSError as e:
            self._die("không nối được app %s:%d (%s) - app chưa mở/chưa bấm Bắt đầu?" % (self.host, self.port, e))
            return False

    # ------------------------------------------------------------------------------------------ một vòng
    def step(self):
        """Một lượt: dò phiên, chuyển EA->app, app->EA, dọn tệp cũ. Không chặn."""
        sess = self._sessions()
        if self.cur is not None and int(self.cur["sid"]) not in sess:
            self._end()                                          # EA đã xoá hết tệp của phiên (EA tắt/đóng phiên)
        if sess:
            newest = max(sess)
            if self.cur is None or newest > int(self.cur["sid"]):
                self._end()
                self._begin(newest, sess[newest])
        self._clean(sess)
        if self.cur is not None:
            self._pump_out()
            if self.cur is not None and self.cur["sock"] is not None:
                self._pump_in()

    def _pump_out(self):
        c = self.cur
        for _ in range(64):                                      # tối đa vài đoạn/lượt
            path = self._p(out_name(c["sid"], c["oseq"]))
            nxt_exists = os.path.exists(self._p(out_name(c["sid"], c["oseq"] + 1)))
            try:
                size = os.path.getsize(path)
            except OSError:
                if nxt_exists:                                   # đoạn này đã bị xoá, sang đoạn kế
                    c["oseq"] += 1
                    c["off"] = 0
                    continue
                return
            if size < c["off"]:
                c["off"] = 0
            if size > c["off"]:
                try:
                    with open(path, "rb") as f:
                        f.seek(c["off"])
                        data = f.read(min(size - c["off"], CHUNK))
                except OSError:
                    return
                c["off"] += len(data)
                if not c["dead"]:
                    if c["sock"] is None and not self._connect():
                        continue
                    try:
                        self._send_all(c["sock"], data)
                        self.stats["to_app"] += len(data)
                    except OSError as e:
                        self._die("gửi tới app lỗi (%s)" % e)
                continue
            if nxt_exists:                                       # đã đọc hết đoạn cũ và EA đã mở đoạn mới -> xoá đoạn cũ, sang đoạn kế
                try:
                    os.remove(path)
                except OSError:
                    pass
                c["oseq"] += 1
                c["off"] = 0
                continue
            return

    @staticmethod
    def _send_all(sock, data):
        end = time.monotonic() + 5.0
        view = memoryview(data)
        while view:
            try:
                n = sock.send(view)
                view = view[n:]
            except (BlockingIOError, InterruptedError):
                if time.monotonic() > end:
                    raise OSError("gửi quá 5s")
                select.select([], [sock], [], 0.2)

    def _pump_in(self):
        c = self.cur
        try:
            r, _, _ = select.select([c["sock"]], [], [], 0)
        except (OSError, ValueError):
            self._die("socket hỏng")
            return
        if not r:
            return
        try:
            data = c["sock"].recv(CHUNK)
        except (BlockingIOError, InterruptedError):
            return
        except OSError as e:
            self._die("đọc từ app lỗi (%s)" % e)
            return
        if not data:
            self._die("app đóng kết nối")
            return
        try:
            self._append_in(data)
            self.stats["to_ea"] += len(data)
        except OSError as e:
            self._die("không ghi được tệp cho EA (%s)" % e)

    def _clean(self, sess):
        """Xoá tệp của phiên cũ (không phải phiên hiện tại) đã im lặng quá stale_s giây, và tệp in mồ côi."""
        cur = int(self.cur["sid"]) if self.cur else None
        now = time.time()
        try:
            names = os.listdir(self.dir)
        except OSError:
            return
        for n in names:
            m = re.match(r"^pyea_[oi]_(\d+)_\d+\.txt$", n)
            if not m or int(m.group(1)) == cur:
                continue
            p = self._p(n)
            try:
                if now - os.path.getmtime(p) > self.stale_s:
                    os.remove(p)
            except OSError:
                pass

    def run(self, poll=0.1):
        while True:
            try:
                self.step()
            except Exception as e:                               # relay không được chết vì một lỗi lẻ
                self.log("err", "lỗi trong vòng lặp: %r" % (e,), every=10)
            c = self.cur
            if c is not None and c["sock"] is not None:
                try:
                    select.select([c["sock"]], [], [], poll)
                    continue
                except (OSError, ValueError):
                    pass
            time.sleep(poll)


def main(argv=None):
    ap = argparse.ArgumentParser(description="PyEA relay tệp <-> app")
    ap.add_argument("--dir", required=True, help="<thư mục MT5>/MQL5/Files")
    ap.add_argument("--host", default=os.environ.get("PYEA_HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("PYEA_PORT", "18765")))
    ap.add_argument("--poll", type=float, default=0.1)
    a = ap.parse_args(argv)
    os.makedirs(a.dir, exist_ok=True)
    Relay(a.dir, a.host, a.port).run(a.poll)


if __name__ == "__main__":
    main()
