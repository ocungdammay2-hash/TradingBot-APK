# PyEA Runner

Ứng dụng Android giao dịch **kiểu MetaTrader 5, viết bằng Python**: nhiều tài sản (Market Watch), **gắn bot (EA) vào tài sản** để tự giao dịch, **đặt lệnh thủ công**, biểu đồ có chấm vào/ra bấm xem lý do, **Strategy Tester (backtest + tối ưu)**, chạy nền có thông báo/báo động, và chat nhiều AI để giải thích/sửa bot.

> Tài liệu kỹ thuật cho người/AI tiếp quản: **HANDOFF.md**. Mặc định chạy **paper** (giả lập). Giao dịch thật là tính năng thử nghiệm - có thể mất vốn.

## 1. Build APK trên GitHub
> **Quan trọng:** GitHub **không tự giải nén** file `.zip`. Hãy giải nén `pyea-runner.zip` trên máy rồi đẩy các file bên trong lên repo. (Workflow bản này còn **tự giải nén** nếu repo chỉ chứa file zip - nhưng nên đẩy file đã giải nén; đừng để zip trong `.github/workflows/`.)

1. Tạo repo, đẩy **toàn bộ nội dung** của zip lên nhánh `main` (`git init && git add -A && git commit -m init && git push`).
   `buildozer.spec`, `main.py`, `pyea/`... phải cùng cấp. Workflow bản này **tự dò** `buildozer.spec` (kể cả khi nằm trong thư mục con - bản cũ báo lỗi *No buildozer.spec found*). File `.github/workflows/build-apk.yml` **phải ở gốc repo** (upload qua web hay bỏ sót thư mục ẩn → tạo tay, nội dung ở `docs/build-apk.yml`).
2. Tab **Actions → Build APK** (tự chạy khi push hoặc *Run workflow*). Lần đầu 30–60 phút.
3. Tải **Artifacts → pyearunner-apk** → cài APK. Nếu build lỗi: mở lần chạy → mục **Summary** có sẵn phần *Các dòng lỗi* + 80 dòng cuối của log buildozer; log đầy đủ nằm ở **Artifacts → buildozer-log**. Cache SDK/NDK được lưu cả khi lỗi nên lần chạy lại nhanh hơn nhiều (lần đầu 30–60 phút). Muốn vào Releases: `git tag v1.0.0 && git push --tags`.
(Chắc chắn thiết bị 64-bit: bỏ `armeabi-v7a` trong `buildozer.spec` để build nhanh gấp đôi.)

## 2. Các tab (giống MT5)
| Tab | Chức năng |
|---|---|
| **Thị trường** | Market Watch: giá bid/ask nhiều tài sản. Chạm vào mã → xem biểu đồ / đặt lệnh / gắn bot / xoá. *Thêm mã* có gợi ý từ sàn. **KẾT NỐI** để bắt đầu phiên. |
| **Giao dịch** | Tài khoản (số dư, equity, ký quỹ, lãi/lỗ), **vị thế mọi tài sản** (Sửa SL/TP, Đóng), **Lệnh mới** (mua/bán thị trường + SL/TP), lịch sử lệnh. |
| **Bot** | **Gắn bot vào tài sản + khung giờ** (nhiều bot, nhiều tài sản, cùng 1 bot gắn nhiều nơi, tham số riêng từng chỗ). Bật/tắt từng bot, xem trạng thái, lãi/lỗ riêng. Thư viện file .py (nạp, mẫu, xoá). |
| **Biểu đồ** | Chọn mã + **21 khung như MT5** (M1…M30, H1…H12, D1, W1, MN1). Nến, lưới, trục giá/giờ, **điều khiển bằng cảm ứng** (kéo = lướt có đà · chụm 2 ngón = thu/phóng · chạm nến = xem giá & giá trị chỉ báo · chạm 2 lần = về mặc định), **33 chỉ báo MT5** (nút *+ Chỉ báo*), chip **ẩn/hiện** chỉ báo + đường của bot, **chấm vào/ra** (▲ mua, ▼ bán, ● thoát, ◆ tín hiệu bị bỏ qua). **Chạm vào chấm → popup lý do** (nguồn quyết định, điều kiện + thông số kích hoạt, chỉ báo lúc đó, AI: từng model + lý do). |
| **Backtest** | Strategy Tester: chọn bot, tài sản, khung, số nến, mô phỏng tick (OHLC theo hướng nến / O→H→L→C / O→L→H→C / «xấu nhất» / chỉ giá mở; nút so sánh độ nhạy), vốn, đòn bẩy, spread, phí → báo cáo (lợi nhuận ròng, profit factor, drawdown, Sharpe, chuỗi thắng/thua, mua/bán...), đường equity, **biểu đồ có chấm vào/ra bấm xem lý do**, danh sách lệnh, **tối ưu hoá** tham số (quét lưới). |
| **AI** | Chat 1 AI / nhóm AI + bạn / nhóm AI tự thảo luận (ra tín hiệu cho bot `ai_follow`; chốt bởi 1 AI hoặc **biểu quyết đa số**). Giải thích bot, sửa bot (xem diff, lưu bản mới/ghi đè). |
| **Cài đặt** | Nguồn thị trường/sàn, chế độ paper/live, vốn paper, đòn bẩy, phí, ngưỡng dừng lỗ, chạy nền, API... |
| **Nhật ký** | Log; **Kiểm tra hệ thống** (báo cáo thiết bị/mạng/dịch vụ nền/pin để gửi hỗ trợ). |

**Nguồn thị trường** (Cài đặt → *Nguồn thị trường / sàn*): `simulated` (8 tài sản giả: BTCUSD, ETHUSD, EURUSD, XAUUSD, US500, AAPL... chạy offline, tua nhanh được) · `binance_spot` / `binance_futures` (crypto, giá thật; futures có bán khống + đòn bẩy) · `oanda` (forex/vàng/chỉ số CFD, có tài khoản **demo** miễn phí - cần token + account ID). Paper dùng giá thật của sàn đã chọn với tiền giả; live gửi lệnh thật (nên thử **Testnet/Demo** trước).

## 2b. Biểu đồ: khung giờ, cảm ứng, chỉ báo
**Khung thời gian (21):** 1m 2m 3m 4m 5m 6m 10m 12m 15m 20m 30m · 1h 2h 3h 4h 6h 8h 12h · 1d 1w 1mo. Bấm nút khung → lưới chọn. Nến căn theo **UTC**
(tuần mở Thứ Hai 00:00, tháng mở ngày 1). Khung sàn không có sẵn (vd Binance 12m/3h, OANDA 20m) được **ghép từ khung nhỏ hơn**.
**Cảm ứng:** kéo ngang = lướt (thả ra còn đà) · kéo dọc trên biểu đồ = cuộn trang · chụm/giãn 2 ngón = thu/phóng quanh vị trí 2 ngón ·
kéo ngang ở dải trục giờ (mép dưới) = thu/phóng · chạm vào nến = crosshair + O/H/L/C + giá trị chỉ báo · chạm lại = tắt · chạm 2 lần = về 60 nến, nến mới nhất ·
khi đang xem quá khứ có nút **Mới nhất ▶** ngay trên biểu đồ. Số nến kéo lùi được: Cài đặt → *Số nến đưa lên biểu đồ* (mặc định 400) và *Số nến lịch sử nạp sẵn* (500).
**Chỉ báo (nút *+ Chỉ báo*):** thêm nhiều chỉ báo, mỗi cái có tham số riêng (hộp Inputs như MT5), chọn màu, ẩn/hiện bằng chip `ƒ ...`, sửa/xoá; lưu riêng cho biểu đồ thường và biểu đồ backtest.
- Trên biểu đồ giá: MA (SMA/EMA/SMMA/LWMA), DEMA, TEMA, Bollinger Bands, Envelopes, Ichimoku (có mây + dịch Senkou/Chikou), Parabolic SAR, Alligator, Fractals, Kênh Donchian.
- Cửa sổ phụ: RSI, MACD, Stochastic, ADX, CCI, ATR, Momentum, Williams %R, ROC, OsMA, Bulls/Bears Power, DeMarker, Force Index, RVI, TRIX, Standard Deviation, Awesome (AO), Accelerator (AC).
- Khối lượng: Volumes, MFI, OBV, Accumulation/Distribution (cần nguồn giá có khối lượng - nguồn *simulated* không có nên hiện ghi chú).
Công thức/mặc định theo MT5 (vd đường tín hiệu MACD là **SMA**, ATR là **SMA của TR**, ADX làm mượt EMA); có tuỳ chọn kiểu cổ điển (EMA / Wilder) trong hộp tham số.
Các hàm cùng công thức dùng được trong bot: `ta.macd_series`, `ta.stoch_series`, `ta.adx_series`, ... (xem `ai.SDK_CHEATSHEET`).

## 2c. Vỏ: an toàn & vận hành (v1.2)
**Hợp đồng với bot (API 1.1):** mọi lệnh trả `OrderResult` có `retcode` chuẩn (OK, INVALID_VOLUME, INVALID_STOPS, INSUFFICIENT_MARGIN, TRADE_DISABLED, SYMBOL_MODE, MARKET_CLOSED, NO_QUOTES, NOT_SUPPORTED, HEDGE_NOT_ALLOWED, REJECTED...). Lệnh chờ limit/stop/stop-limit (có hạn, giữ chỗ ký quỹ), đóng một phần, `on_trade`, `on_timer`, `symbol_info()/account_info()/time_info()`, nến đa khung giờ, `request_id` chống gửi trùng. Xem `pyea/examples/pending_grid.py.txt`.
**An toàn:** nút **KILL SWITCH** (dừng bot → huỷ lệnh chờ → đóng hết → khoá giao dịch, sống qua restart) · chế độ **chỉ-xem** · chặn lệnh khi **giá cũ/mất kết nối** · luật khối lượng min/max/step + stop level + chế độ riêng từng mã (long-only/close-only/disabled) · **margin call** và **stop-out** · bot lỗi: chịu N lỗi/giờ rồi tự tắt (circuit breaker), phát hiện bot **treo** · app **chặn bot chứa subprocess/eval/exec...** (bật Chế độ nhà phát triển nếu tin file) · kiểm tra quyền API key Binance khi kết nối live · xác nhận trước khi đặt lệnh tay (tắt được = một chạm).
**Đối soát & dữ liệu (v1.3):** app so vị thế của mình với vị thế THẬT trên sàn (Binance Futures, OANDA) mỗi phút và ngay sau lệnh lỗi; lệch thì **mặc định tự đổi sổ theo sàn** (`adopt`, từ v1.7.0; chỉ làm sau khi thấy lệch lặp lại, đóng ở giá khớp thật lấy từ lịch sử sàn; muốn chỉ báo thì chọn `alert`). Lịch sử nến được lưu trên đĩa nên khởi động lại chỉ tải phần mới, tự phát hiện và lấp khoảng trống.
**Vận hành:** thanh trạng thái kết nối + mức ký quỹ trong tab Giao dịch · **cảnh báo giá** (≥/≤/±%) chạy cả khi không có bot · **Lịch sử & báo cáo** (win rate, profit factor, sụt vốn, theo từng bot, đường lãi/lỗ, xuất CSV) · số liệu từng bot (thắng, PF, thời gian on_tick) ngay ở tab Bot · **Sao lưu/Khôi phục** (mặc định xoá API key) · **Gói chẩn đoán** zip (không chứa khoá) · **Đặt lại tài khoản giả lập** · lọc Nhật ký theo mức/chữ/tên bot · nhớ tab và mã/khung biểu đồ lần trước.

## 2d. Sàn & cầu nối (v1.4)
`exchange` chọn ở Cài đặt: `simulated` · `binance_spot` · `binance_futures` · `oanda` · **`exness`** (API chính thức của Exness, chỉ VN/TH, chỉ "Exness trading account") · **`metaapi` / `mt5gw` / `bridge`** (MT4/MT5 qua cầu nối: Exness MT5 và mọi broker MetaTrader — xem `gateway/README.md`) · **`ccxt`** (~100 sàn khác; cần cài thư viện ccxt).
- **Khoá API được mã hoá** (Android Keystore; trên máy tính dùng khoá file). Tạo khoá riêng cho app, quyền tối thiểu (không cho rút tiền), bật giới hạn IP.
- **Lệnh chờ native** (`Lệnh chờ = auto`): nằm trên sàn, vẫn sống khi app/điện thoại chết. **Đồng bộ lịch sử + số dư** với sàn mỗi 5 phút (chỉ live), cảnh báo khi số dư lệch.
- **Nhiều tài khoản chạy song song** (Cài đặt → *Tài khoản…*): lưu hồ sơ từ cài đặt hiện tại, bot gắn theo tài khoản, "Xem" để chuyển tài khoản đang xem. Chạy được cả khi không bật chạy nền (v1.7.0; khi đó tài khoản phụ không có AI hub và dừng khi đóng app).
- **Backtest chi tiết chi phí** (spread cố định, phí/lot, trượt giá, swap, funding) và **Walk-forward** (tab Backtest).
- **Cô lập bot** (`Bot chạy ở = process`): bot chạy tiến trình riêng, giết được khi treo. Chưa dùng được trên Android (tự rơi về luồng).
- **Chưa kiểm chứng trên sàn thật**: toàn bộ các sàn/cầu nối ở trên mới được test bằng máy chủ giả (xem `HANDOFF.md` mục 5b). **Luôn thử demo/testnet trước.**
- **Tự kiểm tra sàn (một lệnh, mọi sàn)**: `python -m pyea.selfcheck --template exness > exness.json` (điền khoá) rồi `python -m pyea.selfcheck --exchange exness --settings exness.json` (CHỈ ĐỌC) hoặc thêm `--trade --yes` (lệnh thật khối lượng nhỏ nhất - dùng tài khoản DEMO; tự dọn vị thế/lệnh chờ). Báo cáo `[OK]/[CHÚ Ý]/[LỖI]` kèm phản hồi thô của sàn đã che khoá - dán lại để chỉnh. Cùng bộ kiểm tra này là nút *Nhật ký → Kiểm tra hệ thống* (chỉ đọc). Hợp đồng adapter ở `pyea/contract.py`.

## 2e. Vỏ bổ sung (v1.6, API bot 1.3)
- **Bot:** `api.store` (kho JSON bền riêng của bot) và `api.shared` (chung mọi bot, như GlobalVariable của MT5) · `api.oco(a, b)` nối lệnh chờ thành nhóm OCO · `api.stats()` thống kê lệnh đã đóng · `on_tester()` trả fitness riêng để tối ưu hoá xếp hạng (như OnTester của MT5) · `Ret.FROZEN` + `symbol_info().freeze_level` (freeze level kiểu MT5).
- **Quyền mạng theo bot:** khai báo `# @permission: network(api.example.com)` ở đầu file bot; bạn cho phép từng bot. **Chỉ cưỡng chế khi bot chạy ở tiến trình riêng** (Cài đặt → *Bot chạy ở = process*; chưa dùng được trên Android) - không phải ranh giới an ninh trước mã cố tình phá.
- **Backtest:** chọn thứ tự giá trong nến + nút **So sánh thứ tự giá trong nến**: kết quả đổi dấu nghĩa là chiến lược dựa vào giả định mà dữ liệu OHLC không kiểm chứng được. **Phát lại tín hiệu AI** đã ghi (model + dấu vân tay prompt) cho bot dùng `api.ai_signal` - chỉ tái dựng đúng tín hiệu đã ghi, không sinh lại câu trả lời của AI.
- **Không làm phiền:** Cài đặt → nút 1/4/8/24 giờ hoặc khung giờ ban đêm: tắt âm/rung nhưng cảnh báo vẫn được ghi và hiện thông báo im lặng; sự cố nghiêm trọng (kill switch, margin call, bot/dịch vụ lỗi, lệch vị thế…) mặc định vẫn kêu.
- **An toàn dữ liệu:** che khoá trong nhật ký/chat AI · phiên bản định dạng dữ liệu (file mới hơn app thì giữ nguyên) · xoay vòng nhật ký · cảnh báo rủi ro lần đầu trước LIVE · tuỳ chọn chặn chụp/quay màn hình.
- **SL/TP native** (Cài đặt, mặc định TẮT, thử demo/testnet trước): Binance Futures, OANDA (lệnh reduce-only) và **Binance Spot** (một lệnh OCO cho SL+TP, vì Spot không có reduce-only). **MetaApi/MT**: SL/TP gắn lên đúng ticket (v1.7.0); **cổng + EA MT4/MT5 và Exness** từ v1.8.0 (cần chép lại + biên dịch lại EA; Exness dò dạng thân yêu cầu lúc chạy, chưa kiểm chứng; netting: chỉ khi vị thế ảo là cả ticket) - HANDOFF 5h.

## 3. Chạy nền
Mặc định phiên chạy trong **dịch vụ nền** (thông báo trên thanh trạng thái: số bot, equity, lệnh mở): vẫn chạy khi tắt màn hình/thoát app, mở lại app tự gắn vào. Sự cố (bot lỗi, đạt ngưỡng lỗ, mất giá, đặt lệnh lỗi liên tiếp, dịch vụ bị giết) → **cảnh báo rung + âm**; dịch vụ crash → tự chạy lại và **khôi phục sổ lệnh + các bot**. Lần đầu nên cho app **không bị tối ưu pin**.

## 4. Tham số bot: tự nhận dạng, tự sinh form, đồng bộ như MT5
App **đọc khai báo tham số ngay trong code bot** (như MT5 nhận dạng từ khoá `input`) rồi **tự sinh form nhập** đúng kiểu: số → ô nhập có kiểm tra min/max, bật/tắt → công tắc, danh sách → ô chọn, nhóm → tiêu đề nhóm. Có 3 cách khai báo (dùng cách nào cũng được):
```python
class MyBot(BaseBot):
    inputs = {"lot": Input(0.01, "Khối lượng", min=0)}          # 1) dict (đầy đủ nhất: min/max/help/group/choices)
    fast = Input(10, "SMA nhanh", min=2)                        # 2) thuộc tính lớp = Input(...)

    # == Tín hiệu ==                                             # 3) chỉ cần thuộc tính có kiểu + giá trị (dạng 3 chỉ dùng
    rsi_period: int = 14        # Chu kỳ RSI                    #    khi không có dạng 1, 2); chú thích sau # là nhãn,
    mode: str = "both"          # Hướng [long|short|both]       #    [a|b|c] là ô chọn, "# == Tên ==" đặt nhóm
```
Mỗi tham số dùng được là `self.p.lot` **hoặc** `self.lot` (như biến `input` của MQ5). Giá trị người dùng nhập được lưu **riêng cho từng lần gắn bot vào tài sản**; ô sai kiểu/ngoài khoảng bị chặn ở form.
**Đồng bộ khi bot đang chạy** (đúng cơ chế MT5 *REASON_PARAMETERS*): ở tab Bot → *Tham số* → **Lưu & áp dụng**: bot gọi `on_deinit("params")`, nạp tham số mới, rồi gọi `on_init()` lại; **lệnh đang mở giữ nguyên**, biểu đồ có chấm ◆ "Đổi tham số: fast 10 → 12". Nếu `on_init()` trả về `False` (tham số sai, như `INIT_PARAMETERS_INCORRECT`) thì **tham số mới bị từ chối, quay lại tham số cũ** và bot không chết. Chạy qua dịch vụ nền cũng đồng bộ và được nhớ để khôi phục sau sự cố. Đổi file bot (kể cả AI vừa sửa): form tự cập nhật theo khai báo mới, tham số trùng tên được giữ.
**Bộ tham số có tên** (như file `.set`): *Lưu bộ / Nạp bộ*, *Sao chép / Dán* JSON. Backtest dùng đúng form này.

## 5. Viết bot
Bấm *Sao chép mẫu* (tab Bot) hoặc xem `pyea/examples/*.py.txt`.
```python
from pyea import BaseBot, Input, ta

class MyBot(BaseBot):
    name = "Bot của tôi"
    inputs = {"lot": Input(0.01, "Khối lượng", min=0), "fast": Input(10, "SMA nhanh", min=2)}

    def on_bar(self, candle):                       # khi 1 nến đóng
        closes = self.api.closes(100)
        f = ta.sma(closes, self.p.fast)
        if f and closes[-1] > f and not self.api.positions("buy"):
            self.api.buy(self.p.lot, sl=closes[-1] * 0.99, reason="Giá vượt SMA",
                         details={"SMA": round(f, 4), "giá": closes[-1]})
```
`self.api`: `symbol`, `timeframe` (tài sản/khung mà bot được GẮN vào), `buy/sell(volume, sl, tp, comment, reason, details, ai)` (sl/tp là **giá**; `reason`+`details` là nội dung popup khi chạm chấm), `close/close_all(..., reason, details)`, `positions/modify` (**chỉ lệnh của chính bot**), `candles/closes`, `plot(tên, giá trị)`, `status(text)`, `signal(text)`, `ai_signal`, `tick`, `balance`, `equity`, `log`. Chỉ dùng thư viện chuẩn + `pyea.ta`. Chỉ nạp file bạn tin tưởng - bot chạy với toàn quyền Python.

## 5b. Mất mạng, app bị giết, ngừng lâu (v1.7.0)
- **Mất mạng**: sau 30 giây app báo động nghiêm trọng, nói rõ bao nhiêu vị thế do **sàn** canh SL/TP (native, vẫn chạy) và bao nhiêu chỉ do **app** canh (KHÔNG chạy lúc này), nhắc lại mỗi 10 phút; có lại mạng thì đối soát với sàn ngay. Phiên không còn tự dừng khi mất giá (chỉ dừng nếu bạn đặt «Dừng phiên nếu mất giá liên tục quá»).
- **App bị hệ thống giết/crash**: báo thức giám sát dựng lại dịch vụ, khôi phục sổ lệnh, chờ mạng nếu chưa có, đối soát với sàn và báo nghiêm trọng nếu phiên đã ngừng ≥90 giây khi đang có vị thế.
- **Khớp lệnh với sàn**: vị thế/lệnh thay đổi lúc app không chạy được đối soát và đưa về đúng sàn, kèm giá đóng thật. **Giới hạn không thể tránh**: SL/TP và lệnh chờ do app giữ không chạy lúc app chết hoặc mất mạng - muốn sàn tự canh hãy bật SL/TP native (DEMO trước).
- **Lịch kinh tế** (Cài đặt → Lịch kinh tế, tự chọn nguồn): báo trước tin và tuỳ chọn chặn lệnh MỚI của bot/AI quanh giờ ra tin (lệnh tay và đóng lệnh không bị chặn).
- Tất cả mới kiểm bằng sàn giả; **chưa chạy trên sàn/Android thật** - xem HANDOFF 5g.

## 5c. Số liệu đồng bộ từ sàn như MT5 (v1.8.0)
- Khung **Giao dịch** hiện Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ **do sàn báo** (nhãn «SÀN»); không có số của sàn thì dùng sổ của app và ghi «sổ app». Trường sàn không báo hiện «-», không bịa 0. «Tổng lãi/lỗ» và «Thắng/số lệnh» luôn là sổ app.
- Từng vị thế: lãi/lỗ, swap, giá hiện tại do **sàn** tính (đúng contract size, quy đổi tiền) thay cho «chênh giá × khối lượng» của sổ app; hoa hồng chỉ hiện khi sàn báo theo vị thế.
- **Lịch sử & báo cáo → LỊCH SỬ TỪ SÀN**: Hôm nay/7/30/90 ngày với Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư (định nghĩa như tab Lịch sử của MT5) và danh sách vị thế đã đóng, gồm cả lệnh bạn đánh tay ngoài app.
- Hiện có cho MetaApi, cổng MT5, cổng+EA (cần EA/cổng bản mới), hồ sơ cầu nối khai op `history` và Exness (tên trường chưa kiểm chứng). **Chưa có** cho OANDA/Binance/ccxt (app nói rõ). Chỉ ở chế độ chạy thật. Số của từng vị thế làm mới mỗi ~15 giây. Mới kiểm bằng sàn giả - **so với tab MT5 thật trước khi tin** (HANDOFF 5h).

## 5d. Trợ lý AI + ánh xạ trường dùng chung (v1.9.0)
- **Trợ lý** (nút «Trợ lý» ở tab Giao dịch / Cài đặt / Nhật ký, và «Hỏi Trợ lý» trên hộp báo app bị lỗi): hướng dẫn cách dùng, cài đặt (APK, quyền, tối ưu pin, kết nối sàn, thêm AI) và xử lý sự cố khi app gặp vấn đề. Dùng AI bạn đã thêm ở tab AI; **không có AI / mất mạng / AI lỗi thì vẫn trả lời từ sổ tay có sẵn** trong app.
- **Chỉ ĐỀ XUẤT, không bao giờ đặt lệnh**: mỗi đề xuất là một thẻ nói rõ «đổi gì, từ gì sang gì», bạn bấm «Áp dụng» mới đổi (có «Hoàn tác»). Chỉ đổi được một số cài đặt an toàn (hiển thị, thông báo, nhịp làm mới, AI, danh sách theo dõi), ghi ánh xạ trường, chạy Kiểm tra hệ thống (chỉ đọc), tạo Gói chẩn đoán, mở hộp thoại bỏ tối ưu pin, mở tab. Không đụng được vào lệnh, kill switch, paper/live, khoá API, đòn bẩy, giới hạn lỗ.
- **Riêng tư**: câu hỏi gửi đi đã che khoá API/số tài khoản; số dư/vị thế/nhật ký/sự cố chỉ gửi khi bạn bật «Cho Trợ lý xem trạng thái» (mặc định TẮT).
- **Một hệ thống cho mọi sàn**: sàn đặt tên trường khác (số hiện «-») thì khai tên khoá thật ở Cài đặt → «Ánh xạ trường tuỳ chỉnh», không cần sửa mã (xem `pyea/fieldmap.py`; «Kiểm tra hệ thống» có mục «Ánh xạ trường» chỉ ra trường nào chưa khớp). Lớp này chỉ giải quyết đổi tên trường; giao thức khác hẳn vẫn cần adapter (mọi broker MetaTrader đi qua MetaApi/cổng/EA nên không cần).
- Chưa chạy với model thật / trên Android - xem HANDOFF 5i.

## 5g. Trailing Stop + Hòa vốn (v1.9.3)
- Bấm vị thế → «Trailing Stop (khoảng giá)» / «Hòa vốn khi lãi ≥». Luật theo từng vị thế, do người dùng đặt; SL chỉ dời theo chiều có lợi. Mã: pyea/trail.py; test: tests/test_trail.py.

## 5f. Backtest kiểu MT5 + thống kê từng tham số + AI tư vấn (v1.9.2)
- Tab Backtest: khoảng ngày, tốc độ chạy + tạm dừng, tối ưu tới 3 tham số, «So sánh từng tham số» (lãi/lỗ theo giá trị tham số, xếp hạng ảnh hưởng, bản đồ nhiệt, độ vững), chia lời/lỗ theo lý do thoát/chiều/giờ/thứ, «Hỏi AI tư vấn» (chỉ đề xuất, Áp dụng chỉ cho lần backtest kế tiếp).
- Mã: pyea/btanalysis.py; test: tests/test_btanalysis.py. AI chưa thử với model thật - xem HANDOFF 5k.

## 5e. Lịch sử từ sàn cho mọi sàn bằng hồ sơ JSON (v1.9.1)
- **Một bộ máy, mỗi sàn một hồ sơ dữ liệu**: OANDA, Binance Futures, ccxt (và Exness/MT như cũ) cho ra cùng khuôn «Lịch sử» của MT5. Sàn khác: Cài đặt → «Hồ sơ lịch sử sàn (JSON)», dán `{"tên_sàn": {...}}` - không cần sửa mã. Định dạng: docstring đầu `pyea/histengine.py`; ví dụ: `pyea/histprofiles.py`.
- Dưới mục Lịch sử có «Ghi chú về số liệu» (giả định của hồ sơ + cảnh báo vàng khi có thể thiếu). Hồ sơ chỉ ĐỌC, không đặt được lệnh.
- Chưa kiểm trên sàn thật - xem HANDOFF 5j.

## 6. Live & giới hạn
- Live: Binance Spot (không bán khống), Binance Futures USDT-M (one-way mode) hoặc OANDA (gộp vị thế 1 chiều/mã → bot/đặt tay không giữ đồng thời mua+bán cùng mã). Phí/PnL tính theo tiền báo giá của mã (xấp xỉ khi quote ≠ tiền tài khoản).
- AI chỉ **tư vấn**; bot luôn là bên quyết định cuối. API key được mã hoá khi lưu (Android Keystore; trên máy tính dùng khoá file - xem 2d) và bị che khỏi nhật ký/chat.
- Đã test bằng giả lập (1491 test) và Kivy giả; **chưa chạy trên thiết bị thật** - xem mục 5–6 HANDOFF.md.
- Chạy test lõi: `python -m unittest discover -s tests -v` (không cần Kivy).

## 5h. Đặt lệnh trên biểu đồ, ngôn ngữ, sàn có API (v1.9.10)
- **Đặt lệnh trên biểu đồ**: tab Biểu đồ → «＋». Đường vào/SL/TP kéo được; loại lệnh tự suy ra (`pyea/chartorder.py`). Chưa thử cảm ứng thật.
- **Ngôn ngữ**: Cài đặt → «Ngôn ngữ / Language» (10 ngôn ngữ Latinh/Kirin). Bảng dịch ở `pyea/i18n.py` (`CAT`); chuỗi chưa có trong bảng giữ tiếng Việt. Thêm dịch = thêm một dòng vào `CAT`. Chữ Trung/Nhật/Hàn/Thái/Hindi/Ả Rập cần nhúng thêm phông.
- **Sàn/broker có API ngoài danh sách app đang hỗ trợ** (tra cứu 2026-11-03; CHƯA có adapter, mới là danh sách ứng viên):

| Sàn / broker | API | Ghi chú (nguồn) |
|---|---|---|
| cTrader (mọi broker cTrader, vd. Pepperstone/IC Markets bản cTrader) | cTrader Open API (Protobuf/JSON) | Dùng được cho ai có tài khoản broker liên kết cTrader, có demo – help.ctrader.com/open-api |
| MT5 trực tiếp (mt5ws, MỌI broker MT5 có web terminal) | MT5 Web Terminal WebSocket (giao thức KHÔNG chính thức, dịch ngược bởi pymt5) | Chạy NGAY TRONG ĐIỆN THOẠI, không PC/VPS/trung gian; CHƯA thử sàn thật – dùng tài khoản DEMO trước |

Chi tiết những gì mt5ws CÒN THIẾU so với MT5: `docs/MT5_GAPS.md`.
| Capital.com | REST (khoá API + phiên CST/X-SECURITY-TOKEN), có môi trường demo | **ĐÃ CÓ adapter từ v1.9.12** (`pyea/capital.py`), chưa thử với sàn thật |
| IG | REST + Streaming cho khách cá nhân; FIX chỉ cho tổ chức; demo phải cùng email với tài khoản thật | trang IG «How to use IG's API» |
| Alpaca | REST, cổ phiếu Mỹ + crypto, có paper trading miễn phí | docs.alpaca.markets |
| Deriv | WebSocket API, có lệnh/giá/danh mục | developers.deriv.com (demo: trang không xác nhận) |
| Saxo | OpenAPI REST; token 24h của cổng dev chỉ chạy môi trường SIM (tài khoản mô phỏng 100.000$); live cần OAuth | developer.saxo |
| Interactive Brokers | TWS API: cần TWS hoặc IB Gateway chạy sẵn (khó cho app điện thoại) | trang ib-async trên PyPI |
| FXCM, FOREX.com | REST/FIX | chỉ theo bài tổng hợp forexbrokers.com, chưa tự kiểm |
| Bybit, OKX, Bitget, KuCoin, Kraken, Gate, MEXC… | đã dùng được qua `ccxt` (Cài đặt → ccxt_id) | cần cài thư viện ccxt |
| Chứng khoán VN: SSI FastConnect, DNSE (API phái sinh) | có API chính thức | chỉ thấy qua kết quả tìm kiếm, chưa đọc tài liệu |
- Kết luận cũ «Exness không có API» là SAI (đã có adapter `exness`). Mọi dòng trên là thông tin tra cứu, KHÔNG phải cam kết hỗ trợ: thêm sàn nào thì cần adapter + thử trên demo.

## 5i. Đo tải & giảm tải (v1.9.11)
- `python -m pyea.loadbench --bots N --indicators K [--no-split]` đo CPU Python theo thành phần trên máy phát triển (tỷ lệ giữa các phần ít phụ thuộc máy). Kết quả mẫu (sandbox, 1 tick/giây, UI làm mới 1 lần/giây): trước khi tách chart ~76% CPU là JSON+ghi+đọc state.json; bot mẫu và xử lý tick chỉ ~0,5%.
- Sau khi tách chart tĩnh (`chart.json`): ghi mỗi giây giảm 73–92% dung lượng; CPU giảm 44–62%. Còn lại lớn nhất là tính chỉ báo hiển thị (35–58%, ~1,3–1,8 ms/giây trên máy đo).
- Màn hình Cài đặt → «Tải thiết bị» đo CPU/RAM/ghi đĩa thật trên máy. Không có con số «giảm 90%» nào được chứng minh cho CPU/pin; chỉ lượng GHI ĐĨA giảm tới ~90% khi ít bot.

## 5j. Capital.com + giữ kết nối + tab ẩn (v1.9.12)
- `exchange = capital`: nhập `capital_api_key`, `capital_identifier` (email), `capital_password` (mật khẩu của API key); Testnet = demo. Tên đường dẫn/trường lấy từ open-api.capital.com (đọc 2026-11-03). Giới hạn: không đóng một phần; xoá SL/TP gửi `null` (tài liệu không nói rõ); chưa có lịch sử kiểu MT5. Chạy `python -m pyea.selfcheck --exchange capital --settings capital.json` trên DEMO trước mọi việc khác.
- `feeds.http_json` giữ kết nối cho GET (`POOL_ENABLED`): đo sandbox 2,47 → 0,50 ms CPU/yêu cầu. POST/PUT/DELETE luôn kết nối mới.
- `App.tab_visible` + `_catch_up`: tab ẩn không cập nhật mỗi giây. `idle_fps_save`: 20 fps sau 15 giây không chạm (chưa kiểm chứng trên Kivy thật).

## 5k. Bổ sung tra cứu sàn (2026-11-03, v1.9.13)
- **XTB: API đã TẮT từ 14/03/2025** (trang trợ giúp XTB) - đừng làm adapter; mọi thư viện `xapi` cũ không còn dùng được.
- eToro: API công khai (đặt/huỷ lệnh, SL/TP, giá) nhưng «chỉ một số người dùng được chọn» (Finextra) - chưa dùng được đại trà.
- tastytrade: OAuth2, REST + streaming, có môi trường sandbox (cert) riêng; hướng tới cổ phiếu/quyền chọn Mỹ.
- Coinbase Advanced Trade: REST + WebSocket (tài liệu CDP); cách xác thực/sandbox chưa đọc được. Dùng được qua ccxt.
- Tradovate: bài viết tìm thấy là năm 2021 nói API chưa mở cho khách lẻ; chưa xác nhận hiện nay. Dukascopy JForex: chỉ Java, tin 2009 - không phù hợp.
- Xếp hạng nên làm tiếp (giao thức tương tự Capital.com nên rẻ nhất): IG (cùng kiểu CST/X-SECURITY-TOKEN), rồi Alpaca, Deriv (WebSocket), cTrader Open API (Protobuf, nặng hơn).

## 5l. Làm tiếp theo PDF «Dự án còn thiếu gì» (v1.9.14)
PDF (do một AI khác viết) có nhiều mục đã LỖI THỜI: Visual mode backtest, thống kê theo giờ/thứ, lọc lịch sử, xuất CSV, đa ngôn ngữ đều đã có từ trước. Đã làm các mục còn thật sự thiếu:
- **Hedge mode Binance Futures** (`broker.py`: `_hedge`, `_leg`, `_extra_order_params`): xác minh tài liệu Binance (New Order/New Algo Order): hedge → `positionSide` bắt buộc, `reduceOnly` không được gửi. Test: `tests/test_hedge_futures.py` (sàn giả áp đúng luật, -4061/-1106).
- **Lịch sử Binance Spot** (`histprofiles.BINANCE_SPOT`, `BinanceBroker.account_history`): myTrades theo mã, cửa sổ ≤24h; không bịa lãi/lỗ. `tests/test_history_spot.py`.
- **Công cụ vẽ + Object List** (`pyea/drawings.py`, `CandleChart._draw_objects`, `ChartPanel.draw_menu`): `tests/test_drawings.py` + `TestDrawingTools` trong `test_chart.py`.
- **Báo cáo HTML** (`pyea/report.py`): `tests/test_report.py`.
- **Debugger bot** (`pyea/botdebug.py`, hook ở `BotRunner._call`, tham số `run_backtest(debugger=)`) + **Profiler** (`loadprobe.profiler_text`): `tests/test_botdebug.py`.
- **Pháp lý/giới thiệu** (`pyea/legal.py`), **cập nhật** (`pyea/updater.py`), **báo lỗi tự động** (`pyea/crashsend.py`): `tests/test_support.py`. LICENSE.md (chưa chọn), docs/USER_GUIDE.md.
- **Thử tải** (`pyea/stress.py`, `tests/test_stress.py`).
**Các mục từng bị hoãn ở 1.9.14 đã được làm ở 1.9.15 - xem mục 5m.**

## 5m. v1.9.15 — bản quyền Play, build Play, giao diện sáng, DOM, tick thật, phiên bản bot
**Bản quyền (`pyea/license.py`, `tools/license_keygen.py`, `tests/test_license.py`)**
- Cài từ Play (`getInstallSourceInfo(...).getInstallingPackageName() == com.android.vending`, fallback `getInstallerPackageName`) → dùng thử 90 ngày kể từ lần mở đầu; cài ngoài Play → `sideload`, không giới hạn. Hết hạn → chỉ chặn mở phiên LIVE mới (`ui.start_session` → `license_gate_live`).
- Khoá `PYEA1-<payload>.<chữ ký>`, Ed25519 (xác minh thuần Python mới thêm vào `ed25519.py`, đối chiếu vector RFC 8032 và thư viện chuẩn). Khoá ràng với ID cài đặt hoặc `*` (dùng chung), có hạn hoặc vĩnh viễn. Khoá CÔNG KHAI nằm trong `license.PUBLIC_KEY`; khoá RIÊNG do chủ dự án giữ (file `license_private.key` đi kèm bản giao riêng, KHÔNG nằm trong zip/APK, KHÔNG commit). Cấp khoá: `python3 tools/license_keygen.py issue license_private.key --iid <ID> --days 365`. Muốn đổi cặp khoá: `new-keypair` rồi dán khoá công khai mới và phát hành lại app.
- Chống lùi đồng hồ (mốc `seen` chỉ tăng), sửa tay `license.json` (tổng kiểm) → trên bản Play coi như hết dùng thử. KHÔNG chống được xoá dữ liệu/cài lại (cần máy chủ hoặc Play Integrity/Billing - quyết định kinh doanh, chưa làm). Chính sách sau hết hạn là một chỗ duy nhất (`blocks_live`).
**Build cho Play (CHƯA build thử, chưa thử trên máy thật)**: nguồn đã tra - p4a releases/PR #3262 (v2024.01.21 không có `foregroundServiceType`, v2026.05.09 có), trang Target API của Google Play (API 36 cho app mới/bản cập nhật từ 31/8/2026), tài liệu Android về FGS (dataSync giới hạn 6 giờ/24 giờ ở Android 15 → chọn `specialUse`). Thiếu: thuộc tính `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` trong `<service>` (p4a không phát ra) và phần khai báo FGS ở Play Console (Policy → App content) - phải điền tay. Nếu build lỗi, cấu hình lùi: `android.api = 33`, `android.ndk = 25b`, `p4a.branch = v2024.01.21`, `kivy==2.3.0`, bỏ `:foregroundServiceType=specialUse` và quyền FOREGROUND_SERVICE_SPECIAL_USE (chạy được nhưng KHÔNG đủ điều kiện đăng Play). Workflow cài buildozer mới nhất (không ghim).
**Giao diện sáng** (`ui_widgets.Col/THEMES/apply_theme`, setting `theme`): màu là list đổi TẠI CHỖ nên `from ui_widgets import PANEL` ở module khác vẫn thấy màu mới; phải gọi trước khi dựng widget. Chữ trên nút giữ trắng trừ khi tương phản < 3 (hổ phách). Chưa nhìn trên màn hình thật: widget mặc định của Kivy không đặt màu (tab header, spinner dropdown) có thể còn tối - kiểm trên máy.
**Khác**: `bars.py` (Renko/Range/gộp), `specs.py` + `BinanceFeed.depth/symbol_info/agg_trades` (DOM, thông số), `tickdata.py` + `run_backtest(ticks=, mode="real")`, `botversions.py` (`.versions/` cạnh bot). Test: test_license, test_theme, test_bars, test_marketdata, test_botversions.
**Vẫn KHÔNG làm (cần máy chủ/quyết định/thiết bị)**: đồng bộ đa thiết bị, marketplace, copy trading, VPS (cần máy chủ); mã hoá nguồn bot (Python không giấu được mã chạy trên máy người dùng); Play Billing/Integrity; soak 24/7 và kiểm tra trên Android thật.

## 5n. v1.9.16 — các mục «chưa làm» ở 1.9.15, làm theo hướng KHÔNG cần máy chủ của tác giả
- **Headless/VPS** (`pyea/headless.py`, `docs/vps/Dockerfile`, `docs/vps/pyea.service`, `tests/test_headless.py`): tái dùng `ipc.ServiceHost` (cùng đường chạy với dịch vụ nền Android). LIVE phải có `--accept-risk` + `live_confirm`. Mã thoát 0/1/2 cho supervisor. CHƯA chạy trên VPS thật.
- **Đồng bộ đa thiết bị** (`pyea/bundle.py`, `tests/test_bundle.py`): gói mã hoá (PBKDF2-HMAC-SHA256 200k vòng, dòng khoá HMAC-CTR, mã xác thực encrypt-then-MAC) ở file hoặc WebDAV. Chống ghi ra ngoài thư mục (chỉ `bots/*.py`, `params/*.json`, `instances.json`, `ui_prefs.json`, `settings`). Không mang theo `bot_perms.json`. Đồng bộ theo thao tác, không thời gian thực.
- **Chợ bot** (`pyea/market.py`, `tools/bot_pack.py`, `tests/test_market.py`): gói ký Ed25519 + danh mục SHA-256. Chữ ký = toàn vẹn + danh tính khoá, KHÔNG phải kiểm duyệt an toàn. Không thanh toán/bản quyền (cần máy chủ/Play Billing).
- **Copy trading** (`pyea/copyfeed.py`, `pyea/examples/copy_master|copy_follower.py.txt`, `tests/test_copyfeed.py`): HMAC dùng chung; đã chạy thử xuyên động cơ thật (backtest) bằng file chung. Muốn dùng https phải sửa dòng `@permission: network(host)` trong bot mẫu thành host của bạn rồi cấp quyền (rào mạng chỉ cưỡng chế ở chế độ bot-tiến-trình-riêng, xem perms.py).
**Vẫn không làm**: Play Billing/Integrity, chợ tín hiệu có thanh toán + xếp hạng (cần máy chủ), «mã hoá nguồn bot» (không khả thi với Python), soak 24/7 và Android thật.

## 5zb. v1.9.30 — công tắc `boot_alert`

Cờ `boot_resume.flag` có nội dung `A` (báo động) / `Q` (thường); `bootflag.sync(..., loud)` ghi lại khi đổi cài đặt; `BootReceiver.loud()` đọc cờ (kho thường rồi device-protected) và gọi `quiet()` (kênh `pyea_boot`, mức mặc định) nếu `Q`. Cài đặt `boot_alert` thuộc GLOBAL, nằm trong `ACCOUNT_DENY`.

## 5zv. v1.9.50 — sửa build, di truyền/Monte Carlo trong UI, luật biểu thức, ánh xạ mã webhook

`pyea/rules.py` (+ `examples/rule_bot.py.txt`), `webhook.normalize_symbol/session_executor`, ui.py (`GEN_METHOD`, `montecarlo_dialog`). Test: `tests/test_rules_webhook_ui.py`. Workflow build: cache `buildozer-v3-`, bước xoá dists (xem HANDOFF 5bi). Lỗi pip «lai» (`capture_logging`): recipe `tools/p4a_recipes/pyeapipfix` + `pip==25.3` trong `tools/p4a_constraints.txt` + xoá `build-*/build/venv` (HANDOFF 5bl). Đã chạy giao diện Kivy 2.3.2 thật dưới Xvfb: 8 tab không lỗi.

## 5zu. v1.9.49 — DNSE

`pyea/dnse.py` (V2 ký + `DnseV1`/`DnseBackend`/`DnseStream`/`parse_quote`), `pyea/mqttws.py`, `pyea/ui_dnse.py`, `wsclient.binary`. exchange=`dnse` đi qua `bridges.make_backend`. Tests: test_dnse, test_dnse_v1. Chưa kiểm tài khoản thật; chỗ đoán trong docs/DNSE.md.

## 5zt. v1.9.48 — DNSE (một phần)

`pyea/dnse.py` + `docs/DNSE.md` (đã biết / còn thiếu). Setting `max_bot_objects`. Việc tiếp: DnseBackend khi có đặc tả endpoint.

## 5zs. v1.9.47 — vẽ của bot, sổ lệnh, Binance WS (API 1.8)

engine: `BotContext.draw_*` → `BotRunner._draw/draw_objs` → `chart()['bot_objects']` → `ui_widgets chart.bot_objects`. `order_book/recent_trades` → `TradingSession.market_call` → feed.depth/agg_trades (chỉ BinanceFeed). `feeds._WsBook` + setting `binance_ws`. Tests: test_bot_draw, test_binance_ws.

## 5zr. v1.9.46 — bot đa mã (API 1.7)

`symbol=` trong BotContext (engine.py: `_sym`, `foreign_candles`, `tick_of`); `run_backtest(extra=)`; test `tests/test_multisymbol.py`. Mã khác tự vào `session.watch`. Chưa làm: đối tượng vẽ do bot tạo, order book, tick-volume.

## 5zq. v1.9.45 — Tài liệu lập trình bot

`docs/BOT_DEV.md`: quy tắc viết bot, tham chiếu `self.api`, đối chiếu MQL5, bảng giới hạn so với EA. Test: `tests/test_bot_dev_doc.py` (tên API trong tài liệu phải tồn tại). Khi thêm hàm vào `BotContext`/`Ret`/khung giờ/danh sách chặn, cập nhật tài liệu này.

## 5zp. v1.9.44 — cTrader Open API (điện thoại, không trung gian)

`pyea/ctrader.py` (không Kivy): `CtConn` (WebSocket JSON 5036, `payloadType`, heartbeat 51 mỗi 10s, `_raw_call` theo clientMsgId, `trade_call` KHÔNG tự thử lại, chờ ExecutionEvent theo clientMsgId hoặc orderId/positionId/clientOrderId), `Tokens` (file chung `ctrader_tokens.json` ở ANDROID_PRIVATE; `origin` = refresh token trong Cài đặt: Cài đặt mới thắng), `CtraderBackend(MtBackend)` (lot = volume/lotSize; giá/nến /1e5; native limit+stop), OAuth cục bộ (`oauth_login`/`wait_for_code` HTTP 127.0.0.1:53682, `exchange_code`). Cắm vào `bridges.make_backend` (exchange="ctrader"), settings (nhóm «cTrader API»), keystore (3 bí mật), selfcheck. UI: `pyea/ui_ctrader.py` + 2 nút ở Cài đặt. Test: tests/test_ctrader.py + tests/fake_ctrader.py (MÁY CHỦ GIẢ theo tài liệu). CHƯA kiểm chứng với broker thật; các điểm mơ hồ ghi `# CHƯA XÁC MINH`.

## 5zo. v1.9.43 — phát lại backtest

`pyea/replay.py` (không Kivy): `Replay(res)` cắt lát nến/plots/events/curve tới nến `pos` bằng bisect (cửa sổ WINDOW=2000 nến). `BacktestTab.replay_toggle/replay_step/replay_exit/_replay_tick` (Clock 15 fps; tốc độ = `_speed_val`, 0→400/giây). `run()` gọi `replay_exit()`. Test: tests/test_replay.py. Chưa thử máy thật.

## 5zn. v1.9.42 — thanh tốc độ backtest

`run_backtest(speed=)` nhận số HOẶC hàm không đối số (đọc lại mỗi nến); hàm + `on_step` thì luôn gọi on_step (giao diện tự giới hạn 5 lần/giây), `progress` mỗi nến chỉ khi tốc độ > 0. `BacktestTab.speed_sp` (Spinner) ↔ `form.ctrl["speed"]` đồng bộ hai chiều; luồng chạy đọc `_speed_val` (không đọc widget từ luồng nền). Test: test_btanalysis.py. Chưa thử trên máy thật.

## 5zm. v1.9.41 — vẽ nến gom màu

`CandleChart._draw`: vòng nến chạy 2 lượt (UP rồi DOWN) với một `Color` mỗi lượt. Profile stub: Python ~2,4 ms/100 khung, ~540 lệnh canvas/khung; chi phí thật nằm ở số lệnh GL nên đề xuất kế tiếp là `Mesh` (chưa làm: stub không có Mesh, chưa thử máy thật). Import urllib/http không lười hoá được vì tab Thị trường cần ngay.

## 5zl. v1.9.40 — khởi động nhanh

Đo bằng stub (không phải máy thật): `_build_main` 158 ms → ~11 ms. Nguyên nhân chậm chưa từng được đo ở các bản "tối ưu" trước (chúng chỉ giảm request/vẽ lại, không đụng khởi động): (1) `SettingsTab` dựng ~780/1187 widget ngay; (2) `refresh_bots` nạp 12 bot (exec + 2-3 lần `check_bot_source`) rồi dựng thư viện hai lần. Nay `SettingsTab.gform` là property dựng lười (`built`; `_tab_changed` dựng khi mở tab), `refresh_bots(lazy=True)` chỉ nạp bot chọn, `_fill_infos` nạp dần mỗi lượt Clock một bot rồi `refresh_bots()` một lần; `inspect_bot` đọc/quét một lần (`load_bot_class(_pre=)`). Test: tests/test_startup_perf.py. Chưa làm: import lúc khởi động ~170 ms, cache lớp nến tĩnh khi lướt/zoom.

## 5zk. v1.9.39 — kéo thả SL/TP kiểu MT5, chống giật

`CandleChart`: lớp phủ `_ov` (Canvas riêng, thêm lại sau mỗi `redraw`; `request_overlay/_redraw_overlay` vẽ `_draw_draft` + `_draw_ldrag`), `_dyn_text` (chữ đổi liên tục, ≥60 ms/lần dựng), `_notify_draft` (≥120 ms, ép khi thả). Nhấn giữ: `touch_down` hẹn `_arm_drag` 0,4 s nếu chạm trúng đường kéo được (`_line_at`: tag `("pos"|"pend", id, "sl"|"tp"|"entry")`, trừ entry của lệnh đã khớp); `lock` pan/cuộn huỷ hẹn; thả -> `on_line_drag(tag, giá)` -> `PyEAApp.apply_line_drag` (kiểm bid/ask, `round_price`, `ctl.modify_position` / `ctl.modify_order`). `hlines` phần tử thứ 4 là tag 3 phần; `_hlhits` = `(y, tag, giá, màu, nhãn, ref)`. Tests: test_line_drag.

## 5zj. v1.9.38 — đa khung tự phát hiện, danh mục, mốc UTC

`loader.detect_mtf` (regex `timeframe="..."`) -> `BotInfo.mtf_auto`; `_load_htf(extra=)`; chạy đơn: `res.mtf` có khung `resampled` chưa nạp -> nạp rồi chạy lại 1 lần. `TradingSession.htf/htf_ends` khoá theo `(symbol, tf)` (`set_htf(htf, symbol)`, `add_htf`); `run_portfolio` đọc `entry["htf"]`. `feeds.utc_guard/utc_misaligned/history_via_1h`: `MtFeed/ExnFeed/CcxtFeed.history` = guard + `_native_history`. Nguồn tra: OANDA dailyAlignment mặc định 17 America/New_York (feed đã ép UTC), Binance timeZone mặc định UTC, count tối đa OANDA 5000 / Binance 1000.

## 5zi. v1.9.37 — cache khi nến đóng, backtest đa khung thật

`TradingSession.flush_cache` (gọi ở vòng lặp chính + `_finish`; `_cache_dirty` đặt trong `process_tick` khi nến đóng; khung < 1h tối thiểu 120 s giữa hai lần ghi; không ghi ở sync/simulated). `# @mtf: 1h,1d` -> `loader.parse_manifest/BotInfo.mtf`; `BacktestTab._load_htf` (HTF_DEPTH=300, qua `_candles` = kho nến) -> `run_backtest(htf=...)` -> `TradingSession.set_htf` (`htf`, `htf_ends` = `tf_next`); `BotRunner.other_candles(tf, include_current, count)` nguồn real (bisect theo giờ đóng <= giờ tick cuối; trước tick đầu = hết nến warm-up) / builder / resampled (bỏ nến đầu thiếu). `mtf_use` -> `summary()["mtf"]` và `BacktestResult.mtf`; UI `mtf_dialog`, `pyea/mtf.py`. Tối ưu/WF/độ nhạy truyền `htf`. Danh mục (`run_portfolio`) chưa nhận htf.

## 5zh. v1.9.36 — tương quan chỉ báo ↔ giá, tham số ↔ kết quả

`pyea/corrlab.py` (không Kivy): `spearman`, `align_plots` (giá trị gần nhất không sau thời điểm nến), `normalize` (chỉ báo cùng thang giá -> (close-v)/v), `indicator_vs_price` (lợi suất h nến sau, `n_eff=n/h`, `significant` = |t|≥3), `indicator_redundancy` (trên hiệu bậc 1, tránh tương quan giả giữa hai chuỗi cùng xu hướng), `param_effects` (tham số↔metric, cặp tham số trong 25% tốt nhất). UI: `BacktestTab.indicator_corr_dialog`, mục thêm trong `opt_stats_dialog`; `advice_from_run(corr=True)` / `advice_from_optimization` đính bảng vào prompt AI. Nguồn chỉ báo = `res.plots` (bot phải `api.plot`). Tối ưu/walk-forward/AI tư vấn đã có từ trước (btanalysis).

## 5zg. v1.9.35 — Back, đổi mã/khung của bot, chạm lệnh để sửa

`backnav.TabHistory` (lịch sử tab, không Kivy) + `PyEAApp.go_back` (popup trên cùng → huỷ draft biểu đồ → tab trước → nền); `ui_widgets.POPUP_STACK/top_popup`, `StyledPopup.back_blocks` (risk_dialog, điều khoản). `AttachTab` thêm nút → `edit_instance_dialog` / `apply_instance_target` (detach+attach cùng iid). `ui_widgets.TapPanel` (dòng vị thế/lệnh chờ chạm được), `CandleChart.on_line_tap` + tag thứ 4 của hlines `("pos"|"pend", id)`. Lỗi «không kéo ngang được» chưa tái hiện; chỉ giảm nguyên nhân khả dĩ (xem changelog).

## 5zf. v1.9.34 — màn hình «Bot hỏi AI»

`aiask.HIST_FILE` (`ai_ask_history.jsonl`, `AskService.history`/`_hist`: ghi mọi lần chạy + lần bị hạn mức throttled 60 s/key), `load_history/clear_history/usage_counts/hist_line/hist_detail`; `BotContext.ask_ai` gửi `bot=iid`; UI `ui_askhist.open_ask_history` (nút «Bot hỏi AI» ở `AITab`). File chung nên đọc được cả khi AskService chạy trong dịch vụ nền. `logrot` cắt còn 500 dòng.

## 5ze. v1.9.33 — bot gọi AI (api.ask_ai)

`pyea/aiask.py` (không Kivy): `AskService` (hạn mức giờ/ngày, cache theo key, pending nền, lỗi nhớ 30 s, che bí mật, ghi `ai_asks.jsonl`), schema (`validate/extract_json/schema_prompt`), `CONTEXT_PROVIDERS`/`build_context` (thêm nguồn = thêm hàm), `ReplayAsk/NullAsk`. `BotContext.ask_ai/ask_ai_info` (engine.py) -> `AIHub.ask` -> `AskService`; backtest: `airec.NullHub/ReplayHub.ask`, `SignalList.asks` do `BacktestTab._ai_replay` nạp. `ai.chat_completion` gộp `extra_body` (JSON); agent có `extra_body/web_model/web_extra_body`. `sdk.AIAnswer` (đã vào `botproc._CLASSES`), API 1.6, perm `ai_ask`. Tài liệu docs/BOT_AI.md, mẫu `ai_advisor.py.txt`, KB `bot_ask_ai`. Chưa kiểm chứng với AI/tra web thật.

## 5zd. v1.9.32 — tách kết nối / chạy bot

`PyEAApp.start_session(run_bots=None)` (`_run_bots`: True = bot `auto` chạy khi kết nối; False = chỉ kết nối; None = như lần trước), `_make_config` đặt `running = auto and _run_bots`, `run_bots_or_connect` (nút tab Bot), `_reconnect` giữ trạng thái chạy bot. `toggle_session`/nút «Kết nối» ở biểu đồ = `run_bots=False`. `export_diagnostics` thêm `boot.log` (bootlog.path) + `crash.log.old`. Nguyên nhân app thoát khi vừa kết nối CHƯA xác định (nhật ký người dùng gửi không có ngăn xếp).

## 5zc. v1.9.31 — kho nến backtest + CSV

`pyea/candlestore.py` (không Kivy): `CandleStore` (file `<nguồn>__<MÃ>__<khung>.bin`, header `PYC1`+uint32, dòng `<6d`, đọc bằng seek/bisect, `put` nối đuôi tại chỗ, nối đầu/chồng lấn ghi lại nguyên tử, `MAX_STORED`=300k), `get_candles` (chỉ tải đuôi + phần cũ; yêu cầu CHỒNG LÊN ít nhất 1 nến đã lưu, không thì `fresh()` bỏ chuỗi và tải lại; chỉ nến đã đóng; `pull(n+1)` bù nến đang chạy dở), `parse_csv/to_csv/detect_tf/import_csv_text/export_csv` (xuất từng khúc 20k). `source_key(settings)`: simulated -> None (không lưu), ccxt -> `ccxt-<id>`; nhập CSV dùng nguồn `file`. UI: `ui_candles.open_data_dialog`, `BacktestTab._candles/candle_store/data_dialog`, ô `data_source`. Kho nằm ở `<data_dir>/candles`; xuất CSV vào `exports/`. Giới hạn: nguồn «public» có thể trộn nhiều nguồn dự phòng (Binance/Bybit/…) trong một chuỗi; giờ CSV coi là UTC. Chưa kiểm chứng trên máy thật (chọn file SAF, hiệu năng thật).

## 5za. v1.9.29 — báo động kiểu báo thức khi máy khởi động lại

`BootReceiver.alert()`: kênh `pyea_boot_alarm` (IMPORTANCE_HIGH, âm TYPE_ALARM + AudioAttributes USAGE_ALARM, rung, bypass DND nếu được cấp, VISIBILITY_PUBLIC), `CATEGORY_ALARM` + `FLAG_INSISTENT` (lặp tới khi vuốt bỏ). Id 7302 (chưa mở khoá), 7303 (đã khôi phục), 7301 (khởi động dịch vụ thất bại). Không dùng full-screen intent (Android 14+ chỉ cho app gọi/báo thức). Chưa kiểm chứng trên máy thật.

## 5z. v1.9.28 — nhắc mở khoá sau khởi động

`BootReceiver` thêm LOCKED_BOOT_COMPLETED (receiver `directBootAware`): nếu `UserManager.isUserUnlocked()` còn false và có cờ trong kho device-protected (`android_native.device_files_dir`, dịch vụ sao cờ qua `bootflag.sync(..., mirror_dir)`), phát thông báo 7302 «mở khoá để bot chạy lại»; BOOT_COMPLETED sau đó huỷ thông báo và dựng dịch vụ. KHÔNG chạy Python trước khi mở khoá: p4a giải nén Python/mã app vào `getFilesDir()/app` (kho credential, chỉ có sau mở khoá); chuyển sang device-protected cần vá sâu PythonActivity/PythonUtil + dời API key ra kho kém an toàn. Chưa kiểm chứng trên máy thật.

## 5y. v1.9.27 — tự chạy lại sau khi khởi động máy

`android_src/org/pyea/pyearunner/BootReceiver.java` (BOOT_COMPLETED / MY_PACKAGE_REPLACED / QUICKBOOT_POWERON) dựng lại `ServiceBotservice` nếu có cờ `files/boot_resume.flag`; cờ do `pyea/bootflag.py` giữ qua `ServiceHost._boot_want` (phiên cần chạy + `auto_resume` + `start_on_boot`). `buildozer.spec`: `android.add_src`, `p4a.hook = tools/p4a_hook.py` (chèn `<receiver>` vào mẫu manifest vì buildozer không có tuỳ chọn này), quyền `RECEIVE_BOOT_COMPLETED`. CI có bước «Verify boot receiver in manifest» (báo lỗi nếu manifest thiếu). Android 15 chặn FGS dataSync/camera/mediaPlayback/phoneCall/mediaProjection/microphone từ boot; `specialUse` thì không. Chỉ đọc được files dir sau khi mở khoá (không dùng LOCKED_BOOT_COMPLETED). Chưa kiểm chứng trên máy thật; báo thức AlarmManager bị xoá khi khởi động lại nên watchdog được đặt lại bởi dịch vụ sau khi dựng.

## 5x. v1.9.26 — chuẩn tham số bot

`sdk.Input(choices=dict|Enum, subtype=color|time|datetime|text)`, `sdk.Group`, `Input.label_of`; `loader.collect_inputs` áp `Group` cho Input phía sau; `ParamForm` hiện nhãn (`_lab`). Tài liệu docs/BOT_INPUTS.md, bot mẫu inputs_standard.py.txt, `PyEAApp.ai_convert_inputs`, mục KB `bot_inputs`.

## 5w. v1.9.25 — phản hồi nút NGẮT, nhận dạng tham số rộng hơn

`PyEAApp._stop_t/_force_stop` (phản hồi + hỏi buộc dừng sau 10s -> `native.stop_service`). `loader._auto_inputs`: nhận cả `Assign` không chú thích (trừ tên thuộc về BaseBot) và `{min..max step s}` trong chú thích.

## 5v. v1.9.24 — tiêu điểm xuống chỉ báo, lọc nến hỏng, hộp thoại API theo nhóm

`CandleChart._subgeo/cross_pane` (hình học cửa sổ phụ ghi lúc vẽ; `_cross_price_from_y` dùng `_pm` + cửa sổ phụ). `publicfeed.clean_candles`. `ParamForm.open_api_dialog` viết lại (nhóm, thẻ, ghim nút). Nút lịch sử ở ChartTab/TradeTab -> `open_history_dialog` (ui_shell, histview).

## 5u. v1.9.23 — hộp thoại API, nguồn của phiên, lịch mẫu

`ParamForm.open_api_dialog` thay mục gập (`_sec_box` không gắn vào cây, chỉ giữ giá trị). `PyEAApp.feed_exchange()` + `_sess_ex`; `_commit_settings` hỏi kết nối lại khi đổi sàn lúc đang chạy. `econcal.PRESET_URL/resolve_source`: nguồn trống/auto = lịch tuần faireconomy (không chính thức; ttl >= 1h).

## 5t. v1.9.22 — nguồn dự phòng cho «public»

`publicfeed.py` viết lại thành chuỗi nguồn: `BinanceSrc/BybitSrc/OkxSrc/CoinbaseSrc/KrakenSrc` (crypto), `YahooSrc/TwelveDataSrc` (+PAXG cho vàng); `PublicFeed._run` thử theo thứ tự, nguồn lỗi nghỉ `COOLDOWN`=60s, `active[mã]`. Định dạng phản hồi đã đối chiếu tài liệu Bybit/Kraken/Coinbase/Twelve Data; OKX theo hiểu biết (chưa đọc được trang tài liệu) -> kiểm khi chạy thật. Setting `twelvedata_key` (secret, nằm trong keystore).

## 5s. v1.9.21 — nguồn giá thật «public» (không cần API)

`pyea/publicfeed.py`: `route()` (Binance cho crypto, Yahoo `v8/finance/chart` cho phần còn lại; XAUUSD->GC=F, US500->^GSPC, cặp forex->XXXYYY=X), `parse_yahoo`, `PublicFeed` (tick cache 2s, lịch sử có ghép khung). `exchange="public"` thuộc `settings.NO_BROKER` -> live bị chặn (engine/ui/headless/brokerhist). Chưa thử với mạng thật (sandbox chặn Yahoo): kiểm trên máy.

## 5r. v1.9.20 — tắt/đặt chế độ cảnh báo mạng, kéo dọc cột giá

Setting `net_alert` (connected|always|off); `_net_step` chỉ hiện dải đỏ khi được phép, chạm dải = mute tới khi có mạng. `CandleChart.pshift/pzoom` + zone `paxis`: kéo dọc cột giá dời thang giá; `reset_view` xoá.

## 5q. v1.9.19 — cảnh báo mất mạng, nhãn dữ liệu giả lập

`pyea/netwatch.py` (thăm dò TCP luồng nền) + dải đỏ `net_banner` trong `_build_main` (root bọc trong BoxLayout). Chart/Market ghi «giả lập» khi exchange=simulated. ParamForm section luôn mở. Bỏ toast ✚. `CandleChart.update` bỏ qua khi dữ liệu không đổi. Chưa kiểm trên máy thật.

## 5p. v1.9.18 — nút tiêu điểm ✚ kiểu MT5

Góc trên-phải `CandleChart` có nút ✚ tròn (`crosshair_mode`). BẬT: một ngón chạm/kéo đặt `cross` (x bám nến, y là giá) và không lướt; TẮT: kéo lướt như cũ (chạm nhanh vẫn hiện tiêu điểm). Hai ngón luôn thu/phóng. Nhãn thời gian vẽ ở trục dưới. Chưa kiểm trên máy thật.

## 5o. v1.9.17 — sửa lỗi bố cục báo từ máy thật
Báo từ người dùng: không chụp được màn hình; chạm tam giác API không thấy ô nhập; bảng che nửa tab Cài đặt; kéo chọn mục khó; không có đặt lệnh trên biểu đồ. Nguyên nhân tìm được (từ mã, CHƯA nhìn trên máy thật): (1) `secure_screen="sensitive"` mặc định → chặn chụp ở tab Cài đặt (nay `off` + `storage.migrate_defaults`); (2) SettingsTab có ~8 hàng nút cố định ngoài vùng cuộn; (3) ScrollView mặc định `scroll_timeout=55ms` để TextInput/Switch/Spinner giành touch → khó kéo; (4) 1.9.15 tôi dồn thêm nút «Kiểu» vào hàng đầu tab Biểu đồ làm «＋» bị ép nhỏ. Test `tests/test_ui_layout_fixes.py` kiểm CẤU TRÚC (stub Kivy không đo pixel) - vẫn cần xác nhận bằng mắt trên điện thoại. Nếu «tam giác API» vẫn không mở: gửi ảnh chụp tab Cài đặt (nay chụp được) để chẩn đoán.
