# PyEA Runner - Hướng dẫn người dùng

> App chạy bot giao dịch (EA) + biểu đồ trên điện thoại. **Mặc định là PAPER (giả lập, không tiền thật).** Kết quả backtest/paper không đảm bảo kết quả thật. Đọc «Cảnh báo rủi ro» trong app trước khi dùng tiền thật.

## 1. Bắt đầu trong 5 phút
1. Mở app lần đầu → đọc và đồng ý Điều khoản/Riêng tư → làm theo hướng dẫn 6 bước (xem lại: **Cài đặt → Hướng dẫn · điều khoản · riêng tư · cập nhật**).
2. Muốn thử ngay không cần tài khoản: **Cài đặt → … → Dùng cài đặt mẫu an toàn** (paper + nguồn «simulated»).
3. Tab **Thị trường → KẾT NỐI** → thấy giá các mã.
4. Tab **Bot** → chọn `ma_cross.py` → gắn vào mã + khung → chạy.
5. Chạm chấm ▲▼ trên **Biểu đồ** để xem *lý do* mỗi lệnh.

## 2. Kết nối sàn thật
Cài đặt → «Nguồn thị trường / sàn» → chọn sàn → dán khoá API ở mục «KẾT NỐI SÀN / API».
- Dùng khoá **demo/testnet** trước; khoá chỉ có quyền giao dịch, **không bật quyền rút tiền**.
- Binance Futures: hỗ trợ cả **One-way** và **Hedge mode** (tự nhận). Trong Hedge mode app vẫn chỉ giữ một chiều mỗi mã.
- Lịch sử từ sàn: tab Giao dịch/Lịch sử (OANDA, Binance Spot, Binance Futures, ccxt, MT, Exness). Binance Spot không báo lãi/lỗ nên cột lãi/lỗ = 0 (app không tự bịa).
- Sau khi bật chế độ **live**, kiểm tra bằng Nhật ký → *Kiểm tra hệ thống* với lệnh nhỏ nhất.

## 3. Biểu đồ
- Kéo ngang = lướt · chụm = thu/phóng · chạm nến = xem giá/chỉ báo · chạm 2 lần = về mặc định.
- **＋** = đặt lệnh ngay trên biểu đồ: kéo đường vào/SL/TP, bấm → để gửi.
- **Vẽ** = công cụ vẽ: đường ngang, đường xu hướng, hình chữ nhật, Fibonacci, chữ. Chạm 1-2 điểm; chạm vào hình đã vẽ để xoá; «Danh sách đối tượng» để xoá từng cái/tất cả. Hình lưu theo từng mã. Hình vẽ **không** tự đặt lệnh.
- 33 chỉ báo MT5, 21 khung thời gian.

## 4. Backtest
Tab Backtest: chọn bot, mã, khung, số nến hoặc khoảng ngày → CHẠY. «Tốc độ chạy» ≠ Tối đa = xem từng nến như Visual mode (có Tạm dừng).
- **Báo cáo HTML**: biểu đồ tăng trưởng/sụt vốn + phân tích theo mã/phiên/giờ/thứ; mở bằng trình duyệt, in ra PDF được. Cũng có ở tab Lịch sử (từ sổ app).
- **Debug bot**: đặt «Debug bot» = *Từng dòng* hoặc *Chỉ điểm dừng* (+ «Điểm dừng», vd `42, 57:rsi < 30`), chạy, rồi bấm «Nhật ký debug». Ghi 5 lần gọi đầu của on_bar/on_tick; không đổi kết quả backtest.
- Tối ưu hoá, walk-forward, danh mục, độ nhạy thứ tự giá trong nến: các nút bên dưới.

## 5. An toàn
- «Dừng bot nếu lỗ quá (%)», «Chế độ CHỈ-XEM», SL/TP native (sàn canh khi app tắt, nếu sàn hỗ trợ).
- Cài đặt → **Sao lưu** định kỳ; Gói chẩn đoán đã che khoá API.
- Một số hãng điện thoại giết app nền: tắt tối ưu pin cho app, bật dịch vụ nền.

## 6. Cập nhật & báo lỗi (mặc định TẮT)
- **Kiểm tra cập nhật**: Cài đặt → «Hỗ trợ & cập nhật» → nhập kho GitHub `chủ/tên` (cần Releases có file .apk). App chỉ báo có bản mới; bạn tự cài.
- **Tự gửi báo lỗi**: bật + nhập địa chỉ `https://...` của máy chủ BẠN nhận. Chỉ gửi nhật ký lỗi đã che bí mật. App không có máy chủ của tác giả và không có telemetry.

## 7. Hỏi đáp
- **Không thấy giá?** Kiểm tra mạng/khoá API; Nhật ký → Kiểm tra hệ thống. Binance có thể bị chặn theo vùng (đổi `base_url`).
- **Bot không vào lệnh?** Chạm chấm ghi chú trên biểu đồ/Nhật ký để xem bot nói gì; xem tab Bot (trạng thái), bật Debug khi backtest.
- **App chậm/nóng?** Cài đặt → «Tải thiết bị» xem CPU/RAM và thời gian callback của từng bot (Profiler); giảm số chỉ báo/bot, bật «Tiết kiệm pin».
- **Hỏi Trợ lý** (tab AI/Cài đặt → Trợ lý) trả lời cả khi không có mạng.

## Mới ở 1.9.15
- **Dùng thử 90 ngày** (chỉ bản cài từ Google Play): Cài đặt → «Hướng dẫn · điều khoản · riêng tư · cập nhật» → «Bản quyền». Gửi «ID thiết bị» cho người cấp khoá để kích hoạt sau khi hết hạn. Bản cài ngoài Play không bị giới hạn.
- **Giao diện sáng**: Cài đặt → Giao diện (dark / light / auto), mở lại app.
- **Biểu đồ**: nút «Kiểu» (Renko, Range, gộp N nến), «Sổ lệnh (DOM)» và «Thông số mã» (Binance).
- **Backtest tick thật**: ô «Mô phỏng tick» → «Tick thật (Binance aggTrades)». Futures chỉ có 48 giờ gần nhất.
- **Phiên bản bot**: tab Bot → «Phiên bản bot (hoàn tác / khôi phục)».

## Mới ở 1.9.16
- **VPS/Docker**: `python -m pyea.headless --data-dir /var/lib/pyea` (xem docs/vps/). LIVE cần thêm `--accept-risk`.
- **Đồng bộ đa thiết bị**: menu «Hướng dẫn · điều khoản…» → «Sao lưu / đồng bộ» (file hoặc WebDAV, mã hoá bằng mật khẩu của bạn).
- **Chợ bot**: tab Bot → «Chợ bot (gói có chữ ký)»; người bán dùng `tools/bot_pack.py`.
- **Copy trading**: bot mẫu «Copy trading - Bot chủ» và «Bot theo»; đặt cùng khoá bí mật và cùng nơi đặt tín hiệu.

## Mới ở 1.9.50

- **Cài đè bản mới không cần gỡ bản cũ** (làm MỘT lần): (1) **thay file `.github/workflows/build-apk.yml` trong repo bằng file cùng tên của dự án** (hoặc `docs/build-apk.yml`). Upload file zip KHÔNG thay file này và GitHub không cho bot tự sửa nó; nếu repo vẫn chạy workflow cũ thì mỗi build có một khoá ký ngẫu nhiên và KHÔNG BAO GIỜ cài đè được. Build mới sẽ hiện cảnh báo vàng khi file workflow trong repo khác bản đi kèm dự án. (2) tạo secret `PYEA_KEY_SEED` trên GitHub (Settings → Secrets → Actions, một chuỗi dài ≥ 32 ký tự, GIỮ KỸ, không dán vào chat, mất là không cài đè được nữa). Bản đã cài bằng khoá cũ vẫn phải gỡ MỘT lần; từ bản sau đó cài đè bình thường.
- **Khối lượng theo rủi ro** (bot): `vol = self.api.size_for_risk(giá_vào, giá_SL, risk_pct=1.0)` → lỗ đúng ~1% vốn nếu dính SL. Làm tròn xuống, trả 0 nếu dưới mức tối thiểu (khai `# @api_min: 1.9`).
- **Giới hạn lỗ trong ngày** (Cài đặt → Tài khoản / rủi ro, mặc định tắt): chạm mức thì khoá lệnh MỚI tới hết ngày (đóng lệnh vẫn chạy); xem ô «hôm nay» trên màn hình chính.
- **Kelly và VaR/CVaR**: Backtest → «Monte Carlo + Sortino…» → mục «Rủi ro». Chỉ là ước lượng từ lịch sử; Kelly âm = chiến lược không có lợi thế; đừng đặt cược theo full Kelly.
- **Giờ giao dịch và ngày nghỉ lễ VN**: lịch 2026 có sẵn; **năm khác app KHÔNG đoán** (báo «chưa biết») nên thêm ngày nghỉ ở Cài đặt → DNSE hoặc đặt file lịch tự cập nhật (xem `docs/DNSE.md`). Bật «Chặn lệnh ngoài giờ giao dịch» nếu muốn app không gửi lệnh mới khi sàn đóng. Ngoài giờ/nghỉ lễ thì giá đứng là bình thường: app không còn báo «mất kết nối giá» oan; còn mất kết nối thật thì vẫn báo (mất kết nối KHÔNG có nghĩa là ngày nghỉ).
- **Nhật ký lệnh**: Giao dịch → bấm một lệnh trong LỊCH SỬ → «Nhật ký» (ghi chú, thẻ như `fomo`, điểm 1-5★). Thống kê lãi/lỗ theo thẻ và xuất CSV ở cùng màn hình; có trong sao lưu.
- **Webhook TradingView ngay trong app** (Cài đặt → «Webhook TradingView (trong app)»): tắt mặc định, mặc định chỉ kiểm tra. Điện thoại không có địa chỉ công khai nên PHẢI có đường hầm HTTPS (cloudflared/ngrok); đọc `docs/WEBHOOK.md` trước khi bật. Chưa thử trên máy thật.
- **Sửa an toàn**: khoá Capital.com trước đây lưu chữ rõ; nay mã hoá như khoá khác. Nếu từng gửi bản sao lưu có Capital.com cho người khác, hãy tạo lại API key.
- **MT5 nhúng báo phần trăm đúng; tự dừng khi bộ cài «quay vòng»**: nếu bộ cài MT5 chiếm CPU mà không tiến triển, sau ~10 phút app dừng và ghi báo cáo. Khi gặp, bấm «Sao chép chẩn đoán» và gửi nội dung (mục «quay vòng», stages.log). Chưa kiểm trên máy thật.
- **DNSE: bước giá lệnh LO**: app tự làm tròn giá lệnh chờ về bước giá hợp lệ (mua xuống, bán lên). Mã HNX/UPCoM chọn «hnx», ETF/chứng quyền chọn «etf» trong Cài đặt → DNSE.
- **MT5 chạy NGAY trong app, không cần Termux** (Cài đặt → nút xanh «Kết nối MT5 nhanh» → nhập Login, Mật khẩu, Server → Bắt đầu): app tự tải và cài một máy ảo nhỏ (proot + Ubuntu + Box64 + Wine + MetaTrader 5). Lần đầu nặng (vài trăm MB, có thể vài chục phút, cần ~4 GB trống, nên cắm sạc + Wi-Fi), các lần sau chỉ bật MT5. Có nút Dừng / Chạy lại / Xoá sạch và dòng CPU/RAM thật. Mặc định chạy «cấu hình nhẹ» để đỡ tốn CPU/RAM (Cài đặt → «MT5 nhúng: cấu hình nhẹ»).
- **Lưu ý của MT5 nhúng**: APK nhắm Android mới (API 36) nên Google Play Protect không chặn cài; proot nằm sẵn trong APK. Vẫn **chỉ cài ngoài, không có trên Google Play** (Play cấm app tải mã chạy được từ ngoài). Nếu Play Protect báo «xây dựng cho phiên bản Android cũ» thì APK đó là bản cũ nhắm targetSdk 28: hãy cài bản mới (tạm thời có thể tắt «Quét ứng dụng bằng Play Protect» rồi bật lại). Android 12-14 có thể tự giết tiến trình con: bật «Tắt giới hạn tiến trình con» (Tuỳ chọn nhà phát triển) và cho PyEA chạy nền không giới hạn pin. **Chưa chạy thử trên điện thoại thật** - dùng tài khoản DEMO trước.
- **Kết nối MT5 nhanh** (MT5 thật chạy trong giả lập trên điện thoại, cài tự động): Cài đặt → nút xanh đầu trang → nhập login, mật khẩu, server → Bắt đầu → cài Termux (F-Droid) một lần → «Sao chép lệnh» → mở Termux, dán, Enter. Phần còn lại tự chạy và hiện tiến trình trong app. Lần đầu lâu và tốn dung lượng; các lần sau chỉ bật lại (`bash ~/pyea-start-mt5.sh`). Chưa thử trên máy thật: dùng DEMO trước. Chi tiết, giới hạn: `docs/MT5_QUICK.md`. (Nút «MT5 trên đám mây MetaApi» là lựa chọn khác, có thể tính phí: `docs/METAAPI_CLOUD.md`.)
- **Bot theo luật**: nạp bot mẫu «Bot theo luật», gõ điều kiện, ví dụ `cross_above(sma(close, 10), sma(close, 30)) and rsi(close, 14) < 70`. Hàm: sma ema rsi stdev highest lowest atr bb_upper/bb_lower/bb_mid macd macd_signal prev cross_above cross_below. Chưa đủ dữ liệu = điều kiện sai.
- **Tối ưu di truyền**: Backtest → Tối ưu hoá → «Phương pháp: Di truyền» khi lưới quá lớn.
- **Monte Carlo**: Backtest → nút «Monte Carlo + Sortino…» sau khi chạy.
- **Webhook TradingView**: mã `BINANCE:BTCUSDT.P` tự về `BTCUSDT`; ánh xạ riêng bằng `--webhook-symbol-map "XAUUSD=GOLD"` (cổng MT) hoặc ô «Ánh xạ mã» (trong app).

## Mới ở 1.9.49

DNSE: chọn nguồn «dnse», xem docs/DNSE.md (OTP, gói vay, giới hạn).

## Mới ở 1.9.48

Trần đối tượng vẽ chỉnh được; DNSE: xem docs/DNSE.md.

## Mới ở 1.9.47

Bot vẽ lên biểu đồ (`api.draw_*`), sổ lệnh/giao dịch khớp (`api.order_book`, Binance), giá Binance đẩy qua WebSocket (cài đặt, mặc định bật).

## Mới ở 1.9.46

Bot đa mã: dùng `symbol="ETHUSD"` trong `self.api.candles/buy/...` (xem docs/BOT_DEV.md).

## Mới ở 1.9.45

Tài liệu cho người viết bot: `docs/BOT_DEV.md` (quy tắc, API, đối chiếu MQL5, giới hạn so với EA).

## Mới ở 1.9.44
- **cTrader nối thẳng từ điện thoại** (không máy tính/VPS/trung gian): (1) đăng ký ứng dụng ở openapi.ctrader.com bằng cTrader ID, ghi Client ID/Secret, thêm Redirect URI `http://localhost:53682/callback`; (2) Cài đặt → Sàn = ctrader, nhập Client ID/Secret; (3) bấm «Đăng nhập cTrader» → đăng nhập, cho phép; (4) bấm «Chọn tài khoản cTrader» → chọn DEMO; (5) kết nối. Luôn thử DEMO trước. Chưa kiểm chứng với sàn thật.
- ccxt chỉ có sàn crypto (không có Exness). Exness: dùng «Exness API» (nếu tài khoản thuộc khu vực được mở API); tài khoản MT5 thường phải qua cầu nối.

## Mới ở 1.9.43
- **Backtest → ▶ Phát lại**: xem lại lần chạy đã xong từng nến (nến, chỉ báo, chấm vào/ra, đường vốn), có tạm dừng, lùi/tiến, đổi tốc độ khi đang phát.

## Mới ở 1.9.42
- **Backtest**: thanh «Tốc độ (nến/giây)» ngay dưới nút CHẠY, đổi được cả khi đang chạy.

## Mới ở 1.9.41
- **Biểu đồ nhẹ hơn khi lướt/phóng to** (nến vẽ gom theo màu, hình không đổi).

## Mới ở 1.9.40
- **Khởi động nhanh hơn**: form Cài đặt chỉ dựng khi bạn mở tab đó; bot mẫu hiện tên file rồi tự cập nhật tên sau vài khoảnh khắc. Không mất tính năng nào.

## Mới ở 1.9.39
- **Sửa nhanh SL/TP bằng kéo thả**: nhấn giữ lên đường SL/TP trên biểu đồ → kéo → thả tay là áp dụng. Chạm nhanh vào đường hoặc dòng lệnh để mở hộp sửa chi tiết.

## Mới ở 1.9.37
- **Bot đa khung**: trong bot dùng `self.api.candles(100, timeframe="4h")`. Muốn backtest dùng nến THẬT của khung đó, thêm dòng đầu file bot `# @mtf: 4h, 1d`. Xem bot đang dùng khung nào: «Khung dữ liệu bot dùng».
- **Cache nến** được ghi ngay khi nến đóng: mở lại sau khi máy khởi động lại/app crash chỉ tải bù đoạn ngắn.
