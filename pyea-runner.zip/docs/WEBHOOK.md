# Webhook TradingView chạy NGAY TRONG APP (1.9.50)

Alert của TradingView → HTTP POST → app kiểm tra → đặt/đóng lệnh trong phiên đang kết nối (paper hoặc live). Mã: `pyea/webhooksrv.py` (máy chủ) + `pyea/webhook.py` (kiểm tra tín hiệu).
Cách cũ vẫn còn: chạy `gateway/mt_gateway.py --webhook-secret …` trên một máy/VPS riêng (xem `docs/BOT_DEV.md`). Dùng trong app khi không có máy riêng.

## Đọc trước khi bật: 4 sự thật
1. **Điện thoại không có địa chỉ công khai.** TradingView chỉ gọi được cổng **80/443** của một địa chỉ công khai. Cần một **đường hầm** (cloudflared, ngrok, Tailscale Funnel…) nhận HTTPS ở ngoài rồi chuyển về cổng của app trên máy. Không có đường hầm thì TradingView không tới được app.
2. **Máy chủ trong app nói HTTP thường.** Secret nằm trong nội dung JSON (TradingView không ký HMAC được) nên **chỉ cho đi qua đường hầm HTTPS**. Đừng mở cổng thẳng ra Internet.
3. **TradingView chờ tối đa 3 giây và không hứa gửi lại khi lỗi.** App trả lời ngay rồi mới đặt lệnh (chạy luồng riêng). Điện thoại ngủ/Android giết app/mất mạng = **mất tín hiệu**, không có hàng đợi bù. Đừng dùng cho chiến lược mà một tín hiệu rơi mất gây thiệt hại lớn khi không có SL.
4. **Chưa thử trên máy thật.** Phần máy chủ được kiểm bằng ổ cắm thật trên 127.0.0.1 (giao thức, giới hạn, khoá dò secret, vòng đời, nối vào phiên paper) nhưng CHƯA thử với đường hầm thật, TradingView thật, hay Android thật. Thử bằng chế độ «chỉ kiểm tra» trước.

## Mặc định an toàn
| Cài đặt | Mặc định | Ý nghĩa |
|---|---|---|
| Bật máy chủ webhook | **tắt** | Chỉ chạy khi phiên đang kết nối, không bao giờ khi backtest |
| Chỉ kiểm tra (dry-run) | **bật** | Nhận và kiểm tra tín hiệu, ghi nhật ký, **không đặt lệnh**. Thử xong mới tắt |
| Địa chỉ nghe | `127.0.0.1` | Chỉ chính điện thoại (đường hầm chạy cùng máy). `0.0.0.0` = cả Wi-Fi/LAN |
| Cổng | 8787 | Android không cho mở cổng dưới 1024. Địa chỉ công khai trên TradingView vẫn là 80/443 của đường hầm |
| Secret | trống | Bắt buộc **≥ 16 ký tự**, lưu mã hoá như khoá API, không vào bản sao lưu xuất ra |
| «close»/«close_all» đóng | `own` | Chỉ vị thế do webhook mở. `all` = mọi vị thế của mã đó (hoặc tất cả) kể cả lệnh tay/bot |
| Khối lượng tối đa | 0 | **LIVE + không dry-run bắt buộc > 0**, nếu không app từ chối bật (phòng lộ secret/gõ nhầm số lượng) |

## Cài đặt từng bước
1. Cài đặt → nhóm **Webhook TradingView (trong app)**: đặt secret dài, ngẫu nhiên (đừng dùng lại mật khẩu nơi khác); giữ «chỉ kiểm tra» bật; điền **Chỉ nhận các mã** và **Khối lượng tối đa**.
2. Mở đường hầm trỏ về `http://127.0.0.1:8787` (ví dụ, chưa kiểm trên máy này: cloudflared `cloudflared tunnel --url http://127.0.0.1:8787` → được địa chỉ `https://….trycloudflare.com`; ngrok `ngrok http 8787`). Địa chỉ miễn phí thường **đổi mỗi lần chạy** → phải sửa lại alert.
3. Nếu đi qua đường hầm của bạn, bật «Tin X-Forwarded-For» để app thấy IP thật của người gọi (cần cho bộ lọc IP và khoá IP, xem dưới).
4. Kết nối phiên. Nhật ký phải có dòng «Webhook TradingView đang nghe 127.0.0.1:8787/v1/webhook/tradingview (CHỈ KIỂM TRA…)».
5. Thử tại chỗ (cùng máy): `curl -s -X POST http://127.0.0.1:8787/v1/webhook/tradingview -d '{"secret":"<secret>","id":"t1","action":"buy","symbol":"BTCUSDT","volume":0.01}'` → `{"ok": true, "dry_run": true, "order": {...}}`.
6. Trên TradingView: Alert → Notifications → Webhook URL = `https://<địa chỉ đường hầm>/v1/webhook/tradingview`; nội dung (Message) là JSON bên dưới. Xem alert tới trong nhật ký của app.
7. Hài lòng thì tắt «chỉ kiểm tra». Bắt đầu với khối lượng tối thiểu.

## Nội dung alert (JSON)
```json
{"secret":"<secret>","id":"{{ticker}}-{{time}}-{{strategy.order.action}}","action":"{{strategy.order.action}}","symbol":"{{ticker}}","volume":{{strategy.order.contracts}},"sl":0,"tp":0,"comment":"tv"}
```
* `action`: `buy` · `sell` · `close` (đóng mã đó) · `close_all`; bí danh `long/short/exit/flat…` được nhận. Chỉ `buy`/`sell` cần `volume`.
* `id`: chống trùng trong 1 giờ (TradingView đôi khi gửi lặp) → lần trùng trả `duplicate: true`, **không đặt lệnh lần hai**. Nên có.
* `symbol`: tiền tố sàn `BINANCE:` và hậu tố `.P`/`1!` tự bỏ. **App không đoán tên mã của sàn**: `VN30F1M` → mã hợp đồng thật (vd `VN30F2612`) phải khai ở «Ánh xạ mã» (`VN30F1M=VN30F2612`). Danh sách «Chỉ nhận các mã» so SAU khi đổi mã.
* Với DNSE: lệnh webhook đi qua cùng cổng lệnh của phiên nên **«Chặn lệnh ngoài giờ giao dịch»** (nếu bật) vẫn áp dụng, và giới hạn lỗ ngày/kill switch/chặn tin vẫn chặn lệnh mới.

## Lớp phòng thủ
* Chỉ `POST` đúng đường dẫn `/v1/webhook/tradingview`; `Content-Length` bắt buộc và ≤ 4096 byte, kiểm TRƯỚC khi đọc thân; không nhận `Transfer-Encoding`.
* Hạn chót TỔNG 8 giây cho mỗi kết nối (chống nhỏ giọt từng byte), tối đa 8 kết nối cùng lúc (quá thì trả 503).
* Secret so sánh hằng thời gian; tối đa 30 tín hiệu/phút; kiểm mã cho phép/khối lượng tối đa; danh sách IP (tuỳ chọn, «tradingview» = 4 IP chính thức).
* **Khoá IP dò secret:** 8 lần sai trong 5 phút → khoá IP đó 10 phút (HTTP 429). Chỉ bật khi app phân biệt được người gọi (bật «Tin X-Forwarded-For», hoặc nghe `0.0.0.0`). Nghe `127.0.0.1` mà không tin tiêu đề thì mọi yêu cầu qua đường hầm đều trông như từ `127.0.0.1`: khoá «IP đó» sẽ chặn luôn TradingView thật (kẻ xấu cố tình gửi sai là chặn được tín hiệu thật), nên khi đó app **không khoá**, chỉ **cảnh báo** («Webhook bị dò secret?») khi ≥ 20 lần sai/5 phút: đổi secret ngay.
* Lỗi cấu hình alert (JSON sai, mã/khối lượng bị từ chối) KHÔNG tính vào khoá IP.
* App không bao giờ ghi nội dung thân/secret vào nhật ký hay phản hồi.

## Mã phản hồi
`200` nhận (`accepted`/`dry_run`/`duplicate`) · `400` JSON/`action`/`volume` sai · `401` sai secret/chữ ký · `403` IP/mã/khối lượng không được phép · `404` sai đường dẫn · `405` không phải POST · `408` đọc thân quá chậm · `411` thiếu `Content-Length` · `413` thân > 4096 byte · `429` quá nhiều tín hiệu/đang khoá IP · `503` quá nhiều kết nối. Phản hồi `200` chỉ nghĩa là **đã nhận và kiểm tra hợp lệ**; kết quả đặt lệnh nằm trong nhật ký (đặt lệnh chạy sau khi đã trả lời).

## Đổi secret
Sửa ở Cài đặt rồi **ngắt/kết nối lại phiên** (máy chủ đọc cấu hình lúc phiên bắt đầu), sửa alert TradingView. Đổi cổng/địa chỉ nghe cũng cần kết nối lại.
