# Kết nối MT5 nhanh = MT5 THẬT trong giả lập trên điện thoại, cài tự động

**Yêu cầu**: người dùng chỉ nhập thông tin đăng nhập (login, mật khẩu, server); không phải tự cài Box64/Wine/MT5, tự chép EA, tự biên dịch hay tự gõ cấu hình.
**Cách làm**: chính MetaTrader 5 chạy trong giả lập ngay trên điện thoại (proot + Ubuntu + Box64 + Wine + Xvfb), có EA cầu nối `PyEABridge` nối về app (`docs/MT5_EA_BRIDGE.md`). Một bộ script làm hết các bước và báo tiến trình về app.
Có **hai cách chạy**, cùng một đường cài/giám sát/báo tiến trình:
1. **NHÚNG (ưu tiên) - chạy ngay trong app PyEA, KHÔNG cần cài Termux** (mục ngay dưới).
2. **Termux (dự phòng)** - khi máy/APK không hợp cách 1 (app tự phát hiện và hiện lý do trong hộp thoại). Xem mục «Cách Termux».

> **Nói thẳng**: logic + script + bộ chạy nhúng đã test bằng lệnh giả, proot GIẢ và máy chủ cục bộ thật của app (`tests/test_embedded.py`, `tests/test_mt5emu_embedded.py`, `tests/test_mt5_install.py`, `tests/test_mt5emu.py`, `tests/test_mt5_phone_tools.py`) và Kivy thật dưới xvfb. **CHƯA TỪNG chạy proot/Box64/Wine/MT5 trên điện thoại thật** (sandbox là x86 và chặn một số máy chủ). Hãy thử bằng tài khoản **DEMO** trước. Các URL tải, tên gói, mẫu câu log MT5 là theo tài liệu/trí nhớ, có thể sai ở máy thật; script dừng ở đúng bước lỗi và báo về app để sửa.

## Cách NHÚNG (không Termux)
**Vì sao làm được ở mọi targetSdk**: Android 10+ cấm app nhắm API ≥ 29 chạy (`execve`) file nằm trong thư mục DỮ LIỆU của chính nó (SELinux chỉ cấm `execute_no_trans` trên `app_data_file`; nạp/mmap code vẫn được - [tài liệu Android 10](https://developer.android.com/about/versions/10/behavior-changes-10), [commit sepolicy](https://android.googlesource.com/platform/system/sepolicy/)). Thư mục thư viện gốc của APK thì được phép chạy trực tiếp. Nên `proot` + `loader` được **đóng gói trong APK** (`native_libs/arm64-v8a/lib*.so`, buildozer `android.add_libs_arm64_v8a`; p4a đã bật `extractNativeLibs`/`useLegacyPackaging`), và proot tự chạy chương trình khách bằng loader + mmap, không `execve` file trong thư mục dữ liệu (mã nguồn proot `src/execve/enter.c`). UserLAnd (cũng proot) làm đúng cách này ở targetSdk 37. Nhờ đó APK **nhắm API mới (36)**: **không** bị Google Play Protect chặn kiểu «được xây dựng cho phiên bản Android cũ» (Play Protect cảnh báo/chặn khi targetSdk thấp hơn Android của máy quá 2 mức - [hướng dẫn nhà phát triển](https://developers.google.com/android/play-protect/warning-dev-guidance); bản APK nhắm targetSdk 28 từng bị chặn thật trên máy người dùng). Vẫn **chỉ cài ngoài (sideload), không lên Google Play**, nhưng lý do là chính sách Play cấm app tải mã chạy được (Box64/Wine/Ubuntu) từ ngoài Play, không phải targetSdk. Dung lượng ổ đĩa không quan trọng, ưu tiên tải CPU/RAM thấp.

**Cái gì chạy trong app**: dịch vụ nền riêng `Emu` (`service_emu.py` → `pyea/embedded.py`, foreground + sticky, giữ wake-lock) làm tuần tự:
1. `precheck`: CPU ARM 64-bit, dung lượng trống (≥ ~4 GB, ước lượng chưa đo), kiểm proot trong APK (nếu APK cũ không có proot thì **thử thật** việc chạy một file tải về; Android chặn thì báo rõ lý do, không cài dở).
2. `proot`: dùng proot ARM64 **đã nằm sẵn trong APK** (UserLAnd-Assets-Support v1.4.33; không tải gì, mã băm từng file ghi ở `native_libs/SHA256SUMS`); chọn bản `.a10` (Android 10+) hay bản thường, tự thử bản còn lại nếu bản đầu không chạy. (APK cũ không có proot trong thư viện gốc thì quay lại cách tải về ~9 MB, kiểm SHA256 đã ghim, cần targetSdk 28.)
3. `rootfs`: tải Ubuntu Base 22.04 arm64 (`.tar.gz`) **kiểm theo `SHA256SUMS` cùng thư mục** (tự chọn bản 22.04.x mới nhất), giải nén bằng bộ giải nén an toàn (cấm đường dẫn tuyệt đối/`..`, cấm ghi xuyên symlink, bỏ thiết bị, bỏ setuid), chỉnh cho apt chạy được trong proot (DNS, nguồn `ports.ubuntu.com`, tắt sandbox `_apt`, không tự bật dịch vụ). Thử chạy một lệnh trong Ubuntu; lỗi seccomp/ptrace thì tự thử lại với `PROOT_NO_SECCOMP=1`.
4. `apt → box64 → wine → prefix → mt5 → provision → compile`: **chính các script đã có** (`install_mt5_termux.sh inner`) chạy bên trong proot, báo tiến trình về app qua cổng cục bộ `127.0.0.1` như cách Termux (nên màn hình tiến trình dùng lại).
5. `login`: `run_mt5_termux.sh run` bật Xvfb + MT5, đăng nhập, nối EA; dịch vụ giám sát script này (chết thì dựng lại, lùi dần; chết nhanh nhiều lần thì dừng và báo).

**Dùng**: Cài đặt → **«Kết nối MT5 nhanh»** → nhập Login, Mật khẩu, Server (+ link bộ cài của sàn nếu có) → **Bắt đầu**. Hết. Không Termux, không dán lệnh. Hộp thoại hiện từng bước ✓/▶/✗, **CPU/RAM thật** của giả lập (mỗi ~10 giây), và các nút: **Dừng** (dịu: script tự tắt Wine rồi mới tắt dịch vụ), **Khởi động lại** (làm tiếp từ bước dở, không tải lại phần đã xong), **Sao chép chẩn đoán** (token đã che), **Xoá MT5 nhúng** (bấm 2 lần; xoá cả Ubuntu/Wine/MT5), **Nhập lại thông tin**. Đóng app giữa chừng: dịch vụ vẫn chạy; mở lại thì hộp thoại vào thẳng trang tiến trình.

**Giảm tải CPU/RAM (ưu tiên của người dùng)** - hồ sơ `lean` là mặc định của cách nhúng:
- Box64: để mặc định của Box64 thay vì ép `BOX64_DYNAREC_STRONGMEM=1`/`SAFEFLAGS=2` (hồ sơ `stable` cũ), `BOX64_DYNAREC_BIGBLOCK=3` (khối lớn, hợp chương trình Wine), `BOX64_MAXCPU=2`. Tên biến lấy từ `docs/USAGE.md` của Box64.
- Nhường CPU: tiến trình trong giả lập chạy với `nice` cao hơn (dịch vụ hạ ưu tiên cả cây tiến trình, quét mỗi ~10 s).
- EA ở chế độ nhẹ (`InpLean`): tắt vẽ biểu đồ (`CHART_SHOW=false` + các thuộc tính hiển thị khác), bỏ symbol mặc định khỏi Market Watch sau khi nối được máy chủ (mỗi symbol đang chọn là một luồng tick), quét mỗi 200 ms thay vì 100 ms.
- Tự lùi: nếu MT5 chết nhanh 3 lần liên tiếp ở `lean`, dịch vụ chuyển sang `stable` (ổn định hơn, tốn hơn), nhớ lựa chọn và báo trong app.
- **Chưa đo** mức giảm thật trên máy thật. Số CPU/RAM hiển thị trong app là số đo thật từ `/proc` (CPU: 100% = 1 nhân; RAM: tổng RSS, có thể tính trùng trang dùng chung của Wine) để bạn tự so `lean` với `stable` (đặt `PYEA_PROFILE`).

**Điều kiện/giới hạn**:
- ARM 64-bit (aarch64), Android ≥ 7 (minapi 24). Máy 32-bit không chạy được Box64.
- APK phải có dịch vụ `Emu` và proot trong thư viện gốc (`lib/arm64-v8a/libproot.so`...); CI kiểm cả hai và kiểm targetSdk không bị hạ (`.github/workflows/build-apk.yml`). Bản không đủ điều kiện thì hộp thoại tự dùng cách Termux và ghi lý do. Bản APK nhắm targetSdk thấp (vd 28, đặt `PYEA_TARGET_SDK=28`) sẽ bị Play Protect chặn cài - chỉ để thử.
- **Android 12-14 có thể tự giết tiến trình con của app** (phantom process killer): vào Tuỳ chọn nhà phát triển bật «Disable child process restrictions», và tắt «tối ưu pin» cho PyEA. Nếu dịch vụ bị giết, `state.json` ngừng ghi nhịp và hộp thoại báo «CHƯA thấy dịch vụ nền báo nhịp».
- Mật khẩu **không** đi qua dịch vụ hay ghi file: ô nhập → RAM của app → cổng cục bộ → `startup.ini` (script trong Ubuntu lấy qua GET), như cách Termux; token nằm trong `emu/request.json` (quyền 0600) và file `token` trong Ubuntu, không nằm trên dòng lệnh.

**Đã kiểm / chưa kiểm nguồn tải** (kiểm bằng sandbox có GitHub, ngày 2026-11-16):
| Nguồn | Trạng thái |
|---|---|
| proot UserLAnd `v1.4.33/arm64-v8a-assets.zip` | Tải được, đã băm SHA256 và ghim trong code; có đủ `proot`, `loader`, `loader32`, `libtalloc.so.2` (+ bản `.a10`). Chưa chạy trên Android |
| Ubuntu Base 22.04 arm64 (`cdimage.ubuntu.com`) | **Chưa kiểm được** (sandbox chặn). Hash kiểm lúc chạy theo `SHA256SUMS`; tên tệp tự chọn từ `SHA256SUMS` |
| Box64 `box64-android` (kho `ryanfortner/box64-debs`) | Đã kiểm trong kho GitHub: gói `box64-android` arm64 có trong chỉ mục `Packages`, tệp `box64.list` đúng. Máy chủ `ryanfortner.github.io` (nơi apt tải) chưa kiểm được |
| Wine 9.7 amd64 (Kron4ek/Wine-Builds) | Có thật (HTTP 200, ~56 MB) |
| Bộ cài MT5 `download.mql5.com` | **Chưa kiểm được** (sandbox chặn) |

## Cách Termux (dự phòng)
Dùng khi hộp thoại báo cách nhúng chưa dùng được (APK không có proot trong thư viện gốc/dịch vụ Emu, CPU không phải ARM64...). Phần Android không cho tự động:
1. **Cài Termux** - app riêng, bản **F-Droid hoặc GitHub** (không dùng bản Google Play: đã cũ, kho gói không còn hoạt động). Một app không thể tự cài app khác.
2. **Dán MỘT lệnh vào Termux** (app tạo sẵn và có nút «Sao chép lệnh»). Android không cho app chạy file đã tải trong thư mục của chính nó (W^X), nên việc chạy phải nằm trong Termux. (Nâng cấp sau: Termux có cơ chế RUN_COMMAND để app tự gửi lệnh, nhưng người dùng phải bật `allow-external-apps` một lần và app cần thêm quyền; chưa làm.)

Mọi thứ còn lại (gói, Debian, Box64, Wine, MT5, EA, biên dịch, đăng nhập) là tự động.

### Dùng (cách Termux)
1. App → **Cài đặt** → nút xanh đầu trang **«Kết nối MT5 nhanh»** → nhập **Login**, **Mật khẩu**, **Server** → **Bắt đầu**.
   - Server: tên (vd `Exness-MT5Real8`) hoặc `địa chỉ:cổng` như email của sàn. Sàn có bộ cài MT5 riêng thì dán link vào ô cuối (tuỳ chọn; bỏ trống = bản chung của MetaQuotes).
   - Bấm Bắt đầu = đồng ý đặt «Nguồn thị trường» = `mt5ea` trong Cài đặt. Mật khẩu **không** ghi vào Cài đặt.
2. Cài Termux (nút «Cài Termux (F-Droid)»), bấm **«Sao chép lệnh»**, **«Mở Termux»**, giữ ngón tay trên màn hình → Dán → Enter.
3. Đợi. Hộp thoại trong app hiện từng bước (✓ xong · ▶ đang chạy · ✗ lỗi) và cuối cùng **«ĐÃ NỐI: MT5 đã đăng nhập tài khoản ... và EA đang nối với app»**. Giữ Termux mở, đừng tắt app PyEA lúc cài.
4. Bấm **Kết nối** ở màn hình chính như mọi nguồn khác.

## Chỉ lần đầu hay mỗi lần đều như vậy? (cách Termux; cách nhúng thì «bật lại» = nút Khởi động lại, không cài lại)
| | Làm gì | Mất bao lâu |
|---|---|---|
| **Lần đầu** | Cài Termux (1 lần), dán lệnh, script tải + cài tất cả | Lâu, tốn dung lượng (cần ≥ ~3 GB trống, ước lượng chưa đo; tải Wine + MT5 vài trăm MB đến hơn 1 GB). Chưa đo thời gian thật |
| **Các lần sau** | Không cài lại gì. Bật MT5: `bash ~/pyea-start-mt5.sh` (hoặc dán lại lệnh cũ - các bước đã xong tự bỏ qua) | Chỉ khởi động Xvfb + MT5 + đăng nhập, dự kiến vài chục giây (chưa đo) |
| **Sau khi khởi động lại điện thoại** | Tự bật nếu có **Termux:Boot** (cài + mở 1 lần; script đã tạo sẵn `~/.termux/boot/pyea-mt5.sh`); nếu không, gõ `bash ~/pyea-start-mt5.sh` | |
| **Đổi tài khoản** | Mở lại hộp thoại, «Nhập lại thông tin», dán lại lệnh (hoặc dùng lệnh bật lại sau khi cập nhật) | Nhanh: không cài lại |

Chạy lại lệnh cài bất cứ lúc nào là an toàn: mỗi bước kiểm **trạng thái thật** (có `box64` chạy được không, có `wine64` không, có `terminal64.exe` không, EA đã biên dịch chưa) chứ không chỉ cờ «đã làm», bước nào đủ thì bỏ qua, bước lỗi làm tiếp. Ép làm lại một bước: `PYEA_REDO=wine,mt5 bash ...`.

## Các bước (hiện trong app, theo đúng thứ tự)
`precheck` (CPU 64-bit ARM, dung lượng) → `termux_pkgs` (proot-distro, curl, wget) → `rootfs` (Debian) → `fetch` (lấy script + cấu hình từ app) → `apt` (Xvfb, thư viện X11/font) → `box64` (kho ryanfortner.github.io/box64-debs, gói `box64-android`) → `wine` (Wine 64-bit của Kron4ek, mặc định 9.7) → `prefix` (`wineboot`) → `mt5` (bộ cài MT5 chạy với cờ `/auto`) → `provision` (chép `PyEABridge.mq5`, `bridge.set`, `startup.ini` từ app) → `compile` (MetaEditor `/portable /compile`) → `launcher` (tạo `~/pyea-start-mt5.sh`, boot script) → `login` (bật MT5, đăng nhập, EA nối vào app).

Lỗi ở bước nào thì bước đó hiện ✗ kèm lý do + đuôi nhật ký, app báo động «Cài MT5 trong giả lập: lỗi ở bước ...», và «Xuất chẩn đoán EA» có đủ chi tiết. Sửa nguyên nhân (mạng, dung lượng...) rồi **chạy lại cùng lệnh**.

## Mật khẩu
- Đi đường: ô nhập → RAM của app → cổng cục bộ `127.0.0.1` (có token) → `startup.ini` trong thư mục MT5 trong Debian → MT5. Không qua mạng ngoài, không vào Cài đặt, không vào nhật ký/chẩn đoán (có test).
- `startup.ini` dùng `KeepPrivate=1` (tài liệu MetaTrader: lưu mật khẩu giữa các lần kết nối) nên MT5 tự nhớ tài khoản sau lần đăng nhập đầu.
- Khi EA nối được và báo đã có tài khoản, **app quên mật khẩu** (xoá khỏi RAM) và script cứ vài giây lấy lại `startup.ini` mới từ app → dòng `Password=` **tự biến mất** khỏi máy (đã test, kể cả kiểm đột biến). Mật khẩu chờ quá 2 giờ cũng tự bị quên.
- Hệ quả: nếu app bị tắt trước khi MT5 đăng nhập được, phải nhập lại (hộp thoại hiện lại ô nhập).
- Mật khẩu có xuống dòng bị từ chối (tránh chèn thêm khoá vào file `.ini`).

## Lệnh trong Termux
- `bash ~/pyea-start-mt5.sh` - bật MT5 + giám sát (nền); `status`; `stop`.
- Nhật ký: `~/.pyea/run.out` (giám sát), `~/.pyea/install.log` (cài, phần Termux), trong Debian: `.../root/.pyea/install.log`.

## Điều chưa biết / có thể sai ở máy thật (đừng tin cho tới khi thử)
- Box64 + Wine 9.7 có chạy MT5 ổn trên máy của bạn không (cộng đồng báo kết quả lẫn lộn: có máy thiếu tick, có máy báo «no connection»). Cờ `/auto` của bộ cài MT5, và việc có tắt tiến trình bộ cài đúng lúc không.
- **Danh sách địa chỉ cho phép của MT5** (MT5 chỉ cho EA mở socket tới địa chỉ nằm trong Tools → Options → Expert Advisors): theo tài liệu và các bài trên diễn đàn MQL5, danh sách này KHÔNG có khoá trong file ini (nó nằm trong file nhị phân của MT5), nên script **không** đặt trước được. Cách giải: xem mục «Đường tệp dự phòng» bên dưới. Khoá `[Experts]` của `startup.ini` chỉ còn `Enabled`, `AllowLiveTrading` (có trong tài liệu); `WebRequest`/`WebRequestUrl` đã bỏ vì không có trong tài liệu.
- Server theo tài liệu là `địa chỉ:cổng`; **tên** server có được nhận trong `startup.ini` hay không chưa kiểm. Nếu không đăng nhập được, dùng `địa chỉ:cổng` hoặc bộ cài riêng của sàn.
- Mẫu câu log «authorized on» (để báo «đăng nhập ổn») theo trí nhớ log tiếng Anh; kết luận cuối cùng của app luôn là EA nối được và có số tài khoản, không phải dòng log.
- Android 12+ có thể giết tiến trình con của Termux (phantom process killer): tắt hạn chế trong Tuỳ chọn nhà phát triển, cho Termux không bị tối ưu pin. Đã có `termux-wake-lock`.
- Dung lượng/thời gian ở bảng trên là ước lượng.

## Nếu bước «Khởi tạo Wine» báo «map_fixed_area out of memory» / «ntdll.dll» hoặc «could not exec wineserver»
Gặp thật trên Cat S52 (Android 10, nhân 4.9). Kết quả thật trên máy đó: **Wine 8.19 và 9.7 đều lỗi «map_fixed_area out of memory»** (Wine 64-bit không dựng được vùng nhớ cho `ntdll.dll`; Box64 gắn lỗi này với nhân chỉ có không gian địa chỉ ảo **39-bit**, Wine x86-64 cần ~47-bit). **Wine 10.12 qua được lỗi đó** nhưng dừng ở «wine: could not exec wineserver».
- App dùng **MỘT bản Wine cố định (10.12)**, không đoán bản theo máy và không thử lần lượt nhiều bản (bản trước làm vậy là sai: ghi cứng theo một loại máy, tải lại vài trăm MB mỗi lần). Muốn thử bản khác: biến `WINE_VER` (script) hoặc tham số `wine_ver` của `launch()`.
- «could not exec wineserver»: Wine tự tìm `wineserver` theo đường dẫn của chính nó rồi `execv()`; qua Box64 + proot cách đó có thể hỏng. Script đặt biến **`WINESERVER`** và **`WINELOADER`** (có trong man wine(1)) trỏ vào hai script bọc `~/.pyea_bin/wineserver`, `~/.pyea_bin/wine` (gọi `box64 …`). **Log thật bản v6 cho thấy cách này có tác dụng**: hết lỗi «could not exec wineserver», wineserver chạy được (xem mục kế tiếp cho lỗi mới).
- «Chẩn đoán» có phần «chẩn đoán Wine»: bản Box64, bản Wine, có lỗi vùng nhớ hay không, kiểu tệp wineserver (x86_64/script), kết quả `wineserver --version` gọi thẳng và qua script, dòng cuối của wineboot. Gửi phần đó nếu vẫn lỗi.
- **Có thể máy này không chạy được Wine 64-bit qua Box64** (giới hạn của nhân/Box64, không phải lỗi mạng hay cài đặt).

## Nếu «Khởi tạo Wine» báo «failed to set 60000020 protection … ntdll.dll section .text, noexec filesystem?»
Gặp thật ở bản v6 trên Cat S52 (sau khi wineserver đã chạy được). **Khác lỗi vùng nhớ 39-bit** (không có dòng `map_fixed_area`): Wine nạp `ntdll.dll` rồi gọi `mprotect(PROT_READ|PROT_EXEC)` lên vùng `.text` và Android trả lỗi (EACCES).
- **Nguyên nhân đã ĐO thật trên Cat S52 (Android 10, nhân 4.9)**: SELinux (miền `untrusted_app`) trả EACCES khi `mprotect` thêm quyền thực thi lên vùng file **đã bị ghi** (copy-on-write); vùng file chưa ghi (`map_RX`, `R->RX`, `RW->RX`) và bộ nhớ ẩn danh (`RW->RX`, `RWX`) đều được; không có mount noexec trên `/data`. Máy khác có thể khác - phép đo bên dưới chạy lại trên từng máy.
- **Phép đo** (không đoán): ở bước «Khởi tạo Wine» script chạy `python3` trong rootfs thử mmap/mprotect có quyền thực thi và ghi dòng `[file Wine] map_RX:… R->RX:… RW->RX:… đã-ghi->RX:… | [file tạm] … | [bộ nhớ ẩn danh] … | [mount noexec] … | [selinux] …` vào «Chẩn đoán» (mục «đo quyền thực thi»). Cách đọc: `R->RX:EACCES` = vùng ánh xạ từ file bị chặn bit thực thi; `đã-ghi->RX` lỗi mà `R->RX` ổn = luật «execmod» (trang bị sao chép rồi cho thực thi); bộ nhớ ẩn danh ổn = JIT của Box64 vẫn chạy được.
- **Lớp đệm `pyea_noexec`** (`tools/mt5_phone/shim/pyea_noexec.c`): LD_PRELOAD cho Box64; chỉ khi nhân từ chối quyền thực thi thì thử lại không có quyền đó (Box64 dịch mã x86 chứ không chạy trực tiếp nên không cần bit đó). Tự bật **một lần** khi chính lỗi này xuất hiện (rồi làm lại tiền tố); `PYEA_SHIM=0` tắt, `PYEA_SHIM=1` luôn bật. Khi bật, `box64` trong PATH của rootfs là script bọc `~/.pyea_shim/box64`.
- **Bằng chứng**: lớp đệm ghi errno thật của từng lời gọi bị từ chối vào `shim.log` (mục «lớp đệm» của Chẩn đoán). Nếu lớp đệm bật rồi mà vẫn lỗi, gửi phần «đo quyền thực thi» + «lớp đệm» + «chẩn đoán Wine» (có dòng `wine kênh virtual`).
- Dựng lại lớp đệm sau khi sửa mã nguồn: `sh tools/mt5_phone/shim/build_shim.sh` (cần clang + lld; ghi `pyea/assets/pyea_noexec_aarch64.so.txt` và `BUILD_INFO.txt`; test kiểm hai file khớp nhau).
- **Đã kiểm chứng trên Cat S52 (log bản v7)**: Box64 gọi `mprotect` qua libc nên lớp đệm bắt được; `shim.log` đầy `errno=13 -> thu-lai-khong-exec:ok` và lỗi `ntdll.dll` biến mất. Wine đi tiếp tới lỗi khác (mục dưới).

## Nếu «Khởi tạo Wine» chờ 300 giây rồi báo «boot event wait timed out» + «could not load kernel32.dll, status c0000135»
Gặp thật ở bản v7 trên Cat S52, ngay sau khi lỗi quyền thực thi được lớp đệm cứu. Tiến trình `wine wineboot` đầu tiên của tiền tố mới sinh một `wineboot --init` con rồi **chờ nó tối đa 300 giây (giới hạn cứng của Wine)**; con không xong thì tiến trình chính bỏ chờ và chết với `c0000135` (hệ quả, không phải lỗi gốc).
- **Nghi vấn chính (CHƯA kiểm chứng)**: tiền tố mới + có màn hình (Xvfb) làm Wine bật hộp thoại «cài Wine Mono / Wine Gecko» và **chờ người bấm nút**; trong Xvfb không ai bấm. Dấu hiệu trong log thật: hai tiến trình con cùng báo `start_rpcss Failed to open RpcSs service`, một trong hai nạp Vulkan (đang dựng cửa sổ). Script chạy MT5 đã tắt hai thành phần này; script cài thì chưa - bản này đặt `WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=d"` cho mọi lần chạy Wine (cách chuẩn của Wine/winetricks khi không có người dùng; MT5 chạy EA không cần .NET hay IE nhúng).
- **Giả thuyết còn lại**: máy chậm (CPU yếu, lại chạy qua Box64 + proot) nên `wineboot` thật sự cần hơn 300 giây. Vì vậy khi tiến trình chính bỏ chờ mà còn tiến trình Wine con, script **chờ thêm** (tối đa `PREFIX_TIMEOUT`, mặc định 900 giây) và chỉ thôi khi tổng CPU của chúng đứng im `WINE_STALL_S` giây (mặc định 120) hoặc không còn tiến trình nào; xong thì dựa vào lệnh thử `cmd.exe` THẬT để kết luận, không dựng lại tiền tố.
- **Bằng chứng để lần sau khỏi đoán** (mục «chẩn đoán Wine»): `wineboot_mẫu_CPU` (giây CPU tích luỹ mỗi 30 s: **tăng = đang làm, đứng im = kẹt**), `wineboot_chương_trình_đã_mở` (thấy `appwiz.cpl` = trình cài Mono/Gecko), `wineboot_dòng_process`, `wineboot_20_dòng_cuối` (có giờ), `system32 (mẫu)`, `dosdevices`, `WINEDLLOVERRIDES`, và `vết_nạp_kernel32` (chạy `cmd /c ver` trên chính tiền tố hỏng với `+loaddll,+module`). Vết đầy đủ nằm ở `~/dl/wineboot.out` trong rootfs; nhật ký cài chỉ giữ dòng lỗi.
- **Chưa kiểm chứng trên điện thoại**: cả hai giả thuyết (Mono/Gecko, máy chậm) và việc `wineboot` có xong trên Cat S52 hay không.

## Vì sao không tự viết các thành phần Windows thay cho Wine?
Đã cân nhắc (ý của người dùng: bớt ghi cứng, bớt thành phần thừa). Kết luận: **không khả thi và không nên**.
- MT5 (`terminal64.exe`) là chương trình Windows x86-64 đóng nguồn, gọi hàng trăm hàm Win32 (kernel32/ntdll/user32/gdi32/ws2_32/wininet/crypt32…), đọc registry, mở cửa sổ + đồ hoạ. Thay Wine = viết lại một lớp tương thích Windows, thiếu một hàm là MT5 chết, và không có tài liệu nào nói MT5 gọi những hàm nào. Wine làm việc đó gần 30 năm.
- Điện thoại là ARM64 còn MT5 là x86-64: vẫn cần Box64 (dịch lệnh CPU). Phần tự viết chỉ thay được Wine, không thay được Box64.
- Lỗi hiện tại (vùng nhớ ảo 39-bit, `could not exec wineserver`) nằm ở **giao điểm Android nhân 4.9 + Box64 + proot**; code tự viết vẫn phải chạy trên đúng nhân đó và sẽ gặp giới hạn bộ nhớ tương tự.
- Hướng THẬT SỰ giảm tải: cắt bớt thành phần Wine không cần (không Mono/Gecko, `WINEDLLOVERRIDES`, không đồ hoạ nặng, EA ẩn đồ thị) - đã làm trong «cấu hình nhẹ». Hướng khác (tự nói giao thức MT5 với máy chủ môi giới) là kỹ thuật ngược giao thức đóng, vi phạm điều khoản và rất dễ vỡ; đường đám mây (MetaApi) thì bạn đã loại.

## Đã chạy được trên Cat S52 (log bản v8): bước «Khởi tạo Wine» xong sau ~3 phút
Sau khi tắt Mono/Gecko (và chờ wineboot con), tiền tố tạo xong lúc 20:08 → 20:11, lệnh thử `cmd.exe` in `PYEA_PROBE_OK`, `system32` có 791 file, `wineboot_mẫu_CPU` cho thấy `rundll32 setupapi,InstallHinfSection` chạy bận (CPU tăng) rồi xong. **Chưa phân biệt được** việc tắt Mono/Gecko hay việc chờ thêm đã giúp (cả hai cùng có mặt ở bản đó).

## Nếu «Tải và cài MetaTrader 5» chạy rất lâu mà không ra terminal64.exe
Gặp thật ở bản v8 trên Cat S52: bộ cài `mt5setup.exe /auto` (23,7 MB, tải xong sau 3,5 phút) chạy đủ 2400 s, **không một dòng lỗi nào** ngoài vài dòng vô hại (thiếu libSDL2/libusb/libvulkan gốc, `wineusb`, `winemenubuilder`), `terminal64.exe` không xuất hiện. Chưa biết nó đang bận, đang chờ ai bấm, hay đang chờ mạng/WebView2.
- **Manh mối ban đầu (đã được log thật v9 trả lời một phần, xem mục dưới)**: script cài chính thức của MetaQuotes cho Linux (`mt5debian.sh`) trước khi chạy bộ cài còn (1) đặt Windows 10 và (2) cài **Microsoft Edge WebView2 Runtime**; và chạy bộ cài KHÔNG có cờ `/auto`. (2) chưa làm: WebView2 là Chromium x64, chạy qua Box64 trên điện thoại sẽ rất nặng - cần bằng chứng trước. Log v9 cho thấy bộ cài KHÔNG nạp wininet/winhttp/mshtml/webview2loader, nên WebView2 không phải thủ phạm ở bước này.
- **Tự dừng sớm**: nếu tổng CPU của các tiến trình Wine tăng < `MT5_CPU_MIN` giây (6) VÀ `drive_c` đổi < 64 KB trong `MT5_STALL_S` giây (**300**, bản v9 là 600) thì báo «đứng im» thay vì chờ đủ 2400 s. CPU còn tăng (đang giải nén/tính) thì KHÔNG bị coi là đứng.
- **Bằng chứng** (mục «chẩn đoán Wine»): `bộ_cài_mẫu_theo_thời_gian` (mỗi 60 s: số tiến trình, CPU, cỡ `drive_c`, file mới lớn nhất, **tên các cửa sổ đang hiện** - cần `xwininfo`, script tự cài `x11-utils` + `x11-apps`), `bộ_cài_DLL_đã_nạp` (webview2loader/mshtml/wininet/winhttp/…), `bộ_cài_12_dòng_cuối_vết`, `windows_khai_báo` (phiên bản Windows trong tiền tố). Vết đầy đủ ở `~/dl/mt5setup.out` trong rootfs; nhật ký cài chỉ giữ dòng lỗi.


## Bộ cài MT5 dừng ở hộp thoại «A debugger has been found…» (xác nhận bằng ảnh thật, Cat S52) - bản v13: máy tự tìm bản Wine chạy được
**Quan sát thật (log v11)**: ảnh màn hình ảo lúc bộ cài đứng im (giải bằng `tools/mt5_phone/xwd_decode.py`) cho thấy `mt5setup.exe` dừng ở hộp thoại MetaQuotes «**A debugger has been found running in your system. Please, unload it from memory and restart your program.**» (một nút OK). Hộp thoại chờ bấm nên bộ cài đứng im, khớp log v8/v9/v11. Đặt Windows 11 KHÔNG giúp; Box64 chặn `winedbg` («[BOX64] winedbg detected, not launching it!») nên chỉ có ảnh chụp là nguồn bằng chứng.

**Nguyên nhân (theo nguồn, CHƯA tự kiểm)**: lớp bảo vệ MetaQuotes gọi thẳng syscall Windows; Wine xử lý bằng Syscall User Dispatch từ **11.5**, sửa hẳn ở **11.6+** ([WineHQ bug 58043](https://bugs.winehq.org/show_bug.cgi?id=58043), [mt5-connector PR #23](https://github.com/swing-traders/mt5-connector/pull/23), [mql5.com](https://www.mql5.com/en/forum/503128)); Box64 ≥ 0.4.4 giả lập SUD cho nhân không có sẵn (máy này: nhân 4.9, Box64 0.4.5 bản «Nov 20 2026»).

**Kết quả thật của bản v12 (21/11 tối) - hai lỗi, đều đã sửa ở v13:**
1. **Wine 11.19 KHÔNG khởi động được trên máy này.** Tải xong (~100 MB) nhưng wineboot chết ngay: «anon_mmap_alloc: Assertion `!(size & host_page_mask)' failed», «virtual_setup_exception stack overflow», rồi «could not load kernel32.dll, status c0000135» (system32 trống). Nguyên nhân chưa rõ (liên quan cách Wine ≥ 10.4 căn trang bộ nhớ trên không gian địa chỉ 39-bit của nhân Android; tương tự [bug 58084](https://bugs.winehq.org/show_bug.cgi?id=58084) nhưng không cùng đường chạy). Vì thế «chốt 11.19» của v12 là chốt sai.
2. **Script vứt oan tiền tố của Wine 10.12.** Sau khi lùi, 10.12 dựng đủ tiền tố (791 file hệ thống, system.reg 3 MB) nhưng wineboot in chữ «vùng nhớ ảo» và thoát mã 1; bản cũ coi chữ đó là kết luận, xoá tiền tố và báo «không dựng được». Nay: **chữ lỗi KHÔNG phải kết luận** - nếu tiền tố đủ file hệ thống thì chờ tiến trình con xong rồi để chạy thử `cmd.exe` quyết định; chỉ khi thiếu file mới dừng ngay như cũ.

**Cách v13 chọn Wine - MỘT quy tắc, máy tự đo, không đoán theo máy:** «bản Wine 11.N **mới nhất** mà máy này khởi động được, N từ 6 (bản đầu có sửa SUD) tới 19; không có thì 10.12.» «Khởi động được» = dựng được tiền tố VÀ chạy được `cmd.exe`.
- **Tìm nhị phân** (≤ 4 lần thử thay vì 14): thử 11.19; hỏng → thử giữa khoảng (11.12); chạy được → thử cao hơn; hỏng → thấp hơn; hết khoảng thì chốt bản chạy được mới nhất (không có → 10.12). **Giả định (nói rõ)**: lỗi bắt đầu từ một bản nào đó trở đi (đơn điệu). Nếu không đúng thì có thể bỏ sót một bản chạy được nằm lẻ giữa các bản hỏng.
- **Có sẵn trên Kron4ek** (xem danh sách release ngày 21/11): `wine-11.7 … 11.22-amd64.tar.xz` (~89-104 MB mỗi bản); 11.6 chưa xác nhận (không tải được thì tính là «hỏng» và tìm tiếp). Tệp tải về được giữ làm cache nên quay lại bản đã tải không tải lại.
- **Chi phí một lần**: bản hỏng ~1-2 phút (tải + chết nhanh), bản chạy được ~3 phút (dựng tiền tố) + dựng lại tiền tố cho bản chốt. Kết quả nhớ trong `~/.pyea/wine_search` (`ok=` N lớn nhất chạy được, `bad=` N nhỏ nhất hỏng, `done=1` khi chốt) và `~/.pyea/wine_ver`; **dịch vụ bị tắt giữa chừng thì làm tiếp, không tải lại bản đã biết**; chốt rồi thì không tìm lại. Muốn tìm lại: xoá hai tệp đó (trong rootfs của app).
- **Không tìm** khi bạn tự đặt `WINE_VER`/`WINE_URL` hoặc dùng bản wow64: giữ đúng bản đó, hỏng thì báo lỗi.
- Máy đã cài v12 (có `wine_ver`=10.12 mà không có `wine_search`): tệp cũ bị bỏ để tìm lại từ đầu.
- Chẩn đoán có: `kiểu_wine … mặc_định=… chốt=…`, `wine_tìm: chạy_được_tới=11.x hỏng_từ=11.y chốt=có|chưa`, `wine_đã_hỏng (bản: lý do)`.

**Giữ từ v11/v12**: thăm dò lúc bộ cài đứng im (90 s: tên cửa sổ X + luồng chờ; 300 s: dừng và chụp ảnh màn hình ảo vào CUỐI chẩn đoán), `reg add` đặt Windows 11, `WINE_FLAVOR=staging` thủ công (cần bản `wine-<WINE_VER>-staging-amd64` ở Kron4ek; chưa kiểm).

**Chưa biết (chỉ máy thật trả lời được)**: (a) có bản nào trong 11.6-11.19 khởi động được trên Cat S52 không. **Nếu không**: máy chốt 10.12 và hộp thoại «debugger» sẽ lại hiện - nhưng lúc đó đã BIẾT chắc đường «Wine ≥ 11.6 + Box64» chưa dùng được trên máy này (thử `WINE_VER=11.21`/`11.22` bằng tay: Kron4ek đã có; 11.20 từng bị báo văng khi khởi động), và phải đổi hướng (Box64 bản khác qua `BOX64_PKG`, Wine Staging, hoặc cách đưa MT5 vào mà không qua bộ cài); (b) giả định đơn điệu; (c) giả lập SUD của Box64 có đủ để qua lớp bảo vệ không; (d) sau đó bộ cài đi tiếp, MT5 đăng nhập, EA nối được không. Gửi lại «chẩn đoán MT5 nhúng» sau lần chạy tới.

## Bản MT5 «chung» của MetaQuotes và bản của từng sàn
Bản chung chỉ đăng nhập được server mà nó đã biết (danh bạ MetaQuotes / `servers.dat`: tìm công ty trong «Mở tài khoản» hoặc «Đăng nhập tài khoản giao dịch»); bộ cài của sàn đã kèm sẵn server của sàn (nguồn công khai: diễn đàn mql5.com, trang trợ giúp của các sàn). Nếu đăng nhập báo không thấy server (đã gõ đúng tên, kể cả hậu tố `-Live`/`-MT5`), dán **link bộ cài MT5 của sàn** vào ô «Link bộ cài MT5 của sàn» trong app (cần `https://`). Chưa kiểm chứng với sàn cụ thể nào; bộ cài của sàn cùng họ với bộ cài chung nên có thể gặp cùng vấn đề đứng im ở trên.

### Ô «Link bộ cài MT5 của sàn» hoạt động thế nào (mỗi link một thư mục MT5 riêng)
- **Bỏ trống** = bộ cài chung của MetaQuotes. **Có link** = tải bộ cài đó thay cho bản chung. Link phải `https://`, không khoảng trắng.
- Mỗi link ứng với **MỘT thư mục MT5 riêng** trong Wine: `drive_c/pyea-mt5/<mã của link>/`. MT5 chạy ở chế độ `/portable` nên mọi thứ của nó (tài khoản đã đăng nhập, danh sách server, EA, `startup.ini`) nằm gọn trong thư mục đó. Sổ ghi «link → thư mục» ở `~/.pyea/mt5_dir.<mã>`. Sau khi cài xong, thư mục vừa cài được **chuyển** vào chỗ riêng này, nên bộ cài của link kế tiếp — kể cả khi nó tự chọn trùng tên thư mục «MetaTrader 5» — **không thể ghi đè** lên bản trước.
- Bản chung cài **không thành công** rồi đổi sang link của sàn: không có gì để ghi đè (chưa có `terminal64.exe`); script tải bộ cài mới **từ đầu** (tệp tải về được nhớ theo link; trước đây `wget -c` với link khác sẽ nối đuôi vào tệp dở hoặc giữ nguyên bộ cài cũ — đã thử thật, đã sửa).
- Bản chung đã cài **thành công** rồi đổi link: cài thêm bản của sàn ở thư mục riêng, bản chung giữ nguyên. Đổi link lại về cái cũ (hoặc bỏ trống) thì **không tải/cài lại**, chỉ trỏ lại sang thư mục đó (`~/mt5` là liên kết trỏ tới thư mục đang dùng).
- «Làm lại MT5» (`PYEA_REDO=mt5`) chỉ xoá và cài sạch thư mục của **chính link đang dùng**, không đụng thư mục của link khác.
- **Dọn bản không dùng**: nút «Dọn bản MT5 không dùng» (trang tiến trình MT5 nhúng). Bấm lần 1 hiện «Xoá N bản (dung lượng)? Bấm lại», bấm lại trong 10 giây mới xoá. Chỉ xoá các thư mục trong `pyea-mt5/` KHÔNG phải bản đang dùng (`~/mt5` trỏ tới) và dòng tương ứng trong sổ; **xoá cả dữ liệu trong các bản đó** (tài khoản đã đăng nhập, EA đã gắn), quay lại link đó sẽ phải cài lại. Từ chối khi đang cài hoặc không xác định được bản đang dùng; không đi theo liên kết tượng trưng; không đụng tệp bộ cài `dl/mt5setup.exe` (nhỏ) và không đụng thư mục dở dang do bộ cài lỗi để lại ngoài `pyea-mt5/`. Mã: `embedded.mt5_installs/prune_mt5`; Kivy thật: `tools/ui_smoke/smoke_embedded.py`.
- Bản cài của phiên bản cũ (chưa có sổ, nằm ở «Program Files/MetaTrader 5») được nhận rồi **chuyển** vào thư mục riêng ở lần chạy đầu, để bộ cài của sàn chọn trùng tên cũng không đè lên.
- **Nhiều tài khoản**: một thư mục MT5 đăng nhập được nhiều tài khoản **của các server mà nó biết** (đổi login/server trong app, MT5 khởi động lại bằng `startup.ini` mới; không cài lại). Tài khoản ở sàn khác mà bản đó không biết server thì dùng link bộ cài của sàn đó (thư mục riêng, chuyển qua lại không tải lại). **Chạy HAI MT5 cùng lúc trong giả lập CHƯA hỗ trợ** (một cổng + một token + một thư mục đang dùng; mỗi MT5 qua Box64/Wine cũng tốn CPU/RAM đáng kể) và chưa được thử.
- Chưa kiểm chứng trên máy thật: việc chuyển thư mục sau khi cài (chỉ là đổi tên trong cùng ổ đĩa, đã test bằng lệnh giả), và bộ cài của sàn cụ thể nào có chạy được qua Wine hay không.

## Cài đè bản mới mà KHÔNG mất dữ liệu (khoá ký APK cố định)
Android chỉ cho cài đè khi APK mới **ký cùng khoá** với bản cũ. Khoá khác = phải gỡ app = **mất cả Ubuntu + Wine + MT5 đã cài** (hàng GB, 20+ phút). CI dùng một khoá cố định, lấy theo thứ tự: (1) secret `PYEA_KEYSTORE_B64` (bền nhất, bạn tự đặt); (2) **nhánh `pyea-signing-key` của chính repo** (tự động, không cần làm gì; `tools/ci_signing_key.sh`; **CHỈ khi repo RIÊNG TƯ**); (3) cache `pyea-debug-keystore-v1`; (4) tạo mới.
**Vì sao v13 thêm (2) - lỗ hổng của bản trước**: cache là chỗ giữ khoá duy nhất và có ba điểm yếu thật: (a) cache chỉ được lưu khi **cả job thành công** - build đầu tiên tạo khoá mà lỗi giữa chừng thì khoá mất và lần sau lại tạo khoá khác (gỡ app thêm một lần nữa); (b) cache của lần build chạy từ tag `v*` không thấy được từ nơi khác; (c) cache bị xoá sau 7 ngày không dùng. Nay khoá mới tạo được **lưu NGAY** (cache + nhánh repo) trước khi build, và các lần sau lấy từ nhánh repo trước. Hai bước lưu có `continue-on-error`: lỗi lưu khoá không bao giờ làm hỏng build.
**Repo công khai**: khoá KHÔNG được ghi vào repo (ai đọc được nhánh đó ký được bản «cập nhật» đè lên app của bạn); CI chỉ cảnh báo và khoá chỉ nằm ở cache. Hãy đặt secret như dưới đây.
**Chưa kiểm trên GitHub thật**: script đã chạy với git + keytool thật và một kho cục bộ (khôi phục đúng từng byte, không ghi đè khoá khác, không đụng repo công khai, không làm hỏng build khi lỗi); CHƯA chạy với quyền ghi thật của `GITHUB_TOKEN`. Repo có luật chặn tạo nhánh mới thì bước ghi chỉ báo cảnh báo.
**Biết APK này có cài đè được không**: trang tóm tắt mỗi lần chạy CI in dòng «Khoá ký APK» (nguồn: secret / nhánh pyea-signing-key / cache / **TẠO MỚI**) và dấu vân tay SHA-256. «TẠO MỚI» = APK này khác chữ ký bản cài trước → gỡ app cũ MỘT lần; từ lần sau khoá được giữ.
**CÁCH DỄ NHẤT - chỉ cần điện thoại (từ bản v15): secret `PYEA_KEY_SEED`.** Mở repo trên GitHub → Settings → Secrets and variables → Actions → New repository secret → Name: `PYEA_KEY_SEED`, Secret: một chuỗi chữ NGẪU NHIÊN, DÀI (>= 32 ký tự, ví dụ 40 ký tự chữ+số bạn tự gõ lung tung; hãy lưu nó ở nơi an toàn). CI dựng khoá ký TẤT ĐỊNH từ chuỗi đó (`tools/ci_derive_keystore.py`): cùng chuỗi → cùng khoá ở MỌI lần build, không phụ thuộc cache hay nhánh, dùng được cả repo công khai. Làm xong: chạy build, **gỡ app cũ MỘT lần cuối** rồi cài; từ đó cài đè được mãi miễn secret còn nguyên. Trang tóm tắt CI in «Khoá ký APK: secret PYEA_KEY_SEED» + dấu vân tay SHA-256. Mục «Sao chép chẩn đoán» trong app in dòng `apk: … chữ_ký_SHA256=…`: so với dấu vân tay CI để biết chắc APK đang cài và APK mới cùng khoá hay không. AN TOÀN: ai biết chuỗi này ký được bản «cập nhật» đè lên app của bạn (app xử lý dữ liệu giao dịch) → đừng đưa nó vào mã/zip/chat. Thứ tự ưu tiên khi đặt nhiều secret: `PYEA_KEYSTORE_B64` > `PYEA_KEY_SEED` > nhánh repo riêng tư > cache > tạo mới.
Đặt secret (tuỳ chọn, bền nhất; làm trên máy bạn, KHÔNG gửi file keystore cho ai, không đưa lên repo):
```
keytool -genkeypair -keystore pyea.keystore -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 36500 -dname "CN=PyEA Debug,O=PyEA,C=VN"
base64 -w0 pyea.keystore      # (macOS: base64 -i pyea.keystore)
```
Dán kết quả vào GitHub → repo → Settings → Secrets and variables → Actions → New repository secret, tên `PYEA_KEYSTORE_B64`. (alias phải là `androiddebugkey`, mật khẩu `android` vì Gradle dùng khoá debug.) Đây là khoá ký APK, không liên quan tới khoá bản quyền.

## Build chậm? (CI)
Xem `docs/build-apk.yml`. Cache chia 4 phần (SDK/NDK/p4a · phần đã biên dịch · Gradle · ccache), khoá theo `tools/ci_fingerprint.py` nên **đổi phiên bản/mã nguồn không làm mất cache**; chỉ đổi `requirements`, NDK/API, kiến trúc, recipe cục bộ mới biên dịch lại. Lần build đầu sau khi áp dụng vẫn đủ lâu; từ lần 2 nhanh hơn rõ rệt (chưa đo được ở đây - xem bảng tóm tắt TRÚNG/trượt ở trang tóm tắt lần chạy). Chạy tay có thể chọn **chỉ arm64-v8a** để nhanh gần gấp đôi (máy 32-bit sẽ không cài được).

## Nếu bước «Cài MT5» báo «could not load kernel32.dll, status c0000135»
Đây là lỗi thật đã gặp trên một điện thoại. Từ bản này script tự: kiểm tiền tố Wine bằng cách chạy thử `cmd.exe`, dựng lại tiền tố nếu hỏng, đổi sang Wine wow64 nếu bộ cài MT5 là 32-bit, dừng ngay khi gặp lỗi và thử lại đúng một lần. Nếu vẫn lỗi, app dừng (không tự lặp) và mục **«Chẩn đoán»** có thêm phần «chẩn đoán Wine»: bản Wine, kích thước trang nhớ, loại bộ cài (x64/x86), có `kernel32.dll` trong tiền tố hay không. Gửi phần đó cho người phát triển. **Chưa xác minh trên máy thật**; nếu «trang_nhớ» khác 4096 thì Box64/Wine có thể không chạy được trên máy đó.

## Đường tệp dự phòng (khi MT5 chặn socket)
MT5 chặn EA mở socket tới 127.0.0.1 nếu địa chỉ chưa nằm trong danh sách cho phép, mà danh sách đó không đặt được bằng ini. Để người dùng vẫn **chỉ nhập đăng nhập**:
1. EA `PyEABridge` (`InpTransport = auto`) thử socket trước. Nếu nối được thì đi thẳng như thiết kế gốc.
2. Nếu MT5 chặn, EA tự ghi các dòng giao thức ra tệp `MQL5/Files/pyea_o_<sid>_<seq>.txt` (EA luôn được phép ghi ở đó) và đọc trả lời ở `pyea_i_<sid>_<seq>.txt`.
3. `pyea_relay.py` (Python, chạy trong Debian, do script giám sát tự bật và dựng lại nếu chết; trình cài tự cài `python3`) là một tiến trình Linux bình thường nên nối được 127.0.0.1 của app; nó chỉ chuyển byte qua lại, không hiểu nội dung.
4. Tệp chia đoạn 256 KB, đọc hết đoạn nào thì xoá đoạn đó; mỗi phiên EA có `sid` riêng, phiên mới nhất thắng; `RELAYCLOSE` báo EA mở phiên mới khi app đóng/không nối được.
5. EA báo `HELLO ... link=file` nên app biết đang đi đường tệp. Nếu cả hai đường đều tịt, EA ghi log `no link to app` và app báo động kèm gợi ý (nhật ký `PYEA-RELAY` trong `~/.pyea/run.out`; hoặc làm tay một lần: thêm `127.0.0.1` vào danh sách của MT5, khi đó EA nối thẳng).
**Nói thẳng:** relay + quy tắc tệp đã test với máy chủ thật của app (`tests/test_mt5_relay.py`, 15 ca, có kiểm đột biến). Phần MQL5 đọc/ghi tệp trong EA **chưa từng biên dịch hay chạy** trên MT5 (không có MetaEditor ở đây): nếu MetaEditor báo lỗi biên dịch, bước «Biên dịch EA cầu nối» sẽ hiện ✗ kèm dòng lỗi để sửa. Độ trễ đường tệp cao hơn socket (vài chục đến ~200 ms mỗi chiều), chưa đo.

## Khác với MetaApi
Nút phụ **«MT5 trên đám mây MetaApi»** (dịch vụ bên thứ ba, có thể tính phí) vẫn còn cho ai muốn, xem `docs/METAAPI_CLOUD.md`. Nó **không** phải «Kết nối MT5 nhanh».

## Cho người phát triển
- Nhúng: `pyea/embedded.py` (tải/kiểm hash/giải nén an toàn/dựng lệnh proot/cài/giám sát/`Sampler` CPU-RAM/`launch`-`stop`-`status`-`supported`), `service_emu.py` (dịch vụ p4a `Emu`), `native_libs/arm64-v8a` (proot + loader trong APK, `SHA256SUMS`), `tools/p4a_hook.py` (chỉ còn tuỳ chọn hạ targetSdk, mặc định KHÔNG), `mt5emu.prepare_embedded/progress_embedded/headline_embedded`, `mt5ea.EMBED_STAGES`, sự kiện `SEVT kind=res|emu_exit|profile`, EA `InpLean`, script `PYEA_PROFILE/PYEA_ENV_OVERRIDE/PYEA_STOP_FILE`. Test: `tests/test_embedded.py` (45 ca, proot giả), `tests/test_mt5emu_embedded.py` (18), `TestProfileAndStop` trong `tests/test_mt5_phone_tools.py`; Kivy thật: `tools/ui_smoke/smoke_embedded.py`.
- Logic: `pyea/mt5emu.py` (`problems/plan/prepare/bootstrap_command/progress/render/headline`), giao diện `pyea/ui_mt5emu.py`; phía máy chủ: `pyea/mt5ea.py` (`INSTALL_STAGES`, `ensure_server`, `make_startup_ini(settings, password)`, `Mt5EaServer.first_login_password/install`, sự kiện `SEVT kind=install`).
- Script: `tools/mt5_phone/install_mt5_termux.sh` (outer = Termux, inner = Debian) + `pyea_relay.py` (relay tệp dự phòng) + `run_mt5_termux.sh` (giám sát; theo dõi đăng nhập và đồng bộ cấu hình bật bằng `PYEA_LOGIN_WATCH/PYEA_SYNC_CFG` trong `~/.pyea_env.sh`). APK đóng gói bản sao `pyea/assets/*.sh.txt` (đuôi `.sh` không được nhận); test kiểm hai bản giống nhau + khối helper chung giống nhau.
- Test: `tests/test_mt5_install.py` (20 ca: bước cài, chạy lại bỏ qua, lỗi → báo app → chạy tiếp, mật khẩu biến mất, lệnh dán), `tests/test_mt5emu.py` (18 ca), `tests/test_mt5_relay.py` (15 ca: đường tệp + relay thật + máy chủ app thật). Kivy thật dưới xvfb: `tools/ui_smoke/smoke_emu.py`.
