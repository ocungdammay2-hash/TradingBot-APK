# DNSE — chứng khoán / phái sinh Việt Nam (1.9.50)

Chọn **Cài đặt → Nguồn thị trường = dnse**. Dùng API **LightSpeed V1** (tài khoản Entrade X của bạn). **CHƯA thử với tài khoản thật** — mọi thứ mới qua máy chủ giả. Thử bằng lệnh nhỏ, tài khoản ít tiền.

## Cách dùng
1. Nhập `DNSE tên đăng nhập` + `mật khẩu`, `gói vay (loanPackageId)` (bắt buộc khi đặt lệnh).
2. Lấy trading token (8 giờ): Smart OTP → nhập mã vào «DNSE OTP», loại `smart`, bấm **Lấy trading token DNSE**. Email OTP → bấm **Gửi Email OTP DNSE**, nhập mã (hiệu lực 2 phút), loại `email`, bấm **Lấy trading token DNSE**.
3. Chỉ xem giá/backtest thì không cần OTP; đặt/huỷ lệnh mới cần.

## Đã làm
| Thành phần | Chi tiết | Nguồn |
|---|---|---|
| Đăng nhập | `POST api.dnse.com.vn/auth-service/login` → JWT 8 giờ (tự đăng nhập lại) | hdsd.dnse.com.vn «Tài liệu LightSpeed API V1» |
| Tài khoản/số dư | `GET /order-service/accounts`, `/account-balances/{acc}` | như trên |
| Đặt lệnh | `POST /order-service/v2/orders` (cổ phiếu), `/derivative/orders` (VN30F...), header `Trading-Token`; LO, MP (cổ phiếu), MTL (phái sinh) | như trên |
| Bước giá lệnh LO | `dnse.snap_price`: gióng GIÁ GỬI về bước giá hợp lệ trước khi đặt (mua làm tròn xuống, bán làm tròn lên → không bao giờ xấu hơn giá bot yêu cầu). HOSE cổ phiếu 10 đ (<10.000) / 50 đ (10.000–49.950) / 100 đ (≥50.000); ETF + chứng quyền HOSE 10 đ; HNX + UPCoM 100 đ; VN30F 0,1 điểm. Chọn bằng `DNSE bước giá lệnh LO` (hose mặc định · hnx · etf · off · hoặc số) | tài liệu DNSE «Cập nhật quy định giao dịch sau KRX 2025» (bước giá không đổi khi lên KRX); VN30F 0,1 là quy tắc phổ biến, tài liệu đó không nêu |
| Sổ lệnh / huỷ | `GET/DELETE /order-service/v2/orders[/{id}]?accountNo=` | như trên |
| Vị thế | `GET /deal-service/deals?accountNo=` (deal OPEN) | như trên |
| Giá realtime | MQTT 5 qua WebSocket `wss://datafeed-lts.dnse.com.vn/wss`, user = investorId, pass = JWT; topic `plaintext/quotes/{stock\|derivative}/{tick\|TP}/{mã}` | mã mẫu + đặc tả MDDS DNSE (bạn gửi), repo chienazazaz/dnse-lightspeed-api |
| MQTT client | `pyea/mqttws.py` (thư viện chuẩn, không paho) | — |
| V2 (API key, HMAC) | `pyea/dnse.py` phần đầu: ký request + client mức thấp, chưa nối bot | README PyPI, thanhdat-phung/dnse_openapi, pskho/dnse-mt5-connector |

## Còn ĐOÁN / chưa xác minh (chỉnh được trong Cài đặt)
1. **Khoá JSON thực tế** của tick/top price: parser không phân biệt hoa/thường, nhận `matchPrice/matchQtty`, `bid/ask[].price`. Nếu sai: không có giá, app báo «Chưa có giá» (không bịa giá).
2. **Đơn vị giá**: feed có thể trả nghìn đồng trong khi lệnh cần đồng (hoặc ngược lại) → chỉnh `DNSE hệ số giá`. Kiểm bằng lệnh nhỏ.
3. **Nến lịch sử**: không có trong tài liệu chính thức; mặc định `services.entrade.com.vn/chart-api/v2/ohlcs/{stock|derivative}` (đường dẫn phổ biến, chưa xác minh) → chỉnh `DNSE đường dẫn nến`. Khung hỗ trợ: 1m 5m 15m 30m 1h 1d. Sai đường dẫn: bot vẫn chạy được từ giá realtime nhưng thiếu lịch sử lúc khởi động.
4. Topic phái sinh `derivative/tick|TP` là suy ra từ topic OHLC phái sinh trong mã mẫu (đăng ký topic không tồn tại thì vô hại).
5. **Bước giá**: app không biết mã thuộc sàn nào → mặc định áp luật HOSE; mã HNX/UPCoM phải đặt `DNSE bước giá lệnh LO = hnx`, ETF/chứng quyền = `etf`. Đơn vị giá tự nhận: giá gửi < 1000 coi là nghìn đồng (25.05 = 25.050 đ), còn lại là đồng. Trái phiếu chính phủ kỳ hạn (GB…) KHÔNG được gióng (chưa rõ bước giá). Chưa xử lý giá trần/sàn/tham chiếu (sàn tự từ chối nếu ngoài biên độ).
6. Không có sửa lệnh trong V1 (app huỷ + đặt lại); stop/stop-limit do app mô phỏng; chưa có lịch sử deal đồng bộ.

## Đặc thù thị trường VN
Cổ phiếu cơ sở chỉ mua trước bán sau, lô 100, T+2, bước giá theo sàn; phái sinh VN30F có Long/Short và ký quỹ. Lệnh bán cổ phiếu vừa mua có thể bị từ chối do T+2 (sàn trả lỗi, app báo nguyên văn).

## Giờ giao dịch, ngày nghỉ lễ và bộ chặn lệnh ngoài giờ (1.9.50)
**Phiên khớp lệnh** (kiểm chéo FPTS, KIS, HSC): HOSE ATO 9:00-9:15 · liên tục 9:15-11:30 và 13:00-14:30 · nghỉ trưa 11:30-13:00 · ATC 14:30-14:45 · 14:45-15:00 chỉ thỏa thuận. HNX liên tục 9:00-11:30 và 13:00-14:30, ATC 14:30-14:45. UPCoM liên tục 9:00-11:30 và 13:00-15:00. Phái sinh VN30F: ATO 8:45-9:00, liên tục 9:00-11:30 và 13:00-14:30, ATC 14:30-14:45. Giờ Việt Nam cố định UTC+7.
**CHƯA kiểm:** giờ NHẬN lệnh trước giờ mở cửa, giờ giao dịch ngày đáo hạn phái sinh, giờ thỏa thuận chi tiết. App chỉ trả lời «đang khớp lệnh hay không» (`pyea/vnmarket.py`; bot dùng `api.vn_market_state()`).
**Ngày nghỉ lễ:** lịch 2026 có sẵn trong app (đối chiếu thông báo HNX/HOSE: 1/1, 16-20/2, 27/4, 30/4, 1/5, 31/8, 1/9, 2/9). **Năm khác 2026 app KHÔNG đoán**: chỉ biết các lễ cố định luật định (1/1, 30/4, 1/5, 2/9) và báo `calendar_known = False` («Chưa có lịch nghỉ lễ năm X»). Tết và Giỗ Tổ theo âm lịch, ngày nghỉ bù do Chính phủ quyết từng năm, nên phải lấy từ thông báo của sở.

**Tự cập nhật lịch qua mạng** (`pyea/vncal.py`, chạy NỀN mỗi 24 giờ, chỉ khi bạn dùng DNSE hoặc bật bộ chặn; lỗi mạng thì giữ bản cũ; backtest không bao giờ gọi mạng):
- Cài đặt «Nguồn lịch nghỉ lễ tự cập nhật»: `auto` (mặc định) = tải `docs/vn_holidays.json` từ kho GitHub bạn đã nhập ở «Kho GitHub chứa bản phát hành» (qua `raw.githubusercontent.com/<kho>/HEAD/docs/vn_holidays.json`; kho PHẢI công khai, kho riêng tư trả 404 → dùng lịch có sẵn) · `off` = tắt · hoặc dán URL https / đường dẫn file JSON. Nếu thư mục dự án nằm sâu trong kho (không ở gốc), dán URL đầy đủ.
- **Vì sao là một file JSON chứ không tự cào trang của sở:** HOSE/HNX chỉ công bố ngày nghỉ dưới dạng thông báo (trang tin/PDF), không có API máy đọc được mà ta kiểm chứng được; cào chữ tự do sẽ sai âm thầm. Quy trình: sở ra thông báo → bạn sửa `docs/vn_holidays.json` (và `push`) → mọi máy tự nhận trong 24 giờ, không cần build lại APK.
- Định dạng: `{"version": 1, "updated": "2027-01-05", "years": [2026, 2027], "holidays": {"2027-02-08": "Tết Âm lịch", ...}}`. `years` = các năm danh sách ĐÃ ĐẦY ĐỦ (năm không khai báo vẫn là «chưa biết»). Chỉ cần ghi ngày thường (T2-T6) sở nghỉ.
- **Kiểm tra chặt, file lỗi bị từ chối cả khối (giữ lịch cũ):** HTTPS (hoặc file cục bộ) · ≤ 64 KB · `version` = 1 · ngày hợp lệ trong 2020-2100 · ≤ 400 ngày, ≤ 40 ngày/năm · mỗi năm khai báo đủ phải có đủ lễ cố định rơi vào ngày thường (thiếu = danh sách chắc chắn cụt) · bộ đệm trên máy cũng bị kiểm tra lại khi nạp. File này chỉ cho app biết thêm ngày nghỉ, không điều khiển được gì khác.
- Ưu tiên: ngày bạn thêm tay («Ngày nghỉ lễ thêm») > lịch tải từ mạng > lịch có sẵn.

**Giá đứng khi thị trường đóng ≠ mất kết nối** (`vnmarket.quiet_symbols`, dùng trong `health()`): với DNSE, mã VN đang ngoài giờ giao dịch theo lịch (cuối tuần, nghỉ lễ, nghỉ trưa, trước/sau giờ, và 120 giây đầu sau khi mở lại) KHÔNG bị tính là «mất giá/mất kết nối», nên không còn cảnh báo nghiêm trọng lặp lại mỗi 10 phút vào cuối tuần. Thanh trạng thái ghi «Thị trường VN đóng cửa theo lịch - giá đứng là bình thường». **Chiều ngược lại KHÔNG đúng và app không làm:** mất kết nối KHÔNG được suy ra thành «hôm nay là ngày nghỉ» (rớt mạng, sàn bảo trì, token hết hạn 8 giờ, bị giới hạn tần suất trông giống hệt; ngày lễ nhiều khi vẫn đăng nhập được). Cũng vì thế: mã đang có LỖI thật khi lấy giá (sàn trả lỗi) hoặc gọi API sàn lỗi liên tiếp vẫn báo như thường kể cả ngày nghỉ; năm chưa có lịch thì ngày thường trong giờ giao dịch vẫn coi là «đang giao dịch» (không đoán là nghỉ) nên mất giá vẫn báo.

**Bộ chặn lệnh ngoài giờ** (Cài đặt «Chặn lệnh ngoài giờ giao dịch (DNSE)», mặc định `off`). `block`: không gửi lệnh MỚI khi sàn đóng cửa (cuối tuần, ngày lễ), và không gửi lệnh THỊ TRƯỜNG (MP/MTL) khi chưa ở phiên khớp liên tục (ATO, ATC, nghỉ trưa, ngoài giờ). Lệnh giới hạn (LO) ngoài giờ trong ngày giao dịch VẪN gửi vì nhiều công ty chứng khoán nhận lệnh chờ trước giờ mở (chưa kiểm với DNSE; sàn tự từ chối nếu không nhận). **Đóng vị thế không bao giờ bị chặn.** Mã phái sinh (VN30F…) theo giờ phái sinh; mã khác theo giờ HOSE (app không có bảng niêm yết để phân biệt HOSE/HNX/UPCoM, giờ khớp chỉ khác nhau ở 14:45-15:00).
