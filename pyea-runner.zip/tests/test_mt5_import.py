"""v17: nhập MT5 từ tệp .zip trong BỘ NHỚ điện thoại (không cần link, không chạy bộ cài .exe).
Kiểm phần chạy được ngoài Android: chép tệp lớn không đọc vào RAM + kiểm «PK» (android_utils), sổ nhập + chuyển vào Ubuntu (embedded), nút bấm (ui_mt5emu).
CHƯA kiểm: bộ chọn tệp hệ thống (SAF) và openFileDescriptor trên máy thật."""
import io
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import android_utils as au, embedded as em  # noqa: E402


class Chunky:
    """Tệp giả đọc từng mẩu nhỏ: kiểm không đọc cả tệp một lần."""

    def __init__(self, data, step=7):
        self.b, self.step, self.calls = io.BytesIO(data), step, 0

    def read(self, n=-1):
        self.calls += 1
        return self.b.read(min(n, self.step) if n and n > 0 else self.step)


class TestCopyZip(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dest = os.path.join(self.tmp.name, "imp", "mt5_import.zip")
        os.makedirs(os.path.dirname(self.dest))

    def test_zip_copied_in_chunks_and_renamed(self):
        data = b"PK\x03\x04" + os.urandom(1000)
        src = Chunky(data)
        n = au.copy_stream_to(src, self.dest, chunk=64)
        self.assertEqual(n, len(data))
        self.assertEqual(open(self.dest, "rb").read(), data)
        self.assertGreater(src.calls, 10, "phải đọc từng mẩu, không đọc cả tệp một lần")
        self.assertFalse(os.path.exists(self.dest + ".part"))

    def test_not_a_zip_is_rejected_and_nothing_left(self):
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(b"MZ\x90\x00 an exe"), self.dest)
        self.assertIn("không phải tệp .zip", str(cm.exception))
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_empty_file_is_rejected(self):
        with self.assertRaises(ValueError):
            au.copy_stream_to(io.BytesIO(b""), self.dest)
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_too_large_is_rejected_midway_and_cleaned(self):
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(b"PK" + b"x" * 5000), self.dest, chunk=100, limit=1000)
        self.assertIn("quá lớn", str(cm.exception))
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_failed_copy_keeps_the_previous_good_file(self):
        open(self.dest, "wb").write(b"PKold")
        with self.assertRaises(ValueError):
            au.copy_stream_to(io.BytesIO(b"notzip"), self.dest)
        self.assertEqual(open(self.dest, "rb").read(), b"PKold", "lỗi không được đè lên tệp tốt đã chọn trước đó")

    def test_pick_off_android_reports_cleanly(self):
        got = []
        au.pick_file_copy(self.dest, lambda *a: got.append(a))
        self.assertEqual(got, [(None, 0, "not_android")])


class TestImportBook(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = os.path.join(self.tmp.name, "data")
        os.makedirs(self.data)

    def emb(self):
        return em.Embedded(self.data, host="127.0.0.1", port=1, token="t" * 24, scripts=lambda n: "", urls={}, sdk=30, arch="aarch64", min_free_mb=1, native_dir=None, va_bits=0)

    def put(self, payload=b"PKfake-zip"):
        open(em.import_dest(self.data), "wb").write(payload)

    def test_nothing_chosen(self):
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_register_requires_the_copied_file(self):
        with self.assertRaises(ValueError):
            em.import_register(self.data, "a.zip", 10)

    def test_pending_then_staged_into_guest_and_url_built(self):
        self.put(b"PK" + b"z" * 100)
        m = em.import_register(self.data, "../../evil/MT5 portable.zip", 102)
        self.assertEqual(m["name"], "MT5 portable.zip", "chỉ giữ tên tệp, bỏ phần đường dẫn")
        self.assertEqual(em.import_info(self.data)["state"], "pending")
        e = self.emb()
        env = e.inner_env()
        url = env["MT5_SETUP_URL"]
        self.assertRegex(url, r"^file:///root/dl/mt5_import\.zip\?id=[0-9a-f-]+$")
        lo = em.Layout(self.data)
        self.assertTrue(os.path.isfile(lo.import_staged), "tệp phải được chuyển vào Ubuntu")
        self.assertFalse(os.path.exists(lo.import_zip), "chuyển bằng đổi tên: bản ngoài rootfs không còn")
        self.assertEqual(em.import_info(self.data)["state"], "active")

    def test_active_import_is_sticky_across_restarts_with_blank_link(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        u1 = self.emb().inner_env()["MT5_SETUP_URL"]
        u2 = self.emb().inner_env(mt5_url="")["MT5_SETUP_URL"]
        self.assertEqual(u1, u2, "mở lại app/bấm Bắt đầu lại vẫn dùng đúng tệp, không quay về bản chung")

    def test_new_pick_changes_the_id_so_script_installs_fresh_dir(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        u1 = self.emb().inner_env()["MT5_SETUP_URL"]
        self.put(b"PK2")
        em.import_register(self.data, "a.zip", 3)
        u2 = self.emb().inner_env()["MT5_SETUP_URL"]
        self.assertNotEqual(u1, u2)

    def test_pending_import_beats_typed_link(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        env = self.emb().inner_env(mt5_url="https://broker.example/x.exe")
        self.assertTrue(env["MT5_SETUP_URL"].startswith("file:///root/dl/"))

    def test_typed_link_after_active_import_drops_the_import(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        self.emb().inner_env()                                       # đang dùng
        env = self.emb().inner_env(mt5_url="https://broker.example/x.exe")
        self.assertEqual(env["MT5_SETUP_URL"], "https://broker.example/x.exe")
        self.assertIsNone(em.import_info(self.data))
        self.assertFalse(os.path.exists(em.Layout(self.data).import_staged))

    def test_clear_removes_everything(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        self.emb().inner_env()
        em.import_clear(self.data)
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_staged_file_vanished_means_not_selected(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        self.emb().inner_env()
        os.remove(em.Layout(self.data).import_staged)
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_corrupt_meta_is_ignored(self):
        os.makedirs(em.Layout(self.data).root, exist_ok=True)
        open(em.Layout(self.data).import_meta, "w").write("{không phải json")
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_id_in_url_cannot_inject_characters(self):
        self.put()
        em.import_register(self.data, "a.zip", 10)
        meta_path = em.Layout(self.data).import_meta
        m = json.load(open(meta_path))
        m["id"] = "abc12-3?;rm -rf /"
        json.dump(m, open(meta_path, "w"))
        url = self.emb().inner_env()["MT5_SETUP_URL"]
        self.assertRegex(url, r"^file:///root/dl/mt5_import\.zip\?id=[0-9a-f-]*$")


if __name__ == "__main__":
    unittest.main()
