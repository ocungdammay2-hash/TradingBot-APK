"""v17: nhập MT5 từ tệp .zip trong BỘ NHỚ điện thoại (không cần link, không chạy bộ cài .exe).
Kiểm phần chạy được ngoài Android: chép tệp lớn không đọc vào RAM + kiểm «PK» (android_utils), sổ nhập + chuyển vào Ubuntu (embedded), nút bấm (ui_mt5emu).
CHƯA kiểm: bộ chọn tệp hệ thống (SAF) và openFileDescriptor trên máy thật."""
import io
import json
import os
import shutil
import sys
import tempfile
import unittest
import zipfile

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import android_utils as au, embedded as em  # noqa: E402


def real_zip(extra=b"", entries=None):
    """Zip thật chứa terminal64.exe (finalize_part giờ đọc thử toàn bộ zip, nên dữ liệu «PK...» giả không còn qua được)."""
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in (entries or {"MetaTrader 5/terminal64.exe": os.urandom(3000) + extra}).items():
            z.writestr(n, d)
    return bio.getvalue()


class Chunky:
    """Tệp giả đọc từng mẩu nhỏ: kiểm không đọc cả tệp một lần."""

    def __init__(self, data, step=7):
        self.b, self.step, self.calls = io.BytesIO(data), step, 0

    def read(self, n=-1):
        self.calls += 1
        return self.b.read(min(n, self.step) if n and n > 0 else self.step)


class TestCopyZip(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dest = os.path.join(self.tmp.name, "imp", "mt5_import.zip")
        os.makedirs(os.path.dirname(self.dest))

    def test_zip_copied_in_chunks_and_renamed(self):
        data = real_zip(os.urandom(2000))
        src = Chunky(data)
        n = au.copy_stream_to(src, self.dest, chunk=64)
        self.assertEqual(n, len(data))
        self.assertEqual(open(self.dest, "rb").read(), data)
        self.assertGreater(src.calls, 10, "phải đọc từng mẩu, không đọc cả tệp một lần")
        self.assertEqual(n, os.path.getsize(self.dest))
        self.assertFalse(os.path.exists(self.dest + ".part"))

    def test_not_a_zip_is_rejected_and_nothing_left(self):
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(b"MZ\x90\x00 an exe"), self.dest)
        self.assertIn("không phải tệp .zip", str(cm.exception))
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_empty_file_is_rejected(self):
        with self.assertRaises(ValueError):
            au.copy_stream_to(io.BytesIO(b""), self.dest)
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_too_large_is_rejected_midway_and_cleaned(self):
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(real_zip(os.urandom(5000))), self.dest, chunk=100, limit=1000)
        self.assertIn("quá lớn", str(cm.exception))
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_failed_copy_keeps_the_previous_good_file(self):
        good = real_zip()
        open(self.dest, "wb").write(good)
        with self.assertRaises(ValueError):
            au.copy_stream_to(io.BytesIO(b"notzip"), self.dest)
        self.assertEqual(open(self.dest, "rb").read(), good, "lỗi không được đè lên tệp tốt đã chọn trước đó")

    def test_corrupt_zip_is_rejected_at_pick_time_and_old_file_kept(self):
        # tái hiện log thật: zip còn danh mục nhưng hỏng giữa tệp => phải báo ngay lúc chọn, không đợi cài hơn 1 giờ
        good = real_zip()
        open(self.dest, "wb").write(good)
        bad = bytearray(real_zip(os.urandom(200000)))
        bad[len(bad) // 3: len(bad) // 3 + 30000] = bytes(30000)
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(bytes(bad)), self.dest, chunk=4096)
        self.assertIn("HỎNG", str(cm.exception))
        self.assertEqual(open(self.dest, "rb").read(), good)
        self.assertFalse(os.path.exists(self.dest + ".part"))

    def test_zip_without_terminal_is_rejected_at_pick_time(self):
        with self.assertRaises(ValueError) as cm:
            au.copy_stream_to(io.BytesIO(real_zip(entries={"docs/readme.txt": b"hi"})), self.dest)
        self.assertIn("terminal64.exe", str(cm.exception))
        self.assertEqual(os.listdir(os.path.dirname(self.dest)), [])

    def test_first_copy_corrupt_then_second_way_ok_is_accepted_and_noted(self):
        from pyea import zipcheck
        calls = []

        def primary():
            calls.append("python")
            raise zipcheck.ZipCorrupt("Tệp .zip bị HỎNG: 2/10 mục")

        def alternate():
            calls.append("java")
            return 1234
        self.assertEqual(au.copy_with_fallback(primary, alternate), 1234)
        self.assertEqual(calls, ["python", "java"])
        self.assertIn("Java", au.LAST_COPY_NOTE)
        self.assertIn("tốt", au.LAST_COPY_NOTE)

    def test_both_ways_corrupt_means_source_is_corrupt(self):
        from pyea import zipcheck

        def bad():
            raise zipcheck.ZipCorrupt("Tệp .zip bị HỎNG: 1/5 mục")
        with self.assertRaises(zipcheck.ZipCorrupt) as cm:
            au.copy_with_fallback(bad, bad)
        self.assertIn("2 cách", str(cm.exception))
        self.assertIn("tệp gốc", str(cm.exception))

    def test_other_errors_do_not_trigger_the_second_copy(self):
        calls = []

        def notzip():
            calls.append(1)
            raise ValueError("Đây không phải tệp .zip")

        def alt():
            calls.append(2)
            return 1
        with self.assertRaises(ValueError):
            au.copy_with_fallback(notzip, alt)
        self.assertEqual(calls, [1], "lỗi không phải «zip hỏng» thì chép lại cũng vô ích")

    def test_good_first_copy_never_runs_the_second(self):
        calls = []
        self.assertEqual(au.copy_with_fallback(lambda: calls.append(1) or 7, lambda: calls.append(2) or 8), 7)
        self.assertEqual(calls, [1])
        self.assertEqual(au.LAST_COPY_NOTE, "")

    def test_copy_note_is_stored_in_the_import_book(self):
        data = os.path.join(self.tmp.name, "d")
        os.makedirs(data)
        open(em.import_dest(data), "wb").write(real_zip())
        m = em.import_register(data, "a.zip", 10, note="chép lần 1 hỏng, lần 2 tốt")
        self.assertEqual(m["copy_note"], "chép lần 1 hỏng, lần 2 tốt")
        self.assertEqual(em.import_info(data)["copy_note"], "chép lần 1 hỏng, lần 2 tốt")

    def test_pick_off_android_reports_cleanly(self):
        got = []
        au.pick_file_copy(self.dest, lambda *a: got.append(a))
        self.assertEqual(got, [(None, 0, "not_android")])


class TestImportBook(unittest.TestCase):
    """v21: tệp zip người dùng chọn được app GIẢI NÉN BẰNG PYTHON ở đầu lần cài, rồi chuyển thư mục vào Ubuntu; script nhận «file:///root/dl/mt5_import_x?id=…» (thư mục)."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.data = os.path.join(self.tmp.name, "data")
        os.makedirs(self.data)

    def emb(self):
        return em.Embedded(self.data, host="127.0.0.1", port=1, token="t" * 24, scripts=lambda n: "", urls={}, sdk=30, arch="aarch64", min_free_mb=1, native_dir=None, va_bits=0)

    def put(self, payload=None):
        open(em.import_dest(self.data), "wb").write(payload if payload is not None else real_zip())

    def pick(self, name="a.zip", payload=None):
        self.put(payload)
        return em.import_register(self.data, name, os.path.getsize(em.import_dest(self.data)))

    def test_nothing_chosen(self):
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_register_requires_the_copied_file(self):
        with self.assertRaises(ValueError):
            em.import_register(self.data, "a.zip", 10)

    def test_pending_then_extracted_staged_into_guest_and_url_built(self):
        m = self.pick("../../evil/MT5 portable.zip")
        self.assertEqual(m["name"], "MT5 portable.zip", "chỉ giữ tên tệp, bỏ phần đường dẫn")
        self.assertEqual(em.import_info(self.data)["state"], "pending")
        env = self.emb().inner_env()
        self.assertRegex(env["MT5_SETUP_URL"], r"^file:///root/dl/mt5_import_x\?id=[0-9a-f-]+$")
        lo = em.Layout(self.data)
        self.assertTrue(os.path.isfile(os.path.join(lo.guest_x, "MetaTrader 5", "terminal64.exe")), "thư mục đã giải nén phải nằm trong Ubuntu")
        self.assertFalse(os.path.exists(lo.import_x), "chuyển bằng đổi tên: bản ngoài rootfs không còn")
        self.assertTrue(os.path.isfile(lo.import_zip), "tệp zip gốc vẫn giữ (để làm lại MT5 mà không phải chọn lại)")
        self.assertTrue(os.path.isfile(lo.guest_x_sha), "có sổ sha256 để script so lại trong Ubuntu")
        meta = em.import_info(self.data)
        self.assertEqual(meta["state"], "active")
        self.assertEqual(meta["extracted"], meta["id"])
        self.assertEqual(len(meta["zip_sha256"]), 64)

    def test_manifest_lists_big_files_in_sha256sum_format(self):
        import hashlib
        big = os.urandom(1500000)
        self.pick(payload=real_zip(entries={"MetaTrader 5/terminal64.exe": big, "MetaTrader 5/small.txt": b"x"}))
        self.emb().inner_env()
        lo = em.Layout(self.data)
        lines = open(lo.guest_x_sha, encoding="utf-8").read().splitlines()
        self.assertEqual(lines, ["%s  MetaTrader 5/terminal64.exe" % hashlib.sha256(big).hexdigest()])

    def test_active_import_is_sticky_across_restarts_with_blank_link(self):
        self.pick()
        u1 = self.emb().inner_env()["MT5_SETUP_URL"]
        u2 = self.emb().inner_env(mt5_url="")["MT5_SETUP_URL"]
        self.assertEqual(u1, u2, "mở lại app/bấm Bắt đầu lại vẫn dùng đúng tệp, không quay về bản chung")

    def test_same_file_is_not_extracted_twice(self):
        self.pick()
        self.emb().inner_env()
        lo = em.Layout(self.data)
        marker = os.path.join(lo.guest_x, "marker.txt")
        open(marker, "w").write("script đã nhận hoặc đang dùng thư mục này")
        self.emb().inner_env()
        self.assertTrue(os.path.isfile(marker), "cùng tệp, cùng id: không giải nén lại, không đụng thư mục đang dùng")
        self.assertFalse(os.path.exists(lo.import_x))

    def test_dir_moved_away_by_script_is_not_recreated(self):
        self.pick()
        self.emb().inner_env()
        lo = em.Layout(self.data)
        shutil.move(lo.guest_x, os.path.join(self.tmp.name, "adopted"))      # script đã chuyển vào prefix
        url = self.emb().inner_env()["MT5_SETUP_URL"]
        self.assertTrue(url.startswith("file:///root/dl/mt5_import_x"))
        self.assertFalse(os.path.exists(lo.guest_x) or os.path.exists(lo.import_x), "không giải nén lại thêm 300 MB mỗi lần bấm Bắt đầu")

    def test_force_redo_extracts_again(self):
        self.pick()
        self.emb().inner_env()
        lo = em.Layout(self.data)
        shutil.rmtree(lo.guest_x)
        self.emb()._import_url(False, force=True)
        self.assertTrue(os.path.isfile(os.path.join(lo.guest_x, "MetaTrader 5", "terminal64.exe")))

    def test_new_pick_changes_the_id_so_script_installs_fresh_dir(self):
        self.pick()
        u1 = self.emb().inner_env()["MT5_SETUP_URL"]
        self.pick(payload=real_zip(entries={"MetaTrader 5/terminal64.exe": os.urandom(3300)}))
        u2 = self.emb().inner_env()["MT5_SETUP_URL"]
        self.assertNotEqual(u1, u2)
        lo = em.Layout(self.data)
        self.assertEqual(os.path.getsize(os.path.join(lo.guest_x, "MetaTrader 5", "terminal64.exe")), 3300, "phải là nội dung tệp MỚI, không phải tệp cũ")

    def test_pending_import_beats_typed_link(self):
        self.pick()
        env = self.emb().inner_env(mt5_url="https://broker.example/x.exe")
        self.assertTrue(env["MT5_SETUP_URL"].startswith("file:///root/dl/"))

    def test_typed_link_after_active_import_drops_the_import(self):
        self.pick()
        self.emb().inner_env()                                       # đang dùng
        env = self.emb().inner_env(mt5_url="https://broker.example/x.exe")
        self.assertEqual(env["MT5_SETUP_URL"], "https://broker.example/x.exe")
        self.assertIsNone(em.import_info(self.data))
        lo = em.Layout(self.data)
        self.assertFalse(os.path.exists(lo.guest_x) or os.path.exists(lo.import_zip))

    def test_clear_removes_everything(self):
        self.pick()
        self.emb().inner_env()
        em.import_clear(self.data)
        lo = em.Layout(self.data)
        self.assertIsNone(em.import_info(self.data))
        self.assertFalse(any(os.path.exists(x) for x in (lo.guest_x, lo.guest_x_sha, lo.import_x, lo.import_x_sha, lo.import_zip, lo.import_meta)))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_zip_vanished_means_not_selected(self):
        self.pick()
        self.emb().inner_env()
        os.remove(em.Layout(self.data).import_zip)
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_corrupt_meta_is_ignored(self):
        os.makedirs(em.Layout(self.data).root, exist_ok=True)
        open(em.Layout(self.data).import_meta, "w").write("{không phải json")
        self.assertIsNone(em.import_info(self.data))
        self.assertNotIn("MT5_SETUP_URL", self.emb().inner_env())

    def test_id_in_url_cannot_inject_characters(self):
        self.pick()
        meta_path = em.Layout(self.data).import_meta
        m = json.load(open(meta_path))
        m["id"] = "abc12-3?;rm -rf /"
        json.dump(m, open(meta_path, "w"))
        url = self.emb().inner_env()["MT5_SETUP_URL"]
        self.assertRegex(url, r"^file:///root/dl/mt5_import_x\?id=[0-9a-f-]*$")

    # ---- zip hỏng: báo NGAY ĐẦU lần cài ----
    def corrupt_zip(self):
        bad = bytearray(real_zip(entries={"MetaTrader 5/terminal64.exe": os.urandom(400000)}))
        bad[len(bad) // 3: len(bad) // 3 + 60000] = bytes(60000)
        return bytes(bad)

    def test_corrupt_zip_raises_before_anything_is_staged(self):
        self.pick(payload=self.corrupt_zip())
        with self.assertRaises(ValueError) as cm:
            self.emb()._import_url(False)
        self.assertIn("HỎNG", str(cm.exception))
        lo = em.Layout(self.data)
        self.assertFalse(os.path.exists(lo.guest_x) or os.path.exists(lo.import_x), "không để lại thư mục dở")
        self.assertEqual(em.import_info(self.data)["state"], "pending", "chưa dùng được thì vẫn «chờ dùng»")

    def test_install_fails_at_the_very_first_stage_with_clear_message(self):
        self.pick(payload=self.corrupt_zip())
        e = self.emb()
        e.event = lambda stage, state, detail="": e.events.append((stage, state, detail))
        e.events = []
        e.set_state = lambda **kw: e.states.update(kw)
        e.states = {}
        ok = e.install()
        self.assertFalse(ok)
        stages = [x[0] for x in e.events]
        self.assertIn("precheck", stages)
        self.assertNotIn("proot", stages, "zip hỏng phải dừng TRƯỚC khi tải proot/Ubuntu (không đợi hơn 1 giờ)")
        fail = [x for x in e.events if x[1] == "fail"]
        self.assertEqual(len(fail), 1)
        self.assertIn("HỎNG", fail[0][2])
        self.assertIn("TẢI LẠI", fail[0][2])
        self.assertEqual(e.states.get("failed_stage"), "precheck")

    def test_failure_message_says_where_to_change_or_delete_the_zip(self):
        self.pick(payload=self.corrupt_zip())
        e = self.emb()
        e.event = lambda stage, state, detail="": e.events.append((stage, state, detail))
        e.events = []
        e.set_state = lambda **kw: None
        e.install()
        detail = [x for x in e.events if x[1] == "fail"][0][2]
        self.assertIn("Chọn tệp .zip MT5", detail)
        self.assertIn("Bỏ tệp .zip", detail)
        self.assertIn("Khởi động lại", detail)

    def test_after_a_bad_zip_a_new_pick_is_used_on_the_next_run(self):
        # người dùng: «zip lỗi thì không có chỗ import lại» -> chọn tệp mới rồi «Khởi động lại» phải dùng tệp MỚI, không dính tệp hỏng cũ
        self.pick(name="hong.zip", payload=self.corrupt_zip())
        e = self.emb()
        e.event = lambda *a, **k: None
        e.set_state = lambda **kw: None
        self.assertFalse(e.install())
        old_id = em.import_info(self.data)["id"]
        self.pick(name="tot.zip")
        self.assertNotEqual(em.import_info(self.data)["id"], old_id)
        e2 = self.emb()
        e2._precheck_machine = lambda: None
        e2.st_precheck()
        m = em.import_info(self.data)
        self.assertEqual(m["name"], "tot.zip")
        self.assertEqual(m["extracted"], m["id"])
        self.assertTrue(os.path.exists(os.path.join(em.Layout(self.data).import_x, "MetaTrader 5", "terminal64.exe")))

    def test_deleting_a_bad_zip_leaves_nothing_behind(self):
        self.pick(payload=self.corrupt_zip())
        e = self.emb()
        e.event = lambda *a, **k: None
        e.set_state = lambda **kw: None
        e.install()
        em.import_clear(self.data)
        lo = em.Layout(self.data)
        self.assertIsNone(em.import_info(self.data))
        for pth in (lo.import_zip, lo.import_x, lo.guest_x, lo.import_meta):
            self.assertFalse(os.path.exists(pth), pth)

    def test_good_zip_does_not_block_precheck(self):
        self.pick()
        e = self.emb()
        e._precheck_machine = lambda: None
        e.st_precheck()
        self.assertEqual(em.import_info(self.data)["extracted"], em.import_info(self.data)["id"])

    def test_precheck_progress_goes_to_first_row_not_mt5_row(self):
        # UI suy «bước trước đã xong» từ bước SAU: tiến độ giải nén mà báo ở hàng «mt5» sẽ làm apt/box64/wine hiện «xong» giả
        self.pick()
        e = self.emb()
        e._precheck_machine = lambda: None
        got = []
        e.event = lambda stage, state, detail="": got.append(stage)
        e.st_precheck()
        self.assertTrue(got and set(got) == {"precheck"}, got)


if __name__ == "__main__":
    unittest.main()
