"""Workflow «Lấy thư mục MT5 (zip)» (máy Windows của GitHub): không chạy được ở đây, nên chỉ khoá những điều kiểm tĩnh được."""
import os
import re
import unittest

import yaml

ROOT = os.path.join(os.path.dirname(__file__), "..")


def read(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as f:
        return f.read()


class TestMt5PortableWorkflow(unittest.TestCase):
    def setUp(self):
        self.text = read("docs", "mt5-portable.yml")
        self.wf = yaml.safe_load(self.text)
        self.on = self.wf.get("on", self.wf.get(True))
        self.job = self.wf["jobs"]["mt5"]

    def test_both_copies_identical(self):
        self.assertEqual(self.text, read(".github", "workflows", "mt5-portable.yml"))

    def test_manual_only_and_read_only_token(self):
        self.assertEqual(set(self.on), {"workflow_dispatch"}, "chỉ chạy tay: không tự chạy khi push/PR")
        self.assertEqual(self.wf["permissions"], {"contents": "read"})

    def test_runs_on_windows_with_timeout(self):
        self.assertEqual(self.job["runs-on"], "windows-latest")
        self.assertLessEqual(int(self.job["timeout-minutes"]), 60)

    def test_user_input_never_inline_in_scripts(self):
        # link do người dùng nhập chỉ được vào qua biến môi trường (chống chèn lệnh), không `${{ inputs.* }}` trong run
        for st in self.job["steps"]:
            self.assertNotIn("${{", st.get("run", ""), st["name"])
        env_use = [st for st in self.job["steps"] if "inputs.setup_url" in str(st.get("env", ""))]
        self.assertEqual(len(env_use), 1)

    def test_only_https_links_and_exe_magic_checked(self):
        self.assertIn("^https://", self.text)
        self.assertIn("0x4D", self.text)

    def test_artifact_short_retention_and_fails_when_empty(self):
        up = self.job["steps"][-1]
        self.assertTrue(up["uses"].startswith("actions/upload-artifact@v4"))
        self.assertEqual(up["with"]["name"], "mt5-portable")
        self.assertLessEqual(int(up["with"]["retention-days"]), 7)
        self.assertEqual(up["with"]["if-no-files-found"], "error")
        self.assertIn("OUT_DIR", up["with"]["path"])

    def test_packages_a_copy_on_a_simple_path(self):
        # Program Files (x86) có ngoặc đơn: không đưa thẳng vào mẫu glob của upload-artifact
        self.assertIn("RUNNER_TEMP 'mt5-portable'", self.text)
        self.assertIn("Replace('\\', '/')", self.text)

    def test_no_secrets_or_keys_referenced(self):
        self.assertNotIn("secrets.", self.text)
        self.assertIsNone(re.search(r"BEGIN [A-Z ]*PRIVATE KEY", self.text))


if __name__ == "__main__":
    unittest.main()
