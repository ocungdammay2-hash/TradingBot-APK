"""tools/ci_derive_keystore.py: khoá ký APK dẫn xuất từ hạt giống - phải TẤT ĐỊNH (cài đè được giữa các lần build), đọc được bằng keytool, và từ chối hạt giống yếu."""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
try:
    import ci_derive_keystore as K
    from cryptography.hazmat.primitives import serialization
    HAVE = True
except ImportError:                                     # máy không có cryptography: bỏ qua, CI luôn cài
    HAVE = False

SEED = "Kq9vT2mZp4Ls7Wd1Rb6Nc3Hy5Fj8Ga0XeQ"
TOOL = os.path.join(HERE, "..", "tools", "ci_derive_keystore.py")


@unittest.skipUnless(HAVE, "cần cryptography")
class TestDerive(unittest.TestCase):
    def test_same_seed_same_certificate_byte_for_byte(self):
        a, b = K.build(SEED), K.build(SEED)
        der = lambda c: c.public_bytes(serialization.Encoding.DER)
        self.assertEqual(der(a[1]), der(b[1]))                       # Android so sánh NGUYÊN chứng chỉ
        self.assertEqual(K.fingerprint(a[1]), K.fingerprint(b[1]))

    def test_surrounding_whitespace_in_secret_is_ignored(self):
        self.assertEqual(K.fingerprint(K.build(SEED)[1]), K.fingerprint(K.build("  " + SEED + "\n")[1]))

    def test_different_seed_different_key(self):
        self.assertNotEqual(K.fingerprint(K.build(SEED)[1]), K.fingerprint(K.build(SEED + "x")[1]))

    def test_key_is_2048_bit_rsa_with_e_65537_and_sane_primes(self):
        key, cert = K.build(SEED)
        n = key.public_key().public_numbers()
        self.assertEqual((n.n.bit_length(), n.e), (2048, 65537))
        pn = key.private_numbers()
        self.assertEqual(pn.p * pn.q, n.n)
        self.assertTrue(K.is_probable_prime(pn.p) and K.is_probable_prime(pn.q))
        self.assertNotEqual(pn.p, pn.q)

    def test_weak_seed_refused(self):
        for bad in ("", "abc", "x" * (K.MIN_SEED - 1), "   " + "y" * 10 + "   "):
            with self.assertRaises(K.SeedError):
                K.build(bad)

    def test_primality_helper(self):
        for p in (2, 3, 97, 7919, 2 ** 127 - 1):
            self.assertTrue(K.is_probable_prime(p), p)
        for c in (0, 1, 4, 91, 7917, 561, 2 ** 127 - 3 * 7):          # 561 = số Carmichael
            self.assertFalse(K.is_probable_prime(c), c)

    def test_write_file_private_and_atomic(self):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "sub", "debug.keystore")
            fp = K.write_keystore(SEED, p)
            self.assertTrue(os.path.getsize(p) > 500)
            self.assertEqual(os.stat(p).st_mode & 0o777, 0o600)
            self.assertFalse(os.path.exists(p + ".tmp"))
            self.assertEqual(fp, K.fingerprint(K.build(SEED)[1]))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    @unittest.skipUnless(shutil.which("keytool"), "cần keytool (JDK)")
    def test_keytool_reads_it_with_gradle_alias_and_password(self):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "debug.keystore")
            fp = K.write_keystore(SEED, p)
            out = subprocess.run(["keytool", "-list", "-v", "-keystore", p, "-storepass", "android", "-alias", "androiddebugkey"], capture_output=True, text=True, timeout=60)
            self.assertEqual(out.returncode, 0, out.stdout + out.stderr)
            self.assertIn("PrivateKeyEntry", out.stdout)
            self.assertIn("SHA256: " + fp, out.stdout)                   # đúng định dạng dấu vân tay mà workflow in ra
            bad = subprocess.run(["keytool", "-list", "-keystore", p, "-storepass", "wrong", "-alias", "androiddebugkey"], capture_output=True, text=True, timeout=60)
            self.assertNotEqual(bad.returncode, 0)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    @unittest.skipUnless(shutil.which("jarsigner") and shutil.which("zip"), "cần jarsigner + zip")
    def test_jarsigner_signs_with_it(self):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "debug.keystore")
            K.write_keystore(SEED, p)
            open(os.path.join(d, "f.txt"), "w").write("x")
            subprocess.run(["zip", "-q", os.path.join(d, "t.jar"), "f.txt"], cwd=d, check=True)
            r = subprocess.run(["jarsigner", "-keystore", p, "-storepass", "android", "-keypass", "android", os.path.join(d, "t.jar"), "androiddebugkey"], capture_output=True, text=True, timeout=60)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        finally:
            shutil.rmtree(d, ignore_errors=True)


@unittest.skipUnless(HAVE, "cần cryptography")
class TestCli(unittest.TestCase):
    def run_tool(self, args, seed=None):
        env = dict(os.environ)
        env.pop("KS_SEED", None)
        if seed is not None:
            env["KS_SEED"] = seed
        return subprocess.run([sys.executable, TOOL] + args, capture_output=True, text=True, env=env, timeout=120)

    def test_cli_prints_fingerprint_and_never_echoes_seed(self):
        d = tempfile.mkdtemp()
        try:
            r = self.run_tool([os.path.join(d, "k")], SEED)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(r.stdout.strip(), K.fingerprint(K.build(SEED)[1]))
            self.assertNotIn(SEED, r.stdout + r.stderr)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_cli_rejects_weak_or_missing_seed_and_writes_nothing(self):
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "k")
            for seed in (None, "short"):
                r = self.run_tool([p], seed)
                self.assertEqual(r.returncode, 3, r.stderr)
                self.assertFalse(os.path.exists(p))
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_seed_is_not_accepted_on_the_command_line(self):
        r = self.run_tool([SEED, "x"])                                   # sai số tham số -> báo cách dùng, không dùng làm hạt giống
        self.assertEqual(r.returncode, 2)


if __name__ == "__main__":
    unittest.main()


class TestAppSignature(unittest.TestCase):
    """android_native.app_signature: đọc chữ ký APK đang chạy để so với dấu vân tay CI (không cần Android thật: giả pyjnius)."""

    def setUp(self):
        sys.path.insert(0, os.path.join(HERE, ".."))
        from pyea import android_native
        self.an = android_native
        self.orig = (android_native._jnius, android_native.context, android_native.sdk_int, android_native.IS_ANDROID)

    def tearDown(self):
        self.an._jnius, self.an.context, self.an.sdk_int, self.an.IS_ANDROID = self.orig

    def fake(self, sdk, cert=b"CERT-DER-BYTES", fail=False):
        class Sig:
            def toByteArray(s):
                return [b - 256 if b > 127 else b for b in cert]          # pyjnius trả byte[] có dấu
        class Info:
            versionName = "1.9.50"
            versionCode = 1009050
            signatures = [Sig()]
            def getLongVersionCode(s): return 1009050
            class signingInfo:
                @staticmethod
                def getApkContentsSigners(): return [Sig()]
        class Pm:
            def getPackageInfo(s, pkg, flags):
                if fail: raise RuntimeError("NameNotFoundException")
                return Info()
        class Ctx:
            def getPackageManager(s): return Pm()
            def getPackageName(s): return "org.pyea.pyearunner"
        class PMC:
            GET_SIGNING_CERTIFICATES = 134217728
            GET_SIGNATURES = 64
        self.an.context = lambda: Ctx()
        self.an._jnius = lambda: (lambda name: PMC)
        self.an.sdk_int = lambda: sdk

    def test_fingerprint_format_matches_keytool(self):
        import hashlib
        want = ":".join("%02X" % b for b in hashlib.sha256(b"abc").digest())
        self.assertEqual(self.an.cert_fingerprint(b"abc"), want)
        self.assertRegex(want, r"^([0-9A-F]{2}:){31}[0-9A-F]{2}$")

    def test_reads_signing_certs_on_api28_and_signatures_before(self):
        import hashlib
        want = self.an.cert_fingerprint(b"CERT-DER-BYTES")
        for sdk in (28, 29, 24):
            self.fake(sdk)
            a = self.an.app_signature()
            self.assertEqual((a["error"], a["version_name"], a["version_code"], a["sha256"]), ("", "1.9.50", 1009050, [want]), sdk)

    def test_signed_bytes_are_unsigned_before_hashing(self):
        cert = bytes(range(120, 140))                                     # có byte > 127
        self.fake(29, cert)
        self.assertEqual(self.an.app_signature()["sha256"], [self.an.cert_fingerprint(cert)])

    def test_error_never_raises(self):
        self.fake(29, fail=True)
        a = self.an.app_signature()
        self.assertIn("NameNotFoundException", a["error"])
        self.assertEqual(a["sha256"], [])

    def test_line_empty_off_android_and_informative_on(self):
        self.an.IS_ANDROID = False
        self.assertEqual(self.an.app_signature_line(), "")
        self.an.IS_ANDROID = True
        self.fake(29)
        line = self.an.app_signature_line()
        self.assertIn("chữ_ký_SHA256=" + self.an.cert_fingerprint(b"CERT-DER-BYTES"), line)
        self.fake(29, fail=True)
        self.assertIn("không đọc được", self.an.app_signature_line())
