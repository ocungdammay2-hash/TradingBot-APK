"""«Giá đứng» khi thị trường VN đóng cửa KHÔNG được tính là mất kết nối (vnmarket.quiet_symbols + TradingSession.health + linkwatch);
và ngược lại: lỗi thật vẫn báo, mất kết nối KHÔNG bao giờ được suy ra thành «ngày nghỉ»."""
import datetime
import os
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub                                                 # noqa: E402
kivy_stub.install()

from pyea import vnmarket                                         # noqa: E402
from test_recon_cache import make                                 # noqa: E402

VN = datetime.timezone(datetime.timedelta(hours=7))


def ts(y, m, d, hh, mm, ss=0):
    return datetime.datetime(y, m, d, hh, mm, ss, tzinfo=VN).timestamp()


# 2026-11-23 là Thứ Hai (ngày thường, lịch 2026 đã biết, không lễ); 11-28 là Thứ Bảy; 2026-09-02 (Quốc khánh) là Thứ Tư; 2027 chưa có lịch.
MON = (2026, 11, 23)


class TestQuietSymbols(unittest.TestCase):
    def q(self, h, m, sec=0, syms=("HPG",), date=MON, **kw):
        return vnmarket.quiet_symbols(list(syms), ts(*date, h, m, sec), **kw)

    def test_open_hours_not_quiet(self):
        self.assertEqual(self.q(10, 0), set())
        self.assertEqual(self.q(14, 40), set())                    # ATC vẫn là đang giao dịch

    def test_outside_hours_quiet(self):
        for h, m in ((7, 0), (8, 59), (12, 0), (15, 30), (23, 0)):  # trước giờ, nghỉ trưa, sau giờ
            self.assertEqual(self.q(h, m), {"HPG"}, (h, m))

    def test_weekend_and_holiday_quiet(self):
        self.assertEqual(self.q(10, 0, date=(2026, 11, 28)), {"HPG"})
        self.assertEqual(self.q(10, 0, date=(2026, 9, 2)), {"HPG"})
        self.assertEqual(self.q(10, 0, date=(2026, 9, 2), extra="2026-09-02"), {"HPG"})

    def test_grace_after_reopen(self):
        self.assertEqual(self.q(9, 0, 30), {"HPG"})                # mở cửa 30 giây: tick đầu có thể chưa tới
        self.assertEqual(self.q(9, 1, 59), {"HPG"})
        self.assertEqual(self.q(9, 2, 1), set())                   # quá 120 giây: bắt đầu đòi giá tươi
        self.assertEqual(self.q(13, 0, 10), {"HPG"})               # sau nghỉ trưa
        self.assertEqual(self.q(13, 2, 30), set())
        self.assertEqual(self.q(9, 0, 30, grace=0), set())          # tắt grace

    def test_user_added_holiday_is_quiet(self):
        self.assertEqual(self.q(10, 0, extra="2026-11-23"), {"HPG"})

    def test_unknown_year_weekday_not_guessed_as_closed(self):
        # 2027 chưa có lịch: ngày thường trong giờ giao dịch vẫn tính là đang giao dịch -> mất giá vẫn phải báo (không đoán là nghỉ)
        d = (2027, 6, 15)                                          # Thứ Ba
        self.assertEqual(datetime.date(*d).weekday(), 1)
        self.assertFalse(vnmarket.state(ts(*d, 10, 0), "hose")["calendar_known"])
        self.assertEqual(self.q(10, 0, date=d), set())
        self.assertEqual(self.q(10, 0, date=(2027, 6, 19)), {"HPG"})   # nhưng cuối tuần thì luôn nghỉ

    def test_derivative_venue(self):
        # mỗi mã được xét theo sàn CỦA NÓ (phái sinh VN30F… khác giờ với cổ phiếu): kết quả phải khớp state() của sàn đó
        for h, m in ((9, 30), (11, 45), (14, 35), (14, 50)):
            got = self.q(h, m, syms=("VN30F2612", "HPG"))
            for sym in ("VN30F2612", "HPG"):
                st = vnmarket.state(ts(*MON, h, m), vnmarket.venue_for(sym))
                prev = vnmarket.state(ts(*MON, h, m) - 120, vnmarket.venue_for(sym))
                self.assertEqual(sym in got, (not st["trading"]) or (not prev["trading"]), (sym, h, m))

    def test_calendar_error_never_hides_alarm(self):
        orig = vnmarket.state
        vnmarket.state = lambda *a, **k: 1 / 0
        try:
            self.assertEqual(self.q(3, 0), set())                  # lỗi lịch -> coi như KHÔNG yên lặng -> vẫn báo mất giá
        finally:
            vnmarket.state = orig

    def test_empty(self):
        self.assertEqual(vnmarket.quiet_symbols([], ts(*MON, 3, 0)), set())
        self.assertEqual(vnmarket.quiet_symbols(None, ts(*MON, 3, 0)), set())


class TestHealth(unittest.TestCase):
    def sess(self, exchange="dnse", syms=("HPG", "FPT"), age=600.0, **over):
        s = make(exchange=exchange, stale_after=30.0, **over)
        s.watch = list(syms)
        now = time.time()
        s._tick_wall = {x: now - age for x in syms}                # mọi mã đã 10 phút không có giá mới
        return s

    def test_closed_market_not_disconnected(self):
        s = self.sess()
        h = s.health(now=ts(2026, 11, 28, 10, 0))                  # Thứ Bảy
        self.assertEqual(h["state"], "market_closed")
        self.assertEqual(h["market_closed"], ["FPT", "HPG"])
        self.assertEqual(h["stale"], [])

    def test_open_market_stale_is_disconnected(self):
        s = self.sess()
        h = s.health(now=ts(*MON, 10, 0))                          # đang giao dịch mà 10 phút không có giá = mất giá thật
        self.assertEqual(h["state"], "disconnected")
        self.assertEqual(h["market_closed"], [])

    def test_feed_errors_still_count_on_closed_day(self):
        s = self.sess()
        s._feed_fail = {"HPG": 7}                                  # HPG: sàn trả LỖI thật - không được che dù thị trường đóng
        h = s.health(now=ts(2026, 11, 28, 10, 0))
        self.assertEqual(h["failing"], ["HPG"])
        self.assertEqual(h["market_closed"], ["FPT"])
        self.assertNotEqual(h["state"], "market_closed")

    def test_other_exchanges_unaffected(self):
        for ex in ("binance_futures", "simulated", "public"):
            s = self.sess(exchange=ex, syms=("BTCUSDT",))
            h = s.health(now=ts(2026, 11, 28, 10, 0))
            self.assertEqual(h["state"], "disconnected", ex)        # crypto 24/7: Thứ Bảy không phải lý do giá đứng
            self.assertEqual(h["market_closed"], [], ex)

    def test_fresh_ticks_report_connected(self):
        s = self.sess(age=1.0)
        self.assertEqual(s.health(now=ts(*MON, 10, 0))["state"], "connected")

    def test_connection_loss_is_not_inferred_as_holiday(self):
        """Ngày thường trong giờ giao dịch + mất kết nối => vẫn là mất kết nối (không có nhánh nào suy ra «nghỉ lễ» từ lỗi mạng)."""
        s = self.sess()
        s._feed_fail = {"HPG": 30, "FPT": 30}
        h = s.health(now=ts(*MON, 10, 0))
        self.assertEqual(h["state"], "disconnected")
        self.assertEqual(h["market_closed"], [])
        self.assertEqual(vnmarket.state(ts(*MON, 10, 0))["phase"], "continuous")

    def test_extra_holiday_setting_respected(self):
        s = self.sess(vn_extra_holidays="2026-11-23")
        self.assertEqual(s.health(now=ts(*MON, 10, 0))["state"], "market_closed")

    def test_no_symbols_idle(self):
        s = self.sess(syms=())
        self.assertEqual(s.health(now=ts(*MON, 10, 0))["state"], "idle")


class TestLinkWatch(unittest.TestCase):
    def test_no_false_alarm_on_weekend_but_real_alarm_on_trading_day(self):
        s = make(exchange="dnse", stale_after=30.0, link_alarm_s=1.0)
        s.watch = ["HPG"]
        s._tick_wall = {"HPG": time.time() - 900}
        s._link_t = 0.0
        # Thứ Bảy: không cảnh báo
        orig = vnmarket.quiet_symbols
        vnmarket.quiet_symbols = lambda syms, now=None, extra=None, grace=120.0: orig(syms, ts(2026, 11, 28, 10, 0), extra, grace)
        try:
            s._check_link_inner()
            self.assertEqual(s._link["down_since"], 0.0)
            self.assertEqual(s._link["episodes"], 0)
            # Thứ Hai 10:00: cảnh báo thật
            vnmarket.quiet_symbols = lambda syms, now=None, extra=None, grace=120.0: orig(syms, ts(*MON, 10, 0), extra, grace)
            s._link_t = 0.0
            s._check_link_inner()
            self.assertEqual(s._link["episodes"], 1)
            self.assertGreater(s._link["down_since"], 0.0)
        finally:
            vnmarket.quiet_symbols = orig


if __name__ == "__main__":
    unittest.main()
