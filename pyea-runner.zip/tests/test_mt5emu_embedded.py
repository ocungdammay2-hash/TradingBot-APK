"""Phần app của MT5 NHÚNG: chuẩn bị (cài đặt lean, mật khẩu chỉ RAM, bật dịch vụ), đọc tiến trình/CPU-RAM, các câu trạng thái, file .set chế độ nhẹ, EA có chế độ nhẹ.
Dịch vụ Emu/proot thật chạy ở tests/test_embedded.py (proot giả); ở đây dịch vụ được thay bằng hàm giả."""
import base64
import json
import os
import socket
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from pyea import embedded as em                  # noqa: E402
from pyea import mt5ea, mt5emu                   # noqa: E402
from test_mt5emu import free_port, get_file, sup_exchange, wait as wait_for      # noqa: E402


def served(port, tok, name):
    d = get_file(port, tok, name)
    return base64.b64decode(d["b64"]).decode("utf-8")


class TestPrepareEmbedded(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.s = {"mt5ea_port": str(free_port())}
        self.calls = []
        self.upd, self.srv, self.res = mt5emu.prepare_embedded(self.s, "5550123", "Pw!1secret", "Demo-1", "https://b.example/mt5.exe", data_dir=self.tmp.name,
                                                               launcher=lambda a: self.calls.append(json.loads(a)) or (True, ""))
        self.port, self.tok = self.srv.port, self.upd["mt5ea_token"]
        self.addCleanup(lambda: (self.srv.close(), mt5ea._SERVERS.pop(self.port, None)))

    def test_settings_lean_and_service_started(self):
        self.assertEqual(self.upd["mt5ea_lean"], "yes")
        self.assertEqual(self.upd["mt5ea_supervised"], "yes")
        self.assertEqual(self.res, (True, ""))
        self.assertEqual(self.calls, [{"data_dir": self.tmp.name}])
        q = em.read_request(self.tmp.name)
        self.assertEqual((q["want"], q["port"], q["token"], q["profile"], q["mt5_url"]), ("run", self.port, self.tok, "lean", "https://b.example/mt5.exe"))

    def test_password_only_in_app_ram_never_in_files_or_args(self):
        for root, _, files in os.walk(self.tmp.name):
            for f in files:
                self.assertNotIn("Pw!1secret", open(os.path.join(root, f), errors="replace").read(), f)
        self.assertNotIn("Pw!1secret", json.dumps(self.calls))
        ini = served(self.port, self.tok, "startup.ini")                 # script trong Ubuntu lấy qua cổng cục bộ
        self.assertIn("Password=Pw!1secret", ini)
        self.srv.set_first_login_password(None)
        self.assertNotIn("Password", served(self.port, self.tok, "startup.ini"))

    def test_bridge_set_is_lean(self):
        d = served(self.port, self.tok, "bridge.set")
        self.assertIn("InpLean=true", d)
        self.assertIn("InpTimerMs=%d" % mt5ea.LEAN_TIMER_MS, d)

    def test_bad_input_refused_before_anything_starts(self):
        with self.assertRaises(ValueError):
            mt5emu.prepare_embedded({}, "abc", "pw", "S", data_dir=self.tmp.name, launcher=lambda a: self.fail("không được bật dịch vụ"))

    def test_launch_failure_is_returned_not_raised(self):
        s = {"mt5ea_port": str(free_port())}
        upd, srv, res = mt5emu.prepare_embedded(s, "5550123", "pw", "S", data_dir=self.tmp.name, launcher=lambda a: (False, "ClassNotFound: ServiceEmu"))
        self.addCleanup(lambda: (srv.close(), mt5ea._SERVERS.pop(srv.port, None)))
        self.assertEqual(res, (False, "ClassNotFound: ServiceEmu"))


class TestSetFile(unittest.TestCase):
    def test_default_not_lean(self):
        d = mt5ea.make_set_file({"mt5ea_port": "19999", "mt5ea_token": "tok-12345678"})
        self.assertIn("InpLean=false", d)
        self.assertIn("InpTimerMs=100", d)

    def test_setting_registered(self):
        from pyea import settings
        self.assertEqual(settings.default_settings()["mt5ea_lean"], "no")
        self.assertIn("mt5ea_lean", settings.API_KEYS["mt5ea"])


class TestProgressEmbedded(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.d = self.tmp.name
        self.srv = mt5ea.Mt5EaServer(0, "tok_progress_123")
        self.srv.start()
        self.addCleanup(self.srv.close)

    def state(self, **kv):
        lo = em.Layout(self.d)
        os.makedirs(lo.root, exist_ok=True)
        kv.setdefault("t", time.time())
        open(lo.state, "w").write(json.dumps(kv))

    def ev(self, stage, state, detail=""):
        sup_exchange(self.srv.port, "tok_progress_123", "SEVT|kind=install|stage=%s|state=%s|detail=%s" % (stage, state, detail))

    def test_rows_are_embedded_stages_in_order(self):
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual([r[0] for r in p["rows"]], [i for i, _ in mt5ea.EMBED_STAGES])
        self.assertNotIn("termux_pkgs", [r[0] for r in p["rows"]])               # không còn bước Termux
        self.assertEqual(p["pct"], 0)

    def test_progress_from_server_events(self):
        for st in ("precheck", "proot", "rootfs"):
            self.ev(st, "ok")
        self.ev("apt", "start", "Cài thư viện")
        p = mt5emu.progress_embedded(self.srv, self.d)
        stt = {r[0]: r[2] for r in p["rows"]}
        self.assertEqual((stt["precheck"], stt["proot"], stt["rootfs"], stt["apt"], stt["wine"]), ("ok", "ok", "ok", "run", "todo"))
        self.assertGreater(p["pct"], 0)
        self.assertIn("Đang cài", mt5emu.headline_embedded(p)[0])

    # ---- log thật: «Đang cài (0%)» dù đã qua 5/11 bước (mở lại app giữa chừng => RAM của cầu nối cục bộ trống) ----
    def stage_log(self, *entries, t=None):
        lo = em.Layout(self.d)
        os.makedirs(os.path.dirname(lo.stages_log), exist_ok=True)
        t = int(t or time.time())
        with open(lo.stages_log, "a", encoding="utf-8") as f:
            for sid, state in entries:
                f.write("%d %s %s\n" % (t, sid, state))

    def stt(self, p):
        return {r[0]: r[2] for r in p["rows"]}

    def test_percent_survives_reopening_the_app_because_steps_are_read_from_disk(self):
        now = time.time()
        self.state(phase="installing", run_t=now - 60, stages={"precheck": {"state": "ok", "detail": "", "t": now - 50}, "proot": {"state": "skip", "detail": "", "t": now - 49},
                                                                "rootfs": {"state": "skip", "detail": "", "t": now - 48}})
        self.stage_log(("apt", "skip"), ("box64", "skip"), ("wine", "start"), t=now - 30)
        self.assertEqual(self.srv.install, {}, "máy chủ vừa mở lại: RAM trống")
        p = mt5emu.progress_embedded(self.srv, self.d)
        s = self.stt(p)
        self.assertEqual([s[i] for i in ("precheck", "proot", "rootfs", "apt", "box64")], ["ok"] * 5)
        self.assertEqual(s["wine"], "run")
        self.assertEqual(s["prefix"], "todo")
        self.assertGreaterEqual(p["pct"], 45, "5/11 bước xong + bước đang chạy tính nửa phần")
        self.assertTrue(p["started"])
        self.assertIn("Đang cài (%d%%)" % p["pct"], mt5emu.headline_embedded(p)[0])
        self.assertNotIn("(0%)", mt5emu.headline_embedded(p)[0])

    def test_earlier_steps_are_inferred_when_only_a_later_event_reached_the_app(self):
        self.ev("wine", "progress", "đã có 244 MB, vẫn đang chạy")            # đúng ảnh chụp: chỉ có sự kiện của bước đang chạy
        p = mt5emu.progress_embedded(self.srv, self.d)
        s = self.stt(p)
        for sid in ("precheck", "proot", "rootfs", "apt", "box64"):
            self.assertEqual(s[sid], "ok", (sid, p["rows"]))
        self.assertEqual(s["wine"], "run")
        self.assertIn("244 MB", dict((r[0], r[3]) for r in p["rows"])["wine"], "chi tiết của bước đang chạy vẫn hiện")
        self.assertIn("suy ra", dict((r[0], r[3]) for r in p["rows"])["apt"])
        self.assertGreater(p["pct"], 0)

    def test_nothing_known_yet_is_still_zero(self):
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual(p["pct"], 0)
        self.assertEqual(set(self.stt(p).values()), {"todo"})
        self.assertFalse(p["started"])

    def test_log_lines_from_a_previous_run_do_not_show_as_this_runs_state(self):
        now = time.time()
        self.stage_log(("apt", "ok"), ("mt5", "fail"), t=now - 3600)          # lần cài trước: lỗi ở mt5
        self.state(phase="installing", run_t=now - 5)                         # lần này vừa bắt đầu
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual(p["failed"], [], "lỗi cũ của lần trước không được hiện như lỗi hiện tại")
        self.assertEqual(self.stt(p)["mt5"], "todo")
        self.assertEqual(em.read_stages(self.d), {})

    def test_a_newer_disk_record_beats_an_older_one_in_ram(self):
        self.ev("wine", "progress", "đang tải")
        time.sleep(0.05)
        now = time.time() + 5
        self.stage_log(("wine", "ok"), t=now)
        self.state(phase="installing")
        self.assertEqual(self.stt(mt5emu.progress_embedded(self.srv, self.d))["wine"], "ok")

    def test_failure_recorded_only_on_disk_is_shown(self):
        now = time.time()
        self.state(phase="installing", run_t=now - 30)
        self.stage_log(("apt", "ok"), ("box64", "ok"), ("wine", "ok"), ("prefix", "ok"), ("mt5", "fail"), t=now - 1)
        p = mt5emu.progress_embedded(None, self.d)                              # app chưa có máy chủ cầu nối
        self.assertEqual([r[0] for r in p["failed"]], ["mt5"])
        self.assertEqual(mt5emu.headline_embedded(p)[1], "fail")

    def test_percent_is_monotonic_as_steps_finish(self):
        last = -1
        self.state(phase="installing")
        for sid, _ in mt5ea.EMBED_STAGES[:-1]:
            self.ev(sid, "start")
            p = mt5emu.progress_embedded(self.srv, self.d)
            self.assertGreaterEqual(p["pct"], last, (sid, p["pct"], last))
            last = p["pct"]
            self.ev(sid, "ok")
            p = mt5emu.progress_embedded(self.srv, self.d)
            self.assertGreater(p["pct"], 0)
            self.assertGreaterEqual(p["pct"], last)
            last = p["pct"]
        self.assertLess(last, 100, "chưa có EA nối thì không bao giờ 100%")

    def test_termux_flow_does_not_infer_steps(self):
        sup_exchange(self.srv.port, "tok_progress_123", "SEVT|kind=install|stage=wine|state=progress|detail=x")
        self.assertTrue(wait_for(lambda: "wine" in self.srv.install))
        st = {sid: s for sid, _, s, _ in mt5emu.progress(self.srv)["rows"]}
        self.assertEqual(st["precheck"], "todo", "luồng Termux giữ cách cũ: không suy ra")

    def test_failure_from_service_state_when_server_missed_it(self):
        self.state(phase="failed", failed_stage="proot", error="proot không chạy được")
        p = mt5emu.progress_embedded(None, self.d)                                # app chưa có máy chủ: vẫn hiện lỗi thật từ state.json
        text, tone = mt5emu.headline_embedded(p)
        self.assertEqual(tone, "fail")
        self.assertIn("Tải proot", text)
        self.assertIn("proot không chạy được", mt5emu.render(p))

    def test_stopped_and_dead_service_messages(self):
        self.state(phase="stopped")
        self.assertIn("DỪNG", mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))[0])
        self.state(phase="installing", t=time.time() - 600)                       # đang «cài» nhưng 10 phút không có nhịp
        self.assertIn("CHƯA thấy dịch vụ nền", mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))[0])

    def test_resources_shown_from_server_and_fallback_to_state(self):
        sup_exchange(self.srv.port, "tok_progress_123", "SEVT|kind=res|cpu=37.5|rss=412|procs=9|top=terminal64.exe:30%25/300MB")
        self.state(phase="running")
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertEqual((p["res"]["cpu"], p["res"]["rss_mb"], p["res"]["procs"]), (37.5, 412, 9))
        self.assertIn("RAM 412 MB", mt5emu.headline_embedded(p)[0])
        self.state(phase="running", res={"cpu": 5.0, "rss_mb": 200, "procs": 3, "top": "x"})
        p2 = mt5emu.progress_embedded(None, self.d)
        self.assertEqual(p2["res"]["rss_mb"], 200)

    def test_phantom_process_warning_near_limit(self):
        self.state(phase="running", res={"cpu": 5.0, "rss_mb": 200, "procs": 9, "top": "x"})
        t = mt5emu.headline_embedded(mt5emu.progress_embedded(None, self.d))[0]
        self.assertIn("9 tiến trình con", t)
        self.assertNotIn("CẢNH BÁO", t)
        self.state(phase="running", res={"cpu": 5.0, "rss_mb": 200, "procs": mt5emu.PHANTOM_WARN, "top": "x"})
        t = mt5emu.headline_embedded(mt5emu.progress_embedded(None, self.d))[0]
        self.assertIn("CẢNH BÁO", t)
        self.assertIn("Tắt giới hạn tiến trình con", t)

    def test_res_events_do_not_flood_diagnostics(self):
        n0 = len(self.srv.diag)
        for _ in range(30):
            self.srv._sup_event({"kind": "res", "cpu": "1", "rss": "2", "procs": "3", "top": "a"})
        self.assertLessEqual(len(self.srv.diag) - n0, 1)
        self.assertIn("tài nguyên giả lập nhúng: CPU", self.srv.diagnostics_text())

    def test_emu_exit_and_profile_events_make_alerts(self):
        self.srv._sup_event({"kind": "emu_exit", "code": "1", "up": "5", "profile": "lean"})
        self.srv._sup_event({"kind": "profile", "to": "stable", "why": "MT5 chết nhanh"})
        kinds = [a["kind"] for a in self.srv.alerts]
        self.assertIn("emu_exit", kinds)
        self.assertIn("profile", kinds)

    def test_connected_headline_has_cost_and_hides_steps(self):
        p = mt5emu.progress_embedded(self.srv, self.d)
        p.update(connected=True, login=5550123, server="Demo-1", res={"cpu": 12.0, "rss_mb": 300, "procs": 5})
        text, tone = mt5emu.headline_embedded(p)
        self.assertEqual(tone, "ok")
        self.assertIn("5550123", text)
        self.assertIn("CPU 12%", text)


    # ---- log thật v14: tìm bản Wine tải lại Wine NGAY TRONG bước prefix => sự kiện «wine progress» muộn hơn «wine ok»; bước MT5 sau đó lỗi ----
    def test_late_progress_of_earlier_stage_does_not_stay_running_after_later_stage_failed(self):
        for st in ("precheck", "proot", "rootfs", "apt", "box64", "wine", "prefix"):
            self.ev(st, "ok")
        time.sleep(0.02)
        self.ev("wine", "progress", "đã có 485 MB, vẫn đang chạy")               # muộn hơn mọi «ok» ở trên
        self.ev("mt5", "fail", "bộ cài MT5 QUAY VÒNG 625s")
        p = mt5emu.progress_embedded(self.srv, self.d)
        stt = {r[0]: r[2] for r in p["rows"]}
        self.assertEqual(stt["wine"], "ok")                                        # không còn ▶ «Tải Wine»
        self.assertEqual(stt["mt5"], "fail")
        self.assertEqual([r[0] for r in p["rows"] if r[2] == "run"], [])
        self.assertIn("MT5", mt5emu.render(p))

    def test_same_scenario_from_disk_only(self):
        t = int(time.time())
        self.stage_log(("precheck", "ok"), ("apt", "ok"), ("box64", "ok"), ("wine", "ok"), ("prefix", "ok"), ("mt5", "fail"), t=t)
        self.state(stages={"wine": {"state": "progress", "detail": "đã có 485 MB", "t": time.time() + 5}})
        stt = {r[0]: r[2] for r in mt5emu.progress_embedded(None, self.d)["rows"]}
        self.assertEqual((stt["wine"], stt["mt5"]), ("ok", "fail"))

    def test_running_stage_stays_running_when_nothing_after_it_has_finished(self):
        for st in ("precheck", "proot", "rootfs", "apt"):
            self.ev(st, "ok")
        self.ev("box64", "progress", "đang tải")
        self.ev("wine", "start")                                                  # hai bước cùng chạy, chưa bước nào sau đó xong -> không đoán
        stt = {r[0]: r[2] for r in mt5emu.progress_embedded(self.srv, self.d)["rows"]}
        self.assertEqual((stt["box64"], stt["wine"]), ("run", "run"))

    def test_earlier_failure_is_not_hidden_by_inference(self):
        for st in ("precheck", "proot"):
            self.ev(st, "ok")
        self.ev("rootfs", "fail", "hết dung lượng")
        self.ev("apt", "ok")                                                       # bản ghi cũ lẫn vào: lỗi vẫn phải hiện
        stt = {r[0]: r[2] for r in mt5emu.progress_embedded(self.srv, self.d)["rows"]}
        self.assertEqual(stt["rootfs"], "fail")

    # ---- log thật 2026-11-26: cài nền lâu, Android tắt tiến trình giao diện, mở lại thì app dựng lại cầu nối KHÔNG còn mật khẩu (chỉ RAM) ----
    def pw_lost(self):
        return mt5emu.progress_embedded(self.srv, self.d)["pw_lost"]

    def test_pw_lost_when_installing_without_password_and_ea_never_connected(self):
        self.state(phase="installing")
        self.assertTrue(self.pw_lost())
        text, tone = mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))
        self.assertEqual(tone, "wait")
        self.assertIn("Nhập lại thông tin", text)
        self.assertIn("KHÔNG phải làm lại", text, "phải nói rõ phần đã cài không mất")

    def test_pw_not_lost_while_the_app_still_holds_the_password(self):
        self.srv.set_first_login_password("Abcd1234!")
        self.state(phase="installing")
        self.assertFalse(self.pw_lost())
        self.assertNotIn("Nhập lại thông tin", mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))[0])

    def test_pw_not_lost_once_the_ea_has_connected_or_phase_is_running_or_no_server_or_fresh_idle(self):
        self.state(phase="installing")
        self.srv._ever = True                                                      # EA đã từng nối: đã đăng nhập được, mật khẩu không còn cần
        self.assertFalse(self.pw_lost())
        self.srv._ever = False
        self.state(phase="running")
        self.assertFalse(self.pw_lost(), "MT5 đang chạy thì không nhắc mật khẩu")
        self.state(phase="installing")
        self.assertFalse(mt5emu.progress_embedded(None, self.d)["pw_lost"], "chưa có máy chủ cục bộ thì không kết luận được")
        os.remove(em.Layout(self.d).state)
        self.assertFalse(self.pw_lost(), "mới tinh, chưa bắt đầu gì thì không nhắc")

    def test_pw_lost_hint_is_also_shown_on_a_failed_install(self):
        self.state(phase="failed", failed_stage="compile", error="biên dịch lỗi")
        p = mt5emu.progress_embedded(self.srv, self.d)
        self.assertTrue(p["pw_lost"])
        text, tone = mt5emu.headline_embedded(p)
        self.assertEqual(tone, "fail")
        self.assertIn("Nhập lại thông tin", text)

    def test_failed_provision_because_app_port_was_closed_gets_specific_advice(self):
        self.ev("provision", "fail", "Cấp file từ app lỗi: LỖI bridge.set: không nối được app (127.0.0.1:18765); Connection refused")
        self.state(phase="failed", failed_stage="provision", error="x")
        text, tone = mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))
        self.assertEqual(tone, "fail")
        self.assertIn("không mở cổng cục bộ", text)
        self.assertIn("Nhập lại thông tin", text)
        self.assertIn("«Bắt đầu»", text)
        self.assertIn("KHÔNG phải làm lại", text)

    def test_other_provision_failures_keep_the_generic_message(self):
        self.ev("provision", "fail", "Cấp file từ app lỗi: HTTP 403")
        self.state(phase="failed", failed_stage="provision", error="x")
        text, _ = mt5emu.headline_embedded(mt5emu.progress_embedded(self.srv, self.d))
        self.assertNotIn("không mở cổng cục bộ", text)
        self.assertIn("Khởi động lại", text)


class TestSourcesConsistent(unittest.TestCase):
    def test_ea_has_lean_mode(self):
        ea = mt5ea.ea_source()
        for w in ("input bool   InpLean", "void LeanChart()", "void LeanWatch()", "CHART_SHOW, false", "SymbolSelect(s, false)", "TERMINAL_CONNECTED"):
            self.assertIn(w, ea)
        self.assertEqual(ea.count("{"), ea.count("}"))
        self.assertEqual(ea.count("("), ea.count(")"))

    def test_embedded_stage_ids_match_installer_script(self):
        inst = mt5ea.script_source("install_mt5_termux.sh")
        for sid, _ in mt5ea.EMBED_STAGES:
            if sid in ("precheck", "proot", "login"):
                continue                                              # do Python báo
            self.assertIn("stage %s " % sid, inst, sid)

    def test_service_declared_and_entry_exists(self):
        spec = open(os.path.join(HERE, "..", "buildozer.spec"), encoding="utf-8").read()
        self.assertIn("Emu:service_emu.py:foreground:sticky", spec)
        self.assertTrue(os.path.exists(os.path.join(HERE, "..", "service_emu.py")))
        from pyea import android_native
        self.assertEqual(android_native.EMU_SERVICE_NAME, "Emu")
        self.assertNotEqual(android_native.NOTIF_EMU, android_native.NOTIF_RUN)


if __name__ == "__main__":
    unittest.main()


class TestPeReport(unittest.TestCase):
    """embedded.pe_report: mô tả cấu trúc bộ cài mt5setup.exe (chỉ đọc) để lần sau biết bên trong có gì, và có stub syscall Windows trực tiếp hay không."""

    @staticmethod
    def build_pe(text=b"", overlay=b"", machine=0x8664):
        import struct
        dos = bytearray(0x80)
        dos[0:2] = b"MZ"
        struct.pack_into("<I", dos, 0x3C, 0x80)
        coff = struct.pack("<4sHHIIIHH", b"PE\0\0", machine, 2, 0, 0, 0, 0xF0, 0x22)
        opt = bytearray(0xF0)
        struct.pack_into("<H", opt, 0, 0x20B)
        struct.pack_into("<H", opt, 68, 2)
        text = text.ljust(0x200, b"\x90")
        rsrc = (b"MetaQuotes terminal64.exe " * 20)[:0x200].ljust(0x200, b"\0")
        base = 0x80 + len(coff) + len(opt) + 80
        base = (base + 0x1FF) // 0x200 * 0x200
        sec1 = struct.pack("<8sIIIIIIHHI", b".text", len(text), 0x1000, len(text), base, 0, 0, 0, 0, 0x60000020)
        sec2 = struct.pack("<8sIIIIIIHHI", b".rsrc", len(rsrc), 0x2000, len(rsrc), base + len(text), 0, 0, 0, 0, 0x40000040)
        hdr = bytes(dos) + coff + bytes(opt) + sec1 + sec2
        return hdr.ljust(base, b"\0") + text + rsrc + overlay

    def write(self, data):
        d = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(d, ignore_errors=True))
        p = os.path.join(d, "mt5setup.exe")
        open(p, "wb").write(data)
        return p

    def test_reads_headers_sections_overlay_and_signatures(self):
        ov = b"\x00" * 100 + b"7z\xbc\xaf\x27\x1c\x00\x04" + os.urandom(2000) + b"PK\x03\x04" + b"\xfd7zXZ\x00" + b"\x00" * 50
        r = em.pe_report(self.write(self.build_pe(overlay=ov)))
        self.assertIn("PE máy=0x8664 (x64) PE32+ subsystem=2 section=2", r)
        self.assertIn(".text raw=512", r)
        self.assertIn(".rsrc raw=512", r)
        self.assertRegex(r, r"overlay: từ \d+, %d byte" % len(ov))
        for name in ("7z×1", "zip×1", "xz×1"):
            self.assertIn(name, r)
        self.assertIn("MetaQuotes×", r)
        self.assertIn("terminal64.exe×", r)

    def test_detects_direct_syscall_stubs_with_numbers(self):
        import struct
        stub = lambda n: b"\x4c\x8b\xd1\xb8" + struct.pack("<I", n) + b"\x0f\x05\xc3"
        r = em.pe_report(self.write(self.build_pe(text=stub(0x19) + b"\x90" * 8 + stub(0x3C) + stub(0x19))))
        self.assertIn("stub_syscall_trực_tiếp: 3 (số hiệu: 0x19,0x3C)", r)
        r2 = em.pe_report(self.write(self.build_pe(text=b"\x90" * 64)))
        self.assertIn("stub_syscall_trực_tiếp: 0 (số hiệu: không)", r2)

    def test_not_a_pe_missing_and_truncated_never_raise(self):
        self.assertIn("KHÔNG phải PE", em.pe_report(self.write(b"<html>404</html>" * 10)))
        self.assertIn("không có tệp", em.pe_report("/nonexistent/mt5setup.exe"))
        import struct
        bad = bytearray(0x80)
        bad[0:2] = b"MZ"
        struct.pack_into("<I", bad, 0x3C, 0xFFFFF0)                          # e_lfanew trỏ ra ngoài tệp
        self.assertIn("không thấy 'PE", em.pe_report(self.write(bytes(bad))))
        pe = self.build_pe()
        self.assertIn("không phân tích được", em.pe_report(self.write(pe[:0x90])))     # cắt cụt giữa tiêu đề COFF
        self.assertTrue(em.pe_report(self.write(b"")))                       # tệp rỗng

    def test_diagnostics_text_includes_the_report_and_the_apk_line(self):
        d = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(d, ignore_errors=True))
        lo = em.Layout(d)
        os.makedirs(os.path.dirname(lo.setup_exe), exist_ok=True)
        open(lo.setup_exe, "wb").write(self.build_pe())
        t = em.diagnostics_text(d)
        self.assertIn("--- cấu trúc bộ cài (mt5setup.exe", t)
        self.assertIn("PE máy=0x8664", t)

    def test_big_file_is_capped(self):
        p = self.write(self.build_pe(overlay=b"\x00" * 4096))
        r = em.pe_report(p, max_bytes=2048)
        self.assertIn("chỉ đọc 2048 byte đầu", r)
