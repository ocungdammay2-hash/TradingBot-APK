"""Nhật ký lệnh (journal.py): khoá lệnh bền, làm sạch thẻ/ghi chú, lưu/nạp an toàn, thống kê theo thẻ, xuất CSV chống công thức, nối vào tradeinfo/storage/giao diện."""
import csv
import json
import os
import shutil
import sys
import tempfile
import unittest
from dataclasses import dataclass

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from pyea import journal, tradeinfo                                  # noqa: E402


@dataclass
class T:
    id: int
    symbol: str = "BTCUSDT"
    side: str = "buy"
    volume: float = 1.0
    open_price: float = 100.0
    close_price: float = 110.0
    open_time: float = 1_800_000_000.0
    close_time: float = 1_800_000_600.0
    profit: float = 10.0
    reason: str = "TP"
    comment: str = ""
    owner: str = "botA"
    swap: float = 0.0
    fee: float = 0.0


class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.p = os.path.join(self.d, "trade_journal.json")

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)


class TestKeyAndClean(unittest.TestCase):
    def test_key_is_stable_and_ignores_session_local_id(self):
        a, b = T(1), T(999)
        self.assertEqual(journal.trade_key(a), journal.trade_key(b))                         # id sổ app có thể lặp sau «Đặt lại paper»
        self.assertNotEqual(journal.trade_key(a), journal.trade_key(T(1, side="sell")))
        self.assertNotEqual(journal.trade_key(a), journal.trade_key(T(1, close_time=1_800_000_601.0)))
        self.assertNotEqual(journal.trade_key(a), journal.trade_key(T(1, owner="manual")))
        self.assertEqual(journal.trade_key(a), journal.trade_key({"symbol": "btcusdt", "side": "BUY", "open_time": 1_800_000_000.4, "close_time": 1_800_000_600.9, "owner": "botA"}))

    def test_key_survives_garbage(self):
        self.assertIsInstance(journal.trade_key({}), str)
        self.assertIsInstance(journal.trade_key({"open_time": "x", "close_time": None}), str)

    def test_tags_cleaned(self):
        self.assertEqual(journal.clean_tags("FOMO, đúng kế hoạch ; fomo\n trái|xu\"hướng"), ["fomo", "đúng-kế-hoạch", "trái-xu-hướng"])
        self.assertEqual(journal.clean_tags(["A", "a", " ", "", None]), ["a", "none"])
        self.assertEqual(len(journal.clean_tags([str(i) for i in range(20)])), journal.MAX_TAGS)
        self.assertLessEqual(max(len(t) for t in journal.clean_tags(["x" * 100])), journal.MAX_TAG_LEN)
        self.assertEqual(journal.clean_tags(None), [])
        self.assertEqual(journal.clean_tags(",,;;"), [])


class TestJournal(Base):
    def test_set_get_roundtrip_and_persistence(self):
        j = journal.Journal(self.p)
        t = T(1)
        j.set(t, "vào theo kế hoạch\nra sớm", "Đúng-kế-hoạch, scalp", 4)
        e = j.get(T(77))                                                                   # cùng lệnh, id khác
        self.assertEqual((e["note"], e["tags"], e["rating"]), ("vào theo kế hoạch\nra sớm", ["đúng-kế-hoạch", "scalp"], 4))
        k = journal.Journal(self.p)                                                        # mở lại
        self.assertEqual(k.get(t)["tags"], ["đúng-kế-hoạch", "scalp"])
        self.assertEqual(json.load(open(self.p, encoding="utf-8"))["_schema"], 1)
        self.assertFalse(os.path.exists(self.p + ".tmp"))

    def test_empty_entry_deletes_and_unknown_trade_is_blank(self):
        j = journal.Journal(self.p)
        t = T(1)
        j.set(t, "x", "a", 1)
        self.assertEqual(j.count(), 1)
        j.set(t, "   ", "", 0)
        self.assertEqual(j.count(), 0)
        self.assertEqual(j.get(t), {"note": "", "tags": [], "rating": 0, "updated": 0.0})
        j.set(t, "y")
        j.delete(t)
        j.delete(t)                                                                        # xoá lần 2 không lỗi
        self.assertEqual(j.count(), 0)

    def test_limits_and_rating_clamp(self):
        j = journal.Journal(self.p)
        e = j.set(T(1), "n" * 5000, "", 99)
        self.assertEqual((len(e["note"]), e["rating"]), (journal.MAX_NOTE, 5))
        self.assertEqual(j.set(T(1), "x", "", -3)["rating"], 0)
        self.assertEqual(j.set(T(1), "x", "", "abc")["rating"], 0)
        self.assertNotIn("\x00", j.set(T(1), "a\x00b")["note"])

    def test_prune_removes_oldest_updates_first(self):
        clk = [1000.0]
        j = journal.Journal(self.p, clock=lambda: clk[0])
        old = journal.MAX_ENTRIES = 40                                                      # hạ trần để test nhanh (ghi file mỗi lần set)
        self.addCleanup(setattr, journal, "MAX_ENTRIES", 5000)
        for i in range(old + 3):
            clk[0] += 1
            j.set(T(i, open_time=1_800_000_000.0 + i, close_time=1_800_000_100.0 + i), "n%d" % i)
        self.assertEqual(j.count(), old)
        self.assertEqual(j.get(T(0, open_time=1_800_000_000.0, close_time=1_800_000_100.0))["note"], "")       # 3 lệnh cũ nhất bị loại
        self.assertEqual(j.get(T(0, open_time=1_800_000_000.0 + old + 2, close_time=1_800_000_100.0 + old + 2))["note"], "n%d" % (old + 2))

    def test_corrupt_file_is_kept_aside_not_overwritten(self):
        open(self.p, "w", encoding="utf-8").write("{hỏng")
        j = journal.Journal(self.p, clock=lambda: 5.0)
        self.assertEqual(j.count(), 0)
        self.assertIn("bị hỏng", j.warning)
        self.assertTrue(any(n.startswith("trade_journal.json.bad-") for n in os.listdir(self.d)))
        j.set(T(1), "ok")                                                                  # dùng tiếp bình thường
        self.assertEqual(journal.Journal(self.p).get(T(1))["note"], "ok")

    def test_newer_schema_is_not_destroyed(self):
        json.dump({"_schema": 9, "entries": {"k": {"note": "x"}}}, open(self.p, "w"))
        j = journal.Journal(self.p)
        self.assertEqual(j.count(), 0)
        self.assertTrue(any(".bad-" in n for n in os.listdir(self.d)))

    def test_hostile_entries_are_sanitised_on_load(self):
        json.dump({"_schema": 1, "entries": {"a|buy|1|2|": {"note": "z" * 9999, "tags": ["X" * 80, "b,c"], "rating": 77, "updated": "x"}, "b": 5, "c": None}}, open(self.p, "w"))
        j = journal.Journal(self.p)
        e = j.entries["a|buy|1|2|"]
        self.assertEqual((len(e["note"]), e["rating"], e["tags"][1]), (journal.MAX_NOTE, 5, "b-c"))
        self.assertEqual(j.count(), 1)

    def test_in_memory_when_no_path(self):
        j = journal.Journal(None)
        j.set(T(1), "x")
        self.assertEqual(j.get(T(1))["note"], "x")

    def test_unwritable_location_raises_oserror_for_the_ui_to_report(self):
        j = journal.Journal(os.path.join(self.d, "no", "such", "dir", "j.json"))
        with self.assertRaises(OSError):
            j.set(T(1), "x")


class TestTagStats(Base):
    def test_per_tag_pnl_worst_first_and_untagged_group(self):
        j = journal.Journal(self.p)
        ts = [T(1, profit=-30.0, open_time=1.0, close_time=2.0), T(2, profit=-20.0, open_time=3.0, close_time=4.0), T(3, profit=50.0, open_time=5.0, close_time=6.0),
              T(4, profit=5.0, open_time=7.0, close_time=8.0), T(5, profit=-1.0, open_time=9.0, close_time=10.0)]
        j.set(ts[0], "", "fomo")
        j.set(ts[1], "", "fomo, scalp")
        j.set(ts[2], "", "plan")
        j.set(ts[3], "", "plan")
        rows = j.tag_stats(ts)
        by = {r["tag"]: r for r in rows}
        self.assertEqual(rows[0]["tag"], "fomo")                                           # thẻ làm mất tiền nhiều nhất lên đầu
        self.assertEqual((by["fomo"]["n"], by["fomo"]["pnl"], by["fomo"]["wins"], by["fomo"]["worst"]), (2, -50.0, 0, -30.0))
        self.assertEqual((by["plan"]["n"], by["plan"]["pnl"], by["plan"]["win_rate"]), (2, 55.0, 100.0))
        self.assertEqual((by["scalp"]["n"], by["scalp"]["pnl"]), (1, -20.0))               # lệnh nhiều thẻ tính vào từng thẻ
        self.assertEqual((by["(chưa gắn thẻ)"]["n"], by["(chưa gắn thẻ)"]["pnl"]), (1, -1.0))
        txt = j.tag_stats_text(ts)
        self.assertIn("fomo", txt)
        self.assertIn("mẫu nhỏ", txt)
        self.assertEqual(j.tag_stats_text([]), "Chưa có lệnh nào.")

    def test_bad_profit_values_do_not_crash(self):
        j = journal.Journal(None)
        rows = j.tag_stats([{"symbol": "X", "side": "buy", "profit": "abc"}, {"symbol": "X", "side": "buy", "profit": None, "open_time": 5}])
        self.assertEqual(rows[0]["pnl"], 0.0)


class TestCsv(Base):
    def read(self, path):
        with open(path, newline="", encoding="utf-8-sig") as f:
            return list(csv.reader(f))

    def test_export_columns_and_content_with_notes(self):
        j = journal.Journal(self.p)
        t1, t2 = T(1), T(2, symbol="ETHUSDT", open_time=1_800_001_000.0, close_time=1_800_001_900.0, profit=-4.5)
        j.set(t1, "ghi chú, có dấu phẩy\nvà xuống dòng", "fomo, plan", 3)
        out = os.path.join(self.d, "sub", "j.csv")
        n = j.export_csv([t1, t2], out, fmt_time=lambda ts: "T%d" % ts)
        self.assertEqual(n, 2)
        rows = self.read(out)
        self.assertEqual(tuple(rows[0]), journal.Journal.COLUMNS)
        r1 = dict(zip(rows[0], rows[1]))
        self.assertEqual((r1["symbol"], r1["profit"], r1["open_time"], r1["rating"], r1["tags"]), ("BTCUSDT", "10.0", "T1800000000", "3", "fomo,plan"))
        self.assertEqual(r1["note"], "ghi chú, có dấu phẩy\nvà xuống dòng")                # csv đọc lại nguyên vẹn
        r2 = dict(zip(rows[0], rows[2]))
        self.assertEqual((r2["symbol"], r2["note"], r2["rating"]), ("ETHUSDT", "", ""))
        self.assertFalse(os.path.exists(out + ".tmp"))
        self.assertTrue(open(out, "rb").read().startswith(b"\xef\xbb\xbf"))                  # BOM cho Excel

    def test_formula_injection_is_defused_but_numbers_are_untouched(self):
        j = journal.Journal(self.p)
        t = T(1, comment='=HYPERLINK("http://evil","x")', profit=-12.5, reason="+cmd|' /C calc'!A0")
        j.set(t, "@SUM(1+1)", "-tag", 0)
        out = os.path.join(self.d, "j.csv")
        j.export_csv([t], out)
        r = dict(zip(*self.read(out)))
        self.assertTrue(r["comment"].startswith("'="))
        self.assertTrue(r["reason"].startswith("'+"))
        self.assertTrue(r["note"].startswith("'@"))
        self.assertEqual(r["profit"], "-12.5")                                               # số âm KHÔNG bị thêm dấu '
        for v in ("=1+1", "+1", "-1", "@a", "\tx", "\rx"):
            self.assertTrue(journal.safe_cell(v).startswith("'"), v)
        for v in ("abc", "", None, 5, -5.5, 0):
            self.assertFalse(str(journal.safe_cell(v) or "").startswith("'"), v)

    def test_empty_export_has_header_only(self):
        out = os.path.join(self.d, "e.csv")
        self.assertEqual(journal.Journal(None).export_csv([], out), 0)
        self.assertEqual(len(self.read(out)), 1)


class TestWiring(Base):
    def test_tradeinfo_gives_journal_ref_only_for_closed(self):
        t = T(5)
        info = tradeinfo.build("trade", t)
        ref = info["journal_ref"]
        self.assertEqual(journal.trade_key(ref), journal.trade_key(t))                       # khoá từ info == khoá từ Trade -> nhật ký tìm lại đúng lệnh
        row = {"symbol": "EURUSD", "side": "buy", "volume": 1.0, "price": 1.1, "price2": 1.2, "time": 1_800_000_500.0, "open_time": 1_800_000_000.0, "profit": 5.0, "id": 9}
        self.assertIsNotNone(tradeinfo.build("row", row)["journal_ref"])
        open_row = {"symbol": "EURUSD", "side": "buy", "volume": 1.0, "price": 1.1, "time": 1_800_000_000.0, "profit": 0.0, "id": 9}
        self.assertIsNone(tradeinfo.build("row", open_row)["journal_ref"])

        class P:
            symbol, side, volume, open_price, open_time, profit, swap, fee, owner, ref, comment, sl, tp, id = "X", "buy", 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, "", "", "", 0.0, 0.0, 3
        self.assertIsNone(tradeinfo.build("position", P())["journal_ref"])

    def test_storage_path_and_backup_membership(self):
        from pyea.storage import Store
        s = Store(self.d)
        self.assertEqual(s.journal_path, os.path.join(self.d, "trade_journal.json"))
        self.assertIn("trade_journal.json", Store._BACKUP_FILES)
        journal.Journal(s.journal_path).set(T(1), "bài học", "plan", 5)
        zp = s.export_backup()
        import zipfile
        with zipfile.ZipFile(zp) as z:
            self.assertIn("trade_journal.json", z.namelist())
        d2 = tempfile.mkdtemp()
        try:
            s2 = Store(d2)
            s2.import_backup(zp)
            self.assertEqual(journal.Journal(s2.journal_path).get(T(1))["note"], "bài học")      # khôi phục lại được
        finally:
            shutil.rmtree(d2, ignore_errors=True)

    def test_ui_modules_wired(self):
        root = os.path.join(HERE, "..", "pyea")
        ui = open(os.path.join(root, "ui.py"), encoding="utf-8").read()
        tv = open(os.path.join(root, "ui_tradeview.py"), encoding="utf-8").read()
        self.assertIn("ui_journal.show_stats", ui)
        self.assertIn("ui_journal.export", ui)
        self.assertIn("def journal(self)", ui)
        self.assertIn("ui_journal.show_entry", tv)
        compile(open(os.path.join(root, "ui_journal.py"), encoding="utf-8").read(), "ui_journal.py", "exec")


if __name__ == "__main__":
    unittest.main()
