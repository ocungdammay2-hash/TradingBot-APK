"""Khoá ký APK bền qua các lần build (tools/ci_signing_key.sh + bước tương ứng trong build-apk.yml).

Người dùng phải GỠ app (mất cả Ubuntu + Wine + MT5 đã cài, 20+ phút) mỗi khi khoá ký đổi. Cách cũ chỉ dựa vào cache Actions mà cache chỉ được lưu khi CẢ job thành công,
chỉ thấy được từ cùng nhánh/nhánh mặc định và bị xoá sau 7 ngày không dùng. Script mới giữ khoá trong một nhánh của repo (chỉ repo RIÊNG TƯ). Test này chạy script THẬT với
repo git THẬT (kho trống cục bộ làm «GitHub») và keytool THẬT; KHÔNG chạy được trên GitHub Actions: quyền ghi thật của GITHUB_TOKEN chưa kiểm."""
import os
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPT = os.path.join(ROOT, "tools", "ci_signing_key.sh")
HAVE = all(shutil.which(x) for x in ("git", "keytool", "bash", "base64"))


def sh(*args, **kw):
    return subprocess.run(args, capture_output=True, text=True, timeout=120, **kw)


@unittest.skipUnless(HAVE, "cần git, keytool, bash, base64")
class TestSigningKeyBranch(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(prefix="pyea_ks_")
        self.addCleanup(shutil.rmtree, self.d, True)
        self.bare = os.path.join(self.d, "origin.git")
        sh("git", "init", "-q", "--bare", self.bare)
        self.remote = "file://" + self.bare
        self.out = os.path.join(self.d, "gh_output")
        open(self.out, "w").close()

    def keystore(self, name, cn="PyEA Debug"):
        p = os.path.join(self.d, name)
        r = sh("keytool", "-genkeypair", "-keystore", p, "-storepass", "android", "-keypass", "android", "-alias", "androiddebugkey",
               "-keyalg", "RSA", "-keysize", "2048", "-validity", "36500", "-dname", "CN=%s,O=PyEA,C=VN" % cn)
        self.assertEqual(r.returncode, 0, r.stderr)
        return p

    def run_script(self, mode, ks, private="true", remote=None, **env):
        e = dict(os.environ, KS_REMOTE=remote or self.remote, GITHUB_OUTPUT=self.out, REPO_PRIVATE=private, HOME=self.d)
        e.pop("GH_TOKEN", None)
        e.update(env)
        return subprocess.run(["bash", SCRIPT, mode, ks], capture_output=True, text=True, env=e, timeout=120)

    def restored(self):
        vals = re.findall(r"^restored=(\w+)$", open(self.out).read(), re.M)
        return vals[-1] if vals else None

    def branch_blob(self, branch="pyea-signing-key"):
        r = sh("git", "--git-dir", self.bare, "show", "%s:debug.keystore.b64" % branch)
        return r.stdout.strip() if r.returncode == 0 else None

    def commits(self, branch="pyea-signing-key"):
        r = sh("git", "--git-dir", self.bare, "rev-list", "--count", branch)
        return int(r.stdout.strip()) if r.returncode == 0 else 0

    def test_first_build_saves_the_key_and_the_next_build_gets_the_very_same_file_back(self):
        ks = self.keystore("a.keystore")
        r = self.run_script("restore", os.path.join(self.d, "got0.keystore"))
        self.assertEqual((r.returncode, self.restored()), (0, "false"), r.stdout + r.stderr)
        r = self.run_script("save", ks)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("Đã ghi khoá ký", r.stdout)
        self.assertEqual(self.commits(), 1)
        # «máy mới» của lần build sau: thư mục khác, không cache nào
        got = os.path.join(self.d, "new_runner", ".android", "debug.keystore")
        r = self.run_script("restore", got)
        self.assertEqual((r.returncode, self.restored()), (0, "true"), r.stdout + r.stderr)
        self.assertEqual(open(got, "rb").read(), open(ks, "rb").read(), "phải GIỐNG HỆT từng byte (khác một byte = khác chữ ký = không cài đè được)")
        self.assertEqual(sh("keytool", "-list", "-keystore", got, "-storepass", "android", "-alias", "androiddebugkey").returncode, 0)

    def test_saving_the_same_key_again_makes_no_new_commit(self):
        ks = self.keystore("a.keystore")
        self.run_script("save", ks)
        r = self.run_script("save", ks)
        self.assertEqual(r.returncode, 0)
        self.assertIn("đã giữ đúng khoá này", r.stdout)
        self.assertEqual(self.commits(), 1)

    def test_a_different_key_never_overwrites_the_one_that_holds_the_installed_apps(self):
        a = self.keystore("a.keystore", "Cu")
        b = self.keystore("b.keystore", "Moi")
        self.run_script("save", a)
        before = self.branch_blob()
        r = self.run_script("save", b)
        self.assertEqual(r.returncode, 0)
        self.assertIn("không ghi đè", r.stdout)
        self.assertEqual(self.branch_blob(), before)
        self.assertEqual(self.commits(), 1)

    def test_public_or_unknown_repo_never_reads_or_writes_the_key(self):
        ks = self.keystore("a.keystore")
        for private in ("false", "", "False"):
            r = self.run_script("save", ks, private=private)
            self.assertEqual(r.returncode, 0)
            self.assertIn("PYEA_KEYSTORE_B64", r.stdout, "phải nhắc cách chốt khoá vĩnh viễn")
            self.assertIsNone(self.branch_blob(), "repo công khai: KHÔNG được đưa khoá lên")
        # có khoá sẵn (do lúc trước repo còn riêng tư) mà nay công khai: cũng KHÔNG đọc
        self.run_script("save", ks)
        got = os.path.join(self.d, "g.keystore")
        r = self.run_script("restore", got, private="false")
        self.assertEqual((r.returncode, self.restored()), (0, "false"))
        self.assertFalse(os.path.exists(got))

    def test_garbage_in_the_branch_is_ignored_not_used_and_never_breaks_the_build(self):
        w = os.path.join(self.d, "w")
        sh("git", "init", "-q", w)
        sh("git", "-C", w, "checkout", "-q", "-b", "pyea-signing-key")
        open(os.path.join(w, "debug.keystore.b64"), "w").write("khong-phai-base64-hop-le!!\n")
        sh("git", "-C", w, "add", ".")
        sh("git", "-C", w, "-c", "user.name=t", "-c", "user.email=t@t", "commit", "-q", "-m", "x")
        sh("git", "-C", w, "push", "-q", self.remote, "pyea-signing-key")
        got = os.path.join(self.d, "g.keystore")
        r = self.run_script("restore", got)
        self.assertEqual((r.returncode, self.restored()), (0, "false"), r.stdout + r.stderr)
        self.assertFalse(os.path.exists(got))
        # và lưu khoá mới thì KHÔNG đè lên nhánh đang có (dù nội dung hỏng): người dùng tự quyết
        r = self.run_script("save", self.keystore("a.keystore"))
        self.assertEqual(r.returncode, 0)

    def test_unreachable_remote_is_only_a_warning(self):
        ks = self.keystore("a.keystore")
        bad = "file://" + os.path.join(self.d, "khong-ton-tai.git")
        r = self.run_script("restore", os.path.join(self.d, "g.keystore"), remote=bad)
        self.assertEqual((r.returncode, self.restored()), (0, "false"))
        r = self.run_script("save", ks, remote=bad)
        self.assertEqual(r.returncode, 0)
        self.assertIn("::warning::", r.stdout)

    def test_invalid_keystore_file_is_not_saved(self):
        junk = os.path.join(self.d, "junk.keystore")
        open(junk, "w").write("khong phai keystore")
        r = self.run_script("save", junk)
        self.assertEqual(r.returncode, 0)
        self.assertIn("không hợp lệ", r.stdout)
        self.assertIsNone(self.branch_blob())

    def test_token_is_never_printed(self):
        ks = self.keystore("a.keystore")
        r = self.run_script("save", ks, GH_TOKEN="ghs_SECRETSECRETSECRET")
        self.assertNotIn("SECRETSECRET", r.stdout + r.stderr)
        src = open(SCRIPT, encoding="utf-8").read()
        for line in src.splitlines():
            line = re.sub(r"\s#.*$", "", line)            # bỏ chú thích cuối dòng
            if "GH_TOKEN" in line and not line.lstrip().startswith("#"):
                self.assertTrue("http.extraheader" in line or '[ -n "${GH_TOKEN:-}" ]' in line, "token chỉ được dùng để dựng header đăng nhập: " + line)
        self.assertNotRegex(src, r"echo[^\n]*\$\{?GH_TOKEN")

    def test_script_has_no_key_material_and_exits_2_without_mode(self):
        src = open(SCRIPT, encoding="utf-8").read()
        self.assertNotRegex(src, r"(?i)BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY")
        r = subprocess.run(["bash", SCRIPT], capture_output=True, text=True)
        self.assertEqual(r.returncode, 2)


if __name__ == "__main__":
    unittest.main()
