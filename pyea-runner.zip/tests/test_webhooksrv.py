"""Máy chủ webhook TradingView chạy trong app (pyea/webhooksrv.py): giao thức, giới hạn, khoá dò secret, vòng đời, nối vào phiên giao dịch.
Dùng ổ cắm thật trên 127.0.0.1 (cổng do hệ điều hành chọn)."""
import http.client
import json
import os
import socket
import sys
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub                                                 # noqa: E402
kivy_stub.install()

from pyea import webhook, webhooksrv                             # noqa: E402
from pyea.engine import Account                                  # noqa: E402
from pyea.keystore import SECRET_SETTING_KEYS                    # noqa: E402
from pyea.sdk import Tick                                        # noqa: E402
from pyea.settings import GLOBAL_INPUTS, clean_settings, default_settings   # noqa: E402
from test_recon_cache import make as make_paper                  # noqa: E402

SECRET = "S3cret-Value-0123456789"


def body(**kw):
    d = {"secret": SECRET, "id": "a1", "action": "buy", "symbol": "BTCUSDT", "volume": 1}
    d.update(kw)
    return json.dumps({k: v for k, v in d.items() if v is not None})


class Srv:
    """Máy chủ thử + bộ ghi executor/log/alarm."""

    def __init__(self, **kw):
        self.calls, self.logs, self.alarms, self.evt = [], [], [], threading.Event()

        def ex(o):
            self.calls.append(o)
            self.evt.set()
            return {"ok": True}
        ck = {k: kw.pop(k) for k in list(kw) if k in ("allowed_ips", "allowed_symbols", "max_volume", "dry_run", "symbol_map")}
        self.core = webhook.WebhookCore(ex, SECRET, async_exec=True, log=lambda *a: self.logs.append(a[0]), **ck)
        kw.setdefault("log", lambda *a: self.logs.append(a[0]))
        kw.setdefault("alarm", lambda t, x: self.alarms.append((t, x)))
        self.srv = webhooksrv.WebhookServer(self.core, "127.0.0.1", 0, **kw)
        self.port = self.srv.start()

    def post(self, b=None, headers=None, path=webhooksrv.PATH, method="POST"):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            c.request(method, path, body=(b if b is not None else body()), headers=headers or {})
            r = c.getresponse()
            return r.status, json.loads(r.read().decode() or "{}")
        finally:
            c.close()

    def raw(self, data, wait=2.0):
        """Gửi byte thô, trả toàn bộ phản hồi (bytes) tới khi máy chủ đóng hoặc hết `wait` giây."""
        s = socket.create_connection(("127.0.0.1", self.port), timeout=wait)
        try:
            s.sendall(data)
            out = b""
            while True:
                try:
                    ch = s.recv(65536)
                except socket.timeout:
                    break
                if not ch:
                    break
                out += ch
            return out
        finally:
            s.close()

    def close(self):
        self.srv.stop()


class Base(unittest.TestCase):
    def mk(self, **kw):
        s = Srv(**kw)
        self.addCleanup(s.close)
        return s


class TestHelpers(unittest.TestCase):
    def test_parse_map_and_list(self):
        self.assertEqual(webhooksrv.parse_map("BINANCE:BTCUSDT=BTCUSD, XAUUSD=GOLD;bad;=x;y="), {"BINANCE:BTCUSDT": "BTCUSD", "XAUUSD": "GOLD"})
        self.assertEqual(webhooksrv.split_list("a, b;c\nd,,"), ["a", "b", "c", "d"])
        self.assertEqual(webhooksrv.split_list(None), [])

    def test_parse_ips(self):
        ips, bad = webhooksrv.parse_ips("tradingview, 1.2.3.4, 1.2.3.4, nope, 999.1.1.1")
        self.assertEqual(ips, list(webhook.TV_IPS) + ["1.2.3.4"])
        self.assertEqual(bad, ["nope", "999.1.1.1"])
        self.assertEqual(webhooksrv.parse_ips(""), ([], []))

    def test_lockout_threshold_expiry_and_bound(self):
        t = [1000.0]
        lk = webhooksrv.Lockout(limit=3, window=60.0, lock_s=100.0, clock=lambda: t[0], max_ips=4)
        self.assertFalse(lk.fail("a")); self.assertFalse(lk.fail("a"))
        self.assertEqual(lk.blocked("a"), 0.0)
        self.assertTrue(lk.fail("a"))                                # lần thứ 3 kích hoạt
        self.assertAlmostEqual(lk.blocked("a"), 100.0)
        self.assertFalse(lk.fail("a"))                               # đang khoá: không kích hoạt lại / không kéo dài vô hạn
        self.assertEqual(lk.blocked("b"), 0.0)
        t[0] += 101
        self.assertEqual(lk.blocked("a"), 0.0)                       # hết hạn
        lk.fail("c"); t[0] += 61; lk.fail("c"); lk.fail("c")         # lần sai cũ ngoài cửa sổ không cộng dồn
        self.assertEqual(lk.blocked("c"), 0.0)
        for i in range(50):                                          # kẻ giả hàng loạt IP không làm phình bộ nhớ
            lk.fail("ip%d" % i)
        self.assertLessEqual(len(lk._fails), 4 + 1)


class TestProtocol(Base):
    def test_valid_post_dry_run_does_not_execute(self):
        s = self.mk(dry_run=True)
        st, r = s.post()
        self.assertEqual(st, 200)
        self.assertTrue(r["ok"] and r["dry_run"])
        time.sleep(0.2)
        self.assertEqual(s.calls, [])
        self.assertTrue(any("CHỈ KIỂM TRA" in x for x in s.logs))

    def test_valid_post_executes_async_and_returns_fast(self):
        s = self.mk()
        t0 = time.monotonic()
        st, r = s.post()
        self.assertLess(time.monotonic() - t0, 2.5)                  # TradingView chờ tối đa 3 giây
        self.assertEqual(st, 200)
        self.assertTrue(r["accepted"])
        self.assertTrue(s.evt.wait(2.0))
        self.assertEqual(s.calls[0]["symbol"], "BTCUSDT")
        self.assertEqual(s.calls[0]["action"], "buy")

    def test_duplicate_id_runs_once(self):
        s = self.mk()
        s.post(); self.assertTrue(s.evt.wait(2.0))
        st, r = s.post()
        self.assertTrue(r.get("duplicate"))
        time.sleep(0.2)
        self.assertEqual(len(s.calls), 1)

    def test_only_post_on_exact_path(self):
        s = self.mk()
        for m in ("GET", "PUT", "DELETE"):
            self.assertEqual(s.post(method=m)[0], 405, m)
        self.assertEqual(s.post(path="/")[0], 404)
        self.assertEqual(s.post(path=webhooksrv.PATH + "/x")[0], 404)
        self.assertEqual(s.post(path=webhooksrv.PATH + "?a=1")[0], 200)     # chuỗi truy vấn được bỏ qua, đường dẫn vẫn phải đúng
        self.assertEqual(s.calls, [] if not s.evt.wait(0.3) else s.calls)

    def test_content_length_rules(self):
        s = self.mk()
        hdr = b"POST %s HTTP/1.0\r\n" % webhooksrv.PATH.encode()
        self.assertIn(b" 411 ", s.raw(hdr + b"\r\n").split(b"\r\n")[0] + b" ")                      # thiếu Content-Length
        self.assertIn(b" 411 ", s.raw(hdr + b"Transfer-Encoding: chunked\r\n\r\n0\r\n\r\n").split(b"\r\n")[0] + b" ")
        self.assertIn(b" 411 ", s.raw(hdr + b"Transfer-Encoding: chunked\r\nContent-Length: 2\r\n\r\n{}").split(b"\r\n")[0] + b" ")   # cả hai tiêu đề: mơ hồ -> từ chối
        self.assertIn(b" 400 ", s.raw(hdr + b"Content-Length: abc\r\n\r\n").split(b"\r\n")[0] + b" ")
        self.assertIn(b" 400 ", s.raw(hdr + b"Content-Length: 0\r\n\r\n").split(b"\r\n")[0] + b" ")
        self.assertIn(b" 400 ", s.raw(hdr + b"Content-Length: -5\r\n\r\n").split(b"\r\n")[0] + b" ")
        t0 = time.monotonic()
        out = s.raw(hdr + b"Content-Length: 5000\r\n\r\n", wait=3.0)        # khai 5000 byte mà KHÔNG gửi thân: phải bị từ chối ngay, không chờ đọc
        self.assertIn(b" 413 ", out.split(b"\r\n")[0] + b" ")
        self.assertLess(time.monotonic() - t0, 1.5)
        self.assertEqual(s.calls, [])

    def test_body_exactly_limit_and_oversize_json(self):
        s = self.mk()
        big = body(comment="x" * 10)
        pad = json.dumps({"secret": SECRET, "id": "z", "action": "buy", "symbol": "BTCUSDT", "volume": 1, "comment": "y" * 5000})
        self.assertGreater(len(pad), webhooksrv.MAX_BODY)
        self.assertEqual(s.post(pad)[0], 413)
        self.assertEqual(s.post(big)[0], 200)

    def test_truncated_body_gets_408_and_nothing_runs(self):
        s = self.mk(total_timeout=1.0)
        out = s.raw(b"POST %s HTTP/1.0\r\nContent-Length: 100\r\n\r\n{\"secret\":" % webhooksrv.PATH.encode(), wait=3.0)
        self.assertTrue(out == b"" or b" 408 " in out.split(b"\r\n")[0] + b" ")
        self.assertEqual(s.calls, [])

    def test_bad_json_and_bad_action(self):
        s = self.mk()
        self.assertEqual(s.post("not json")[0], 400)
        self.assertEqual(s.post(body(action="explode"))[0], 400)
        self.assertEqual(s.post(body(volume=-1))[0], 400)
        self.assertEqual(s.calls, [])

    def test_symbol_and_volume_limits(self):
        s = self.mk(allowed_symbols=["BTCUSDT"], max_volume=2)
        self.assertEqual(s.post(body(symbol="ETHUSDT", id="e"))[1]["code"], "SYMBOL_DENIED")
        self.assertEqual(s.post(body(volume=3, id="v"))[1]["code"], "VOLUME_DENIED")
        self.assertEqual(s.post(body(volume=2, id="ok"))[0], 200)

    def test_response_and_logs_never_contain_secret_or_body(self):
        s = self.mk()
        for b in (body(id="r1", comment="HIDDEN-COMMENT-XYZ"), body(secret="wrong-wrong-wrong-1", id="r2"), "garbage-" + SECRET):
            st, r = s.post(b)
            self.assertNotIn(SECRET, json.dumps(r))
            self.assertNotIn("wrong-wrong", json.dumps(r))
        time.sleep(0.3)
        blob = "\n".join(s.logs) + json.dumps(s.srv.stats())
        self.assertNotIn(SECRET, blob)
        self.assertNotIn("wrong-wrong", blob)
        self.assertNotIn("HIDDEN-COMMENT", blob)


class TestAuthDefence(Base):
    def test_lockout_per_ip_with_trusted_proxy(self):
        s = self.mk(trust_proxy=True, lockout=webhooksrv.Lockout(limit=3, window=60, lock_s=60))
        self.assertTrue(s.srv.lockout_active)
        bad = body(secret="wrong-wrong-wrong-1")
        for _ in range(3):
            self.assertEqual(s.post(bad, {"X-Forwarded-For": "6.6.6.6"})[1]["code"], "BAD_SECRET")
        st, r = s.post(body(id="v1"), {"X-Forwarded-For": "6.6.6.6"})
        self.assertEqual((st, r["code"]), (429, "LOCKED"))           # kẻ dò bị khoá kể cả khi lần này đúng secret
        st, r = s.post(body(id="v2"), {"X-Forwarded-For": "7.7.7.7"})
        self.assertEqual(st, 200)                                    # người khác không bị ảnh hưởng
        self.assertTrue(any("KHOÁ 6.6.6.6" in x for x in s.logs))
        self.assertEqual(s.srv.stats()["locked_ips"], 1)

    def test_no_lockout_on_loopback_without_proxy_so_attacker_cannot_block_real_alerts(self):
        s = self.mk(attack_threshold=5)
        self.assertFalse(s.srv.lockout_active)
        for i in range(12):
            self.assertEqual(s.post(body(secret="wrong-wrong-wrong-1", id="b%d" % i))[0], 401)
        st, r = s.post(body(id="real"))
        self.assertEqual(st, 200)                                    # tín hiệu thật VẪN vào được
        self.assertTrue(r["accepted"])
        self.assertEqual(len(s.alarms), 1)                           # nhưng chủ máy được báo (một lần, không dồn dập)
        self.assertIn("secret", s.alarms[0][1])

    def test_config_errors_do_not_count_towards_lockout(self):
        s = self.mk(trust_proxy=True, allowed_symbols=["BTCUSDT"], lockout=webhooksrv.Lockout(limit=3, window=60, lock_s=60))
        h = {"X-Forwarded-For": "8.8.8.8"}
        for i in range(6):                                           # alert cấu hình sai (đúng secret) lặp lại: không khoá TradingView
            self.assertEqual(s.post(body(symbol="ETHUSDT", id="c%d" % i), h)[1]["code"], "SYMBOL_DENIED")
        self.assertEqual(s.post(body(id="fine"), h)[0], 200)

    def test_ip_allow_list_with_proxy_header(self):
        s = self.mk(trust_proxy=True, allowed_ips=["52.89.214.238"])
        self.assertEqual(s.post(body(id="i1"), {"X-Forwarded-For": "52.89.214.238"})[0], 200)
        self.assertEqual(s.post(body(id="i2"), {"X-Forwarded-For": "1.1.1.1"})[1]["code"], "IP_DENIED")
        self.assertEqual(s.post(body(id="i3"))[1]["code"], "IP_DENIED")      # không có tiêu đề: IP ổ cắm 127.0.0.1 không nằm trong danh sách

    def test_xff_rightmost_wins_and_spoof_ignored(self):
        s = self.mk(trust_proxy=True, allowed_ips=["52.89.214.238"])
        # kẻ xấu tự điền IP hợp lệ ở đầu danh sách; proxy của bạn nối IP thật vào CUỐI -> dùng mục cuối
        self.assertEqual(s.post(body(id="x1"), {"X-Forwarded-For": "52.89.214.238, 6.6.6.6"})[1]["code"], "IP_DENIED")
        self.assertEqual(s.post(body(id="x2"), {"X-Forwarded-For": "6.6.6.6, 52.89.214.238"})[0], 200)
        self.assertEqual(s.post(body(id="x3"), {"X-Forwarded-For": "52.89.214.238:443"})[0], 200)     # có cổng
        self.assertEqual(s.post(body(id="x4"), {"X-Forwarded-For": "not-an-ip"})[1]["code"], "IP_DENIED")

    def test_xff_ignored_when_not_trusted(self):
        s = self.mk(allowed_ips=["52.89.214.238"])
        self.assertEqual(s.post(body(id="n1"), {"X-Forwarded-For": "52.89.214.238"})[1]["code"], "IP_DENIED")


class TestResourceLimits(Base):
    def test_slow_headers_are_cut_by_total_deadline(self):
        s = self.mk(total_timeout=0.8, timeout=5.0)
        c = socket.create_connection(("127.0.0.1", s.port), timeout=5)
        try:
            t0 = time.monotonic()
            closed = False
            for ch in b"POST /v1/webhook/tradingview HTTP/1.0\r\nX-A: ":
                try:
                    c.sendall(bytes([ch]))
                except OSError:
                    closed = True
                    break
                time.sleep(0.12)                                     # nhỏ giọt từng byte: tổng thời gian vượt hạn chót
                if time.monotonic() - t0 > 4:
                    break
            if not closed:
                c.settimeout(2.0)
                try:
                    closed = c.recv(10) == b""
                except OSError:
                    closed = True
            self.assertTrue(closed)
            self.assertLess(time.monotonic() - t0, 4.0)
        finally:
            c.close()

    def test_connection_cap_returns_503_then_recovers(self):
        s = self.mk(max_conns=2, total_timeout=30.0, timeout=30.0)
        idle = [socket.create_connection(("127.0.0.1", s.port), timeout=5) for _ in range(2)]
        try:
            time.sleep(0.3)
            out = s.raw(b"POST %s HTTP/1.0\r\nContent-Length: 2\r\n\r\n{}" % webhooksrv.PATH.encode())
            self.assertIn(b" 503 ", out.split(b"\r\n")[0] + b" ")
            self.assertGreaterEqual(s.srv.stats()["busy"], 1)
        finally:
            for c in idle:
                c.close()
        for _ in range(40):                                          # các kết nối rảnh đã đóng -> chỗ trống lại
            time.sleep(0.1)
            try:
                if s.post(body(id="after"))[0] == 200:
                    return
            except OSError:
                pass
        self.fail("không phục hồi sau khi giải phóng kết nối")


class TestLifecycle(unittest.TestCase):
    def test_start_stop_and_port_reuse(self):
        s = Srv()
        p = s.port
        self.assertTrue(s.srv.running)
        self.assertEqual(s.srv.start(), p)                           # gọi lại không mở cổng thứ hai
        s.close()
        self.assertFalse(s.srv.running)
        with self.assertRaises(OSError):
            socket.create_connection(("127.0.0.1", p), timeout=1)
        s.srv.stop()                                                 # dừng hai lần không lỗi
        s2 = webhooksrv.WebhookServer(webhook.WebhookCore(lambda o: {}, SECRET), "127.0.0.1", p)
        s2.start()                                                   # cổng cũ dùng lại được ngay
        s2.stop()

    def test_port_in_use_raises_oserror(self):
        a = Srv()
        try:
            b = webhooksrv.WebhookServer(webhook.WebhookCore(lambda o: {}, SECRET), "127.0.0.1", a.port)
            with self.assertRaises(OSError):
                b.start()
        finally:
            a.close()


def paper_session(**over):
    base = dict(mode="paper", exchange="binance_futures", initial_balance=100000.0, leverage=1.0, webhook_secret=SECRET, webhook_enabled=True,
                webhook_dry_run=False, webhook_max_volume=5.0)
    base.update(over)
    s = make_paper(**base)
    s.sync = False
    s.account = Account(base["initial_balance"], 0.0, 1.0)
    s.watch = ["BTCUSDT"]
    s.process_tick(Tick("BTCUSDT", time.time(), 100.0, 100.0))
    return s


class TestSessionWiring(unittest.TestCase):
    def test_settings_declared_and_secret_registered(self):
        for k in ("webhook_enabled", "webhook_secret", "webhook_dry_run", "webhook_port", "webhook_bind", "webhook_symbols", "webhook_max_volume",
                  "webhook_close_scope", "webhook_ips", "webhook_trust_proxy", "webhook_symbol_map", "webhook_symbol_suffix"):
            self.assertIn(k, GLOBAL_INPUTS, k)
        d = default_settings()
        self.assertFalse(d["webhook_enabled"])                       # TẮT mặc định
        self.assertTrue(d["webhook_dry_run"])                        # chỉ-kiểm-tra mặc định
        self.assertEqual(d["webhook_bind"], "127.0.0.1")             # chỉ máy này mặc định
        self.assertEqual(d["webhook_close_scope"], "own")
        self.assertIn("webhook_secret", SECRET_SETTING_KEYS)
        self.assertTrue(GLOBAL_INPUTS["webhook_secret"].secret)
        secret_inputs = {k for k, i in GLOBAL_INPUTS.items() if i.secret}
        self.assertTrue(secret_inputs <= set(SECRET_SETTING_KEYS), secret_inputs - set(SECRET_SETTING_KEYS))
        self.assertEqual(clean_settings({"webhook_port": 80})["webhook_port"], 8787)           # < 1024 bị từ chối (Android không cho)
        self.assertEqual(clean_settings({"webhook_bind": "8.8.8.8"})["webhook_bind"], "127.0.0.1")

    def test_build_refuses_unsafe_or_incomplete_config(self):
        s = paper_session()
        for over, frag in ((dict(webhook_secret="short"), "≥ 16"),
                           (dict(mode="live", webhook_dry_run=False, webhook_max_volume=0.0), "LIVE"),
                           (dict(webhook_ips="tradingview, nope"), "IP nguồn"),
                           (dict(webhook_trust_proxy=True, webhook_bind="0.0.0.0"), "X-Forwarded-For")):
            s.settings.update(paper_session(**over).settings)
            srv, why = webhooksrv.build(s)
            self.assertIsNone(srv, over)
            self.assertIn(frag, why)
        s.settings.update(paper_session().settings)
        srv, why = webhooksrv.build(s)
        self.assertIsNotNone(srv, why)
        self.assertEqual(why, "")

    def test_live_with_cap_or_dry_run_is_allowed(self):
        s = paper_session(mode="live", webhook_max_volume=1.0)
        self.assertIsNotNone(webhooksrv.build(s)[0])
        s = paper_session(mode="live", webhook_max_volume=0.0, webhook_dry_run=True)
        self.assertIsNotNone(webhooksrv.build(s)[0])

    def test_end_to_end_buy_then_close_only_own_positions(self):
        s = paper_session()
        s.open_position("BTCUSDT", "buy", 1.0, owner="manual")       # lệnh tay có sẵn: «close» của webhook KHÔNG được đụng tới
        srv, why = webhooksrv.build(s)
        srv.port = 0
        srv.start()
        self.addCleanup(srv.stop)
        h = Srv.post.__get__(type("X", (), {"port": srv.port})())
        st, r = h(body(id="b1", volume=2))
        self.assertEqual((st, r["accepted"]), (200, True))
        for _ in range(50):
            if len(s.account.positions) == 2:
                break
            time.sleep(0.1)
        owners = sorted(p.owner for p in s.account.positions.values())
        self.assertEqual(owners, ["manual", "webhook"])
        self.assertEqual(h(body(id="c1", action="close", volume=None))[0], 200)
        for _ in range(50):
            if len(s.account.positions) == 1:
                break
            time.sleep(0.1)
        self.assertEqual([p.owner for p in s.account.positions.values()], ["manual"])
        self.assertEqual(h(body(id="c2", action="close_all", volume=None))[0], 200)
        time.sleep(0.5)
        self.assertEqual([p.owner for p in s.account.positions.values()], ["manual"])           # close_all cũng chỉ đóng của webhook

    def test_close_scope_all_closes_everything(self):
        s = paper_session(webhook_close_scope="all")
        s.open_position("BTCUSDT", "buy", 1.0, owner="manual")
        srv, _ = webhooksrv.build(s)
        srv.port = 0
        srv.start()
        self.addCleanup(srv.stop)
        h = Srv.post.__get__(type("X", (), {"port": srv.port})())
        h(body(id="c", action="close_all", volume=None))
        for _ in range(50):
            if not s.account.positions:
                break
            time.sleep(0.1)
        self.assertEqual(len(s.account.positions), 0)

    def test_dry_run_places_nothing(self):
        s = paper_session(webhook_dry_run=True)
        srv, _ = webhooksrv.build(s)
        srv.port = 0
        srv.start()
        self.addCleanup(srv.stop)
        h = Srv.post.__get__(type("X", (), {"port": srv.port})())
        self.assertTrue(h(body(id="d1"))[1]["dry_run"])
        time.sleep(0.4)
        self.assertEqual(len(s.account.positions), 0)

    def test_volume_cap_enforced_by_session_wiring(self):
        s = paper_session(webhook_max_volume=1.5)
        srv, _ = webhooksrv.build(s)
        srv.port = 0
        srv.start()
        self.addCleanup(srv.stop)
        h = Srv.post.__get__(type("X", (), {"port": srv.port})())
        self.assertEqual(h(body(id="big", volume=2))[1]["code"], "VOLUME_DENIED")
        time.sleep(0.3)
        self.assertEqual(len(s.account.positions), 0)

    def test_session_lifecycle_start_stop_and_snapshot(self):
        s = paper_session(webhook_port=0)
        s.settings["webhook_port"] = 0                               # (qua build: int(0 or 8787) = 8787 -> đặt cổng thật bên dưới)
        import pyea.webhooksrv as ws
        real = ws.build

        def build0(sess, clock=time.time):
            srv, why = real(sess, clock)
            if srv is not None:
                srv.port = 0
            return srv, why
        ws.build = build0
        try:
            self.assertEqual(s.webhook_status(), {"on": False})
            s._start_webhook()
            self.assertIsNotNone(s.webhook)
            st = s.webhook_status()
            self.assertTrue(st["on"])
            self.assertFalse(st["dry_run"])
            self.assertGreater(st["port"], 0)
            s._start_webhook()                                       # gọi lại không mở cổng thứ hai
            port = st["port"]
            s._stop_webhook()
            self.assertIsNone(s.webhook)
            with self.assertRaises(OSError):
                socket.create_connection(("127.0.0.1", port), timeout=1)
            self.assertEqual(s.webhook_status(), {"on": False})
        finally:
            ws.build = real
            s._stop_webhook()

    def test_off_by_default_and_never_in_backtest(self):
        s = paper_session(webhook_enabled=False)
        s._start_webhook()
        self.assertIsNone(s.webhook)
        s = paper_session()
        s.sync = True                                                # backtest
        s._start_webhook()
        self.assertIsNone(s.webhook)

    def test_unsafe_config_warns_and_session_continues(self):
        s = paper_session(webhook_secret="short")
        s._start_webhook()
        self.assertIsNone(s.webhook)
        self.assertTrue(any("Webhook không chạy" in a for a in s.alarms), s.alarms)

    def test_port_busy_warns_and_session_continues(self):
        blocker = Srv()
        try:
            s = paper_session()
            s.settings["webhook_port"] = blocker.port
            s._start_webhook()
            self.assertIsNone(s.webhook)
            self.assertTrue(any("Webhook không chạy" in a for a in s.alarms), s.alarms)
        finally:
            blocker.close()


if __name__ == "__main__":
    unittest.main()
