"""Kênh giám sát -> app: server THẬT + script run_mt5_termux.sh THẬT với lệnh MT5/MetaEditor giả (không có MT5/Wine ở đây)."""
import base64
import os
import socket
import subprocess
import tempfile
import time
import unittest

from pyea import mt5ea

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(os.path.dirname(HERE), "tools", "mt5_phone", "run_mt5_termux.sh")
TOKEN = "tok-12345678"


def server():
    s = mt5ea.Mt5EaServer(0, TOKEN)
    s.provision = {"PyEABridge.mq5": "// ea ünï\n", "bridge.set": "InpToken=%s\n" % TOKEN, "startup.ini": "[Common]\n"}
    s.start()
    return s


def env_for(srv, d, **extra):
    extra = dict({"LOG_POLL": "0"}, **extra)
    e = dict(os.environ, NO_XVFB="1", STATUS_FILE=os.path.join(d, "st"), LOG_FILE=os.path.join(d, "log"), NOTIFY_CMD="/bin/true", BACKOFF_START="0.05", BACKOFF_MAX="0.1",
             PYEA_PORT=str(srv.port), PYEA_TOKEN=TOKEN, MT5_DIR=d, PYEA_STATE_DIR=os.path.join(d, ".pyea"), **extra)
    return e


def wait(cond, t=8.0):
    end = time.time() + t
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.05)
    return False


def kinds(srv):
    return [a["kind"] for a in list(srv.alerts)]


class TestServerSup(unittest.TestCase):
    def setUp(self):
        self.srv = server()

    def tearDown(self):
        self.srv.close()

    def sup(self, *lines, token=TOKEN):
        c = socket.create_connection(("127.0.0.1", self.srv.port), timeout=3)
        c.sendall(("SUPHELLO|v=1|token=%s\n" % token + "".join(l + "\n" for l in lines)).encode())
        return c

    def test_wrong_token_denied(self):
        c = self.sup("SLOG|lvl=I|m=x", token="bad-token-1")
        self.assertIn(b"DENY", c.recv(200))
        self.assertTrue(wait(lambda: "token" in kinds(self.srv)))
        self.assertFalse(any("x" == t for *_, t in self.srv.diag))

    def test_run_stuck_event_and_noalive_gave_up_make_clear_alerts(self):
        """v28: báo rõ «MT5 không lên» (khác «chết nhanh»): có lý do, mẫu cuối, và không hứa «sẽ chạy lại»."""
        self.sup("SEVT|kind=run_stuck|run=1|up=151|explorer_pct=99|detail=RAM_trống%3D800MB explorer.exe(pid 3)%3D99%25")
        self.assertTrue(wait(lambda: "run_stuck" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "run_stuck"][0]
        self.assertIn("lần chạy 1", a["title"] if "title" in a else a["text"]); self.assertIn("99", a["text"]); self.assertIn("151", a["text"])
        self.sup("SEVT|kind=gave_up|code=137|fast=0|reason=noalive|runs=2|why=MT5 không ghi nhật ký nào trong 2 lần chạy liên tiếp (lần cuối mã 137 sau 185s)")
        self.assertTrue(wait(lambda: "gave_up" in kinds(self.srv)))
        g = [x for x in self.srv.alerts if x["kind"] == "gave_up"][0]
        self.assertIn("không ghi nhật ký", g["text"]); self.assertIn("Sao chép chẩn đoán", g["text"]); self.assertFalse(g["auto"])
        self.assertNotIn("chết nhanh", g["text"])
        self.assertEqual(self.srv.sup["state"], "gave_up")

    def test_exit_codes_classified(self):
        self.assertIn("Android", mt5ea.classify_exit(137)[0])
        self.assertIn("SIGSEGV", mt5ea.classify_exit(139)[0])
        self.assertIn("77", mt5ea.classify_exit(77)[0])
        self.assertTrue(mt5ea.classify_exit("x")[1])

    def test_mt5_exit_event_makes_alert_with_cause_auto_need(self):
        self.sup("SEVT|kind=mt5_exit|code=137|up=42|restarts=3|will_restart=1|wait=5")
        self.assertTrue(wait(lambda: "mt5_exit" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "mt5_exit"][0]
        self.assertIn("137", a["title"]); self.assertIn("Android", a["text"]); self.assertIn("• Tự khắc phục:", a["text"]); self.assertTrue(a["auto"])
        self.assertTrue(self.srv.is_supervised())                 # tự phát hiện, không cần cài đặt

    def test_compile_fail_carries_log_excerpt_to_app(self):
        self.sup("SEVT|kind=compile|ok=0|errors=2|warnings=0|excerpt=PyEABridge.mq5 12:3 error 256: undeclared identifier")
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "compile_fail"][0]
        self.assertIn("undeclared identifier", a["text"]); self.assertTrue(a["critical"])

    def test_logline_rules_login_failed_and_socket_blocked_rate_limited(self):
        self.sup("LOGLINE|src=journal|text=2026.11.10 12:00:00 Network '123': authorization on Server failed (invalid account)",
                 "LOGLINE|src=journal|text=again authorization on Server failed (invalid account)",
                 "LOGLINE|src=experts|text=PyEABridge: no link to app - socket error 4014, file relay did not answer")
        self.assertTrue(wait(lambda: "socket_blocked" in kinds(self.srv)))
        self.assertEqual(kinds(self.srv).count("login_failed"), 1)  # lặp lại trong 10 phút không báo lại
        self.assertEqual(len(self.srv.diag), 3)                   # nhưng cả 3 dòng đều vào nhật ký

    def test_get_provision_and_unknown(self):
        c = self.sup("GET|name=PyEABridge.mq5", "GET|name=evil.exe")
        c.settimeout(3)
        buf = b""
        while buf.count(b"\n") < 3:
            buf += c.recv(4096)
        lines = buf.decode().split("\n")
        self.assertTrue(lines[0].startswith("SUPWELCOME"))
        self.assertEqual(base64.b64decode(mt5ea.dec(lines[1])[1]["b64"]).decode(), "// ea ünï\n")
        self.assertIn("err", mt5ea.dec(lines[2])[1])

    def test_sup_does_not_replace_ea_connection(self):
        from tests.fake_ea import FakeEA
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        self.sup("SLOG|lvl=I|m=hi")
        self.assertTrue(wait(lambda: any(t == "hi" for *_, t in self.srv.diag)))
        self.assertTrue(self.srv.alive())
        ea.close()

    def test_diagnostics_masks_token_everywhere(self):
        self.srv.diag_add("ea", "E", "boom token=" + TOKEN)
        self.srv.info = {"login": "1", "token": TOKEN}
        txt = self.srv.diagnostics_text()
        self.assertNotIn(TOKEN, txt); self.assertIn("boom", txt); self.assertIn("login=1", txt)

    def test_ea_log_message_enters_diag_and_error_alerts(self):
        from tests.fake_ea import FakeEA
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        ea.send("LOG", lvl="E", m="OrderSend failed 10027")
        self.assertTrue(wait(lambda: "ea_error" in kinds(self.srv)))
        ea.close()

    def test_lost_while_mt5_running_is_distinguished(self):
        from tests.fake_ea import FakeEA
        self.sup("SEVT|kind=started|restarts=0")
        ea = FakeEA(self.srv.port, TOKEN)
        ea.start()
        self.assertTrue(wait(self.srv.alive))
        self.srv.alerts.clear()
        ea.kill_link()
        self.assertTrue(wait(lambda: "lost_mt5_up" in kinds(self.srv)))
        ea.close()


class TestScriptToApp(unittest.TestCase):
    def setUp(self):
        self.srv = server()
        self.d = tempfile.mkdtemp()

    def tearDown(self):
        self.srv.close()

    def run_script(self, *args, **extra):
        return subprocess.run(["bash", SCRIPT, *args], env=env_for(self.srv, self.d, **extra), capture_output=True, text=True, timeout=60)

    def test_crash_loop_reports_each_exit_and_gave_up(self):
        p = self.run_script(MT5_CMD="sh -c 'exit 137'", MAX_FAST_CRASHES="3", MIN_UP="60")
        self.assertEqual(p.returncode, 2)
        self.assertTrue(wait(lambda: "gave_up" in kinds(self.srv)))
        self.assertGreaterEqual(kinds(self.srv).count("mt5_exit"), 2)
        a = [x for x in self.srv.alerts if x["kind"] == "gave_up"][0]
        self.assertIn("137", a["text"]); self.assertFalse(a["auto"])
        self.assertTrue(any("đuôi log" in t for *_, t in self.srv.diag))

    def test_provision_writes_files_from_app_exactly(self):
        p = self.run_script("provision")
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertEqual(open(os.path.join(self.d, "MQL5/Experts/PyEABridge.mq5"), encoding="utf-8").read(), "// ea ünï\n")
        self.assertIn(TOKEN, open(os.path.join(self.d, "MQL5/Profiles/Tester/bridge.set")).read())
        self.assertTrue(os.path.exists(os.path.join(self.d, "startup.ini")))

    def test_provision_wrong_token_fails_clearly(self):
        p = subprocess.run(["bash", SCRIPT, "provision"], env=dict(env_for(self.srv, self.d), PYEA_TOKEN="wrong-token-9"), capture_output=True, text=True, timeout=60)
        self.assertNotEqual(p.returncode, 0)
        self.assertTrue(wait(lambda: "token" in kinds(self.srv)))

    def _fake_metaeditor(self, body):
        f = os.path.join(self.d, "me.sh")
        with open(f, "w") as fh:
            fh.write("#!/bin/bash\n" + body)
        os.chmod(f, 0o755)
        return f

    def test_compile_ok_and_fail_reported_from_log_without_opening_metaeditor(self):
        os.makedirs(os.path.join(self.d, "MQL5/Experts"))
        open(os.path.join(self.d, "MQL5/Experts/PyEABridge.mq5"), "w").write("x")
        ok = self._fake_metaeditor('src="${1#/compile:}"; src="${src#Z:}"; src="${src//\\\\//}"; : > "${src%.mq5}.ex5"; '
                                   'echo "Result: 0 errors, 1 warnings" | iconv -t UTF-16 > "${src%.mq5}.log"\n')
        p = self.run_script("compile", METAEDITOR_CMD=ok)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertTrue(wait(lambda: "compile_ok" in kinds(self.srv)))
        bad = self._fake_metaeditor('src="${1#/compile:}"; src="${src#Z:}"; src="${src//\\\\//}"; '
                                    'printf "PyEABridge.mq5 (12,3) : error 256: undeclared identifier\\nResult: 1 errors, 0 warnings\\n" | iconv -t UTF-16LE > "${src%.mq5}.log"\n')
        os.remove(os.path.join(self.d, "MQL5/Experts/PyEABridge.ex5"))
        p = self.run_script("compile", METAEDITOR_CMD=bad)
        self.assertEqual(p.returncode, 1)
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))
        a = [x for x in self.srv.alerts if x["kind"] == "compile_fail"][0]
        self.assertIn("undeclared identifier", a["text"])

    def test_compile_without_source_reports_not_crash(self):
        p = self.run_script("compile", METAEDITOR_CMD="/bin/true")
        self.assertEqual(p.returncode, 1)
        self.assertTrue(wait(lambda: "compile_fail" in kinds(self.srv)))

    def test_log_tailer_forwards_utf16_lines_and_alerts(self):
        os.makedirs(os.path.join(self.d, "logs")); os.makedirs(os.path.join(self.d, "MQL5/Logs"))
        lf = os.path.join(self.d, "logs/20261110.log")
        txt = "boring line\nNetwork '123': authorization on Srv failed (invalid account)\n"
        with open(lf, "wb") as f:
            f.write(b"\xff\xfe" + txt.encode("utf-16le"))
        ef = os.path.join(self.d, "MQL5/Logs/20261110.log")
        with open(ef, "wb") as f:
            f.write(b"\xff\xfe" + "PyEABridge: no link to app - socket error 4014, file relay did not answer\n".encode("utf-16le"))
        p = subprocess.Popen(["bash", SCRIPT], env=env_for(self.srv, self.d, MT5_CMD="sleep 20", LOG_POLL="0.2"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self.assertTrue(wait(lambda: "login_failed" in kinds(self.srv) and "socket_blocked" in kinds(self.srv), 10))
            self.assertFalse(any("boring" in t for *_, t in self.srv.diag))      # chỉ đẩy dòng đáng chú ý
            with open(lf, "ab") as f:                                              # dòng mới nối thêm cũng được đọc, không đọc lại dòng cũ
                f.write("PyEA late error\n".encode("utf-16le"))
            self.assertTrue(wait(lambda: any("late error" in t for *_, t in self.srv.diag), 10))
            self.assertEqual(sum("authorization" in t for *_, t in self.srv.diag), 1)
        finally:
            p.terminate(); p.wait(10)

    def test_no_token_means_script_still_works_silently(self):
        p = subprocess.run(["bash", SCRIPT], env=dict(env_for(self.srv, self.d, MT5_CMD="sh -c 'exit 3'", MAX_FAST_CRASHES="2"), PYEA_TOKEN=""), capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 2)
        self.assertEqual(kinds(self.srv), [])


if __name__ == "__main__":
    unittest.main()


class TestRunWatch(unittest.TestCase):
    """v28: đo lúc MT5 đang chạy + dừng sớm + bỏ cuộc (log thật Cat S52 2026-11-27: explorer.exe quay 99%, MT5 không ghi nhật ký, bị kill 137 sau ~3 phút, 65 lần chạy lại).
    Dùng tiến trình giả TÊN «explorer.exe» (vòng lặp bận) và `ps` thật của máy chạy test."""

    def setUp(self):
        self.srv = server()
        self.d = tempfile.mkdtemp()
        self.st = os.path.join(self.d, ".pyea")

    def tearDown(self):
        self.srv.close()

    def fake(self, name, body):
        f = os.path.join(self.d, name)
        with open(f, "w") as fh:
            fh.write("#!/bin/bash\n" + body)
        os.chmod(f, 0o755)
        return f

    def run_script(self, timeout=60, **extra):
        env = env_for(self.srv, self.d, **dict({"PYEA_STUCK_WATCH": "1", "RUN_SAMPLE_S": "1", "RUN_PROBE": "0"}, **extra))
        return subprocess.run(["bash", SCRIPT], env=env, capture_output=True, text=True, timeout=timeout)

    def read(self, name):
        try:
            return open(os.path.join(self.st, name), encoding="utf-8", errors="replace").read()
        except OSError:
            return ""

    def events(self, kind):
        return [t for *_, t in self.srv.diag if ("kind=%s" % kind) in t]

    def test_hot_explorer_without_mt5_log_is_stopped_early_then_script_gives_up_with_code_3(self):
        ex = self.fake("explorer.exe", "while :; do :; done\n")
        p = self.run_script(MT5_CMD="bash %s" % ex, RUN_STUCK_S="2", RUN_HOT_N="2", MAX_NOALIVE="2", MIN_UP="0")
        self.assertEqual(p.returncode, 3, p.stdout + p.stderr)
        samples = self.read("run_samples.txt")
        self.assertIn("explorer.exe(pid", samples, "mẫu phải ghi tên + pid tiến trình Wine")
        self.assertRegex(samples, r"explorer\.exe\(pid \d+\)=(\d{2,3})%/\d+MB", "có %CPU và RAM của explorer.exe")
        self.assertIn("RAM_trống=", samples)
        self.assertIn("DỪNG SỚM", samples)
        self.assertIn("[lần 1]", samples); self.assertIn("[lần 2]", samples)
        self.assertNotIn("[lần 3]", samples, "chỉ 2 lần chạy rồi bỏ cuộc, không chạy lại vô hạn")
        self.assertTrue(wait(lambda: "gave_up" in kinds(self.srv)))
        self.assertTrue(wait(lambda: self.events("run_stuck")))
        g = [t for t in self.events("gave_up")][0]
        self.assertIn("reason=noalive", g)
        self.assertIn("explorer.exe quay", g)
        self.assertTrue(wait(lambda: any("mẫu cuối" in t for *_, t in self.srv.diag)))
        self.assertIn("=== lần chạy 1", self.read("run_trace.txt"))
        self.assertIn("gave_up", open(os.path.join(self.d, "st")).read())

    def test_run_that_dies_without_any_mt5_log_counts_even_if_nobody_stopped_it(self):
        """Trường hợp thật: Android kill (137) trước khi ta kịp dừng - vẫn phải bỏ cuộc thay vì chạy lại 65 lần."""
        p = self.run_script(MT5_CMD="sh -c 'sleep 1; exit 137'", MAX_NOALIVE="2", MIN_UP="0")
        self.assertEqual(p.returncode, 3, p.stdout + p.stderr)
        self.assertTrue(wait(lambda: "gave_up" in kinds(self.srv)))
        g = [t for t in self.events("gave_up")][0]
        self.assertIn("code=137", g); self.assertIn("runs=2", g)
        self.assertEqual(self.read("run_samples.txt").count("kết thúc mã 137"), 2)

    def test_mt5_that_writes_a_journal_is_never_stopped_or_given_up_on(self):
        mt = self.fake("explorer.exe", "mkdir -p logs; echo started >> logs/20261128.log; while :; do :; done\n")
        stopf = os.path.join(self.d, "stop.req")
        env = env_for(self.srv, self.d, PYEA_STUCK_WATCH="1", RUN_SAMPLE_S="1", RUN_PROBE="0", RUN_STUCK_S="1", RUN_HOT_N="1", MAX_NOALIVE="1", MIN_UP="0",
                      MT5_CMD="bash %s" % mt, PYEA_STOP_FILE=stopf)
        p = subprocess.Popen(["bash", SCRIPT], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=self.d)
        try:
            self.assertTrue(wait(lambda: self.read("run_samples.txt").count("MT5_đã_ghi_nhật_ký=1") >= 3, 20), self.read("run_samples.txt"))
            self.assertIsNone(p.poll(), "MT5 đã ghi nhật ký thì không bị dừng/bỏ cuộc dù explorer.exe bận")
            open(stopf, "w").close()
            self.assertEqual(p.wait(timeout=20), 0)
        finally:
            if p.poll() is None:
                p.kill()
        self.assertNotIn("DỪNG SỚM", self.read("run_samples.txt"))
        self.assertFalse(self.events("run_stuck")); self.assertFalse(self.events("gave_up"))

    def test_old_journal_from_a_previous_run_is_not_proof_of_life(self):
        os.makedirs(os.path.join(self.d, "logs"))
        open(os.path.join(self.d, "logs", "old.log"), "w").write("old\n")
        os.utime(os.path.join(self.d, "logs", "old.log"), (1, 1))
        p = self.run_script(MT5_CMD="sh -c 'sleep 1; exit 1'", MAX_NOALIVE="2", MIN_UP="0")
        self.assertEqual(p.returncode, 3, p.stdout + p.stderr)

    def test_watch_off_by_default_keeps_the_old_behaviour(self):
        env = env_for(self.srv, self.d, RUN_SAMPLE_S="1", MT5_CMD="sh -c 'sleep 1; exit 1'", MAX_FAST_CRASHES="3", MIN_UP="60")
        p = subprocess.run(["bash", SCRIPT], env=env, capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 2, "không có PYEA_STUCK_WATCH=1: vẫn là luật «chết nhanh» cũ (mã 2), không có mã 3")
        self.assertFalse(os.path.exists(os.path.join(self.st, "run_trace.txt")), "không bật thì không ghi vết Wine")

    def test_wine_trace_goes_to_trace_file_only_for_the_first_runs(self):
        cmd = self.fake("noisy.sh", "echo 'err:fake:boom_%s' >&2; sleep 0.3; exit 1\n" % "$$")
        p = self.run_script(MT5_CMD="bash %s" % cmd, MAX_NOALIVE="4", MIN_UP="0", MAX_FAST_CRASHES="50", RUN_TRACE_RUNS="2")
        self.assertEqual(p.returncode, 3, p.stdout + p.stderr)
        tr = self.read("run_trace.txt")
        self.assertEqual(tr.count("err:fake:boom_"), 2, tr)
        self.assertEqual(open(os.path.join(self.d, "log"), encoding="utf-8", errors="replace").read().count("err:fake:boom_"), 2, "từ lần chạy thứ 3 stderr lại về log chung")

    def test_probe_is_called_once_per_run_when_mt5_still_silent(self):
        pr = self.fake("probe.sh", "echo \"$@\" >> %s\n" % os.path.join(self.d, "probe_calls"))
        ex = self.fake("explorer.exe", "sleep 6\n")
        p = self.run_script(MT5_CMD="bash %s" % ex, RUN_PROBE="1", RUN_PROBE_AT="2", PYEA_PROBE_SH=pr, MAX_NOALIVE="1", MIN_UP="0", RUN_STUCK_S="100")
        self.assertEqual(p.returncode, 3, p.stdout + p.stderr)
        calls = open(os.path.join(self.d, "probe_calls")).read().split("\n")
        self.assertEqual([c for c in calls if c], ["probe chạy1"], "đúng một lần, đúng nhãn")
