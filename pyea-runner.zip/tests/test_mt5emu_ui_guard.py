"""Hộp thoại «Kết nối MT5 nhanh» không được trống trơn khi dựng trang lỗi (log thật: ảnh hộp thoại trống, không nút nào) và tick lỗi không được ném vào Clock."""
import os
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import embedded, mt5emu, ui_mt5emu as U  # noqa: E402


class App:
    data_dir = "/tmp/pyea_ui_guard_data"
    settings = {}
    settings_tab = None

    def __init__(self):
        self.toasts = []

    def toast(self, m):
        self.toasts.append(m)


def texts(widget):
    out = []
    for c in getattr(widget, "children", []):
        out.append(str(getattr(c, "text", "")))
        out += texts(c)
    return out


class TestGuard(unittest.TestCase):
    def setUp(self):
        self.orig = (embedded.supported, U.wlabel, mt5emu.progress_embedded)
        embedded.supported = lambda *a, **k: (True, "")
        self.addCleanup(self.restore)

    def restore(self):
        embedded.supported, U.wlabel, mt5emu.progress_embedded = self.orig

    def test_build_error_shows_minimal_page_not_empty_box(self):
        real, n = U.wlabel, [0]

        def boom(*a, **k):
            n[0] += 1
            if n[0] == 1:
                raise RuntimeError("giả lập lỗi dựng trang")
            return real(*a, **k)
        U.wlabel = boom
        d = U.Mt5EmuDialog(App())
        d.open()                                                          # không được ném
        self.assertGreaterEqual(len(d.box.children), 2)                  # có chữ lỗi + hàng nút + nút Đóng
        joined = "\n".join(texts(d.box))
        self.assertIn("Không dựng được trang", joined)
        self.assertIn("giả lập lỗi dựng trang", joined)
        self.assertIn("Sao chép chẩn đoán", joined)
        self.assertIn("RuntimeError", d.ui_err)

    def test_open_error_in_state_reading_still_opens_with_fallback(self):
        orig = d_status = embedded.status
        embedded.status = lambda *a, **k: (_ for _ in ()).throw(OSError("đĩa lỗi"))
        self.addCleanup(lambda: setattr(embedded, "status", orig))
        d = U.Mt5EmuDialog(App())
        d.open()
        self.assertIn("đĩa lỗi", "\n".join(texts(d.box)))

    def test_tick_error_is_contained_and_reported_in_head(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.head = U.wlabel("", 12, U.TEXT)
        mt5emu.progress_embedded = lambda *a, **k: (_ for _ in ()).throw(ValueError("hỏng đọc"))
        d.tick()                                                          # không ném
        self.assertIn("hỏng đọc", d.head.text)
        self.assertIn("ValueError", d.ui_err)

    def test_fallback_itself_never_raises(self):
        d = U.Mt5EmuDialog(App())
        d.box = None                                                      # hỏng nặng: không có hộp
        d._fallback("thử", RuntimeError("x"))                            # không ném

    def test_diag_copy_includes_ui_error(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.ui_err = "tick: ValueError hỏng đọc"
        got = []
        d.copy = lambda text, msg: got.append(text)
        d.emb_diag()
        self.assertIn("--- lỗi giao diện ---", got[0])
        self.assertIn("ValueError hỏng đọc", got[0])


class TestPickZipUi(unittest.TestCase):
    """v17: nút chọn tệp .zip MT5 từ bộ nhớ (bộ chọn thật là SAF của Android, ở đây thay bằng hàm giả)."""

    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.orig = (embedded.supported, U.android_utils.pick_file_copy)
        embedded.supported = lambda *a, **k: (True, "")

        def restore():
            embedded.supported, U.android_utils.pick_file_copy = self.orig
        self.addCleanup(restore)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]

    def run_scheduled(self):
        """Clock giả chỉ xếp hàng; chạy các lệnh đã hẹn như Kivy sẽ làm ở khung hình kế tiếp."""
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for fn in fns:
            fn(0)

    def open_dialog(self):
        d = U.Mt5EmuDialog(self.app)
        d.open()
        return d

    def test_form_has_pick_and_clear_buttons_and_empty_state(self):
        d = self.open_dialog()
        joined = "\n".join(texts(d.box))
        self.assertIn("Chọn tệp .zip MT5", joined)
        self.assertIn("Bỏ tệp đã chọn", joined)
        self.assertIn("Chưa chọn tệp .zip.", joined)

    def test_picked_file_is_registered_and_shown(self):
        d = self.open_dialog()
        dest = embedded.import_dest(self.tmp.name)

        def fake_pick(dst, cb):
            self.assertEqual(dst, dest)
            open(dst, "wb").write(b"PK" + b"0" * (3 << 20))
            cb("MT5 portable.zip", 3 << 20, None)
        U.android_utils.pick_file_copy = fake_pick
        d.pick_zip()
        self.assertNotIn("MT5 portable.zip", d.imp_lbl.text, "chưa chạy Clock thì chưa cập nhật nhãn")
        self.run_scheduled()
        self.assertIn("MT5 portable.zip", d.imp_lbl.text)
        self.assertIn("3 MB", d.imp_lbl.text)
        self.assertEqual(embedded.import_info(self.tmp.name)["name"], "MT5 portable.zip")

    def test_cancel_and_error_are_reported_without_registering(self):
        d = self.open_dialog()
        d._zip_picked(None, 0, "cancelled")
        self.assertIsNone(embedded.import_info(self.tmp.name))
        d._zip_picked(None, 0, "Traceback...\nValueError: Đây không phải tệp .zip")
        self.assertIn("không phải tệp .zip", d.status.text)
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_copying_notice_shown_and_nothing_registered(self):
        d = self.open_dialog()
        d._zip_picked("MT5 portable.zip", 0, "copying")
        self.assertIn("Đang chép và kiểm tra", d.status.text)
        self.assertIn("MT5 portable.zip", d.status.text)
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_corrupt_zip_message_reaches_the_user(self):
        d = self.open_dialog()
        d._zip_picked(None, 0, "Tệp .zip bị HỎNG: 2/332 mục đọc không được, ví dụ terminal64.exe. Thường do tải về dở: hãy TẢI LẠI tệp")
        self.assertIn("HỎNG", d.status.text)
        self.assertIn("TẢI LẠI", d.status.text)

    def test_clear_button_forgets_the_file(self):
        d = self.open_dialog()
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        d._zip_picked("a.zip", 4, None)
        self.assertIsNotNone(embedded.import_info(self.tmp.name))
        d.clear_zip()
        self.assertIsNone(embedded.import_info(self.tmp.name))
        self.assertIn("Chưa chọn", d.imp_lbl.text)

def press(root, label):
    """Bấm nút có chữ == label (gọi callback on_release đã bind)."""
    def walk(w):
        yield w
        for c in getattr(w, "children", []):
            yield from walk(c)
    for x in walk(root):
        if getattr(x, "text", None) == label and x._binds.get("on_release"):
            for cb in x._binds["on_release"]:
                cb(x)
            return True
    raise AssertionError("không thấy nút %r" % label)


class TestZipOnProgressPage(unittest.TestCase):
    """Người dùng (2026-11-26): «Nếu là zip lỗi thì lại ko có chỗ để import lại zip, hay chỗ để xoá zip cũ bị lỗi» - trang tiến trình (nơi hiện lỗi)
    phải có nút chọn tệp .zip khác và bỏ tệp cũ, không bắt đi vòng qua «Nhập lại thông tin»."""

    def setUp(self):
        import json
        import tempfile
        import time
        self.json, self.time = json, time
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.orig = (embedded.supported, U.android_utils.pick_file_copy)
        embedded.supported = lambda *a, **k: (True, "")

        def restore():
            embedded.supported, U.android_utils.pick_file_copy = self.orig
        self.addCleanup(restore)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]
        self.d = U.Mt5EmuDialog(self.app)
        self.d.open()
        self.d.show_progress_embedded()

    def run_scheduled(self):
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for fn in fns:
            fn(0)

    def set_phase(self, phase, age=0):
        lo = embedded.Layout(self.tmp.name)
        os.makedirs(os.path.dirname(lo.state), exist_ok=True)
        with open(lo.state, "w") as f:
            self.json.dump({"phase": phase, "t": self.time.time() - age}, f)

    def test_progress_page_has_zip_buttons_and_state(self):
        joined = "\n".join(texts(self.d.box))
        self.assertIn("Chọn tệp .zip MT5", joined)
        self.assertIn("Bỏ tệp .zip", joined)
        self.assertIn("Chưa chọn tệp .zip.", joined)
        self.assertIn("Khởi động lại", joined)

    def test_labels_explain_which_zip_and_what_cleanup_means(self):
        joined = "\n".join(texts(self.d.box))
        self.assertIn("chỉ giữ MỘT tệp", joined)
        self.assertIn("KHÔNG xoá tệp trong «Tải xuống»", joined)
        self.assertIn("mỗi sàn một bản", joined)
        self.assertIn("Xoá một bản là mất luôn tài khoản/EA", joined)

    def test_pick_on_progress_page_registers_and_points_to_restart(self):
        def fake_pick(dst, cb):
            open(dst, "wb").write(b"PK" + b"0" * (2 << 20))
            cb("mt5 moi.zip", 2 << 20, None)
        U.android_utils.pick_file_copy = fake_pick
        press(self.d.box, "Chọn tệp .zip MT5")
        self.run_scheduled()
        self.assertEqual(embedded.import_info(self.tmp.name)["name"], "mt5 moi.zip")
        self.assertIn("mt5 moi.zip", self.d.imp_lbl.text)
        self.assertIn("Khởi động lại", self.d.imp_lbl.text)
        self.assertIn("Khởi động lại", self.d.status.text)
        self.assertNotIn("Bắt đầu", self.d.status.text, "đang ở trang tiến trình, không có nút Bắt đầu")

    def test_broken_zip_can_be_deleted_from_progress_page(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "hong.zip", 4)
        os.makedirs(embedded.Layout(self.tmp.name).import_x)
        self.set_phase("failed")
        press(self.d.box, "Bỏ tệp .zip")
        self.assertIsNone(embedded.import_info(self.tmp.name))
        self.assertFalse(os.path.exists(embedded.import_dest(self.tmp.name)))
        self.assertFalse(os.path.exists(embedded.Layout(self.tmp.name).import_x), "bản đã giải nén của tệp lỗi cũng phải mất")
        self.assertIn("Chưa chọn", self.d.imp_lbl.text)
        self.assertIn("Đã xoá", self.d.status.text)

    def test_zip_change_refused_while_install_is_running(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "dang_dung.zip", 4)
        self.set_phase("installing")
        called = []
        U.android_utils.pick_file_copy = lambda dst, cb: called.append(1)
        press(self.d.box, "Chọn tệp .zip MT5")
        press(self.d.box, "Bỏ tệp .zip")
        self.assertEqual(called, [], "đang cài: không mở bộ chọn tệp")
        self.assertIsNotNone(embedded.import_info(self.tmp.name), "đang cài: không xoá tệp")
        self.assertIn("Dừng", self.d.status.text)

    def test_stale_installing_state_does_not_block(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "a.zip", 4)
        self.set_phase("installing", age=3600)               # dịch vụ đã chết từ lâu (không còn ghi nhịp): không được chặn vĩnh viễn
        press(self.d.box, "Bỏ tệp .zip")
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_failed_and_stopped_phases_allow_changes(self):
        for ph in ("failed", "stopped", "idle"):
            open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
            embedded.import_register(self.tmp.name, "a.zip", 4)
            self.set_phase(ph)
            press(self.d.box, "Bỏ tệp .zip")
            self.assertIsNone(embedded.import_info(self.tmp.name), ph)

    def test_form_page_still_uses_start_wording(self):
        self.d.show_form()
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        self.d._zip_picked("a.zip", 4, None)
        self.assertIn("Bắt đầu", self.d.status.text)
        self.assertIn("Bắt đầu", self.d.imp_lbl.text)

class _SyncThread:
    """Thread giả chạy ngay trong luồng gọi (Clock giả chỉ xếp hàng, ta tự chạy)."""
    def __init__(self, target=None, args=(), kwargs=None, daemon=None):
        self.t, self.a, self.k = target, args, kwargs or {}

    def start(self):
        self.t(*self.a, **self.k)


class TestMt5ListUi(unittest.TestCase):
    """Người dùng (2026-11-26): «tại sao không liệt kê ra rồi cho người dùng chọn xoá bản nào» - nút dọn hàng loạt đã được thay bằng danh sách + xoá TỪNG bản."""
    HOME = "/root/.wine-mt5/drive_c/pyea-mt5"

    def setUp(self):
        import tempfile
        from unittest import mock
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.orig = embedded.supported
        embedded.supported = lambda *a, **k: (True, "")
        self.addCleanup(lambda: setattr(embedded, "supported", self.orig))
        p = mock.patch.object(U.threading, "Thread", _SyncThread)
        p.start()
        self.addCleanup(p.stop)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]
        self.lo = embedded.Layout(self.tmp.name)
        self.home = os.path.join(self.lo.rootfs, self.HOME.lstrip("/"))
        os.makedirs(os.path.join(self.lo.host_root, ".pyea"))
        self.mk("111", 100, "tệp .zip «sàn A.zip»")
        self.mk("222", 3 << 20, "bộ cài từ link của broker-b.com")
        self.mk("333", 2 << 20, "tệp .zip «[b]xấu[/b].zip»")
        link = os.path.join(self.lo.host_root, "mt5")
        os.symlink(self.HOME + "/111", link)
        self.d = U.Mt5EmuDialog(self.app)
        self.d.open()
        self.d.show_progress_embedded()

    def mk(self, key, size, label):
        p = os.path.join(self.home, key)
        os.makedirs(os.path.join(p, "MQL5"))
        with open(os.path.join(p, "terminal64.exe"), "wb") as f:
            f.write(b"x" * size)
        with open(os.path.join(self.lo.host_root, ".pyea", "mt5_dir." + key), "w") as f:
            f.write(self.HOME + "/" + key + "\n")
        with open(os.path.join(self.lo.host_root, ".pyea", "mt5_label." + key), "w", encoding="utf-8") as f:
            f.write(label + "\n")

    def run_scheduled(self):
        while kivy_stub.SCHEDULED:
            fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
            for fn in fns:
                fn(0)

    def list_it(self):
        press(self.d.box, "Xem các bản MT5 đã cài")
        self.run_scheduled()

    def exists(self, key):
        return os.path.isdir(os.path.join(self.home, key))

    def test_no_bulk_clean_button_and_nothing_is_deleted_by_listing(self):
        joined = "\n".join(texts(self.d.box))
        self.assertNotIn("Dọn bản MT5 không dùng", joined)
        self.assertIn("App KHÔNG tự xoá bản nào", joined)
        self.list_it()
        self.assertTrue(self.exists("111") and self.exists("222") and self.exists("333"))

    def test_list_shows_every_version_with_source_size_and_active_marker(self):
        self.list_it()
        joined = "\n".join(texts(self.d.mt5_list))
        self.assertIn("sàn A.zip", joined)
        self.assertIn("broker-b.com", joined)
        self.assertIn("ĐANG DÙNG", joined)
        self.assertEqual(joined.count("ĐANG DÙNG"), 1)
        self.assertIn("3.0 MB", joined.replace(",", "."))
        self.assertEqual(sum(1 for t in texts(self.d.mt5_list) if t == "Xoá bản này"), 2, "bản đang dùng không có nút xoá")
        self.assertIn("Có 3 bản MT5", self.d.mt5_msg.text)

    def test_label_markup_from_a_file_name_is_escaped(self):
        self.list_it()
        joined = "\n".join(texts(self.d.mt5_list))
        self.assertNotIn("[b]xấu[/b]", joined, "tên tệp chứa thẻ markup phải được thoát, không làm vỡ giao diện")

    def test_two_taps_on_one_row_remove_only_that_version(self):
        self.list_it()
        btns = [b for b in self.d.mt5_list.children if getattr(b, "text", "") == "Xoá bản này"]
        self.assertEqual(len(btns), 2)
        target = self.d._rm_btns["222"]
        target._binds["on_release"][-1](target)                     # lần 1: chỉ hỏi lại
        self.assertTrue(self.exists("222"))
        self.assertIn("Xoá thật", target.text)
        self.assertEqual(self.d._rm_btns["333"].text, "Xoá bản này", "bản khác không bị hỏi/đổi")
        target._binds["on_release"][-1](target)                     # lần 2: xoá
        self.run_scheduled()
        self.assertFalse(self.exists("222"))
        self.assertTrue(self.exists("111"), "bản đang dùng còn nguyên")
        self.assertTrue(self.exists("333"), "bản không được chọn còn nguyên")
        self.assertIn("Đã xoá", self.d.mt5_msg.text)
        self.assertIn("Có 2 bản MT5", self.d.mt5_msg.text)
        self.assertNotIn("broker-b.com", "\n".join(texts(self.d.mt5_list)), "danh sách phải vẽ lại, không còn bản vừa xoá")

    def test_tapping_another_row_between_the_two_taps_cancels_the_first(self):
        self.list_it()
        a, b = self.d._rm_btns["222"], self.d._rm_btns["333"]
        a._binds["on_release"][-1](a)
        b._binds["on_release"][-1](b)                               # sang bản khác: bản 222 hết «đang hỏi», 333 mới được hỏi
        self.assertEqual(a.text, "Xoá bản này")
        self.assertIn("Xoá thật", b.text)
        self.assertTrue(self.exists("222") and self.exists("333"))
        self.d._rm_disarm("222")                                    # hẹn giờ cũ của 222 chạy muộn: không được huỷ lượt hỏi của 333
        self.assertIn("Xoá thật", b.text)

    def test_timer_expiry_disarms(self):
        self.list_it()
        a = self.d._rm_btns["222"]
        a._binds["on_release"][-1](a)
        self.assertIn("Xoá thật", a.text)
        self.d._rm_disarm("222")
        self.assertEqual(a.text, "Xoá bản này")
        a._binds["on_release"][-1](a)                               # sau khi hết hạn bấm lại = lần 1 mới, không xoá
        self.assertTrue(self.exists("222"))

    def test_nothing_removed_while_installing(self):
        import json
        import time
        self.list_it()
        with open(self.lo.state, "w") as f:
            json.dump({"phase": "installing", "t": time.time()}, f)
        a = self.d._rm_btns["222"]
        a._binds["on_release"][-1](a)
        a._binds["on_release"][-1](a)
        self.run_scheduled()
        self.assertTrue(self.exists("222"))
        self.assertIn("Đang cài", self.d.mt5_msg.text)

    def test_unknown_active_version_lists_nothing_and_says_why(self):
        os.remove(os.path.join(self.lo.host_root, "mt5"))
        self.list_it()
        self.assertIn("Không liệt kê được", self.d.mt5_msg.text)
        self.assertEqual([t for t in texts(self.d.mt5_list) if t == "Xoá bản này"], [])
        self.assertTrue(self.exists("222"))



class TestBatteryRow(unittest.TestCase):
    """Người dùng (2026-11-27): «sao ko làm UI tắt (tối ưu pin) nhanh ngay trong app» - thay vì bắt tự vào Cài đặt → Pin. Hàng này hiện trạng thái THẬT từ hệ thống và nút xin miễn."""

    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        N = U.native
        self.orig = (embedded.supported, N.IS_ANDROID, N.is_ignoring_battery_optimizations, N.request_ignore_battery_optimizations)
        self.state = {"ignoring": False, "asked": 0, "opens": True}
        embedded.supported = lambda *a, **k: (True, "")
        N.IS_ANDROID = True
        N.is_ignoring_battery_optimizations = lambda: self.state["ignoring"]

        def ask():
            self.state["asked"] += 1
            return self.state["opens"]
        N.request_ignore_battery_optimizations = ask

        def restore():
            embedded.supported, N.IS_ANDROID, N.is_ignoring_battery_optimizations, N.request_ignore_battery_optimizations = self.orig
        self.addCleanup(restore)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]
        self.d = U.Mt5EmuDialog(self.app)
        self.d.open()

    def run_scheduled(self):
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for fn in fns:
            fn(0)

    def joined(self):
        return "\n".join(texts(self.d.box))

    def test_form_page_shows_not_yet_state_and_button(self):
        self.d.show_form()
        j = self.joined()
        self.assertIn("CHƯA tắt cho PyEA", j)
        self.assertIn(U.Mt5EmuDialog.BAT_TEXT, j)

    def test_progress_page_shows_the_button_too(self):
        self.d.show_progress_embedded()
        self.assertIn(U.Mt5EmuDialog.BAT_TEXT, self.joined())

    def test_button_asks_android_and_toasts_the_instruction(self):
        self.d.show_progress_embedded()
        press(self.d.box, U.Mt5EmuDialog.BAT_TEXT)
        self.assertEqual(self.state["asked"], 1)
        self.assertTrue(any("Cho phép" in t for t in self.app.toasts), self.app.toasts)

    def test_button_failure_tells_the_manual_path(self):
        self.state["opens"] = False
        self.d.show_progress_embedded()
        press(self.d.box, U.Mt5EmuDialog.BAT_TEXT)
        self.assertTrue(any("Cài đặt → Ứng dụng → PyEA Runner → Pin" in t for t in self.app.toasts), self.app.toasts)

    def test_already_exempt_shows_green_line_without_button(self):
        self.state["ignoring"] = True
        self.d.show_progress_embedded()
        j = self.joined()
        self.assertIn("ĐÃ tắt cho PyEA", j)
        self.assertNotIn(U.Mt5EmuDialog.BAT_TEXT, j)
        self.assertIn("không bảo đảm tuyệt đối", j, "không hứa quá: miễn tối ưu pin chỉ giảm khả năng bị tắt")

    def test_progress_tick_flips_to_ok_after_the_user_allows_it_in_the_system_dialog(self):
        self.d.show_progress_embedded()
        self.assertIn(U.Mt5EmuDialog.BAT_TEXT, self.joined())
        self.state["ignoring"] = True                                    # người dùng bấm «Cho phép» rồi quay lại app
        self.d._bat_t = 0.0                                              # quá hạn chu kỳ 2 giây
        self.d.tick()
        j = self.joined()
        self.assertIn("ĐÃ tắt cho PyEA", j)
        self.assertNotIn(U.Mt5EmuDialog.BAT_TEXT, j)

    def test_status_is_not_polled_every_tick(self):
        calls = []
        U.native.is_ignoring_battery_optimizations = lambda: calls.append(1) or False
        self.d.show_progress_embedded()
        n = len(calls)
        for _ in range(5):
            self.d.tick()
        self.assertEqual(len(calls), n, "tick mỗi giây không được gọi hệ thống mỗi lần")

    def test_form_page_rechecks_after_click_because_it_has_no_tick(self):
        self.d.show_form()
        press(self.d.box, U.Mt5EmuDialog.BAT_TEXT)
        self.state["ignoring"] = True
        self.run_scheduled()
        self.assertIn("ĐÃ tắt cho PyEA", self.joined())

    def test_hidden_when_not_android(self):
        U.native.IS_ANDROID = False
        self.d.show_form()
        self.assertNotIn(U.Mt5EmuDialog.BAT_TEXT, self.joined())
        self.assertNotIn("Tối ưu pin:", self.joined())
        self.assertIsNone(self.d.bat_box)
        self.d.show_progress_embedded()
        self.assertIsNone(self.d.bat_box)
        self.d.tick()                                                    # không ném


class TestBatteryIntents(unittest.TestCase):
    """android_native.request_ignore_battery_optimizations: hộp thoại xin miễn riêng của PyEA; bị hãng máy chặn thì mở danh sách tối ưu pin; không phải Android thì False."""

    def setUp(self):
        N = U.native
        self.N, self.orig = N, (N.IS_ANDROID, N._jnius)
        self.started = []
        started = self.started

        class Activity:
            def getPackageName(self):
                return "org.pyea.runner"

            def startActivity(self, intent):
                if intent.action in FAIL:
                    raise RuntimeError("ActivityNotFoundException")
                started.append((intent.action, intent.data))

        class Intent:
            def __init__(self, action):
                self.action, self.data = action, None

            def setData(self, d):
                self.data = d

        class Uri:
            @staticmethod
            def parse(s):
                return s

        FAIL = set()
        self.FAIL = FAIL
        classes = {"org.kivy.android.PythonActivity": type("PA", (), {"mActivity": Activity()}), "android.content.Intent": Intent, "android.net.Uri": Uri}
        N.IS_ANDROID = True
        N._jnius = lambda: (lambda name: classes[name])
        self.addCleanup(lambda: (setattr(N, "IS_ANDROID", self.orig[0]), setattr(N, "_jnius", self.orig[1])))

    def test_direct_request_names_the_package(self):
        self.assertTrue(self.N.request_ignore_battery_optimizations())
        self.assertEqual(self.started, [("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "package:org.pyea.runner")])

    def test_falls_back_to_the_battery_list_when_the_direct_dialog_is_blocked(self):
        self.FAIL.add("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")
        self.assertTrue(self.N.request_ignore_battery_optimizations())
        self.assertEqual([a for a, _ in self.started], ["android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"])

    def test_both_blocked_returns_false_without_raising(self):
        self.FAIL.update({"android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"})
        self.assertFalse(self.N.request_ignore_battery_optimizations())

    def test_not_android_returns_false(self):
        self.N.IS_ANDROID = False
        self.assertFalse(self.N.request_ignore_battery_optimizations())
        self.assertFalse(self.N.open_battery_settings())


if __name__ == "__main__":
    unittest.main()
