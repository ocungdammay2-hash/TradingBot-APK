"""Hộp thoại «Kết nối MT5 nhanh» không được trống trơn khi dựng trang lỗi (log thật: ảnh hộp thoại trống, không nút nào) và tick lỗi không được ném vào Clock."""
import os
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import embedded, mt5emu, ui_mt5emu as U  # noqa: E402


class App:
    data_dir = "/tmp/pyea_ui_guard_data"
    settings = {}
    settings_tab = None

    def __init__(self):
        self.toasts = []

    def toast(self, m):
        self.toasts.append(m)


def texts(widget):
    out = []
    for c in getattr(widget, "children", []):
        out.append(str(getattr(c, "text", "")))
        out += texts(c)
    return out


class TestGuard(unittest.TestCase):
    def setUp(self):
        self.orig = (embedded.supported, U.wlabel, mt5emu.progress_embedded)
        embedded.supported = lambda *a, **k: (True, "")
        self.addCleanup(self.restore)

    def restore(self):
        embedded.supported, U.wlabel, mt5emu.progress_embedded = self.orig

    def test_build_error_shows_minimal_page_not_empty_box(self):
        real, n = U.wlabel, [0]

        def boom(*a, **k):
            n[0] += 1
            if n[0] == 1:
                raise RuntimeError("giả lập lỗi dựng trang")
            return real(*a, **k)
        U.wlabel = boom
        d = U.Mt5EmuDialog(App())
        d.open()                                                          # không được ném
        self.assertGreaterEqual(len(d.box.children), 2)                  # có chữ lỗi + hàng nút + nút Đóng
        joined = "\n".join(texts(d.box))
        self.assertIn("Không dựng được trang", joined)
        self.assertIn("giả lập lỗi dựng trang", joined)
        self.assertIn("Sao chép chẩn đoán", joined)
        self.assertIn("RuntimeError", d.ui_err)

    def test_open_error_in_state_reading_still_opens_with_fallback(self):
        orig = d_status = embedded.status
        embedded.status = lambda *a, **k: (_ for _ in ()).throw(OSError("đĩa lỗi"))
        self.addCleanup(lambda: setattr(embedded, "status", orig))
        d = U.Mt5EmuDialog(App())
        d.open()
        self.assertIn("đĩa lỗi", "\n".join(texts(d.box)))

    def test_tick_error_is_contained_and_reported_in_head(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.head = U.wlabel("", 12, U.TEXT)
        mt5emu.progress_embedded = lambda *a, **k: (_ for _ in ()).throw(ValueError("hỏng đọc"))
        d.tick()                                                          # không ném
        self.assertIn("hỏng đọc", d.head.text)
        self.assertIn("ValueError", d.ui_err)

    def test_fallback_itself_never_raises(self):
        d = U.Mt5EmuDialog(App())
        d.box = None                                                      # hỏng nặng: không có hộp
        d._fallback("thử", RuntimeError("x"))                            # không ném

    def test_diag_copy_includes_ui_error(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.ui_err = "tick: ValueError hỏng đọc"
        got = []
        d.copy = lambda text, msg: got.append(text)
        d.emb_diag()
        self.assertIn("--- lỗi giao diện ---", got[0])
        self.assertIn("ValueError hỏng đọc", got[0])


class TestPickZipUi(unittest.TestCase):
    """v17: nút chọn tệp .zip MT5 từ bộ nhớ (bộ chọn thật là SAF của Android, ở đây thay bằng hàm giả)."""

    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.orig = (embedded.supported, U.android_utils.pick_file_copy)
        embedded.supported = lambda *a, **k: (True, "")

        def restore():
            embedded.supported, U.android_utils.pick_file_copy = self.orig
        self.addCleanup(restore)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]

    def run_scheduled(self):
        """Clock giả chỉ xếp hàng; chạy các lệnh đã hẹn như Kivy sẽ làm ở khung hình kế tiếp."""
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for fn in fns:
            fn(0)

    def open_dialog(self):
        d = U.Mt5EmuDialog(self.app)
        d.open()
        return d

    def test_form_has_pick_and_clear_buttons_and_empty_state(self):
        d = self.open_dialog()
        joined = "\n".join(texts(d.box))
        self.assertIn("Chọn tệp .zip MT5", joined)
        self.assertIn("Bỏ tệp đã chọn", joined)
        self.assertIn("Chưa chọn tệp .zip.", joined)

    def test_picked_file_is_registered_and_shown(self):
        d = self.open_dialog()
        dest = embedded.import_dest(self.tmp.name)

        def fake_pick(dst, cb):
            self.assertEqual(dst, dest)
            open(dst, "wb").write(b"PK" + b"0" * (3 << 20))
            cb("MT5 portable.zip", 3 << 20, None)
        U.android_utils.pick_file_copy = fake_pick
        d.pick_zip()
        self.assertNotIn("MT5 portable.zip", d.imp_lbl.text, "chưa chạy Clock thì chưa cập nhật nhãn")
        self.run_scheduled()
        self.assertIn("MT5 portable.zip", d.imp_lbl.text)
        self.assertIn("3 MB", d.imp_lbl.text)
        self.assertEqual(embedded.import_info(self.tmp.name)["name"], "MT5 portable.zip")

    def test_cancel_and_error_are_reported_without_registering(self):
        d = self.open_dialog()
        d._zip_picked(None, 0, "cancelled")
        self.assertIsNone(embedded.import_info(self.tmp.name))
        d._zip_picked(None, 0, "Traceback...\nValueError: Đây không phải tệp .zip")
        self.assertIn("không phải tệp .zip", d.status.text)
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_copying_notice_shown_and_nothing_registered(self):
        d = self.open_dialog()
        d._zip_picked("MT5 portable.zip", 0, "copying")
        self.assertIn("Đang chép và kiểm tra", d.status.text)
        self.assertIn("MT5 portable.zip", d.status.text)
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_corrupt_zip_message_reaches_the_user(self):
        d = self.open_dialog()
        d._zip_picked(None, 0, "Tệp .zip bị HỎNG: 2/332 mục đọc không được, ví dụ terminal64.exe. Thường do tải về dở: hãy TẢI LẠI tệp")
        self.assertIn("HỎNG", d.status.text)
        self.assertIn("TẢI LẠI", d.status.text)

    def test_clear_button_forgets_the_file(self):
        d = self.open_dialog()
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        d._zip_picked("a.zip", 4, None)
        self.assertIsNotNone(embedded.import_info(self.tmp.name))
        d.clear_zip()
        self.assertIsNone(embedded.import_info(self.tmp.name))
        self.assertIn("Chưa chọn", d.imp_lbl.text)

def press(root, label):
    """Bấm nút có chữ == label (gọi callback on_release đã bind)."""
    def walk(w):
        yield w
        for c in getattr(w, "children", []):
            yield from walk(c)
    for x in walk(root):
        if getattr(x, "text", None) == label and x._binds.get("on_release"):
            for cb in x._binds["on_release"]:
                cb(x)
            return True
    raise AssertionError("không thấy nút %r" % label)


class TestZipOnProgressPage(unittest.TestCase):
    """Người dùng (2026-11-26): «Nếu là zip lỗi thì lại ko có chỗ để import lại zip, hay chỗ để xoá zip cũ bị lỗi» - trang tiến trình (nơi hiện lỗi)
    phải có nút chọn tệp .zip khác và bỏ tệp cũ, không bắt đi vòng qua «Nhập lại thông tin»."""

    def setUp(self):
        import json
        import tempfile
        import time
        self.json, self.time = json, time
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.orig = (embedded.supported, U.android_utils.pick_file_copy)
        embedded.supported = lambda *a, **k: (True, "")

        def restore():
            embedded.supported, U.android_utils.pick_file_copy = self.orig
        self.addCleanup(restore)
        self.app = App()
        self.app.data_dir = self.tmp.name
        del kivy_stub.SCHEDULED[:]
        self.d = U.Mt5EmuDialog(self.app)
        self.d.open()
        self.d.show_progress_embedded()

    def run_scheduled(self):
        fns, kivy_stub.SCHEDULED[:] = list(kivy_stub.SCHEDULED), []
        for fn in fns:
            fn(0)

    def set_phase(self, phase, age=0):
        lo = embedded.Layout(self.tmp.name)
        os.makedirs(os.path.dirname(lo.state), exist_ok=True)
        with open(lo.state, "w") as f:
            self.json.dump({"phase": phase, "t": self.time.time() - age}, f)

    def test_progress_page_has_zip_buttons_and_state(self):
        joined = "\n".join(texts(self.d.box))
        self.assertIn("Chọn tệp .zip MT5", joined)
        self.assertIn("Bỏ tệp .zip", joined)
        self.assertIn("Chưa chọn tệp .zip.", joined)
        self.assertIn("Khởi động lại", joined)

    def test_pick_on_progress_page_registers_and_points_to_restart(self):
        def fake_pick(dst, cb):
            open(dst, "wb").write(b"PK" + b"0" * (2 << 20))
            cb("mt5 moi.zip", 2 << 20, None)
        U.android_utils.pick_file_copy = fake_pick
        press(self.d.box, "Chọn tệp .zip MT5")
        self.run_scheduled()
        self.assertEqual(embedded.import_info(self.tmp.name)["name"], "mt5 moi.zip")
        self.assertIn("mt5 moi.zip", self.d.imp_lbl.text)
        self.assertIn("Khởi động lại", self.d.imp_lbl.text)
        self.assertIn("Khởi động lại", self.d.status.text)
        self.assertNotIn("Bắt đầu", self.d.status.text, "đang ở trang tiến trình, không có nút Bắt đầu")

    def test_broken_zip_can_be_deleted_from_progress_page(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "hong.zip", 4)
        os.makedirs(embedded.Layout(self.tmp.name).import_x)
        self.set_phase("failed")
        press(self.d.box, "Bỏ tệp .zip")
        self.assertIsNone(embedded.import_info(self.tmp.name))
        self.assertFalse(os.path.exists(embedded.import_dest(self.tmp.name)))
        self.assertFalse(os.path.exists(embedded.Layout(self.tmp.name).import_x), "bản đã giải nén của tệp lỗi cũng phải mất")
        self.assertIn("Chưa chọn", self.d.imp_lbl.text)
        self.assertIn("Đã xoá", self.d.status.text)

    def test_zip_change_refused_while_install_is_running(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "dang_dung.zip", 4)
        self.set_phase("installing")
        called = []
        U.android_utils.pick_file_copy = lambda dst, cb: called.append(1)
        press(self.d.box, "Chọn tệp .zip MT5")
        press(self.d.box, "Bỏ tệp .zip")
        self.assertEqual(called, [], "đang cài: không mở bộ chọn tệp")
        self.assertIsNotNone(embedded.import_info(self.tmp.name), "đang cài: không xoá tệp")
        self.assertIn("Dừng", self.d.status.text)

    def test_stale_installing_state_does_not_block(self):
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        embedded.import_register(self.tmp.name, "a.zip", 4)
        self.set_phase("installing", age=3600)               # dịch vụ đã chết từ lâu (không còn ghi nhịp): không được chặn vĩnh viễn
        press(self.d.box, "Bỏ tệp .zip")
        self.assertIsNone(embedded.import_info(self.tmp.name))

    def test_failed_and_stopped_phases_allow_changes(self):
        for ph in ("failed", "stopped", "idle"):
            open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
            embedded.import_register(self.tmp.name, "a.zip", 4)
            self.set_phase(ph)
            press(self.d.box, "Bỏ tệp .zip")
            self.assertIsNone(embedded.import_info(self.tmp.name), ph)

    def test_form_page_still_uses_start_wording(self):
        self.d.show_form()
        open(embedded.import_dest(self.tmp.name), "wb").write(b"PKxx")
        self.d._zip_picked("a.zip", 4, None)
        self.assertIn("Bắt đầu", self.d.status.text)
        self.assertIn("Bắt đầu", self.d.imp_lbl.text)



if __name__ == "__main__":
    unittest.main()
