"""Hộp thoại «Kết nối MT5 nhanh» không được trống trơn khi dựng trang lỗi (log thật: ảnh hộp thoại trống, không nút nào) và tick lỗi không được ném vào Clock."""
import os
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import embedded, mt5emu, ui_mt5emu as U  # noqa: E402


class App:
    data_dir = "/tmp/pyea_ui_guard_data"
    settings = {}
    settings_tab = None

    def __init__(self):
        self.toasts = []

    def toast(self, m):
        self.toasts.append(m)


def texts(widget):
    out = []
    for c in getattr(widget, "children", []):
        out.append(str(getattr(c, "text", "")))
        out += texts(c)
    return out


class TestGuard(unittest.TestCase):
    def setUp(self):
        self.orig = (embedded.supported, U.wlabel, mt5emu.progress_embedded)
        embedded.supported = lambda *a, **k: (True, "")
        self.addCleanup(self.restore)

    def restore(self):
        embedded.supported, U.wlabel, mt5emu.progress_embedded = self.orig

    def test_build_error_shows_minimal_page_not_empty_box(self):
        real, n = U.wlabel, [0]

        def boom(*a, **k):
            n[0] += 1
            if n[0] == 1:
                raise RuntimeError("giả lập lỗi dựng trang")
            return real(*a, **k)
        U.wlabel = boom
        d = U.Mt5EmuDialog(App())
        d.open()                                                          # không được ném
        self.assertGreaterEqual(len(d.box.children), 2)                  # có chữ lỗi + hàng nút + nút Đóng
        joined = "\n".join(texts(d.box))
        self.assertIn("Không dựng được trang", joined)
        self.assertIn("giả lập lỗi dựng trang", joined)
        self.assertIn("Sao chép chẩn đoán", joined)
        self.assertIn("RuntimeError", d.ui_err)

    def test_open_error_in_state_reading_still_opens_with_fallback(self):
        orig = d_status = embedded.status
        embedded.status = lambda *a, **k: (_ for _ in ()).throw(OSError("đĩa lỗi"))
        self.addCleanup(lambda: setattr(embedded, "status", orig))
        d = U.Mt5EmuDialog(App())
        d.open()
        self.assertIn("đĩa lỗi", "\n".join(texts(d.box)))

    def test_tick_error_is_contained_and_reported_in_head(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.head = U.wlabel("", 12, U.TEXT)
        mt5emu.progress_embedded = lambda *a, **k: (_ for _ in ()).throw(ValueError("hỏng đọc"))
        d.tick()                                                          # không ném
        self.assertIn("hỏng đọc", d.head.text)
        self.assertIn("ValueError", d.ui_err)

    def test_fallback_itself_never_raises(self):
        d = U.Mt5EmuDialog(App())
        d.box = None                                                      # hỏng nặng: không có hộp
        d._fallback("thử", RuntimeError("x"))                            # không ném

    def test_diag_copy_includes_ui_error(self):
        d = U.Mt5EmuDialog(App())
        d.open()
        d.mode = "embedded"
        d.ui_err = "tick: ValueError hỏng đọc"
        got = []
        d.copy = lambda text, msg: got.append(text)
        d.emb_diag()
        self.assertIn("--- lỗi giao diện ---", got[0])
        self.assertIn("ValueError hỏng đọc", got[0])


if __name__ == "__main__":
    unittest.main()
