"""Kelly / VaR / CVaR theo từng lệnh (mcarlo.py): công thức đúng, cận Wilson, cảnh báo mẫu nhỏ, không bịa khi thiếu dữ liệu, và có mặt trong extra_stats/báo cáo/giao diện."""
import math
import os
import statistics
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from pyea import mcarlo                                         # noqa: E402


class TestKelly(unittest.TestCase):
    def test_textbook_value(self):
        tr = [2.0] * 6 + [-1.0] * 4                              # p = 0.6, b = 2 -> f* = 0.6 - 0.4/2 = 0.4
        k = mcarlo.kelly(tr)
        self.assertAlmostEqual(k["p"], 0.6)
        self.assertAlmostEqual(k["b"], 2.0)
        self.assertAlmostEqual(k["full"], 0.4)
        self.assertAlmostEqual(k["half"], 0.2)
        self.assertAlmostEqual(k["quarter"], 0.1)
        self.assertTrue(k["edge"])

    def test_even_odds_coin_with_no_edge_is_zero_or_negative(self):
        k = mcarlo.kelly([1.0, -1.0] * 20)                        # p = 0.5, b = 1 -> 0
        self.assertAlmostEqual(k["full"], 0.0, places=12)
        self.assertFalse(k["edge"])
        self.assertIn("KHÔNG có lợi thế", k["warning"])
        neg = mcarlo.kelly([1.0] * 3 + [-1.0] * 7)
        self.assertLess(neg["full"], 0)
        self.assertFalse(neg["edge"])

    def test_uses_average_win_over_average_loss_not_counts(self):
        k = mcarlo.kelly([10.0, 30.0, -5.0, -15.0])               # TB lãi 20, TB lỗ 10 -> b = 2, p = 0.5 -> 0.25
        self.assertAlmostEqual(k["full"], 0.25)

    def test_needs_both_wins_and_losses_and_never_invents_a_number(self):
        for tr, frag in (([], "chưa có lệnh"), ([1.0, 2.0], "cả lệnh thắng lẫn lệnh thua"), ([-1.0, -2.0], "cả lệnh thắng lẫn lệnh thua"), ([0.0, 0.0], "cả lệnh thắng lẫn lệnh thua")):
            k = mcarlo.kelly(tr)
            self.assertIsNone(k["full"])
            self.assertIn(frag, k["warning"])
            self.assertIn("không tính được", mcarlo.risk_text(tr, 1000.0))

    def test_small_sample_is_flagged_and_conservative_is_lower(self):
        k = mcarlo.kelly([2.0] * 6 + [-1.0] * 4)
        self.assertIn("rất nhiễu", k["warning"])
        self.assertLess(k["conservative"], k["full"])
        self.assertLess(k["p_low"], k["p"])
        big = mcarlo.kelly(([2.0] * 6 + [-1.0] * 4) * 30)
        self.assertNotIn("rất nhiễu", big["warning"])
        self.assertGreater(big["conservative"], k["conservative"])          # mẫu lớn -> cận dưới sát hơn

    def test_wilson_lower_bound_values(self):
        self.assertEqual(mcarlo.wilson_lower(0, 0), 0.0)
        self.assertAlmostEqual(mcarlo.wilson_lower(50, 100), 0.4038, places=3)      # giá trị chuẩn của Wilson 95%
        self.assertAlmostEqual(mcarlo.wilson_lower(10, 10), 0.7225, places=3)
        for w, n in ((0, 5), (5, 5), (3, 7)):
            self.assertTrue(0.0 <= mcarlo.wilson_lower(w, n) <= w / n + 1e-12)


class TestVar(unittest.TestCase):
    def test_historical_var_and_cvar_on_known_sample(self):
        tr = [float(x) for x in range(-10, 90)]                  # 100 lệnh: -10..89, lỗ 10 nặng nhất
        v = mcarlo.var_cvar(tr, 1000.0, 0.95)
        self.assertEqual(v["n"], 100)
        self.assertEqual(v["var"], 6.0)                          # đuôi 5% = 5 lệnh xấu nhất (lỗ 10..6); VaR = lệnh xấu thứ 5 = 6
        self.assertAlmostEqual(v["cvar"], 8.0)                   # TB(10,9,8,7,6)
        self.assertEqual(v["worst"], 10.0)
        self.assertAlmostEqual(v["var_pct"], v["var"] / 1000.0 * 100)

    def test_cvar_is_never_below_var_and_never_above_worst(self):
        import random
        rnd = random.Random(7)
        for _ in range(30):
            tr = [rnd.gauss(0.5, 4.0) for _ in range(rnd.randint(10, 200))]
            v = mcarlo.var_cvar(tr, 1000.0, rnd.choice([0.9, 0.95, 0.99]))
            self.assertGreaterEqual(v["cvar"] + 1e-9, v["var"])
            self.assertGreaterEqual(v["worst"] + 1e-9, v["cvar"])

    def test_gains_only_gives_zero_not_negative(self):
        v = mcarlo.var_cvar([1.0, 2.0, 3.0], 100.0)
        self.assertEqual((v["var"], v["cvar"], v["worst"]), (0.0, 0.0, 0.0))

    def test_normal_var_matches_formula(self):
        tr = [3.0, -2.0, 4.0, -1.0, 2.0, -3.0, 5.0, -2.0]
        v = mcarlo.var_cvar(tr, 100.0, 0.95)
        mu, sd = statistics.fmean(tr), statistics.pstdev(tr)
        self.assertAlmostEqual(v["var_normal"], max(0.0, -(mu - 1.6448536269514722 * sd)), places=9)

    def test_too_few_trades_and_bad_level(self):
        self.assertIsNone(mcarlo.var_cvar([5.0], 100.0)["var"])
        self.assertIsNone(mcarlo.var_cvar([], 100.0)["var"])
        for bad in (1.0, 0.2, 2):
            with self.assertRaises(ValueError):
                mcarlo.var_cvar([1.0, -1.0], 100.0, bad)

    def test_zero_start_balance_gives_no_percentages(self):
        v = mcarlo.var_cvar([-3.0, 2.0, -1.0, 4.0], 0.0)
        self.assertIsNone(v["var_pct"])
        self.assertIn("VaR", mcarlo.risk_text([-3.0, 2.0, -1.0, 4.0], 0.0))

    def test_small_sample_warning(self):
        self.assertIn("rất nhiễu", mcarlo.var_cvar([-1.0, 2.0] * 5, 100.0)["warning"])


class T:
    def __init__(self, p, ct=1767225600):
        self.profit, self.close_time = p, ct


class TestWiring(unittest.TestCase):
    TR = [T(p) for p in [3.0, -1.0, 2.0, -2.0, 4.0, -1.0, 1.5, -1.0, 2.5, -2.0] * 5]

    def test_extra_stats_carries_risk_block(self):
        ex = mcarlo.extra_stats(self.TR, 1000.0)
        self.assertEqual(set(ex["Rủi ro"]), {"kelly", "var"})
        self.assertIsNotNone(ex["Rủi ro"]["kelly"]["full"])

    def test_text_states_assumptions_and_has_no_double_percent_or_nan(self):
        t = mcarlo.risk_text(self.TR, 1000.0)
        for frag in ("Kelly:", "VaR 95%", "TỪNG LỆNH", "không phải lời khuyên"):
            self.assertIn(frag, t)
        self.assertNotIn("%%", t)
        self.assertNotIn("nan", t.lower())
        self.assertNotIn("-0.0%", t)

    def test_ui_and_report_use_it(self):
        root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pyea")
        self.assertIn("mcarlo.risk_text", open(os.path.join(root, "ui.py"), encoding="utf-8").read())
        self.assertIn("mcarlo.risk_text", open(os.path.join(root, "report.py"), encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()
