"""Giờ giao dịch + lịch nghỉ lễ VN (vnmarket.py), lịch tự cập nhật từ mạng (vncal.py), bộ chặn lệnh ngoài giờ của DNSE và api.vn_market_state."""
import copy
import datetime
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
import kivy_stub                                                 # noqa: E402
kivy_stub.install()

from pyea import vncal, vnmarket                                 # noqa: E402
from pyea.bridges import BridgeError                              # noqa: E402
from pyea.settings import clean_settings, default_settings        # noqa: E402


def ts(y, mo, d, h=0, mi=0):
    """epoch giây của thời điểm theo GIỜ VIỆT NAM."""
    return (datetime.datetime(y, mo, d, h, mi) - datetime.datetime(1970, 1, 1)).total_seconds() - 7 * 3600


class Base(unittest.TestCase):
    def setUp(self):
        vncal.reset()

    def tearDown(self):
        vncal.reset()


class TestSessions(Base):
    def phase(self, venue, y, mo, d, h, mi):
        return vnmarket.state(ts(y, mo, d, h, mi), venue)["phase"]

    def test_hose_day_walkthrough_tuesday(self):           # 2026-11-24 là Thứ Ba, không lễ
        want = [((8, 59), "pre_open"), ((9, 0), "ato"), ((9, 14), "ato"), ((9, 15), "continuous"), ((11, 29), "continuous"), ((11, 30), "lunch"), ((12, 59), "lunch"),
                ((13, 0), "continuous"), ((14, 29), "continuous"), ((14, 30), "atc"), ((14, 44), "atc"), ((14, 45), "post_close"), ((14, 59), "post_close"), ((15, 0), "closed")]
        for (h, m), ph in want:
            self.assertEqual(self.phase("hose", 2026, 11, 24, h, m), ph, "%02d:%02d" % (h, m))

    def test_trading_and_continuous_flags(self):
        f = lambda h, m: vnmarket.state(ts(2026, 11, 24, h, m), "hose")
        self.assertEqual((f(9, 5)["trading"], f(9, 5)["continuous"]), (True, False))          # ATO: khớp định kỳ, lệnh thị trường chưa hợp lệ
        self.assertEqual((f(10, 0)["trading"], f(10, 0)["continuous"]), (True, True))
        self.assertEqual((f(14, 35)["trading"], f(14, 35)["continuous"]), (True, False))      # ATC
        for h, m in ((12, 0), (14, 50), (16, 0), (8, 0)):
            self.assertEqual(f(h, m)["trading"], False, (h, m))

    def test_other_venues(self):
        self.assertEqual(self.phase("hnx", 2026, 11, 24, 9, 0), "continuous")                 # HNX không có ATO
        self.assertEqual(self.phase("hnx", 2026, 11, 24, 14, 30), "atc")
        self.assertEqual(self.phase("upcom", 2026, 11, 24, 14, 50), "continuous")             # UPCoM khớp tới 15:00
        self.assertEqual(self.phase("upcom", 2026, 11, 24, 15, 0), "closed")
        self.assertEqual(self.phase("deriv", 2026, 11, 24, 8, 45), "ato")                     # phái sinh mở 8:45
        self.assertEqual(self.phase("deriv", 2026, 11, 24, 14, 45), "closed")
        self.assertEqual(self.phase("hose", 2026, 11, 24, 8, 45), "pre_open")

    def test_weekend_and_unknown_venue(self):
        self.assertEqual(vnmarket.state(ts(2026, 11, 28, 10, 0))["phase"], "weekend")          # Thứ Bảy
        self.assertEqual(vnmarket.state(ts(2026, 11, 29, 10, 0))["phase"], "weekend")
        with self.assertRaises(ValueError):
            vnmarket.state(ts(2026, 11, 24, 10, 0), "nyse")

    def test_utc_instant_maps_to_vietnam_clock(self):
        t = (datetime.datetime(2026, 11, 24, 2, 30) - datetime.datetime(1970, 1, 1)).total_seconds()      # 02:30 UTC = 09:30 VN
        st = vnmarket.state(t)
        self.assertEqual((st["local"], st["phase"]), ("2026-11-24 09:30", "continuous"))
        t = (datetime.datetime(2026, 11, 24, 17, 30) - datetime.datetime(1970, 1, 1)).total_seconds()     # 17:30 UTC = 00:30 ngày sau theo VN (Thứ Tư)
        self.assertEqual(vnmarket.state(t)["local"], "2026-11-25 00:30")

    def test_next_open(self):
        st = vnmarket.state(ts(2026, 11, 27, 15, 30))                                           # Thứ Sáu chiều
        self.assertEqual(st["next_open_local"], "2026-11-30 09:00")                              # nhảy qua cuối tuần
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 7, 0))["next_open_local"], "2026-11-24 09:00")   # sáng cùng ngày
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 7, 0), "deriv")["next_open_local"], "2026-11-24 08:45")
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 12, 0))["next_open_local"], "2026-11-24 13:00")  # nghỉ trưa: mở lại phiên chiều cùng ngày
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 14, 50))["next_open_local"], "2026-11-25 09:00")  # sau đóng cửa: sáng hôm sau
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 12, 0), "upcom")["next_open_local"], "2026-11-24 13:00")
        self.assertEqual(vnmarket.state(ts(2026, 11, 24, 10, 0))["next_open_ts"], None)         # đang khớp: không có «lần mở kế»


class TestHolidays(Base):
    def test_verified_2026_closures(self):
        for d in ("2026-01-01", "2026-02-16", "2026-02-17", "2026-02-18", "2026-02-19", "2026-02-20", "2026-04-27", "2026-04-30", "2026-05-01", "2026-08-31", "2026-09-01", "2026-09-02"):
            y, m, dd = map(int, d.split("-"))
            st = vnmarket.state(ts(y, m, dd, 10, 0))
            self.assertEqual(st["phase"], "holiday", d)
            self.assertFalse(st["trading"], d)
            self.assertTrue(st["calendar_known"], d)
        for d in ("2026-01-02", "2026-02-23", "2026-04-28", "2026-05-04", "2026-09-03", "2026-08-28"):      # ngày liền kề: giao dịch bình thường
            y, m, dd = map(int, d.split("-"))
            self.assertEqual(vnmarket.state(ts(y, m, dd, 10, 0))["phase"], "continuous", d)

    def test_tet_next_open_skips_the_whole_closure(self):
        st = vnmarket.state(ts(2026, 2, 13, 16, 0))                                              # Thứ Sáu 13/2 sau giờ
        self.assertEqual(st["next_open_local"], "2026-02-23 09:00")                              # nghỉ 16-20/2, giao dịch lại 23/2
        st = vnmarket.state(ts(2026, 8, 28, 16, 0))                                              # Thứ Sáu trước Quốc khánh
        self.assertEqual(st["next_open_local"], "2026-09-03 09:00")

    def test_year_without_calendar_says_unknown_but_knows_fixed_holidays(self):
        st = vnmarket.state(ts(2027, 3, 3, 10, 0))                                               # Thứ Tư thường trong năm chưa có lịch
        self.assertEqual((st["phase"], st["calendar_known"]), ("continuous", False))
        self.assertIn("Chưa có lịch nghỉ lễ năm 2027", st["note"])
        self.assertIn("Chưa có lịch", vnmarket.describe(st))
        one = vnmarket.state(ts(2027, 1, 1, 10, 0))                                              # 1/1/2027 là Thứ Sáu: lễ cố định luật định
        self.assertEqual(one["phase"], "holiday")
        self.assertIn("lễ cố định", one["holiday"])
        self.assertFalse(one["calendar_known"])
        self.assertEqual(vnmarket.state(ts(2027, 9, 2, 10, 0))["phase"], "holiday")              # Thứ Năm
        self.assertEqual(vnmarket.state(ts(2027, 4, 30, 10, 0))["phase"], "holiday")             # Thứ Sáu
        self.assertEqual(vnmarket.state(ts(2027, 5, 1, 10, 0))["phase"], "weekend")              # Thứ Bảy: cuối tuần thắng

    def test_user_extra_holidays_win_and_parse_forgivingly(self):
        ex, bad = vnmarket.parse_extra("2027-02-08, 09/02/2027;10.02.2027\n2027-02-30 abc 2027-13-01 2027-02-11")
        self.assertEqual(sorted(ex), ["2027-02-08", "2027-02-09", "2027-02-10", "2027-02-11"])
        self.assertEqual(sorted(bad), ["2027-02-30", "2027-13-01", "abc"])
        self.assertEqual(vnmarket.parse_extra(None), ({}, []))
        st = vnmarket.state(ts(2027, 2, 8, 10, 0), extra="2027-02-08")
        self.assertEqual((st["phase"], st["calendar_known"]), ("holiday", True))
        self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0), extra=ex)["phase"], "holiday")
        self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0))["phase"], "continuous")          # không thêm thì không nghỉ

    def test_venue_for(self):
        for s in ("VN30F2412", "vn30f1m", "VN100F2503", "41I1G3000"):
            self.assertEqual(vnmarket.venue_for(s), "deriv", s)
        for s in ("HPG", "FPT", "", None):
            self.assertEqual(vnmarket.venue_for(s), "hose", s)
        self.assertEqual(vnmarket.venue_for("SHB", "hnx"), "hnx")
        self.assertEqual(vnmarket.venue_for("SHB", "bogus"), "hose")


class TestGuardMessage(Base):
    def test_closed_day_blocks_everything_but_open_day_blocks_only_market_outside_continuous(self):
        wk = vnmarket.state(ts(2026, 11, 28, 10, 0))
        self.assertIn("đóng cửa", vnmarket.guard_message(wk, "limit"))
        self.assertIn("đóng cửa", vnmarket.guard_message(wk, "market"))
        self.assertEqual(vnmarket.guard_message(vnmarket.state(ts(2026, 11, 24, 10, 0)), "market"), "")
        self.assertEqual(vnmarket.guard_message(vnmarket.state(ts(2026, 11, 24, 10, 0)), "limit"), "")
        for h, m in ((9, 5), (12, 0), (14, 35), (8, 0), (16, 0)):
            st = vnmarket.state(ts(2026, 11, 24, h, m))
            self.assertIn("lệnh thị trường", vnmarket.guard_message(st, "market").lower(), (h, m))
            self.assertEqual(vnmarket.guard_message(st, "limit"), "", (h, m))                    # LO ngoài giờ trong ngày giao dịch: không chặn


class TestCalendarInfo(Base):
    def test_feed_overrides_and_extends(self):
        self.assertEqual(vnmarket.calendar_info()["years"], [2026])
        vnmarket.set_feed({"2027-02-08": "Tết Âm lịch"}, {2027}, 123.0, "x")
        self.assertEqual(vnmarket.calendar_info()["years"], [2026, 2027])
        st = vnmarket.state(ts(2027, 2, 8, 10, 0))
        self.assertEqual((st["phase"], st["holiday"], st["calendar_known"]), ("holiday", "Tết Âm lịch", True))
        self.assertEqual(vnmarket.state(ts(2027, 3, 3, 10, 0))["calendar_known"], True)        # năm đã khai báo đủ
        self.assertEqual(vnmarket.state(ts(2028, 3, 3, 10, 0))["calendar_known"], False)
        vnmarket.set_feed(None)
        self.assertEqual(vnmarket.calendar_info()["years"], [2026])

    def test_user_extra_beats_feed(self):
        vnmarket.set_feed({"2027-02-08": "Tết Âm lịch"}, {2027})
        self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0), extra="2027-02-08")["holiday"], "ngày nghỉ bạn thêm")


GOOD = {"version": 1, "updated": "2026-11-24", "years": [2027],
        "holidays": {"2027-01-01": "Tết Dương lịch", "2027-02-08": "Tết Âm lịch", "2027-02-09": "Tết Âm lịch", "2027-04-30": "Giải phóng miền Nam", "2027-09-02": "Quốc khánh"}}


def bad(**ch):
    d = copy.deepcopy(GOOD)
    for k, v in ch.items():
        if v is None:
            d.pop(k, None)
        else:
            d[k] = v
    return d


class TestValidate(Base):
    def test_good_document(self):
        h, y = vncal.validate(GOOD)
        self.assertEqual(y, {2027})
        self.assertEqual(h["2027-02-08"], "Tết Âm lịch")

    def test_shipped_file_is_valid_and_equals_builtin_table(self):
        with open(os.path.join(HERE, "..", "docs", "vn_holidays.json"), encoding="utf-8") as f:
            h, y = vncal.validate(json.load(f))
        self.assertEqual(h, vnmarket.HOLIDAYS)
        self.assertEqual(y, set(vnmarket.KNOWN_YEARS))

    def test_every_suspicious_shape_is_rejected(self):
        h = GOOD["holidays"]
        cases = {
            "không phải dict": [1, 2],
            "version sai": bad(version=2),
            "thiếu version": bad(version=None),
            "thiếu holidays": bad(holidays=None),
            "holidays là list": bad(holidays=["2027-01-01"]),
            "years không phải list": bad(years=2027),
            "năm là chuỗi": bad(years=["2027"]),
            "năm là bool": bad(years=[True]),
            "năm ngoài khoảng": bad(years=[1999]),
            "quá nhiều năm": bad(years=list(range(2020, 2032))),
            "khoá sai định dạng": bad(holidays=dict(h, **{"27-02-08": "x"})),
            "ngày không có thật": bad(holidays=dict(h, **{"2027-02-30": "x"})),
            "lý do không phải chuỗi": bad(holidays=dict(h, **{"2027-02-10": 5})),
            "năm ngoài khoảng 2": bad(holidays=dict(h, **{"3000-01-01": "x"})),
            "thiếu lễ cố định 1/1/2027 (T6)": bad(holidays={k: v for k, v in h.items() if k != "2027-01-01"}),
            "thiếu lễ cố định 2/9/2027 (T5)": bad(holidays={k: v for k, v in h.items() if k != "2027-09-02"}),
            "thiếu lễ cố định 30/4/2027 (T6)": bad(holidays={k: v for k, v in h.items() if k != "2027-04-30"}),
            "quá nhiều ngày/năm": bad(holidays=dict(h, **{"2027-06-%02d" % i: "x" for i in range(1, 31)}, **{"2027-07-%02d" % i: "x" for i in range(1, 15)})),
        }
        for name, doc in cases.items():
            with self.assertRaises(vncal.FeedError, msg=name):
                vncal.validate(doc)

    def test_fixed_holiday_on_weekend_need_not_be_listed(self):
        doc = {"version": 1, "years": [2027], "holidays": {"2027-01-01": "a", "2027-04-30": "b", "2027-09-02": "c"}}       # 1/5/2027 là Thứ Bảy
        vncal.validate(doc)
        doc2 = {"version": 1, "years": [2026], "holidays": {"2026-01-01": "a", "2026-04-30": "b", "2026-05-01": "c", "2026-09-02": "d"}}
        vncal.validate(doc2)

    def test_reason_text_is_sanitised(self):
        h, _ = vncal.validate(bad(holidays=dict(GOOD["holidays"], **{"2027-02-10": "a\x00b\x1b[31m" + "x" * 200})))
        r = h["2027-02-10"]
        self.assertLessEqual(len(r), 80)
        self.assertNotRegex(r, r"[\x00-\x1f]")
        self.assertEqual(vncal.validate(bad(holidays=dict(GOOD["holidays"], **{"2027-02-10": "   "})))[0]["2027-02-10"], "Ngày nghỉ lễ")


class TestFetch(Base):
    def test_resolve_source(self):
        self.assertEqual(vncal.resolve_source("auto", "ten/kho"), "https://raw.githubusercontent.com/ten/kho/HEAD/docs/vn_holidays.json")
        self.assertEqual(vncal.resolve_source("auto", ""), "")
        self.assertEqual(vncal.resolve_source("auto", "khong hop le"), "")
        self.assertEqual(vncal.resolve_source("auto", "a/b/c"), "")
        for off in ("", "off", "OFF", None):
            self.assertEqual(vncal.resolve_source(off, "a/b"), "")
        self.assertEqual(vncal.resolve_source("https://x.y/z.json", ""), "https://x.y/z.json")

    def test_http_plain_is_refused_and_local_file_works_and_size_capped(self):
        with self.assertRaises(vncal.FeedError):
            vncal.fetch_text("http://example.com/x.json")
        with self.assertRaises(vncal.FeedError):
            vncal.fetch_text("")
        d = tempfile.mkdtemp()
        try:
            p = os.path.join(d, "h.json")
            open(p, "w", encoding="utf-8").write(json.dumps(GOOD))
            self.assertEqual(json.loads(vncal.fetch_text(p))["version"], 1)
            self.assertEqual(json.loads(vncal.fetch_text("file://" + p))["version"], 1)
            big = os.path.join(d, "big.json")
            open(big, "w").write(" " * (vncal.MAX_BYTES + 10))
            with self.assertRaises(vncal.FeedError):
                vncal.fetch_text(big)
        finally:
            shutil.rmtree(d, ignore_errors=True)


class Clock:
    def __init__(self, t=1_800_000_000.0):
        self.t = t

    def __call__(self):
        return self.t


class TestHolidayFeed(Base):
    def feed(self, text, **kw):
        calls = []

        def fetch(src):
            calls.append(src)
            if isinstance(text, Exception):
                raise text
            return text() if callable(text) else text
        clock = kw.pop("clock", Clock())
        f = vncal.HolidayFeed("https://example.test/h.json", fetch=fetch, clock=clock, **kw)
        return f, calls, clock

    def test_refresh_success_applies_to_market_and_status(self):
        f, calls, clock = self.feed(json.dumps(GOOD))
        ok, err = f.refresh()
        self.assertEqual((ok, err), (True, ""))
        self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0))["holiday"], "Tết Âm lịch")
        s = f.status()
        self.assertEqual((s["years"], s["holidays"], s["error"], s["updated"]), ([2027], 5, "", "2026-11-24"))

    def test_ttl_and_retry_backoff(self):
        f, calls, clock = self.feed(json.dumps(GOOD), ttl=3600.0)
        self.assertTrue(f.stale())
        f.refresh()
        self.assertFalse(f.stale())
        clock.t += 3599
        self.assertFalse(f.stale())
        clock.t += 2
        self.assertTrue(f.stale())
        self.assertEqual(f.refresh(), (True, ""))
        self.assertEqual(len(calls), 2)
        self.assertEqual(f.refresh(), (False, ""))                         # chưa cũ: không gọi lại
        self.assertEqual(len(calls), 2)

    def test_network_error_keeps_old_data_and_retries_within_an_hour(self):
        state = {"text": json.dumps(GOOD)}
        f, calls, clock = self.feed(lambda: state["text"] if isinstance(state["text"], str) else (_ for _ in ()).throw(state["text"]), ttl=24 * 3600.0)
        f.refresh()
        clock.t += 25 * 3600
        state["text"] = OSError("mất mạng")
        ok, err = f.refresh()
        self.assertFalse(ok)
        self.assertIn("mất mạng", err)
        self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0))["holiday"], "Tết Âm lịch")      # vẫn dùng lịch cũ
        self.assertFalse(f.stale())                                                           # vừa thử xong, chưa thử lại ngay
        clock.t += 3601
        self.assertTrue(f.stale())                                                            # sau 1 giờ thử lại
        state["text"] = json.dumps(GOOD)
        self.assertEqual(f.refresh(), (True, ""))
        self.assertEqual(f.status()["error"], "")

    def test_bad_document_is_rejected_whole_and_old_data_kept(self):
        state = {"text": json.dumps(GOOD)}
        f, calls, clock = self.feed(lambda: state["text"], ttl=10.0)
        f.refresh()
        for txt in ("không phải json", json.dumps([1]), json.dumps(bad(years=[2027], holidays={"2027-02-08": "x"})), "�"):
            clock.t += 7200
            state["text"] = txt
            ok, err = f.refresh()
            self.assertFalse(ok, txt)
            self.assertTrue(err, txt)
            self.assertEqual(vnmarket.state(ts(2027, 2, 9, 10, 0))["holiday"], "Tết Âm lịch", txt)   # lịch tốt trước đó còn nguyên

    def test_cache_roundtrip_survives_restart_without_network(self):
        d = tempfile.mkdtemp()
        try:
            cp = os.path.join(d, "c.json")
            f, _, _ = self.feed(json.dumps(GOOD), cache_path=cp)
            f.refresh()
            vncal.reset()
            g, calls, _ = self.feed(OSError("offline"), cache_path=cp)
            g.apply()                                                                             # chưa gọi mạng: có lịch ngay từ đệm
            self.assertEqual(calls, [])
            self.assertEqual(vnmarket.state(ts(2027, 2, 8, 10, 0))["holiday"], "Tết Âm lịch")
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_tampered_or_foreign_cache_is_ignored(self):
        d = tempfile.mkdtemp()
        try:
            cp = os.path.join(d, "c.json")
            doc = bad(holidays={"2027-02-08": "x"})                                               # cụt: thiếu lễ cố định
            json.dump({"source": "https://example.test/h.json", "loaded_at": 1.0, "doc": doc}, open(cp, "w"))
            f, _, _ = self.feed("{}", cache_path=cp)
            self.assertEqual((f.holidays, f.loaded_at), ({}, 0.0))
            json.dump({"source": "https://khac.test/x.json", "loaded_at": 1.0, "doc": GOOD}, open(cp, "w"))
            g, _, _ = self.feed("{}", cache_path=cp)
            self.assertEqual(g.holidays, {})                                                      # nguồn khác: không dùng
            open(cp, "w").write("{hỏng")
            h, _, _ = self.feed("{}", cache_path=cp)
            self.assertEqual(h.holidays, {})
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_refresh_never_raises_on_garbage(self):
        for t in (None, 5, b"x", object()):
            f, _, _ = self.feed(lambda t=t: t)
            self.assertFalse(f.refresh()[0])

    def test_concurrent_refresh_runs_once(self):
        gate, started = threading.Event(), threading.Event()
        count = []

        def slow():
            count.append(1)
            started.set()
            gate.wait(5)
            return json.dumps(GOOD)
        f, _, _ = self.feed(slow)
        t = threading.Thread(target=f.refresh)
        t.start()
        started.wait(5)
        self.assertEqual(f.refresh(force=True), (False, ""))                                      # đang tải: không tải chồng
        gate.set()
        t.join(5)
        self.assertEqual(len(count), 1)


class TestEnsure(Base):
    def test_off_without_repo_and_default_does_no_network(self):
        called = []
        self.assertIsNone(vncal.ensure({"vn_holidays_source": "auto", "update_repo": ""}, fetch=lambda s: called.append(s), background=False))
        self.assertIsNone(vncal.ensure({"vn_holidays_source": "off", "update_repo": "a/b"}, fetch=lambda s: called.append(s), background=False))
        self.assertEqual(called, [])

    def test_auto_with_repo_fetches_once_then_uses_cache_until_stale(self):
        d = tempfile.mkdtemp()
        try:
            calls = []

            def fetch(src):
                calls.append(src)
                return json.dumps(GOOD)
            clk = Clock()
            st = {"vn_holidays_source": "auto", "update_repo": "a/b"}
            f = vncal.ensure(st, d, fetch=fetch, clock=clk, background=False)
            self.assertEqual(calls, ["https://raw.githubusercontent.com/a/b/HEAD/docs/vn_holidays.json"])
            self.assertEqual(f.status()["years"], [2027])
            vncal.ensure(st, d, fetch=fetch, clock=clk, background=False)
            self.assertEqual(len(calls), 1)
            self.assertTrue(os.path.exists(os.path.join(d, "vn_holidays_cache.json")))
            clk.t += 25 * 3600
            vncal.ensure(st, d, fetch=fetch, clock=clk, background=False)
            self.assertEqual(len(calls), 2)
        finally:
            shutil.rmtree(d, ignore_errors=True)

    def test_switching_source_off_removes_downloaded_calendar(self):
        vncal.ensure({"vn_holidays_source": "x.json", "update_repo": ""}, None, fetch=lambda s: json.dumps(GOOD), background=False)
        self.assertEqual(vnmarket.calendar_info()["years"], [2026, 2027])
        vncal.ensure({"vn_holidays_source": "off"}, None, background=False)
        self.assertEqual(vnmarket.calendar_info()["years"], [2026])

    def test_background_thread_does_not_block_caller(self):
        gate = threading.Event()

        def slow(src):
            gate.wait(5)
            return json.dumps(GOOD)
        t0 = time.time()
        vncal.ensure({"vn_holidays_source": "x.json"}, None, fetch=slow, background=True)
        self.assertLess(time.time() - t0, 1.0)
        gate.set()
        th = vncal._CUR["thread"]
        th.join(5)
        self.assertEqual(vnmarket.calendar_info()["years"], [2026, 2027])


class TestSessionHook(Base):
    def make(self, **over):
        from test_recon_cache import make as make_paper
        s = make_paper(**over)
        s.sync = False
        return s

    def test_not_called_for_non_vn_users(self):
        s = self.make(exchange="simulated", update_repo="a/b")
        orig = vncal.ensure
        seen = []
        vncal.ensure = lambda *a, **k: seen.append(1)
        try:
            s._vncal_t = 0.0
            s._check_vn_calendar()
        finally:
            vncal.ensure = orig
        self.assertEqual(seen, [])

    def test_called_for_dnse_or_guard_and_throttled(self):
        for over in ({"exchange": "dnse"}, {"vn_market_guard": "block"}):
            s = self.make(**over)
            orig = vncal.ensure
            seen = []
            vncal.ensure = lambda *a, **k: seen.append(1)
            try:
                s._vncal_t = 0.0
                s._check_vn_calendar()
                s._check_vn_calendar()
            finally:
                vncal.ensure = orig
            self.assertEqual(seen, [1], over)

    def test_backtest_never_touches_network(self):
        s = self.make(exchange="dnse")
        s.sync = True
        orig = vncal.ensure
        seen = []
        vncal.ensure = lambda *a, **k: seen.append(1)
        try:
            s._vncal_t = 0.0
            s._check_vn_calendar()
        finally:
            vncal.ensure = orig
        self.assertEqual(seen, [])

    def test_error_in_hook_is_logged_not_raised(self):
        s = self.make(exchange="dnse")
        orig = vncal.ensure
        vncal.ensure = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        try:
            s._vncal_t = 0.0
            s._check_vn_calendar()
        finally:
            vncal.ensure = orig


class TestDnseGuard(Base):
    def backend(self, guard, now, holidays=""):
        from test_dnse_v1 import mk
        b, h, st = mk(guard=guard, holidays=holidays)
        b.now = lambda: now
        b.tt, b.tt_t = "TT", 0.0
        return b, h

    def posted(self, h):
        return [c for c in h.calls if c[0] == "POST" and c[1] == "/order-service/v2/orders"]

    def test_default_off_never_blocks(self):
        b, h = self.backend("off", ts(2026, 11, 28, 10, 0))                      # Thứ Bảy
        self.assertEqual(b.market("HPG", "buy", 100)["order_id"], "99")
        self.assertEqual(len(self.posted(h)), 1)

    def test_block_refuses_new_orders_on_closed_day_without_calling_the_exchange(self):
        b, h = self.backend("block", ts(2026, 11, 28, 10, 0))
        for fn in (lambda: b.market("HPG", "buy", 100), lambda: b.place_pending("HPG", "buy", "limit", 100, 25000.0, 0.0, 0)):
            with self.assertRaises(BridgeError) as cm:
                fn()
            self.assertIn("đóng cửa", str(cm.exception))
        self.assertEqual(self.posted(h), [])

    def test_holiday_blocks_and_user_added_holiday_blocks(self):
        b, h = self.backend("block", ts(2026, 9, 1, 10, 0))
        with self.assertRaises(BridgeError):
            b.market("HPG", "buy", 100)
        b2, h2 = self.backend("block", ts(2027, 2, 8, 10, 0), holidays="2027-02-08")
        with self.assertRaises(BridgeError):
            b2.market("HPG", "buy", 100)
        b3, h3 = self.backend("block", ts(2027, 2, 8, 10, 0))                    # chưa thêm ngày -> coi là mở
        self.assertEqual(b3.market("HPG", "buy", 100)["order_id"], "99")

    def test_market_order_blocked_outside_continuous_but_limit_allowed(self):
        for hh, mm in ((9, 5), (12, 0), (14, 35), (8, 0)):
            b, h = self.backend("block", ts(2026, 11, 24, hh, mm))
            with self.assertRaises(BridgeError) as cm:
                b.market("HPG", "buy", 100)
            self.assertIn("lệnh thị trường", str(cm.exception).lower())
            self.assertEqual(b.place_pending("HPG", "buy", "limit", 100, 25000.0, 0.0, 0), "99", (hh, mm))
        b, h = self.backend("block", ts(2026, 11, 24, 10, 0))
        self.assertEqual(b.market("HPG", "buy", 100)["order_id"], "99")

    def test_derivative_uses_derivative_hours(self):
        b, h = self.backend("block", ts(2026, 11, 24, 8, 50))                      # phái sinh đang ATO: lệnh thị trường (MTL) chưa hợp lệ
        with self.assertRaises(BridgeError):
            b.market("VN30F2612", "buy", 1)

    def test_closing_a_position_is_never_blocked(self):
        b, h = self.backend("block", ts(2026, 11, 28, 10, 0))                      # cuối tuần
        r = b.close_position("5", 100)
        self.assertEqual(r["order_id"], "99")
        self.assertEqual(len(self.posted(h)), 1)

    def test_make_backend_reads_settings(self):
        from pyea.dnse import make_backend
        b = make_backend({"dnse_username": "u", "dnse_password": "p", "vn_market_guard": "block", "vn_extra_holidays": "2027-02-08, 2027-02-09"})
        self.assertEqual(b.guard, "block")
        self.assertEqual(sorted(b.holidays), ["2027-02-08", "2027-02-09"])
        b2 = make_backend({"dnse_username": "u", "dnse_password": "p"})
        self.assertEqual((b2.guard, b2.holidays), ("off", {}))
        b3 = make_backend({"dnse_username": "u", "dnse_password": "p", "vn_market_guard": "weird"})
        self.assertEqual(b3.guard, "off")                                          # giá trị lạ -> an toàn là KHÔNG chặn bừa cũng không bật ngầm


class TestSettingsAndApi(Base):
    def test_settings_defaults_and_validation(self):
        d = default_settings()
        self.assertEqual((d["vn_market_guard"], d["vn_extra_holidays"], d["vn_holidays_source"]), ("off", "", "auto"))
        c = clean_settings({"vn_market_guard": "block", "vn_holidays_source": "https://x.y/z.json", "vn_extra_holidays": "2027-02-08"})
        self.assertEqual((c["vn_market_guard"], c["vn_holidays_source"], c["vn_extra_holidays"]), ("block", "https://x.y/z.json", "2027-02-08"))
        self.assertEqual(clean_settings({"vn_market_guard": "zzz"})["vn_market_guard"], "off")

    def test_dnse_settings_group_and_backend_cache_key(self):
        from pyea import settings as S
        grp = S.BACKEND_KEYS["dnse"] if hasattr(S, "BACKEND_KEYS") else None
        src = open(os.path.join(HERE, "..", "pyea", "bridges.py"), encoding="utf-8").read()
        for k in ("vn_market_guard", "vn_extra_holidays"):
            self.assertIn('"%s"' % k, src)                                          # đổi cài đặt phải dựng lại backend, không dùng bản cũ
        if grp is not None:
            self.assertTrue({"vn_market_guard", "vn_extra_holidays", "vn_holidays_source"} <= grp)

    def test_bot_api_vn_market_state_uses_sim_time_symbol_and_extra_holidays(self):
        from pyea.engine import BotContext
        from test_recon_cache import make as make_paper
        s = make_paper(vn_extra_holidays="2026-11-24")
        s._now = lambda: ts(2026, 11, 24, 10, 0)

        class R:
            session, symbol = s, "VN30F2612"
        api = BotContext(R())
        st = api.vn_market_state()
        self.assertEqual((st["venue"], st["phase"], st["holiday"]), ("deriv", "holiday", "ngày nghỉ bạn thêm"))
        s2 = make_paper()
        s2._now = lambda: ts(2026, 11, 24, 10, 0)

        class R2:
            session, symbol = s2, "HPG"
        a2 = BotContext(R2())
        self.assertEqual((a2.vn_market_state()["venue"], a2.vn_market_state()["phase"]), ("hose", "continuous"))
        self.assertEqual(a2.vn_market_state("upcom")["venue"], "upcom")


if __name__ == "__main__":
    unittest.main()
