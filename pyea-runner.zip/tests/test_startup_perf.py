"""1.9.40: khởi động nhanh - form Cài đặt dựng lười, bot chỉ nạp dần, không quét/đọc file bot hai lần."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(__file__))
import kivy_stub  # noqa: E402

kivy_stub.install()
from pyea import loader, ui  # noqa: E402


def fresh_app():
    app = ui.PyEAApp()
    app.user_data_dir = tempfile.mkdtemp()
    app.build()
    return app


class TestStartupPerf(unittest.TestCase):
    def setUp(self):
        kivy_stub.SCHEDULED.clear()

    def test_settings_form_lazy_but_transparent(self):
        app = fresh_app()
        st = app.settings_tab
        self.assertFalse(st.built)                          # chưa dựng ~780 widget lúc khởi động
        form = st.gform                                     # truy cập từ bất kỳ nơi nào vẫn có form đầy đủ
        self.assertTrue(st.built)
        self.assertIn("tick_interval", form.inputs)
        self.assertIsNotNone(form.ctrl["tick_interval"])    # form.ctrl[...] vẫn dùng được: dựng ô theo yêu cầu
        self.assertIs(st.gform, form)                       # không dựng lại lần hai

    def test_param_form_lazy_mode_still_builds_in_steps(self):
        """ParamForm(lazy=True) (dùng cho các form nhỏ ở nơi khác): dựng từng phần theo ngân sách, kết quả bằng dựng một lượt."""
        from pyea.settings import GLOBAL_INPUTS
        from pyea.ui_widgets import ParamForm
        vals = {}
        g = ParamForm(GLOBAL_INPUTS, vals, lazy=True)
        self.assertTrue(g.pending)
        self.assertEqual(g.progress[0], 0)
        self.assertFalse(g.step(0))                                       # ngân sách 0 = đúng MỘT hàng mỗi lượt (luôn tiến lên)
        self.assertEqual(g.progress[0], 1)
        g.finish()
        self.assertFalse(g.pending)
        self.assertEqual(sorted(g.ctrl), sorted(ParamForm(GLOBAL_INPUTS, vals).ctrl))

    def test_settings_tab_builds_only_headers_not_inputs(self):
        """Log thật (Cat S52): dựng 187 ô một lượt mất 18.9 s, khung hình dài nhất 0.69 s => kéo trang giật. Nay lúc mở tab chỉ dựng tiêu đề các mục."""
        import test_ui_smoke as T
        from pyea.settings import API_GROUPS, GLOBAL_INPUTS
        app = fresh_app()
        st = app.settings_tab
        st.build(app.settings, progressive=True)
        g = st._gform
        self.assertTrue(g.deferred)
        self.assertEqual(len(g.ctrl), 0)                                  # chưa dựng ô nhập nào
        self.assertEqual(g.progress[0], 0)
        self.assertFalse(g.pending)
        self.assertEqual(len(st.folds), 13)
        self.assertNotIn("other", st.folds, "có nhóm ô chưa được xếp vào mục nào của SETTINGS_FOLDS")
        collapsed = sum(1 for _ in T.walk(st))
        self.assertLess(collapsed, 120, collapsed)                        # trước đây ~455 widget luôn nằm trong cây
        self.assertTrue(all(not f.is_open and f.body.parent is None for f in st.folds.values()))
        every = set()
        for f in st.folds.values():
            every.update(f.state.get("groups", ()))
        listed = set()
        for fid, _t, groups, _x in ui.SETTINGS_FOLDS:
            listed.update(groups)
        self.assertEqual(listed | set(API_GROUPS), {i.group for i in GLOBAL_INPUTS.values()}, "mọi nhóm ô phải thuộc đúng một mục (hoặc mục API)")
        self.assertEqual(sum(f.count for f in st.folds.values()) + sum(1 for i in GLOBAL_INPUTS.values() if i.group in API_GROUPS), len(GLOBAL_INPUTS))
        st.expand_all()
        self.assertGreater(sum(1 for _ in T.walk(st)), 3 * collapsed)     # mở hết mới có đủ ô: đúng là phần nặng đã được hoãn
        self.assertEqual(sorted(k for k in g.ctrl if g.inputs[k].group not in API_GROUPS),
                         sorted(k for k, i in GLOBAL_INPUTS.items() if i.group not in API_GROUPS))

    def test_group_not_listed_in_the_table_falls_into_other_fold_instead_of_vanishing(self):
        import copy
        from collections import OrderedDict
        extra = copy.copy(ui.GLOBAL_INPUTS["tick_interval"])
        extra.group = "Nhóm lạ mới"
        patched = OrderedDict(ui.GLOBAL_INPUTS)
        patched["zz_new_key"] = extra
        orig = ui.GLOBAL_INPUTS
        ui.GLOBAL_INPUTS = patched
        try:
            app = fresh_app()
            st = app.settings_tab
            st.build(app.settings)
            self.assertIn("other", st.folds)
            self.assertEqual(st.folds["other"].count, 1)
            st.open_fold("other", finish=True)
            self.assertIsNotNone(st.gform.ctrl.get("zz_new_key"))
            self.assertIn("zz_new_key", st.gform.read()[0])
        finally:
            ui.GLOBAL_INPUTS = orig

    def test_opening_a_fold_builds_its_rows_in_steps_and_closing_detaches_them(self):
        app = fresh_app()
        st = app.settings_tab
        st.build(app.settings)
        st._fold_budget = 0                                               # đúng một hàng mỗi lượt (máy chậm): thấy được từng bước
        g = st._gform
        fold = st.folds["trade"]
        n = fold.count
        self.assertGreater(n, 20)
        fold.set_open(True)
        self.assertIs(fold.body.parent, fold)
        self.assertIn("▼", fold.head.text)
        self.assertEqual(g.group_progress(fold.state["groups"])[0], 0)    # mở xong chưa dựng hàng nào: màn hình không bị chặn
        tick = fold.state["tick"]
        self.assertTrue(tick())                                           # một lượt dựng được >= 1 hàng, còn dở
        self.assertGreaterEqual(g.group_progress(fold.state["groups"])[0], 1)
        self.assertIn("đang mở", fold.head.text)
        guard = 0
        while tick():
            guard += 1
            self.assertLess(guard, 5000)
        self.assertEqual(g.group_progress(fold.state["groups"]), (n, n))
        self.assertNotIn("đang mở", fold.head.text)
        self.assertIsNone(fold.state["ev"])
        fold.set_open(False)                                              # đóng: thân gỡ khỏi cây (không tốn vẽ/cuộn), ô vẫn giữ giá trị
        self.assertIsNone(fold.body.parent)
        self.assertIn("▶", fold.head.text)
        fold.set_open(True)
        self.assertIs(fold.body.parent, fold)
        self.assertIsNone(fold.state["ev"])                               # đã dựng xong thì mở lại không dựng lại

    def test_closing_a_fold_midway_pauses_and_reopen_resumes(self):
        app = fresh_app()
        st = app.settings_tab
        st.build(app.settings)
        st._fold_budget = 0
        g = st._gform
        fold = st.folds["trade"]
        fold.set_open(True)
        tick = fold.state["tick"]
        tick()
        done = g.group_progress(fold.state["groups"])[0]
        fold.set_open(False)
        self.assertFalse(tick())                                          # đóng giữa chừng: vòng dựng dừng, không dựng ngầm
        self.assertIsNone(fold.state["ev"])
        self.assertEqual(g.group_progress(fold.state["groups"])[0], done)
        fold.set_open(True)
        self.assertIsNotNone(fold.state["ev"])                            # mở lại: dựng tiếp từ chỗ dở
        tick = fold.state["tick"]
        while tick():
            pass
        self.assertTrue(all(g.group_done(x) for x in fold.state["groups"]))

    def test_unbuilt_fields_read_save_and_update_like_built_ones(self):
        """Ô chưa dựng phải đọc/lưu/đổi giá trị y như ô đã dựng: Lưu không được mất hay đổi ô nào."""
        from pyea.settings import GLOBAL_INPUTS
        from pyea.ui_widgets import ParamForm
        app = fresh_app()
        st = app.settings_tab
        st.build(app.settings)
        g = st._gform
        eager = ParamForm(GLOBAL_INPUTS, app.settings)
        self.assertEqual(g.read(), eager.read())                          # chưa mở mục nào mà đọc ra y hệt bản dựng đủ
        self.assertEqual(len(g.ctrl), 0)
        g.update_values({"ui_refresh": 7, "background_service": True})
        eager.update_values({"ui_refresh": 7, "background_service": True})
        self.assertEqual(len(g.ctrl), 0)                                  # đổi giá trị cũng không bắt buộc dựng ô
        self.assertEqual(g.read(), eager.read())
        self.assertEqual(g.read()[0]["ui_refresh"], 7)
        g.set_values({"ui_refresh": 7, "tick_interval": 2.5})             # set_values đặt MỌI khoá (khoá không nêu về mặc định)
        eager.set_values({"ui_refresh": 7, "tick_interval": 2.5})
        self.assertEqual(g.read(), eager.read())
        self.assertEqual(len(g.ctrl), 0)
        grp = GLOBAL_INPUTS["ui_refresh"].group
        fid = next(f for f, _t, groups, _x in ui.SETTINGS_FOLDS if grp in groups)
        fold = st.open_fold(fid, finish=True)                             # dựng ô thật: phải hiện đúng giá trị đã đổi lúc còn chưa dựng
        self.assertEqual(g.ctrl["ui_refresh"].text, str(GLOBAL_INPUTS["ui_refresh"].display(7)))
        self.assertTrue(g.ctrl["background_service"].active if "background_service" in g.ctrl else True)
        g.ctrl["ui_refresh"].text = "9"                                   # người dùng gõ vào ô đã dựng
        eager.ctrl["ui_refresh"].text = "9"
        self.assertEqual(g.read(), eager.read())
        g.reset()
        eager.reset()
        self.assertEqual(g.read(), eager.read())

    def test_ctrl_access_builds_on_demand_but_get_does_not(self):
        app = fresh_app()
        st = app.settings_tab
        g = st.gform
        self.assertIsNone(g.ctrl.get("tick_interval"))
        self.assertNotIn("tick_interval", g.ctrl)
        c = g.ctrl["tick_interval"]                                       # nơi cũ (và test cũ) đọc form.ctrl[...] vẫn chạy
        self.assertIs(g.ctrl.get("tick_interval"), c)
        with self.assertRaises(KeyError):
            g.ctrl["khong_co_khoa_nay"]

    def test_api_dialog_reads_and_writes_without_building_api_rows(self):
        """Hộp thoại API tự dựng ô riêng cho sàn đang chọn: 47 hàng của mục API không cần dựng (trước đây dựng hết, vô hình)."""
        import kivy_stub as ks
        app = fresh_app()
        st = app.settings_tab
        g = st.gform
        g.set_raw("exchange", "binance_spot")
        g.set_raw("api_key" if "api_key" in g.inputs else g._sec_keys[0], "abc")
        built_before = len(g.ctrl)
        g.open_api_dialog()
        self.assertEqual(len(g.ctrl), built_before, "mở hộp thoại API không được dựng hàng nào của mục API")
        for k in g._sec_keys:
            self.assertIsNone(g.ctrl.get(k))
        ks.OPEN_POPUPS.clear()

    def test_rebuild_cancels_pending_fold_jobs(self):
        app = fresh_app()
        st = app.settings_tab
        st.build(app.settings)
        st._fold_budget = 0
        fold = st.folds["trade"]
        fold.set_open(True)
        tick = fold.state["tick"]
        first = st._gform
        st.build(app.settings)                                            # khôi phục sao lưu: dựng lại, bỏ việc dựng dở
        self.assertIsNot(st._gform, first)
        self.assertFalse(tick())
        self.assertEqual(st._gform.progress[0], 0)

    def test_build_and_fold_open_leave_boot_log_lines_for_diagnostics(self):
        from pyea import bootlog
        lines = []
        orig = bootlog.crumb
        bootlog.crumb = lambda m, *a, **k: lines.append(m)
        try:
            app = fresh_app()
            st = app.settings_tab
            st.build(app.settings)
            fold = st.open_fold("trade", finish=True)
        finally:
            bootlog.crumb = orig
        self.assertTrue(any("cài đặt: dựng 13 mục sổ xuống" in x for x in lines), lines)
        self.assertTrue(any("cài đặt: mở mục «Giao dịch & an toàn»" in x for x in lines), lines)

    def test_progressive_form_in_ui_uses_progressive_for_tab_open(self):
        import inspect
        src = inspect.getsource(ui)
        self.assertEqual(src.count("settings_tab.build(self.settings, progressive=True)"), 2)   # mở tab + khởi động đang ở tab Cài đặt
        self.assertNotIn("settings_tab.build(self.settings)", src)

    def test_only_selected_bot_inspected_at_startup(self):
        calls = []
        orig = ui.inspect_bot
        ui.inspect_bot = lambda *a, **k: (calls.append(a[0]), orig(*a, **k))[1]
        try:
            app = fresh_app()
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0], app.selected)
            n = len(app.store.list_bots())
            self.assertGreater(n, 3)
            for _ in range(n + 2):                          # các lượt Clock nạp dần
                fs = [f for f in kivy_stub.SCHEDULED if getattr(f, "__name__", "") == "_fill_infos"]
                kivy_stub.SCHEDULED.clear()
                for f in fs:
                    f()
            self.assertEqual(sorted(set(calls)), sorted(app.store.list_bots()))
            self.assertEqual(len(calls), n)                 # mỗi bot đúng một lần
            self.assertTrue(all(app.get_info(p).ok for p in app.store.list_bots()))
        finally:
            ui.inspect_bot = orig

    def test_inspect_bot_reads_and_checks_once(self):
        n = {"c": 0}
        orig = loader.check_bot_source
        loader.check_bot_source = lambda *a, **k: (n.__setitem__("c", n["c"] + 1), orig(*a, **k))[1]
        try:
            app = fresh_app()
            n["c"] = 0
            info = loader.inspect_bot(app.store.list_bots()[0])
            self.assertTrue(info.ok)
            self.assertEqual(n["c"], 1)
        finally:
            loader.check_bot_source = orig


if __name__ == "__main__":
    unittest.main()
