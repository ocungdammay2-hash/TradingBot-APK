"""Kiểm zip MT5 lúc chọn tệp (pyea/zipcheck.py). Tái hiện triệu chứng trong log thật 2026-11-26 (Cat S52): zip bị «lỗ» giữa tệp (danh mục cuối tệp
còn nguyên) làm unzip báo «invalid compressed data to inflate terminal64.exe» + «bad zipfile offset (local header sig)». Nguyên nhân thật của cái lỗ CHƯA biết
(giả thuyết: tải về điện thoại bị ngắt/tải song song), nên hàm này chỉ PHÁT HIỆN sớm, không sửa."""
import os
import random
import sys
import tempfile
import unittest
import zipfile

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))
from pyea import zipcheck  # noqa: E402


def build(path, extra=(), skip_terminal=False, big=2 << 20):
    random.seed(3)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for i in range(40):
            z.writestr("MetaTrader 5/MQL5/Include/f%02d.mqh" % i, os.urandom(random.randint(500, 4000)))
        z.writestr("MetaTrader 5/metaeditor64.exe", os.urandom(big))
        if not skip_terminal:
            z.writestr("MetaTrader 5/terminal64.exe", os.urandom(big))
        for n, data in extra:
            z.writestr(n, data)


class TestVerifyZip(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = os.path.join(self.tmp.name, "mt5.zip")

    def test_good_zip_passes_and_counts_files(self):
        build(self.p)
        self.assertEqual(zipcheck.verify_zip(self.p), 42)

    def test_hole_in_the_middle_is_detected_like_the_real_log(self):
        build(self.p)
        b = bytearray(open(self.p, "rb").read())
        at = int(len(b) * 0.55)
        b[at:at + (1 << 20) // 4] = bytes((1 << 20) // 4)        # khối số 0 giữa tệp, danh mục cuối tệp còn nguyên
        open(self.p, "wb").write(b)
        with self.assertRaises(ValueError) as cm:
            zipcheck.verify_zip(self.p)
        msg = str(cm.exception)
        self.assertIn("HỎNG", msg)
        self.assertIn("TẢI LẠI", msg)
        self.assertRegex(msg, r"\d+/\d+ mục")

    def test_flipped_byte_is_caught_by_crc(self):
        with zipfile.ZipFile(self.p, "w", zipfile.ZIP_STORED) as z:
            z.writestr("MetaTrader 5/terminal64.exe", b"A" * 50000)
        b = bytearray(open(self.p, "rb").read())
        b[len(b) // 2] ^= 0xFF
        open(self.p, "wb").write(b)
        with self.assertRaises(ValueError) as cm:
            zipcheck.verify_zip(self.p)
        self.assertIn("terminal64.exe", str(cm.exception))

    def test_truncated_file_has_no_directory(self):
        build(self.p)
        b = open(self.p, "rb").read()
        open(self.p, "wb").write(b[: len(b) // 2])
        with self.assertRaises(ValueError) as cm:
            zipcheck.verify_zip(self.p)
        self.assertIn("danh mục", str(cm.exception))

    def test_not_a_mt5_folder_is_reported(self):
        build(self.p, skip_terminal=True)
        with self.assertRaises(ValueError) as cm:
            zipcheck.verify_zip(self.p)
        self.assertIn("terminal64.exe", str(cm.exception))
        self.assertIn("MetaTrader 5", str(cm.exception))

    def test_terminal_too_deep_is_reported(self):
        # script chỉ tìm terminal64.exe sâu tối đa 3 cấp; sâu hơn thì phải báo ngay chứ không đợi tới cuối cài
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("a/b/c/d/terminal64.exe", b"x")
        with self.assertRaises(ValueError):
            zipcheck.verify_zip(self.p)

    def test_terminal_at_root_or_one_folder_deep_and_windows_slashes_ok(self):
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("terminal64.exe", b"x")
        self.assertEqual(zipcheck.verify_zip(self.p), 1)
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("MetaTrader 5\\Terminal64.EXE", b"x")
        self.assertEqual(zipcheck.verify_zip(self.p), 1)

    def test_zip_with_only_folders_is_empty(self):
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("MetaTrader 5/", b"")
        with self.assertRaises(ValueError) as cm:
            zipcheck.verify_zip(self.p)
        self.assertIn("không có tệp nào", str(cm.exception))

    def test_garbage_after_pk_is_not_a_zip(self):
        open(self.p, "wb").write(b"PK" + os.urandom(3000))
        with self.assertRaises(ValueError):
            zipcheck.verify_zip(self.p)

    def test_large_entry_is_streamed_not_loaded(self):
        # 40 MB dễ nén: nếu đọc cả mục vào RAM thì tốn 40 MB; kiểm bằng cách giới hạn kích thước khối đọc
        with zipfile.ZipFile(self.p, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("MetaTrader 5/terminal64.exe", b"\0" * (40 << 20))
        sizes = []
        orig = zipfile.ZipExtFile.read

        def spy(self_, n=-1):
            out = orig(self_, n)
            sizes.append(len(out))
            return out
        zipfile.ZipExtFile.read = spy
        try:
            self.assertEqual(zipcheck.verify_zip(self.p), 1)
        finally:
            zipfile.ZipExtFile.read = orig
        self.assertLessEqual(max(sizes), zipcheck._CHUNK)


if __name__ == "__main__":
    unittest.main()


class TestExtractZip(unittest.TestCase):
    """v21: giải nén bằng Python (không qua unzip/proot). Lý do: log thật 2026-11-26 - unzip trong Ubuntu báo zip hỏng dù điện thoại giải nén bình thường."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.p = os.path.join(self.tmp.name, "mt5.zip")
        self.dest = os.path.join(self.tmp.name, "out", "x")

    def test_extracts_everything_with_manifest_of_big_files(self):
        build(self.p, big=1500000)
        r = zipcheck.extract_zip(self.p, self.dest)
        self.assertEqual(r["files"], 42)
        self.assertEqual(r["skipped"], 0)
        t = os.path.join(self.dest, "MetaTrader 5", "terminal64.exe")
        self.assertEqual(os.path.getsize(t), 1500000)
        self.assertEqual(os.stat(t).st_mode & 0o777, 0o644)
        import hashlib
        want = {rel: hashlib.sha256(open(os.path.join(self.dest, rel), "rb").read()).hexdigest() for _, rel in r["manifest"]}
        self.assertEqual({rel for _, rel in r["manifest"]}, {"MetaTrader 5/terminal64.exe", "MetaTrader 5/metaeditor64.exe"})
        for sha, rel in r["manifest"]:
            self.assertEqual(sha, want[rel], "sha256 trong sổ phải là của bản ĐÃ GHI ra đĩa")

    def test_content_matches_original_bytes(self):
        data = os.urandom(70000)
        with zipfile.ZipFile(self.p, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("MetaTrader 5/terminal64.exe", data)
            z.writestr("MetaTrader 5/MQL5/Experts/ea.mq5", b"//x")
        zipcheck.extract_zip(self.p, self.dest)
        self.assertEqual(open(os.path.join(self.dest, "MetaTrader 5", "terminal64.exe"), "rb").read(), data)
        self.assertEqual(open(os.path.join(self.dest, "MetaTrader 5", "MQL5", "Experts", "ea.mq5"), "rb").read(), b"//x")

    def test_zip_slip_absolute_and_drive_paths_are_skipped(self):
        outside = os.path.join(self.tmp.name, "out", "evil.txt")
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("MetaTrader 5/terminal64.exe", b"x")
            z.writestr("../evil.txt", b"pwn")
            z.writestr("../../evil.txt", b"pwn")
            z.writestr("a/../../evil.txt", b"pwn")
            z.writestr("/etc/pyea_abs", b"pwn")
            z.writestr("C:/Windows/evil.dll", b"pwn")
            z.writestr("ok\x01ctl.txt", b"pwn")
        r = zipcheck.extract_zip(self.p, self.dest)
        self.assertEqual(r["files"], 1)
        self.assertEqual(r["skipped"], 6)
        self.assertFalse(os.path.exists(outside))
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, "evil.txt")))
        self.assertEqual(sorted(os.listdir(self.dest)), ["MetaTrader 5"])

    def test_symlink_entries_are_skipped(self):
        with zipfile.ZipFile(self.p, "w") as z:
            z.writestr("MetaTrader 5/terminal64.exe", b"x")
            zi = zipfile.ZipInfo("MetaTrader 5/link")
            zi.create_system = 3
            zi.external_attr = (0o120777 << 16)
            z.writestr(zi, "/etc/passwd")
        r = zipcheck.extract_zip(self.p, self.dest)
        self.assertEqual((r["files"], r["skipped"]), (1, 1))
        self.assertFalse(os.path.lexists(os.path.join(self.dest, "MetaTrader 5", "link")))

    def test_hole_gives_zipcorrupt_and_cleans_dest(self):
        build(self.p)
        b = bytearray(open(self.p, "rb").read())
        at = int(len(b) * 0.6)
        b[at:at + 300000] = bytes(300000)
        open(self.p, "wb").write(b)
        with self.assertRaises(zipcheck.ZipCorrupt) as cm:
            zipcheck.extract_zip(self.p, self.dest)
        self.assertIn("HỎNG", str(cm.exception))
        self.assertFalse(os.path.exists(self.dest), "lỗi giữa chừng phải dọn thư mục đích")

    def test_no_terminal_and_empty_are_plain_valueerror_not_corrupt(self):
        build(self.p, skip_terminal=True)
        with self.assertRaises(ValueError) as cm:
            zipcheck.extract_zip(self.p, self.dest)
        self.assertNotIsInstance(cm.exception, zipcheck.ZipCorrupt)
        self.assertFalse(os.path.exists(self.dest))

    def test_truncated_is_zipcorrupt(self):
        build(self.p)
        b = open(self.p, "rb").read()
        open(self.p, "wb").write(b[: len(b) // 3])
        with self.assertRaises(zipcheck.ZipCorrupt):
            zipcheck.extract_zip(self.p, self.dest)

    def test_not_enough_disk_is_reported(self):
        build(self.p)
        import shutil
        real = shutil.disk_usage
        shutil.disk_usage = lambda p: shutil._ntuple_diskusage(1 << 30, 1 << 30, 10 << 20)
        try:
            with self.assertRaises(ValueError) as cm:
                zipcheck.extract_zip(self.p, self.dest)
        finally:
            shutil.disk_usage = real
        self.assertIn("dung lượng", str(cm.exception))

    def test_nonempty_destination_refused(self):
        build(self.p)
        os.makedirs(self.dest)
        open(os.path.join(self.dest, "keep.txt"), "w").write("x")
        with self.assertRaises(ValueError):
            zipcheck.extract_zip(self.p, self.dest)
        self.assertTrue(os.path.exists(os.path.join(self.dest, "keep.txt")), "không được xoá dữ liệu có sẵn ở thư mục đích")

    def test_progress_reports_bytes(self):
        build(self.p)
        seen = []
        zipcheck.extract_zip(self.p, self.dest, progress=lambda d, t: seen.append((d, t)))
        self.assertTrue(seen and seen[-1][0] == seen[-1][1])

    def test_password_protected_is_not_called_corrupt(self):
        # zip mã hoá: Python không giải được -> báo «có mật khẩu», KHÔNG bảo người dùng tải lại
        import subprocess
        d = os.path.join(self.tmp.name, "src")
        os.makedirs(os.path.join(d, "MetaTrader 5"))
        open(os.path.join(d, "MetaTrader 5", "terminal64.exe"), "wb").write(b"x" * 500)
        r = subprocess.run("cd %s && zip -q -r -P secret %s 'MetaTrader 5'" % (d, self.p), shell=True)
        if r.returncode != 0:
            self.skipTest("không có lệnh zip")
        with self.assertRaises(ValueError) as cm:
            zipcheck.extract_zip(self.p, self.dest)
        self.assertNotIsInstance(cm.exception, zipcheck.ZipCorrupt)
        self.assertIn("mật khẩu", str(cm.exception))
