"""Khối lượng theo rủi ro (sizing.py + api.size_for_risk) và giới hạn lỗ trong ngày (dayloss.py + cổng lệnh + lưu phiên + backtest)."""
import json
import os
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
import kivy_stub                                                 # noqa: E402
kivy_stub.install()

from pyea import dayloss, sizing                                 # noqa: E402
from pyea.engine import Account, BotContext, TradingSession      # noqa: E402
from pyea.sdk import API_VERSION, Ret, Tick                      # noqa: E402
from pyea.settings import GLOBAL_INPUTS, clean_settings, default_settings   # noqa: E402
from test_recon_cache import make as make_paper                  # noqa: E402


def sz(**kw):
    base = dict(entry=100.0, stop=95.0, risk_pct=1.0, base_amount=10000.0)
    base.update(kw)
    return sizing.size_for_risk(**base)


class TestSizing(unittest.TestCase):
    def test_basic_formula_risk_pct_of_balance(self):
        r = sz()
        self.assertTrue(r["ok"])
        self.assertAlmostEqual(r["volume"], 20.0)                    # 1% × 10000 = 100 tiền, SL cách 5 -> 20 đơn vị
        self.assertAlmostEqual(r["actual_risk"], 100.0)
        self.assertAlmostEqual(r["risk_money"], 100.0)

    def test_short_side_same_distance(self):
        self.assertAlmostEqual(sz(entry=100.0, stop=105.0)["volume"], 20.0)

    def test_risk_money_alone_and_min_of_both(self):
        self.assertAlmostEqual(sz(risk_pct=None, risk_money=50.0)["volume"], 10.0)
        self.assertAlmostEqual(sz(risk_pct=1.0, risk_money=50.0)["volume"], 10.0)         # lấy số NHỎ hơn
        self.assertAlmostEqual(sz(risk_pct=0.2, risk_money=50.0)["volume"], 4.0)

    def test_contract_size_scales_loss_per_lot(self):
        r = sizing.size_for_risk(1.1000, 1.0950, risk_money=50.0, contract_size=100000.0, volume_step=0.01, volume_min=0.01)
        self.assertAlmostEqual(r["volume"], 0.10, places=6)          # 0.005 × 100000 = 500 / lot -> 50/500 = 0.1 lot
        self.assertAlmostEqual(r["risk_per_unit"], 500.0, places=6)

    def test_always_rounds_down_never_above_risk(self):
        r = sz(volume_step=3.0)
        self.assertEqual(r["volume"], 18.0)
        self.assertLessEqual(r["actual_risk"], r["risk_money"] + 1e-9)
        for step in (0.01, 0.1, 1.0, 5.0):
            r = sz(entry=123.45, stop=120.1, risk_pct=0.7, volume_step=step)
            if r["ok"]:
                self.assertLessEqual(r["actual_risk"], r["risk_money"] + 1e-9, step)

    def test_float_step_noise_does_not_lose_a_step(self):
        self.assertEqual(sizing.floor_to_step(0.3, 0.1), 0.3)        # 0.3/0.1 = 2.9999999999999996
        self.assertEqual(sizing.floor_to_step(0.7, 0.1), 0.7)
        self.assertEqual(sizing.floor_to_step(1.0, 0.0), 1.0)

    def test_below_min_volume_gives_zero_with_reason_unless_round_up(self):
        r = sz(entry=100.0, stop=50.0, risk_pct=0.1, volume_min=1.0, volume_step=1.0)     # 10 tiền / 50 = 0.2 < 1
        self.assertFalse(r["ok"])
        self.assertEqual(r["volume"], 0.0)
        self.assertIn("tối thiểu", r["reason"])
        up = sz(entry=100.0, stop=50.0, risk_pct=0.1, volume_min=1.0, volume_step=1.0, round_up_to_min=True)
        self.assertTrue(up["ok"])
        self.assertEqual((up["volume"], up["capped_by"]), (1.0, "min_volume"))
        self.assertGreater(up["actual_risk"], up["risk_money"])      # nói thật: rủi ro thật LỚN hơn đã định

    def test_caps_volume_max_user_max_and_margin(self):
        self.assertEqual((sz(volume_max=5.0)["volume"], sz(volume_max=5.0)["capped_by"]), (5.0, "volume_max"))
        self.assertEqual(sz(user_max=7.0)["capped_by"], "max_volume")
        m = sz(margin_per_unit=50.0, free_margin=400.0)              # chỉ đủ ký quỹ cho 8 đơn vị
        self.assertEqual((m["volume"], m["capped_by"]), (8.0, "margin"))
        self.assertEqual(sz(margin_per_unit=50.0, free_margin=0.0)["capped_by"], None)      # không biết ký quỹ -> không chặn bừa

    def test_loss_per_unit_override_for_foreign_quote_currency(self):
        r = sizing.size_for_risk(150.0, 149.0, risk_money=100.0, contract_size=100000.0, loss_per_unit=650.0)
        self.assertAlmostEqual(r["risk_per_unit"], 650.0)
        self.assertAlmostEqual(r["volume"], 100.0 / 650.0, places=6)

    def test_bad_inputs_never_raise_and_say_why(self):
        for kw, frag in ((dict(entry=0), "không hợp lệ"), (dict(stop=-1), "không hợp lệ"), (dict(stop=100.0), "trùng"), (dict(risk_pct=None), "risk_pct hoặc risk_money"),
                         (dict(base_amount=0.0), "vốn"), (dict(entry="x"), "không hợp lệ"), (dict(entry=float("nan")), "không hợp lệ"), (dict(risk_pct=-5), "risk_pct hoặc risk_money")):
            r = sz(**kw)
            self.assertFalse(r["ok"], kw)
            self.assertEqual(r["volume"], 0.0)
            self.assertIn(frag, r["reason"], kw)


def session(**over):
    base = dict(daily_loss_pct=2.0, initial_balance=10000.0)
    base.update(over)
    s = make_paper(**base)
    s.sync = False
    s.account = Account(base["initial_balance"], 0.0, 1.0)
    s.watch = ["BTCUSDT"]
    return s


def tick(s, px, t=None):
    s.process_tick(Tick("BTCUSDT", t or time.time(), px, px))


class TestDayKey(unittest.TestCase):
    def test_reset_hour_shifts_the_day_boundary(self):
        fmt = lambda f, ts: time.strftime(f, time.gmtime(ts))
        t = 1767225600 + 4 * 3600                                    # 2026-01-01 04:00 UTC
        self.assertEqual(dayloss.day_key(t, 0, fmt), "2026-01-01")
        self.assertEqual(dayloss.day_key(t, 5, fmt), "2025-12-31")   # ngày mới bắt đầu lúc 05:00 -> 04:00 vẫn thuộc ngày trước
        self.assertEqual(dayloss.day_key(t + 3600, 5, fmt), "2026-01-01")

    def test_config_clamps_and_defaults(self):
        self.assertEqual(dayloss.config({}), (0.0, 0.0, "block", 0.0))
        self.assertEqual(dayloss.config({"daily_loss_pct": "x", "daily_loss_money": -5, "daily_loss_action": "zzz", "daily_reset_hour": 99}), (0.0, 0.0, "block", 23.0))
        self.assertEqual(dayloss.config({"daily_loss_pct": 500})[0], 100.0)

    def test_limit_is_the_smaller_of_pct_and_money(self):
        self.assertEqual(dayloss.limit_amount(10000.0, 2.0, 0.0), 200.0)
        self.assertEqual(dayloss.limit_amount(10000.0, 2.0, 150.0), 150.0)
        self.assertEqual(dayloss.limit_amount(10000.0, 0.0, 150.0), 150.0)
        self.assertEqual(dayloss.limit_amount(10000.0, 0.0, 0.0), 0.0)


class TestUpdate(unittest.TestCase):
    FMT = staticmethod(lambda f, ts: time.strftime(f, time.gmtime(ts)))
    T0 = 1767225600 + 9 * 3600                                       # 2026-01-01 09:00 UTC

    def upd(self, st, dt, eq, bal=None, trades=(), **s):
        cfg = dict(daily_loss_pct=2.0)
        cfg.update(s)
        return dayloss.update(st, self.T0 + dt, eq, eq if bal is None else bal, trades, cfg, self.FMT)

    def test_trips_exactly_once_and_latches_even_if_equity_recovers(self):
        st = {}
        self.assertFalse(self.upd(st, 0, 10000)["tripped"])
        r = self.upd(st, 60, 9850)
        self.assertEqual((r["tripped"], r["newly_tripped"]), (False, False))
        r = self.upd(st, 120, 9800)                                  # đúng -2% = ngưỡng 200
        self.assertEqual((r["tripped"], r["newly_tripped"]), (True, True))
        self.assertIn("chặn lệnh MỚI", r["message"])
        r = self.upd(st, 180, 9700)
        self.assertEqual((r["tripped"], r["newly_tripped"]), (True, False))
        r = self.upd(st, 240, 10200)                                 # hồi lại vẫn chặn tới hết ngày
        self.assertEqual((r["tripped"], r["newly_tripped"]), (True, False))
        self.assertTrue(dayloss.blocks_new_orders(st, {"daily_loss_pct": 2.0}))

    def test_new_day_resets_and_takes_fresh_start_equity(self):
        st = {}
        self.upd(st, 0, 10000)
        self.upd(st, 60, 9700)
        self.assertTrue(st["tripped"])
        r = self.upd(st, 86400, 9700)                                # ngày hôm sau
        self.assertEqual((r["tripped"], r["start_equity"], r["pnl"]), (False, 9700.0, 0.0))
        self.assertFalse(dayloss.blocks_new_orders(st, {"daily_loss_pct": 2.0}))
        self.assertEqual(self.upd(st, 86400 + 60, 9700 - 193)["tripped"], False)    # ngưỡng mới = 2% × 9700 = 194

    def test_raising_or_disabling_the_limit_lifts_the_block_only_if_not_exceeded(self):
        st = {}
        self.upd(st, 0, 10000)
        self.upd(st, 60, 9800)
        self.assertTrue(st["tripped"])
        self.assertTrue(self.upd(st, 70, 9800, daily_loss_pct=2.0)["tripped"])                  # giữ nguyên
        self.assertTrue(self.upd(st, 80, 9800, daily_loss_pct=1.5)["tripped"])                  # siết hơn: vẫn chặn
        self.assertFalse(self.upd(st, 90, 9800, daily_loss_pct=3.0)["tripped"])                 # nới tới mức chưa chạm: gỡ
        st2 = {}
        self.upd(st2, 0, 10000)
        self.upd(st2, 60, 9800)
        self.assertFalse(self.upd(st2, 70, 9800, daily_loss_pct=0.0)["tripped"])                # tắt hẳn: gỡ
        self.assertFalse(dayloss.blocks_new_orders(st2, {"daily_loss_pct": 0.0}))

    def test_floating_loss_counts_because_it_is_equity_based(self):
        st = {}
        self.upd(st, 0, 10000, bal=10000)
        r = self.upd(st, 60, 9790, bal=10000)                        # chưa đóng lệnh nào, chỉ lỗ thả nổi
        self.assertTrue(r["tripped"])

    def test_restart_mid_day_estimates_start_from_todays_realised_trades(self):
        class T:
            def __init__(s, ct, p): s.close_time, s.profit = ct, p
        trades = [T(self.T0 - 3600, -120.0), T(self.T0 - 60, -50.0), T(self.T0 - 86400 * 2, -999.0)]    # 2 lệnh hôm nay, 1 lệnh cũ
        st = {}
        r = self.upd(st, 0, 9830, bal=9830, trades=trades)           # số dư 9830 = đầu ngày 10000 − 170 đã đóng
        self.assertAlmostEqual(r["start_equity"], 10000.0)
        self.assertAlmostEqual(r["pnl"], -170.0)
        self.assertFalse(r["tripped"])
        self.assertTrue(self.upd(st, 30, 9790, bal=9790, trades=trades)["tripped"])

    def test_off_means_never_trips(self):
        st = {}
        self.upd(st, 0, 10000, daily_loss_pct=0.0)
        r = self.upd(st, 60, 1, daily_loss_pct=0.0)
        self.assertEqual((r["on"], r["tripped"], r["newly_tripped"]), (False, False, False))

    def test_state_is_json_serialisable(self):
        st = {}
        self.upd(st, 0, 10000)
        self.upd(st, 60, 9000)
        self.assertEqual(json.loads(json.dumps(st))["tripped"], True)


class TestSessionGate(unittest.TestCase):
    def trip(self, s):
        tick(s, 100.0)
        s._check_daily_loss()                                        # chụp equity đầu ngày
        p = s.send_order("BTCUSDT", "buy", 100.0, owner="botA").position       # mua 100 @100
        tick(s, 97.0)                                                # thả nổi -300 = -3% > 2%
        s._check_daily_loss()
        return p

    def test_new_orders_blocked_for_bot_and_manual_but_closing_works(self):
        s = session()
        p = self.trip(s)
        self.assertTrue(s.account.day["tripped"])
        for owner in ("botA", "manual"):
            r = s.send_order("BTCUSDT", "buy", 1.0, owner=owner)
            self.assertEqual((r.ok, r.retcode), (False, Ret.DAILY_LOSS), owner)
            self.assertIn("giới hạn lỗ", r.message.lower())
        self.assertEqual(s.place_pending("BTCUSDT", "buy", "limit", 1.0, 90.0, owner="botA").retcode, Ret.DAILY_LOSS)
        self.assertEqual(s._gate("BTCUSDT", "sell", closing=True), None)
        self.assertTrue(s.close_position(p.id, "bot", "đóng tay").ok)
        self.assertEqual(len(s.account.positions), 0)

    def test_block_action_keeps_positions_but_close_block_closes_them(self):
        a = session(daily_loss_action="block")
        self.trip(a)
        self.assertEqual(len(a.account.positions), 1)
        b = session(daily_loss_action="close_block")
        self.trip(b)
        self.assertEqual(len(b.account.positions), 0)
        self.assertEqual(b.send_order("BTCUSDT", "buy", 1.0, owner="botA").retcode, Ret.DAILY_LOSS)

    def test_alarm_once_only(self):
        s = session()
        self.trip(s)
        n = len([a for a in s.alarms if "giới hạn lỗ" in a.lower()])
        for _ in range(5):
            s._check_daily_loss()
        self.assertEqual(n, 1)
        self.assertEqual(len([a for a in s.alarms if "giới hạn lỗ" in a.lower()]), 1)

    def test_default_off_never_blocks(self):
        s = session(daily_loss_pct=0.0, daily_loss_money=0.0)
        tick(s, 100.0)
        s.send_order("BTCUSDT", "buy", 50.0, owner="botA")           # vừa phải để còn ký quỹ cho lệnh sau
        tick(s, 50.0)
        s._check_daily_loss()
        self.assertEqual(s.account.day, {})
        self.assertTrue(s.send_order("BTCUSDT", "buy", 1.0, owner="botA").ok)

    def test_survives_restart_via_to_dict_restore(self):
        s = session()
        self.trip(s)
        d = json.loads(json.dumps(s.account.to_dict()))
        acc2 = Account(10000.0, 0.0, 1.0)
        acc2.restore(d)
        self.assertTrue(acc2.day["tripped"])
        self.assertEqual(acc2.day["key"], s.account.day["key"])
        acc3 = Account(10000.0, 0.0, 1.0)
        acc3.restore({k: v for k, v in d.items() if k != "day"})     # phiên cũ (không có khoá day) vẫn đọc được
        self.assertEqual(acc3.day, {})

    def test_status_view_is_read_only_and_never_trips_by_itself(self):
        s = session()
        tick(s, 100.0)
        s._check_daily_loss()
        s.send_order("BTCUSDT", "buy", 100.0, owner="botA")
        tick(s, 97.0)
        st = s.day_status()                                          # UI gọi trước vòng canh: không được tự chốt, nếu không sẽ nuốt cảnh báo/đóng lệnh
        self.assertTrue(st["tripped"])
        self.assertFalse(s.account.day["tripped"])
        s._check_daily_loss()
        self.assertTrue(s.account.day["tripped"])
        self.assertEqual(len([a for a in s.alarms if "giới hạn lỗ" in a.lower()]), 1)

    def test_snapshot_carries_daily_block(self):
        s = session()
        tick(s, 100.0)
        s._check_daily_loss()
        snap = s.snapshot()
        self.assertTrue(snap["daily"]["on"])
        self.assertIn("pnl", snap["daily"])

    def test_error_inside_guard_never_blocks_or_raises(self):
        s = session()
        tick(s, 100.0)
        s.account.day = {"key": "2026-01-01", "tripped": "yes", "limit_at_trip": "bad"}
        self.assertIsNone(s._daily_gate(False) if not dayloss.blocks_new_orders({}, {}) else None)
        orig = dayloss.update
        dayloss.update = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        try:
            s._check_daily_loss()                                    # không ném
        finally:
            dayloss.update = orig


class TestApiAndSettings(unittest.TestCase):
    def test_api_version_and_changes_registered(self):
        from pyea.changelog import API_CHANGES
        self.assertEqual(API_VERSION, "1.9")
        self.assertEqual(API_CHANGES[0][0], "1.9")
        self.assertIn("size_for_risk", " ".join(API_CHANGES[0][1]))
        self.assertTrue(hasattr(Ret, "DAILY_LOSS"))

    def test_settings_exist_validate_and_default_off(self):
        d = default_settings()
        self.assertEqual((d["daily_loss_pct"], d["daily_loss_money"], d["daily_loss_action"], d["daily_reset_hour"]), (0.0, 0.0, "block", 0.0))
        c = clean_settings({"daily_loss_pct": 999, "daily_loss_action": "zzz", "daily_reset_hour": -3})      # ngoài khoảng/sai kiểu -> về mặc định (quy ước chung của clean_settings)
        self.assertEqual((c["daily_loss_pct"], c["daily_loss_action"], c["daily_reset_hour"]), (0.0, "block", 0.0))
        ok = clean_settings({"daily_loss_pct": 3.5, "daily_loss_money": 120, "daily_loss_action": "close_block", "daily_reset_hour": 5})
        self.assertEqual((ok["daily_loss_pct"], ok["daily_loss_money"], ok["daily_loss_action"], ok["daily_reset_hour"]), (3.5, 120.0, "close_block", 5.0))

    def test_bot_api_size_for_risk_uses_symbol_rules_and_account(self):
        s = session(min_volume=1.0, volume_step=1.0, max_volume=15.0, daily_loss_pct=0.0)
        tick(s, 100.0)

        class R:
            session, symbol = s, "BTCUSDT"
        api = BotContext(R())
        info = api.size_for_risk_info(100.0, 95.0, risk_pct=1.0)     # 100 tiền / 5 = 20 -> trần max_volume 15
        self.assertEqual((info["ok"], info["volume"], info["capped_by"]), (True, 15.0, "volume_max"))
        self.assertEqual(api.size_for_risk(100.0, 95.0, risk_pct=0.5), 10.0)
        self.assertEqual(api.size_for_risk(100.0, 100.0, risk_pct=1.0), 0.0)
        self.assertEqual(api.size_for_risk(100.0, 95.0), 0.0)        # thiếu cả risk_pct lẫn risk_money
        self.assertEqual(api.day_pnl()["on"], False)
        eq = api.size_for_risk(100.0, 95.0, risk_pct=0.5, base="equity")
        self.assertEqual(eq, 10.0)


class TestBacktestHonoursLimit(unittest.TestCase):
    def test_backtest_session_applies_the_gate(self):
        from pyea.backtest import TradingSession as BT                # noqa: F401 - cùng lớp; ở đây chỉ kiểm cổng với sync=True
        s = make_paper(daily_loss_pct=2.0, initial_balance=10000.0)    # make_paper dựng sync=True như backtest
        self.assertTrue(s.sync)
        tick(s, 100.0)
        s._check_daily_loss()
        s.send_order("BTCUSDT", "buy", 100.0, owner="botA")
        tick(s, 97.0)
        s._check_daily_loss()
        self.assertEqual(s.send_order("BTCUSDT", "buy", 1.0, owner="botA").retcode, Ret.DAILY_LOSS)


if __name__ == "__main__":
    unittest.main()
