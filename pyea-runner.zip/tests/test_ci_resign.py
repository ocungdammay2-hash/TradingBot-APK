"""Bước «Verify boot receiver in manifest» của workflow: APK bị Gradle ký bằng khoá khác (run #161 «APK KHÔNG ký bằng khoá cố định»)
phải được KÝ LẠI bằng khoá cố định. Chạy đúng đoạn lệnh trong YAML với apksigner/zipalign/aapt2/keytool GIẢ (không có Android SDK ở đây).
Thứ chưa kiểm được: apksigner/zipalign THẬT (chỉ GitHub mới có) - test này khoá thứ tự lệnh, đường lỗi và việc không bao giờ làm hỏng APK."""
import hashlib
import os
import shutil
import subprocess
import tempfile
import unittest
import zipfile

import yaml

ROOT = os.path.join(os.path.dirname(__file__), "..")
WANT = "3C:DD:6C:BB:FC:23:FA:6C:61:6C:B1:0D:73:88:0F:0D:67:7B:EF:CD:9B:01:3B:76:26:0B:7B:16:2D:95:9E:E6"
GRADLE_KEY = "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90"
OTHER_KEY = "0f" * 32

FAKE_APKSIGNER = r'''#!/bin/bash
echo "apksigner $*" >> "$FAKE_LOG"
case "$1" in
  verify)
    apk="${@: -1}"; h=$(sha256sum "$apk" | cut -d' ' -f1)
    if [ -f "$FAKE_DB/$h" ]; then fp=$(cat "$FAKE_DB/$h"); else fp=$(cat "$FAKE_DB/default"); fi
    [ "$fp" = none ] && exit 1
    echo "Signer #1 certificate DN: CN=fake"; echo "Signer #1 certificate SHA-256 digest: $fp"; echo "Signer #1 certificate SHA-1 digest: 00"
    ;;
  sign)
    [ -n "$FAKE_SIGN_FAIL" ] && { echo "Failed to load signer" >&2; exit 2; }
    while [ $# -gt 0 ]; do case "$1" in --ks) ks="$2"; shift 2;; --out) out="$2"; shift 2;; --*) shift 2;; *) in="$1"; shift;; esac; done
    echo "sign-input-entries: $(unzip -Z1 "$in" | tr '\n' ' ')" >> "$FAKE_LOG"
    cp "$in" "$out"
    fp=$(cat "$ks" | tr 'A-F' 'a-f' | tr -d ':')
    [ -n "$FAKE_SIGN_WRONG" ] && fp="$FAKE_SIGN_WRONG"
    echo "$fp" > "$FAKE_DB/$(sha256sum "$out" | cut -d' ' -f1)"
    ;;
esac
'''
FAKE_ZIPALIGN = r'''#!/bin/bash
echo "zipalign $*" >> "$FAKE_LOG"
case "$1" in
  -c) [ -n "$FAKE_ALIGN_BAD" ] && { echo "Verification FAILED" ; exit 1; }; echo "Verification succesful";;
  -p) [ -n "$FAKE_ZA_FAIL" ] && exit 1; cp "$4" "$5";;
esac
'''
FAKE_AAPT2 = '''#!/bin/bash
if [ "$2" = "xmltree" ]; then
  [ -n "$FAKE_XMLTREE" ] && [ -f "$FAKE_XMLTREE" ] && { cat "$FAKE_XMLTREE"; exit 0; }
  exit 1
fi
echo "sdkVersion:'24'"; echo "targetSdkVersion:'36'"
'''
FAKE_KEYTOOL = r'''#!/bin/bash
ks=""; while [ $# -gt 0 ]; do case "$1" in -keystore) ks="$2"; shift 2;; *) shift;; esac; done
[ -f "$ks" ] || exit 1
echo "	 SHA256: $(cat "$ks")"
'''


def step_script():
    with open(os.path.join(ROOT, ".github", "workflows", "build-apk.yml"), encoding="utf-8") as f:
        wf = yaml.safe_load(f)
    for st in wf["jobs"]["build"]["steps"]:
        if st.get("name") == "Verify boot receiver in manifest":
            return st["run"].replace("${{ steps.sign.outputs.fp }}", WANT)
    raise AssertionError("không thấy bước Verify boot receiver in manifest")


def sha(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


class Env:
    def __init__(self, apks=("app-debug.apk",), signer=True, zipalign=True):
        self.t = tempfile.mkdtemp(prefix="pyea_resign_")
        self.home = os.path.join(self.t, "home")
        self.proj = os.path.join(self.t, "proj")
        self.fake = os.path.join(self.t, "fakebin")
        self.db = os.path.join(self.t, "db")
        self.log = os.path.join(self.t, "calls.log")
        for d in (self.home, self.proj, self.fake, self.db):
            os.makedirs(d)
        open(self.log, "w").close()
        with open(os.path.join(self.db, "default"), "w") as f:
            f.write(GRADLE_KEY)
        bt = os.path.join(self.home, ".buildozer", "android", "platform", "android-sdk", "build-tools", "36.0.0")
        os.makedirs(bt)
        self.bt = bt
        self.put(os.path.join(bt, "aapt2"), FAKE_AAPT2)
        if signer:
            self.put(os.path.join(bt, "apksigner"), FAKE_APKSIGNER)
        if zipalign:
            self.put(os.path.join(bt, "zipalign"), FAKE_ZIPALIGN)
        self.put(os.path.join(self.fake, "keytool"), FAKE_KEYTOOL)
        os.makedirs(os.path.join(self.home, ".android"))
        with open(os.path.join(self.home, ".android", "debug.keystore"), "w") as f:
            f.write(WANT)
        with open(os.path.join(self.proj, "buildozer.spec"), "w") as f:
            f.write("[app]\nandroid.api = 36\n")
        m = os.path.join(self.proj, ".buildozer", "android", "platform", "build-arm64-v8a", "dists", "x", "src", "main")
        os.makedirs(m)
        with open(os.path.join(m, "AndroidManifest.xml"), "w") as f:
            f.write('<manifest android:extractNativeLibs="true"><service android:name="ServiceEmu"/>'
                    '<receiver android:name="org.pyea.pyearunner.BootReceiver"/>'
                    '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/></manifest>')
        os.makedirs(os.path.join(self.proj, "bin"))
        for i, n in enumerate(apks):
            self.make_apk(os.path.join(self.proj, "bin", n), i)

    @staticmethod
    def put(path, text):
        with open(path, "w") as f:
            f.write(text)
        os.chmod(path, 0o755)

    @staticmethod
    def make_apk(path, i=0):
        with zipfile.ZipFile(path, "w") as z:
            z.writestr("META-INF/MANIFEST.MF", "x")
            z.writestr("META-INF/CERT.SF", "x")
            z.writestr("META-INF/CERT.RSA", "x")
            z.writestr("AndroidManifest.xml", "m%d" % i)
            z.writestr("resources.arsc", "r")
            for f in ("libproot.so", "libproot_a10.so", "libproot_loader.so", "libproot_loader32.so", "libpyea_talloc.so", "libpyea_talloc_a10.so"):
                z.writestr("lib/arm64-v8a/" + f, "x")

    def run(self, **extra):
        env = dict(os.environ, HOME=self.home, FAKE_LOG=self.log, FAKE_DB=self.db,
                   PATH=self.fake + os.pathsep + os.environ["PATH"])
        env.pop("PYEA_TARGET_SDK", None)
        env.update(extra)
        r = subprocess.run(["bash", "--noprofile", "--norc", "-eo", "pipefail", "-c", step_script()], cwd=self.proj,
                           env=env, capture_output=True, text=True, timeout=120)
        return r

    def calls(self):
        with open(self.log) as f:
            return f.read()

    def apk(self, n="app-debug.apk"):
        return os.path.join(self.proj, "bin", n)

    def cert_of(self, n="app-debug.apk"):
        p = self.apk(n)
        d = os.path.join(self.db, sha(p))
        if os.path.exists(d):
            return open(d).read().strip()
        return open(os.path.join(self.db, "default")).read().strip()

    def close(self):
        shutil.rmtree(self.t, ignore_errors=True)


class TestResign(unittest.TestCase):
    def mk(self, **kw):
        e = Env(**kw)
        self.addCleanup(e.close)
        return e

    def test_wrong_gradle_key_is_resigned_in_correct_order(self):
        e = self.mk()
        before = sha(e.apk())
        r = e.run()
        out = r.stdout + r.stderr
        self.assertEqual(r.returncode, 0, out[-2500:])
        self.assertNotEqual(sha(e.apk()), before, "APK phải được thay bằng bản đã ký lại")
        self.assertEqual(e.cert_of().upper(), WANT.replace(":", ""), "chữ ký cuối phải là khoá cố định")
        self.assertIn("OK: đã KÝ LẠI", out)
        self.assertIn("::notice title=APK đã được ký lại bằng khoá cố định", out)
        c = e.calls()
        i_align, i_sign, i_check = c.index("zipalign -p -f 4"), c.index("apksigner sign"), c.index("zipalign -c 4")
        self.assertLess(i_align, i_sign, "phải căn zip TRƯỚC khi ký")
        self.assertLess(i_sign, i_check, "phải kiểm căn SAU khi ký")
        self.assertNotIn("CERT.SF", c.split("sign-input-entries:")[1].splitlines()[0], "chữ ký cũ phải được bỏ trước khi ký lại")
        self.assertIn("--ks-key-alias androiddebugkey", c)
        # nội dung APK (thư viện proot) vẫn còn nguyên
        names = zipfile.ZipFile(e.apk()).namelist()
        self.assertIn("lib/arm64-v8a/libproot.so", names)

    def test_diagnostics_printed_for_next_log(self):
        e = self.mk()
        out = e.run().stdout
        self.assertIn("Chữ ký APK (SHA-256):", out)
        self.assertIn("Khoá cố định mong muốn: " + WANT, out)
        self.assertIn("Chẩn đoán khoá: keystore sau build =", out)
        self.assertIn("ANDROID_USER_HOME=", out)

    def test_already_fixed_key_is_left_alone(self):
        e = self.mk()
        open(os.path.join(e.db, "default"), "w").write(WANT.replace(":", "").lower())
        before = sha(e.apk())
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-800:])
        self.assertIn("OK: APK ký bằng khoá cố định", r.stdout)
        self.assertEqual(sha(e.apk()), before)
        self.assertNotIn("apksigner sign", e.calls())

    def test_sign_failure_keeps_original_and_never_fails_job(self):
        e = self.mk()
        before = sha(e.apk())
        r = e.run(FAKE_SIGN_FAIL="1")
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-800:])
        self.assertEqual(sha(e.apk()), before)
        self.assertIn("::warning::apksigner sign lỗi", r.stdout)

    def test_wrong_cert_after_resign_keeps_original(self):
        e = self.mk()
        before = sha(e.apk())
        r = e.run(FAKE_SIGN_WRONG=OTHER_KEY)
        self.assertEqual(r.returncode, 0)
        self.assertEqual(sha(e.apk()), before)
        self.assertIn("vẫn không khớp khoá cố định", r.stdout)

    def test_misaligned_result_is_never_published(self):
        # APK lệch căn 4 byte bị Android 11+ từ chối cài => thà giữ bản gốc còn cài được (máy mới)
        e = self.mk()
        before = sha(e.apk())
        r = e.run(FAKE_ALIGN_BAD="1")
        self.assertEqual(r.returncode, 0)
        self.assertEqual(sha(e.apk()), before)
        self.assertIn("không qua kiểm căn 4 byte", r.stdout)

    def test_no_zipalign_signs_without_stripping(self):
        e = self.mk(zipalign=False)
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-800:])
        self.assertEqual(e.cert_of().upper(), WANT.replace(":", ""))
        self.assertIn("không có zipalign", r.stdout)
        # không zipalign thì không được động tới zip bằng `zip -d` (làm mất căn); apksigner nhận APK gốc còn nguyên META-INF
        self.assertIn("CERT.SF", e.calls().split("sign-input-entries:")[1].splitlines()[0])

    def test_zipalign_failure_falls_back_to_direct_sign(self):
        e = self.mk()
        r = e.run(FAKE_ZA_FAIL="1")
        self.assertEqual(r.returncode, 0)
        self.assertEqual(e.cert_of().upper(), WANT.replace(":", ""))

    def test_all_apks_in_bin_are_resigned(self):
        e = self.mk(apks=("a-debug.apk", "b-debug.apk"))
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-800:])
        for n in ("a-debug.apk", "b-debug.apk"):
            self.assertEqual(e.cert_of(n).upper(), WANT.replace(":", ""), n)

    def test_missing_apksigner_only_warns(self):
        e = self.mk(signer=False)
        before = sha(e.apk())
        r = e.run()
        self.assertEqual(r.returncode, 0)
        self.assertIn("Không tìm thấy apksigner", r.stdout)
        self.assertEqual(sha(e.apk()), before)

    def test_unreadable_signature_is_also_resigned(self):
        # apksigner verify thất bại (APK không chữ ký hợp lệ) cũng phải ký lại, không được tưởng là «khớp»
        e = self.mk()
        open(os.path.join(e.db, "default"), "w").write("none")
        r = e.run()
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-800:])
        self.assertEqual(e.cert_of().upper(), WANT.replace(":", ""))

OLD_MANIFEST = '<manifest><service android:name="ServiceEmu"/><uses-permission android:name="android.permission.INTERNET"/></manifest>'
XMLTREE_OK = """N: android=http://schemas.android.com/apk/res/android
  E: manifest (line=2)
    E: uses-permission (line=9)
      A: android:name(0x01010003)="android.permission.RECEIVE_BOOT_COMPLETED" (Raw: "android.permission.RECEIVE_BOOT_COMPLETED")
    E: application (line=20)
      A: android:extractNativeLibs(0x010104ea)=true
      E: service (line=30)
        A: android:name(0x01010003)="org.pyea.pyearunner.ServiceEmu" (Raw: "org.pyea.pyearunner.ServiceEmu")
      E: receiver (line=40)
        A: android:name(0x01010003)="org.pyea.pyearunner.BootReceiver" (Raw: "org.pyea.pyearunner.BootReceiver")
"""


class TestManifestPick(unittest.TestCase):
    """Run #169 (GitHub thật): APK dựng xong, hook đã chèn BootReceiver, nhưng bước kiểm báo «Manifest thiếu BootReceiver»: `find | head -n 1`
    chọn nhầm manifest của dist CŨ trong cache .buildozer. Sự thật phải là manifest TRONG APK; không đọc được thì lấy tệp mới nhất."""

    def setUp(self):
        self.e = Env()
        self.addCleanup(self.e.close)
        self.fresh = os.path.join(self.e.proj, ".buildozer", "android", "platform", "build-arm64-v8a", "dists", "x", "src", "main", "AndroidManifest.xml")

    def stale(self, name="build-aaa_old", text=OLD_MANIFEST, age=86400 * 3):
        d = os.path.join(self.e.proj, ".buildozer", "android", "platform", name, "dists", "pyearunner", "src", "main")
        os.makedirs(d)
        f = os.path.join(d, "AndroidManifest.xml")
        with open(f, "w") as fh:
            fh.write(text)
        import time
        os.utime(f, (time.time() - age, time.time() - age))
        return f

    def xml(self, text=XMLTREE_OK):
        p = os.path.join(self.e.t, "xmltree.txt")
        with open(p, "w") as f:
            f.write(text)
        return p

    def test_stale_old_dist_is_not_picked_over_the_newest_manifest(self):
        self.stale()
        self.stale("a_even_earlier_dir")
        r = self.e.run()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("tệp mới nhất", r.stdout)
        self.assertIn("build-arm64-v8a/dists/x", r.stdout)

    def test_manifest_inside_apk_is_the_truth_when_aapt2_can_read_it(self):
        os.remove(self.fresh)                                 # không còn tệp văn bản nào đúng, nhưng APK thì đúng
        self.stale()
        r = self.e.run(FAKE_XMLTREE=self.xml())
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("manifest TRONG", r.stdout)
        self.assertNotIn("extractNativeLibs=true (p4a", r.stdout, "xmltree ghi extractNativeLibs(0x…)=true phải được nhận")

    def test_apk_without_receiver_fails_even_if_a_stale_text_manifest_has_it(self):
        self.stale(text=self_manifest_ok())
        bad = XMLTREE_OK.replace("org.pyea.pyearunner.BootReceiver", "x.Other")
        r = self.e.run(FAKE_XMLTREE=self.xml(bad))
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("Manifest thiếu BootReceiver", r.stdout + r.stderr)
        self.assertIn("manifest TRONG", r.stdout + r.stderr)

    def test_apk_without_service_emu_fails(self):
        bad = XMLTREE_OK.replace("org.pyea.pyearunner.ServiceEmu", "x.Other")
        r = self.e.run(FAKE_XMLTREE=self.xml(bad))
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("ServiceEmu", r.stdout + r.stderr)

    def test_diagnostics_list_every_candidate_manifest(self):
        f = self.stale()
        r = self.e.run()
        self.assertIn("Chẩn đoán manifest: " + os.path.relpath(f, self.e.proj), r.stdout)
        self.assertIn("Chẩn đoán manifest: " + os.path.relpath(self.fresh, self.e.proj), r.stdout)

    def test_no_manifest_at_all_still_fails_clearly(self):
        os.remove(self.fresh)
        r = self.e.run()
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("Không thấy AndroidManifest.xml", r.stdout + r.stderr)

    def test_garbage_xmltree_falls_back_to_the_text_manifest(self):
        r = self.e.run(FAKE_XMLTREE=self.xml("error: bad apk\n"))
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("tệp mới nhất", r.stdout)


def self_manifest_ok():
    return ('<manifest android:extractNativeLibs="true"><service android:name="ServiceEmu"/>'
            '<receiver android:name="org.pyea.pyearunner.BootReceiver"/>'
            '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/></manifest>')



if __name__ == "__main__":
    unittest.main()
