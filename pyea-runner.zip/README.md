# PyEA Runner

Ứng dụng Android giao dịch **kiểu MetaTrader 5, viết bằng Python**: nhiều tài sản (Market Watch), **gắn bot (EA) vào tài sản** để tự giao dịch, **đặt lệnh thủ công**, biểu đồ có chấm vào/ra bấm xem lý do, **Strategy Tester (backtest + tối ưu)**, chạy nền có thông báo/báo động, và chat nhiều AI để giải thích/sửa bot.

> Tài liệu kỹ thuật cho người/AI tiếp quản: **HANDOFF.md**. Mặc định chạy **paper** (giả lập). Giao dịch thật là tính năng thử nghiệm - có thể mất vốn.

## 1. Build APK trên GitHub
> **Quan trọng:** GitHub **không tự giải nén** file `.zip`. Hãy giải nén `pyea-runner.zip` trên máy rồi đẩy các file bên trong lên repo. (Workflow bản này còn **tự giải nén** nếu repo chỉ chứa file zip - nhưng nên đẩy file đã giải nén; đừng để zip trong `.github/workflows/`.)

1. Tạo repo, đẩy **toàn bộ nội dung** của zip lên nhánh `main` (`git init && git add -A && git commit -m init && git push`).
   `buildozer.spec`, `main.py`, `pyea/`... phải cùng cấp. Workflow bản này **tự dò** `buildozer.spec` (kể cả khi nằm trong thư mục con - bản cũ báo lỗi *No buildozer.spec found*). File `.github/workflows/build-apk.yml` **phải ở gốc repo** (upload qua web hay bỏ sót thư mục ẩn → tạo tay, nội dung ở `docs/build-apk.yml`).
2. Tab **Actions → Build APK** (tự chạy khi push hoặc *Run workflow*). Lần đầu 30–60 phút.
3. Tải **Artifacts → pyearunner-apk** → cài APK. Nếu build lỗi: mở lần chạy → mục **Summary** có sẵn phần *Các dòng lỗi* + 80 dòng cuối của log buildozer; log đầy đủ nằm ở **Artifacts → buildozer-log**. Cache SDK/NDK được lưu cả khi lỗi nên lần chạy lại nhanh hơn nhiều (lần đầu 30–60 phút). Muốn vào Releases: `git tag v1.0.0 && git push --tags`.
(Chắc chắn thiết bị 64-bit: bỏ `armeabi-v7a` trong `buildozer.spec` để build nhanh gấp đôi.)

## 2. Các tab (giống MT5)
| Tab | Chức năng |
|---|---|
| **Thị trường** | Market Watch: giá bid/ask nhiều tài sản. Chạm vào mã → xem biểu đồ / đặt lệnh / gắn bot / xoá. *Thêm mã* có gợi ý từ sàn. **KẾT NỐI** để bắt đầu phiên. |
| **Giao dịch** | Tài khoản (số dư, equity, ký quỹ, lãi/lỗ), **vị thế mọi tài sản** (Sửa SL/TP, Đóng), **Lệnh mới** (mua/bán thị trường + SL/TP), lịch sử lệnh. |
| **Bot** | **Gắn bot vào tài sản + khung giờ** (nhiều bot, nhiều tài sản, cùng 1 bot gắn nhiều nơi, tham số riêng từng chỗ). Bật/tắt từng bot, xem trạng thái, lãi/lỗ riêng. Thư viện file .py (nạp, mẫu, xoá). |
| **Biểu đồ** | Chọn mã + **21 khung như MT5** (M1…M30, H1…H12, D1, W1, MN1). Nến, lưới, trục giá/giờ, **điều khiển bằng cảm ứng** (kéo = lướt có đà · chụm 2 ngón = thu/phóng · chạm nến = xem giá & giá trị chỉ báo · chạm 2 lần = về mặc định), **33 chỉ báo MT5** (nút *+ Chỉ báo*), chip **ẩn/hiện** chỉ báo + đường của bot, **chấm vào/ra** (▲ mua, ▼ bán, ● thoát, ◆ tín hiệu bị bỏ qua). **Chạm vào chấm → popup lý do** (nguồn quyết định, điều kiện + thông số kích hoạt, chỉ báo lúc đó, AI: từng model + lý do). |
| **Backtest** | Strategy Tester: chọn bot, tài sản, khung, số nến, mô phỏng tick (OHLC theo hướng nến / O→H→L→C / O→L→H→C / «xấu nhất» / chỉ giá mở; nút so sánh độ nhạy), vốn, đòn bẩy, spread, phí → báo cáo (lợi nhuận ròng, profit factor, drawdown, Sharpe, chuỗi thắng/thua, mua/bán...), đường equity, **biểu đồ có chấm vào/ra bấm xem lý do**, danh sách lệnh, **tối ưu hoá** tham số (quét lưới). |
| **AI** | Chat 1 AI / nhóm AI + bạn / nhóm AI tự thảo luận (ra tín hiệu cho bot `ai_follow`; chốt bởi 1 AI hoặc **biểu quyết đa số**). Giải thích bot, sửa bot (xem diff, lưu bản mới/ghi đè). |
| **Cài đặt** | Nguồn thị trường/sàn, chế độ paper/live, vốn paper, đòn bẩy, phí, ngưỡng dừng lỗ, chạy nền, API... |
| **Nhật ký** | Log; **Kiểm tra hệ thống** (báo cáo thiết bị/mạng/dịch vụ nền/pin để gửi hỗ trợ). |

**Nguồn thị trường** (Cài đặt → *Nguồn thị trường / sàn*): `simulated` (8 tài sản giả: BTCUSD, ETHUSD, EURUSD, XAUUSD, US500, AAPL... chạy offline, tua nhanh được) · `binance_spot` / `binance_futures` (crypto, giá thật; futures có bán khống + đòn bẩy) · `oanda` (forex/vàng/chỉ số CFD, có tài khoản **demo** miễn phí - cần token + account ID). Paper dùng giá thật của sàn đã chọn với tiền giả; live gửi lệnh thật (nên thử **Testnet/Demo** trước).

## 2b. Biểu đồ: khung giờ, cảm ứng, chỉ báo
**Khung thời gian (21):** 1m 2m 3m 4m 5m 6m 10m 12m 15m 20m 30m · 1h 2h 3h 4h 6h 8h 12h · 1d 1w 1mo. Bấm nút khung → lưới chọn. Nến căn theo **UTC**
(tuần mở Thứ Hai 00:00, tháng mở ngày 1). Khung sàn không có sẵn (vd Binance 12m/3h, OANDA 20m) được **ghép từ khung nhỏ hơn**.
**Cảm ứng:** kéo ngang = lướt (thả ra còn đà) · kéo dọc trên biểu đồ = cuộn trang · chụm/giãn 2 ngón = thu/phóng quanh vị trí 2 ngón ·
kéo ngang ở dải trục giờ (mép dưới) = thu/phóng · chạm vào nến = crosshair + O/H/L/C + giá trị chỉ báo · chạm lại = tắt · chạm 2 lần = về 60 nến, nến mới nhất ·
khi đang xem quá khứ có nút **Mới nhất ▶** ngay trên biểu đồ. Số nến kéo lùi được: Cài đặt → *Số nến đưa lên biểu đồ* (mặc định 400) và *Số nến lịch sử nạp sẵn* (500).
**Chỉ báo (nút *+ Chỉ báo*):** thêm nhiều chỉ báo, mỗi cái có tham số riêng (hộp Inputs như MT5), chọn màu, ẩn/hiện bằng chip `ƒ ...`, sửa/xoá; lưu riêng cho biểu đồ thường và biểu đồ backtest.
- Trên biểu đồ giá: MA (SMA/EMA/SMMA/LWMA), DEMA, TEMA, Bollinger Bands, Envelopes, Ichimoku (có mây + dịch Senkou/Chikou), Parabolic SAR, Alligator, Fractals, Kênh Donchian.
- Cửa sổ phụ: RSI, MACD, Stochastic, ADX, CCI, ATR, Momentum, Williams %R, ROC, OsMA, Bulls/Bears Power, DeMarker, Force Index, RVI, TRIX, Standard Deviation, Awesome (AO), Accelerator (AC).
- Khối lượng: Volumes, MFI, OBV, Accumulation/Distribution (cần nguồn giá có khối lượng - nguồn *simulated* không có nên hiện ghi chú).
Công thức/mặc định theo MT5 (vd đường tín hiệu MACD là **SMA**, ATR là **SMA của TR**, ADX làm mượt EMA); có tuỳ chọn kiểu cổ điển (EMA / Wilder) trong hộp tham số.
Các hàm cùng công thức dùng được trong bot: `ta.macd_series`, `ta.stoch_series`, `ta.adx_series`, ... (xem `ai.SDK_CHEATSHEET`).

## 2c. Vỏ: an toàn & vận hành (v1.2)
**Hợp đồng với bot (API 1.1):** mọi lệnh trả `OrderResult` có `retcode` chuẩn (OK, INVALID_VOLUME, INVALID_STOPS, INSUFFICIENT_MARGIN, TRADE_DISABLED, SYMBOL_MODE, MARKET_CLOSED, NO_QUOTES, NOT_SUPPORTED, HEDGE_NOT_ALLOWED, REJECTED...). Lệnh chờ limit/stop/stop-limit (có hạn, giữ chỗ ký quỹ), đóng một phần, `on_trade`, `on_timer`, `symbol_info()/account_info()/time_info()`, nến đa khung giờ, `request_id` chống gửi trùng. Xem `pyea/examples/pending_grid.py.txt`.
**An toàn:** nút **KILL SWITCH** (dừng bot → huỷ lệnh chờ → đóng hết → khoá giao dịch, sống qua restart) · chế độ **chỉ-xem** · chặn lệnh khi **giá cũ/mất kết nối** · luật khối lượng min/max/step + stop level + chế độ riêng từng mã (long-only/close-only/disabled) · **margin call** và **stop-out** · bot lỗi: chịu N lỗi/giờ rồi tự tắt (circuit breaker), phát hiện bot **treo** · app **chặn bot chứa subprocess/eval/exec...** (bật Chế độ nhà phát triển nếu tin file) · kiểm tra quyền API key Binance khi kết nối live · xác nhận trước khi đặt lệnh tay (tắt được = một chạm).
**Đối soát & dữ liệu (v1.3):** app so vị thế của mình với vị thế THẬT trên sàn (Binance Futures, OANDA) mỗi phút và ngay sau lệnh lỗi; lệch thì **mặc định tự đổi sổ theo sàn** (`adopt`, từ v1.7.0; chỉ làm sau khi thấy lệch lặp lại, đóng ở giá khớp thật lấy từ lịch sử sàn; muốn chỉ báo thì chọn `alert`). Lịch sử nến được lưu trên đĩa nên khởi động lại chỉ tải phần mới, tự phát hiện và lấp khoảng trống.
**Vận hành:** thanh trạng thái kết nối + mức ký quỹ trong tab Giao dịch · **cảnh báo giá** (≥/≤/±%) chạy cả khi không có bot · **Lịch sử & báo cáo** (win rate, profit factor, sụt vốn, theo từng bot, đường lãi/lỗ, xuất CSV) · số liệu từng bot (thắng, PF, thời gian on_tick) ngay ở tab Bot · **Sao lưu/Khôi phục** (mặc định xoá API key) · **Gói chẩn đoán** zip (không chứa khoá) · **Đặt lại tài khoản giả lập** · lọc Nhật ký theo mức/chữ/tên bot · nhớ tab và mã/khung biểu đồ lần trước.

## 2d. Sàn & cầu nối (v1.4)
`exchange` chọn ở Cài đặt: `simulated` · `binance_spot` · `binance_futures` · `oanda` · **`exness`** (API chính thức của Exness, chỉ VN/TH, chỉ "Exness trading account") · **`metaapi` / `mt5gw` / `bridge`** (MT4/MT5 qua cầu nối: Exness MT5 và mọi broker MetaTrader — xem `gateway/README.md`) · **`ccxt`** (~100 sàn khác; cần cài thư viện ccxt).
- **Khoá API được mã hoá** (Android Keystore; trên máy tính dùng khoá file). Tạo khoá riêng cho app, quyền tối thiểu (không cho rút tiền), bật giới hạn IP.
- **Lệnh chờ native** (`Lệnh chờ = auto`): nằm trên sàn, vẫn sống khi app/điện thoại chết. **Đồng bộ lịch sử + số dư** với sàn mỗi 5 phút (chỉ live), cảnh báo khi số dư lệch.
- **Nhiều tài khoản chạy song song** (Cài đặt → *Tài khoản…*): lưu hồ sơ từ cài đặt hiện tại, bot gắn theo tài khoản, "Xem" để chuyển tài khoản đang xem. Chạy được cả khi không bật chạy nền (v1.7.0; khi đó tài khoản phụ không có AI hub và dừng khi đóng app).
- **Backtest chi tiết chi phí** (spread cố định, phí/lot, trượt giá, swap, funding) và **Walk-forward** (tab Backtest).
- **Cô lập bot** (`Bot chạy ở = process`): bot chạy tiến trình riêng, giết được khi treo. Chưa dùng được trên Android (tự rơi về luồng).
- **Chưa kiểm chứng trên sàn thật**: toàn bộ các sàn/cầu nối ở trên mới được test bằng máy chủ giả (xem `HANDOFF.md` mục 5b). **Luôn thử demo/testnet trước.**
- **Tự kiểm tra sàn (một lệnh, mọi sàn)**: `python -m pyea.selfcheck --template exness > exness.json` (điền khoá) rồi `python -m pyea.selfcheck --exchange exness --settings exness.json` (CHỈ ĐỌC) hoặc thêm `--trade --yes` (lệnh thật khối lượng nhỏ nhất - dùng tài khoản DEMO; tự dọn vị thế/lệnh chờ). Báo cáo `[OK]/[CHÚ Ý]/[LỖI]` kèm phản hồi thô của sàn đã che khoá - dán lại để chỉnh. Cùng bộ kiểm tra này là nút *Nhật ký → Kiểm tra hệ thống* (chỉ đọc). Hợp đồng adapter ở `pyea/contract.py`.

## 2e. Vỏ bổ sung (v1.6, API bot 1.3)
- **Bot:** `api.store` (kho JSON bền riêng của bot) và `api.shared` (chung mọi bot, như GlobalVariable của MT5) · `api.oco(a, b)` nối lệnh chờ thành nhóm OCO · `api.stats()` thống kê lệnh đã đóng · `on_tester()` trả fitness riêng để tối ưu hoá xếp hạng (như OnTester của MT5) · `Ret.FROZEN` + `symbol_info().freeze_level` (freeze level kiểu MT5).
- **Quyền mạng theo bot:** khai báo `# @permission: network(api.example.com)` ở đầu file bot; bạn cho phép từng bot. **Chỉ cưỡng chế khi bot chạy ở tiến trình riêng** (Cài đặt → *Bot chạy ở = process*; chưa dùng được trên Android) - không phải ranh giới an ninh trước mã cố tình phá.
- **Backtest:** chọn thứ tự giá trong nến + nút **So sánh thứ tự giá trong nến**: kết quả đổi dấu nghĩa là chiến lược dựa vào giả định mà dữ liệu OHLC không kiểm chứng được. **Phát lại tín hiệu AI** đã ghi (model + dấu vân tay prompt) cho bot dùng `api.ai_signal` - chỉ tái dựng đúng tín hiệu đã ghi, không sinh lại câu trả lời của AI.
- **Không làm phiền:** Cài đặt → nút 1/4/8/24 giờ hoặc khung giờ ban đêm: tắt âm/rung nhưng cảnh báo vẫn được ghi và hiện thông báo im lặng; sự cố nghiêm trọng (kill switch, margin call, bot/dịch vụ lỗi, lệch vị thế…) mặc định vẫn kêu.
- **An toàn dữ liệu:** che khoá trong nhật ký/chat AI · phiên bản định dạng dữ liệu (file mới hơn app thì giữ nguyên) · xoay vòng nhật ký · cảnh báo rủi ro lần đầu trước LIVE · tuỳ chọn chặn chụp/quay màn hình.
- **SL/TP native** (Cài đặt, mặc định TẮT, thử demo/testnet trước): Binance Futures, OANDA (lệnh reduce-only) và **Binance Spot** (một lệnh OCO cho SL+TP, vì Spot không có reduce-only). **MetaApi/MT**: SL/TP gắn lên đúng ticket (v1.7.0); **cổng + EA MT4/MT5 và Exness** từ v1.8.0 (cần chép lại + biên dịch lại EA; Exness dò dạng thân yêu cầu lúc chạy, chưa kiểm chứng; netting: chỉ khi vị thế ảo là cả ticket) - HANDOFF 5h.

## 3. Chạy nền
Mặc định phiên chạy trong **dịch vụ nền** (thông báo trên thanh trạng thái: số bot, equity, lệnh mở): vẫn chạy khi tắt màn hình/thoát app, mở lại app tự gắn vào. Sự cố (bot lỗi, đạt ngưỡng lỗ, mất giá, đặt lệnh lỗi liên tiếp, dịch vụ bị giết) → **cảnh báo rung + âm**; dịch vụ crash → tự chạy lại và **khôi phục sổ lệnh + các bot**. Lần đầu nên cho app **không bị tối ưu pin**.

## 4. Tham số bot: tự nhận dạng, tự sinh form, đồng bộ như MT5
App **đọc khai báo tham số ngay trong code bot** (như MT5 nhận dạng từ khoá `input`) rồi **tự sinh form nhập** đúng kiểu: số → ô nhập có kiểm tra min/max, bật/tắt → công tắc, danh sách → ô chọn, nhóm → tiêu đề nhóm. Có 3 cách khai báo (dùng cách nào cũng được):
```python
class MyBot(BaseBot):
    inputs = {"lot": Input(0.01, "Khối lượng", min=0)}          # 1) dict (đầy đủ nhất: min/max/help/group/choices)
    fast = Input(10, "SMA nhanh", min=2)                        # 2) thuộc tính lớp = Input(...)

    # == Tín hiệu ==                                             # 3) chỉ cần thuộc tính có kiểu + giá trị (dạng 3 chỉ dùng
    rsi_period: int = 14        # Chu kỳ RSI                    #    khi không có dạng 1, 2); chú thích sau # là nhãn,
    mode: str = "both"          # Hướng [long|short|both]       #    [a|b|c] là ô chọn, "# == Tên ==" đặt nhóm
```
Mỗi tham số dùng được là `self.p.lot` **hoặc** `self.lot` (như biến `input` của MQ5). Giá trị người dùng nhập được lưu **riêng cho từng lần gắn bot vào tài sản**; ô sai kiểu/ngoài khoảng bị chặn ở form.
**Đồng bộ khi bot đang chạy** (đúng cơ chế MT5 *REASON_PARAMETERS*): ở tab Bot → *Tham số* → **Lưu & áp dụng**: bot gọi `on_deinit("params")`, nạp tham số mới, rồi gọi `on_init()` lại; **lệnh đang mở giữ nguyên**, biểu đồ có chấm ◆ "Đổi tham số: fast 10 → 12". Nếu `on_init()` trả về `False` (tham số sai, như `INIT_PARAMETERS_INCORRECT`) thì **tham số mới bị từ chối, quay lại tham số cũ** và bot không chết. Chạy qua dịch vụ nền cũng đồng bộ và được nhớ để khôi phục sau sự cố. Đổi file bot (kể cả AI vừa sửa): form tự cập nhật theo khai báo mới, tham số trùng tên được giữ.
**Bộ tham số có tên** (như file `.set`): *Lưu bộ / Nạp bộ*, *Sao chép / Dán* JSON. Backtest dùng đúng form này.

## 5. Viết bot
Bấm *Sao chép mẫu* (tab Bot) hoặc xem `pyea/examples/*.py.txt`.
```python
from pyea import BaseBot, Input, ta

class MyBot(BaseBot):
    name = "Bot của tôi"
    inputs = {"lot": Input(0.01, "Khối lượng", min=0), "fast": Input(10, "SMA nhanh", min=2)}

    def on_bar(self, candle):                       # khi 1 nến đóng
        closes = self.api.closes(100)
        f = ta.sma(closes, self.p.fast)
        if f and closes[-1] > f and not self.api.positions("buy"):
            self.api.buy(self.p.lot, sl=closes[-1] * 0.99, reason="Giá vượt SMA",
                         details={"SMA": round(f, 4), "giá": closes[-1]})
```
`self.api`: `symbol`, `timeframe` (tài sản/khung mà bot được GẮN vào), `buy/sell(volume, sl, tp, comment, reason, details, ai)` (sl/tp là **giá**; `reason`+`details` là nội dung popup khi chạm chấm), `close/close_all(..., reason, details)`, `positions/modify` (**chỉ lệnh của chính bot**), `candles/closes`, `plot(tên, giá trị)`, `status(text)`, `signal(text)`, `ai_signal`, `tick`, `balance`, `equity`, `log`. Chỉ dùng thư viện chuẩn + `pyea.ta`. Chỉ nạp file bạn tin tưởng - bot chạy với toàn quyền Python.

## 5b. Mất mạng, app bị giết, ngừng lâu (v1.7.0)
- **Mất mạng**: sau 30 giây app báo động nghiêm trọng, nói rõ bao nhiêu vị thế do **sàn** canh SL/TP (native, vẫn chạy) và bao nhiêu chỉ do **app** canh (KHÔNG chạy lúc này), nhắc lại mỗi 10 phút; có lại mạng thì đối soát với sàn ngay. Phiên không còn tự dừng khi mất giá (chỉ dừng nếu bạn đặt «Dừng phiên nếu mất giá liên tục quá»).
- **App bị hệ thống giết/crash**: báo thức giám sát dựng lại dịch vụ, khôi phục sổ lệnh, chờ mạng nếu chưa có, đối soát với sàn và báo nghiêm trọng nếu phiên đã ngừng ≥90 giây khi đang có vị thế.
- **Khớp lệnh với sàn**: vị thế/lệnh thay đổi lúc app không chạy được đối soát và đưa về đúng sàn, kèm giá đóng thật. **Giới hạn không thể tránh**: SL/TP và lệnh chờ do app giữ không chạy lúc app chết hoặc mất mạng - muốn sàn tự canh hãy bật SL/TP native (DEMO trước).
- **Lịch kinh tế** (Cài đặt → Lịch kinh tế, tự chọn nguồn): báo trước tin và tuỳ chọn chặn lệnh MỚI của bot/AI quanh giờ ra tin (lệnh tay và đóng lệnh không bị chặn).
- Tất cả mới kiểm bằng sàn giả; **chưa chạy trên sàn/Android thật** - xem HANDOFF 5g.

## 5c. Số liệu đồng bộ từ sàn như MT5 (v1.8.0)
- Khung **Giao dịch** hiện Số dư · Tài sản · Lãi/lỗ thả nổi · Ký quỹ · Ký quỹ còn dư · Mức ký quỹ **do sàn báo** (nhãn «SÀN»); không có số của sàn thì dùng sổ của app và ghi «sổ app». Trường sàn không báo hiện «-», không bịa 0. «Tổng lãi/lỗ» và «Thắng/số lệnh» luôn là sổ app.
- Từng vị thế: lãi/lỗ, swap, giá hiện tại do **sàn** tính (đúng contract size, quy đổi tiền) thay cho «chênh giá × khối lượng» của sổ app; hoa hồng chỉ hiện khi sàn báo theo vị thế.
- **Lịch sử & báo cáo → LỊCH SỬ TỪ SÀN**: Hôm nay/7/30/90 ngày với Lợi nhuận · Tiền nạp · Phí qua đêm · Phí trung gian · Số dư (định nghĩa như tab Lịch sử của MT5) và danh sách vị thế đã đóng, gồm cả lệnh bạn đánh tay ngoài app.
- Hiện có cho MetaApi, cổng MT5, cổng+EA (cần EA/cổng bản mới), hồ sơ cầu nối khai op `history` và Exness (tên trường chưa kiểm chứng). **Chưa có** cho OANDA/Binance/ccxt (app nói rõ). Chỉ ở chế độ chạy thật. Số của từng vị thế làm mới mỗi ~15 giây. Mới kiểm bằng sàn giả - **so với tab MT5 thật trước khi tin** (HANDOFF 5h).

## 6. Live & giới hạn
- Live: Binance Spot (không bán khống), Binance Futures USDT-M (one-way mode) hoặc OANDA (gộp vị thế 1 chiều/mã → bot/đặt tay không giữ đồng thời mua+bán cùng mã). Phí/PnL tính theo tiền báo giá của mã (xấp xỉ khi quote ≠ tiền tài khoản).
- AI chỉ **tư vấn**; bot luôn là bên quyết định cuối. API key được mã hoá khi lưu (Android Keystore; trên máy tính dùng khoá file - xem 2d) và bị che khỏi nhật ký/chat.
- Đã test bằng giả lập (1370 test) và Kivy giả; **chưa chạy trên thiết bị thật** - xem mục 5–6 HANDOFF.md.
- Chạy test lõi: `python -m unittest discover -s tests -v` (không cần Kivy).
