# PyEA Runner

Ứng dụng Android chạy **bot giao dịch viết bằng Python** (như MT5 nạp file EA), có giao diện theo dõi, bảng thông số tự sinh và **chat nhiều AI** để giải thích / sửa bot.

> Tài liệu kỹ thuật cho người/AI tiếp quản: xem **HANDOFF.md**.
> Mặc định chạy **paper (giả lập)**. Giao dịch thật (Binance Spot) là tính năng thử nghiệm — chỉ dùng sau khi đã thử kỹ, có thể mất vốn.

## 1. Build APK trên GitHub
1. Tạo repo mới trên GitHub, đẩy **toàn bộ nội dung** của zip lên nhánh `main`:
   ```
   git init && git add -A && git commit -m "init"
   git branch -M main && git remote add origin <URL-repo> && git push -u origin main
   ```
   (Upload qua web hay bỏ sót thư mục ẩn `.github` → nếu thiếu, tạo file `.github/workflows/build-apk.yml` bằng tay, dán nội dung từ `docs/build-apk.yml`.)
2. Vào tab **Actions → Build APK** (tự chạy khi push, hoặc bấm *Run workflow*). Lần đầu 30–60 phút.
3. Xong: mở lần chạy → **Artifacts → pyearunner-apk** → tải file `.apk` → cài lên điện thoại (cho phép cài từ nguồn ngoài).
   Muốn APK nằm ở mục Releases: `git tag v1.0.0 && git push --tags`.

Máy 64-bit chắc chắn có thể bỏ `armeabi-v7a` trong `buildozer.spec` (mục `android.archs`) để build nhanh gấp đôi.

## 2. Dùng app
- **Bot**: chọn bot (có sẵn 4 bot mẫu) → *Nạp file .py* để thêm bot của bạn → **CHẠY BOT**.
- **Thông số**: ô nhập tự sinh từ `inputs` của bot + cài đặt chung (cặp, khung giờ, vốn paper, đòn bẩy, phí, ngưỡng dừng lỗ…). Bấm **Lưu**; áp dụng khi chạy lại bot.
- **Giám sát**: kiểu MT5 — nến + lưới + trục giá/giờ, đường chỉ báo bot vẽ (chip **ẩn/hiện** từng đường), **chấm vào/ra lệnh** (▲ mua, ▼ bán, ● thoát, ◆ tín hiệu bị bỏ qua) nối bằng đường nét đứt, thu phóng/cuộn lùi. **Chạm vào chấm** (hoặc vào dòng trong "Điểm vào/ra gần đây") → popup nêu **nguồn quyết định** (thuật toán bot / AI / SL / TP / thủ công), **lý do**, **điều kiện & thông số kích hoạt**, giá trị các chỉ báo lúc đó, tham số bot; nếu do AI: model nào, tin cậy, lý do từng model và trích thảo luận. Dòng "Bot đang nghĩ" hiển thị `self.api.status(...)`.
- **AI**: *Quản lý AI* → thêm AI (nhà cung cấp, model, API key) → *Thử*. Chế độ: **Chat 1 AI**, **Nhóm AI + tôi**, **Nhóm AI tự thảo luận** (ra tín hiệu cho bot `ai_follow`). Nút *Giải thích bot*; khi AI trả code mới sẽ có nút *Xem & áp dụng code*.
- **Nhật ký**: log bot/app; nút **Kiểm tra hệ thống** (báo cáo thiết bị, mạng, dịch vụ nền, pin... — dán lại khi cần hỗ trợ).
- **Chạy nền**: mặc định bot chạy trong **dịch vụ nền** (có thông báo trên thanh trạng thái: bot, cặp, equity, số lệnh mở) nên vẫn chạy khi tắt màn hình/thoát app; mở lại app tự gắn vào. Sự cố (bot lỗi, đạt ngưỡng lỗ, mất giá, đặt lệnh lỗi liên tiếp, dịch vụ bị giết) → **thông báo cảnh báo rung + âm**; dịch vụ crash → tự khởi động lại và **khôi phục sổ lệnh**. Lần đầu nên bấm *Mở cài đặt* để loại app khỏi tối ưu pin.
- Nút **Back** đưa app xuống nền. Thoát hẳn: tab Bot → *Thoát ứng dụng* (chọn bot chạy tiếp hoặc dừng).

## 3. Viết bot
Bấm *Sao chép mẫu* (tab Bot) hoặc xem `pyea/examples/*.py.txt`.
```python
from pyea import BaseBot, Input, ta

class MyBot(BaseBot):
    name = "Bot của tôi"
    inputs = {"lot": Input(0.01, "Khối lượng", min=0), "fast": Input(10, "SMA nhanh", min=2)}

    def on_bar(self, candle):                       # khi 1 nến đóng
        closes = self.api.closes(100)
        f = ta.sma(closes, self.p.fast)
        if f and closes[-1] > f and not self.api.positions("buy"):
            self.api.buy(self.p.lot, sl=closes[-1] * 0.99, comment="vượt SMA")
```
`self.api`: `buy/sell(volume, sl, tp, comment, reason, details, ai)` (sl/tp là **giá**; `reason` + `details` là nội dung popup khi chạm chấm — hãy ghi rõ điều kiện đã kích hoạt; `ai=sig` nếu theo tín hiệu AI), `close/close_all(..., reason, details)`, `positions/modify`, `candles/closes`, `plot(tên, giá trị)`, `status(text)`, `signal(text)` (đánh dấu tín hiệu bị bỏ qua), `ai_signal`, `tick`, `balance`, `equity`, `log`. Chỉ dùng thư viện chuẩn + `pyea.ta` (không có numpy/pandas). Chỉ nạp file bạn tin tưởng — bot chạy với toàn quyền Python.

## 4. AI miễn phí / chuyên biệt tài chính
Mọi nhà cung cấp dùng chuẩn OpenAI `/chat/completions`. Preset có sẵn: OpenRouter (model đuôi `:free`), Groq, Google Gemini, Cerebras, Mistral, NVIDIA NIM; **Máy chủ riêng / Tuỳ chỉnh** cho model tài chính tự host (Ollama/vLLM). Gói miễn phí và tên model thay đổi thường xuyên → tự kiểm tra danh sách hiện hành rồi nhập tên model. API key lưu dạng văn bản thường trong bộ nhớ riêng của app.
AI chỉ **tư vấn**; bot luôn là bên quyết định cuối (khối lượng, SL/TP).

## 5. Live & giới hạn đã biết
- Live: **Binance Spot** (không bán khống) hoặc **Futures USDT-M** (mua/bán khống, đòn bẩy; tài khoản phải ở One-way mode). Hãy thử **Testnet** (bật trong Thông số) trước khi dùng tiền thật.
- AI chốt quyết định: `decider` (1 AI) hoặc `majority` (mọi AI bỏ phiếu, cần đa số đồng thuận — an toàn hơn).
- Đã test bằng giả lập (43 test), **chưa chạy trên thiết bị thật**: lỗi đầu tiên khi build/chạy là bình thường — xem mục 5–6 của HANDOFF.md. API key lưu dạng văn bản trong bộ nhớ riêng của app (đã tắt sao lưu), chưa mã hoá.

Chạy test lõi (không cần Kivy): `python -m unittest discover -s tests -v`
