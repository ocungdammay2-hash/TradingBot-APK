"""
Nguồn giá nhiều tài sản (feed). Giao diện chung:
    symbols() -> list[str]            danh sách mã (Market Watch)
    tick(symbol) -> Tick              giá bid/ask hiện tại
    history(symbol, tf, n, end=None)  n nến kết thúc trước `end` (epoch giây; None = mới nhất)
    close()
Các nguồn:
  SimFeed     : nhiều tài sản giả (crypto/forex/vàng/cổ phiếu/chỉ số) chạy offline, tua nhanh được
  BinanceFeed : crypto thật (spot hoặc futures USDT-M), API công khai
  OandaFeed   : forex / kim loại / chỉ số CFD thật (tài khoản demo miễn phí) - cần token + account id
"""
import json
import math
import random
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

from .sdk import Candle, Tick

TIMEFRAMES = {
    "1m": 60, "5m": 300, "15m": 900, "30m": 1800,
    "1h": 3600, "4h": 14400, "1d": 86400,
}


class FeedError(Exception):
    pass


def tf_seconds(tf):
    try:
        return TIMEFRAMES[tf]
    except KeyError:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)


# --------------------------------------------------------------------------
# HTTP (dùng certifi để chạy được trên Android)
# --------------------------------------------------------------------------
_ctx = None


def ssl_context():
    global _ctx
    if _ctx is None:
        try:
            import certifi
            _ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            _ctx = ssl.create_default_context()
    return _ctx


def http_json(url, params=None, headers=None, method="GET", timeout=10, body=None):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    headers = dict(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers.setdefault("Content-Type", "application/json")
        if method == "GET":
            method = "POST"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body_txt = e.read().decode("utf-8", "ignore")
        except Exception:
            body_txt = ""
        raise FeedError("HTTP %s: %s" % (e.code, body_txt[:200]))
    except Exception as e:
        raise FeedError("Lỗi mạng: %s" % e)


# --------------------------------------------------------------------------
# Feed mô phỏng nhiều tài sản
# --------------------------------------------------------------------------
# symbol: (giá khởi điểm, biến động/phút, loại)
SIM_UNIVERSE = {
    "BTCUSD": (30000.0, 0.0007, "crypto"), "ETHUSD": (2000.0, 0.0009, "crypto"),
    "EURUSD": (1.0800, 0.00012, "forex"), "GBPUSD": (1.2600, 0.00014, "forex"),
    "XAUUSD": (2300.0, 0.00025, "kim loại"), "US500": (5200.0, 0.00018, "chỉ số"),
    "AAPL": (190.0, 0.0004, "cổ phiếu"), "USOIL": (78.0, 0.0005, "hàng hoá"),
}


class SimFeed:
    """Giá ngẫu nhiên (random walk có drift chậm) cho nhiều mã. `speed` = số giây mô phỏng
    trôi qua trong 1 giây thật (speed=10 -> nến 1 phút đóng sau ~6 giây thật)."""

    max_chunk = 200000        # lịch sử giả sinh liền 1 lần (không phân trang -> không đứt giá)

    def __init__(self, start_price=30000.0, speed=10.0, vol_per_min=0.0007, seed=None, universe=None):
        self.universe = dict(universe or SIM_UNIVERSE)
        self.default = (float(start_price), float(vol_per_min), "khác")
        self.speed = float(speed)
        self.seed = seed
        self._t0_wall = time.time()
        self._t0_mono = time.monotonic()
        self._st = {}

    @property
    def sim_time(self):
        return self._t0_wall + (time.monotonic() - self._t0_mono) * self.speed

    def symbols(self):
        return sorted(self.universe)

    def _state(self, symbol):
        st = self._st.get(symbol)
        if st is None:
            p0, vol, _ = self.universe.get(symbol, self.default)
            rng = random.Random("%s|%s" % (self.seed, symbol)) if self.seed is not None else random.Random()
            st = self._st[symbol] = {"price": p0, "vol": vol, "drift": 0.0, "rng": rng, "last": time.monotonic()}
        return st

    def tick(self, symbol):
        st = self._state(symbol)
        now = time.monotonic()
        dt = max((now - st["last"]) * self.speed, 0.01)
        st["last"] = now
        scale = math.sqrt(dt / 60.0)
        rng, vol = st["rng"], st["vol"]
        st["drift"] = 0.97 * st["drift"] + rng.gauss(0, vol * 0.15) * scale
        st["price"] *= math.exp(st["drift"] * scale + rng.gauss(0, vol * scale))
        half = st["price"] * 0.00005
        return Tick(symbol, self.sim_time, st["price"] - half, st["price"] + half)

    def history(self, symbol, tf, n, end=None):
        st = self._state(symbol)
        step = tf_seconds(tf)
        t_end = int((end if end is not None else self.sim_time) // step) * step
        rng = random.Random("%s|h|%s|%s|%s" % (self.seed, symbol, tf, int(t_end)))
        raw, p = [], 1.0
        for i in range(n):
            o = p
            hi = lo = o
            for _ in range(8):
                p *= math.exp(rng.gauss(0, st["vol"] * math.sqrt(step / 60.0 / 8)))
                hi, lo = max(hi, p), min(lo, p)
            raw.append((t_end - (n - i) * step, o, hi, lo, p))
        k = st["price"] / p
        return [Candle(t, o * k, h * k, l * k, c * k, 0.0) for (t, o, h, l, c) in raw]

    def close(self):
        pass


# --------------------------------------------------------------------------
# Binance (public)
# --------------------------------------------------------------------------
_BASES = {
    ("binance_spot", False): "https://api.binance.com",
    ("binance_spot", True): "https://testnet.binance.vision",
    ("binance_futures", False): "https://fapi.binance.com",
    ("binance_futures", True): "https://testnet.binancefuture.com",
    ("oanda", False): "https://api-fxtrade.oanda.com",
    ("oanda", True): "https://api-fxpractice.oanda.com",
}


def resolve_base(settings):
    """URL gốc theo sàn/testnet; `base_url` (nếu nhập) được ưu tiên."""
    custom = (settings.get("base_url") or "").strip()
    if custom:
        return custom.rstrip("/")
    return _BASES.get((settings.get("exchange", "binance_spot"), bool(settings.get("testnet"))),
                      "https://api.binance.com")


class BinanceFeed:
    def __init__(self, base_url="https://api.binance.com", futures=False):
        self.base = base_url.rstrip("/")
        self.p = "/fapi/v1" if futures else "/api/v3"
        self.offset = None
        self._symbols = None

    def _sync(self):
        try:
            d = http_json(self.base + self.p + "/time")
            self.offset = d["serverTime"] / 1000.0 - time.time()
        except Exception:
            self.offset = 0.0

    def symbols(self):
        if self._symbols is None:
            rows = http_json(self.base + self.p + "/ticker/price", timeout=20)
            if not isinstance(rows, list):
                raise FeedError("Danh sách mã không hợp lệ")
            self._symbols = sorted(r["symbol"] for r in rows if r.get("symbol", "").endswith("USDT"))
        return self._symbols

    def tick(self, symbol):
        if self.offset is None:
            self._sync()
        d = http_json(self.base + self.p + "/ticker/bookTicker", {"symbol": symbol})
        try:
            return Tick(symbol, time.time() + self.offset, float(d["bidPrice"]), float(d["askPrice"]))
        except (KeyError, ValueError):
            raise FeedError("Phản hồi giá không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        params = {"symbol": symbol, "interval": tf, "limit": max(2, min(int(n), 1000))}
        if end is not None:
            params["endTime"] = int(end * 1000) - 1
        rows = http_json(self.base + self.p + "/klines", params)
        if not isinstance(rows, list):
            raise FeedError("Phản hồi nến không hợp lệ")
        return [Candle(r[0] / 1000.0, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5]))
                for r in rows]

    def close(self):
        pass


# --------------------------------------------------------------------------
# OANDA v20 (forex / kim loại / chỉ số CFD)
# --------------------------------------------------------------------------
_OANDA_GRAN = {"1m": "M1", "5m": "M5", "15m": "M15", "30m": "M30", "1h": "H1", "4h": "H4", "1d": "D"}


class OandaFeed:
    def __init__(self, base_url, token, account_id):
        if not token or not account_id:
            raise FeedError("OANDA cần API token và Account ID")
        self.base = base_url.rstrip("/")
        self.h = {"Authorization": "Bearer " + token.strip()}
        self.acc = account_id.strip()
        self._symbols = None

    def _get(self, path, params=None):
        return http_json(self.base + path, params, headers=self.h, timeout=15)

    def symbols(self):
        if self._symbols is None:
            d = self._get("/v3/accounts/%s/instruments" % self.acc)
            self._symbols = sorted(i["name"] for i in d.get("instruments", []))
        return self._symbols

    def tick(self, symbol):
        d = self._get("/v3/accounts/%s/pricing" % self.acc, {"instruments": symbol})
        try:
            p = d["prices"][0]
            t = p.get("time")
            return Tick(symbol, _oanda_time(t) if t else time.time(), float(p["bids"][0]["price"]), float(p["asks"][0]["price"]))
        except (KeyError, IndexError, ValueError, TypeError):
            raise FeedError("Phản hồi giá OANDA không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        gran = _OANDA_GRAN.get(tf)
        if not gran:
            raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)
        params = {"granularity": gran, "count": max(2, min(int(n), 5000)), "price": "M"}
        if end is not None:
            params["to"] = "%.0f" % end
        d = self._get("/v3/instruments/%s/candles" % symbol, params)
        out = []
        for c in d.get("candles", []):
            m = c.get("mid") or {}
            try:
                out.append(Candle(_oanda_time(c["time"]), float(m["o"]), float(m["h"]), float(m["l"]), float(m["c"]),
                                  float(c.get("volume", 0))))
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def close(self):
        pass


def _oanda_time(t):
    """RFC3339 ('2024-01-02T03:04:05.000000000Z') hoặc epoch -> epoch giây."""
    try:
        return float(t)
    except (TypeError, ValueError):
        pass
    import calendar
    s = str(t).split(".")[0].rstrip("Z")
    return float(calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%S")))


# --------------------------------------------------------------------------
def make_feed(kind, settings):
    """kind: simulated | binance_spot | binance_futures | oanda  (còn nhận 'binance' = spot)."""
    if kind in ("binance", "binance_spot", "binance_futures"):
        fut = kind == "binance_futures"
        st = dict(settings, exchange="binance_futures" if fut else "binance_spot")
        return BinanceFeed(resolve_base(st), futures=fut)
    if kind == "oanda":
        return OandaFeed(resolve_base(dict(settings, exchange="oanda")), settings.get("oanda_token", ""),
                         settings.get("oanda_account", ""))
    return SimFeed(start_price=float(settings.get("sim_start_price", 30000.0)),
                   speed=float(settings.get("sim_speed", 10.0)))


def fetch_history(feed, symbol, tf, bars, end=None, progress=None):
    """Lấy `bars` nến (có phân trang) kết thúc trước `end`. Trả về list Candle cũ -> mới, không trùng."""
    step = tf_seconds(tf)
    out, cursor, guard = [], end, 0
    while len(out) < bars and guard < 60:
        guard += 1
        chunk = feed.history(symbol, tf, min(getattr(feed, "max_chunk", 1000), bars - len(out) + 2), cursor)
        if not chunk:
            break
        chunk = [c for c in chunk if end is None or c.time < end]
        if not chunk:
            break
        out = chunk + out
        new_cursor = chunk[0].time
        if cursor is not None and new_cursor >= cursor:
            break
        cursor = new_cursor
        if progress:
            progress(len(out), bars)
    seen, uniq = set(), []
    for c in out:
        if c.time not in seen:
            seen.add(c.time)
            uniq.append(c)
    uniq.sort(key=lambda c: c.time)
    return uniq[-bars:]
