"""
Nguồn giá (feed):
  - SimFeed     : giá mô phỏng ngẫu nhiên, chạy offline, có thể tua nhanh thời gian (để thử bot)
  - BinanceFeed : giá thật từ API công khai của Binance (không cần API key)
"""
import json
import math
import random
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

from .sdk import Candle, Tick

TIMEFRAMES = {
    "1m": 60, "5m": 300, "15m": 900, "30m": 1800,
    "1h": 3600, "4h": 14400, "1d": 86400,
}


class FeedError(Exception):
    pass


def tf_seconds(tf):
    try:
        return TIMEFRAMES[tf]
    except KeyError:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)


# --------------------------------------------------------------------------
# HTTP (dùng certifi để chạy được trên Android)
# --------------------------------------------------------------------------
_ctx = None


def ssl_context():
    global _ctx
    if _ctx is None:
        try:
            import certifi
            _ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            _ctx = ssl.create_default_context()
    return _ctx


def http_json(url, params=None, headers=None, method="GET", timeout=10, body=None):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    headers = dict(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers.setdefault("Content-Type", "application/json")
        if method == "GET":
            method = "POST"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "ignore")
        except Exception:
            body = ""
        raise FeedError("HTTP %s: %s" % (e.code, body[:200]))
    except Exception as e:
        raise FeedError("Lỗi mạng: %s" % e)


# --------------------------------------------------------------------------
# Feed mô phỏng
# --------------------------------------------------------------------------
class SimFeed:
    """
    Giá ngẫu nhiên (random walk có drift chậm). `speed` = số giây mô phỏng trôi qua
    trong 1 giây thật; speed=10 -> nến 1 phút đóng sau ~6 giây thật.
    """

    def __init__(self, start_price=30000.0, speed=10.0, vol_per_min=0.0007, seed=None):
        self.rng = random.Random(seed)
        self.price = float(start_price)
        self.speed = float(speed)
        self.vol = float(vol_per_min)
        self.drift = 0.0
        self.sim_time = time.time()
        self._last_real = time.monotonic()

    def tick(self, symbol):
        now = time.monotonic()
        dt_real = max(0.0, now - self._last_real)
        self._last_real = now
        dt = max(dt_real * self.speed, 0.01)
        self.sim_time += dt
        scale = math.sqrt(dt / 60.0)
        self.drift = 0.97 * self.drift + self.rng.gauss(0, self.vol * 0.15) * scale
        self.price *= math.exp(self.drift * scale + self.rng.gauss(0, self.vol * scale))
        half_spread = self.price * 0.00005
        return Tick(symbol, self.sim_time, self.price - half_spread, self.price + half_spread)

    def history(self, symbol, tf, n):
        step = tf_seconds(tf)
        t_end = int(self.sim_time // step) * step      # mở nến hiện tại
        raw = []
        p = 1.0
        for i in range(n):
            o = p
            hi = lo = o
            for _ in range(8):
                p *= math.exp(self.rng.gauss(0, self.vol * math.sqrt(step / 60.0 / 8)))
                hi = max(hi, p)
                lo = min(lo, p)
            raw.append((t_end - (n - i) * step, o, hi, lo, p))
        k = self.price / p
        return [Candle(t, o * k, h * k, l * k, c * k, 0.0) for (t, o, h, l, c) in raw]

    def close(self):
        pass


# --------------------------------------------------------------------------
# Feed Binance (public)
# --------------------------------------------------------------------------
_BASES = {
    ("binance_spot", False): "https://api.binance.com",
    ("binance_spot", True): "https://testnet.binance.vision",
    ("binance_futures", False): "https://fapi.binance.com",
    ("binance_futures", True): "https://testnet.binancefuture.com",
}


def resolve_base(settings):
    """URL gốc theo exchange/testnet; `base_url` (nếu nhập) được ưu tiên."""
    custom = (settings.get("base_url") or "").strip()
    if custom:
        return custom.rstrip("/")
    return _BASES.get((settings.get("exchange", "binance_spot"), bool(settings.get("testnet"))),
                      "https://api.binance.com")


class BinanceFeed:
    """Giá công khai của Binance (spot hoặc futures USDT-M)."""

    def __init__(self, base_url="https://api.binance.com", futures=False):
        self.base = base_url.rstrip("/")
        self.p = "/fapi/v1" if futures else "/api/v3"
        self.offset = None   # chênh lệch giờ server - giờ máy

    def _sync(self):
        try:
            d = http_json(self.base + self.p + "/time")
            self.offset = d["serverTime"] / 1000.0 - time.time()
        except Exception:
            self.offset = 0.0

    def tick(self, symbol):
        if self.offset is None:
            self._sync()
        d = http_json(self.base + self.p + "/ticker/bookTicker", {"symbol": symbol})
        try:
            return Tick(symbol, time.time() + self.offset, float(d["bidPrice"]), float(d["askPrice"]))
        except (KeyError, ValueError):
            raise FeedError("Phản hồi giá không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n):
        tf_seconds(tf)
        rows = http_json(self.base + self.p + "/klines",
                         {"symbol": symbol, "interval": tf, "limit": max(2, min(int(n), 1000))})
        if not isinstance(rows, list):
            raise FeedError("Phản hồi nến không hợp lệ")
        return [Candle(r[0] / 1000.0, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5]))
                for r in rows]

    def close(self):
        pass


def make_feed(kind, settings):
    """kind: simulated | binance (spot) | binance_futures"""
    if kind in ("binance", "binance_futures"):
        fut = kind == "binance_futures"
        st = dict(settings)
        st["exchange"] = "binance_futures" if fut else "binance_spot"
        return BinanceFeed(resolve_base(st), futures=fut)
    return SimFeed(start_price=float(settings.get("sim_start_price", 30000.0)),
                   speed=float(settings.get("sim_speed", 10.0)))
