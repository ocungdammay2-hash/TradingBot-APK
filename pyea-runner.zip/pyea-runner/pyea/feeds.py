"""
Nguồn giá nhiều tài sản (feed). Giao diện chung:
    symbols() -> list[str]            danh sách mã (Market Watch)
    tick(symbol) -> Tick              giá bid/ask hiện tại
    history(symbol, tf, n, end=None)  n nến kết thúc trước `end` (epoch giây; None = mới nhất)
    close()
Các nguồn:
  SimFeed     : nhiều tài sản giả (crypto/forex/vàng/cổ phiếu/chỉ số) chạy offline, tua nhanh được
  BinanceFeed : crypto thật (spot hoặc futures USDT-M), API công khai
  OandaFeed   : forex / kim loại / chỉ số CFD thật (tài khoản demo miễn phí) - cần token + account id
"""
import calendar
import json
import math
import random
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict

from .sdk import Candle, Tick

# Bộ khung thời gian đầy đủ như MT5 (M1..M30, H1..H12, D1, W1, MN1). Giữ tên cũ (1m/5m/1h/1d) để không vỡ cấu hình đã lưu.
# Quy ước nến (UTC, mọi nguồn dùng chung để nến lịch sử khớp nến dựng từ tick):
#   phút/giờ/ngày: mở tại bội số của khung tính từ 00:00 UTC · tuần "1w": mở Thứ Hai 00:00 UTC · tháng "1mo": ngày 1 hằng tháng.
TIMEFRAMES = OrderedDict([
    ("1m", 60), ("2m", 120), ("3m", 180), ("4m", 240), ("5m", 300), ("6m", 360), ("10m", 600), ("12m", 720),
    ("15m", 900), ("20m", 1200), ("30m", 1800),
    ("1h", 3600), ("2h", 7200), ("3h", 10800), ("4h", 14400), ("6h", 21600), ("8h", 28800), ("12h", 43200),
    ("1d", 86400), ("1w", 604800), ("1mo", 2592000),      # 1mo: độ dài danh nghĩa 30 ngày (độ dài thật: tf_span)
])
TF_LABELS = OrderedDict((k, k) for k in TIMEFRAMES)
TF_LABELS.update({"1mo": "1 tháng", "1w": "1 tuần", "1d": "1 ngày"})
TF_GROUPS = [("PHÚT", ["1m", "2m", "3m", "4m", "5m", "6m", "10m", "12m", "15m", "20m", "30m"]),
             ("GIỜ", ["1h", "2h", "3h", "4h", "6h", "8h", "12h"]),
             ("NGÀY (1d) · TUẦN (1w) · THÁNG (1mo)", ["1d", "1w", "1mo"])]
_WEEK_ANCHOR = 4 * 86400        # 1970-01-05 00:00 UTC là Thứ Hai


class FeedError(Exception):
    pass


def tf_seconds(tf):
    try:
        return TIMEFRAMES[tf]
    except KeyError:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)


def tf_bucket(tf, t):
    """Giờ MỞ của nến chứa thời điểm t (epoch giây UTC)."""
    step = tf_seconds(tf)
    if tf == "1mo":
        g = time.gmtime(t)
        return calendar.timegm((g.tm_year, g.tm_mon, 1, 0, 0, 0))
    if tf == "1w":
        return int((t - _WEEK_ANCHOR) // step) * step + _WEEK_ANCHOR
    return int(t // step) * step


def tf_prev(tf, start, k=1):
    """Giờ mở của nến đứng trước nến mở lúc `start` đúng k nến."""
    if tf == "1mo":
        g = time.gmtime(start)
        y, m = divmod(g.tm_year * 12 + (g.tm_mon - 1) - k, 12)
        return calendar.timegm((y, m + 1, 1, 0, 0, 0))
    return start - k * tf_seconds(tf)


def tf_next(tf, start):
    return tf_prev(tf, start, -1)


def tf_span(tf, start):
    """Độ dài THẬT (giây) của nến mở lúc `start` (tháng có 28-31 ngày)."""
    return tf_next(tf, start) - start


def resample(candles, tf):
    """Gộp nến nhỏ thành khung `tf` (nến đã sắp xếp hoặc không). Nến cuối có thể chưa đủ (đang hình thành)."""
    out, cur = [], None
    for c in sorted(candles, key=lambda c: c.time):
        b = tf_bucket(tf, c.time)
        if cur is not None and cur.time == b:
            cur.high = max(cur.high, c.high)
            cur.low = min(cur.low, c.low)
            cur.close = c.close
            cur.volume += c.volume
        else:
            cur = Candle(b, c.open, c.high, c.low, c.close, c.volume)
            out.append(cur)
    return out


def pick_base(tf, native):
    """Khung gốc LỚN NHẤT mà sàn có sẵn và chia hết `tf` (để ghép nến, vd 3h = 3 x 1h, 12m = 4 x 3m)."""
    want = tf_seconds(tf)
    best = None
    for k in native:
        if k in ("1w", "1mo"):
            continue
        s = TIMEFRAMES[k]
        if s < want and want % s == 0 and (best is None or s > TIMEFRAMES[best]):
            best = k
    return best


def history_resampled(feed, native, symbol, tf, n, end=None):
    """Lấy n nến khung `tf` cho sàn không có sẵn khung đó: tải khung gốc rồi ghép (bỏ nến đầu vì thường thiếu phần đầu)."""
    base = pick_base(tf, native)
    if base is None:
        raise FeedError("Khung thời gian không hỗ trợ: %s" % tf)
    ratio = TIMEFRAMES[tf] // TIMEFRAMES[base]
    raw = fetch_history(feed, symbol, base, (int(n) + 1) * ratio, end)
    out = resample(raw, tf)
    if len(out) > 1:
        out = out[1:]
    return out[-int(n):]


# --------------------------------------------------------------------------
# HTTP (dùng certifi để chạy được trên Android)
# --------------------------------------------------------------------------
_ctx = None


def ssl_context():
    global _ctx
    if _ctx is None:
        try:
            import certifi
            _ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            _ctx = ssl.create_default_context()
    return _ctx


def http_json(url, params=None, headers=None, method="GET", timeout=10, body=None):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    headers = dict(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers.setdefault("Content-Type", "application/json")
        if method == "GET":
            method = "POST"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body_txt = e.read().decode("utf-8", "ignore")
        except Exception:
            body_txt = ""
        raise FeedError("HTTP %s: %s" % (e.code, body_txt[:200]))
    except Exception as e:
        raise FeedError("Lỗi mạng: %s" % e)


# --------------------------------------------------------------------------
# Feed mô phỏng nhiều tài sản
# --------------------------------------------------------------------------
# symbol: (giá khởi điểm, biến động/phút, loại)
SIM_UNIVERSE = {
    "BTCUSD": (30000.0, 0.0007, "crypto"), "ETHUSD": (2000.0, 0.0009, "crypto"),
    "EURUSD": (1.0800, 0.00012, "forex"), "GBPUSD": (1.2600, 0.00014, "forex"),
    "XAUUSD": (2300.0, 0.00025, "kim loại"), "US500": (5200.0, 0.00018, "chỉ số"),
    "AAPL": (190.0, 0.0004, "cổ phiếu"), "USOIL": (78.0, 0.0005, "hàng hoá"),
}


class SimFeed:
    """Giá ngẫu nhiên (random walk có drift chậm) cho nhiều mã. `speed` = số giây mô phỏng
    trôi qua trong 1 giây thật (speed=10 -> nến 1 phút đóng sau ~6 giây thật)."""

    max_chunk = 200000        # lịch sử giả sinh liền 1 lần (không phân trang -> không đứt giá)

    def __init__(self, start_price=30000.0, speed=10.0, vol_per_min=0.0007, seed=None, universe=None):
        self.universe = dict(universe or SIM_UNIVERSE)
        self.default = (float(start_price), float(vol_per_min), "khác")
        self.speed = float(speed)
        self.seed = seed
        self._t0_wall = time.time()
        self._t0_mono = time.monotonic()
        self._st = {}

    @property
    def sim_time(self):
        return self._t0_wall + (time.monotonic() - self._t0_mono) * self.speed

    def symbols(self):
        return sorted(self.universe)

    def _state(self, symbol):
        st = self._st.get(symbol)
        if st is None:
            p0, vol, _ = self.universe.get(symbol, self.default)
            rng = random.Random("%s|%s" % (self.seed, symbol)) if self.seed is not None else random.Random()
            st = self._st[symbol] = {"price": p0, "vol": vol, "drift": 0.0, "rng": rng, "last": time.monotonic()}
        return st

    def tick(self, symbol):
        st = self._state(symbol)
        now = time.monotonic()
        dt = max((now - st["last"]) * self.speed, 0.01)
        st["last"] = now
        scale = math.sqrt(dt / 60.0)
        rng, vol = st["rng"], st["vol"]
        st["drift"] = 0.97 * st["drift"] + rng.gauss(0, vol * 0.15) * scale
        st["price"] *= math.exp(st["drift"] * scale + rng.gauss(0, vol * scale))
        half = st["price"] * 0.00005
        return Tick(symbol, self.sim_time, st["price"] - half, st["price"] + half)

    def history(self, symbol, tf, n, end=None):
        st = self._state(symbol)
        tf_seconds(tf)
        t_end = tf_bucket(tf, end if end is not None else self.sim_time)
        rng = random.Random("%s|h|%s|%s|%s" % (self.seed, symbol, tf, int(t_end)))
        raw, p = [], 1.0
        for i in range(n):
            t0 = tf_prev(tf, t_end, n - i)
            step = tf_span(tf, t0)
            o = p
            hi = lo = o
            for _ in range(8):
                p *= math.exp(rng.gauss(0, st["vol"] * math.sqrt(step / 60.0 / 8)))
                hi, lo = max(hi, p), min(lo, p)
            raw.append((t0, o, hi, lo, p))
        k = st["price"] / p
        return [Candle(t, o * k, h * k, l * k, c * k, 0.0) for (t, o, h, l, c) in raw]

    def close(self):
        pass


# --------------------------------------------------------------------------
# Binance (public)
# --------------------------------------------------------------------------
_BASES = {
    ("binance_spot", False): "https://api.binance.com",
    ("binance_spot", True): "https://testnet.binance.vision",
    ("binance_futures", False): "https://fapi.binance.com",
    ("binance_futures", True): "https://testnet.binancefuture.com",
    ("oanda", False): "https://api-fxtrade.oanda.com",
    ("oanda", True): "https://api-fxpractice.oanda.com",
}


def resolve_base(settings):
    """URL gốc theo sàn/testnet; `base_url` (nếu nhập) được ưu tiên."""
    custom = (settings.get("base_url") or "").strip()
    if custom:
        return custom.rstrip("/")
    return _BASES.get((settings.get("exchange", "binance_spot"), bool(settings.get("testnet"))),
                      "https://api.binance.com")


# Khung Binance có sẵn (giá trị = chuỗi interval của API; tháng là "1M" viết hoa)
_BINANCE_INT = {"1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1h", "2h": "2h", "4h": "4h",
                "6h": "6h", "8h": "8h", "12h": "12h", "1d": "1d", "1w": "1w", "1mo": "1M"}


class BinanceFeed:
    def __init__(self, base_url="https://api.binance.com", futures=False):
        self.base = base_url.rstrip("/")
        self.p = "/fapi/v1" if futures else "/api/v3"
        self.offset = None
        self._symbols = None

    def _sync(self):
        try:
            d = http_json(self.base + self.p + "/time")
            self.offset = d["serverTime"] / 1000.0 - time.time()
        except Exception:
            self.offset = 0.0

    def symbols(self):
        if self._symbols is None:
            rows = http_json(self.base + self.p + "/ticker/price", timeout=20)
            if not isinstance(rows, list):
                raise FeedError("Danh sách mã không hợp lệ")
            self._symbols = sorted(r["symbol"] for r in rows if r.get("symbol", "").endswith("USDT"))
        return self._symbols

    def tick(self, symbol):
        if self.offset is None:
            self._sync()
        d = http_json(self.base + self.p + "/ticker/bookTicker", {"symbol": symbol})
        try:
            return Tick(symbol, time.time() + self.offset, float(d["bidPrice"]), float(d["askPrice"]))
        except (KeyError, ValueError):
            raise FeedError("Phản hồi giá không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        iv = _BINANCE_INT.get(tf)
        if iv is None:                      # 2m/4m/6m/10m/12m/20m/3h: Binance không có -> ghép từ khung nhỏ hơn
            return history_resampled(self, _BINANCE_INT, symbol, tf, n, end)
        params = {"symbol": symbol, "interval": iv, "limit": max(2, min(int(n), 1000))}
        if end is not None:
            params["endTime"] = int(end * 1000) - 1
        rows = http_json(self.base + self.p + "/klines", params)
        if not isinstance(rows, list):
            raise FeedError("Phản hồi nến không hợp lệ")
        return [Candle(r[0] / 1000.0, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5]))
                for r in rows]

    def close(self):
        pass


# --------------------------------------------------------------------------
# OANDA v20 (forex / kim loại / chỉ số CFD)
# --------------------------------------------------------------------------
_OANDA_GRAN = {"1m": "M1", "2m": "M2", "4m": "M4", "5m": "M5", "10m": "M10", "15m": "M15", "30m": "M30",
               "1h": "H1", "2h": "H2", "3h": "H3", "4h": "H4", "6h": "H6", "8h": "H8", "12h": "H12",
               "1d": "D", "1w": "W", "1mo": "M"}


class OandaFeed:
    def __init__(self, base_url, token, account_id):
        if not token or not account_id:
            raise FeedError("OANDA cần API token và Account ID")
        self.base = base_url.rstrip("/")
        self.h = {"Authorization": "Bearer " + token.strip()}
        self.acc = account_id.strip()
        self._symbols = None

    def _get(self, path, params=None):
        return http_json(self.base + path, params, headers=self.h, timeout=15)

    def symbols(self):
        if self._symbols is None:
            d = self._get("/v3/accounts/%s/instruments" % self.acc)
            self._symbols = sorted(i["name"] for i in d.get("instruments", []))
        return self._symbols

    def tick(self, symbol):
        d = self._get("/v3/accounts/%s/pricing" % self.acc, {"instruments": symbol})
        try:
            p = d["prices"][0]
            t = p.get("time")
            return Tick(symbol, _oanda_time(t) if t else time.time(), float(p["bids"][0]["price"]), float(p["asks"][0]["price"]),
                        tradeable=bool(p.get("tradeable", True)))
        except (KeyError, IndexError, ValueError, TypeError):
            raise FeedError("Phản hồi giá OANDA không hợp lệ: %s" % str(d)[:120])

    def history(self, symbol, tf, n, end=None):
        tf_seconds(tf)
        gran = _OANDA_GRAN.get(tf)
        if not gran:                        # 3m/6m/12m/20m: OANDA không có -> ghép từ khung nhỏ hơn
            return history_resampled(self, _OANDA_GRAN, symbol, tf, n, end)
        # Căn nến theo UTC (mặc định OANDA căn 17:00 New York) để khớp nến dựng từ tick; tuần mở Thứ Hai.
        params = {"granularity": gran, "count": max(2, min(int(n), 5000)), "price": "M",
                  "alignmentTimezone": "UTC", "dailyAlignment": 0, "weeklyAlignment": "Monday"}
        if end is not None:
            params["to"] = "%.0f" % end
        d = self._get("/v3/instruments/%s/candles" % symbol, params)
        out = []
        for c in d.get("candles", []):
            m = c.get("mid") or {}
            try:
                out.append(Candle(_oanda_time(c["time"]), float(m["o"]), float(m["h"]), float(m["l"]), float(m["c"]),
                                  float(c.get("volume", 0))))
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def close(self):
        pass


def _oanda_time(t):
    """RFC3339 ('2024-01-02T03:04:05.000000000Z') hoặc epoch -> epoch giây."""
    try:
        return float(t)
    except (TypeError, ValueError):
        pass
    import calendar
    s = str(t).split(".")[0].rstrip("Z")
    return float(calendar.timegm(time.strptime(s, "%Y-%m-%dT%H:%M:%S")))


# --------------------------------------------------------------------------
def make_feed(kind, settings):
    """kind: simulated | binance_spot | binance_futures | oanda  (còn nhận 'binance' = spot)."""
    if kind in ("binance", "binance_spot", "binance_futures"):
        fut = kind == "binance_futures"
        st = dict(settings, exchange="binance_futures" if fut else "binance_spot")
        return BinanceFeed(resolve_base(st), futures=fut)
    if kind == "oanda":
        return OandaFeed(resolve_base(dict(settings, exchange="oanda")), settings.get("oanda_token", ""),
                         settings.get("oanda_account", ""))
    return SimFeed(start_price=float(settings.get("sim_start_price", 30000.0)),
                   speed=float(settings.get("sim_speed", 10.0)))


def fetch_history(feed, symbol, tf, bars, end=None, progress=None):
    """Lấy `bars` nến (có phân trang) kết thúc trước `end`. Trả về list Candle cũ -> mới, không trùng."""
    step = tf_seconds(tf)
    out, cursor, guard = [], end, 0
    while len(out) < bars and guard < 60:
        guard += 1
        chunk = feed.history(symbol, tf, min(getattr(feed, "max_chunk", 1000), bars - len(out) + 2), cursor)
        if not chunk:
            break
        chunk = [c for c in chunk if end is None or c.time < end]
        if not chunk:
            break
        out = chunk + out
        new_cursor = chunk[0].time
        if cursor is not None and new_cursor >= cursor:
            break
        cursor = new_cursor
        if progress:
            progress(len(out), bars)
    seen, uniq = set(), []
    for c in out:
        if c.time not in seen:
            seen.add(c.time)
            uniq.append(c)
    uniq.sort(key=lambda c: c.time)
    return uniq[-bars:]
