"""
Strategy Tester kiểu MT5: chạy bot trên dữ liệu lịch sử bằng CHÍNH engine giao dịch (TradingSession đồng bộ),
nên SL/TP, phí, ký quỹ, sự kiện + lý do vào/ra lệnh hoạt động y như khi chạy thật.

Chế độ mô phỏng tick từ nến:
  ohlc : 4 tick/nến (O → L → H → C nếu nến tăng; O → H → L → C nếu nến giảm)  [mặc định, giống "1 minute OHLC"]
  open : 1 tick/nến tại giá mở cửa (rất nhanh, giống "Open prices only")
Giá bid/ask = giá ± spread/2 (spread_pct % của giá).
"""
import math
import threading
from collections import deque
from dataclasses import dataclass, field

from .engine import Account, CandleBuilder, TradingSession, _Halt
from .feeds import FeedError, tf_seconds
from .sdk import Candle, Tick

MODES = {"ohlc": "OHLC (4 tick/nến)", "open": "Chỉ giá mở cửa (nhanh)"}


class _ReplayFeed:
    def tick(self, symbol):
        raise FeedError("backtest: không có giá hiện tại cho %s" % symbol)

    def history(self, *a, **k):
        return []

    def symbols(self):
        return []

    def close(self):
        pass


def candle_ticks(c, step, mode):
    """[(thời gian, giá)] mô phỏng bên trong 1 nến."""
    if mode == "open":
        return [(c.time, c.open)]
    path = [c.open, c.low, c.high, c.close] if c.close >= c.open else [c.open, c.high, c.low, c.close]
    return [(c.time + step * k / 4.0, p) for k, p in enumerate(path)]


@dataclass
class BacktestResult:
    ok: bool = True
    error: str = ""
    report: dict = field(default_factory=dict)
    trades: list = field(default_factory=list)
    events: list = field(default_factory=list)
    candles: list = field(default_factory=list)       # nến hiển thị (cuối warm-up + cửa sổ test)
    plots: dict = field(default_factory=dict)
    curve: list = field(default_factory=list)         # [(t, balance, equity)]
    symbol: str = ""
    timeframe: str = ""
    params: dict = field(default_factory=dict)
    logs: list = field(default_factory=list)


def compute_report(trades, start_balance, curve, bars=0):
    n = len(trades)
    profits = [t.profit for t in trades]
    gp = sum(p for p in profits if p > 0)
    gl = sum(p for p in profits if p < 0)
    wins = [p for p in profits if p > 0]
    losses = [p for p in profits if p < 0]
    net = sum(profits)

    def streak(pred):
        best_n = best_m = cur_n = 0
        cur_m = 0.0
        for p in profits:
            if pred(p):
                cur_n += 1
                cur_m += p
                if cur_n > best_n:
                    best_n = cur_n
                if abs(cur_m) > abs(best_m):
                    best_m = cur_m
            else:
                cur_n, cur_m = 0, 0.0
        return best_n, best_m
    mw, mwm = streak(lambda p: p > 0)
    ml, mlm = streak(lambda p: p <= 0)
    longs = [t for t in trades if t.side == "buy"]
    shorts = [t for t in trades if t.side == "sell"]

    def wr(ts):
        return (sum(1 for t in ts if t.profit > 0) / len(ts) * 100.0) if ts else 0.0
    peak, dd_abs, dd_pct = start_balance, 0.0, 0.0
    for _, _, eq in curve:
        peak = max(peak, eq)
        dd_abs = max(dd_abs, peak - eq)
        if peak > 0:
            dd_pct = max(dd_pct, (peak - eq) / peak * 100.0)
    rets = []
    for i in range(1, len(curve)):
        e0, e1 = curve[i - 1][2], curve[i][2]
        if e0 > 0:
            rets.append(e1 / e0 - 1.0)
    sharpe = 0.0
    if len(rets) > 2:
        m = sum(rets) / len(rets)
        sd = math.sqrt(sum((r - m) ** 2 for r in rets) / (len(rets) - 1))
        sharpe = (m / sd * math.sqrt(len(rets))) if sd > 0 else 0.0
    end_eq = curve[-1][2] if curve else start_balance
    return {
        "Số dư ban đầu": start_balance, "Số dư cuối": start_balance + net, "Lợi nhuận ròng": net,
        "Lợi nhuận gộp": gp, "Lỗ gộp": gl,
        "Profit factor": (gp / abs(gl)) if gl < 0 else (None if gp == 0 else float("inf")),
        "Kỳ vọng / lệnh": (net / n) if n else 0.0, "Recovery factor": (net / dd_abs) if dd_abs > 0 else None,
        "Sharpe (xấp xỉ)": sharpe,
        "Sụt vốn tối đa (tuyệt đối)": dd_abs, "Sụt vốn tối đa (%)": dd_pct,
        "Tổng số lệnh": n, "Lệnh mua": len(longs), "Lệnh bán": len(shorts),
        "Thắng (%)": wr(trades), "Thắng - mua (%)": wr(longs), "Thắng - bán (%)": wr(shorts),
        "Lệnh lãi": len(wins), "Lệnh lỗ": len(losses),
        "Lãi lớn nhất": max(wins) if wins else 0.0, "Lỗ lớn nhất": min(losses) if losses else 0.0,
        "Lãi trung bình": (sum(wins) / len(wins)) if wins else 0.0, "Lỗ trung bình": (sum(losses) / len(losses)) if losses else 0.0,
        "Chuỗi thắng dài nhất (lệnh)": mw, "Chuỗi thắng dài nhất ($)": mwm,
        "Chuỗi thua dài nhất (lệnh)": ml, "Chuỗi thua dài nhất ($)": mlm,
        "Số nến test": bars, "Equity cuối": end_eq,
    }


def run_backtest(bot_path, params, settings, symbol, tf, candles, warmup=100, mode="ohlc", spread_pct=None,
                 progress=None, stop_event=None):
    """candles: list Candle cũ -> mới (đã gồm cả đoạn warm-up). Trả về BacktestResult."""
    step = tf_seconds(tf)
    res = BacktestResult(symbol=symbol, timeframe=tf, params=dict(params or {}))
    candles = [c for c in candles if c is not None]
    if len(candles) < 5:
        res.ok, res.error = False, "Không đủ dữ liệu nến để backtest (%d)" % len(candles)
        return res
    warmup = max(0, min(int(warmup), len(candles) - 3))
    spread_pct = float(settings.get("spread_pct", 0.01) if spread_pct is None else spread_pct)

    st = dict(settings, mode="paper", exchange="simulated", state_file=None, read_only=False)   # Strategy Tester không bị chế độ chỉ-xem
    sess = TradingSession(st, sync=True, feed=_ReplayFeed())
    sess.events = deque(maxlen=200000)
    sess.account = Account(float(st["initial_balance"]), st["commission_pct"], st["leverage"])
    sess.status = "running"
    sess.ready.set()
    b = CandleBuilder(step, max_len=len(candles) + 10, tf=tf)
    b.seed(candles[:warmup], candles[warmup].time)
    sess.builders[(symbol, tf)] = b

    inst = sess.attach(bot_path, symbol, tf, params or {}, iid="bt")
    inst.plot_cap = 10 ** 7
    curve = []
    err = ""
    try:
        inst.start()                           # đồng bộ: nạp bot + on_init
    except _Halt as h:
        res.ok, res.error = False, str(h)
        res.logs = [x[3] for x in sess.logs]
        return res
    except Exception as e:                     # pragma: no cover
        res.ok, res.error = False, "Lỗi khởi tạo backtest: %s" % e
        return res

    test = candles[warmup:]
    last_tick = None
    try:
        for i, c in enumerate(test):
            if stop_event is not None and stop_event.is_set():
                err = "Đã dừng theo yêu cầu"
                break
            for t, p in candle_ticks(c, step, mode):
                half = p * spread_pct / 200.0
                last_tick = Tick(symbol, t, p - half, p + half)
                sess.process_tick(last_tick)
            sess._check_max_loss()
            sess._check_margin()
            curve.append((c.time, sess.account.balance, sess.account.equity()))
            if progress and (i % 50 == 0 or i == len(test) - 1):
                progress(i + 1, len(test))
    except _Halt as h:
        err = ("Bot lỗi: " + str(h)) if h.error else str(h)
        if h.error:
            res.ok = False
    except Exception as e:
        res.ok, err = False, "Lỗi backtest: %s" % e
    finally:
        try:
            if last_tick is not None and sess.account.positions:
                sess.close_all("stop", "Kết thúc backtest: đóng lệnh còn mở theo giá cuối")
                curve.append((last_tick.time, sess.account.balance, sess.account.equity()))
            if inst.bot is not None:
                inst.bot.on_deinit("backtest_end")
        except Exception:
            pass
    res.error = err
    res.trades = list(sess.account.trades)
    res.events = list(sess.events)
    res.candles = candles[max(0, warmup - 30):]
    res.plots = {n: list(s.items()) for n, s in inst.plots.items()}
    res.curve = curve
    res.logs = [x[3] for x in sess.logs][-200:]
    res.report = compute_report(res.trades, float(st["initial_balance"]), curve, len(test))
    return res


def optimize(bot_path, base_params, grid, settings, symbol, tf, candles, warmup=100, mode="open", top=20,
             sort_key="Lợi nhuận ròng", max_runs=120, progress=None, stop_event=None):
    """Quét lưới tham số (như Optimization của MT5). grid: {"fast": [5,10,15], "slow": [20,30]}.
    Trả về list {"params", "report"} sắp xếp giảm dần theo `sort_key`."""
    import itertools
    names = list(grid)
    combos = list(itertools.product(*[grid[n] for n in names]))[:max_runs]
    out = []
    for i, vals in enumerate(combos):
        if stop_event is not None and stop_event.is_set():
            break
        p = dict(base_params or {})
        p.update(dict(zip(names, vals)))
        r = run_backtest(bot_path, p, settings, symbol, tf, candles, warmup, mode)
        if r.ok or r.trades:
            out.append({"params": p, "report": r.report})
        if progress:
            progress(i + 1, len(combos))

    def key(x):
        v = x["report"].get(sort_key)
        return -1e30 if v is None else (1e30 if v == float("inf") else v)
    out.sort(key=key, reverse=True)
    return out[:top]
