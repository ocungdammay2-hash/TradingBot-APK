"""
Đối soát vị thế giữa SỔ NỘI BỘ của app và SÀN THẬT (chỉ live, sàn có hàm positions()):
  orphan   sàn có vị thế mà sổ app không có (vd bạn tự vào lệnh trên app của sàn, hoặc app crash giữa chừng)
  ghost    sổ app còn vị thế mà sàn không còn (vd bị thanh lý/chốt trên app sàn)
  mismatch cả hai có nhưng khác chiều/khối lượng
Chính sách (settings.reconcile_policy): "alert" (mặc định - chỉ báo), "adopt" (sổ app đổi theo SÀN), "off".
Chạy mỗi reconcile_interval giây và NGAY sau khi một lệnh gửi sàn lỗi/không rõ kết quả.
"""
import time

from .broker import BrokerError
from .feeds import FeedError
from .sdk import Position


class ReconcileMixin:
    def _recon_init(self):
        self.recon = {"last": 0.0, "ok": None, "issues": [], "checks": 0, "supported": False, "policy": "alert"}
        self._recon_next = 0.0
        self._recon_seen = set()

    def reconcile_due(self, delay=0.0):
        """Yêu cầu đối soát sớm (vd sau khi gửi lệnh bị lỗi không rõ kết quả)."""
        self._recon_next = time.time() + delay

    def _check_reconcile(self):
        iv = float(self.settings.get("reconcile_interval") or 0)
        b = self.broker
        if b is None or iv <= 0 or not hasattr(b, "positions") or self.settings.get("reconcile_policy", "alert") == "off":
            return
        if time.time() < self._recon_next:
            return
        self._recon_next = time.time() + iv
        try:
            self.reconcile_now()
        except Exception as e:                                  # đối soát lỗi không được làm sập phiên
            self.log("Đối soát với sàn lỗi: %s" % e, "WARN")

    def _local_net(self):
        net = {}
        for p in self.account.positions.values():
            net[p.symbol] = net.get(p.symbol, 0.0) + (p.volume if p.side == "buy" else -p.volume)
        return net

    def reconcile_now(self):
        """Một lượt đối soát. Trả về list issue (dict). Cập nhật self.recon (hiện trên giao diện)."""
        b = self.broker
        policy = self.settings.get("reconcile_policy", "alert")
        if b is None or not hasattr(b, "positions"):
            return []
        try:
            remote = b.positions()
        except BrokerError as e:
            self.recon.update(last=time.time(), ok=None, issues=["Không lấy được vị thế từ sàn: %s" % e], supported=True)
            self.log("Đối soát: không lấy được vị thế từ sàn: %s" % e, "WARN")
            return []
        if remote is None:
            self.recon.update(supported=False)
            return []
        with self.lock:
            local = self._local_net()
        scope_all = self.settings.get("reconcile_scope", "app") == "all"
        relevant = set(local) | set(self.needed_symbols())
        syms = (set(local) | set(remote)) if scope_all else (relevant & (set(local) | set(remote)))
        issues = []
        for sym in sorted(syms):
            lq = local.get(sym, 0.0)
            rq = (remote.get(sym) or {}).get("qty", 0.0)
            spec = self.spec(sym)
            tol = max(1e-9, abs(rq) * 1e-6, 0.5 * spec.volume_step)
            if abs(lq - rq) <= tol:
                continue
            kind = "orphan" if abs(lq) <= tol else ("ghost" if abs(rq) <= tol else "mismatch")
            text = {"orphan": "Sàn có vị thế %s %.8g nhưng sổ app KHÔNG có", "ghost": "Sổ app có vị thế %s %.8g nhưng sàn KHÔNG còn",
                    "mismatch": "Lệch vị thế %s: sàn %.8g · sổ app %.8g"}[kind]
            text = (text % (sym, rq)) if kind == "orphan" else ((text % (sym, lq)) if kind == "ghost" else (text % (sym, rq, lq)))
            issues.append({"symbol": sym, "kind": kind, "local": lq, "remote": rq, "text": text,
                           "price": (remote.get(sym) or {}).get("price", 0.0)})
        self.recon.update(last=time.time(), ok=not issues, issues=[i["text"] for i in issues], checks=self.recon["checks"] + 1,
                          supported=True, policy=policy)
        for i in issues:
            key = (i["symbol"], i["kind"], round(i["local"], 8), round(i["remote"], 8))
            if key not in self._recon_seen:
                self._recon_seen.add(key)
                self.log("ĐỐI SOÁT: %s%s" % (i["text"], " -> app sẽ đổi sổ theo sàn" if policy == "adopt" else ""), "WARN")
                self.alarm("Lệch vị thế với sàn: %s" % i["symbol"], i["text"])
            if policy == "adopt":
                self._adopt(i)
        if not issues:
            self._recon_seen.clear()
        return issues

    def _adopt(self, issue):
        """Đổi sổ app theo sàn cho 1 mã: đóng mọi vị thế nội bộ của mã (không gửi lệnh) rồi nhập vị thế thật của sàn."""
        sym, rq = issue["symbol"], issue["remote"]
        try:
            tick = self.get_tick(sym)
        except (FeedError, KeyError, AttributeError):
            return
        with self.lock:
            for p in [p for p in self.account.positions.values() if p.symbol == sym]:
                tr = self.account.close(p.id, tick.mid, tick.time, "reconcile")
                tr.reason = "Đối soát"
                self.add_event("close", sym, tick.mid, p.side, p.volume, p.id, "manual",
                               "Đối soát: sàn không còn vị thế này - sổ app đóng theo sàn", {"nguồn": "đối soát"}, None, tr.profit, None, p.owner)
                self._save_trade(tr)
            if abs(rq) > 0:
                side = "buy" if rq > 0 else "sell"
                px = issue.get("price") or tick.mid
                pos = self.account.open(sym, side, abs(rq), px, 0.0, 0.0, "Nhận từ sàn (đối soát)", tick.time, "manual")
                self.add_event("open", sym, px, side, abs(rq), pos.id, "manual", "Đối soát: nhận vị thế đang có trên sàn vào sổ app",
                               {"nguồn": "đối soát", "giá vào (sàn)": px}, None, 0.0, None, "manual")
        self.log("ĐỐI SOÁT: đã đổi sổ app theo sàn cho %s (sàn: %.8g)" % (sym, rq), "WARN")
        self._save_state()
