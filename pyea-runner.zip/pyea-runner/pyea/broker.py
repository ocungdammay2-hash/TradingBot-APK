"""
Broker giao dịch THẬT (thử nghiệm) - chỉ lệnh thị trường.

  BinanceBroker         : Spot, chỉ mua/bán (KHÔNG bán khống)
  BinanceFuturesBroker  : USDT-M Futures, mua + BÁN KHỐNG, đòn bẩy (tài khoản phải ở One-way mode)

Giao diện chung (engine chỉ dùng các thành viên này):
    supports_short : bool
    prepare(symbol, leverage) -> số dư quote khả dụng (kiểm tra kết nối/chế độ tài khoản)
    market_order(symbol, side, qty, reduce_only=False) -> Fill
Muốn thêm sàn khác: viết class có cùng giao diện rồi đăng ký trong make_broker().
"""
import hashlib
import hmac
import math
import time
import urllib.parse
from dataclasses import dataclass

from .feeds import FeedError, http_json, resolve_base


class BrokerError(Exception):
    pass


@dataclass
class Fill:
    price: float     # giá khớp trung bình
    qty: float       # số lượng thực tế (spot: đã trừ phí nếu phí tính bằng coin)


class _BinanceBase:
    supports_short = False
    netting = False            # True: sàn gộp vị thế 1 chiều/mã -> không giữ đồng thời mua+bán cùng mã
    api = "/api/v3"            # tiền tố REST

    def __init__(self, api_key, api_secret, base_url):
        if not api_key or not api_secret:
            raise BrokerError("Thiếu API key / secret")
        self.key = api_key.strip()
        self.secret = api_secret.strip().encode()
        self.base = base_url.rstrip("/")
        self._offset = None
        self._info = {}
        self._lev_done = set()

    # ---- HTTP có chữ ký ----
    def _server_time_ms(self):
        if self._offset is None:
            try:
                d = http_json(self.base + self.api + "/time")
                self._offset = d["serverTime"] / 1000.0 - time.time()
            except Exception:
                self._offset = 0.0
        return int((time.time() + self._offset) * 1000)

    def _signed(self, method, path, params):
        p = dict(params)
        p["timestamp"] = self._server_time_ms()
        p["recvWindow"] = 10000
        query = urllib.parse.urlencode(p)
        sig = hmac.new(self.secret, query.encode(), hashlib.sha256).hexdigest()
        url = "%s%s?%s&signature=%s" % (self.base, path, query, sig)
        try:
            return http_json(url, headers={"X-MBX-APIKEY": self.key}, method=method, timeout=15)
        except FeedError as e:
            raise BrokerError(str(e))

    def check_permissions(self):
        """Kiểm tra quyền của API key (Binance: GET /sapi/v1/account/apiRestrictions - có ký). Trả về list cảnh báo (rỗng = ổn).
        An toàn nhất: key CHỈ bật 'đọc + giao dịch', TẮT rút tiền, và giới hạn theo IP. Lỗi mạng/Testnet (không có endpoint) -> bỏ qua."""
        if self.api.startswith("/fapi"):          # endpoint sapi nằm ở host Spot, không gọi được từ host Futures
            return []
        try:
            d = self._signed("GET", "/sapi/v1/account/apiRestrictions", {})
        except Exception:
            return []
        warns = []
        if not isinstance(d, dict):
            return warns
        if d.get("enableWithdrawals"):
            warns.append("API key đang BẬT quyền RÚT TIỀN - hãy tắt trên Binance, bot không cần quyền này")
        if d.get("enableInternalTransfer") or d.get("permitsUniversalTransfer"):
            warns.append("API key đang bật quyền chuyển nội bộ/universal transfer - nên tắt")
        if not d.get("ipRestrict"):
            warns.append("API key CHƯA giới hạn theo địa chỉ IP - nếu lộ key, ai cũng dùng được")
        if not d.get("enableSpotAndMarginTrading"):
            warns.append("API key CHƯA bật quyền giao dịch Spot")
        return warns

    # ---- tiện ích số lượng ----
    @staticmethod
    def _floor_step(qty, step):
        if step <= 0:
            return qty
        return math.floor(qty / step + 1e-9) * step

    @staticmethod
    def _fmt_qty(qty, step):
        decimals = max(0, int(round(-math.log10(step)))) if step > 0 else 8
        return ("%." + str(decimals) + "f") % qty

    def _check_qty(self, symbol, qty):
        info = self._symbol_info(symbol)
        q = self._floor_step(float(qty), info["step"])
        if q <= 0 or q < info["min_qty"]:
            raise BrokerError("Khối lượng %.8g nhỏ hơn mức tối thiểu %.8g của %s" % (q, info["min_qty"], symbol))
        return q, info

    def _symbol_info(self, symbol):
        raise NotImplementedError


class BinanceBroker(_BinanceBase):
    """Spot."""
    supports_short = False
    api = "/api/v3"

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", {"symbol": symbol})
            s = d["symbols"][0]
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") == "LOT_SIZE":
                step, min_qty = float(f["stepSize"]), float(f["minQty"])
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty}
        self._info[symbol] = info
        return info

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        acc = self._signed("GET", self.api + "/account", {})
        for b in acc.get("balances", []):
            if b["asset"] == info["quote"]:
                return float(b["free"])
        return 0.0

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        res = self._signed("POST", self.api + "/order", {
            "symbol": symbol, "side": side.upper(), "type": "MARKET",
            "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "FULL"})
        try:
            executed = float(res["executedQty"])
            quote = float(res["cummulativeQuoteQty"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        net = executed
        if side == "buy":     # phí tính bằng coin nhận về -> trừ ra
            for f in res.get("fills", []):
                if f.get("commissionAsset") == info["base"]:
                    net -= float(f.get("commission", 0))
        return Fill(price=quote / executed, qty=net)


class BinanceFuturesBroker(_BinanceBase):
    """USDT-M Futures, One-way mode."""
    supports_short = True
    netting = True
    api = "/fapi/v1"
    _lev = 0

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", timeout=30)
            s = next(x for x in d["symbols"] if x["symbol"] == symbol)
        except StopIteration:
            raise BrokerError("Không có cặp futures %s" % symbol)
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") in ("MARKET_LOT_SIZE", "LOT_SIZE"):
                st, mq = float(f["stepSize"]), float(f["minQty"])
                if f["filterType"] == "MARKET_LOT_SIZE" or step == 0:
                    step, min_qty = st, mq
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty}
        self._info[symbol] = info
        return info

    def _balance(self, quote):
        err = None
        for path in ("/fapi/v2/balance", "/fapi/v3/balance"):      # tuỳ phiên bản API của sàn
            try:
                rows = self._signed("GET", path, {})
                for r in rows:
                    if r.get("asset") == quote:
                        return float(r.get("availableBalance", r.get("balance", 0)))
                return 0.0
            except BrokerError as e:
                err = e
        raise err

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        mode = self._signed("GET", self.api + "/positionSide/dual", {})
        if isinstance(mode, dict) and mode.get("dualSidePosition"):
            raise BrokerError("Tài khoản đang ở Hedge Mode. Hãy chuyển sang One-way Mode trên Binance rồi thử lại.")
        self._lev = max(1, int(round(float(leverage))))
        self._set_leverage(symbol)
        return self._balance(info["quote"])

    def positions(self):
        """Vị thế ròng đang mở trên sàn: {symbol: {"qty": số có dấu (+mua/-bán), "price": giá vào TB}}. One-way mode: positionAmt có dấu."""
        err = None
        for path in ("/fapi/v2/positionRisk", "/fapi/v3/positionRisk"):         # tuỳ phiên bản API của sàn
            try:
                rows = self._signed("GET", path, {})
                break
            except BrokerError as e:
                err = e
        else:
            raise err
        out = {}
        for r in rows if isinstance(rows, list) else []:
            try:
                q = float(r.get("positionAmt", 0))
                if abs(q) > 0:
                    out[r["symbol"]] = {"qty": q, "price": float(r.get("entryPrice") or 0)}
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def _set_leverage(self, symbol):
        if symbol not in self._lev_done:
            self._signed("POST", self.api + "/leverage", {"symbol": symbol, "leverage": self._lev})
            self._lev_done.add(symbol)

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        if self._lev and symbol not in self._lev_done:      # nhiều mã: đặt đòn bẩy lần đầu cho từng mã
            self._set_leverage(symbol)
        params = {"symbol": symbol, "side": side.upper(), "type": "MARKET",
                  "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "RESULT"}
        if reduce_only:
            params["reduceOnly"] = "true"
        res = self._signed("POST", self.api + "/order", params)
        try:
            executed = float(res["executedQty"])
            price = float(res.get("avgPrice") or 0)
            if price <= 0:
                price = float(res["cumQuote"]) / executed
        except (KeyError, ValueError, TypeError, ZeroDivisionError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        return Fill(price=price, qty=executed)


class OandaBroker:
    """OANDA v20 (forex/kim loại/chỉ số CFD). Lệnh thị trường FOK, volume = số units (làm tròn số nguyên).
    Tài khoản gộp vị thế theo mã (netting) -> engine không giữ đồng thời mua+bán cùng mã."""
    supports_short = True
    netting = True

    def __init__(self, token, account_id, base_url):
        if not token or not account_id:
            raise BrokerError("Thiếu OANDA token / account ID")
        self.h = {"Authorization": "Bearer " + token.strip(), "Content-Type": "application/json"}
        self.acc = account_id.strip()
        self.base = base_url.rstrip("/")

    def _call(self, method, path, body=None):
        try:
            return http_json(self.base + path, headers=self.h, method=method, body=body, timeout=15)
        except FeedError as e:
            raise BrokerError(str(e))

    def prepare(self, symbol, leverage=1.0):
        d = self._call("GET", "/v3/accounts/%s/summary" % self.acc)
        try:
            return float(d["account"]["balance"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi tài khoản OANDA không hợp lệ: %s" % str(d)[:160])

    def positions(self):
        """{instrument: {"qty": long.units + short.units (bán là số âm), "price": giá vào TB}} - GET /v3/accounts/{id}/openPositions."""
        d = self._call("GET", "/v3/accounts/%s/openPositions" % self.acc)
        out = {}
        for p in d.get("positions", []) if isinstance(d, dict) else []:
            try:
                lg, sh = p.get("long") or {}, p.get("short") or {}
                lu, su = float(lg.get("units", 0) or 0), float(sh.get("units", 0) or 0)
                q = lu + su
                if abs(q) > 0:
                    side = lg if abs(lu) >= abs(su) else sh
                    out[p["instrument"]] = {"qty": q, "price": float(side.get("averagePrice") or 0)}
            except (KeyError, ValueError, TypeError):
                continue
        return out

    def market_order(self, symbol, side, qty, reduce_only=False):
        units = int(round(float(qty)))
        if units < 1:
            raise BrokerError("Khối lượng phải >= 1 unit")
        order = {"type": "MARKET", "instrument": symbol, "units": str(units if side == "buy" else -units),
                 "timeInForce": "FOK", "positionFill": "REDUCE_ONLY" if reduce_only else "DEFAULT"}
        d = self._call("POST", "/v3/accounts/%s/orders" % self.acc, {"order": order})
        fill = d.get("orderFillTransaction")
        if not fill:
            raise BrokerError("Lệnh không khớp: %s" % str(d.get("orderCancelTransaction") or d)[:200])
        try:
            return Fill(price=float(fill["price"]), qty=abs(float(fill["units"])))
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi lệnh OANDA không hợp lệ: %s" % str(fill)[:200])


def make_broker(settings):
    ex = settings.get("exchange")
    base = resolve_base(settings)
    if ex == "oanda":
        return OandaBroker(settings.get("oanda_token", ""), settings.get("oanda_account", ""), base)
    cls = BinanceFuturesBroker if ex == "binance_futures" else BinanceBroker
    return cls(settings.get("api_key", ""), settings.get("api_secret", ""), base)
