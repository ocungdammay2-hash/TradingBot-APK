"""
Broker giao dịch THẬT (thử nghiệm) - chỉ lệnh thị trường.

  BinanceBroker         : Spot, chỉ mua/bán (KHÔNG bán khống)
  BinanceFuturesBroker  : USDT-M Futures, mua + BÁN KHỐNG, đòn bẩy (tài khoản phải ở One-way mode)

Giao diện chung (engine chỉ dùng các thành viên này):
    supports_short : bool
    prepare(symbol, leverage) -> số dư quote khả dụng (kiểm tra kết nối/chế độ tài khoản)
    market_order(symbol, side, qty, reduce_only=False) -> Fill
Muốn thêm sàn khác: viết class có cùng giao diện rồi đăng ký trong make_broker().
"""
import hashlib
import hmac
import math
import time
import urllib.parse
from dataclasses import dataclass

from .feeds import FeedError, http_json, resolve_base


class BrokerError(Exception):
    pass


@dataclass
class Fill:
    price: float     # giá khớp trung bình
    qty: float       # số lượng thực tế (spot: đã trừ phí nếu phí tính bằng coin)


class _BinanceBase:
    supports_short = False
    api = "/api/v3"            # tiền tố REST

    def __init__(self, api_key, api_secret, base_url):
        if not api_key or not api_secret:
            raise BrokerError("Thiếu API key / secret")
        self.key = api_key.strip()
        self.secret = api_secret.strip().encode()
        self.base = base_url.rstrip("/")
        self._offset = None
        self._info = {}

    # ---- HTTP có chữ ký ----
    def _server_time_ms(self):
        if self._offset is None:
            try:
                d = http_json(self.base + self.api + "/time")
                self._offset = d["serverTime"] / 1000.0 - time.time()
            except Exception:
                self._offset = 0.0
        return int((time.time() + self._offset) * 1000)

    def _signed(self, method, path, params):
        p = dict(params)
        p["timestamp"] = self._server_time_ms()
        p["recvWindow"] = 10000
        query = urllib.parse.urlencode(p)
        sig = hmac.new(self.secret, query.encode(), hashlib.sha256).hexdigest()
        url = "%s%s?%s&signature=%s" % (self.base, path, query, sig)
        try:
            return http_json(url, headers={"X-MBX-APIKEY": self.key}, method=method, timeout=15)
        except FeedError as e:
            raise BrokerError(str(e))

    # ---- tiện ích số lượng ----
    @staticmethod
    def _floor_step(qty, step):
        if step <= 0:
            return qty
        return math.floor(qty / step + 1e-9) * step

    @staticmethod
    def _fmt_qty(qty, step):
        decimals = max(0, int(round(-math.log10(step)))) if step > 0 else 8
        return ("%." + str(decimals) + "f") % qty

    def _check_qty(self, symbol, qty):
        info = self._symbol_info(symbol)
        q = self._floor_step(float(qty), info["step"])
        if q <= 0 or q < info["min_qty"]:
            raise BrokerError("Khối lượng %.8g nhỏ hơn mức tối thiểu %.8g của %s" % (q, info["min_qty"], symbol))
        return q, info

    def _symbol_info(self, symbol):
        raise NotImplementedError


class BinanceBroker(_BinanceBase):
    """Spot."""
    supports_short = False
    api = "/api/v3"

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", {"symbol": symbol})
            s = d["symbols"][0]
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") == "LOT_SIZE":
                step, min_qty = float(f["stepSize"]), float(f["minQty"])
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty}
        self._info[symbol] = info
        return info

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        acc = self._signed("GET", self.api + "/account", {})
        for b in acc.get("balances", []):
            if b["asset"] == info["quote"]:
                return float(b["free"])
        return 0.0

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        res = self._signed("POST", self.api + "/order", {
            "symbol": symbol, "side": side.upper(), "type": "MARKET",
            "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "FULL"})
        try:
            executed = float(res["executedQty"])
            quote = float(res["cummulativeQuoteQty"])
        except (KeyError, ValueError, TypeError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        net = executed
        if side == "buy":     # phí tính bằng coin nhận về -> trừ ra
            for f in res.get("fills", []):
                if f.get("commissionAsset") == info["base"]:
                    net -= float(f.get("commission", 0))
        return Fill(price=quote / executed, qty=net)


class BinanceFuturesBroker(_BinanceBase):
    """USDT-M Futures, One-way mode."""
    supports_short = True
    api = "/fapi/v1"

    def _symbol_info(self, symbol):
        if symbol in self._info:
            return self._info[symbol]
        try:
            d = http_json(self.base + self.api + "/exchangeInfo", timeout=30)
            s = next(x for x in d["symbols"] if x["symbol"] == symbol)
        except StopIteration:
            raise BrokerError("Không có cặp futures %s" % symbol)
        except Exception as e:
            raise BrokerError("Không lấy được thông tin cặp %s: %s" % (symbol, e))
        step = min_qty = 0.0
        for f in s.get("filters", []):
            if f.get("filterType") in ("MARKET_LOT_SIZE", "LOT_SIZE"):
                st, mq = float(f["stepSize"]), float(f["minQty"])
                if f["filterType"] == "MARKET_LOT_SIZE" or step == 0:
                    step, min_qty = st, mq
        info = {"base": s["baseAsset"], "quote": s["quoteAsset"], "step": step, "min_qty": min_qty}
        self._info[symbol] = info
        return info

    def _balance(self, quote):
        err = None
        for path in ("/fapi/v2/balance", "/fapi/v3/balance"):      # tuỳ phiên bản API của sàn
            try:
                rows = self._signed("GET", path, {})
                for r in rows:
                    if r.get("asset") == quote:
                        return float(r.get("availableBalance", r.get("balance", 0)))
                return 0.0
            except BrokerError as e:
                err = e
        raise err

    def prepare(self, symbol, leverage=1.0):
        info = self._symbol_info(symbol)
        mode = self._signed("GET", self.api + "/positionSide/dual", {})
        if isinstance(mode, dict) and mode.get("dualSidePosition"):
            raise BrokerError("Tài khoản đang ở Hedge Mode. Hãy chuyển sang One-way Mode trên Binance rồi thử lại.")
        lev = max(1, int(round(float(leverage))))
        self._signed("POST", self.api + "/leverage", {"symbol": symbol, "leverage": lev})
        return self._balance(info["quote"])

    def market_order(self, symbol, side, qty, reduce_only=False):
        q, info = self._check_qty(symbol, qty)
        params = {"symbol": symbol, "side": side.upper(), "type": "MARKET",
                  "quantity": self._fmt_qty(q, info["step"]), "newOrderRespType": "RESULT"}
        if reduce_only:
            params["reduceOnly"] = "true"
        res = self._signed("POST", self.api + "/order", params)
        try:
            executed = float(res["executedQty"])
            price = float(res.get("avgPrice") or 0)
            if price <= 0:
                price = float(res["cumQuote"]) / executed
        except (KeyError, ValueError, TypeError, ZeroDivisionError):
            raise BrokerError("Phản hồi lệnh không hợp lệ: %s" % str(res)[:200])
        if executed <= 0:
            raise BrokerError("Lệnh không khớp: %s" % str(res)[:200])
        return Fill(price=price, qty=executed)


def make_broker(settings):
    base = resolve_base(settings)
    cls = BinanceFuturesBroker if settings.get("exchange") == "binance_futures" else BinanceBroker
    return cls(settings.get("api_key", ""), settings.get("api_secret", ""), base)
