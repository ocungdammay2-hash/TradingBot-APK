"""Cài đặt chung của app (khai báo bằng Input để dùng chung bộ sinh form với bot)."""
from collections import OrderedDict

from .feeds import TIMEFRAMES
from .sdk import Input

GLOBAL_INPUTS = OrderedDict([
    # ---- Thị trường ----
    ("exchange", Input("simulated", "Nguồn thị trường / sàn", choices=["simulated", "binance_spot", "binance_futures", "oanda"],
                       group="Thị trường",
                       help="simulated: nhiều tài sản giả chạy offline · binance: crypto · oanda: forex/vàng/chỉ số (có demo)")),
    ("mode", Input("paper", "Chế độ", choices=["paper", "live"], group="Thị trường",
                   help="paper = giao dịch giả lập (giá thật nếu chọn sàn thật); live = TIỀN THẬT")),
    ("watchlist", Input("BTCUSD,ETHUSD,EURUSD,XAUUSD,US500,AAPL", "Danh sách theo dõi (Market Watch)", group="Thị trường",
                        help="Mã cách nhau dấu phẩy. Binance: BTCUSDT; OANDA: EUR_USD, XAU_USD; giả lập: BTCUSD, EURUSD...")),
    # ---- Tài khoản giả lập ----
    ("initial_balance", Input(1000.0, "Số dư ban đầu (paper)", min=1.0, group="Tài khoản / rủi ro")),
    ("leverage", Input(1.0, "Đòn bẩy", min=1.0, max=125.0, group="Tài khoản / rủi ro",
                       help="Giới hạn tổng giá trị lệnh theo vốn")),
    ("commission_pct", Input(0.1, "Phí mỗi chiều (%)", min=0.0, max=5.0, group="Tài khoản / rủi ro")),
    ("max_loss_pct", Input(20.0, "Dừng bot nếu lỗ quá (%)", min=0.0, max=100.0, group="Tài khoản / rủi ro",
                           help="0 = tắt. Đóng hết lệnh và dừng khi equity giảm quá mức này")),
    ("close_on_stop", Input(True, "Đóng hết lệnh khi dừng bot", group="Tài khoản / rủi ro")),
    # ---- Giao dịch (vỏ): luật & an toàn ----
    ("read_only", Input(False, "Chế độ CHỈ-XEM (không gửi lệnh mới)", group="Giao dịch & an toàn",
                        help="Bot vẫn chạy để xem tín hiệu nhưng vỏ chặn mọi lệnh mới (vẫn cho đóng lệnh/huỷ lệnh chờ)")),
    ("confirm_trades", Input(True, "Hỏi xác nhận khi đặt lệnh tay", group="Giao dịch & an toàn",
                             help="Tắt = 'một chạm' (one-click trading) - chỉ nên tắt khi đã quen")),
    ("default_volume", Input(0.0, "Khối lượng mặc định khi đặt lệnh tay", min=0.0, group="Giao dịch & an toàn",
                             help="0 = tự chọn theo loại tài sản (BTC 0.01, forex 1000, vàng 0.1...)")),
    ("min_volume", Input(0.0, "Khối lượng tối thiểu", min=0.0, group="Giao dịch & an toàn", help="0 = không kiểm tra")),
    ("max_volume", Input(0.0, "Khối lượng tối đa mỗi lệnh", min=0.0, group="Giao dịch & an toàn", help="0 = không giới hạn")),
    ("volume_step", Input(0.0, "Bước khối lượng (step)", min=0.0, group="Giao dịch & an toàn",
                          help="Vỏ làm tròn XUỐNG theo bước này; 0 = không ràng buộc")),
    ("stop_level_pct", Input(0.0, "Khoảng cách tối thiểu SL/TP (% giá)", min=0.0, max=50.0, group="Giao dịch & an toàn",
                             help="Như 'stop level' của MT5; 0 = không kiểm tra")),
    ("symbol_overrides", Input("", "Luật riêng theo mã (JSON)", group="Giao dịch & an toàn",
                               help='Vd {"XAUUSD":{"volume_min":0.01,"volume_step":0.01,"trade_mode":"close_only"}} · '
                                    'trade_mode: full|long_only|short_only|close_only|disabled')),
    ("max_slippage_pct", Input(0.0, "Cảnh báo nếu trượt giá quá (%)", min=0.0, max=10.0, group="Giao dịch & an toàn",
                               help="Chỉ áp dụng live: so giá khớp với giá lúc gửi; 0 = tắt")),
    ("stale_after", Input(30.0, "Chặn lệnh nếu giá cũ hơn (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                          help="Mất kết nối giá thì KHÔNG gửi lệnh bằng giá cũ. 0 = tắt")),
    ("margin_call_level", Input(100.0, "Cảnh báo margin call khi mức ký quỹ ≤ (%)", min=0.0, group="Giao dịch & an toàn",
                                help="Mức ký quỹ = equity / ký quỹ đang dùng × 100. 0 = tắt")),
    ("stop_out_level", Input(0.0, "Stop-out: tự đóng lệnh lỗ nặng nhất khi mức ký quỹ ≤ (%)", min=0.0, group="Giao dịch & an toàn",
                             help="0 = tắt. Mỗi lần chỉ đóng 1 vị thế, như MT5")),
    ("bot_error_tolerance", Input(0, "Bot được lỗi bao nhiêu lần/giờ trước khi bị tắt", min=0, max=1000, group="Giao dịch & an toàn",
                                  help="0 = tắt bot ngay ở lỗi đầu tiên. >0 = ghi lỗi và chạy tiếp, vượt ngưỡng mới tắt (circuit breaker)")),
    ("bot_callback_timeout", Input(30.0, "Coi bot là TREO nếu một hàm chạy quá (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                                   help="Python không giết được luồng đang treo; vỏ báo động, đánh dấu lỗi và ngừng đưa tick cho bot. 0 = tắt")),
    ("reconcile_interval", Input(60.0, "Đối soát vị thế với sàn mỗi (giây)", min=0.0, max=3600.0, group="Giao dịch & an toàn",
                                 help="Chỉ live (Binance Futures/OANDA). So sổ lệnh của app với vị thế THẬT trên sàn. 0 = tắt")),
    ("reconcile_policy", Input("alert", "Khi lệch vị thế với sàn", choices=["alert", "adopt", "off"], group="Giao dịch & an toàn",
                               help="alert = chỉ báo động · adopt = sổ app tự đổi theo SÀN (bot mất quyền sở hữu vị thế đó) · off = tắt")),
    ("reconcile_scope", Input("app", "Phạm vi đối soát", choices=["app", "all"], group="Giao dịch & an toàn",
                              help="app = chỉ các mã app đang dùng · all = mọi vị thế trên tài khoản sàn (cả lệnh bạn tự vào)")),
    ("dev_mode", Input(False, "Chế độ nhà phát triển (cho phép bot dùng subprocess/eval/exec...)", group="Giao dịch & an toàn",
                       help="Mặc định vỏ chặn các mã nguy hiểm trong file bot. Chỉ bật khi TIN file bot")),
    # ---- Vận hành ----
    ("tick_interval", Input(1.0, "Chu kỳ lấy giá (giây)", min=0.2, max=60.0, group="Vận hành")),
    ("spread_pct", Input(0.01, "Spread giả lập (% giá)", min=0.0, max=5.0, group="Vận hành",
                         help="Dùng trong backtest và nguồn giả; giá thật dùng bid/ask thật")),
    ("history_bars", Input(500, "Số nến lịch sử nạp sẵn", min=50, max=1000, group="Vận hành",
                          help="Càng nhiều càng kéo lùi biểu đồ được xa, nhưng nạp lâu hơn")),
    ("chart_bars", Input(400, "Số nến đưa lên biểu đồ", min=100, max=1000, group="Vận hành",
                         help="Số nến tối đa kéo lùi được trên biểu đồ. Giảm để tiết kiệm pin/bộ nhớ flash khi chạy nền")),
    ("keep_awake", Input(False, "Giữ màn hình sáng khi chạy", group="Vận hành",
                         help="Chỉ cần khi KHÔNG dùng dịch vụ nền (tốn pin)")),
    ("ui_refresh", Input(1.0, "Tần suất cập nhật giao diện (giây)", min=0.5, max=10.0, group="Vận hành",
                         help="Tăng lên để tiết kiệm pin")),
    ("sim_speed", Input(10.0, "Tốc độ giả lập (x)", min=1.0, max=5000.0, group="Giả lập",
                        help="1 giây thật = bao nhiêu giây giả lập")),
    ("sim_start_price", Input(30000.0, "Giá khởi điểm giả lập", min=0.000001, group="Giả lập")),
    # ---- Chạy nền & cảnh báo ----
    ("background_service", Input(True, "Chạy nền bằng dịch vụ (khuyên dùng)", group="Chạy nền & cảnh báo",
                                 help="Bot sống khi tắt màn hình / thoát app, có thông báo trên thanh trạng thái")),
    ("auto_resume", Input(True, "Tự khôi phục phiên sau sự cố", group="Chạy nền & cảnh báo",
                          help="Nếu dịch vụ bị hệ thống giết/crash, tự chạy lại bot với sổ lệnh đã lưu")),
    ("power_mode", Input("balanced", "Chế độ năng lượng", choices=["balanced", "saver"],
                         group="Chạy nền & cảnh báo",
                         help="saver: khi app ở nền chỉ lấy giá ≥3 giây/lần để tiết kiệm pin")),
    ("notify_trades", Input(False, "Thông báo mỗi khi mở/đóng lệnh", group="Chạy nền & cảnh báo")),
    # ---- AI ----
    ("ai_rounds", Input(2, "Số vòng thảo luận mỗi lần", min=1, max=5, group="AI")),
    ("ai_auto_interval", Input(15, "Chu kỳ AI tự thảo luận (phút)", min=1, max=1440, group="AI",
                               help="Mỗi lần thảo luận tốn API call của từng model")),
    ("ai_decision_mode", Input("decider", "Cách chốt quyết định", choices=["decider", "majority"], group="AI",
                               help="decider: 1 AI chốt; majority: mọi AI bỏ phiếu, cần đa số đồng thuận")),
    ("ai_signal_ttl", Input(30, "Tín hiệu AI hết hạn sau (phút)", min=1, max=1440, group="AI")),
    ("ai_max_tokens", Input(800, "Giới hạn token mỗi câu trả lời", min=100, max=4000, group="AI")),
    # ---- Binance live ----
    ("api_key", Input("", "Binance API key", group="Sàn (chỉ khi live)")),
    ("api_secret", Input("", "Binance API secret", secret=True, group="Sàn (chỉ khi live)")),
    ("testnet", Input(False, "Dùng Testnet / Demo (tiền giả)", group="Sàn (chỉ khi live)",
                      help="Binance Testnet hoặc OANDA practice. Nên thử live ở đây trước")),
    ("base_url", Input("", "Base URL tuỳ chỉnh", group="Sàn (chỉ khi live)",
                       help="Để trống = tự chọn theo sàn/testnet; vd https://data-api.binance.vision")),
    ("oanda_token", Input("", "OANDA API token", secret=True, group="Sàn (chỉ khi live)")),
    ("oanda_account", Input("", "OANDA Account ID", group="Sàn (chỉ khi live)", help="Vd 101-001-1234567-001")),
    ("live_confirm", Input(False, "Tôi hiểu rủi ro giao dịch tiền thật", group="Sàn (chỉ khi live)")),
])


EXCHANGE_WATCH = {
    "simulated": "BTCUSD,ETHUSD,EURUSD,XAUUSD,US500,AAPL",
    "binance_spot": "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT",
    "binance_futures": "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT",
    "oanda": "EUR_USD,GBP_USD,USD_JPY,XAU_USD,SPX500_USD",
}


def default_settings():
    return {k: v.default for k, v in GLOBAL_INPUTS.items()}


def clean_settings(raw):
    """Ép toàn bộ settings về đúng kiểu; giá trị hỏng -> về mặc định."""
    out = {}
    raw = raw or {}
    for k, inp in GLOBAL_INPUTS.items():
        try:
            out[k] = inp.coerce(raw.get(k, inp.default))
        except ValueError:
            out[k] = inp.default
    return out
