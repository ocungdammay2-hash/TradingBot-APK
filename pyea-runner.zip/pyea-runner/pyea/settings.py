"""Cài đặt chung của app (khai báo bằng Input để dùng chung bộ sinh form với bot)."""
from collections import OrderedDict

from .feeds import TIMEFRAMES
from .sdk import Input

GLOBAL_INPUTS = OrderedDict([
    # ---- Thị trường ----
    ("symbol", Input("BTCUSDT", "Cặp giao dịch", group="Thị trường",
                     help="Ví dụ BTCUSDT, ETHUSDT (định dạng Binance)")),
    ("timeframe", Input("1m", "Khung thời gian", choices=list(TIMEFRAMES), group="Thị trường")),
    ("mode", Input("paper", "Chế độ", choices=["paper", "live"], group="Thị trường",
                   help="paper = giao dịch giả lập; live = TIỀN THẬT trên Binance")),
    ("feed", Input("simulated", "Nguồn giá (paper)", choices=["simulated", "binance"], group="Thị trường",
                   help="simulated = giá giả chạy offline; binance = giá thật")),
    # ---- Tài khoản giả lập ----
    ("initial_balance", Input(1000.0, "Số dư ban đầu (paper)", min=1.0, group="Tài khoản / rủi ro")),
    ("leverage", Input(1.0, "Đòn bẩy", min=1.0, max=125.0, group="Tài khoản / rủi ro",
                       help="Giới hạn tổng giá trị lệnh theo vốn")),
    ("commission_pct", Input(0.1, "Phí mỗi chiều (%)", min=0.0, max=5.0, group="Tài khoản / rủi ro")),
    ("max_loss_pct", Input(20.0, "Dừng bot nếu lỗ quá (%)", min=0.0, max=100.0, group="Tài khoản / rủi ro",
                           help="0 = tắt. Đóng hết lệnh và dừng khi equity giảm quá mức này")),
    ("close_on_stop", Input(True, "Đóng hết lệnh khi dừng bot", group="Tài khoản / rủi ro")),
    # ---- Vận hành ----
    ("tick_interval", Input(1.0, "Chu kỳ lấy giá (giây)", min=0.2, max=60.0, group="Vận hành")),
    ("history_bars", Input(300, "Số nến lịch sử nạp sẵn", min=50, max=1000, group="Vận hành")),
    ("keep_awake", Input(False, "Giữ màn hình sáng khi chạy", group="Vận hành",
                         help="Chỉ cần khi KHÔNG dùng dịch vụ nền (tốn pin)")),
    ("ui_refresh", Input(1.0, "Tần suất cập nhật giao diện (giây)", min=0.5, max=10.0, group="Vận hành",
                         help="Tăng lên để tiết kiệm pin")),
    ("sim_speed", Input(10.0, "Tốc độ giả lập (x)", min=1.0, max=5000.0, group="Giả lập",
                        help="1 giây thật = bao nhiêu giây giả lập")),
    ("sim_start_price", Input(30000.0, "Giá khởi điểm giả lập", min=0.000001, group="Giả lập")),
    # ---- Chạy nền & cảnh báo ----
    ("background_service", Input(True, "Chạy nền bằng dịch vụ (khuyên dùng)", group="Chạy nền & cảnh báo",
                                 help="Bot sống khi tắt màn hình / thoát app, có thông báo trên thanh trạng thái")),
    ("auto_resume", Input(True, "Tự khôi phục phiên sau sự cố", group="Chạy nền & cảnh báo",
                          help="Nếu dịch vụ bị hệ thống giết/crash, tự chạy lại bot với sổ lệnh đã lưu")),
    ("power_mode", Input("balanced", "Chế độ năng lượng", choices=["balanced", "saver"],
                         group="Chạy nền & cảnh báo",
                         help="saver: khi app ở nền chỉ lấy giá ≥3 giây/lần để tiết kiệm pin")),
    ("notify_trades", Input(False, "Thông báo mỗi khi mở/đóng lệnh", group="Chạy nền & cảnh báo")),
    # ---- AI ----
    ("ai_rounds", Input(2, "Số vòng thảo luận mỗi lần", min=1, max=5, group="AI")),
    ("ai_auto_interval", Input(15, "Chu kỳ AI tự thảo luận (phút)", min=1, max=1440, group="AI",
                               help="Mỗi lần thảo luận tốn API call của từng model")),
    ("ai_decision_mode", Input("decider", "Cách chốt quyết định", choices=["decider", "majority"], group="AI",
                               help="decider: 1 AI chốt; majority: mọi AI bỏ phiếu, cần đa số đồng thuận")),
    ("ai_signal_ttl", Input(30, "Tín hiệu AI hết hạn sau (phút)", min=1, max=1440, group="AI")),
    ("ai_max_tokens", Input(800, "Giới hạn token mỗi câu trả lời", min=100, max=4000, group="AI")),
    # ---- Binance live ----
    ("api_key", Input("", "Binance API key", group="Binance (chỉ khi live)")),
    ("api_secret", Input("", "Binance API secret", secret=True, group="Binance (chỉ khi live)")),
    ("exchange", Input("binance_spot", "Sàn / loại thị trường", choices=["binance_spot", "binance_futures"],
                       group="Binance (chỉ khi live)",
                       help="futures: có BÁN KHỐNG + đòn bẩy (tài khoản phải ở One-way mode)")),
    ("testnet", Input(False, "Dùng Binance Testnet (tiền giả)", group="Binance (chỉ khi live)",
                      help="Nên thử live ở testnet trước (cần API key của testnet)")),
    ("base_url", Input("", "Base URL tuỳ chỉnh", group="Binance (chỉ khi live)",
                       help="Để trống = tự chọn theo sàn/testnet; vd https://data-api.binance.vision")),
    ("live_confirm", Input(False, "Tôi hiểu rủi ro giao dịch tiền thật", group="Binance (chỉ khi live)")),
])


def default_settings():
    return {k: v.default for k, v in GLOBAL_INPUTS.items()}


def clean_settings(raw):
    """Ép toàn bộ settings về đúng kiểu; giá trị hỏng -> về mặc định."""
    out = {}
    raw = raw or {}
    for k, inp in GLOBAL_INPUTS.items():
        try:
            out[k] = inp.coerce(raw.get(k, inp.default))
        except ValueError:
            out[k] = inp.default
    return out
