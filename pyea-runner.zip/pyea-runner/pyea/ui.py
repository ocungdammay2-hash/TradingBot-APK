"""Giao diện chính (Kivy): 5 tab Bot | Thông số | Giám sát | AI | Nhật ký."""
import json
import os
import re
import threading
import time
import traceback

from kivy.app import App
from kivy.base import ExceptionHandler, ExceptionManager
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelHeader
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.utils import escape_markup, platform

from . import android_native as native
from . import android_utils, diagnostics, explain
from .ai import AGENT_INPUTS, PRESETS, AIHub, default_agent
from .codeedit import (check_bot_code, extract_bot_code, make_diff, overwrite_with_backup,
                       save_new_version)
from .engine import STATUS_TEXT, BotRunner
from .ipc import ServiceClient, ServiceHandle
from .loader import build_params, inspect_bot
from .settings import GLOBAL_INPUTS
from .storage import Store
from .ui_widgets import (AMBER, BG, BG2, BLUE, DOWN, GREEN, MIN_TOUCH, MUTED, PALETTE, PANEL, PANEL2,
                         RED, TEXT, UP, CandleChart, LineChart, Panel, ParamForm, StatBox, Table,
                         confirm, flabel, fm, fp, hexc, mkbtn, mkchip, popup, section, setup_fonts, vbox,
                         vscroll, wlabel)

STATUS_COLOR = {"running": UP, "starting": AMBER, "stopping": AMBER, "stopped": MUTED,
                "idle": MUTED, "error": DOWN}
LOG_COLOR = {"ERROR": DOWN, "WARN": AMBER, "BOT": (0.45, 0.72, 1, 1), "INFO": TEXT}
MAX_LOG_LINES = 250
MAX_BUBBLES = 60
MODES = ["Chat 1 AI", "Nhóm AI + tôi", "Nhóm AI tự thảo luận"]
ZOOMS = [20, 30, 45, 60, 90, 120, 160]


def add_text_block(box, text, size=12, color=TEXT, chunk=28):
    """Thêm văn bản dài vào box theo từng cụm dòng (tránh giới hạn texture của Label)."""
    lines = str(text).split("\n")
    for i in range(0, len(lines), chunk):
        box.add_widget(wlabel(escape_markup("\n".join(lines[i:i + chunk])), size, color))


# ============================================================== Tab: Bot
class BotsTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(8), spacing=dp(6), **kw)
        self.app = app
        self.add_widget(flabel("Bot đã nạp (chạm để chọn)", 14, AMBER, bold=True, size_hint_y=None, height=dp(30)))
        self.list_box = vbox(spacing=dp(4))
        self.add_widget(vscroll(self.list_box))
        self.info = Panel(orientation="vertical", size_hint_y=None, height=dp(96), padding=dp(8), spacing=dp(2))
        self.info_text = wlabel("", 12)
        self.info.add_widget(vscroll(self._wrap(self.info_text)))
        self.add_widget(self.info)

        r1 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r1.add_widget(mkbtn("Nạp file .py", BLUE, on_release=app.pick_bot_file))
        r1.add_widget(mkbtn("Sao chép mẫu", PANEL2, on_release=app.copy_template))
        self.add_widget(r1)
        r2 = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r2.add_widget(mkbtn("Cài lại bot mẫu", PANEL2, on_release=app.reseed))
        r2.add_widget(mkbtn("Xoá bot", PANEL2, on_release=app.delete_selected))
        self.add_widget(r2)
        self.run_btn = mkbtn("▶  CHẠY BOT", GREEN, h=54, on_release=app.start_bot, size=16)
        self.stop_btn = mkbtn("■  DỪNG BOT", RED, h=54, on_release=app.stop_bot, size=16)
        r3 = BoxLayout(size_hint_y=None, height=dp(54), spacing=dp(6))
        r3.add_widget(self.run_btn)
        r3.add_widget(self.stop_btn)
        self.add_widget(r3)
        self.add_widget(mkbtn("Thoát ứng dụng", PANEL, h=40, on_release=app.quit_app, size=12))

    @staticmethod
    def _wrap(w):
        box = vbox()
        box.add_widget(w)
        return box

    def rebuild(self, paths, selected, infos):
        self.list_box.clear_widgets()
        for p in paths:
            info = infos[p]
            title = escape_markup(info.name or info.file) if info.ok else "[color=%s]%s (lỗi)[/color]" % (
                hexc(DOWN), escape_markup(info.file))
            b = ToggleButton(text="%s\n[size=11sp][color=%s]%s[/color][/size]" % (title, hexc(MUTED), escape_markup(info.file)),
                             markup=True, group="bots", allow_no_selection=False, size_hint_y=None,
                             height=dp(60), halign="left", valign="middle", background_normal="",
                             background_down="", background_color=BLUE if p == selected else PANEL2,
                             color=TEXT, font_size=sp(14), state="down" if p == selected else "normal")
            b.bind(size=lambda w, s: setattr(w, "text_size", (s[0] - dp(16), s[1])))
            b.bind(state=lambda w, st: setattr(w, "background_color", BLUE if st == "down" else PANEL2))
            b.bind(on_release=lambda w, p=p: self.app.select_bot(p))
            self.list_box.add_widget(b)

    def show_info(self, info):
        if info is None:
            self.info_text.text = "Chưa chọn bot nào. Hãy nạp file .py hoặc chọn bot mẫu."
        elif not info.ok:
            self.info_text.text = "[color=%s]Không nạp được:\n%s[/color]" % (hexc(DOWN), escape_markup(info.error))
        else:
            self.info_text.text = "[b]%s[/b]  v%s %s\n%s\nSố tham số: %d" % (
                escape_markup(info.name), escape_markup(info.version), escape_markup(info.author),
                escape_markup(info.description or "(không có mô tả)"), len(info.inputs))

    def set_running(self, running):
        self.run_btn.disabled = running
        self.stop_btn.disabled = not running


# ============================================================== Tab: Thông số
class ParamsTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(6), **kw)
        self.app = app
        self.content = vbox(spacing=dp(6))
        self.add_widget(vscroll(self.content))
        self.gform = None
        self.bform = None
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=lambda *_: app.save_forms(True)))
        row.add_widget(mkbtn("Mặc định bot", PANEL2, on_release=lambda *_: self.reset_bot()))
        row.add_widget(mkbtn("Mặc định chung", PANEL2, on_release=lambda *_: self.reset_global()))
        self.add_widget(row)
        self.build(None, {}, app.settings)

    def build(self, info, bot_values, settings):
        self.content.clear_widgets()
        self.content.add_widget(wlabel("Thay đổi áp dụng khi chạy lại bot. Bấm Lưu để ghi nhớ.", 11, MUTED))
        self.content.add_widget(section("THÔNG SỐ BOT" + ((": " + info.name) if info and info.ok else "")))
        if info is not None and info.ok and info.inputs:
            self.bform = ParamForm(info.inputs, bot_values)
            self.content.add_widget(self.bform)
        else:
            self.bform = None
            self.content.add_widget(wlabel("Bot này không khai báo tham số (inputs) hoặc chưa chọn bot.", 12, MUTED))
        self.content.add_widget(section("CÀI ĐẶT CHUNG"))
        self.gform = ParamForm(GLOBAL_INPUTS, settings)
        self.content.add_widget(self.gform)

    def reset_bot(self):
        if self.bform:
            self.bform.reset()

    def reset_global(self):
        if self.gform:
            self.gform.reset()


# ============================================================== Tab: Giám sát
class DashTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", **kw)
        self.app = app
        self.prefs = app.store.load_prefs()
        c = vbox(padding=dp(6), spacing=dp(6))
        self.status = Panel(orientation="vertical", size_hint_y=None, height=dp(66), padding=dp(8))
        self.st_label = flabel("Chưa chạy", 18, MUTED, bold=True)
        self.st_info = flabel("", 11, MUTED)
        self.status.add_widget(self.st_label)
        self.status.add_widget(self.st_info)
        c.add_widget(self.status)
        self.msg = wlabel("", 12, DOWN)
        c.add_widget(self.msg)
        self.thinking = wlabel("", 12, AMBER)
        c.add_widget(self.thinking)
        self.price = flabel("", 14, TEXT, bold=True, size_hint_y=None, height=dp(30))
        c.add_widget(self.price)

        grid = GridLayout(cols=2, size_hint_y=None, height=dp(4 * 58 + 3 * 6), spacing=dp(6))
        self.s = {}
        for key, title in (("balance", "Số dư"), ("equity", "Equity"), ("floating", "Lãi/lỗ thả nổi"),
                           ("pnl", "Tổng lãi/lỗ"), ("trades", "Lệnh đã đóng"), ("winrate", "Tỷ lệ thắng"),
                           ("dd", "Sụt vốn tối đa"), ("run", "Thời gian chạy / tick")):
            self.s[key] = StatBox(title, size_hint_y=None, height=dp(58))
            grid.add_widget(self.s[key])
        c.add_widget(grid)

        c.add_widget(section("BIỂU ĐỒ - chạm vào chấm ▲ ▼ ● để xem lý do"))
        self.chip_sv = ScrollView(do_scroll_y=False, size_hint_y=None, height=dp(42), bar_width=0)
        self.chip_box = BoxLayout(orientation="horizontal", size_hint=(None, 1), spacing=dp(6))
        self.chip_box.bind(minimum_width=self.chip_box.setter("width"))
        self.chip_sv.add_widget(self.chip_box)
        c.add_widget(self.chip_sv)
        self.chart = CandleChart(on_tap=app.show_event, size_hint_y=None, height=dp(300))
        self.chart.bars = int(self.prefs.get("bars", 60))
        self.chart.hidden = set(self.prefs.get("hidden_plots", []))
        self.chart.show_markers = bool(self.prefs.get("show_markers", True))
        self.chart.show_lines = bool(self.prefs.get("show_lines", True))
        self.chart.show_grid = bool(self.prefs.get("show_grid", True))
        c.add_widget(self.chart)
        ctl = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        for text, fn in (("−", lambda *_: self.zoom(+1)), ("+", lambda *_: self.zoom(-1)),
                         ("◀", lambda *_: self.pan(+1)), ("▶", lambda *_: self.pan(-1)),
                         ("Mới nhất", lambda *_: self.pan(0))):
            ctl.add_widget(mkbtn(text, PANEL2, h=40, on_release=fn, size=14))
        c.add_widget(ctl)
        self._chip_sig = None
        self._build_chips([])

        c.add_widget(section("ĐƯỜNG EQUITY"))
        self.eq = LineChart(size_hint_y=None, height=dp(100))
        c.add_widget(self.eq)

        c.add_widget(section("ĐIỂM VÀO / RA GẦN ĐÂY (chạm để xem lý do)"))
        self.ev_box = vbox(spacing=dp(4))
        c.add_widget(self.ev_box)
        self._ev_sig = None

        hdr = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        hdr.add_widget(section("LỆNH ĐANG MỞ"))
        hdr.add_widget(mkbtn("Đóng tất cả", RED, h=40, on_release=app.close_all_positions, size=12, size_hint_x=0.5))
        c.add_widget(hdr)
        self.pos_table = Table(["#", "Loại", "KL", "Giá vào", "SL", "TP", "P/L"], [0.5, 0.8, 1, 1.3, 1.2, 1.2, 1.1])
        c.add_widget(self.pos_table)
        c.add_widget(section("LỊCH SỬ LỆNH (30 gần nhất)"))
        self.tr_table = Table(["Giờ", "Loại", "KL", "Vào", "Ra", "P/L", "Lý do"], [1.1, 0.8, 1, 1.2, 1.2, 1.1, 1.2])
        c.add_widget(self.tr_table)
        self._tr_sig = None
        self.add_widget(vscroll(c))

    # ---- tuỳ chọn hiển thị ----
    def _save_prefs(self):
        ch = self.chart
        self.prefs.update({"bars": ch.bars, "hidden_plots": sorted(ch.hidden), "show_markers": ch.show_markers,
                           "show_lines": ch.show_lines, "show_grid": ch.show_grid})
        try:
            self.app.store.save_prefs(self.prefs)
        except OSError:
            pass

    def _flag(self, attr):
        def cb(active):
            setattr(self.chart, attr, active)
            self._save_prefs()
            self.chart.redraw()
        return cb

    def _plot_toggle(self, name):
        def cb(active):
            (self.chart.hidden.discard if active else self.chart.hidden.add)(name)
            self._save_prefs()
            self.chart.redraw()
        return cb

    def _build_chips(self, plot_names):
        sig = tuple(plot_names)
        if sig == self._chip_sig:
            return
        self._chip_sig = sig
        self.chip_box.clear_widgets()
        ch = self.chart
        self.chip_box.add_widget(mkchip("Điểm vào/ra", AMBER, ch.show_markers, self._flag("show_markers")))
        self.chip_box.add_widget(mkchip("Lệnh mở", AMBER, ch.show_lines, self._flag("show_lines")))
        self.chip_box.add_widget(mkchip("Lưới", AMBER, ch.show_grid, self._flag("show_grid")))
        for i, n in enumerate(plot_names):
            self.chip_box.add_widget(mkchip("■ " + n, PALETTE[i % len(PALETTE)], n not in ch.hidden, self._plot_toggle(n)))

    def zoom(self, d):
        ch = self.chart
        i = min(range(len(ZOOMS)), key=lambda k: abs(ZOOMS[k] - ch.bars))
        ch.bars = ZOOMS[max(0, min(len(ZOOMS) - 1, i + d))]
        self._save_prefs()
        ch.redraw()

    def pan(self, d):
        ch = self.chart
        if d == 0:
            ch.offset = 0
        else:
            ch.offset = max(0, min(max(0, len(ch.candles) - ch.bars), ch.offset + d * max(1, ch.bars // 3)))
        ch.redraw()

    # ---- cập nhật ----
    def update(self, snap, events):
        if not snap:
            return
        st = snap["status"]
        self.st_label.text = snap["status_text"]
        self.st_label.color = STATUS_COLOR.get(st, TEXT)
        self.st_info.text = "%s  |  %s %s  |  chế độ %s" % (snap["bot"], snap["symbol"], snap["timeframe"], snap["mode"].upper())
        self.msg.text = escape_markup(snap.get("message", "")) if st in ("error", "stopped") else ""
        bs = snap.get("bot_status")
        self.thinking.text = ("Bot đang nghĩ: " + escape_markup(bs)) if bs else ""
        if not snap.get("ready"):
            return
        self.price.text = "Bid %s   Ask %s" % (fp(snap["bid"]), fp(snap["ask"]))
        s = self.s
        s["balance"].set(fp(snap["balance"]))
        s["equity"].set(fp(snap["equity"]))
        fl = snap["floating"]
        s["floating"].set(fm(fl), UP if fl >= 0 else DOWN)
        s["pnl"].set("%s (%+.2f%%)" % (fm(snap["pnl"]), snap["pnl_pct"]), UP if snap["pnl"] >= 0 else DOWN)
        s["trades"].set("%d" % snap["n_trades"])
        s["winrate"].set("%.0f%%" % snap["win_rate"] if snap["n_trades"] else "-")
        s["dd"].set("%.2f%%" % snap["max_dd"], DOWN if snap["max_dd"] > 10 else TEXT)
        up = int(snap["uptime"])
        s["run"].set("%02d:%02d:%02d / %d" % (up // 3600, up % 3600 // 60, up % 60, snap["ticks"]))

        hl = [(p.open_price, UP if p.side == "buy" else DOWN) for p in snap["positions"]]
        self._build_chips(list(snap["plots"]))
        self.chart.update(snap["candles"], snap["plots"], events, hl)
        self.eq.update(snap["equity_curve"], snap["start_balance"])

        sig = (len(events), events[-1].id if events else 0)
        if sig != self._ev_sig:
            self._ev_sig = sig
            self.ev_box.clear_widgets()
            if not events:
                self.ev_box.add_widget(wlabel("Chưa có lệnh/tín hiệu nào.", 12, MUTED))
            for ev in reversed(events[-8:]):
                col = {"open": UP if ev.side == "buy" else DOWN, "close": UP if ev.profit >= 0 else DOWN}.get(ev.kind, MUTED)
                kind = {"open": "VÀO", "close": "RA", "note": "TÍN HIỆU"}[ev.kind]
                txt = "%s  %s %s @ %s%s\n%s" % (time.strftime("%H:%M:%S", time.localtime(ev.time)), kind,
                                               {"buy": "MUA", "sell": "BÁN"}.get(ev.side, ""), fp(ev.price),
                                               ("  (%+.2f)" % ev.profit) if ev.kind == "close" else "",
                                               (ev.reason or "")[:80])
                b = mkbtn(txt, PANEL2, h=52, size=11, on_release=lambda *_, e=ev: self.app.show_event(e))
                b.halign = "left"
                b.bind(size=lambda w, sz: setattr(w, "text_size", (sz[0] - dp(14), sz[1])))
                b.color = TEXT
                self.ev_box.add_widget(b)

        rows = []
        for p in snap["positions"][:15]:
            rows.append([str(p.id), ("MUA", UP) if p.side == "buy" else ("BÁN", DOWN), "%.6g" % p.volume,
                         fp(p.open_price), fp(p.sl) if p.sl else "-", fp(p.tp) if p.tp else "-",
                         (fm(p.profit), UP if p.profit >= 0 else DOWN)])
        self.pos_table.set_rows(rows)
        sig = (snap["n_trades"], snap["trades"][0].id if snap["trades"] else 0)
        if sig != self._tr_sig:
            self._tr_sig = sig
            tr_rows = []
            for t in snap["trades"]:
                tr_rows.append([time.strftime("%H:%M:%S", time.localtime(t.close_time)),
                                ("MUA", UP) if t.side == "buy" else ("BÁN", DOWN), "%.6g" % t.volume,
                                fp(t.open_price), fp(t.close_price), (fm(t.profit), UP if t.profit >= 0 else DOWN),
                                t.reason])
            self.tr_table.set_rows(tr_rows)


# ============================================================== Tab: AI
class AITab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(5), **kw)
        self.app = app
        top = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        self.mode = Spinner(text=MODES[0], values=MODES, font_size=sp(12), background_normal="",
                            background_color=PANEL2, color=TEXT)
        self.mode.bind(text=self._on_mode)
        self.agent = Spinner(text="(chưa có AI)", values=[], font_size=sp(12), background_normal="",
                             background_color=PANEL2, color=TEXT)
        top.add_widget(self.mode)
        top.add_widget(self.agent)
        self.add_widget(top)
        r = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        r.add_widget(mkbtn("Quản lý AI", BLUE, h=44, on_release=lambda *_: app.open_agents(), size=12))
        r.add_widget(mkbtn("Giải thích bot", PANEL2, h=44, on_release=lambda *_: self.explain(), size=12))
        r.add_widget(mkbtn("Xoá chat", PANEL2, h=44, on_release=lambda *_: self.clear(), size=12))
        self.add_widget(r)
        self.auto_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        self.auto_btn = mkbtn("Bắt đầu tự thảo luận", GREEN, h=44, on_release=lambda *_: app.toggle_ai_auto(), size=12)
        self.sig_label = flabel("Tín hiệu: chưa có", 11, MUTED)
        self.auto_row.add_widget(self.auto_btn)
        self.auto_row.add_widget(self.sig_label)
        self.chat_box = vbox(spacing=dp(6), padding=dp(2))
        self.sv = vscroll(self.chat_box)
        self.add_widget(self.sv)
        self.status = flabel("", 11, AMBER, size_hint_y=None, height=dp(20))
        self.add_widget(self.status)
        self.inp_row = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(6))
        self.inp = TextInput(hint_text="Nhắn cho AI (vd: giải thích thuật toán / sửa bot để ...)", multiline=True,
                             font_size=sp(13), background_color=PANEL2, foreground_color=TEXT,
                             cursor_color=TEXT, hint_text_color=MUTED)
        self.inp_row.add_widget(self.inp)
        self.send_btn = mkbtn("Gửi", BLUE, h=56, on_release=lambda *_: self.send(), size_hint_x=0.25)
        self.inp_row.add_widget(self.send_btn)
        self.add_widget(self.inp_row)
        self._colors = {}
        self.refresh_agents()
        for m in app.store.chat.tail(30):
            self.add_bubble(m)
        self._pos = app.store.chat.size()

    # ---- trạng thái ----
    def refresh_agents(self):
        names = [a["name"] for a in self.app.hub.agents]
        self.agent.values = names
        if names and self.agent.text not in names:
            self.agent.text = names[0]
        if not names:
            self.agent.text = "(chưa có AI)"

    def _on_mode(self, _w, text):
        auto = text == MODES[2]
        if auto and self.auto_row.parent is None:
            self.add_widget(self.auto_row, index=self.children.index(self.sv) + 1)
        elif not auto and self.auto_row.parent is not None:
            self.remove_widget(self.auto_row)
        self.inp_row.opacity = 0.35 if auto else 1
        self.send_btn.disabled = auto
        self.agent.disabled = text != MODES[0]

    def update(self):
        """Gọi mỗi chu kỳ làm mới: nhận tin mới (từ UI hoặc dịch vụ nền) + cập nhật tín hiệu."""
        msgs, self._pos = self.app.store.chat.read_from(self._pos)
        for m in msgs:
            self.add_bubble(m)
        info = self.app.ai_info()
        s = info.get("signal")
        if s:
            self.sig_label.text = "Tín hiệu: %s %.0f%% (%d phút trước)" % (s["action"].upper(), s["confidence"] * 100, s.get("age", 0) // 60)
            self.sig_label.color = UP if s["action"] == "buy" else DOWN if s["action"] == "sell" else AMBER
        else:
            self.sig_label.text = "Tín hiệu: chưa có / đã hết hạn"
            self.sig_label.color = MUTED
        self.auto_btn.text = "Dừng tự thảo luận" if info.get("auto_on") else "Bắt đầu tự thảo luận"
        self.status.text = info.get("status") or ""

    # ---- hành động ----
    def send(self):
        text = self.inp.text.strip()
        if not text:
            return
        if self._dispatch(text):
            self.inp.text = ""
        else:
            self.status.text = "AI đang bận, vui lòng chờ..."

    def _dispatch(self, text):
        hub = self.app.hub
        if self.mode.text == MODES[0]:
            return hub.ask_single(self.agent.text, text)
        return hub.ask_group(text)

    def explain(self):
        prompt = ("Hãy đọc mã nguồn bot hiện tại và giải thích bằng tiếng Việt: (1) ý tưởng chiến lược, "
                  "(2) điều kiện vào/ra lệnh, (3) quản lý vốn, SL/TP, (4) ý nghĩa từng tham số, "
                  "(5) điểm yếu và rủi ro cần lưu ý.")
        if self.app.selected is None:
            self.status.text = "Hãy chọn bot ở tab Bot trước."
            return
        if not self._dispatch(prompt):
            self.status.text = "AI đang bận, vui lòng chờ..."

    def clear(self):
        self.app.hub.clear_chat()
        self.chat_box.clear_widgets()
        self._pos = 0

    # ---- hiển thị tin nhắn ----
    def _color_for(self, who):
        if who not in self._colors:
            self._colors[who] = PALETTE[len(self._colors) % len(PALETTE)]
        return self._colors[who]

    @staticmethod
    def _display(text):
        """Rút gọn khối code dài + cắt tin quá dài (tránh giới hạn texture)."""
        out, pos = [], 0
        for m in re.finditer(r"```[ \t]*(?:python|py)?[ \t]*\r?\n(.*?)```", text, re.S | re.I):
            out.append(text[pos:m.start()])
            n = m.group(1).count("\n") + 1
            body = m.group(1) if n <= 14 else "[Mã nguồn %d dòng - nhấn 'Xem & áp dụng code']" % n
            out.append("\n" + body + "\n")
            pos = m.end()
        out.append(text[pos:])
        s = "".join(out).strip()
        return s if len(s) <= 3000 else s[:3000] + "\n… (cắt bớt - nhấn Sao chép để lấy đầy đủ)"

    def add_bubble(self, m):
        who, kind = m["who"], m.get("kind", "chat")
        if kind == "notice":
            b = vbox(padding=[dp(6), 0])
            b.add_widget(wlabel("[i]%s[/i]" % escape_markup(m["text"][:600]), 11, MUTED))
        else:
            bg = (0.10, 0.22, 0.38, 1) if who == "user" else ((0.28, 0.22, 0.08, 1) if kind == "decision" else PANEL)
            b = Panel(bg=bg, orientation="vertical", size_hint_y=None, padding=dp(8), spacing=dp(4))
            b.bind(minimum_height=b.setter("height"))
            col = AMBER if who == "user" else self._color_for(who)
            b.add_widget(flabel("[b]%s[/b]  [size=10sp][color=%s]%s[/color][/size]" % (
                escape_markup("Bạn" if who == "user" else who), hexc(MUTED),
                time.strftime("%H:%M", time.localtime(m["ts"]))), 12, col, size_hint_y=None, height=dp(20)))
            b.add_widget(wlabel(escape_markup(self._display(m["text"])), 13))
            if who != "user":
                row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
                row.add_widget(mkbtn("Sao chép", PANEL2, h=40, size=11,
                                     on_release=lambda *_, t=m["text"]: Clipboard.copy(t)))
                if extract_bot_code(m["text"]):
                    row.add_widget(mkbtn("Xem & áp dụng code", GREEN, h=40, size=11,
                                         on_release=lambda *_, mm=m: self.app.review_code(mm)))
                b.add_widget(row)
        self.chat_box.add_widget(b)
        while len(self.chat_box.children) > MAX_BUBBLES:
            self.chat_box.remove_widget(self.chat_box.children[-1])
        Clock.schedule_once(lambda dt: setattr(self.sv, "scroll_y", 0), 0.1)


# ============================================================== Tab: Nhật ký
class LogTab(BoxLayout):
    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", padding=dp(6), spacing=dp(6), **kw)
        self.app = app
        self.box = vbox(spacing=dp(1))
        self.sv = vscroll(self.box)
        self.add_widget(self.sv)
        self.lines = []
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Xoá", PANEL2, on_release=lambda *_: self.clear()))
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy("\n".join(self.lines))))
        row.add_widget(mkbtn("Kiểm tra hệ thống", BLUE, on_release=lambda *_: app.run_diagnostics()))
        self.add_widget(row)

    def clear(self):
        self.box.clear_widgets()
        self.lines = []

    def append(self, entries):
        for _id, ts, level, msg in entries:
            line = "%s [%s] %s" % (time.strftime("%H:%M:%S", time.localtime(ts)), level, msg)
            self.lines.append(line)
            self.box.add_widget(wlabel(escape_markup(line), 11, LOG_COLOR.get(level, TEXT)))
        while len(self.lines) > MAX_LOG_LINES:
            self.lines.pop(0)
            self.box.remove_widget(self.box.children[-1])
        if entries:
            Clock.schedule_once(lambda dt: setattr(self.sv, "scroll_y", 0), 0.1)


# ============================================================== App
class CrashHandler(ExceptionHandler):
    """Lỗi bất ngờ trong callback giao diện: ghi nhật ký + giữ app sống (bot nền không bị ảnh hưởng)."""

    def __init__(self, app):
        super().__init__()
        self.app = app
        self.times = []

    def handle_exception(self, inst):
        try:
            self.app.note_ui_error("".join(traceback.format_exception(type(inst), inst, inst.__traceback__)))
        except Exception:
            pass
        return ExceptionManager.PASS


class PyEAApp(App):
    title = "PyEA Runner"

    def build(self):
        setup_fonts()
        Window.clearcolor = BG
        if platform == "android":
            Window.softinput_mode = "below_target"
        self.store = Store(self.user_data_dir)
        self.store.seed_examples()
        self.client = ServiceClient(self.user_data_dir)
        self.settings = self.store.load_settings()
        self.runner = None
        self.last_snap = None
        self.log_cursor = 0
        self.selected = None
        self._info_cache = {}
        self._was_running = False
        self._last_config = None
        self._restarts = []
        self._alarm_seen = 0.0
        self._ui_errors = []
        self.hub = AIHub(self.store, self._hub_snapshot, self._hub_bot, lambda: self.settings)
        ExceptionManager.add_handler(CrashHandler(self))

        self.bots_tab = BotsTab(self)
        self.params_tab = ParamsTab(self)
        self.dash_tab = DashTab(self)
        self.ai_tab = AITab(self)
        self.log_tab = LogTab(self)

        root = TabbedPanel(do_default_tab=False, tab_pos="bottom_mid", tab_height=dp(46),
                           tab_width=Window.width / 5.0, background_color=BG, background_image="")
        self.tabs = {}
        for key, title, widget in (("bots", "Bot", self.bots_tab), ("params", "Thông số", self.params_tab),
                                   ("dash", "Giám sát", self.dash_tab), ("ai", "AI", self.ai_tab),
                                   ("log", "Nhật ký", self.log_tab)):
            h = TabbedPanelHeader(text=title, font_size=sp(12))
            h.content = widget
            root.add_widget(h)
            self.tabs[key] = h
        Window.bind(width=lambda w, v: setattr(root, "tab_width", v / 5.0))
        Window.bind(on_keyboard=self._on_key)
        self.root_panel = root
        root.switch_to(self.tabs["bots"])

        self.refresh_bots()
        names = [os.path.basename(p) for p in self.store.list_bots()]
        if "ma_cross.py" in names:
            self.select_bot(os.path.join(self.store.bots_dir, "ma_cross.py"))
        elif self.store.list_bots():
            self.select_bot(self.store.list_bots()[0])
        else:
            self.select_bot(None)

        # Gắn lại vào dịch vụ nền đang chạy (nếu mở lại app khi bot vẫn chạy)
        h = ServiceHandle.attach(self.client, self.store.events_path)
        if h is not None:
            self.runner = h
            self._alarm_seen = max([a["t"] for a in h.alarms()] + [0.0])
            self.log_tab.append([(0, time.time(), "INFO", "Đã gắn lại vào bot đang chạy nền.")])
            self.root_panel.switch_to(self.tabs["dash"])
        self._ev = Clock.schedule_interval(self.refresh, float(self.settings["ui_refresh"]))
        Clock.schedule_once(self._after_start, 1.5)
        return root

    def _after_start(self, dt):
        native.request_notification_permission()
        crash = self.store.crash_path
        if os.path.exists(crash):
            try:
                with open(crash, "r", encoding="utf-8") as f:
                    text = f.read()[-1800:]
                os.replace(crash, crash + ".old")
            except OSError:
                return
            popup("Lần chạy trước ứng dụng bị lỗi",
                  "Bot chạy nền (nếu đang bật) vẫn hoạt động bình thường.\n\nChi tiết lỗi:\n" + text,
                  [("Sao chép", PANEL2, lambda p: (Clipboard.copy(text), False)[1]), ("Đóng", BLUE, None)], size=(0.95, 0.8), color=DOWN)

    # ---------------------------------------------------------- hệ thống
    def on_pause(self):
        return True            # giữ app sống khi xuống nền

    def on_resume(self):
        pass

    def on_stop(self):
        r = self.runner
        if r is not None and not isinstance(r, ServiceHandle):
            r.stop()           # chạy trực tiếp trong app -> dừng theo app; chạy nền (dịch vụ) -> để chạy tiếp
        self.hub.stop_auto()
        android_utils.set_keep_awake(False)

    def _on_key(self, window, key, *args):
        if key == 27 and platform == "android":      # nút Back
            android_utils.move_to_background()
            return True
        return False

    def quit_app(self, *_):
        r = self.runner
        svc_alive = isinstance(r, ServiceHandle) and r.is_alive()

        def leave(stop_bot):
            def go(_p):
                if stop_bot and r is not None:
                    r.stop()
                self.on_stop()
                self.stop()
            return go
        if svc_alive:
            popup("Thoát ứng dụng", "Bot đang chạy NỀN (có thông báo trên thanh trạng thái). Bạn muốn:",
                  [("Huỷ", PANEL2, None), ("Thoát, bot chạy tiếp", BLUE, leave(False)), ("Dừng bot & thoát", RED, leave(True))],
                  size=(0.95, 0.5))
        else:
            confirm("Thoát ứng dụng", "Bot đang chạy trực tiếp trong app (nếu có) sẽ bị dừng. Thoát?",
                    lambda: leave(True)(None), "Thoát")

    def toast(self, msg):
        popup("Thông báo", msg, size=(0.88, 0.35))

    # ---------------------------------------------------------- lỗi UI / crash
    def note_ui_error(self, tb):
        now = time.time()
        self._ui_errors = [t for t in self._ui_errors if now - t < 60] + [now]
        try:
            with open(self.store.crash_path, "a", encoding="utf-8") as f:
                f.write("%s [UI]\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
        except OSError:
            pass
        if len(self._ui_errors) <= 3:
            self.log_tab.append([(0, now, "ERROR", "Lỗi giao diện (app vẫn chạy): " + tb.strip().splitlines()[-1])])
        if len(self._ui_errors) == 30:
            native.notify_alarm("PyEA: giao diện lỗi liên tục", "Bot chạy nền (nếu có) vẫn hoạt động. Hãy mở lại app.")

    def report_fatal(self, tb):
        """main.py gọi khi app sắp crash: ghi log + báo động (bot nền vẫn chạy)."""
        try:
            with open(self.store.crash_path, "a", encoding="utf-8") as f:
                f.write("%s [FATAL]\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), tb))
        except Exception:
            pass
        native.notify_alarm("PyEA: ứng dụng bị crash", "Bot chạy nền (nếu đang bật) vẫn hoạt động. Chạm để mở lại. " + tb.strip().splitlines()[-1][:120])

    # ---------------------------------------------------------- bot
    def get_info(self, path):
        if path is None:
            return None
        try:
            mt = os.path.getmtime(path)
        except OSError:
            return None
        c = self._info_cache.get(path)
        if c and c[0] == mt:
            return c[1]
        info = inspect_bot(path)
        self._info_cache[path] = (mt, info)
        return info

    def refresh_bots(self, select=None):
        paths = self.store.list_bots()
        infos = {p: self.get_info(p) for p in paths}
        if select:
            self.selected = select
        if self.selected not in paths:
            self.selected = paths[0] if paths else None
        self.bots_tab.rebuild(paths, self.selected, infos)

    def select_bot(self, path):
        self.selected = path
        info = self.get_info(path)
        self.bots_tab.show_info(info)
        vals = self.store.load_params(path) if path else {}
        self.params_tab.build(info, vals, self.settings)
        self.refresh_bots()

    def pick_bot_file(self, *_):
        if android_utils.IS_ANDROID:
            android_utils.pick_file(self._on_picked)
            return
        chooser = FileChooserListView(filters=["*.py"], path=os.path.expanduser("~"))
        box = BoxLayout(orientation="vertical", spacing=dp(6))
        box.add_widget(chooser)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = Popup(title="Chọn file bot (.py)", content=box, size_hint=(0.95, 0.9))

        def ok(*_):
            if chooser.selection:
                pop.dismiss()
                self._install_path(chooser.selection[0])
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Chọn", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def _install_path(self, src):
        try:
            self.refresh_bots(select=self.store.install_bot_file(src))
            self.select_bot(self.selected)
        except Exception as e:
            self.toast("Không nạp được file: %s" % e)

    @mainthread
    def _on_picked(self, name, text, err):
        if err == "cancelled":
            return
        if err or text is None:
            self.toast("Không đọc được file:\n%s" % (err or ""))
            return
        if not name.lower().endswith(".py"):
            name += ".py"
        path = self.store.install_bot_text(name, text)
        self.refresh_bots(select=path)
        self.select_bot(path)

    def copy_template(self, *_):
        Clipboard.copy(self.store.template_text())
        self.toast("Đã sao chép mẫu bot vào clipboard.\nDán vào ứng dụng ghi chú, sửa lại, lưu thành file .py "
                   "rồi nạp bằng nút 'Nạp file .py'. Hoặc nhờ AI viết bot ở tab AI.")

    def reseed(self, *_):
        def go():
            self.store.seed_examples(overwrite=True)
            self._info_cache.clear()
            self.refresh_bots()
            self.select_bot(self.selected)
        confirm("Cài lại bot mẫu", "Các bot mẫu cùng tên sẽ bị ghi đè bằng bản gốc. Tiếp tục?", go, "Cài lại", BLUE)

    def delete_selected(self, *_):
        if not self.selected:
            return
        if self.runner and self.runner.is_alive():
            self.toast("Hãy dừng bot trước khi xoá.")
            return
        path = self.selected

        def go():
            self.store.delete_bot(path)
            self._info_cache.pop(path, None)
            self.selected = None
            self.refresh_bots()
            self.select_bot(self.selected)
        confirm("Xoá bot", "Xoá %s và thông số đã lưu?" % os.path.basename(path), go, "Xoá")

    # ---------------------------------------------------------- lưu form
    def save_forms(self, show=False):
        p = self.params_tab
        errs = []
        if p.gform:
            vals, e = p.gform.read()
            errs += e
            if not e:
                self.settings = vals
        if p.bform and self.selected:
            bvals, e = p.bform.read()
            errs += ["[bot] " + x for x in e]
            if not e:
                self.store.save_params(self.selected, bvals)
        if errs:
            popup("Giá trị chưa hợp lệ", "\n".join(errs), size=(0.9, 0.5), color=DOWN)
            return False
        self.store.save_settings(self.settings)
        self._ev.cancel()
        self._ev = Clock.schedule_interval(self.refresh, float(self.settings["ui_refresh"]))
        if show:
            self.toast("Đã lưu thông số.")
        return True

    # ---------------------------------------------------------- chạy / dừng
    def _saved_positions(self):
        try:
            with open(self.store.state_path, "r", encoding="utf-8") as f:
                d = json.load(f)
            ok = (d.get("bot_path") == self.selected and d.get("symbol") == str(self.settings["symbol"]).upper()
                  and d.get("mode") == self.settings["mode"])
            return len(d.get("account", {}).get("positions", [])) if ok else 0
        except Exception:
            return 0

    def start_bot(self, *_):
        if self.runner and self.runner.is_alive():
            return
        if not self.selected:
            self.toast("Chưa chọn bot.")
            return
        if not self.save_forms():
            return
        info = self.get_info(self.selected)
        if info is None or not info.ok:
            self.toast("Bot bị lỗi, không chạy được:\n%s" % (info.error if info else ""))
            return
        s = self.settings
        live = s["mode"] == "live"
        if live and not (s["live_confirm"] and s["api_key"] and s["api_secret"]):
            self.toast("Chế độ LIVE cần: nhập API key + secret và tick 'Tôi hiểu rủi ro giao dịch tiền thật' "
                       "ở tab Thông số.")
            return

        def proceed(resume):
            if live:
                where = "TESTNET (tiền giả)" if s["testnet"] else "tài khoản THẬT"
                confirm("GIAO DỊCH TIỀN THẬT" if not s["testnet"] else "LIVE TESTNET",
                        "Bot sẽ đặt lệnh trên Binance %s (%s)%s. Bạn đã thử kỹ ở chế độ paper chưa?" % (
                            where, s["exchange"], "" if s["testnet"] else " và có thể làm mất vốn"),
                        lambda: self._do_start(resume), "Chạy LIVE")
            else:
                self._do_start(resume)
        n = self._saved_positions()
        if n:
            popup("Phiên trước còn %d lệnh mở" % n,
                  "Lần chạy trước dừng khi còn lệnh chưa đóng. Khôi phục sổ lệnh đó (tiếp tục quản lý) hay bắt đầu phiên mới?",
                  [("Phiên mới", PANEL2, lambda p: proceed(False)), ("Khôi phục", GREEN, lambda p: proceed(True))],
                  size=(0.95, 0.45))
        else:
            proceed(False)

    def _make_config(self, resume):
        return {"bot_path": self.selected, "settings": dict(self.settings),
                "params": self.store.load_params(self.selected),
                "log_file": os.path.join(self.store.logs_dir, time.strftime("%Y%m%d") + ".log"),
                "trades_csv": self.store.trades_csv, "ai_auto": False, "resume": resume}

    def _do_start(self, resume=False):
        cfg = self._make_config(resume)
        self._last_config = cfg
        self.log_cursor = 0
        self.log_tab.clear()
        self.dash_tab._tr_sig = None
        self.dash_tab._ev_sig = None
        self.last_snap = None
        self._alarm_seen = time.time()
        started = False
        if native.IS_ANDROID and self.settings["background_service"]:
            started = self._start_service_mode(cfg)
        if not started:
            self._start_local(cfg)
        self.root_panel.switch_to(self.tabs["dash"])
        self._maybe_battery_prompt()

    def _start_service_mode(self, cfg):
        h = ServiceHandle(self.client, self.store.events_path, pending=True)
        h.start(cfg)
        if not self.client.host_alive():
            ok, err = native.start_service(json.dumps({"data_dir": self.user_data_dir}), "PyEA Runner", "Đang khởi động bot...")
            if not ok:
                self.client.pop_commands()
                self.log_tab.append([(0, time.time(), "WARN", "Không bật được dịch vụ nền (%s) -> chạy trực tiếp trong app" %
                                      (err.strip().splitlines()[-1] if err else "?"))])
                return False
        self.runner = h
        self.log_tab.append([(0, time.time(), "INFO", "Bot chạy NỀN bằng dịch vụ (vẫn chạy khi tắt màn hình / thoát app).")])
        return True

    def _start_local(self, cfg):
        if not cfg.get("resume"):
            try:
                os.remove(self.store.state_path)
            except OSError:
                pass
            try:
                open(self.store.events_path, "w").close()
            except OSError:
                pass
        self.runner = BotRunner(
            cfg["bot_path"], cfg["settings"], cfg["params"], log_file=cfg["log_file"], trades_csv=cfg["trades_csv"],
            ai_hub=self.hub, state_file=self.store.state_path, events_file=self.store.events_path,
            resume=cfg["resume"], alarm_cb=native.notify_alarm)
        self.runner.start()
        android_utils.set_keep_awake(bool(cfg["settings"]["keep_awake"]))

    def _maybe_battery_prompt(self):
        if not native.IS_ANDROID:
            return
        prefs = self.store.load_prefs()
        if prefs.get("battery_prompted") or native.is_ignoring_battery_optimizations():
            return
        prefs["battery_prompted"] = True
        self.store.save_prefs(prefs)
        popup("Giữ bot sống khi chạy nền",
              "Android có thể 'tối ưu pin' và giết bot nền sau một thời gian. Hãy cho phép PyEA Runner KHÔNG bị tối ưu pin "
              "(hộp thoại hệ thống sẽ hiện ra).",
              [("Để sau", PANEL2, None),
               ("Mở cài đặt", GREEN, lambda p: (native.request_ignore_battery_optimizations(), None)[1])], size=(0.95, 0.45))

    def stop_bot(self, *_):
        if self.runner and self.runner.is_alive():
            self.runner.stop()

    def close_all_positions(self, *_):
        if self.runner and self.runner.is_alive():
            confirm("Đóng tất cả lệnh", "Đóng toàn bộ lệnh đang mở theo giá thị trường?",
                    self.runner.request_close_all, "Đóng hết")

    # ---------------------------------------------------------- vòng cập nhật
    def refresh(self, dt):
        try:
            self.client.touch_ui()
        except OSError:
            pass
        r = self.runner
        if isinstance(r, ServiceHandle):
            self._service_watch(r)
            r = self.runner
        running = bool(r and r.is_alive())
        if r:
            snap = r.snapshot(chart_bars=160)
            if snap is not None:
                self.last_snap = snap
            new = r.get_logs(self.log_cursor)
            if new:
                self.log_cursor = new[-1][0]
                self.log_tab.append(new)
        if self._was_running and not running:
            self._on_finished()
        self._was_running = running
        self.bots_tab.set_running(running)
        if self.last_snap:
            self.dash_tab.update(self.last_snap, self.current_events(self.last_snap))
        self.ai_tab.update()

    def current_events(self, snap):
        r = self.runner
        if isinstance(r, ServiceHandle):
            return r.events()
        return (snap or {}).get("events", [])

    def _on_finished(self):
        android_utils.set_keep_awake(False)
        r = self.runner
        if isinstance(r, ServiceHandle):
            fin = r.finished_state()
            status, msg = fin if fin else ("", "")
        else:
            status, msg = r.status, r.message
        if status == "error":
            popup("Bot đã dừng vì lỗi", (msg or "")[:900], size=(0.95, 0.6), color=DOWN)

    # ---------------------------------------------------------- dịch vụ nền: theo dõi / báo động
    def _service_watch(self, h):
        if h.failed_to_start():
            self.log_tab.append([(0, time.time(), "ERROR", "Dịch vụ nền không phản hồi -> chạy trực tiếp trong app")])
            native.notify_alarm("PyEA: dịch vụ nền không phản hồi", "Bot được chạy trực tiếp trong app (sẽ dừng nếu bạn thoát app).")
            self.client.pop_commands()
            if self._last_config:
                self._start_local(self._last_config)
            return
        if h.crashed() and h.expect_running:
            self._watchdog_restart()
        for a in h.alarms():
            if a["t"] > self._alarm_seen:
                self._alarm_seen = a["t"]
                self.log_tab.append([(0, a["t"], "ERROR", "CẢNH BÁO: %s - %s" % (a["title"], a["text"]))])
                popup(a["title"], a["text"], size=(0.92, 0.4), color=AMBER)

    def _watchdog_restart(self):
        now = time.time()
        self._restarts = [t for t in self._restarts if now - t < 600]
        if len(self._restarts) >= 3:
            return
        self._restarts.append(now)
        self.log_tab.append([(0, now, "ERROR", "Dịch vụ nền ngừng phản hồi -> đang khởi động lại và khôi phục bot")])
        native.notify_alarm("PyEA: dịch vụ nền ngừng phản hồi", "Đang tự khởi động lại và khôi phục bot...")
        native.start_service(json.dumps({"data_dir": self.user_data_dir}), "PyEA Runner", "Đang khôi phục bot...")

    # ---------------------------------------------------------- AI
    def _hub_snapshot(self):
        r = self.runner
        return r.snapshot(chart_bars=80) if r else self.last_snap

    def _hub_bot(self):
        if not self.selected:
            return None
        info = self.get_info(self.selected)
        try:
            with open(self.selected, "r", encoding="utf-8") as f:
                src = f.read()
        except OSError:
            return None
        params = build_params(info.inputs, self.store.load_params(self.selected)) if info and info.ok else {}
        return (info.name if info and info.ok else os.path.basename(self.selected), src, params)

    def ai_info(self):
        r = self.runner
        if isinstance(r, ServiceHandle) and r.is_alive():
            return r.ai_info()
        h = self.hub
        return {"auto_on": h.auto_on, "signal": h.get_signal(), "status": h.status_text, "busy": h.busy}

    def toggle_ai_auto(self):
        r = self.runner
        if isinstance(r, ServiceHandle) and r.is_alive():
            r.set_ai_auto(not self.ai_info().get("auto_on"))
        elif self.hub.auto_on:
            self.hub.stop_auto()
        else:
            self.hub.start_auto()

    # ---------------------------------------------------------- popup lý do vào/ra lệnh
    def show_event(self, ev):
        events = self.current_events(self.last_snap) if self.last_snap else [ev]
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(6), padding=dp(4))
        for title, body in explain.describe_event(ev, events):
            box.add_widget(flabel(escape_markup(title), 12, AMBER, bold=True, size_hint_y=None, height=dp(26)))
            add_text_block(box, body, 12)
        content.add_widget(vscroll(box))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = Popup(title=explain.event_title(ev), content=content, size_hint=(0.97, 0.92), auto_dismiss=False)
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(explain.describe_text(ev, events))))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss()))
        content.add_widget(row)
        pop.open()

    # ---------------------------------------------------------- kiểm tra hệ thống
    def run_diagnostics(self):
        self.toast("Đang kiểm tra hệ thống (vài giây)...")

        def work():
            try:
                res = diagnostics.run_checks(self.user_data_dir, self.settings, self.store)
            except Exception:
                res = [{"name": "Kiểm tra", "status": "LỖI", "detail": traceback.format_exc(limit=2)}]
            self._show_diag(res)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _show_diag(self, results):
        text = diagnostics.format_report(results)
        try:
            with open(os.path.join(self.user_data_dir, "diagnostics.txt"), "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            pass
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        box = vbox(spacing=dp(4))
        col = {"OK": UP, "CHÚ Ý": AMBER, "LỖI": DOWN}
        for r in results:
            add_text_block(box, "[%s] %s: %s" % (r["status"], r["name"], r["detail"]), 12, col.get(r["status"], TEXT))
        content.add_widget(vscroll(box))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        pop = Popup(title="Kiểm tra hệ thống", content=content, size_hint=(0.97, 0.9), auto_dismiss=False)
        row.add_widget(mkbtn("Sao chép", PANEL2, on_release=lambda *_: Clipboard.copy(text), size=12))
        if native.IS_ANDROID:
            row.add_widget(mkbtn("Tối ưu pin", AMBER, on_release=lambda *_: native.request_ignore_battery_optimizations(), size=12))
        row.add_widget(mkbtn("Đóng", BLUE, on_release=lambda *_: pop.dismiss(), size=12))
        content.add_widget(row)
        pop.open()

    def open_agents(self):
        hub = self.hub
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        lst = vbox(spacing=dp(4))
        pop = Popup(title="Quản lý AI", content=content, size_hint=(0.95, 0.85), auto_dismiss=False)

        def rebuild():
            lst.clear_widgets()
            if not hub.agents:
                lst.add_widget(wlabel("Chưa có AI nào. Bấm 'Thêm AI', chọn nhà cung cấp và dán API key. "
                                      "Nên ưu tiên model miễn phí hoặc model tài chính chuyên biệt "
                                      "(chạy qua 'Máy chủ riêng' / 'Tuỳ chỉnh').", 12, MUTED))
            for i, a in enumerate(hub.agents):
                txt = "%s%s\n[size=11sp][color=%s]%s | %s%s[/color][/size]" % (
                    escape_markup(a["name"]), "" if a.get("enabled", True) else "  (tắt)", hexc(MUTED),
                    escape_markup(a["preset"]), escape_markup(a.get("model") or "(model mặc định)"),
                    " | chốt quyết định" if a.get("decider") else "")
                b = mkbtn(txt, PANEL2, h=58, on_release=lambda *_, i=i: edit(i), markup=True)
                b.halign = "left"
                b.bind(size=lambda w, s: setattr(w, "text_size", (s[0] - dp(16), s[1])))
                lst.add_widget(b)
            self.ai_tab.refresh_agents()

        def edit(idx):
            new = idx is None
            agent = default_agent(len(hub.agents) + 1) if new else dict(hub.agents[idx])
            form = ParamForm(AGENT_INPUTS, agent)
            box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
            note = wlabel("", 11, MUTED)
            res = wlabel("", 12, AMBER)

            def upd_note(*_):
                note.text = escape_markup(PRESETS.get(form.ctrl["preset"].text, {}).get("note", ""))
            form.ctrl["preset"].bind(text=upd_note)
            upd_note()
            inner = vbox(spacing=dp(4))
            inner.add_widget(note)
            inner.add_widget(form)
            inner.add_widget(res)
            box.add_widget(vscroll(inner))
            ep = Popup(title="Thêm AI" if new else "Sửa AI", content=box, size_hint=(0.97, 0.92), auto_dismiss=False)

            def collect():
                vals, errs = form.read()
                if errs:
                    res.text = "[color=%s]%s[/color]" % (hexc(DOWN), escape_markup("\n".join(errs)))
                    return None
                if not vals["name"].strip():
                    res.text = "Tên không được để trống"
                    return None
                for j, a in enumerate(hub.agents):
                    if a["name"] == vals["name"] and j != idx:
                        res.text = "Tên bị trùng"
                        return None
                return vals

            def save(*_):
                vals = collect()
                if vals is None:
                    return
                agents = list(hub.agents)
                if new:
                    agents.append(vals)
                else:
                    agents[idx] = vals
                if vals.get("decider"):          # chỉ 1 AI chốt quyết định
                    for a in agents:
                        if a is not vals:
                            a["decider"] = False
                hub.set_agents(agents)
                ep.dismiss()
                rebuild()

            def test(*_):
                vals = collect()
                if vals is None:
                    return
                res.text = "Đang thử kết nối..."

                def work():
                    ok, msg = hub.test_agent(vals)
                    self._set_text(res, ("[color=%s]OK: %s[/color]" % (hexc(UP), escape_markup(msg))) if ok else
                                   ("[color=%s]Lỗi: %s[/color]" % (hexc(DOWN), escape_markup(msg))))
                threading.Thread(target=work, daemon=True).start()

            def delete(*_):
                agents = [a for j, a in enumerate(hub.agents) if j != idx]
                hub.set_agents(agents)
                ep.dismiss()
                rebuild()
            row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
            row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: ep.dismiss(), size=12))
            row.add_widget(mkbtn("Thử", BLUE, on_release=test, size=12))
            if not new:
                row.add_widget(mkbtn("Xoá", RED, on_release=delete, size=12))
            row.add_widget(mkbtn("Lưu", GREEN, on_release=save, size=12))
            box.add_widget(row)
            ep.open()

        content.add_widget(vscroll(lst))
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Thêm AI", GREEN, on_release=lambda *_: edit(None)))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        content.add_widget(row)
        rebuild()
        pop.open()

    @mainthread
    def _set_text(self, widget, text):
        widget.text = text

    def review_code(self, msg):
        code = extract_bot_code(msg["text"])
        if not code:
            return
        ok, info = check_bot_code(code)
        old = ""
        if self.selected:
            try:
                with open(self.selected, "r", encoding="utf-8") as f:
                    old = f.read()
            except OSError:
                pass
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        content.add_widget(wlabel(escape_markup(info), 13, UP if ok else DOWN))
        box = vbox(spacing=dp(0))
        for ln in make_diff(old, code):
            col = UP if ln.startswith("+") and not ln.startswith("+++") else \
                DOWN if ln.startswith("-") and not ln.startswith("---") else AMBER if ln.startswith("@@") else MUTED
            box.add_widget(wlabel(escape_markup(ln[:160]), 10, col))
        content.add_widget(vscroll(box))
        pop = Popup(title="Thay đổi AI đề xuất", content=content, size_hint=(0.97, 0.92), auto_dismiss=False)

        def new_ver(*_):
            path = save_new_version(self.store.bots_dir, self.selected, code)
            pop.dismiss()
            self.refresh_bots(select=path)
            self.select_bot(path)
            self.toast("Đã lưu thành bot mới: %s" % os.path.basename(path))

        def overwrite(*_):
            if not self.selected:
                return
            if self.runner and self.runner.is_alive():
                self.toast("Hãy dừng bot trước khi ghi đè.")
                return
            overwrite_with_backup(self.selected, code)
            pop.dismiss()
            self._info_cache.pop(self.selected, None)
            self.refresh_bots()
            self.select_bot(self.selected)
            self.toast("Đã ghi đè (bản cũ lưu ở .bak).")

        def send_err(*_):
            pop.dismiss()
            hub = self.hub
            if msg["who"] in [a["name"] for a in hub.agents]:
                hub.ask_single(msg["who"], "Code bạn đưa bị lỗi: %s\nHãy sửa và trả lại TOÀN BỘ file." % info)
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss(), size=12))
        if ok:
            row.add_widget(mkbtn("Lưu bản mới", GREEN, on_release=new_ver, size=12))
            row.add_widget(mkbtn("Ghi đè", AMBER, on_release=overwrite, size=12))
        else:
            row.add_widget(mkbtn("Gửi lỗi cho AI", BLUE, on_release=send_err, size=12))
        content.add_widget(row)
        pop.open()
