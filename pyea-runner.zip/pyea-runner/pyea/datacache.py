"""
Cache lịch sử nến trên đĩa + phát hiện/lấp khoảng trống (không import Kivy).

  HistoryCache      lưu nến ĐÃ ĐÓNG theo (sàn, mã, khung) -> khởi động lại chỉ tải phần còn thiếu thay vì tải lại toàn bộ
  merge_candles     gộp theo thời gian (bản mới thắng)
  find_gaps         tìm nến bị thiếu giữa 2 nến liên tiếp (forex OANDA được phép nghỉ cuối tuần/lễ)
  load_history      luồng đầy đủ: cache -> tải phần thiếu -> kiểm tra khoảng trống -> tải lại đủ nếu còn lỗ -> ghi cache
"""
import json
import os
import re
import time

from .feeds import tf_bucket, tf_next, tf_seconds
from .sdk import Candle

MAX_CACHED = 2500


class HistoryCache:
    def __init__(self, directory):
        self.dir = directory

    def path(self, exchange, symbol, tf):
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", "%s_%s_%s" % (exchange, symbol, tf))
        return os.path.join(self.dir, safe + ".json")

    def load(self, exchange, symbol, tf):
        try:
            with open(self.path(exchange, symbol, tf), "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("v") != 1 or d.get("tf") != tf:
                return []
            out = [Candle(*row) for row in d["c"]]
            return sorted(out, key=lambda c: c.time)
        except (OSError, ValueError, TypeError, KeyError):
            return []                       # cache hỏng -> coi như chưa có, tải lại

    def save(self, exchange, symbol, tf, candles):
        try:
            os.makedirs(self.dir, exist_ok=True)
            rows = [[c.time, c.open, c.high, c.low, c.close, c.volume] for c in candles[-MAX_CACHED:]]
            tmp = self.path(exchange, symbol, tf) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"v": 1, "tf": tf, "symbol": symbol, "saved": time.time(), "c": rows}, f, separators=(",", ":"))
            os.replace(tmp, self.path(exchange, symbol, tf))
            return True
        except OSError:
            return False

    def clear(self):
        n = 0
        try:
            for f in os.listdir(self.dir):
                if f.endswith(".json"):
                    os.remove(os.path.join(self.dir, f))
                    n += 1
        except OSError:
            pass
        return n


def merge_candles(old, new):
    """Gộp theo thời gian mở nến; trùng thì lấy bản `new`. Trả về list tăng dần."""
    d = {c.time: c for c in old}
    for c in new:
        d[c.time] = c
    return [d[t] for t in sorted(d)]


def find_gaps(candles, tf, exchange=""):
    """[(t_trước, t_sau, số_nến_thiếu)]. Forex (oanda) được nghỉ tới 3.5 ngày liên tục (cuối tuần/lễ) nên không tính là lỗ."""
    gaps = []
    step = tf_seconds(tf)
    for a, b in zip(candles, candles[1:]):
        exp = tf_next(tf, a.time)
        if b.time <= exp:
            continue
        if tf in ("1mo",):
            missing = 1
        else:
            missing = int(round((b.time - a.time) / step)) - 1
        if missing <= 0:
            continue
        if exchange == "oanda" and (b.time - a.time) <= 3.5 * 86400:
            continue
        gaps.append((a.time, b.time, missing))
    return gaps


def load_history(feed, cache, exchange, symbol, tf, n, now=None):
    """-> (candles, info). `candles` gồm cả nến đang hình thành (nếu nguồn trả về) như feed.history; cache chỉ ghi nến đã đóng.
    info: cached (số nến lấy từ cache), fetched (số nến tải), gaps (số khoảng trống còn lại), refetched (đã tải lại đủ)."""
    now = time.time() if now is None else now
    step = tf_seconds(tf)
    cur_open = tf_bucket(tf, now)
    info = {"cached": 0, "fetched": 0, "gaps": 0, "gap_candles": 0, "refetched": False, "cache_hit": False}
    cached = []
    if cache is not None:
        cached = [c for c in cache.load(exchange, symbol, tf) if c.time < cur_open]
    if len(cached) >= max(10, n // 2):
        need = max(2, min(n, int((cur_open - cached[-1].time) / step) + 2))
        tail = feed.history(symbol, tf, need)
        merged = merge_candles(cached, tail)
        info.update(cached=len(cached), fetched=len(tail), cache_hit=True)
    else:
        merged = feed.history(symbol, tf, n)
        info["fetched"] = len(merged)
    merged = merged[-n:] if len(merged) > n else merged
    closed = [c for c in merged if c.time < cur_open]
    gaps = find_gaps(closed, tf, exchange)
    if (gaps or len(merged) < n * 0.9) and info["cache_hit"]:
        # cache có lỗ hoặc quá ngắn: tải lại đủ rồi gộp để lấp chỗ thiếu
        full = feed.history(symbol, tf, n)
        merged = merge_candles(merged, full)
        merged = merged[-n:] if len(merged) > n else merged
        closed = [c for c in merged if c.time < cur_open]
        gaps = find_gaps(closed, tf, exchange)
        info["refetched"] = True
        info["fetched"] += len(full)
    info["gaps"], info["gap_candles"] = len(gaps), sum(g[2] for g in gaps)
    if cache is not None and closed:
        cache.save(exchange, symbol, tf, closed)
    return merged, info
