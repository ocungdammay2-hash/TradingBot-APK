"""Hỗ trợ AI sửa file bot: trích code từ câu trả lời, kiểm tra (không chạy), so sánh, lưu."""
import ast
import difflib
import os
import re

_FENCE = re.compile(r"```[ \t]*(?:python|py)?[ \t]*\r?\n(.*?)```", re.S | re.I)


def extract_code_blocks(text):
    return [m.group(1).strip("\n") + "\n" for m in _FENCE.finditer(text or "")]


def extract_bot_code(text):
    """Khối code đầu tiên trông giống 1 file bot (có class kế thừa BaseBot)."""
    for code in extract_code_blocks(text):
        if "BaseBot" in code and re.search(r"^\s*class\s+\w+", code, re.M):
            return code
    return None


def check_bot_code(code):
    """Kiểm tra cú pháp + có class kế thừa BaseBot. KHÔNG thực thi code.
    Trả về (ok, thông_báo)."""
    try:
        tree = ast.parse(code)
        compile(code, "<ai-bot>", "exec")
    except SyntaxError as e:
        return False, "Lỗi cú pháp dòng %s: %s" % (e.lineno, e.msg)
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for b in node.bases:
                nm = b.id if isinstance(b, ast.Name) else (b.attr if isinstance(b, ast.Attribute) else "")
                if nm == "BaseBot":
                    return True, "Cú pháp hợp lệ, class: %s" % node.name
    return False, "Không thấy class nào kế thừa BaseBot"


def make_diff(old, new, max_lines=300):
    lines = list(difflib.unified_diff((old or "").splitlines(), (new or "").splitlines(),
                                      "hiện tại", "AI đề xuất", lineterm="", n=2))
    if len(lines) > max_lines:
        lines = lines[:max_lines] + ["... (rút gọn, còn %d dòng)" % (len(lines) - max_lines)]
    return lines


def save_new_version(bots_dir, base_path, code):
    """Lưu thành file mới <tên>_ai.py, <tên>_ai2.py ... Trả về đường dẫn."""
    stem = os.path.splitext(os.path.basename(base_path or "bot.py"))[0]
    stem = re.sub(r"_ai\d*$", "", stem)
    path = os.path.join(bots_dir, stem + "_ai.py")
    i = 2
    while os.path.exists(path):
        path = os.path.join(bots_dir, "%s_ai%d.py" % (stem, i))
        i += 1
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(code)
    return path


def overwrite_with_backup(path, code):
    """Ghi đè file bot, giữ bản cũ ở <file>.bak."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            old = f.read()
        with open(path + ".bak", "w", encoding="utf-8", newline="\n") as f:
            f.write(old)
    except OSError:
        pass
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(code)
    return path
