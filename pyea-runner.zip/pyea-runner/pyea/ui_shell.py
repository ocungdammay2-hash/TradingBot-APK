"""Giao diện cho các tính năng của VỎ (dialog + thanh an toàn). Là mixin của PyEAApp; import ui.py muộn (trong hàm) để tránh vòng import."""
import os
import time
from collections import OrderedDict

from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.utils import escape_markup

from .shell import AlertBook, load_trades_csv, trade_stats
from .ui_widgets import (AMBER, BLUE, DOWN, GREEN, MIN_TOUCH, MUTED, PANEL, PANEL2, RED, TEXT, UP, LineChart, Panel, Table,
                         confirm, flabel, fm, fp, hexc, mkbtn, popup, section, vbox, vscroll, wlabel)

HEALTH_TEXT = {"connected": ("●  Kết nối giá OK", UP), "degraded": ("●  Một số mã MẤT/CŨ giá", AMBER),
               "disconnected": ("●  MẤT KẾT NỐI GIÁ - vỏ chặn lệnh bằng giá cũ", DOWN), "idle": ("●  Chưa theo dõi mã nào", MUTED)}


def fmt_ago(ts):
    if not ts:
        return "-"
    d = time.time() - ts
    return time.strftime("%d/%m %H:%M", time.localtime(ts)) if d > 86400 else ("%.0f giây trước" % d if d < 90 else "%.0f phút trước" % (d / 60))


class SafetyBar(Panel):
    """Thanh trạng thái an toàn trên tab Giao dịch: sức khoẻ kết nối giá, mức ký quỹ, Kill switch / Mở lại giao dịch."""

    def __init__(self, app, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, height=dp(146), padding=dp(6), spacing=dp(3), **kw)
        self.app = app
        self.l_health = flabel("", 12, MUTED, bold=True, size_hint_y=None, height=dp(20))
        self.l_margin = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_recon = flabel("", 11, MUTED, size_hint_y=None, height=dp(20))
        self.l_flag = flabel("", 12, AMBER, bold=True, size_hint_y=None, height=dp(20))
        row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        self.kill = mkbtn("KILL SWITCH", RED, h=40, size=12, on_release=app.kill_switch_dialog)
        self.resume = mkbtn("Mở lại giao dịch", PANEL2, h=40, size=12, on_release=app.resume_trading_action)
        self.resume.disabled = True
        row.add_widget(self.kill)
        row.add_widget(self.resume)
        for w in (self.l_health, self.l_margin, self.l_recon, self.l_flag, row):
            self.add_widget(w)

    def update(self, snap):
        if not snap or not snap.get("ready"):
            self.l_health.text, self.l_health.color = "●  Chưa kết nối phiên", MUTED
            self.l_margin.text = self.l_flag.text = self.l_recon.text = ""
            self.resume.disabled = True
            return
        h = snap.get("health") or {"state": "idle"}
        txt, col = HEALTH_TEXT.get(h.get("state"), HEALTH_TEXT["idle"])
        extra = ""
        if h.get("state") in ("degraded", "disconnected"):
            names = sorted(set(h.get("stale", [])) | set(h.get("failing", [])))
            extra = " (%s)" % ", ".join(names[:4])
        elif h.get("state") == "connected":
            extra = " · giá mới nhất %.0f giây trước" % h.get("max_age", 0)
        self.l_health.text, self.l_health.color = txt + extra, col
        lvl = snap.get("margin_level")
        self.l_margin.text = "Mức ký quỹ: %s · Khả dụng: %s · Giữ cho lệnh chờ: %s" % (
            ("%.0f%%" % lvl) if lvl else "-", fp(snap.get("free_margin", 0)), fp(snap.get("reserved", 0)))
        self.l_margin.color = DOWN if (lvl and lvl < 100) else MUTED
        rc = snap.get("reconcile") or {}
        if not rc.get("supported") and not rc.get("last"):
            self.l_recon.text = ""
        elif rc.get("ok") is False:
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: LỆCH - " + "; ".join(rc.get("issues", [])[:2]), DOWN
        elif rc.get("ok"):
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: khớp (%s)" % fmt_ago(rc.get("last")), UP
        else:
            self.l_recon.text, self.l_recon.color = "Đối soát sàn: chưa lấy được dữ liệu", MUTED
        flags = []
        if snap.get("halted"):
            flags.append("KILL SWITCH ĐANG BẬT - giao dịch bị khoá")
        if snap.get("read_only"):
            flags.append("Chế độ CHỈ-XEM")
        self.l_flag.text = " · ".join(flags)
        self.l_flag.color = DOWN if snap.get("halted") else AMBER
        self.resume.disabled = not snap.get("halted")
        self.resume.background_color = AMBER if snap.get("halted") else PANEL2


class ShellUIMixin:
    # ------------------------------------------------------------------ an toàn
    def kill_switch_dialog(self, *_):
        if not self.is_connected():
            self.toast("Chưa có phiên nào đang chạy.")
            return
        confirm("KILL SWITCH", "Dừng MỌI bot, huỷ mọi lệnh chờ, ĐÓNG mọi vị thế theo giá thị trường và KHOÁ giao dịch cho tới khi bạn "
                "bấm 'Mở lại giao dịch'.\n\nDùng khi có sự cố hoặc thị trường bất thường.",
                lambda: (self.ctl.kill_switch(), self.toast("Đã gửi lệnh Kill switch - xem kết quả ở tab Nhật ký.")), "KÍCH HOẠT", RED)

    def resume_trading_action(self, *_):
        if not self.is_connected():
            return
        confirm("Mở lại giao dịch", "Mở khoá giao dịch sau Kill switch?\nCác bot đã bị dừng sẽ KHÔNG tự chạy lại - hãy bật lại ở tab Bot.",
                lambda: self.ctl.resume_trading(), "Mở lại", GREEN)

    def reset_paper_dialog(self, *_):
        if self.settings["mode"] == "live":
            self.toast("Chỉ đặt lại được tài khoản GIẢ LẬP (paper). Chế độ live dùng số dư thật của sàn.")
            return

        def do():
            if self.is_connected():
                self.ctl.reset_paper()
            else:
                try:
                    os.remove(self.store.state_path)
                except OSError:
                    pass
            self.toast("Đã đặt lại tài khoản giả lập về số dư ban đầu (%s)." % fp(self.settings["initial_balance"]))
        confirm("Đặt lại tài khoản giả lập", "Xoá mọi vị thế, lệnh chờ và đưa số dư về %s?\nLịch sử trades.csv được giữ." % fp(
            self.settings["initial_balance"]), do, "Đặt lại", RED)

    # ------------------------------------------------------------------ lệnh chờ
    def open_pending_dialog(self, oid):
        from . import ui as U
        o = next((x for x in (self.last_snap or {}).get("pending", []) if x.id == oid), None)
        if o is None:
            return
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        price = U.mk_input("%.10g" % o.price)
        sl = U.mk_input(("%.10g" % o.sl) if o.sl else "", "để trống = bỏ SL")
        tp = U.mk_input(("%.10g" % o.tp) if o.tp else "", "để trống = bỏ TP")
        box.add_widget(wlabel("#%d %s %s %.6g %s%s" % (o.id, o.symbol, o.side.upper(), o.volume, o.kind,
                       (" · kích hoạt %s" % fp(o.stop_price)) if o.kind == "stop_limit" else ""), 13, TEXT))
        box.add_widget(U.labeled("Giá đặt" if o.kind != "stop_limit" else "Giá limit", price))
        box.add_widget(U.labeled("Stop Loss", sl))
        box.add_widget(U.labeled("Take Profit", tp))
        msg = wlabel("", 11, MUTED)
        box.add_widget(msg)
        pop = Popup(title="Sửa lệnh chờ", content=box, size_hint=(0.92, 0.62), auto_dismiss=False)

        def ok(*_):
            try:
                p, a, b = U.num(price.text), U.num(sl.text), U.num(tp.text)
            except ValueError as e:
                msg.text, msg.color = str(e), DOWN
                return
            res = self.ctl.modify_order(oid, p, a, b)
            if res is not True and res is not None and not getattr(res, "ok", True):
                msg.text, msg.color = res.message, DOWN
                return
            pop.dismiss()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Huỷ", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Lưu", GREEN, on_release=ok))
        box.add_widget(row)
        pop.open()

    def cancel_pending(self, oid):
        if self.is_connected():
            confirm("Huỷ lệnh chờ", "Huỷ lệnh chờ #%d?" % oid, lambda: self.ctl.cancel_order(oid), "Huỷ lệnh", RED)

    # ------------------------------------------------------------------ cảnh báo giá
    def _alerts_now(self):
        if self.is_connected():
            ses = getattr(self.ctl, "session", None)
            if ses is not None and ses.alerts is not None:
                return ses.alerts.list()
            return list((self.ctl.snapshot() or {}).get("alerts", []))
        return AlertBook(self.store.alerts_path).list()

    def open_alerts_dialog(self, *_):
        from . import ui as U
        connected = self.is_connected()
        syms = self._symbol_choices() or ["BTCUSD"]
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(4))
        pop = Popup(title="Cảnh báo giá", content=box, size_hint=(0.96, 0.92), auto_dismiss=False)
        box.add_widget(vscroll(body))
        KINDS = OrderedDict([("Giá ≥ (vượt lên trên)", "above"), ("Giá ≤ (xuống dưới)", "below"), ("Biến động ±% từ giá hiện tại", "pct")])
        sp_sym = U.mk_spinner(self.chart_sym if self.chart_sym in syms else syms[0], syms)
        sp_kind = U.mk_spinner(list(KINDS)[0], list(KINDS))
        value = U.mk_input("", "giá hoặc %")
        note = U.mk_input("", "ghi chú (tuỳ chọn)")
        sp_rep = U.mk_spinner("Báo 1 lần", ["Báo 1 lần", "Báo lặp lại"])
        msg = wlabel("Cảnh báo chạy cả khi không có bot - app báo bằng thông báo nổi + nhật ký. Cần đang KẾT NỐI để hoạt động." if not connected
                     else "Cảnh báo đang hoạt động trong phiên.", 11, MUTED)

        def rebuild():
            body.clear_widgets()
            items = self._alerts_now()
            body.add_widget(section("CẢNH BÁO (%d)" % len(items)))
            if not items:
                body.add_widget(wlabel("Chưa có cảnh báo nào.", 12, MUTED))
            for a in items:
                row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(4))
                state = "đang chờ" if a.active else "đã báo %s" % fmt_ago(a.fired_at)
                row.add_widget(flabel("%s\n[size=10sp][color=%s]%s%s%s[/color][/size]" % (
                    escape_markup(a.describe()), hexc(UP if a.active else MUTED), state, " · lặp" if a.repeat else "",
                    (" · " + escape_markup(a.note)) if a.note else ""), 12, TEXT, size_hint_x=0.74))
                row.add_widget(mkbtn("Xoá", RED, h=MIN_TOUCH, size=12, size_hint_x=0.26, on_release=lambda *_, i=a.id: remove(i)))
                body.add_widget(row)
            body.add_widget(section("THÊM CẢNH BÁO"))
            for t, w in (("Tài sản", sp_sym), ("Điều kiện", sp_kind), ("Giá trị", value), ("Ghi chú", note), ("Kiểu", sp_rep)):
                body.add_widget(U.labeled(t, w))
            body.add_widget(msg)

        def remove(i):
            if connected:
                self.ctl.alert_remove(i)
            else:
                b = AlertBook(self.store.alerts_path)
                b.remove(i)
            Clock.schedule_once(lambda dt: rebuild(), 0.05 if getattr(self.ctl, "session", None) is not None or not connected else 1.2)

        def add(*_):
            kind = KINDS[sp_kind.text]
            try:
                v = U.num(value.text)
                if v <= 0:
                    raise ValueError("Giá trị phải > 0")
                rep = sp_rep.text == "Báo lặp lại"
                if connected:
                    self.ctl.alert_add(sp_sym.text, kind, v, note.text, rep)
                else:
                    if kind == "pct":
                        raise ValueError("Cảnh báo % cần KẾT NỐI để biết giá hiện tại - hãy dùng 'Giá ≥ / ≤' khi chưa kết nối")
                    AlertBook(self.store.alerts_path).add(sp_sym.text, kind, v, 0.0, note.text, rep)
            except ValueError as e:
                msg.text, msg.color = str(e), DOWN
                return
            value.text = note.text = ""
            msg.text, msg.color = "Đã thêm cảnh báo.", UP
            rebuild() if (getattr(self.ctl, "session", None) is not None or not connected) else Clock.schedule_once(lambda dt: rebuild(), 1.2)
        rebuild()
        row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        row.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        row.add_widget(mkbtn("Thêm cảnh báo", GREEN, on_release=add))
        box.add_widget(row)
        pop.open()

    # ------------------------------------------------------------------ lịch sử & báo cáo
    def open_history_dialog(self, *_):
        trades = sorted(load_trades_csv(self.store.trades_csv), key=lambda t: t.close_time)
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(6))
        body = vbox(spacing=dp(6))
        pop = Popup(title="Lịch sử & báo cáo", content=box, size_hint=(0.97, 0.94), auto_dismiss=False)
        box.add_widget(vscroll(body))
        start = float(self.settings.get("initial_balance") or 0.0)
        if not trades:
            body.add_widget(wlabel("Chưa có lệnh nào đã đóng (file trades.csv còn trống).", 12, MUTED))
            st = trade_stats([], start)
        else:
            st = trade_stats(trades, start)
            pf = st["profit_factor"]
            lines = ["Tổng lệnh: %d · Thắng: %d (%.1f%%) · Thua: %d" % (st["trades"], st["wins"], st["win_rate"], st["losses"]),
                     "Lãi/lỗ ròng: %s · Profit factor: %s" % (fm(st["profit"]), "-" if pf is None else ("∞" if pf == float("inf") else "%.2f" % pf)),
                     "Kỳ vọng/lệnh: %s · Lãi TB: %s · Lỗ TB: %s" % (fm(st["expectancy"]), fm(st["avg_win"]), fm(st["avg_loss"])),
                     "Lãi lớn nhất: %s · Lỗ lớn nhất: %s" % (fm(st["best"]), fm(st["worst"])),
                     "Sụt vốn tối đa: %s (%.2f%% vốn ban đầu)" % (fp(st["max_drawdown"]), st["max_drawdown_pct"])]
            body.add_widget(section("TỔNG QUAN (mọi lệnh đã đóng)"))
            for ln in lines:
                body.add_widget(wlabel(ln, 12, UP if ("ròng" in ln and st["profit"] >= 0) else TEXT))
            cum, curve = 0.0, []
            for t in trades:
                cum += t.profit
                curve.append(cum)
            body.add_widget(section("ĐƯỜNG LÃI/LỖ LUỸ KẾ"))
            ch = LineChart(size_hint_y=None, height=dp(130))
            ch.update(curve, 0.0)
            body.add_widget(ch)
            by = {}
            for t in trades:
                by.setdefault(t.owner or "thủ công", []).append(t)
            body.add_widget(section("THEO TỪNG BOT"))
            tb = Table(["Bot", "Lệnh", "Thắng", "P/L", "PF", "DD"], [1.7, 0.7, 0.9, 1.1, 0.8, 1.0])
            rows = []
            for owner, ts in sorted(by.items(), key=lambda kv: -sum(x.profit for x in kv[1])):
                s2 = trade_stats(ts, start)
                pf2 = s2["profit_factor"]
                rows.append([owner[:16], str(s2["trades"]), "%.0f%%" % s2["win_rate"], (fm(s2["profit"]), UP if s2["profit"] >= 0 else DOWN),
                             "-" if pf2 is None else ("∞" if pf2 == float("inf") else "%.2f" % pf2), fp(s2["max_drawdown"])])
            tb.set_rows(rows)
            body.add_widget(tb)
            body.add_widget(section("30 LỆNH GẦN NHẤT"))
            tl = Table(["Mã", "Loại", "KL", "Vào", "Ra", "P/L", "Nguồn"], [1.2, 0.7, 0.9, 1.1, 1.1, 1.0, 1.1])
            tl.set_rows([[t.symbol, (t.side.upper(), UP if t.side == "buy" else DOWN), "%.6g" % t.volume, fp(t.open_price), fp(t.close_price),
                          (fm(t.profit), UP if t.profit >= 0 else DOWN), "thủ công" if t.owner == "manual" else (t.reason or t.owner)]
                         for t in reversed(trades[-30:])])
            body.add_widget(tl)
        summary = OrderedDict([("Tổng lệnh", st["trades"]), ("Thắng %", round(st["win_rate"], 2)), ("Lãi/lỗ ròng", round(st["profit"], 6)),
                               ("Profit factor", st["profit_factor"]), ("Sụt vốn tối đa", round(st["max_drawdown"], 6))])

        def save(*_):
            try:
                path = self.store.save_statement(trades, summary)
            except OSError as e:
                self.toast("Không lưu được sao kê: %s" % e)
                return
            popup("Đã lưu sao kê", "File CSV:\n%s\n\n(Mở bằng trình quản lý file / Excel; trên Android nằm trong thư mục riêng của app)" % path, size=(0.92, 0.5))

        def copy(*_):
            from .shell import statement_csv
            Clipboard.copy(statement_csv(trades, summary))
            self.toast("Đã sao chép sao kê CSV vào clipboard - dán vào ghi chú/Excel/chat.")
        r = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(6))
        r.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        r.add_widget(mkbtn("Sao chép CSV", PANEL2, on_release=copy))
        r.add_widget(mkbtn("Lưu CSV", GREEN, on_release=save))
        box.add_widget(r)
        pop.open()

    # ------------------------------------------------------------------ sao lưu / khôi phục / chẩn đoán
    def backup_dialog(self, *_):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        box.add_widget(wlabel("Sao lưu: bot (.py), tham số, bộ tham số có tên, cài đặt, chỉ báo/bố cục biểu đồ, cảnh báo giá.\n"
                              "KHÔNG gồm sổ lệnh/nhật ký. Mặc định XOÁ API key/secret/token khỏi file sao lưu.", 12, TEXT))
        pop = Popup(title="Sao lưu", content=box, size_hint=(0.94, 0.55), auto_dismiss=True)

        def do(secrets):
            pop.dismiss()
            try:
                path = self.store.export_backup(include_secrets=secrets)
            except OSError as e:
                self.toast("Không sao lưu được: %s" % e)
                return
            popup("Đã sao lưu", "File:\n%s\n\n%s" % (path, "Có CHỨA API key - giữ cẩn thận." if secrets else "Đã xoá API key khỏi file."), size=(0.94, 0.55))
        box.add_widget(mkbtn("Sao lưu (không kèm API key)", GREEN, on_release=lambda *_: do(False)))
        box.add_widget(mkbtn("Sao lưu KÈM API key", RED, on_release=lambda *_: confirm(
            "Kèm API key?", "File sao lưu sẽ chứa khoá API dạng chữ thường. Ai có file là dùng được khoá. Tiếp tục?", lambda: do(True), "Sao lưu", RED)))
        box.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))
        pop.open()

    def restore_dialog(self, *_):
        if self.is_connected():
            self.toast("Hãy NGẮT kết nối phiên trước khi khôi phục.")
            return
        d = self.store.exports_dir
        try:
            files = sorted((n for n in os.listdir(d) if n.startswith("pyea-backup") and n.endswith(".zip")), reverse=True)
        except OSError:
            files = []
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        body = vbox(spacing=dp(4))
        pop = Popup(title="Khôi phục từ sao lưu", content=box, size_hint=(0.95, 0.8), auto_dismiss=True)
        box.add_widget(wlabel("Chọn một file sao lưu trong thư mục:\n%s\n(chép file .zip sao lưu vào đó nếu bạn chuyển từ máy khác)" % d, 11, MUTED))
        if not files:
            body.add_widget(wlabel("Chưa có file sao lưu nào (pyea-backup-*.zip).", 12, MUTED))
        for n in files[:15]:
            body.add_widget(mkbtn(n, PANEL2, h=MIN_TOUCH, size=12, on_release=lambda *_, name=n: ask(name)))
        box.add_widget(vscroll(body))
        box.add_widget(mkbtn("Đóng", PANEL2, on_release=lambda *_: pop.dismiss()))

        def ask(name):
            confirm("Khôi phục", "Ghi đè bot/tham số/cài đặt hiện có bằng nội dung của\n%s ?\n(API key hiện có được giữ nếu bản sao lưu không chứa khoá)" % name,
                    lambda: run(name), "Khôi phục", RED)

        def run(name):
            try:
                n, warns = self.store.import_backup(os.path.join(d, name))
            except Exception as e:
                popup("Khôi phục thất bại", str(e), size=(0.92, 0.5), color=DOWN)
                return
            pop.dismiss()
            self.settings = self.store.load_settings()
            self.attach_cfgs = self.store.load_instances()
            self.refresh_bots()
            self.settings_tab.build(self.settings)
            popup("Đã khôi phục", "%d file.%s" % (n, ("\nCảnh báo:\n" + "\n".join(warns[:6])) if warns else ""), size=(0.92, 0.5))
        pop.open()

    def diag_bundle_dialog(self, *_):
        snap = self.last_snap or {}
        extra = "status=%s mode=%s exchange=%s halted=%s health=%s\nversion=%s" % (
            snap.get("status"), self.settings.get("mode"), self.settings.get("exchange"), snap.get("halted"),
            (snap.get("health") or {}).get("state"), self._app_version())
        try:
            path = self.store.export_diagnostics(extra)
        except OSError as e:
            self.toast("Không xuất được gói chẩn đoán: %s" % e)
            return
        popup("Gói chẩn đoán", "Đã tạo (không chứa API key):\n%s\n\nGửi file này cho người/AI hỗ trợ khi có lỗi." % path, size=(0.94, 0.55))

    def _app_version(self):
        from . import __version__
        return __version__
