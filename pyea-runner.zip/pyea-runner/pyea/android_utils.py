"""Tiện ích riêng cho Android (pyjnius). Mọi import đều lazy để chạy được trên máy tính."""
import traceback

from kivy.utils import platform

IS_ANDROID = platform == "android"
_REQ_PICK = 4242
_wake_lock = None
_pick_cb = None


def _activity():
    from jnius import autoclass
    return autoclass("org.kivy.android.PythonActivity").mActivity


def external_files_dir():
    """Thư mục riêng của app trên bộ nhớ ngoài (Android/data/<gói>/files) - người dùng lấy file qua USB/trình quản lý file mà KHÔNG cần
    xin quyền bộ nhớ. Trả về None nếu không phải Android hoặc lỗi."""
    if not IS_ANDROID:
        return None
    try:
        d = _activity().getExternalFilesDir(None)
        return str(d.getAbsolutePath()) if d is not None else None
    except Exception:
        return None


# ---------------------------------------------------------------- chọn file (SAF)
def pick_file(callback):
    """Mở bộ chọn file hệ thống (Storage Access Framework, không cần xin quyền bộ nhớ).
    callback(filename, text, error). Đọc nội dung dạng text UTF-8."""
    global _pick_cb
    if not IS_ANDROID:
        callback(None, None, "not_android")
        return
    try:
        from android import activity
        from jnius import autoclass
        Intent = autoclass("android.content.Intent")
        _pick_cb = callback
        activity.bind(on_activity_result=_on_result)
        intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.setType("*/*")
        _activity().startActivityForResult(intent, _REQ_PICK)
    except Exception:
        callback(None, None, traceback.format_exc(limit=3))


def _on_result(request_code, result_code, intent):
    global _pick_cb
    if request_code != _REQ_PICK:
        return
    from android import activity
    try:
        activity.unbind(on_activity_result=_on_result)
    except Exception:
        pass
    cb, _pick_cb = _pick_cb, None
    if cb is None:
        return
    if result_code != -1 or intent is None:      # RESULT_OK = -1
        cb(None, None, "cancelled")
        return
    try:
        from jnius import autoclass
        uri = intent.getData()
        resolver = _activity().getContentResolver()
        name = "bot.py"
        OpenableColumns = autoclass("android.provider.OpenableColumns")
        cur = resolver.query(uri, None, None, None, None)
        if cur is not None:
            try:
                if cur.moveToFirst():
                    idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if idx >= 0:
                        name = cur.getString(idx) or name
            finally:
                cur.close()
        stream = resolver.openInputStream(uri)
        Scanner = autoclass("java.util.Scanner")
        sc = Scanner(stream, "UTF-8").useDelimiter("\\A")
        text = sc.next() if sc.hasNext() else ""
        stream.close()
        cb(name, text, None)
    except Exception:
        cb(None, None, traceback.format_exc(limit=3))


# ---------------------------------------------------------------- giữ máy thức
def set_keep_awake(on):
    """Giữ màn hình sáng + wake lock CPU khi bot chạy. An toàn gọi nhiều lần."""
    global _wake_lock
    if not IS_ANDROID:
        return
    try:
        from android.runnable import run_on_ui_thread
        from jnius import autoclass

        @run_on_ui_thread
        def _flag():
            w = _activity().getWindow()
            if on:
                w.addFlags(128)          # FLAG_KEEP_SCREEN_ON
            else:
                w.clearFlags(128)
        _flag()

        if on and _wake_lock is None:
            Context = autoclass("android.content.Context")
            PowerManager = autoclass("android.os.PowerManager")
            pm = _activity().getSystemService(Context.POWER_SERVICE)
            _wake_lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pyea:runner")
            _wake_lock.acquire()
        elif not on and _wake_lock is not None:
            if _wake_lock.isHeld():
                _wake_lock.release()
            _wake_lock = None
    except Exception:
        pass


def move_to_background():
    """Nút Back: đưa app xuống nền thay vì thoát (để bot không bị tắt nhầm)."""
    if not IS_ANDROID:
        return False
    try:
        _activity().moveTaskToBack(True)
        return True
    except Exception:
        return False
