"""
Gọi API Android bằng pyjnius - KHÔNG import Kivy (dùng được trong cả UI lẫn dịch vụ nền).
Mọi hàm đều an toàn: lỗi -> trả về False/None, không làm sập app.
"""
import os
import traceback

IS_ANDROID = "ANDROID_ARGUMENT" in os.environ or "ANDROID_PRIVATE" in os.environ
SERVICE_NAME = "Botservice"
CH_RUN = "pyea_run"
CH_ALARM = "pyea_alarm"
NOTIF_RUN = 7001
_alarm_seq = [7100]
_locks = {}


def _jnius():
    from jnius import autoclass
    return autoclass


def context():
    """Context hiện tại: Service (trong tiến trình dịch vụ) hoặc Activity (trong UI)."""
    ac = _jnius()
    svc = ac("org.kivy.android.PythonService").mService
    if svc is not None:
        return svc
    return ac("org.kivy.android.PythonActivity").mActivity


def package_name():
    return context().getPackageName()


def files_dir():
    """Thư mục files riêng của app (cùng thư mục cho UI và dịch vụ nền)."""
    try:
        return str(context().getFilesDir().getAbsolutePath())
    except Exception:
        return None


def sdk_int():
    try:
        return int(_jnius()("android.os.Build$VERSION").SDK_INT)
    except Exception:
        return 0


# ------------------------------------------------------------------ dịch vụ
def start_service(argument="", title="PyEA Runner", text="Bot đang chạy nền"):
    """Khởi động dịch vụ foreground (UI gọi). Trả về (ok, lỗi)."""
    if not IS_ANDROID:
        return False, "không phải Android"
    try:
        ac = _jnius()
        cls = ac("%s.Service%s" % (package_name(), SERVICE_NAME))
        act = ac("org.kivy.android.PythonActivity").mActivity
        try:
            cls.start(act, "icon", title, text, argument)
        except Exception:
            cls.start(act, argument)
        return True, ""
    except Exception:
        return False, traceback.format_exc(limit=3)


def stop_service():
    try:
        ac = _jnius()
        ac("%s.Service%s" % (package_name(), SERVICE_NAME)).stop(ac("org.kivy.android.PythonActivity").mActivity)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ thông báo
def _channel(ctx, cid, name, importance, vibrate=False):
    ac = _jnius()
    if sdk_int() < 26:
        return
    NM = ac("android.app.NotificationManager")
    NC = ac("android.app.NotificationChannel")
    ch = NC(cid, name, importance)
    if vibrate:
        ch.enableVibration(True)
    ctx.getSystemService(ac("android.content.Context").NOTIFICATION_SERVICE).createNotificationChannel(ch)


def _builder(ctx, cid):
    ac = _jnius()
    B = ac("android.app.Notification$Builder")
    return B(ctx, cid) if sdk_int() >= 26 else B(ctx)


def _launch_intent(ctx):
    ac = _jnius()
    pm = ctx.getPackageManager()
    intent = pm.getLaunchIntentForPackage(ctx.getPackageName())
    PI = ac("android.app.PendingIntent")
    flags = PI.FLAG_UPDATE_CURRENT | (PI.FLAG_IMMUTABLE if sdk_int() >= 23 else 0)
    return PI.getActivity(ctx, 0, intent, flags)


def set_service_notification(title, text):
    """Cập nhật thông báo foreground của dịch vụ (hiện trên thanh trạng thái). Chạy trong tiến trình dịch vụ."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        svc = ac("org.kivy.android.PythonService").mService
        if svc is None:
            return False
        _channel(svc, CH_RUN, "Bot đang chạy", ac("android.app.NotificationManager").IMPORTANCE_LOW)
        b = _builder(svc, CH_RUN)
        b.setSmallIcon(svc.getApplicationInfo().icon)
        b.setContentTitle(title)
        b.setContentText(text)
        b.setOngoing(True)
        b.setContentIntent(_launch_intent(svc))
        svc.startForeground(NOTIF_RUN, b.build())
        return True
    except Exception:
        return False


def notify_alarm(title, text):
    """Thông báo CẢNH BÁO (rung + âm báo, mức quan trọng cao). Dùng được từ UI hoặc dịch vụ."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = context()
        NM = ac("android.app.NotificationManager")
        _channel(ctx, CH_ALARM, "Cảnh báo bot", NM.IMPORTANCE_HIGH, vibrate=True)
        b = _builder(ctx, CH_ALARM)
        b.setSmallIcon(ctx.getApplicationInfo().icon)
        b.setContentTitle(title)
        b.setContentText(text)
        b.setStyle(ac("android.app.Notification$BigTextStyle")().bigText(text))
        b.setAutoCancel(True)
        b.setContentIntent(_launch_intent(ctx))
        if sdk_int() < 26:
            b.setDefaults(-1)       # Notification.DEFAULT_ALL
            b.setPriority(1)        # PRIORITY_HIGH
        _alarm_seq[0] += 1
        ctx.getSystemService(ac("android.content.Context").NOTIFICATION_SERVICE).notify(_alarm_seq[0], b.build())
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ giữ CPU/Wi-Fi thức
def acquire_wakelocks():
    """Partial wake lock + Wi-Fi lock cho tiến trình dịch vụ (tắt màn hình vẫn lấy giá được)."""
    if not IS_ANDROID or _locks:
        return bool(_locks)
    try:
        ac = _jnius()
        ctx = context()
        Context = ac("android.content.Context")
        pm = ctx.getSystemService(Context.POWER_SERVICE)
        wl = pm.newWakeLock(ac("android.os.PowerManager").PARTIAL_WAKE_LOCK, "pyea:service")
        wl.setReferenceCounted(False)
        wl.acquire()
        _locks["cpu"] = wl
    except Exception:
        pass
    try:
        wm = context().getApplicationContext().getSystemService(ac("android.content.Context").WIFI_SERVICE)
        wf = wm.createWifiLock(3, "pyea:wifi")      # WIFI_MODE_FULL_HIGH_PERF
        wf.setReferenceCounted(False)
        wf.acquire()
        _locks["wifi"] = wf
    except Exception:
        pass
    return bool(_locks)


def release_wakelocks():
    for k, lk in list(_locks.items()):
        try:
            if lk.isHeld():
                lk.release()
        except Exception:
            pass
        _locks.pop(k, None)


# ------------------------------------------------------------------ quyền / pin
def is_ignoring_battery_optimizations():
    if not IS_ANDROID:
        return True
    try:
        ac = _jnius()
        ctx = context()
        pm = ctx.getSystemService(ac("android.content.Context").POWER_SERVICE)
        return bool(pm.isIgnoringBatteryOptimizations(ctx.getPackageName()))
    except Exception:
        return True


def request_ignore_battery_optimizations():
    """Mở hộp thoại hệ thống xin loại app khỏi tối ưu pin (để Android không giết bot nền)."""
    if not IS_ANDROID:
        return False
    try:
        ac = _jnius()
        ctx = ac("org.kivy.android.PythonActivity").mActivity
        Intent = ac("android.content.Intent")
        Uri = ac("android.net.Uri")
        i = Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")
        i.setData(Uri.parse("package:" + ctx.getPackageName()))
        ctx.startActivity(i)
        return True
    except Exception:
        return False


def request_notification_permission():
    """Android 13+: xin quyền hiện thông báo."""
    if not IS_ANDROID or sdk_int() < 33:
        return False
    try:
        from android.permissions import request_permissions
        request_permissions(["android.permission.POST_NOTIFICATIONS"])
        return True
    except Exception:
        return False


def device_info():
    try:
        ac = _jnius()
        B = ac("android.os.Build")
        V = ac("android.os.Build$VERSION")
        abis = ",".join(str(x) for x in B.SUPPORTED_ABIS)
        return {"model": "%s %s" % (B.MANUFACTURER, B.MODEL), "android": str(V.RELEASE), "sdk": int(V.SDK_INT), "abis": abis}
    except Exception:
        return {}
