"""
Chỉ báo kỹ thuật thuần Python (không cần numpy) - dùng:  from pyea import ta

Quy ước: hàm trả về GIÁ TRỊ CUỐI CÙNG, hoặc None nếu chưa đủ dữ liệu.
Hàm *_series trả về list cùng độ dài với đầu vào (None ở đoạn chưa đủ dữ liệu); đầu vào được phép có None Ở ĐẦU.
Nhóm hàm "kiểu MT5" (macd_series, stoch_series, adx_series, sar_series, ichimoku_series, ...) nhận list Candle và dùng đúng
công thức/mặc định của chỉ báo cùng tên trong MetaTrader 5 (vd tín hiệu MACD của MT5 là SMA, không phải EMA).
"""
import math


def _first(values):
    """Chỉ số của giá trị đầu tiên khác None (dữ liệu hợp lệ giả định liên tục từ đó)."""
    for i, v in enumerate(values):
        if v is not None:
            return i
    return len(values)


def sma_series(values, period):
    n = len(values)
    out = [None] * n
    f = _first(values)
    if period <= 0 or n - f < period:
        return out
    s = sum(values[f:f + period])
    out[f + period - 1] = s / period
    for i in range(f + period, n):
        s += values[i] - values[i - period]
        out[i] = s / period
    return out


def sma(values, period):
    if period <= 0 or len(values) < period:
        return None
    return sum(values[-period:]) / period


def ema_series(values, period):
    n = len(values)
    out = [None] * n
    f = _first(values)
    if period <= 0 or n - f < period:
        return out
    k = 2.0 / (period + 1)
    e = sum(values[f:f + period]) / period
    out[f + period - 1] = e
    for i in range(f + period, n):
        e = values[i] * k + e * (1 - k)
        out[i] = e
    return out


def ema(values, period):
    s = ema_series(values, period)
    return s[-1] if s else None


def smma_series(values, period):
    """SMMA (MT5) = RMA của Wilder: giá trị đầu là SMA, sau đó (trước*(n-1)+giá)/n."""
    n = len(values)
    out = [None] * n
    f = _first(values)
    if period <= 0 or n - f < period:
        return out
    e = sum(values[f:f + period]) / period
    out[f + period - 1] = e
    for i in range(f + period, n):
        e = (e * (period - 1) + values[i]) / period
        out[i] = e
    return out


def lwma_series(values, period):
    """LWMA: trung bình có trọng số tuyến tính (nến mới nhất nặng nhất)."""
    n = len(values)
    out = [None] * n
    f = _first(values)
    if period <= 0 or n - f < period:
        return out
    den = period * (period + 1) / 2.0
    for i in range(f + period - 1, n):
        s = 0.0
        for j in range(period):
            s += values[i - period + 1 + j] * (j + 1)
        out[i] = s / den
    return out


MA_METHODS = ["sma", "ema", "smma", "lwma"]


def ma_series(values, period, method="sma"):
    m = (method or "sma").lower()
    if m == "ema":
        return ema_series(values, period)
    if m in ("smma", "rma", "wilder"):
        return smma_series(values, period)
    if m in ("lwma", "wma"):
        return lwma_series(values, period)
    return sma_series(values, period)


def dema_series(values, period):
    e1 = ema_series(values, period)
    e2 = ema_series(e1, period)
    return [(2 * a - b) if (a is not None and b is not None) else None for a, b in zip(e1, e2)]


def tema_series(values, period):
    e1 = ema_series(values, period)
    e2 = ema_series(e1, period)
    e3 = ema_series(e2, period)
    return [(3 * a - 3 * b + c) if (a is not None and b is not None and c is not None) else None
            for a, b, c in zip(e1, e2, e3)]


def rsi_series(values, period=14):
    """RSI theo Wilder (cũng là RSI của MT5)."""
    n = len(values)
    out = [None] * n
    if period <= 0 or n < period + 1:
        return out
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = values[i] - values[i - 1]
        if d >= 0:
            gains += d
        else:
            losses -= d
    avg_g = gains / period
    avg_l = losses / period
    out[period] = _rsi_val(avg_g, avg_l)
    for i in range(period + 1, n):
        d = values[i] - values[i - 1]
        g = d if d > 0 else 0.0
        l = -d if d < 0 else 0.0
        avg_g = (avg_g * (period - 1) + g) / period
        avg_l = (avg_l * (period - 1) + l) / period
        out[i] = _rsi_val(avg_g, avg_l)
    return out


def _rsi_val(avg_g, avg_l):
    if avg_l == 0:
        return 100.0 if avg_g > 0 else 50.0
    rs = avg_g / avg_l
    return 100.0 - 100.0 / (1.0 + rs)


def rsi(values, period=14):
    s = rsi_series(values, period)
    return s[-1] if s else None


def stdev(values, period):
    if period <= 1 or len(values) < period:
        return None
    w = values[-period:]
    m = sum(w) / period
    return math.sqrt(sum((x - m) ** 2 for x in w) / period)


def stdev_series(values, period):
    """Độ lệch chuẩn quần thể (chia N, như MT5) trên cửa sổ trượt."""
    n = len(values)
    out = [None] * n
    f = _first(values)
    if period <= 1 or n - f < period:
        return out
    for i in range(f + period - 1, n):
        w = values[i - period + 1:i + 1]
        m = sum(w) / period
        out[i] = math.sqrt(sum((x - m) ** 2 for x in w) / period)
    return out


def bollinger(values, period=20, mult=2.0):
    """Trả về (giữa, trên, dưới) hoặc None."""
    m = sma(values, period)
    sd = stdev(values, period)
    if m is None or sd is None:
        return None
    return (m, m + mult * sd, m - mult * sd)


def bollinger_series(values, period=20, mult=2.0):
    """(giữa, trên, dưới) - 3 list."""
    mid = sma_series(values, period)
    sd = stdev_series(values, period)
    up = [(m + mult * s) if m is not None and s is not None else None for m, s in zip(mid, sd)]
    lo = [(m - mult * s) if m is not None and s is not None else None for m, s in zip(mid, sd)]
    return mid, up, lo


def atr(candles, period=14):
    """ATR (Wilder) từ list Candle. Trả về None nếu chưa đủ dữ liệu."""
    if period <= 0 or len(candles) < period + 1:
        return None
    trs = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i - 1]
        trs.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
    a = sum(trs[:period]) / period
    for tr in trs[period:]:
        a = (a * (period - 1) + tr) / period
    return a


def highest(values, period):
    if period <= 0 or len(values) < period:
        return None
    return max(values[-period:])


def lowest(values, period):
    if period <= 0 or len(values) < period:
        return None
    return min(values[-period:])


def macd(values, fast=12, slow=26, signal=9):
    """Trả về (macd, signal, histogram) hoặc None."""
    ef = ema_series(values, fast)
    es = ema_series(values, slow)
    line = [(a - b) if (a is not None and b is not None) else None for a, b in zip(ef, es)]
    valid = [x for x in line if x is not None]
    if len(valid) < signal:
        return None
    sig = ema_series(valid, signal)
    if sig[-1] is None:
        return None
    return (valid[-1], sig[-1], valid[-1] - sig[-1])


def crossed_up(a_prev, b_prev, a_now, b_now):
    """a cắt lên b."""
    return a_prev <= b_prev and a_now > b_now


def crossed_down(a_prev, b_prev, a_now, b_now):
    """a cắt xuống b."""
    return a_prev >= b_prev and a_now < b_now


# ==========================================================================
# Nhóm chỉ báo KIỂU MT5 - nhận list Candle (c.open/high/low/close/volume)
# ==========================================================================
PRICE_MODES = ["close", "open", "high", "low", "median", "typical", "weighted"]


def applied_price(candles, mode="close"):
    """Giá áp dụng như MT5: close/open/high/low/median (H+L)/2/typical (H+L+C)/3/weighted (H+L+2C)/4."""
    if mode == "open":
        return [c.open for c in candles]
    if mode == "high":
        return [c.high for c in candles]
    if mode == "low":
        return [c.low for c in candles]
    if mode == "median":
        return [(c.high + c.low) / 2.0 for c in candles]
    if mode == "typical":
        return [(c.high + c.low + c.close) / 3.0 for c in candles]
    if mode == "weighted":
        return [(c.high + c.low + 2 * c.close) / 4.0 for c in candles]
    return [c.close for c in candles]


def _sub(a, b):
    return [(x - y) if (x is not None and y is not None) else None for x, y in zip(a, b)]


def highest_series(values, period):
    n = len(values)
    out = [None] * n
    f = _first(values)
    for i in range(f + period - 1, n):
        out[i] = max(values[i - period + 1:i + 1])
    return out


def lowest_series(values, period):
    n = len(values)
    out = [None] * n
    f = _first(values)
    for i in range(f + period - 1, n):
        out[i] = min(values[i - period + 1:i + 1])
    return out


def true_range(candles):
    """TR từng nến; nến đầu = None (như MT5: ATR bắt đầu từ nến thứ 2)."""
    out = [None] * len(candles)
    for i in range(1, len(candles)):
        c, pc = candles[i], candles[i - 1].close
        out[i] = max(c.high, pc) - min(c.low, pc)
    return out


def atr_series(candles, period=14, method="sma"):
    """ATR. method='sma' (đúng MT5: trung bình đơn giản của TR) hoặc 'wilder' (SMMA, cách cổ điển)."""
    tr = true_range(candles)
    return smma_series(tr, period) if method == "wilder" else sma_series(tr, period)


def macd_series(values, fast=12, slow=26, signal=9, signal_method="sma"):
    """(macd, signal, histogram). MT5: đường tín hiệu là SMA của MACD (signal_method='sma'); cổ điển: 'ema'."""
    line = _sub(ema_series(values, fast), ema_series(values, slow))
    sig = ma_series(line, signal, signal_method)
    return line, sig, _sub(line, sig)


def osma_series(values, fast=12, slow=26, signal=9, signal_method="sma"):
    return macd_series(values, fast, slow, signal, signal_method)[2]


def stoch_series(candles, k=5, d=3, slowing=3, method="sma", price="lowhigh"):
    """Stochastic như MT5: main = tổng(C-LL)/tổng(HH-LL) trên `slowing` nến, signal = MA(main, d).
    price='lowhigh' (mặc định MT5: Low/High) hoặc 'close' (Close/Close)."""
    n = len(candles)
    hi_src = [c.high for c in candles] if price != "close" else [c.close for c in candles]
    lo_src = [c.low for c in candles] if price != "close" else [c.close for c in candles]
    hh = highest_series(hi_src, k)
    ll = lowest_series(lo_src, k)
    num = [None] * n
    den = [None] * n
    for i in range(n):
        if hh[i] is not None:
            num[i] = candles[i].close - ll[i]
            den[i] = hh[i] - ll[i]
    main = [None] * n
    f = _first(num)
    for i in range(f + slowing - 1, n):
        sn = sum(num[i - slowing + 1:i + 1])
        sd = sum(den[i - slowing + 1:i + 1])
        main[i] = 100.0 if sd == 0 else sn / sd * 100.0
    sig = ma_series(main, d, method)
    return main, sig


def adx_series(candles, period=14, smoothing="ema"):
    """(ADX, +DI, -DI). smoothing='ema' (đúng 'Average Directional Movement Index' của MT5, hệ số 2/(n+1))
    hoặc 'wilder' (ADX Wilder cổ điển, hệ số 1/n)."""
    n = len(candles)
    pos = [None] * n
    neg = [None] * n
    tr = [None] * n
    for i in range(1, n):
        c, p = candles[i], candles[i - 1]
        up, dn = c.high - p.high, p.low - c.low
        up, dn = max(up, 0.0), max(dn, 0.0)
        if up > dn:
            dn = 0.0
        elif up < dn:
            up = 0.0
        else:
            up = dn = 0.0
        pos[i], neg[i] = up, dn
        tr[i] = max(c.high, p.close) - min(c.low, p.close)
    sm = smma_series if smoothing == "wilder" else ema_series
    sp, sn, st = sm(pos, period), sm(neg, period), sm(tr, period)
    pdi = [None] * n
    ndi = [None] * n
    dx = [None] * n
    for i in range(n):
        if sp[i] is None or st[i] is None:
            continue
        pdi[i] = 100.0 * sp[i] / st[i] if st[i] else 0.0
        ndi[i] = 100.0 * sn[i] / st[i] if st[i] else 0.0
        s = pdi[i] + ndi[i]
        dx[i] = abs(pdi[i] - ndi[i]) / s * 100.0 if s else 0.0
    return sm(dx, period), pdi, ndi


def cci_series(candles, period=14, price="typical"):
    p = applied_price(candles, price)
    ma = sma_series(p, period)
    out = [None] * len(p)
    for i in range(len(p)):
        if ma[i] is None:
            continue
        md = sum(abs(x - ma[i]) for x in p[i - period + 1:i + 1]) / period
        out[i] = (p[i] - ma[i]) / (0.015 * md) if md else 0.0
    return out


def momentum_series(values, period=14):
    """Momentum như MT5: giá / giá cách `period` nến × 100 (đường trung tâm = 100)."""
    n = len(values)
    out = [None] * n
    for i in range(period, n):
        if values[i - period]:
            out[i] = values[i] / values[i - period] * 100.0
    return out


def roc_series(values, period=12):
    n = len(values)
    out = [None] * n
    for i in range(period, n):
        if values[i - period]:
            out[i] = (values[i] - values[i - period]) / values[i - period] * 100.0
    return out


def wpr_series(candles, period=14):
    """Williams %R (-100..0)."""
    hh = highest_series([c.high for c in candles], period)
    ll = lowest_series([c.low for c in candles], period)
    out = [None] * len(candles)
    for i, c in enumerate(candles):
        if hh[i] is not None:
            out[i] = -50.0 if hh[i] == ll[i] else -100.0 * (hh[i] - c.close) / (hh[i] - ll[i])
    return out


def bulls_bears_series(candles, period=13):
    """(Bulls Power = High - EMA(close), Bears Power = Low - EMA(close))."""
    e = ema_series([c.close for c in candles], period)
    bulls = [(c.high - x) if x is not None else None for c, x in zip(candles, e)]
    bears = [(c.low - x) if x is not None else None for c, x in zip(candles, e)]
    return bulls, bears


def demarker_series(candles, period=14):
    n = len(candles)
    dmax = [None] * n
    dmin = [None] * n
    for i in range(1, n):
        dmax[i] = max(candles[i].high - candles[i - 1].high, 0.0)
        dmin[i] = max(candles[i - 1].low - candles[i].low, 0.0)
    a, b = sma_series(dmax, period), sma_series(dmin, period)
    return [(x / (x + y)) if (x is not None and (x + y) != 0) else (0.5 if x is not None else None) for x, y in zip(a, b)]


def force_series(candles, period=13, method="ema"):
    n = len(candles)
    raw = [None] * n
    for i in range(1, n):
        raw[i] = (candles[i].close - candles[i - 1].close) * candles[i].volume
    return ma_series(raw, period, method)


def mfi_series(candles, period=14):
    n = len(candles)
    tp = [(c.high + c.low + c.close) / 3.0 for c in candles]
    flow = [tp[i] * candles[i].volume for i in range(n)]
    out = [None] * n
    for i in range(period, n):
        pos = neg = 0.0
        for j in range(i - period + 1, i + 1):
            if tp[j] > tp[j - 1]:
                pos += flow[j]
            elif tp[j] < tp[j - 1]:
                neg += flow[j]
        if neg == 0:
            out[i] = 100.0 if pos > 0 else 50.0
        else:
            out[i] = 100.0 - 100.0 / (1.0 + pos / neg)
    return out


def obv_series(candles):
    out = []
    v = 0.0
    for i, c in enumerate(candles):
        if i == 0:
            v = c.volume
        elif c.close > candles[i - 1].close:
            v += c.volume
        elif c.close < candles[i - 1].close:
            v -= c.volume
        out.append(v)
    return out


def ad_series(candles):
    """Accumulation/Distribution."""
    out, v = [], 0.0
    for c in candles:
        r = c.high - c.low
        if r > 0:
            v += ((c.close - c.low) - (c.high - c.close)) / r * c.volume
        out.append(v)
    return out


def ao_series(candles, fast=5, slow=34):
    """Awesome Oscillator = SMA(median, 5) - SMA(median, 34)."""
    m = applied_price(candles, "median")
    return _sub(sma_series(m, fast), sma_series(m, slow))


def ac_series(candles, fast=5, slow=34, smooth=5):
    """Accelerator Oscillator = AO - SMA(AO, 5)."""
    ao = ao_series(candles, fast, slow)
    return _sub(ao, sma_series(ao, smooth))


def rvi_series(candles, period=10):
    """Relative Vigor Index (MT5): (RVI, signal)."""
    n = len(candles)
    num = [None] * n
    den = [None] * n
    for i in range(3, n):
        a = [candles[i - k].close - candles[i - k].open for k in range(4)]
        b = [candles[i - k].high - candles[i - k].low for k in range(4)]
        num[i] = (a[0] + 2 * a[1] + 2 * a[2] + a[3]) / 6.0
        den[i] = (b[0] + 2 * b[1] + 2 * b[2] + b[3]) / 6.0
    sn, sd = sma_series(num, period), sma_series(den, period)
    rvi = [(x / y) if (x is not None and y) else (0.0 if x is not None else None) for x, y in zip(sn, sd)]
    sig = [None] * n
    f = _first(rvi)
    for i in range(f + 3, n):
        sig[i] = (rvi[i] + 2 * rvi[i - 1] + 2 * rvi[i - 2] + rvi[i - 3]) / 6.0
    return rvi, sig


def trix_series(values, period=14):
    e3 = ema_series(ema_series(ema_series(values, period), period), period)
    out = [None] * len(values)
    for i in range(1, len(values)):
        if e3[i] is not None and e3[i - 1]:
            out[i] = (e3[i] - e3[i - 1]) / e3[i - 1]
    return out


def sar_series(candles, step=0.02, maximum=0.2):
    """Parabolic SAR (Wilder). Trả về list cùng độ dài (None ở nến đầu)."""
    n = len(candles)
    out = [None] * n
    if n < 3:
        return out
    long_ = candles[1].close >= candles[0].close
    sar = candles[0].low if long_ else candles[0].high
    ep = candles[1].high if long_ else candles[1].low
    af = step
    out[1] = sar
    for i in range(2, n):
        c = candles[i]
        sar = sar + af * (ep - sar)
        if long_:
            sar = min(sar, candles[i - 1].low, candles[i - 2].low)
            if c.low < sar:                       # đảo chiều xuống
                long_, sar, ep, af = False, ep, c.low, step
            elif c.high > ep:
                ep, af = c.high, min(af + step, maximum)
        else:
            sar = max(sar, candles[i - 1].high, candles[i - 2].high)
            if c.high > sar:                      # đảo chiều lên
                long_, sar, ep, af = True, ep, c.high, step
            elif c.low < ep:
                ep, af = c.low, min(af + step, maximum)
        out[i] = sar
    return out


def ichimoku_series(candles, tenkan=9, kijun=26, senkou_b=52):
    """(tenkan, kijun, senkou_a, senkou_b, chikou) CHƯA dịch chỗ; người vẽ dịch senkou +kijun nến, chikou -kijun nến."""
    hi = [c.high for c in candles]
    lo = [c.low for c in candles]

    def mid(p):
        h, l = highest_series(hi, p), lowest_series(lo, p)
        return [((a + b) / 2.0) if a is not None else None for a, b in zip(h, l)]
    t, k, b = mid(tenkan), mid(kijun), mid(senkou_b)
    a = [((x + y) / 2.0) if (x is not None and y is not None) else None for x, y in zip(t, k)]
    return t, k, a, b, [c.close for c in candles]


def fractals_series(candles):
    """(fractal_up, fractal_down): giá tại nến đỉnh/đáy 5 nến (có 2 nến xác nhận mỗi bên), None ở chỗ khác."""
    n = len(candles)
    up = [None] * n
    dn = [None] * n
    for i in range(2, n - 2):
        h = candles[i].high
        if h > candles[i - 1].high and h > candles[i - 2].high and h > candles[i + 1].high and h > candles[i + 2].high:
            up[i] = h
        l = candles[i].low
        if l < candles[i - 1].low and l < candles[i - 2].low and l < candles[i + 1].low and l < candles[i + 2].low:
            dn[i] = l
    return up, dn


def donchian_series(candles, period=20):
    hh = highest_series([c.high for c in candles], period)
    ll = lowest_series([c.low for c in candles], period)
    mid = [((a + b) / 2.0) if a is not None else None for a, b in zip(hh, ll)]
    return hh, mid, ll


def envelopes_series(values, period=14, method="sma", pct=0.1):
    ma = ma_series(values, period, method)
    k = pct / 100.0
    return ([x * (1 + k) if x is not None else None for x in ma], ma,
            [x * (1 - k) if x is not None else None for x in ma])
