"""
Chỉ báo kỹ thuật thuần Python (không cần numpy) - dùng:  from pyea import ta

Quy ước: hàm trả về GIÁ TRỊ CUỐI CÙNG, hoặc None nếu chưa đủ dữ liệu.
Hàm *_series trả về list cùng độ dài với đầu vào (None ở đoạn chưa đủ dữ liệu).
"""
import math


def sma_series(values, period):
    n = len(values)
    out = [None] * n
    if period <= 0 or n < period:
        return out
    s = sum(values[:period])
    out[period - 1] = s / period
    for i in range(period, n):
        s += values[i] - values[i - period]
        out[i] = s / period
    return out


def sma(values, period):
    if period <= 0 or len(values) < period:
        return None
    return sum(values[-period:]) / period


def ema_series(values, period):
    n = len(values)
    out = [None] * n
    if period <= 0 or n < period:
        return out
    k = 2.0 / (period + 1)
    e = sum(values[:period]) / period
    out[period - 1] = e
    for i in range(period, n):
        e = values[i] * k + e * (1 - k)
        out[i] = e
    return out


def ema(values, period):
    s = ema_series(values, period)
    return s[-1] if s else None


def rsi_series(values, period=14):
    """RSI theo Wilder."""
    n = len(values)
    out = [None] * n
    if period <= 0 or n < period + 1:
        return out
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = values[i] - values[i - 1]
        if d >= 0:
            gains += d
        else:
            losses -= d
    avg_g = gains / period
    avg_l = losses / period
    out[period] = _rsi_val(avg_g, avg_l)
    for i in range(period + 1, n):
        d = values[i] - values[i - 1]
        g = d if d > 0 else 0.0
        l = -d if d < 0 else 0.0
        avg_g = (avg_g * (period - 1) + g) / period
        avg_l = (avg_l * (period - 1) + l) / period
        out[i] = _rsi_val(avg_g, avg_l)
    return out


def _rsi_val(avg_g, avg_l):
    if avg_l == 0:
        return 100.0 if avg_g > 0 else 50.0
    rs = avg_g / avg_l
    return 100.0 - 100.0 / (1.0 + rs)


def rsi(values, period=14):
    s = rsi_series(values, period)
    return s[-1] if s else None


def stdev(values, period):
    if period <= 1 or len(values) < period:
        return None
    w = values[-period:]
    m = sum(w) / period
    return math.sqrt(sum((x - m) ** 2 for x in w) / period)


def bollinger(values, period=20, mult=2.0):
    """Trả về (giữa, trên, dưới) hoặc None."""
    m = sma(values, period)
    sd = stdev(values, period)
    if m is None or sd is None:
        return None
    return (m, m + mult * sd, m - mult * sd)


def atr(candles, period=14):
    """ATR (Wilder) từ list Candle. Trả về None nếu chưa đủ dữ liệu."""
    if period <= 0 or len(candles) < period + 1:
        return None
    trs = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i - 1]
        trs.append(max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close)))
    a = sum(trs[:period]) / period
    for tr in trs[period:]:
        a = (a * (period - 1) + tr) / period
    return a


def highest(values, period):
    if period <= 0 or len(values) < period:
        return None
    return max(values[-period:])


def lowest(values, period):
    if period <= 0 or len(values) < period:
        return None
    return min(values[-period:])


def macd(values, fast=12, slow=26, signal=9):
    """Trả về (macd, signal, histogram) hoặc None."""
    ef = ema_series(values, fast)
    es = ema_series(values, slow)
    line = [(a - b) if (a is not None and b is not None) else None for a, b in zip(ef, es)]
    valid = [x for x in line if x is not None]
    if len(valid) < signal:
        return None
    sig = ema_series(valid, signal)
    if sig[-1] is None:
        return None
    return (valid[-1], sig[-1], valid[-1] - sig[-1])


def crossed_up(a_prev, b_prev, a_now, b_now):
    """a cắt lên b."""
    return a_prev <= b_prev and a_now > b_now


def crossed_down(a_prev, b_prev, a_now, b_now):
    """a cắt xuống b."""
    return a_prev >= b_prev and a_now < b_now
