"""Lưu trữ: thư mục bot, cài đặt chung, tham số theo từng bot (JSON)."""
import json
import os
import re
import shutil
import threading
import time

from .settings import clean_settings, default_settings

_HERE = os.path.dirname(os.path.abspath(__file__))
EXAMPLES_DIR = os.path.join(_HERE, "examples")


class ChatLog:
    """Lịch sử chat dạng JSON-lines, nhiều tiến trình (UI + dịch vụ nền) cùng ghi nối tiếp được."""

    def __init__(self, path):
        self.path = path
        self._lock = threading.Lock()
        self._last_id = 0

    def new_id(self):
        with self._lock:
            now = int(time.time() * 1000000)
            self._last_id = max(self._last_id + 1, now)
            return self._last_id

    def append(self, msg):
        line = json.dumps(msg, ensure_ascii=False) + "\n"
        with self._lock:
            with open(self.path, "ab") as f:
                f.write(line.encode("utf-8"))

    def size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def read_from(self, pos):
        """Đọc các tin mới từ byte offset `pos`. Trả về (list, offset_mới)."""
        try:
            with open(self.path, "rb") as f:
                f.seek(0, 2)
                end = f.tell()
                if pos > end:
                    pos = 0                      # file bị xoá/cắt -> đọc lại từ đầu
                f.seek(pos)
                data = f.read()
        except OSError:
            return [], 0
        out, used = [], 0
        for raw in data.splitlines(True):
            if not raw.endswith(b"\n"):
                break                             # dòng chưa ghi xong
            used += len(raw)
            try:
                out.append(json.loads(raw.decode("utf-8")))
            except ValueError:
                pass
        return out, pos + used

    def tail(self, n=40):
        msgs, _ = self.read_from(0)
        return msgs[-n:]

    def clear(self):
        with self._lock:
            try:
                open(self.path, "wb").close()
            except OSError:
                pass


class Store:
    def __init__(self, base_dir):
        self.base = base_dir
        self.bots_dir = os.path.join(base_dir, "bots")
        self.params_dir = os.path.join(base_dir, "params")
        self.logs_dir = os.path.join(base_dir, "logs")
        for d in (self.bots_dir, self.params_dir, self.logs_dir):
            os.makedirs(d, exist_ok=True)
        self.settings_path = os.path.join(base_dir, "settings.json")
        self.trades_csv = os.path.join(base_dir, "trades.csv")
        self.agents_path = os.path.join(base_dir, "agents.json")
        self.chat = ChatLog(os.path.join(base_dir, "chat.jsonl"))
        self.state_path = os.path.join(base_dir, "session_state.json")
        self.events_path = os.path.join(base_dir, "events.jsonl")
        self.prefs_path = os.path.join(base_dir, "ui_prefs.json")
        self.crash_path = os.path.join(base_dir, "crash.log")

    # ---- JSON helpers ----
    @staticmethod
    def _read(path, default):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default

    @staticmethod
    def _write(path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    # ---- cài đặt chung ----
    def load_settings(self):
        return clean_settings(self._read(self.settings_path, default_settings()))

    def save_settings(self, settings):
        self._write(self.settings_path, settings)

    # ---- AI agents / lịch sử chat ----
    def load_agents(self):
        data = self._read(self.agents_path, [])
        return data if isinstance(data, list) else []

    def save_agents(self, agents):
        self._write(self.agents_path, agents)

    def load_prefs(self):
        d = self._read(self.prefs_path, {})
        return d if isinstance(d, dict) else {}

    def save_prefs(self, prefs):
        self._write(self.prefs_path, prefs)

    # ---- tham số bot ----
    def _params_path(self, bot_file):
        return os.path.join(self.params_dir, os.path.basename(bot_file) + ".json")

    def load_params(self, bot_file):
        return self._read(self._params_path(bot_file), {})

    def save_params(self, bot_file, params):
        self._write(self._params_path(bot_file), params)

    # ---- bot ----
    def list_bots(self):
        try:
            names = sorted(n for n in os.listdir(self.bots_dir) if n.lower().endswith(".py"))
        except OSError:
            names = []
        return [os.path.join(self.bots_dir, n) for n in names]

    @staticmethod
    def safe_name(name):
        name = os.path.basename(name or "bot.py")
        stem, ext = os.path.splitext(name)
        stem = re.sub(r"[^\w\-]+", "_", stem, flags=re.UNICODE).strip("_") or "bot"
        return stem + ".py"

    def install_bot_text(self, filename, text):
        """Lưu nội dung file .py vào thư mục bot. Trả về đường dẫn."""
        path = os.path.join(self.bots_dir, self.safe_name(filename))
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        return path

    def install_bot_file(self, src):
        with open(src, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
        return self.install_bot_text(os.path.basename(src), text)

    def delete_bot(self, path):
        try:
            os.remove(path)
        except OSError:
            pass
        try:
            os.remove(self._params_path(path))
        except OSError:
            pass

    def seed_examples(self, overwrite=False):
        """Chép bot mẫu vào thư mục bot (lần đầu chạy, hoặc khi bấm 'Cài lại mẫu')."""
        if not os.path.isdir(EXAMPLES_DIR):
            return
        # Ví dụ lưu dạng *.py.txt trong gói app (python-for-android có thể bỏ file .py gốc);
        # khi chép ra thư mục bot sẽ đổi lại thành *.py
        for n in sorted(os.listdir(EXAMPLES_DIR)):
            if not n.endswith(".py.txt"):
                continue
            dst = os.path.join(self.bots_dir, n[:-4])
            if overwrite or not os.path.exists(dst):
                shutil.copyfile(os.path.join(EXAMPLES_DIR, n), dst)

    def template_text(self):
        p = os.path.join(EXAMPLES_DIR, "template_bot.py.txt")
        try:
            with open(p, "r", encoding="utf-8") as f:
                return f.read()
        except OSError:
            return ""
