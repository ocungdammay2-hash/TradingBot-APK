"""
PyEA SDK - những gì người viết bot (file .py) cần dùng.

    from pyea import BaseBot, Input, ta

    class MyBot(BaseBot):
        name = "Bot của tôi"
        inputs = {"lot": Input(0.01, "Khối lượng", min=0)}

        def on_tick(self, tick):
            ...

Tương đương MT5:  OnInit -> on_init | OnTick -> on_tick | OnDeinit -> on_deinit
                  `input double Lot=0.01;` -> inputs = {"lot": Input(0.01, ...)}
"""
import math
from dataclasses import dataclass, field
from typing import Optional


# --------------------------------------------------------------------------
# Dữ liệu thị trường / lệnh
# --------------------------------------------------------------------------
@dataclass
class Tick:
    symbol: str
    time: float          # epoch giây (UTC)
    bid: float
    ask: float

    @property
    def mid(self):
        return (self.bid + self.ask) / 2.0

    @property
    def price(self):
        return self.mid


@dataclass
class Candle:
    time: float          # thời điểm MỞ nến (epoch giây, UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class Position:
    id: int
    symbol: str
    side: str            # "buy" | "sell"
    volume: float
    open_price: float
    open_time: float
    sl: float = 0.0      # 0 = không đặt
    tp: float = 0.0      # 0 = không đặt
    comment: str = ""
    fee: float = 0.0     # phí đã trả khi mở
    profit: float = 0.0  # lãi/lỗ thả nổi (đã trừ phí mở)


@dataclass
class Trade:
    """Một lệnh đã đóng."""
    id: int
    symbol: str
    side: str
    volume: float
    open_price: float
    close_price: float
    open_time: float
    close_time: float
    profit: float        # đã trừ phí
    reason: str          # "SL" | "TP" | "Bot" | "Thủ công" | "Dừng bot" ...
    comment: str = ""


@dataclass
class TradeEvent:
    """Một điểm trên biểu đồ: vào lệnh / thoát lệnh / ghi chú tín hiệu - kèm LÝ DO."""
    id: int
    kind: str                 # "open" | "close" | "note"
    time: float               # thời gian thị trường (epoch giây)
    price: float
    side: str = ""            # "buy" | "sell"
    volume: float = 0.0
    pos_id: int = 0
    source: str = "bot"       # bot | ai | sl | tp | manual | risk | stop
    reason: str = ""          # lý do dạng văn bản
    details: dict = field(default_factory=dict)   # điều kiện/thông số kích hoạt (bot ghi)
    context: dict = field(default_factory=dict)   # ảnh chụp tự động: chỉ báo, tham số, nến...
    ai: Optional[dict] = None                     # nếu quyết định dựa trên tín hiệu AI
    profit: float = 0.0       # chỉ có ở "close"
    wall_time: float = 0.0


def jsonable(obj, depth=0):
    """Chuyển bất kỳ giá trị nào thành dạng JSON an toàn (NaN/inf -> None, lạ -> str)."""
    if depth > 6:
        return str(obj)
    if obj is None or isinstance(obj, (bool, int, str)):
        return obj
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {str(k): jsonable(v, depth + 1) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [jsonable(v, depth + 1) for v in obj]
    if hasattr(obj, "__dataclass_fields__"):
        return {k: jsonable(getattr(obj, k), depth + 1) for k in obj.__dataclass_fields__}
    return str(obj)


# --------------------------------------------------------------------------
# Khai báo tham số (giống `input` của MQ5)
# --------------------------------------------------------------------------
_TRUE = {"1", "true", "yes", "on", "co", "có", "y"}
_FALSE = {"0", "false", "no", "off", "khong", "không", "n", ""}


class Input:
    """
    Khai báo 1 tham số để app tự sinh ô nhập trên giao diện.

    Input(default, label=None, min=None, max=None, step=None,
          choices=None, help="", group=None, secret=False)

    Kiểu dữ liệu suy ra từ `default`: bool / int / float / str.
    Nếu có `choices` -> hiện ô chọn (Spinner).
    """

    def __init__(self, default, label=None, min=None, max=None, step=None,
                 choices=None, help="", group=None, secret=False):
        self.default = default
        self.label = label
        self.min = min
        self.max = max
        self.step = step
        self.choices = list(choices) if choices else None
        self.help = help
        self.group = group
        self.secret = secret
        if self.choices:
            self.kind = "choice"
        elif isinstance(default, bool):
            self.kind = "bool"
        elif isinstance(default, int):
            self.kind = "int"
        elif isinstance(default, float):
            self.kind = "float"
        else:
            self.kind = "str"

    def coerce(self, raw):
        """Ép giá trị người dùng nhập về đúng kiểu; sai thì raise ValueError."""
        k = self.kind
        if k == "bool":
            if isinstance(raw, bool):
                return raw
            s = str(raw).strip().lower()
            if s in _TRUE:
                return True
            if s in _FALSE:
                return False
            raise ValueError("phải là bật/tắt")
        if k == "choice":
            for c in self.choices:
                if str(c) == str(raw):
                    return c
            raise ValueError("giá trị không nằm trong danh sách")
        if k == "str":
            return str(raw)
        # số
        try:
            s = str(raw).strip().replace(",", ".")
            f = float(s)
        except (TypeError, ValueError):
            raise ValueError("phải là số")
        if f != f or f in (float("inf"), float("-inf")):
            raise ValueError("phải là số hợp lệ")
        if k == "int":
            if f != int(f):
                raise ValueError("phải là số nguyên")
            val = int(f)
        else:
            val = f
        if self.min is not None and val < self.min:
            raise ValueError("phải ≥ %s" % self.min)
        if self.max is not None and val > self.max:
            raise ValueError("phải ≤ %s" % self.max)
        return val

    def display(self, value):
        """Chuỗi hiển thị trong ô nhập."""
        if self.kind == "bool":
            return bool(value)
        if self.kind == "float":
            return ("%.10g" % float(value))
        return str(value)


class Params(dict):
    """dict nhưng truy cập được bằng dấu chấm: self.p.fast"""

    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError:
            raise AttributeError(key)


# --------------------------------------------------------------------------
# Lớp cha của mọi bot
# --------------------------------------------------------------------------
class BaseBot:
    name = None            # tên hiển thị (mặc định: tên class)
    version = "1.0"
    author = ""
    description = ""
    inputs = {}            # {"tên_tham_số": Input(...)}

    def __init__(self, api, params):
        self.api = api                 # đối tượng giao dịch (xem README)
        self.params = Params(params)
        self.p = self.params           # viết tắt: self.p.fast

    # ---- các hàm sự kiện: ghi đè trong bot của bạn ----
    def on_init(self):
        """Gọi 1 lần khi bot khởi động. Trả về False để huỷ chạy (INIT_FAILED)."""

    def on_tick(self, tick):
        """Gọi mỗi khi có giá mới."""

    def on_bar(self, candle):
        """Gọi khi 1 nến vừa ĐÓNG (candle = nến đã đóng)."""

    def on_deinit(self, reason):
        """Gọi 1 lần khi bot dừng. reason: 'user' | 'error' | 'max_loss' ..."""

    # ---- tiện ích ----
    def log(self, *args):
        self.api.log(*args)
