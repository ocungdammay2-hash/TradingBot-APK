"""
Hạ tầng của VỎ (không phải logic bot) - thuần Python, không import Kivy:

  SymbolSpec / resolve_spec   luật giao dịch từng mã: khối lượng min/max/step, mức dừng tối thiểu, chế độ giao dịch
  validate_volume/stops       kiểm tra + chuẩn hoá TRƯỚC khi gửi sàn (thay vì đợi sàn từ chối)
  AlertBook / PriceAlert      cảnh báo giá (như tab Alerts của MT5): lưu qua restart, chạy kể cả khi không có bot
  trade_stats / bot_metrics   thống kê lệnh (win rate, profit factor, drawdown...) cho từng bot và toàn tài khoản
  connection_health           sức khoẻ kết nối + độ tươi dữ liệu
  statement_csv               sao kê CSV
"""
import csv
import io
import json
import math
import os
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field

TRADE_MODES = ["full", "long_only", "short_only", "close_only", "disabled"]


# ==========================================================================
# Luật giao dịch từng mã
# ==========================================================================
@dataclass
class SymbolSpec:
    symbol: str
    volume_min: float = 0.0
    volume_max: float = 0.0       # 0 = không giới hạn
    volume_step: float = 0.0      # 0 = không ràng buộc
    stop_level_pct: float = 0.0   # khoảng cách tối thiểu SL/TP so với giá, % giá
    trade_mode: str = "full"
    contract_size: float = 1.0
    tick_size: float = 0.0
    digits: int = 5

    def stops_level(self, price):
        return abs(price) * self.stop_level_pct / 100.0


def resolve_spec(settings, symbol, feed=None, broker=None):
    """Gộp luật: mặc định toàn cục (settings) < dữ liệu sàn (feed/broker.symbol_spec nếu có) < ghi đè theo mã
    (settings['symbol_overrides'] dạng JSON, vd {"XAUUSD": {"volume_min": 0.01, "trade_mode": "long_only"}})."""
    s = settings or {}
    d = {"volume_min": float(s.get("min_volume") or 0.0), "volume_max": float(s.get("max_volume") or 0.0),
         "volume_step": float(s.get("volume_step") or 0.0), "stop_level_pct": float(s.get("stop_level_pct") or 0.0)}
    for src in (feed, broker):
        fn = getattr(src, "symbol_spec", None)
        if callable(fn):
            try:
                extra = fn(symbol)
                if isinstance(extra, dict):
                    d.update({k: v for k, v in extra.items() if k in SymbolSpec.__dataclass_fields__})
            except Exception:
                pass
    raw = s.get("symbol_overrides") or ""
    if raw:
        try:
            ov = json.loads(raw) if isinstance(raw, str) else raw
            d.update({k: v for k, v in (ov.get(symbol) or {}).items() if k in SymbolSpec.__dataclass_fields__})
        except (ValueError, AttributeError, TypeError):
            pass
    spec = SymbolSpec(symbol=symbol)
    for k, v in d.items():
        try:
            setattr(spec, k, type(getattr(spec, k))(v))
        except (TypeError, ValueError):
            pass
    if spec.trade_mode not in TRADE_MODES:
        spec.trade_mode = "full"
    return spec


def validate_volume(spec, volume):
    """-> (volume_đã_chuẩn_hoá, lỗi|None). Làm tròn XUỐNG theo step; từ chối dưới min / trên max / không hợp lệ."""
    try:
        v = float(volume)
    except (TypeError, ValueError):
        return 0.0, "Khối lượng không phải số"
    if not math.isfinite(v) or v <= 0:
        return 0.0, "Khối lượng phải > 0"
    if spec.volume_step > 0:
        v = math.floor(v / spec.volume_step + 1e-9) * spec.volume_step
        v = round(v, 10)
    if spec.volume_min > 0 and v < spec.volume_min - 1e-12:
        return v, "Khối lượng %.8g nhỏ hơn mức tối thiểu %.8g (step %.8g)" % (v, spec.volume_min, spec.volume_step)
    if v <= 0:
        return v, "Khối lượng sau khi làm tròn theo step %.8g bằng 0" % spec.volume_step
    if spec.volume_max > 0 and v > spec.volume_max + 1e-12:
        return v, "Khối lượng %.8g vượt mức tối đa %.8g" % (v, spec.volume_max)
    return v, None


def validate_stops(spec, side, price, sl, tp):
    """SL/TP phải đúng phía giá vào và cách giá ít nhất stops_level. -> lỗi|None."""
    lvl = spec.stops_level(price)
    if side == "buy":
        if sl and sl >= price:
            return "SL (%.8g) phải THẤP hơn giá %.8g khi mua" % (sl, price)
        if tp and tp <= price:
            return "TP (%.8g) phải CAO hơn giá %.8g khi mua" % (tp, price)
    else:
        if sl and sl <= price:
            return "SL (%.8g) phải CAO hơn giá %.8g khi bán" % (sl, price)
        if tp and tp >= price:
            return "TP (%.8g) phải THẤP hơn giá %.8g khi bán" % (tp, price)
    if lvl > 0:
        if sl and abs(price - sl) < lvl - 1e-12:
            return "SL cách giá %.8g < mức tối thiểu %.8g (stop level %.3g%%)" % (abs(price - sl), lvl, spec.stop_level_pct)
        if tp and abs(price - tp) < lvl - 1e-12:
            return "TP cách giá %.8g < mức tối thiểu %.8g (stop level %.3g%%)" % (abs(price - tp), lvl, spec.stop_level_pct)
    return None


def mode_allows(spec, side, closing=False):
    """-> lỗi|None. Đóng lệnh luôn được phép trừ khi disabled."""
    m = spec.trade_mode
    if m == "disabled":
        return "Mã %s bị tắt giao dịch (disabled)" % spec.symbol
    if closing or m == "full":
        return None
    if m == "close_only":
        return "Mã %s chỉ cho phép ĐÓNG lệnh (close-only)" % spec.symbol
    if m == "long_only" and side != "buy":
        return "Mã %s chỉ cho phép MUA (long-only)" % spec.symbol
    if m == "short_only" and side != "sell":
        return "Mã %s chỉ cho phép BÁN (short-only)" % spec.symbol
    return None


# ==========================================================================
# Cảnh báo giá
# ==========================================================================
@dataclass
class PriceAlert:
    id: int
    symbol: str
    kind: str                 # "above" | "below" | "pct" (|giá - ref|/ref >= value %)
    value: float
    ref: float = 0.0          # chỉ pct: giá gốc
    note: str = ""
    created: float = 0.0
    fired_at: float = 0.0
    fired_price: float = 0.0
    active: bool = True
    repeat: bool = False      # True: báo lại mỗi lần giá quay lại rồi vượt ngưỡng
    armed: bool = True
    count: int = 0

    def describe(self):
        if self.kind == "pct":
            return "%s biến động ±%.3g%% từ %.8g" % (self.symbol, self.value, self.ref)
        return "%s %s %.8g" % (self.symbol, "≥" if self.kind == "above" else "≤", self.value)


class AlertBook:
    """Sổ cảnh báo giá (lưu JSON). Session gọi check(tick) mỗi tick; kết quả là các cảnh báo vừa kích hoạt."""

    def __init__(self, path=None):
        self.path = path
        self.lock = threading.RLock()
        self.items = OrderedDict()
        self._next = 1
        self.load()

    def load(self):
        if not self.path or not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                d = json.load(f)
            names = set(PriceAlert.__dataclass_fields__)
            with self.lock:
                self.items = OrderedDict()
                for a in d.get("alerts", []):
                    al = PriceAlert(**{k: v for k, v in a.items() if k in names})
                    self.items[al.id] = al
                self._next = max([int(d.get("next", 1))] + [a + 1 for a in self.items])
        except Exception:
            pass

    def save(self):
        if not self.path:
            return
        try:
            with self.lock:
                data = {"next": self._next, "alerts": [{k: getattr(a, k) for k in a.__dataclass_fields__} for a in self.items.values()]}
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def add(self, symbol, kind, value, ref=0.0, note="", repeat=False):
        symbol = str(symbol).strip().upper()
        if kind not in ("above", "below", "pct"):
            raise ValueError("Loại cảnh báo không hợp lệ: %s" % kind)
        value = float(value)
        if not math.isfinite(value) or value <= 0:
            raise ValueError("Giá trị cảnh báo phải > 0")
        if kind == "pct" and float(ref) <= 0:
            raise ValueError("Cảnh báo % cần giá gốc > 0")
        with self.lock:
            a = PriceAlert(id=self._next, symbol=symbol, kind=kind, value=value, ref=float(ref or 0.0), note=str(note)[:120],
                           created=time.time(), repeat=bool(repeat))
            self._next += 1
            self.items[a.id] = a
        self.save()
        return a

    def remove(self, alert_id):
        with self.lock:
            ok = self.items.pop(int(alert_id), None) is not None
        if ok:
            self.save()
        return ok

    def clear_fired(self):
        with self.lock:
            for i in [i for i, a in self.items.items() if not a.active]:
                del self.items[i]
        self.save()

    def symbols(self):
        with self.lock:
            return sorted({a.symbol for a in self.items.values() if a.active})

    def list(self):
        with self.lock:
            return [PriceAlert(**{k: getattr(a, k) for k in a.__dataclass_fields__}) for a in self.items.values()]

    def check(self, tick):
        """Kiểm tra cảnh báo của tick.symbol; trả về list (PriceAlert đã cập nhật, lý do)."""
        fired = []
        px = tick.mid
        with self.lock:
            for a in self.items.values():
                if not a.active or a.symbol != tick.symbol:
                    continue
                if a.kind == "above":
                    hit, rearm = px >= a.value, px < a.value
                elif a.kind == "below":
                    hit, rearm = px <= a.value, px > a.value
                else:
                    move = abs(px - a.ref) / a.ref * 100.0 if a.ref else 0.0
                    hit, rearm = move >= a.value, move < a.value / 2.0
                if not a.armed:
                    if rearm and a.repeat:
                        a.armed = True
                    continue
                if hit:
                    a.fired_at, a.fired_price, a.count = time.time(), px, a.count + 1
                    a.armed = False
                    if not a.repeat:
                        a.active = False
                    elif a.kind == "pct":
                        a.ref = px
                    fired.append((PriceAlert(**{k: getattr(a, k) for k in a.__dataclass_fields__}),
                                  "Cảnh báo giá: %s - giá hiện tại %.8g%s" % (a.describe(), px, (" · " + a.note) if a.note else "")))
        if fired:
            self.save()
        return fired


# ==========================================================================
# Thống kê lệnh
# ==========================================================================
def trade_stats(trades, start_balance=0.0):
    """Thống kê từ list Trade đã đóng (đủ dùng cho từng bot và toàn tài khoản)."""
    n = len(trades)
    wins = [t.profit for t in trades if t.profit > 0]
    losses = [t.profit for t in trades if t.profit < 0]
    gp, gl = sum(wins), -sum(losses)
    cum = peak = dd = 0.0
    for t in sorted(trades, key=lambda x: x.close_time):
        cum += t.profit
        peak = max(peak, cum)
        dd = max(dd, peak - cum)
    total = sum(t.profit for t in trades)
    return {
        "trades": n, "wins": len(wins), "losses": len(losses), "win_rate": (len(wins) / n * 100.0) if n else 0.0,
        "profit": total, "gross_profit": gp, "gross_loss": gl,
        "profit_factor": (gp / gl) if gl > 0 else (None if gp == 0 else float("inf")),
        "avg_win": (gp / len(wins)) if wins else 0.0, "avg_loss": (-gl / len(losses)) if losses else 0.0,
        "best": max((t.profit for t in trades), default=0.0), "worst": min((t.profit for t in trades), default=0.0),
        "expectancy": (total / n) if n else 0.0, "max_drawdown": dd,
        "max_drawdown_pct": (dd / start_balance * 100.0) if start_balance else 0.0,
    }


class CallbackStats:
    """Đo thời gian chạy callback của bot (on_tick/on_bar/...): số lần, trung bình, lớn nhất, lỗi."""

    def __init__(self):
        self.stats = {}
        self.errors = 0
        self.last_error = ""
        self.error_times = []

    def record(self, name, seconds):
        c = self.stats.setdefault(name, [0, 0.0, 0.0])
        c[0] += 1
        c[1] += seconds
        c[2] = max(c[2], seconds)

    def summary(self):
        return {k: {"n": v[0], "avg_ms": v[1] / v[0] * 1000.0 if v[0] else 0.0, "max_ms": v[2] * 1000.0}
                for k, v in self.stats.items()}


# ==========================================================================
# Sức khoẻ kết nối / dữ liệu
# ==========================================================================
def connection_health(symbols, feed_fail, tick_wall, stale_after, now=None):
    """state: connected | degraded | disconnected | idle. stale = mã có giá cũ hơn `stale_after` giây."""
    now = time.time() if now is None else now
    if not symbols:
        return {"state": "idle", "stale": [], "failing": [], "max_age": 0.0}
    stale, failing, ages = [], [], []
    for s in symbols:
        if feed_fail.get(s, 0) > 0:
            failing.append(s)
        w = tick_wall.get(s)
        age = (now - w) if w else None
        if age is not None:
            ages.append(age)
        if stale_after > 0 and (age is None or age > stale_after):
            stale.append(s)
    bad = set(stale) | set(failing)
    if not bad:
        state = "connected"
    elif len(bad) >= len(symbols):
        state = "disconnected"
    else:
        state = "degraded"
    return {"state": state, "stale": sorted(stale), "failing": sorted(failing), "max_age": max(ages) if ages else 0.0}


# ==========================================================================
# Sao kê
# ==========================================================================
def load_trades_csv(path):
    """Đọc trades.csv (mọi lệnh đã đóng từ trước tới nay, cả paper lẫn live) -> list Trade."""
    from .sdk import Trade
    out = []
    try:
        with open(path, "r", encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                try:
                    out.append(Trade(id=int(r["id"]), symbol=r["symbol"], side=r["side"], volume=float(r["volume"]),
                                     open_price=float(r["open_price"]), close_price=float(r["close_price"]),
                                     open_time=float(r["open_time"]), close_time=float(r["close_time"]),
                                     profit=float(r["profit"]), reason=r.get("reason", ""), owner=r.get("owner", "")))
                except (KeyError, ValueError, TypeError):
                    continue
    except OSError:
        pass
    return out


def statement_csv(trades, summary=None):
    """Chuỗi CSV: phần đầu là tóm tắt (nếu có), sau đó từng lệnh đã đóng."""
    out = io.StringIO()
    w = csv.writer(out)
    if summary:
        for k, v in summary.items():
            w.writerow(["#", k, v])
        w.writerow([])
    w.writerow(["bot", "id", "mã", "chiều", "khối lượng", "giá vào", "giá ra", "giờ vào", "giờ ra", "lãi/lỗ", "lý do", "ghi chú"])
    fm = lambda t: time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(t)) if t else ""      # noqa: E731
    for t in trades:
        w.writerow([t.owner, t.id, t.symbol, t.side, t.volume, t.open_price, t.close_price, fm(t.open_time), fm(t.close_time),
                    round(t.profit, 8), t.reason, t.comment])
    return out.getvalue()
