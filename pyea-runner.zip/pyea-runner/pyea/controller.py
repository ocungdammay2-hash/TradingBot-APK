"""LocalController: giao diện điều khiển phiên giao dịch chạy TRỰC TIẾP trong tiến trình app.
ServiceHandle (ipc.py) có cùng phương thức nhưng chạy qua dịch vụ nền -> giao diện không cần biết đang dùng cái nào."""
from .engine import TradingSession


def legacy_view(snap, chart):
    """Gộp snapshot phiên + biểu đồ 1 mã thành dict phẳng cho AI (market_context)."""
    if not snap or not snap.get("ready") or not chart:
        return {"ready": False}
    v = dict(snap)
    v.update({"symbol": chart["symbol"], "timeframe": chart["timeframe"], "candles": chart["candles"],
              "plots": chart["plots"], "bid": chart.get("bid"), "ask": chart.get("ask")})
    v["ready"] = bool(chart.get("bid") is not None and chart["candles"])
    return v


class LocalController:
    kind = "local"

    def __init__(self, session):
        self.session = session
        self.expect_running = True

    # ---- vòng đời ----
    def start(self, config=None):
        self.session.start()

    def stop(self):
        self.expect_running = False
        self.session.stop()

    def is_alive(self):
        return self.session.is_alive() or any(i.is_alive() for i in self.session.instances.values())

    def finished_state(self):
        if self.session.status in ("stopped", "error") and not self.is_alive():
            return self.session.status, self.session.message
        return None

    # ---- dữ liệu ----
    def snapshot(self):
        return self.session.snapshot()

    def set_chart(self, symbol, tf):
        if self.session.chart_req != (symbol, tf):
            self.session.set_chart(symbol, tf)

    def chart(self, symbol, tf, bars=160):
        return self.session.chart(symbol, tf, bars)

    def get_logs(self, after=0):
        return self.session.get_logs(after)

    def events(self):
        with self.session.lock:
            return list(self.session.events)

    def market_view(self, symbol=None, tf=None):
        s = self.session
        if symbol is None and s.instances:
            i = next(iter(s.instances.values()))
            symbol, tf = i.symbol, i.tf
        if symbol is None and s.chart_req:
            symbol, tf = s.chart_req
        return legacy_view(s.snapshot(), s.chart(symbol, tf, 80) if symbol else None)

    # ---- giao dịch thủ công ----
    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment=""):
        p = self.session.place_order(symbol, side, volume, sl, tp, comment)
        return ("ok", p) if p else ("fail", None)

    def close_position(self, pos_id):
        return self.session.close_position(pos_id, "manual", "Người dùng đóng lệnh #%d" % pos_id)

    def request_close_all(self, symbol=None):
        self.session.request_close_all(symbol)

    def modify_position(self, pos_id, sl=None, tp=None):
        return self.session.modify_position(pos_id, sl, tp)

    def set_watch(self, symbols):
        self.session.set_watch(symbols)

    # ---- bot gắn vào tài sản ----
    def attach(self, cfg, start=True):
        inst = self.session.attach(cfg["bot_path"], cfg["symbol"], cfg["tf"], cfg.get("params", {}), iid=cfg["iid"])
        if start:
            inst.start()
        return inst

    def detach(self, iid):
        self.session.detach(iid)

    def inst_start(self, iid):
        i = self.session.instances.get(iid)
        if i is not None and not i.is_alive():
            i.status = "idle"
            i.start()

    def inst_stop(self, iid):
        i = self.session.instances.get(iid)
        if i is not None:
            i.stop()

    # ---- AI ----
    def ai_info(self):
        h = self.session.ai_hub
        if h is None:
            return {}
        return {"auto_on": h.auto_on, "signal": h.get_signal(), "status": h.status_text, "busy": h.busy}

    def set_ai_auto(self, on):
        h = self.session.ai_hub
        if h is not None:
            (h.start_auto if on else h.stop_auto)()

    def alarms(self):
        return []
