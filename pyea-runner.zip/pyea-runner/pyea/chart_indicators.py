"""
Danh mục CHỈ BÁO trên biểu đồ (kiểu MT5: Insert → Indicators). Thuần Python, KHÔNG import Kivy (test được không cần giao diện).

  INDICATORS            OrderedDict[key -> Indicator]   (33 chỉ báo: Xu hướng / Dao động / Khối lượng / Bill Williams)
  new_cfg(key, ci)      tạo cấu hình 1 chỉ báo đưa lên biểu đồ (dict JSON được: lưu vào prefs)
  compute(cfg, candles) tính toán -> {"pane": "main"|"sub", "lines": [...], "fills": [...], "levels", "zero", "vmin", "vmax", "note"}
  describe(cfg)         nhãn ngắn, vd "MA(20,sma)", "RSI(14)", "MACD(12,26,9)"

Mỗi đường (line) là dict: name, v (list cùng độ dài nến, None = chưa có), style, ci (lệch màu), shift (dịch nến, +: sang phải/tương lai),
color (màu cố định, tuỳ chọn), width. Style: line | hist | hist_ud (xanh khi tăng/đỏ khi giảm) | hist_vol (màu theo nến)
| dots | tri_up | tri_down.  Công thức và mặc định theo MetaTrader 5 (xem docstring từng hàm trong indicators.py).
"""
import uuid
from collections import OrderedDict

from . import indicators as ta
from .sdk import Input

# ---------------------------------------------------------------- màu
PALETTE8 = [(0.98, 0.78, 0.22, 1), (0.36, 0.66, 0.98, 1), (0.82, 0.48, 0.96, 1), (0.30, 0.86, 0.82, 1),
            (0.98, 0.58, 0.36, 1), (0.93, 0.93, 0.93, 1), (0.92, 0.32, 0.36, 1), (0.20, 0.78, 0.50, 1)]
COLOR_NAMES = ["auto", "vàng", "xanh dương", "tím", "ngọc", "cam", "trắng", "đỏ", "xanh lá"]
GREEN = (0.20, 0.78, 0.50, 1)
RED = (0.92, 0.32, 0.36, 1)
BLUE = (0.36, 0.66, 0.98, 1)
CLOUD_UP = (0.20, 0.78, 0.50, 0.16)
CLOUD_DN = (0.92, 0.32, 0.36, 0.16)
BAND = (0.36, 0.66, 0.98, 0.10)

GROUPS = ["Xu hướng", "Dao động", "Khối lượng", "Bill Williams"]


def base_color_index(cfg):
    name = str((cfg.get("params") or {}).get("color", "auto"))
    if name in COLOR_NAMES and name != "auto":
        return COLOR_NAMES.index(name) - 1
    return int(cfg.get("ci", 0)) % len(PALETTE8)


def line_color(cfg, line, k=0):
    if line.get("color"):
        return line["color"]
    return PALETTE8[(base_color_index(cfg) + int(line.get("ci", k))) % len(PALETTE8)]


# ---------------------------------------------------------------- khai báo chung
def _L(name, v, style="line", ci=0, shift=0, color=None, width=1.1):
    return {"name": name, "v": v, "style": style, "ci": ci, "shift": shift, "color": color, "width": width}


def _color():
    return ("color", Input("auto", "Màu", choices=COLOR_NAMES, help="auto = tự chọn theo thứ tự thêm"))


def _period(d, label="Chu kỳ", lo=1, hi=500, key="period"):
    return (key, Input(int(d), label, min=lo, max=hi))


def _price(d="close"):
    return ("price", Input(d, "Giá áp dụng", choices=ta.PRICE_MODES))


def _method(d="sma", label="Phương pháp MA", key="method"):
    return (key, Input(d, label, choices=ta.MA_METHODS))


def _shift(d=0):
    return ("shift", Input(int(d), "Dịch (nến)", min=-200, max=200, help="+ dịch sang phải (tương lai), − sang trái"))


class Indicator:
    def __init__(self, key, name, group, pane, params, calc, label_keys=(), levels=(), zero=False, vmin=None, vmax=None,
                 needs_volume=False, desc=""):
        self.key, self.name, self.group, self.pane = key, name, group, pane
        self.inputs = OrderedDict(params + [_color()])
        self.calc, self.label_keys = calc, list(label_keys)
        self.levels, self.zero, self.vmin, self.vmax = list(levels), zero, vmin, vmax
        self.needs_volume, self.desc = needs_volume, desc

    def defaults(self):
        return {k: v.default for k, v in self.inputs.items()}


INDICATORS = OrderedDict()


def _reg(*a, **kw):
    ind = Indicator(*a, **kw)
    INDICATORS[ind.key] = ind
    return ind


def _ap(candles, p):
    return ta.applied_price(candles, p.get("price", "close"))


# ================================================================ XU HƯỚNG (vẽ trên biểu đồ giá)
_reg("ma", "Moving Average (MA)", "Xu hướng", "main",
     [_period(20), _method(), _price(), _shift()],
     lambda cs, p: ([_L("MA", ta.ma_series(_ap(cs, p), p["period"], p["method"]), shift=p["shift"])], []),
     ["period", "method"], desc="Đường trung bình động: SMA, EMA, SMMA hoặc LWMA")
_reg("dema", "Double EMA (DEMA)", "Xu hướng", "main", [_period(14), _price(), _shift()],
     lambda cs, p: ([_L("DEMA", ta.dema_series(_ap(cs, p), p["period"]), shift=p["shift"])], []), ["period"])
_reg("tema", "Triple EMA (TEMA)", "Xu hướng", "main", [_period(14), _price(), _shift()],
     lambda cs, p: ([_L("TEMA", ta.tema_series(_ap(cs, p), p["period"]), shift=p["shift"])], []), ["period"])


def _bb(cs, p):
    mid, up, lo = ta.bollinger_series(_ap(cs, p), p["period"], p["dev"])
    sh = p["shift"]
    return ([_L("Giữa", mid, ci=0, shift=sh), _L("Trên", up, ci=1, shift=sh), _L("Dưới", lo, ci=1, shift=sh)],
            [{"a": 1, "b": 2, "pos": BAND, "neg": BAND}])


_reg("bb", "Bollinger Bands", "Xu hướng", "main",
     [_period(20), ("dev", Input(2.0, "Độ lệch chuẩn (σ)", min=0.1, max=10.0)), _price(), _shift()], _bb, ["period", "dev"])


def _env(cs, p):
    up, mid, lo = ta.envelopes_series(_ap(cs, p), p["period"], p["method"], p["dev"])
    sh = p["shift"]
    return [_L("Trên", up, ci=0, shift=sh), _L("Dưới", lo, ci=1, shift=sh)], []


_reg("env", "Envelopes", "Xu hướng", "main",
     [_period(14), _method(), _price(), ("dev", Input(0.1, "Độ lệch (%)", min=0.001, max=50.0)), _shift()], _env,
     ["period", "method", "dev"])


def _ichi(cs, p):
    t, k, a, b, ch = ta.ichimoku_series(cs, p["tenkan"], p["kijun"], p["senkou"])
    kj = p["kijun"]
    lines = [_L("Tenkan-sen", t, color=(0.92, 0.32, 0.36, 1)), _L("Kijun-sen", k, color=(0.36, 0.66, 0.98, 1)),
             _L("Senkou A", a, shift=kj, color=(0.20, 0.78, 0.50, 0.9), width=1.0),
             _L("Senkou B", b, shift=kj, color=(0.92, 0.32, 0.36, 0.9), width=1.0),
             _L("Chikou", ch, shift=-kj, color=(0.55, 0.95, 0.35, 0.9), width=1.0)]
    return lines, [{"a": 2, "b": 3, "pos": CLOUD_UP, "neg": CLOUD_DN}]


_reg("ichimoku", "Ichimoku Kinko Hyo", "Xu hướng", "main",
     [("tenkan", Input(9, "Tenkan-sen", min=1, max=200)), ("kijun", Input(26, "Kijun-sen", min=1, max=200)),
      ("senkou", Input(52, "Senkou Span B", min=1, max=400))], _ichi, ["tenkan", "kijun", "senkou"],
     desc="Mây Ichimoku: Senkou dịch +Kijun nến, Chikou dịch −Kijun nến")
_reg("sar", "Parabolic SAR", "Xu hướng", "main",
     [("step", Input(0.02, "Bước (step)", min=0.001, max=1.0)), ("maximum", Input(0.2, "Tối đa (max)", min=0.01, max=2.0))],
     lambda cs, p: ([_L("SAR", ta.sar_series(cs, p["step"], p["maximum"]), style="dots", ci=0)], []), ["step", "maximum"])


_reg("donchian", "Kênh Donchian", "Xu hướng", "main", [_period(20)],
     lambda cs, p: (lambda r: ([_L("Cao nhất", r[0], ci=0), _L("Giữa", r[1], ci=2, width=0.8), _L("Thấp nhất", r[2], ci=0)],
                               [{"a": 0, "b": 2, "pos": BAND, "neg": BAND}]))(ta.donchian_series(cs, p["period"])),
     ["period"], desc="Cao nhất / thấp nhất N nến (không phải chỉ báo gốc MT5 nhưng rất phổ biến)")


def _adxi(cs, p):
    adx, pdi, ndi = ta.adx_series(cs, p["period"], p["smoothing"])
    return [_L("ADX", adx, ci=0, width=1.4), _L("+DI", pdi, color=GREEN, width=0.9), _L("-DI", ndi, color=RED, width=0.9)], []


# ================================================================ DAO ĐỘNG (cửa sổ phụ)
_reg("rsi", "RSI", "Dao động", "sub", [_period(14), _price()],
     lambda cs, p: ([_L("RSI", ta.rsi_series(_ap(cs, p), p["period"]))], []), ["period"],
     levels=[30, 70], vmin=0, vmax=100)


def _macd(cs, p):
    line, sig, hist = ta.macd_series(_ap(cs, p), p["fast"], p["slow"], p["signal"], p["signal_method"])
    return [_L("MACD", line, style="hist", ci=1), _L("Signal", sig, ci=6, width=1.0)], []


_reg("macd", "MACD", "Dao động", "sub",
     [("fast", Input(12, "EMA nhanh", min=1, max=200)), ("slow", Input(26, "EMA chậm", min=2, max=400)),
      ("signal", Input(9, "Tín hiệu", min=1, max=200)), _price(),
      _method("sma", "Đường tín hiệu", key="signal_method")], _macd, ["fast", "slow", "signal"], zero=True,
     desc="Giống MT5: đường tín hiệu là SMA của MACD (đổi sang ema nếu muốn kiểu cổ điển)")


def _stoch(cs, p):
    k, d = ta.stoch_series(cs, p["k"], p["d"], p["slowing"], p["method"], p["field"])
    return [_L("%K", k, ci=0), _L("%D", d, ci=6, width=1.0)], []


_reg("stoch", "Stochastic Oscillator", "Dao động", "sub",
     [("k", Input(5, "%K", min=1, max=200)), ("d", Input(3, "%D", min=1, max=100)),
      ("slowing", Input(3, "Làm chậm", min=1, max=100)), _method("sma", "Phương pháp MA"),
      ("field", Input("lowhigh", "Giá", choices=["lowhigh", "close"], help="lowhigh = Low/High (mặc định MT5); close = Close/Close"))],
     _stoch, ["k", "d", "slowing"], levels=[20, 80], vmin=0, vmax=100)
_reg("adx", "Average Directional Index (ADX)", "Dao động", "sub",
     [_period(14), ("smoothing", Input("ema", "Làm mượt", choices=["ema", "wilder"],
                                       help="ema = ADX của MT5; wilder = ADX Wilder cổ điển"))], _adxi, ["period"], levels=[20], vmin=0)
_reg("cci", "Commodity Channel Index (CCI)", "Dao động", "sub", [_period(14), _price("typical")],
     lambda cs, p: ([_L("CCI", ta.cci_series(cs, p["period"], p["price"]))], []), ["period"], levels=[-100, 100], zero=True)
_reg("atr", "Average True Range (ATR)", "Dao động", "sub",
     [_period(14), ("method", Input("sma", "Cách tính", choices=["sma", "wilder"], help="sma = ATR của MT5; wilder = cổ điển"))],
     lambda cs, p: ([_L("ATR", ta.atr_series(cs, p["period"], p["method"]))], []), ["period"])
_reg("momentum", "Momentum", "Dao động", "sub", [_period(14), _price()],
     lambda cs, p: ([_L("Momentum", ta.momentum_series(_ap(cs, p), p["period"]))], []), ["period"], levels=[100])
_reg("wpr", "Williams' Percent Range", "Dao động", "sub", [_period(14)],
     lambda cs, p: ([_L("%R", ta.wpr_series(cs, p["period"]))], []), ["period"], levels=[-20, -80], vmin=-100, vmax=0)
_reg("roc", "Rate of Change (ROC)", "Dao động", "sub", [_period(12), _price()],
     lambda cs, p: ([_L("ROC", ta.roc_series(_ap(cs, p), p["period"]))], []), ["period"], zero=True)
_reg("osma", "Moving Average of Oscillator (OsMA)", "Dao động", "sub",
     [("fast", Input(12, "EMA nhanh", min=1, max=200)), ("slow", Input(26, "EMA chậm", min=2, max=400)),
      ("signal", Input(9, "Tín hiệu", min=1, max=200)), _price(), _method("sma", "Đường tín hiệu", key="signal_method")],
     lambda cs, p: ([_L("OsMA", ta.osma_series(_ap(cs, p), p["fast"], p["slow"], p["signal"], p["signal_method"]), style="hist", ci=3)], []),
     ["fast", "slow", "signal"], zero=True)


def _bulls(cs, p):
    bu, be = ta.bulls_bears_series(cs, p["period"])
    return [_L("Bulls", bu, style="hist", color=GREEN)], []


def _bears(cs, p):
    bu, be = ta.bulls_bears_series(cs, p["period"])
    return [_L("Bears", be, style="hist", color=RED)], []


_reg("bulls", "Bulls Power", "Dao động", "sub", [_period(13)], _bulls, ["period"], zero=True)
_reg("bears", "Bears Power", "Dao động", "sub", [_period(13)], _bears, ["period"], zero=True)
_reg("demarker", "DeMarker", "Dao động", "sub", [_period(14)],
     lambda cs, p: ([_L("DeM", ta.demarker_series(cs, p["period"]))], []), ["period"], levels=[0.3, 0.7], vmin=0, vmax=1)
_reg("force", "Force Index", "Dao động", "sub", [_period(13), _method("ema")],
     lambda cs, p: ([_L("Force", ta.force_series(cs, p["period"], p["method"]))], []), ["period", "method"], zero=True,
     needs_volume=True)
_reg("rvi", "Relative Vigor Index (RVI)", "Dao động", "sub", [_period(10)],
     lambda cs, p: (lambda r: ([_L("RVI", r[0]), _L("Signal", r[1], ci=6, width=1.0)], []))(ta.rvi_series(cs, p["period"])),
     ["period"], zero=True)
_reg("trix", "Triple Exponential Average (TRIX)", "Dao động", "sub", [_period(14), _price()],
     lambda cs, p: ([_L("TRIX", ta.trix_series(_ap(cs, p), p["period"]))], []), ["period"], zero=True)
_reg("stddev", "Standard Deviation", "Dao động", "sub", [_period(20), _price()],
     lambda cs, p: ([_L("StdDev", ta.stdev_series(_ap(cs, p), p["period"]))], []), ["period"])

# ================================================================ KHỐI LƯỢNG
_reg("volumes", "Volumes", "Khối lượng", "sub", [],
     lambda cs, p: ([_L("Vol", [c.volume for c in cs], style="hist_vol")], []), [], needs_volume=True, vmin=0)
_reg("mfi", "Money Flow Index (MFI)", "Khối lượng", "sub", [_period(14)],
     lambda cs, p: ([_L("MFI", ta.mfi_series(cs, p["period"]))], []), ["period"], levels=[20, 80], vmin=0, vmax=100,
     needs_volume=True)
_reg("obv", "On Balance Volume (OBV)", "Khối lượng", "sub", [],
     lambda cs, p: ([_L("OBV", ta.obv_series(cs))], []), [], needs_volume=True)
_reg("ad", "Accumulation/Distribution", "Khối lượng", "sub", [],
     lambda cs, p: ([_L("A/D", ta.ad_series(cs))], []), [], needs_volume=True)

# ================================================================ BILL WILLIAMS
_reg("ao", "Awesome Oscillator (AO)", "Bill Williams", "sub", [],
     lambda cs, p: ([_L("AO", ta.ao_series(cs), style="hist_ud")], []), [], zero=True)
_reg("ac", "Accelerator Oscillator (AC)", "Bill Williams", "sub", [],
     lambda cs, p: ([_L("AC", ta.ac_series(cs), style="hist_ud")], []), [], zero=True)


def _alligator(cs, p):
    m = ta.applied_price(cs, p["price"])
    jaw = ta.ma_series(m, p["jaw"], p["method"])
    teeth = ta.ma_series(m, p["teeth"], p["method"])
    lips = ta.ma_series(m, p["lips"], p["method"])
    return [_L("Hàm (Jaw)", jaw, shift=p["jaw_shift"], color=(0.30, 0.52, 1.0, 1)),
            _L("Răng (Teeth)", teeth, shift=p["teeth_shift"], color=RED),
            _L("Môi (Lips)", lips, shift=p["lips_shift"], color=GREEN)], []


_reg("alligator", "Alligator", "Bill Williams", "main",
     [("jaw", Input(13, "Chu kỳ Jaw", min=1, max=200)), ("jaw_shift", Input(8, "Dịch Jaw", min=0, max=100)),
      ("teeth", Input(8, "Chu kỳ Teeth", min=1, max=200)), ("teeth_shift", Input(5, "Dịch Teeth", min=0, max=100)),
      ("lips", Input(5, "Chu kỳ Lips", min=1, max=200)), ("lips_shift", Input(3, "Dịch Lips", min=0, max=100)),
      _method("smma"), _price("median")], _alligator, ["jaw", "teeth", "lips"])


def _fractals(cs, p):
    up, dn = ta.fractals_series(cs)
    return [_L("Fractal ▲", up, style="tri_down", color=RED), _L("Fractal ▼", dn, style="tri_up", color=GREEN)], []


_reg("fractals", "Fractals", "Bill Williams", "main", [], _fractals, [],
     desc="Đỉnh/đáy 5 nến (cần 2 nến xác nhận nên không có ở 2 nến mới nhất)")


# ---------------------------------------------------------------- API
def new_cfg(key, ci=0):
    ind = INDICATORS[key]
    return {"uid": uuid.uuid4().hex[:8], "key": key, "params": ind.defaults(), "visible": True, "ci": int(ci) % len(PALETTE8)}


def clean_cfgs(raw):
    """Đọc danh sách cấu hình từ prefs: bỏ chỉ báo lạ, ép tham số về đúng kiểu (hỏng -> mặc định)."""
    out, seen = [], set()
    for c in raw or []:
        if not isinstance(c, dict) or c.get("key") not in INDICATORS:
            continue
        ind = INDICATORS[c["key"]]
        params = {}
        for k, inp in ind.inputs.items():
            try:
                params[k] = inp.coerce((c.get("params") or {}).get(k, inp.default))
            except ValueError:
                params[k] = inp.default
        uid = str(c.get("uid") or uuid.uuid4().hex[:8])
        if uid in seen:
            uid = uuid.uuid4().hex[:8]
        seen.add(uid)
        out.append({"uid": uid, "key": c["key"], "params": params, "visible": bool(c.get("visible", True)),
                    "ci": int(c.get("ci", 0)) % len(PALETTE8)})
    return out


_SHORT = {"bb": "BB", "env": "Env", "ichimoku": "Ichimoku", "sar": "SAR", "donchian": "Donchian", "stoch": "Stoch",
          "force": "Force", "momentum": "Mom", "wpr": "%R", "demarker": "DeM", "volumes": "Vol", "alligator": "Alligator",
          "fractals": "Fractals", "stddev": "StdDev", "bulls": "Bulls", "bears": "Bears", "adx": "ADX", "ad": "A/D"}


def short_name(key):
    if key in _SHORT:
        return _SHORT[key]
    name = INDICATORS[key].name
    return name[name.rindex("(") + 1:name.rindex(")")] if "(" in name else name


def describe(cfg):
    """Nhãn ngắn, vd 'MA(20,sma)', 'RSI(14)', 'MACD(12,26,9)'."""
    ind = INDICATORS[cfg["key"]]
    p = cfg.get("params") or {}
    vals = []
    for k in ind.label_keys:
        v = p.get(k, ind.inputs[k].default)
        vals.append(("%g" % v) if isinstance(v, float) else str(v))
    return "%s(%s)" % (short_name(cfg["key"]), ",".join(vals)) if vals else short_name(cfg["key"])


def title(cfg):
    """Tên đầy đủ + tham số (hiện trong danh sách chỉ báo)."""
    ind = INDICATORS[cfg["key"]]
    p = cfg.get("params") or {}
    shown = ", ".join("%s=%s" % (ind.inputs[k].label or k, p.get(k, ind.inputs[k].default)) for k in ind.label_keys)
    return "%s%s" % (ind.name, (" · " + shown) if shown else "")


def compute(cfg, candles):
    """Tính 1 chỉ báo trên toàn bộ nến. Không bao giờ ném lỗi (lỗi -> kết quả rỗng kèm ghi chú)."""
    ind = INDICATORS[cfg["key"]]
    res = {"ind": ind, "pane": ind.pane, "lines": [], "fills": [], "levels": ind.levels, "zero": ind.zero,
           "vmin": ind.vmin, "vmax": ind.vmax, "note": ""}
    if not candles:
        return res
    p = {}
    for k, inp in ind.inputs.items():
        try:
            p[k] = inp.coerce((cfg.get("params") or {}).get(k, inp.default))
        except ValueError:
            p[k] = inp.default
    if ind.needs_volume and not any(c.volume for c in candles):
        res["note"] = "nguồn giá không có khối lượng"
        return res
    try:
        lines, fills = ind.calc(candles, p)
    except Exception as e:        # chỉ báo hỏng không được làm sập biểu đồ
        res["note"] = "lỗi tính: %s" % e
        return res
    res["lines"], res["fills"] = lines, fills
    return res


def sub_axis_range(res, lo_i, hi_i):
    """(min, max) hiển thị của cửa sổ phụ trên đoạn nến [lo_i, hi_i) có tính dịch chỗ; ưu tiên khoảng cố định (RSI 0..100...)."""
    vals = []
    for ln in res["lines"]:
        sh = ln["shift"]
        for g in range(max(0, lo_i - sh), min(len(ln["v"]), hi_i - sh)):
            v = ln["v"][g]
            if v is not None:
                vals.append(v)
    if not vals:
        return None
    lo, hi = min(vals), max(vals)
    if res["zero"] or any(ln["style"].startswith("hist") for ln in res["lines"]):
        lo, hi = min(lo, 0.0), max(hi, 0.0)
    for lv in res["levels"]:
        lo, hi = min(lo, lv), max(hi, lv)
    fix_lo, fix_hi = res["vmin"] is not None, res["vmax"] is not None
    if fix_lo:
        lo = res["vmin"]
    if fix_hi:
        hi = res["vmax"]
    if hi <= lo:
        hi, lo = lo + 1.0, lo - 1.0
    pad = (hi - lo) * 0.08
    return (lo if fix_lo else lo - pad), (hi if fix_hi else hi + pad)
