"""
Chạy nền: dịch vụ (ServiceHost) chạy BotRunner trong tiến trình riêng; giao diện (ServiceHandle)
giao tiếp qua các file JSON trong <data>/ipc/ (không cần thư viện ngoài, không phụ thuộc Kivy).

  UI  --cmd/*.json-->  Host      lệnh: start | stop | close_all | ai_auto | ping
  UI  <--state.json--  Host      ảnh chụp trạng thái (publish 1s khi UI đang mở, 10s khi UI ở nền)
  UI  <--events.jsonl- Host      điểm vào/ra lệnh kèm lý do (đọc nối tiếp theo offset)
      host.hb                    host chạm file này liên tục -> UI biết dịch vụ còn sống
      desired.json               "bot đang được yêu cầu chạy" -> dùng để TỰ KHÔI PHỤC sau crash
"""
import json
import os
import threading
import time
import traceback
import uuid

from .ai import AIHub
from .controller import legacy_view
from .engine import STATUS_TEXT, TradingSession, _atomic_write, _mk
from .loader import build_params, inspect_bot
from .sdk import Candle, PendingOrder, Position, Trade, TradeEvent, jsonable
from .shell import PriceAlert
from .storage import ChatLog, Store

HB_FRESH = 8.0          # giây: host được coi là còn sống nếu host.hb mới hơn mức này
PENDING_GRACE = 25.0    # giây chờ host nhận lệnh start


# --------------------------------------------------------------------------
# (de)serialize snapshot
# --------------------------------------------------------------------------
def snapshot_to_json(snap, chart=None):
    d = jsonable(snap)
    if chart:
        c = jsonable(chart)
        c.pop("events", None)                 # sự kiện đọc từ events.jsonl
        # nến dạng mảng [t,o,h,l,c,v] (gọn ~2 lần so với dict) - state.json ghi mỗi giây nên cần nhỏ
        c["candles"] = [[x["time"], x["open"], x["high"], x["low"], x["close"], x["volume"]] for x in c.get("candles", [])]
        d["chart"] = c
    return d


def _chart_from_json(c):
    if not c:
        return None
    c = dict(c)
    c["candles"] = [Candle(*x) if isinstance(x, (list, tuple)) else _mk(Candle, x) for x in c.get("candles", [])]
    c["positions"] = [_mk(Position, p) for p in c.get("positions", [])]
    c["pending"] = [_mk(PendingOrder, o) for o in c.get("pending", [])]
    c["plots"] = {n: [(p[0], p[1]) for p in pts] for n, pts in c.get("plots", {}).items()}
    c["events"] = []
    return c


def snapshot_from_json(d):
    if not d:
        return None
    s = dict(d)
    s["positions"] = [_mk(Position, p) for p in d.get("positions", [])]
    s["trades"] = [_mk(Trade, t) for t in d.get("trades", [])]
    s["pending"] = [_mk(PendingOrder, o) for o in d.get("pending", [])]
    s["alerts"] = [_mk(PriceAlert, a) for a in d.get("alerts", [])]
    s["chart"] = _chart_from_json(d.get("chart"))
    return s


def notification_text(snap):
    """(tiêu đề, nội dung) cho thông báo trên thanh trạng thái."""
    if not snap:
        return "PyEA Runner", "Đang chờ phiên giao dịch..."
    inst = snap.get("instances", [])
    run = [i for i in inst if i.get("status") == "running"]
    title = "PyEA • %d bot đang chạy" % len(run) if inst else "PyEA • giao dịch thủ công"
    if not snap.get("ready"):
        return title, snap.get("status_text", "")
    return title, "%s · %s · Equity %s (%+.2f%%) · %d lệnh mở" % (
        snap["status_text"], snap["mode"].upper(), "{:,.2f}".format(snap["equity"]), snap["pnl_pct"], len(snap["positions"]))


# --------------------------------------------------------------------------
# Client (dùng ở cả 2 phía)
# --------------------------------------------------------------------------
class ServiceClient:
    def __init__(self, data_dir):
        self.dir = os.path.join(data_dir, "ipc")
        self.cmd_dir = os.path.join(self.dir, "cmd")
        os.makedirs(self.cmd_dir, exist_ok=True)
        self.state_path = os.path.join(self.dir, "state.json")
        self.desired_path = os.path.join(self.dir, "desired.json")
        self.host_hb = os.path.join(self.dir, "host.hb")
        self.ui_hb = os.path.join(self.dir, "ui.hb")
        self._seq = 0

    # ---- lệnh ----
    def send(self, cmd, **kw):
        self._seq += 1
        name = "%017d_%04d.json" % (int(time.time() * 1e6), self._seq)
        _atomic_write(os.path.join(self.cmd_dir, name), json.dumps(dict(kw, cmd=cmd, t=time.time()), ensure_ascii=False))

    def pop_commands(self):
        out = []
        try:
            names = sorted(n for n in os.listdir(self.cmd_dir) if n.endswith(".json"))
        except OSError:
            return out
        for n in names:
            p = os.path.join(self.cmd_dir, n)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    out.append(json.load(f))
            except Exception:
                pass
            try:
                os.remove(p)
            except OSError:
                pass
        return out

    # ---- trạng thái ----
    def write_state(self, d):
        _atomic_write(self.state_path, json.dumps(d, ensure_ascii=False, separators=(",", ":")))

    def read_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def read_desired(self):
        try:
            with open(self.desired_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def write_desired(self, d):
        _atomic_write(self.desired_path, json.dumps(d, ensure_ascii=False))

    # ---- heartbeat ----
    @staticmethod
    def _touch(path):
        with open(path, "a"):
            pass
        os.utime(path, None)

    def touch_host(self):
        self._touch(self.host_hb)

    def touch_ui(self):
        self._touch(self.ui_hb)

    @staticmethod
    def _age(path):
        try:
            return time.time() - os.path.getmtime(path)
        except OSError:
            return 1e9

    def host_alive(self, max_age=HB_FRESH):
        return self._age(self.host_hb) < max_age

    def ui_age(self):
        return self._age(self.ui_hb)

    def remove_host_hb(self):
        try:
            os.remove(self.host_hb)
        except OSError:
            pass


# --------------------------------------------------------------------------
# Handle phía UI: cùng giao diện với LocalController
# --------------------------------------------------------------------------
class ServiceHandle:
    kind = "service"

    def __init__(self, client, events_path, token=None, pending=False):
        self.client = client
        self.token = token or uuid.uuid4().hex
        self._pending_since = time.time() if pending else 0.0
        self._state = None
        self._snap = None
        self._snap_pub = None
        self.events_log = ChatLog(events_path)
        self._ev_pos = 0
        self._events = []
        self._chart_sent = None
        self.expect_running = pending

    @classmethod
    def attach_running(cls, client, events_path):
        """Gắn vào phiên đang chạy nền (nếu có) khi mở lại app."""
        st = client.read_state()
        if st and st.get("session_alive") and client.host_alive():
            h = cls(client, events_path, token=st.get("token"))
            h.expect_running = True
            return h
        return None

    # ---- vòng đời ----
    def start(self, config):
        self.client.send("session_start", config=dict(config, token=self.token))
        self._pending_since = time.time()
        self.expect_running = True
        self._ev_pos, self._events = 0, []

    def stop(self):
        self.expect_running = False
        self.client.send("session_stop", token=self.token)

    def _refresh(self):
        st = self.client.read_state()
        if st:
            self._state = st
        return self._state

    def _mine(self, st):
        return st is not None and st.get("token") == self.token

    def pending(self):
        return bool(self._pending_since) and (time.time() - self._pending_since) < PENDING_GRACE

    def is_alive(self):
        st = self._refresh()
        if self._mine(st):
            return bool(st.get("session_alive")) and self.client.host_alive()
        return self.pending()

    def crashed(self):
        st = self._refresh()
        return self._mine(st) and bool(st.get("session_alive")) and not self.client.host_alive()

    def failed_to_start(self):
        st = self._refresh()
        return (not self._mine(st)) and bool(self._pending_since) and not self.pending() and not self.client.host_alive()

    def finished_state(self):
        st = self._refresh()
        if self._mine(st) and not st.get("session_alive"):
            return st.get("status"), st.get("message", "")
        return None

    # ---- dữ liệu ----
    def snapshot(self):
        st = self._refresh()
        if not self._mine(st):
            return None
        if st.get("pub") != self._snap_pub:
            self._snap_pub = st.get("pub")
            self._snap = snapshot_from_json(st.get("snapshot"))
        return self._snap

    def set_chart(self, symbol, tf):
        if self._chart_sent != (symbol, tf):
            self._chart_sent = (symbol, tf)
            self.client.send("chart", symbol=symbol, tf=tf)

    def chart(self, symbol, tf, bars=None):
        snap = self.snapshot()
        c = (snap or {}).get("chart")
        if c and c["symbol"] == symbol and c["timeframe"] == tf:
            return c
        return None

    def get_logs(self, after=0):
        st = self._refresh()
        if not self._mine(st):
            return []
        return [tuple(x) for x in st.get("logs", []) if x[0] > after]

    def events(self):
        msgs, newpos = self.events_log.read_from(self._ev_pos)
        if newpos < self._ev_pos:
            self._events = []
        self._ev_pos = newpos
        for m in msgs:
            self._events.append(_mk(TradeEvent, m))
        del self._events[:-600]
        return list(self._events)

    def market_view(self, symbol=None, tf=None):
        snap = self.snapshot()
        return legacy_view(snap, (snap or {}).get("chart"))

    # ---- giao dịch thủ công (bất đồng bộ: kết quả thấy ở Giao dịch / Nhật ký) ----
    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment=""):
        self.client.send("order", symbol=symbol, side=side, volume=volume, sl=sl, tp=tp, comment=comment)
        return ("sent", None)

    def place_pending(self, symbol, side, kind, volume, price, stop_price=0.0, sl=0.0, tp=0.0, comment="", expiration=0.0):
        self.client.send("pending", symbol=symbol, side=side, kind=kind, volume=volume, price=price, stop_price=stop_price,
                         sl=sl, tp=tp, comment=comment, expiration=expiration)
        return ("sent", None)

    def cancel_order(self, order_id):
        self.client.send("cancel_order", order_id=order_id)
        return True

    def modify_order(self, order_id, price=None, sl=None, tp=None, expiration=None):
        self.client.send("modify_order", order_id=order_id, price=price, sl=sl, tp=tp, expiration=expiration)
        return True

    def close_position(self, pos_id, volume=None):
        self.client.send("close", pos_id=pos_id, volume=volume)
        return True

    def request_close_all(self, symbol=None):
        self.client.send("close_all", symbol=symbol)

    # ---- an toàn ----
    def kill_switch(self, reason="Người dùng bấm Kill switch"):
        self.client.send("kill", reason=reason)

    def resume_trading(self):
        self.client.send("resume")

    def reset_paper(self):
        self.client.send("reset_paper")

    # ---- cảnh báo giá ----
    def alert_add(self, symbol, kind, value, note="", repeat=False):
        self.client.send("alert_add", symbol=symbol, kind=kind, value=value, note=note, repeat=repeat)
        return True

    def alert_remove(self, alert_id):
        self.client.send("alert_remove", alert_id=alert_id)
        return True

    def modify_position(self, pos_id, sl=None, tp=None):
        self.client.send("modify", pos_id=pos_id, sl=sl, tp=tp)
        return True

    def set_watch(self, symbols):
        self.client.send("watch", symbols=list(symbols))

    # ---- bot gắn vào tài sản ----
    def attach(self, cfg, start=True):
        self.client.send("attach", cfg=dict(cfg), start=bool(start))

    def detach(self, iid):
        self.client.send("detach", iid=iid)

    def set_params(self, iid, params):
        self.client.send("params", iid=iid, params=dict(params))
        return True

    def inst_start(self, iid):
        self.client.send("inst_start", iid=iid)

    def inst_stop(self, iid):
        self.client.send("inst_stop", iid=iid)

    # ---- AI ----
    def ai_info(self):
        st = self._refresh()
        return (st or {}).get("ai") or {}

    def set_ai_auto(self, on):
        self.client.send("ai_auto", on=bool(on))

    def alarms(self):
        st = self._refresh()
        return (st or {}).get("alarms") or []


# --------------------------------------------------------------------------
# Host (chạy trong dịch vụ nền)
# --------------------------------------------------------------------------
class ServiceHost:
    def __init__(self, data_dir, alarm=None, set_notification=None, sleep=0.25, exit_grace=6.0, idle_exit=20.0):
        self.data_dir = data_dir
        self.store = Store(data_dir)
        self.client = ServiceClient(data_dir)
        self.alarm_fn = alarm
        self.set_notification = set_notification
        self.sleep = sleep
        self.exit_grace = exit_grace
        self.idle_exit = idle_exit
        self.session = None
        self.hub = None
        self.config = None
        self.settings = {}
        self.token = None
        self.alarms = []
        self._pub = 0
        self._last_pub = 0.0
        self._last_notif = 0.0
        self._finished_at = None
        self._idle_since = time.time()
        self._exit = False

    # ---- cảnh báo ----
    def alarm(self, title, text):
        self.alarms.append({"t": time.time(), "title": title, "text": text})
        del self.alarms[:-20]
        if self.alarm_fn:
            try:
                self.alarm_fn(title, text)
            except Exception:
                pass

    # ---- AI hub ----
    def _hub_snapshot(self):
        s = self.session
        if s is None:
            return None
        i = next(iter(s.instances.values()), None)
        sym, tf = (i.symbol, i.tf) if i else (s.chart_req or (None, None))
        return legacy_view(s.snapshot(), s.chart(sym, tf, 80) if sym else None)

    def _hub_bot(self):
        s = self.session
        i = next(iter(s.instances.values()), None) if s else None
        if i is None:
            return None
        info = inspect_bot(i.bot_path)
        try:
            with open(i.bot_path, "r", encoding="utf-8") as f:
                src = f.read()
        except OSError:
            return None
        params = build_params(info.inputs, i.params) if info.ok else {}
        return (info.name if info.ok else i.iid, src, params)

    # ---- phiên ----
    def _save_desired(self, running=True):
        d = self.client.read_desired() or {}
        d["running"] = running
        if self.config is not None:
            d["config"] = self.config
        self.client.write_desired(d)

    def start_session(self, config):
        if self.session is not None and self.session.is_alive():
            self.session.stop(wait=True)
        self.config = config
        self.settings = config["settings"]
        self.token = config["token"]
        resume = bool(config.get("resume"))
        if not resume:                      # phiên mới: xoá sổ lệnh + sự kiện của phiên cũ
            try:
                os.remove(self.store.state_path)
            except OSError:
                pass
            try:
                open(self.store.events_path, "w").close()
            except OSError:
                pass
        self.hub = AIHub(self.store, self._hub_snapshot, self._hub_bot, lambda: self.settings)
        self.session = TradingSession(
            self.settings, log_file=config.get("log_file"), trades_csv=config.get("trades_csv"),
            state_file=self.store.state_path, events_file=self.store.events_path, resume=resume, alerts_file=self.store.alerts_path,
            alarm_cb=self.alarm, notify_cb=lambda t, x: self._post_notification(t, x), ai_hub=self.hub)
        self.session.interval_override = None
        for cfg in config.get("instances", []):
            self._attach(cfg, cfg.get("running", True), save=False)
        self.session.start()
        self._finished_at = None
        self._save_desired(True)
        if config.get("ai_auto"):
            self.hub.start_auto()
        self._publish(force=True)

    def _attach(self, cfg, start, save=True):
        inst = self.session.attach(cfg["bot_path"], cfg["symbol"], cfg["tf"], cfg.get("params", {}), iid=cfg["iid"])
        if start:
            inst.start()
        if save and self.config is not None:
            lst = [c for c in self.config.get("instances", []) if c["iid"] != cfg["iid"]]
            self.config["instances"] = lst + [dict(cfg, running=bool(start))]
            self._save_desired(True)

    def _set_running(self, iid, running):
        for c in (self.config or {}).get("instances", []):
            if c["iid"] == iid:
                c["running"] = running
        self._save_desired(True)

    def _post_notification(self, title, text):
        if self.set_notification:
            try:
                self.set_notification(title, text)
            except Exception:
                pass

    def _consume(self):
        for c in self.client.pop_commands():
            cmd, s = c.get("cmd"), self.session
            try:
                if cmd == "session_start":
                    self.start_session(c["config"])
                elif s is None:
                    continue
                elif cmd == "session_stop" and c.get("token") in (None, self.token):
                    s.stop()
                    for i in list(s.instances.values()):
                        i.stop()
                elif cmd == "order":
                    s.place_order(c["symbol"], c["side"], c["volume"], c.get("sl", 0), c.get("tp", 0), c.get("comment", ""))
                elif cmd == "pending":
                    s.place_pending(c["symbol"], c["side"], c["kind"], c["volume"], c["price"], c.get("stop_price", 0), c.get("sl", 0),
                                    c.get("tp", 0), c.get("comment", ""), "manual", c.get("expiration", 0), "Đặt lệnh chờ thủ công từ ứng dụng")
                elif cmd == "cancel_order":
                    s.cancel_order(int(c["order_id"]), "manual", "Người dùng huỷ lệnh chờ #%s" % c["order_id"])
                elif cmd == "modify_order":
                    s.modify_order(int(c["order_id"]), c.get("price"), c.get("sl"), c.get("tp"), c.get("expiration"))
                elif cmd == "kill":
                    s.request_kill(c.get("reason") or "Người dùng bấm Kill switch")
                    for x in (self.config or {}).get("instances", []):
                        x["running"] = False                 # để lần resume sau KHÔNG tự bật lại các bot đã bị Kill
                    self._save_desired(True)
                elif cmd == "resume":
                    s._cmds.put(("resume",))
                elif cmd == "reset_paper":
                    s._cmds.put(("reset_paper",))
                elif cmd == "alert_add":
                    s.alert_add(c["symbol"], c["kind"], c["value"], c.get("note", ""), bool(c.get("repeat")))
                elif cmd == "alert_remove":
                    s.alert_remove(int(c["alert_id"]))
                elif cmd == "close":
                    s.close_position(int(c["pos_id"]), "manual", "Người dùng đóng lệnh #%s" % c["pos_id"], volume=c.get("volume"))
                elif cmd == "close_all":
                    s.request_close_all(c.get("symbol"))
                elif cmd == "modify":
                    s.modify_position(int(c["pos_id"]), c.get("sl"), c.get("tp"))
                elif cmd == "watch":
                    s.set_watch(c.get("symbols", []))
                elif cmd == "chart":
                    s.set_chart(c["symbol"], c["tf"])
                elif cmd == "attach":
                    self._attach(c["cfg"], c.get("start", True))
                elif cmd == "detach":
                    s.detach(c["iid"])
                    self.config["instances"] = [x for x in self.config.get("instances", []) if x["iid"] != c["iid"]]
                    self._save_desired(True)
                elif cmd == "params" and c["iid"] in s.instances:
                    s.instances[c["iid"]].apply_params(c["params"])
                    for x in (self.config or {}).get("instances", []):
                        if x["iid"] == c["iid"]:
                            x["params"] = dict(c["params"])
                    self._save_desired(True)
                elif cmd == "inst_start" and c["iid"] in s.instances:
                    i = s.instances[c["iid"]]
                    if not i.is_alive():
                        i.status = "idle"
                        i.start()
                    self._set_running(c["iid"], True)
                elif cmd == "inst_stop" and c["iid"] in s.instances:
                    s.instances[c["iid"]].stop()
                    self._set_running(c["iid"], False)
                elif cmd == "ai_auto" and self.hub:
                    (self.hub.start_auto if c.get("on") else self.hub.stop_auto)()
            except Exception:
                self.alarm("Lỗi dịch vụ nền", traceback.format_exc(limit=2).strip().splitlines()[-1])

    def _maybe_resume(self):
        """Khởi động lại sau crash/bị hệ thống giết: phiên đang 'cần chạy' -> chạy lại + khôi phục sổ lệnh."""
        if self.session is not None:
            return
        d = self.client.read_desired()
        if not d or not d.get("running") or not d.get("config"):
            return
        cfg = dict(d["config"])
        if not cfg.get("settings", {}).get("auto_resume", True):
            d["running"] = False
            self.client.write_desired(d)
            return
        now = time.time()
        restarts = [t for t in d.get("restarts", []) if now - t < 300]
        if len(restarts) >= 3:
            d["running"], d["restarts"] = False, restarts
            self.client.write_desired(d)
            self.alarm("Dịch vụ crash liên tục", "Đã tự khởi động lại 3 lần trong 5 phút. Phiên KHÔNG được chạy lại - hãy mở app kiểm tra.")
            return
        restarts.append(now)
        d["restarts"] = restarts
        self.client.write_desired(d)
        cfg["resume"] = True
        self.alarm("Phiên được khôi phục sau sự cố", "Dịch vụ nền bị dừng đột ngột và đã tự chạy lại (khôi phục sổ lệnh và các bot).")
        self.start_session(cfg)

    # ---- publish ----
    def _publish(self, force=False, phase="running"):
        now = time.time()
        visible = self.client.ui_age() < 5.0
        every = 1.0 if visible else 10.0
        if not force and now - self._last_pub < every:
            return
        self._last_pub = now
        self._pub += 1
        st = {"pub": self._pub, "hb": now, "pid": os.getpid(), "phase": phase, "token": self.token,
              "ui_visible": visible, "alarms": self.alarms[-20:], "session_alive": False,
              "status": "idle", "message": "", "snapshot": None, "logs": [], "ai": {}}
        s = self.session
        if s is not None:
            st["session_alive"] = s.is_alive()
            st["status"], st["message"] = s.status, s.message
            chart = s.chart(*s.chart_req, bars=int(s.settings.get("chart_bars", 400))) if s.chart_req else None
            st["snapshot"] = snapshot_to_json(s.snapshot(), chart)
            st["logs"] = [list(x) for x in s.get_logs(0)[-150:]]
        if self.hub is not None:
            st["ai"] = {"auto_on": self.hub.auto_on, "signal": jsonable(self.hub.get_signal()),
                        "status": self.hub.status_text, "busy": self.hub.busy}
        self.client.write_state(st)

    def _update_notification(self, force=False):
        now = time.time()
        if not force and now - self._last_notif < 12.0:
            return
        self._last_notif = now
        if self.session is not None and self.set_notification:
            t, x = notification_text(self.session.snapshot())
            self._post_notification(t, x)

    # ---- vòng chính ----
    def run(self):
        self.client.touch_host()
        self._consume()
        self._maybe_resume()
        try:
            while not self._exit:
                self.client.touch_host()
                self._consume()
                s = self.session
                if s is not None:
                    visible = self.client.ui_age() < 5.0
                    s.interval_override = 3.0 if (self.settings.get("power_mode") == "saver" and not visible) else None
                    if not s.is_alive() and self._finished_at is None:
                        self._finished_at = time.time()
                        self._save_desired(False)
                        if self.hub:
                            self.hub.stop_auto()
                        self._publish(force=True, phase="exiting")
                        self._update_notification(force=True)
                    elif s.is_alive():
                        self._idle_since = time.time()
                        self._publish()
                        self._update_notification()
                    if self._finished_at and time.time() - self._finished_at > self.exit_grace:
                        self._exit = True
                elif time.time() - self._idle_since > self.idle_exit:
                    self._exit = True
                time.sleep(self.sleep)
        finally:
            try:
                self._publish(force=True, phase="exited")
            finally:
                self.client.remove_host_hb()
