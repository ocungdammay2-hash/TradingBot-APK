"""
Chạy nền: dịch vụ (ServiceHost) chạy BotRunner trong tiến trình riêng; giao diện (ServiceHandle)
giao tiếp qua các file JSON trong <data>/ipc/ (không cần thư viện ngoài, không phụ thuộc Kivy).

  UI  --cmd/*.json-->  Host      lệnh: start | stop | close_all | ai_auto | ping
  UI  <--state.json--  Host      ảnh chụp trạng thái (publish 1s khi UI đang mở, 10s khi UI ở nền)
  UI  <--events.jsonl- Host      điểm vào/ra lệnh kèm lý do (đọc nối tiếp theo offset)
      host.hb                    host chạm file này liên tục -> UI biết dịch vụ còn sống
      desired.json               "bot đang được yêu cầu chạy" -> dùng để TỰ KHÔI PHỤC sau crash
"""
import json
import os
import threading
import time
import traceback
import uuid

from .ai import AIHub
from .engine import STATUS_TEXT, BotRunner, _atomic_write, _mk
from .loader import build_params, inspect_bot
from .sdk import Candle, Position, Trade, TradeEvent, jsonable
from .storage import ChatLog, Store

HB_FRESH = 8.0          # giây: host được coi là còn sống nếu host.hb mới hơn mức này
PENDING_GRACE = 25.0    # giây chờ host nhận lệnh start


# --------------------------------------------------------------------------
# (de)serialize snapshot
# --------------------------------------------------------------------------
def snapshot_to_json(snap, drop_events=True):
    d = jsonable(snap)
    if drop_events:
        d.pop("events", None)
    return d


def snapshot_from_json(d):
    if not d:
        return None
    s = dict(d)
    s["candles"] = [_mk(Candle, c) for c in d.get("candles", [])]
    s["positions"] = [_mk(Position, p) for p in d.get("positions", [])]
    s["trades"] = [_mk(Trade, t) for t in d.get("trades", [])]
    s["plots"] = {n: [(p[0], p[1]) for p in pts] for n, pts in d.get("plots", {}).items()}
    s.setdefault("events", [])
    return s


def notification_text(snap):
    """(tiêu đề, nội dung) cho thông báo trên thanh trạng thái."""
    if not snap:
        return "PyEA Runner", "Đang chờ bot..."
    title = "PyEA • %s • %s %s" % (snap.get("bot", "?"), snap.get("symbol", "?"), snap.get("timeframe", ""))
    if not snap.get("ready"):
        return title, snap.get("status_text", "")
    return title, "%s · %s · Equity %s (%+.2f%%) · %d lệnh mở" % (
        snap["status_text"], snap["mode"].upper(), "{:,.2f}".format(snap["equity"]), snap["pnl_pct"],
        len(snap["positions"]))


# --------------------------------------------------------------------------
# Client (dùng ở cả 2 phía)
# --------------------------------------------------------------------------
class ServiceClient:
    def __init__(self, data_dir):
        self.dir = os.path.join(data_dir, "ipc")
        self.cmd_dir = os.path.join(self.dir, "cmd")
        os.makedirs(self.cmd_dir, exist_ok=True)
        self.state_path = os.path.join(self.dir, "state.json")
        self.desired_path = os.path.join(self.dir, "desired.json")
        self.host_hb = os.path.join(self.dir, "host.hb")
        self.ui_hb = os.path.join(self.dir, "ui.hb")
        self._seq = 0

    # ---- lệnh ----
    def send(self, cmd, **kw):
        self._seq += 1
        name = "%017d_%04d.json" % (int(time.time() * 1e6), self._seq)
        _atomic_write(os.path.join(self.cmd_dir, name), json.dumps(dict(kw, cmd=cmd, t=time.time()), ensure_ascii=False))

    def pop_commands(self):
        out = []
        try:
            names = sorted(n for n in os.listdir(self.cmd_dir) if n.endswith(".json"))
        except OSError:
            return out
        for n in names:
            p = os.path.join(self.cmd_dir, n)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    out.append(json.load(f))
            except Exception:
                pass
            try:
                os.remove(p)
            except OSError:
                pass
        return out

    # ---- trạng thái ----
    def write_state(self, d):
        _atomic_write(self.state_path, json.dumps(d, ensure_ascii=False))

    def read_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def read_desired(self):
        try:
            with open(self.desired_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def write_desired(self, d):
        _atomic_write(self.desired_path, json.dumps(d, ensure_ascii=False))

    # ---- heartbeat ----
    @staticmethod
    def _touch(path):
        with open(path, "a"):
            pass
        os.utime(path, None)

    def touch_host(self):
        self._touch(self.host_hb)

    def touch_ui(self):
        self._touch(self.ui_hb)

    @staticmethod
    def _age(path):
        try:
            return time.time() - os.path.getmtime(path)
        except OSError:
            return 1e9

    def host_alive(self, max_age=HB_FRESH):
        return self._age(self.host_hb) < max_age

    def ui_age(self):
        return self._age(self.ui_hb)

    def remove_host_hb(self):
        try:
            os.remove(self.host_hb)
        except OSError:
            pass


# --------------------------------------------------------------------------
# Handle phía UI: giống giao diện của BotRunner
# --------------------------------------------------------------------------
class ServiceHandle:
    kind = "service"

    def __init__(self, client, events_path, token=None, pending=False):
        self.client = client
        self.token = token or uuid.uuid4().hex
        self._pending_since = time.time() if pending else 0.0
        self._state = None
        self._snap = None
        self._snap_pub = None
        self.events_log = ChatLog(events_path)
        self._ev_pos = 0
        self._events = []
        self.expect_running = pending

    @classmethod
    def attach(cls, client, events_path):
        """Gắn vào dịch vụ đang chạy (nếu có) khi mở lại app."""
        st = client.read_state()
        if st and st.get("runner_alive") and client.host_alive():
            h = cls(client, events_path, token=st.get("token"))
            h.expect_running = True
            return h
        return None

    # ---- điều khiển ----
    def start(self, config):
        config = dict(config, token=self.token)
        self.client.send("start", config=config)
        self._pending_since = time.time()
        self.expect_running = True
        self._ev_pos, self._events = 0, []

    def stop(self):
        self.expect_running = False
        self.client.send("stop", token=self.token)

    def request_close_all(self):
        self.client.send("close_all")

    def set_ai_auto(self, on):
        self.client.send("ai_auto", on=bool(on))

    # ---- trạng thái ----
    def _refresh(self):
        st = self.client.read_state()
        if st:
            self._state = st
        return self._state

    def _mine(self, st):
        return st is not None and st.get("token") == self.token

    def pending(self):
        return bool(self._pending_since) and (time.time() - self._pending_since) < PENDING_GRACE

    def is_alive(self):
        st = self._refresh()
        if self._mine(st):
            return bool(st.get("runner_alive")) and self.client.host_alive()
        return self.pending()

    def crashed(self):
        """Dịch vụ chết giữa chừng khi bot đang chạy (host.hb quá cũ)."""
        st = self._refresh()
        return self._mine(st) and bool(st.get("runner_alive")) and not self.client.host_alive()

    def failed_to_start(self):
        st = self._refresh()
        return (not self._mine(st)) and bool(self._pending_since) and not self.pending() and not self.client.host_alive()

    def finished_state(self):
        """Nếu phiên của handle này đã kết thúc: trả (status, message), ngược lại None."""
        st = self._refresh()
        if self._mine(st) and not st.get("runner_alive"):
            return st.get("status"), st.get("message", "")
        return None

    def snapshot(self, **_):
        st = self._refresh()
        if not self._mine(st):
            return None
        if st.get("pub") != self._snap_pub:
            self._snap_pub = st.get("pub")
            self._snap = snapshot_from_json(st.get("snapshot"))
        return self._snap

    def get_logs(self, after=0):
        st = self._refresh()
        if not self._mine(st):
            return []
        return [tuple(x) for x in st.get("logs", []) if x[0] > after]

    def events(self):
        msgs, newpos = self.events_log.read_from(self._ev_pos)
        if newpos < self._ev_pos:
            self._events = []
        self._ev_pos = newpos
        for m in msgs:
            self._events.append(_mk(TradeEvent, m))
        del self._events[:-300]
        return list(self._events)

    def ai_info(self):
        st = self._refresh()
        return (st or {}).get("ai") or {}

    def alarms(self):
        st = self._refresh()
        return (st or {}).get("alarms") or []


# --------------------------------------------------------------------------
# Host (chạy trong dịch vụ nền)
# --------------------------------------------------------------------------
class ServiceHost:
    def __init__(self, data_dir, alarm=None, set_notification=None, sleep=0.25, exit_grace=6.0, idle_exit=20.0,
                 runner_cls=BotRunner):
        self.data_dir = data_dir
        self.store = Store(data_dir)
        self.client = ServiceClient(data_dir)
        self.alarm_fn = alarm
        self.set_notification = set_notification
        self.sleep = sleep
        self.exit_grace = exit_grace
        self.idle_exit = idle_exit
        self.runner_cls = runner_cls
        self.runner = None
        self.hub = None
        self.config = None
        self.settings = {}
        self.token = None
        self.alarms = []
        self._pub = 0
        self._last_pub = 0.0
        self._last_notif = 0.0
        self._finished_at = None
        self._idle_since = time.time()
        self._exit = False

    # ---- cảnh báo ----
    def alarm(self, title, text):
        self.alarms.append({"t": time.time(), "title": title, "text": text})
        del self.alarms[:-20]
        if self.alarm_fn:
            try:
                self.alarm_fn(title, text)
            except Exception:
                pass

    # ---- phiên chạy ----
    def _hub_snapshot(self):
        return self.runner.snapshot(chart_bars=80) if self.runner else None

    def _hub_bot(self):
        if not self.config:
            return None
        path = self.config["bot_path"]
        info = inspect_bot(path)
        try:
            with open(path, "r", encoding="utf-8") as f:
                src = f.read()
        except OSError:
            return None
        params = build_params(info.inputs, self.config.get("params", {})) if info.ok else {}
        return (info.name if info.ok else os.path.basename(path), src, params)

    def start_session(self, config):
        if self.runner is not None and self.runner.is_alive():
            self.runner.stop()
            self.runner._thread.join(10)
        self.config = config
        self.settings = config["settings"]
        self.token = config["token"]
        resume = bool(config.get("resume"))
        if not resume:                      # phiên mới: xoá sổ lệnh + sự kiện của phiên cũ
            try:
                os.remove(self.store.state_path)
            except OSError:
                pass
            try:
                open(self.store.events_path, "w").close()
            except OSError:
                pass
        self.hub = AIHub(self.store, self._hub_snapshot, self._hub_bot, lambda: self.settings)
        self.runner = self.runner_cls(
            config["bot_path"], self.settings, config.get("params", {}),
            log_file=config.get("log_file"), trades_csv=config.get("trades_csv"), ai_hub=self.hub,
            state_file=self.store.state_path, events_file=self.store.events_path, resume=resume,
            alarm_cb=self.alarm, notify_cb=lambda t, x: self._post_notification(t, x))
        self.runner.start()
        self._finished_at = None
        d = self.client.read_desired() or {}
        d.update({"running": True, "config": config})
        self.client.write_desired(d)
        if config.get("ai_auto"):
            self.hub.start_auto()
        self._publish(force=True)

    def _post_notification(self, title, text):
        if self.set_notification:
            try:
                self.set_notification(title, text)
            except Exception:
                pass

    def _consume(self):
        for c in self.client.pop_commands():
            cmd = c.get("cmd")
            try:
                if cmd == "start":
                    self.start_session(c["config"])
                elif cmd == "stop" and self.runner and (c.get("token") in (None, self.token)):
                    self.runner.stop()
                elif cmd == "close_all" and self.runner:
                    self.runner.request_close_all()
                elif cmd == "ai_auto" and self.hub:
                    (self.hub.start_auto if c.get("on") else self.hub.stop_auto)()
            except Exception:
                self.alarm("Lỗi dịch vụ nền", traceback.format_exc(limit=2).strip().splitlines()[-1])

    def _maybe_resume(self):
        """Khởi động lại sau crash/bị hệ thống giết: nếu phiên đang 'cần chạy' -> chạy lại + khôi phục sổ lệnh."""
        if self.runner is not None:
            return
        d = self.client.read_desired()
        if not d or not d.get("running") or not d.get("config"):
            return
        cfg = dict(d["config"])
        if not cfg.get("settings", {}).get("auto_resume", True):
            d["running"] = False
            self.client.write_desired(d)
            return
        now = time.time()
        restarts = [t for t in d.get("restarts", []) if now - t < 300]
        if len(restarts) >= 3:
            d["running"], d["restarts"] = False, restarts
            self.client.write_desired(d)
            self.alarm("Dịch vụ crash liên tục", "Đã tự khởi động lại 3 lần trong 5 phút. Bot KHÔNG được chạy lại - hãy mở app kiểm tra.")
            return
        restarts.append(now)
        d["restarts"] = restarts
        self.client.write_desired(d)
        cfg["resume"] = True
        self.alarm("Bot được khôi phục sau sự cố", "Dịch vụ nền bị dừng đột ngột và đã tự chạy lại bot (đã khôi phục sổ lệnh).")
        self.start_session(cfg)

    # ---- publish ----
    def _publish(self, force=False, phase="running"):
        now = time.time()
        visible = self.client.ui_age() < 5.0
        every = 1.0 if visible else 10.0
        if not force and now - self._last_pub < every:
            return
        self._last_pub = now
        self._pub += 1
        st = {"pub": self._pub, "hb": now, "pid": os.getpid(), "phase": phase, "token": self.token,
              "ui_visible": visible, "alarms": self.alarms[-20:], "runner_alive": False,
              "status": "idle", "message": "", "snapshot": None, "logs": [], "ai": {}}
        r = self.runner
        if r is not None:
            st["runner_alive"] = r.is_alive()
            st["status"], st["message"] = r.status, r.message
            st["snapshot"] = snapshot_to_json(r.snapshot(chart_bars=160))
            st["logs"] = [list(x) for x in r.get_logs(0)[-150:]]
        if self.hub is not None:
            st["ai"] = {"auto_on": self.hub.auto_on, "signal": jsonable(self.hub.get_signal()),
                        "status": self.hub.status_text, "busy": self.hub.busy}
        self.client.write_state(st)

    def _update_notification(self, force=False):
        now = time.time()
        if not force and now - self._last_notif < 12.0:
            return
        self._last_notif = now
        if self.runner is not None and self.set_notification:
            t, x = notification_text(self.runner.snapshot(chart_bars=2))
            self._post_notification(t, x)

    # ---- vòng chính ----
    def run(self):
        self.client.touch_host()
        self._consume()
        self._maybe_resume()
        try:
            while not self._exit:
                self.client.touch_host()
                self._consume()
                r = self.runner
                if r is not None:
                    visible = self.client.ui_age() < 5.0
                    r.interval_override = 3.0 if (self.settings.get("power_mode") == "saver" and not visible) else None
                    if not r.is_alive() and self._finished_at is None:
                        self._finished_at = time.time()
                        d = self.client.read_desired() or {}
                        d["running"] = False
                        self.client.write_desired(d)
                        if self.hub:
                            self.hub.stop_auto()
                        self._publish(force=True, phase="exiting")
                        self._update_notification(force=True)
                    elif r.is_alive():
                        self._idle_since = time.time()
                        self._publish()
                        self._update_notification()
                    if self._finished_at and time.time() - self._finished_at > self.exit_grace:
                        self._exit = True
                elif time.time() - self._idle_since > self.idle_exit:
                    self._exit = True
                time.sleep(self.sleep)
        finally:
            try:
                self._publish(force=True, phase="exited")
            finally:
                self.client.remove_host_hb()
