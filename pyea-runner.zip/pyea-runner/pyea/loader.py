"""Nạp file bot .py (giống MT5 nạp file EA)."""
import ast
import importlib.util
import inspect
import os
import re
import sys
import traceback
from collections import OrderedDict
from dataclasses import dataclass, field

from .sdk import BaseBot, Input


class BotLoadError(Exception):
    pass


@dataclass
class BotInfo:
    path: str
    file: str
    ok: bool = False
    name: str = ""
    version: str = ""
    author: str = ""
    description: str = ""
    inputs: dict = field(default_factory=OrderedDict)
    error: str = ""


def _short_tb():
    lines = traceback.format_exc().strip().splitlines()
    return "\n".join(lines[-6:])


def load_bot_class(path):
    """Import file và trả về (class, module). Raise BotLoadError nếu lỗi."""
    if not os.path.isfile(path):
        raise BotLoadError("Không tìm thấy file: %s" % path)
    stem = re.sub(r"\W", "_", os.path.splitext(os.path.basename(path))[0])
    mod_name = "pyea_userbot_" + stem
    sys.modules.pop(mod_name, None)
    spec = importlib.util.spec_from_file_location(mod_name, path)
    if spec is None or spec.loader is None:
        raise BotLoadError("Không đọc được file Python này")
    module = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = module
    try:
        spec.loader.exec_module(module)
    except SyntaxError as e:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi cú pháp dòng %s: %s" % (e.lineno, e.msg))
    except Exception:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi khi nạp file:\n" + _short_tb())
    cands = [obj for obj in vars(module).values()
             if inspect.isclass(obj) and issubclass(obj, BaseBot) and obj is not BaseBot and obj.__module__ == mod_name]
    # ưu tiên lớp "lá" (không là lớp cha của lớp bot khác trong file) - hỗ trợ kế thừa; nhiều lá -> lớp khai báo trước
    leaves = [c for c in cands if not any(o is not c and issubclass(o, c) for o in cands)]
    found = (leaves or cands or [None])[0]
    if found is None:
        raise BotLoadError("Không thấy class nào kế thừa BaseBot trong file.\n"
                           "Hãy khai báo:  class MyBot(BaseBot): ...")
    return found, module


_NOT_INPUT = {"name", "version", "author", "description", "inputs"}


def _auto_inputs(cls, path):
    """Dạng 3: nhận dạng thuộc tính lớp có chú thích kiểu + giá trị literal làm tham số (như `input double Lot=0.01;`):
        lot: float = 0.01          # Khối lượng
        mode: str = "a"            # Chế độ [a|b|c]      -> ô chọn
        # == Tín hiệu ==           -> đặt nhóm cho các tham số bên dưới
    """
    if not path or not os.path.isfile(path):
        return OrderedDict()
    try:
        src = open(path, "r", encoding="utf-8").read()
        tree = ast.parse(src)
    except (OSError, SyntaxError):
        return OrderedDict()
    lines = src.splitlines()
    node = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls.__name__), None)
    out = OrderedDict()
    if node is None:
        return out
    group_at, cur = {}, None
    for ln in range(node.lineno, (getattr(node, "end_lineno", None) or len(lines)) + 1):
        m = re.match(r"\s*#\s*[=\-]{2,}\s*(.+?)\s*[=\-]*\s*$", lines[ln - 1]) if 0 < ln <= len(lines) else None
        if m:
            cur = m.group(1)
        group_at[ln] = cur
    for st in node.body:
        if not isinstance(st, ast.AnnAssign):
            continue
        group = group_at.get(st.lineno)
        if not isinstance(st.target, ast.Name) or st.target.id.startswith("_") or st.target.id in _NOT_INPUT:
            continue
        try:
            default = ast.literal_eval(st.value)
        except Exception:
            continue
        if not isinstance(default, (bool, int, float, str)):
            continue
        line = lines[st.lineno - 1] if 0 < st.lineno <= len(lines) else ""
        comment = line.split("#", 1)[1].strip() if "#" in line else ""
        choices, label = None, comment or st.target.id
        m = re.search(r"\[([^\]]+\|[^\]]+)\]", comment)
        if m:
            choices = [c.strip() for c in m.group(1).split("|")]
            label = (comment[:m.start()] + comment[m.end():]).strip() or st.target.id
        ann = st.annotation
        if isinstance(ann, ast.Subscript) and getattr(ann.value, "id", "") == "Literal":
            try:
                v = ast.literal_eval(ann.slice)
                choices = list(v) if isinstance(v, tuple) else [v]
            except Exception:
                pass
        if choices and default not in choices:
            choices.insert(0, default)
        out[st.target.id] = Input(default, label, choices=choices, group=group)
    return out


def collect_inputs(cls, path=None):
    """Nhận dạng tham số của bot để tự sinh form (như MT5 nhận dạng `input`). Thứ tự ưu tiên/gộp:
      1) `inputs = {"tên": Input(...)}`
      2) thuộc tính lớp gán `Input(...)`:   lot = Input(0.01, "Khối lượng")
      3) (chỉ khi 1 và 2 trống) thuộc tính có chú thích kiểu + giá trị literal:   lot: float = 0.01  # Khối lượng
    """
    out = OrderedDict()
    for k in reversed([c for c in cls.__mro__ if c not in (BaseBot, object)]):
        d = vars(k).get("inputs")
        if isinstance(d, dict):
            out.update(d)
        for name, v in vars(k).items():
            if isinstance(v, Input):
                out[name] = v
    if not out:
        out.update(_auto_inputs(cls, path))
    return out


def inspect_bot(path):
    """Nạp file để lấy thông tin + danh sách tham số (không chạy bot)."""
    info = BotInfo(path=path, file=os.path.basename(path))
    try:
        cls, _ = load_bot_class(path)
    except BotLoadError as e:
        info.error = str(e)
        return info
    info.ok = True
    info.name = cls.name or cls.__name__
    info.version = str(cls.version or "")
    info.author = str(cls.author or "")
    info.description = (cls.description or (cls.__doc__ or "")).strip()
    info.inputs = collect_inputs(cls, path)
    return info


def build_params(inputs, saved):
    """Gộp giá trị đã lưu với mặc định; giá trị hỏng -> mặc định."""
    saved = saved or {}
    out = {}
    for key, inp in inputs.items():
        try:
            out[key] = inp.coerce(saved.get(key, inp.default))
        except ValueError:
            out[key] = inp.default
    return out
