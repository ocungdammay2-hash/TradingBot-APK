"""Nạp file bot .py (giống MT5 nạp file EA)."""
import importlib.util
import inspect
import os
import re
import sys
import traceback
from collections import OrderedDict
from dataclasses import dataclass, field

from .sdk import BaseBot


class BotLoadError(Exception):
    pass


@dataclass
class BotInfo:
    path: str
    file: str
    ok: bool = False
    name: str = ""
    version: str = ""
    author: str = ""
    description: str = ""
    inputs: dict = field(default_factory=OrderedDict)
    error: str = ""


def _short_tb():
    lines = traceback.format_exc().strip().splitlines()
    return "\n".join(lines[-6:])


def load_bot_class(path):
    """Import file và trả về (class, module). Raise BotLoadError nếu lỗi."""
    if not os.path.isfile(path):
        raise BotLoadError("Không tìm thấy file: %s" % path)
    stem = re.sub(r"\W", "_", os.path.splitext(os.path.basename(path))[0])
    mod_name = "pyea_userbot_" + stem
    sys.modules.pop(mod_name, None)
    spec = importlib.util.spec_from_file_location(mod_name, path)
    if spec is None or spec.loader is None:
        raise BotLoadError("Không đọc được file Python này")
    module = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = module
    try:
        spec.loader.exec_module(module)
    except SyntaxError as e:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi cú pháp dòng %s: %s" % (e.lineno, e.msg))
    except Exception:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi khi nạp file:\n" + _short_tb())
    found = None
    for obj in vars(module).values():
        if (inspect.isclass(obj) and issubclass(obj, BaseBot) and obj is not BaseBot
                and obj.__module__ == mod_name):
            found = obj
            break
    if found is None:
        raise BotLoadError("Không thấy class nào kế thừa BaseBot trong file.\n"
                           "Hãy khai báo:  class MyBot(BaseBot): ...")
    return found, module


def inspect_bot(path):
    """Nạp file để lấy thông tin + danh sách tham số (không chạy bot)."""
    info = BotInfo(path=path, file=os.path.basename(path))
    try:
        cls, _ = load_bot_class(path)
    except BotLoadError as e:
        info.error = str(e)
        return info
    info.ok = True
    info.name = cls.name or cls.__name__
    info.version = str(cls.version or "")
    info.author = str(cls.author or "")
    info.description = (cls.description or (cls.__doc__ or "")).strip()
    info.inputs = OrderedDict(getattr(cls, "inputs", {}) or {})
    return info


def build_params(inputs, saved):
    """Gộp giá trị đã lưu với mặc định; giá trị hỏng -> mặc định."""
    saved = saved or {}
    out = {}
    for key, inp in inputs.items():
        try:
            out[key] = inp.coerce(saved.get(key, inp.default))
        except ValueError:
            out[key] = inp.default
    return out
