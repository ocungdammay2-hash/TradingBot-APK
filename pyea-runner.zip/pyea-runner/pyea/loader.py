"""Nạp file bot .py (giống MT5 nạp file EA)."""
import ast
import importlib.util
import inspect
import os
import re
import sys
import traceback
from collections import OrderedDict
from dataclasses import dataclass, field

from .sdk import API_VERSION, BaseBot, Input


class BotLoadError(Exception):
    pass


@dataclass
class BotInfo:
    path: str
    file: str
    ok: bool = False
    name: str = ""
    version: str = ""
    author: str = ""
    description: str = ""
    inputs: dict = field(default_factory=OrderedDict)
    error: str = ""
    api_min: str = ""                                   # `# @api_min: 1.1` trong bot
    warnings: list = field(default_factory=list)        # cảnh báo an toàn (mạng, ghi file...)


def _short_tb():
    lines = traceback.format_exc().strip().splitlines()
    return "\n".join(lines[-6:])



# --------------------------------------------------------------------------
# Khai báo (manifest) + kiểm tra an toàn tĩnh trước khi nạp bot
# --------------------------------------------------------------------------
_BLOCK_MODULES = {"subprocess": "chạy lệnh hệ thống", "ctypes": "gọi mã native", "pty": "mở terminal giả",
                  "multiprocessing": "tạo tiến trình con", "pexpect": "điều khiển tiến trình"}
_WARN_MODULES = {"requests": "network", "urllib": "network", "urllib3": "network", "http": "network", "socket": "network",
                 "websocket": "network", "websockets": "network", "aiohttp": "network", "shutil": "files", "pathlib": "files"}
_BLOCK_OS = {"system", "popen", "execv", "execve", "execvp", "execl", "execle", "execlp", "spawnl", "spawnv", "spawnve", "fork",
             "forkpty", "kill", "killpg", "startfile"}
_BLOCK_CALLS = {"eval": "chạy chuỗi như mã", "exec": "chạy chuỗi như mã", "compile": "biên dịch mã động",
                "__import__": "nạp module động"}


def _ver_tuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().split(".")[:3])
    except ValueError:
        return (0,)


def parse_manifest(source):
    """Đọc dòng khai báo ở đầu file bot:  `# @api_min: 1.1`  và  `# @permissions: network, files` (thông tin cho người dùng)."""
    m = {"api_min": "", "permissions": []}
    for line in source.splitlines()[:40]:
        mm = re.match(r"^\s*#\s*@(\w+)\s*:\s*(.+?)\s*$", line)
        if not mm:
            continue
        k, v = mm.group(1).lower(), mm.group(2)
        if k == "api_min":
            m["api_min"] = v
        elif k == "permissions":
            m["permissions"] = [x.strip().lower() for x in v.split(",") if x.strip()]
    return m


def check_bot_source(source, dev_mode=False):
    """-> (errors, warnings, manifest). errors: mã nguy hiểm (chặn nạp trừ khi dev_mode) hoặc bot cần API mới hơn vỏ."""
    errors, warnings = [], []
    man = parse_manifest(source)
    if man["api_min"] and _ver_tuple(man["api_min"]) > _ver_tuple(API_VERSION):
        errors.append("Bot yêu cầu API ≥ %s nhưng vỏ hiện chỉ có API %s - hãy cập nhật ứng dụng" % (man["api_min"], API_VERSION))
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return errors, warnings, man          # lỗi cú pháp để load_bot_class báo
    seen = set()
    risky = []
    for node in ast.walk(tree):
        mods = []
        if isinstance(node, ast.Import):
            mods = [a.name.split(".")[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            mods = [node.module.split(".")[0]]
        for mname in mods:
            if mname in _BLOCK_MODULES:
                risky.append("dòng %d: import %s (%s)" % (node.lineno, mname, _BLOCK_MODULES[mname]))
            elif mname in _WARN_MODULES and mname not in seen:
                seen.add(mname)
                warnings.append("Bot dùng %s (%s)" % (mname, _WARN_MODULES[mname]))
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name) and f.id in _BLOCK_CALLS:
                risky.append("dòng %d: %s() (%s)" % (node.lineno, f.id, _BLOCK_CALLS[f.id]))
            elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "os" and f.attr in _BLOCK_OS:
                risky.append("dòng %d: os.%s() (chạy lệnh/tiến trình hệ thống)" % (node.lineno, f.attr))
    if risky:
        msg = "Bot chứa mã nguy hiểm: " + "; ".join(risky[:5]) + (" ..." if len(risky) > 5 else "")
        if dev_mode:
            warnings.append(msg + " (cho phép vì đang bật Chế độ nhà phát triển)")
        else:
            errors.append(msg + ".\nBot chạy toàn quyền Python nên vỏ chặn các lệnh này. Nếu bạn TIN file bot, bật "
                                "Cài đặt → Chế độ nhà phát triển.")
    return errors, warnings, man


DEV_MODE = False      # đặt theo Cài đặt → Chế độ nhà phát triển (cả UI lẫn dịch vụ nền); load/inspect không truyền thì dùng giá trị này


def load_bot_class(path, dev_mode=None):
    """Import file và trả về (class, module). Raise BotLoadError nếu lỗi."""
    if not os.path.isfile(path):
        raise BotLoadError("Không tìm thấy file: %s" % path)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            src = f.read()
    except OSError as e:
        raise BotLoadError("Không đọc được file: %s" % e)
    errs, _, _ = check_bot_source(src, DEV_MODE if dev_mode is None else dev_mode)
    if errs:
        raise BotLoadError("\n".join(errs))
    stem = re.sub(r"\W", "_", os.path.splitext(os.path.basename(path))[0])
    mod_name = "pyea_userbot_" + stem
    sys.modules.pop(mod_name, None)
    spec = importlib.util.spec_from_file_location(mod_name, path)
    if spec is None or spec.loader is None:
        raise BotLoadError("Không đọc được file Python này")
    module = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = module
    try:
        spec.loader.exec_module(module)
    except SyntaxError as e:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi cú pháp dòng %s: %s" % (e.lineno, e.msg))
    except Exception:
        sys.modules.pop(mod_name, None)
        raise BotLoadError("Lỗi khi nạp file:\n" + _short_tb())
    cands = [obj for obj in vars(module).values()
             if inspect.isclass(obj) and issubclass(obj, BaseBot) and obj is not BaseBot and obj.__module__ == mod_name]
    # ưu tiên lớp "lá" (không là lớp cha của lớp bot khác trong file) - hỗ trợ kế thừa; nhiều lá -> lớp khai báo trước
    leaves = [c for c in cands if not any(o is not c and issubclass(o, c) for o in cands)]
    found = (leaves or cands or [None])[0]
    if found is None:
        raise BotLoadError("Không thấy class nào kế thừa BaseBot trong file.\n"
                           "Hãy khai báo:  class MyBot(BaseBot): ...")
    return found, module


_NOT_INPUT = {"name", "version", "author", "description", "inputs"}


def _auto_inputs(cls, path):
    """Dạng 3: nhận dạng thuộc tính lớp có chú thích kiểu + giá trị literal làm tham số (như `input double Lot=0.01;`):
        lot: float = 0.01          # Khối lượng
        mode: str = "a"            # Chế độ [a|b|c]      -> ô chọn
        # == Tín hiệu ==           -> đặt nhóm cho các tham số bên dưới
    """
    if not path or not os.path.isfile(path):
        return OrderedDict()
    try:
        src = open(path, "r", encoding="utf-8").read()
        tree = ast.parse(src)
    except (OSError, SyntaxError):
        return OrderedDict()
    lines = src.splitlines()
    node = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls.__name__), None)
    out = OrderedDict()
    if node is None:
        return out
    group_at, cur = {}, None
    for ln in range(node.lineno, (getattr(node, "end_lineno", None) or len(lines)) + 1):
        m = re.match(r"\s*#\s*[=\-]{2,}\s*(.+?)\s*[=\-]*\s*$", lines[ln - 1]) if 0 < ln <= len(lines) else None
        if m:
            cur = m.group(1)
        group_at[ln] = cur
    for st in node.body:
        if not isinstance(st, ast.AnnAssign):
            continue
        group = group_at.get(st.lineno)
        if not isinstance(st.target, ast.Name) or st.target.id.startswith("_") or st.target.id in _NOT_INPUT:
            continue
        try:
            default = ast.literal_eval(st.value)
        except Exception:
            continue
        if not isinstance(default, (bool, int, float, str)):
            continue
        line = lines[st.lineno - 1] if 0 < st.lineno <= len(lines) else ""
        comment = line.split("#", 1)[1].strip() if "#" in line else ""
        choices, label = None, comment or st.target.id
        m = re.search(r"\[([^\]]+\|[^\]]+)\]", comment)
        if m:
            choices = [c.strip() for c in m.group(1).split("|")]
            label = (comment[:m.start()] + comment[m.end():]).strip() or st.target.id
        ann = st.annotation
        if isinstance(ann, ast.Subscript) and getattr(ann.value, "id", "") == "Literal":
            try:
                v = ast.literal_eval(ann.slice)
                choices = list(v) if isinstance(v, tuple) else [v]
            except Exception:
                pass
        if choices and default not in choices:
            choices.insert(0, default)
        out[st.target.id] = Input(default, label, choices=choices, group=group)
    return out


def collect_inputs(cls, path=None):
    """Nhận dạng tham số của bot để tự sinh form (như MT5 nhận dạng `input`). Thứ tự ưu tiên/gộp:
      1) `inputs = {"tên": Input(...)}`
      2) thuộc tính lớp gán `Input(...)`:   lot = Input(0.01, "Khối lượng")
      3) (chỉ khi 1 và 2 trống) thuộc tính có chú thích kiểu + giá trị literal:   lot: float = 0.01  # Khối lượng
    """
    out = OrderedDict()
    for k in reversed([c for c in cls.__mro__ if c not in (BaseBot, object)]):
        d = vars(k).get("inputs")
        if isinstance(d, dict):
            out.update(d)
        for name, v in vars(k).items():
            if isinstance(v, Input):
                out[name] = v
    if not out:
        out.update(_auto_inputs(cls, path))
    return out


def inspect_bot(path, dev_mode=None):
    """Nạp file để lấy thông tin + danh sách tham số (không chạy bot)."""
    info = BotInfo(path=path, file=os.path.basename(path))
    try:
        cls, _ = load_bot_class(path, dev_mode)
    except BotLoadError as e:
        info.error = str(e)
        return info
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            _, info.warnings, man = check_bot_source(f.read(), DEV_MODE if dev_mode is None else dev_mode)
        info.api_min = man["api_min"]
    except OSError:
        pass
    info.ok = True
    info.name = cls.name or cls.__name__
    info.version = str(cls.version or "")
    info.author = str(cls.author or "")
    info.description = (cls.description or (cls.__doc__ or "")).strip()
    info.inputs = collect_inputs(cls, path)
    return info


def build_params(inputs, saved):
    """Gộp giá trị đã lưu với mặc định; giá trị hỏng -> mặc định."""
    saved = saved or {}
    out = {}
    for key, inp in inputs.items():
        try:
            out[key] = inp.coerce(saved.get(key, inp.default))
        except ValueError:
            out[key] = inp.default
    return out
