"""Kiểm tra hệ thống (nút 'Kiểm tra hệ thống'): giúp phát hiện sớm lỗi trên thiết bị thật
và dán báo cáo lại cho người hỗ trợ. Không phụ thuộc Kivy."""
import os
import platform
import sys
import time

from . import android_native as an
from .feeds import FeedError, http_json, resolve_base
from .ipc import ServiceClient

OK, WARN, FAIL = "OK", "CHÚ Ý", "LỖI"


def run_checks(data_dir, settings, store=None, network=True):
    res = []

    def add(name, status, detail=""):
        res.append({"name": name, "status": status, "detail": str(detail)})

    add("Python", OK, "%s | %s" % (sys.version.split()[0], platform.platform()))
    if an.IS_ANDROID:
        info = an.device_info()
        add("Thiết bị Android", OK if info else WARN,
            "%(model)s | Android %(android)s (API %(sdk)s) | ABI %(abis)s" % info if info else "không đọc được (pyjnius?)")
    else:
        add("Nền tảng", WARN, "Không phải Android: dịch vụ nền / thông báo / chọn file hệ thống không khả dụng")

    try:
        p = os.path.join(data_dir, ".write_test")
        with open(p, "w") as f:
            f.write("x")
        os.remove(p)
        add("Thư mục dữ liệu ghi được", OK, data_dir)
    except OSError as e:
        add("Thư mục dữ liệu ghi được", FAIL, "%s: %s" % (data_dir, e))

    try:
        import certifi
        add("Chứng chỉ HTTPS (certifi)", OK if os.path.exists(certifi.where()) else FAIL, certifi.where())
    except Exception as e:
        add("Chứng chỉ HTTPS (certifi)", FAIL, e)

    assets = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "DejaVuSans.ttf")
    add("Font tiếng Việt", OK if os.path.exists(assets) else FAIL, assets)

    if store is not None:
        n = len(store.list_bots())
        add("Bot đã nạp", OK if n else WARN, "%d file" % n)
        agents = store.load_agents()
        en = [a for a in agents if a.get("enabled", True)]
        add("AI đã cấu hình", OK if en else WARN, "%d AI (%d đang bật)" % (len(agents), len(en)))
        if os.path.exists(store.crash_path):
            add("Nhật ký crash của app", WARN, "có file %s" % store.crash_path)
        sc = os.path.join(data_dir, "service_crash.log")
        if os.path.exists(sc):
            add("Nhật ký crash của dịch vụ nền", WARN, "có file %s" % sc)

    if an.IS_ANDROID:
        try:
            ac = an._jnius()
            ac("%s.Service%s" % (an.package_name(), an.SERVICE_NAME))
            add("Dịch vụ nền (foreground service)", OK, "đã được đóng gói trong APK")
        except Exception as e:
            add("Dịch vụ nền (foreground service)", FAIL, "không tìm thấy lớp dịch vụ: %s" % e)
        add("Loại khỏi tối ưu pin", OK if an.is_ignoring_battery_optimizations() else WARN,
            "đã loại" if an.is_ignoring_battery_optimizations() else "CHƯA - Android có thể giết bot nền; bấm 'Tối ưu pin'")
    client = ServiceClient(data_dir)
    alive = client.host_alive()
    add("Dịch vụ nền đang chạy", OK if alive else WARN, "có" if alive else "không (bình thường nếu bot chưa chạy)")

    if network:
        base = resolve_base(settings)
        path = "/fapi/v1/time" if settings.get("exchange") == "binance_futures" else "/api/v3/time"
        t0 = time.time()
        try:
            d = http_json(base + path, timeout=10)
            ms = (time.time() - t0) * 1000
            skew = d["serverTime"] / 1000.0 - time.time()
            add("Kết nối sàn (%s)" % base, OK, "%.0f ms" % ms)
            add("Đồng hồ máy so với sàn", OK if abs(skew) < 3 else WARN,
                "lệch %.1f giây%s" % (skew, "" if abs(skew) < 3 else " - app tự bù khi gọi API, nhưng nên bật giờ tự động"))
        except (FeedError, KeyError) as e:
            add("Kết nối sàn (%s)" % base, FAIL, "%s (có thể bị chặn vùng - thử 'Base URL tuỳ chỉnh' hoặc nguồn giá simulated)" % e)
    return res


def format_report(results):
    mark = {OK: "[OK]   ", WARN: "[CHÚ Ý]", FAIL: "[LỖI]  "}
    lines = ["PyEA Runner - báo cáo kiểm tra %s" % time.strftime("%Y-%m-%d %H:%M:%S")]
    for r in results:
        lines.append("%s %s: %s" % (mark.get(r["status"], r["status"]), r["name"], r["detail"]))
    return "\n".join(lines)
