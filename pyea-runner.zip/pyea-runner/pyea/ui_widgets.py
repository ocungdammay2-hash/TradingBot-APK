"""Widget dùng chung cho giao diện Kivy: theme, bảng, form tham số, biểu đồ, popup.

Lưu ý kỹ thuật (đã rút kinh nghiệm):
- Texture của Label bị giới hạn ~4096px chiều cao trên nhiều GPU -> KHÔNG đưa văn bản dài
  (log, code) vào 1 Label; dùng mỗi dòng 1 Label trong ScrollView.
- Font mặc định của Kivy thiếu dấu tiếng Việt -> nạp DejaVu Sans trong assets/.
- Không dùng emoji (DejaVu không có glyph) - chỉ dùng ký tự thường, ■ ▶ ●.
"""
import os
import time
from bisect import bisect_right

from kivy.core.text import Label as CoreLabel
from kivy.core.text import LabelBase
from kivy.graphics import Color, Ellipse, Line, Quad, Rectangle, RoundedRectangle, Triangle
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.switch import Switch
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.utils import escape_markup

# ---------------------------------------------------------------- theme
BG = (0.05, 0.06, 0.08, 1)
BG2 = (0.08, 0.09, 0.12, 1)
PANEL = (0.11, 0.13, 0.17, 1)
PANEL2 = (0.16, 0.19, 0.25, 1)
TEXT = (0.92, 0.94, 0.97, 1)
MUTED = (0.60, 0.66, 0.74, 1)
GREEN = (0.13, 0.62, 0.40, 1)
RED = (0.80, 0.24, 0.28, 1)
BLUE = (0.18, 0.46, 0.84, 1)
AMBER = (0.95, 0.70, 0.22, 1)
UP = (0.20, 0.78, 0.50, 1)
DOWN = (0.92, 0.32, 0.36, 1)
PALETTE = [(0.98, 0.78, 0.22, 1), (0.36, 0.66, 0.98, 1), (0.82, 0.48, 0.96, 1),
           (0.30, 0.86, 0.82, 1), (0.98, 0.58, 0.36, 1)]

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
MIN_TOUCH = 48   # dp - vùng chạm tối thiểu (dễ bấm khi đeo găng/tay ướt, màn hình nhỏ)


def hexc(c):
    return "%02x%02x%02x" % tuple(int(v * 255) for v in c[:3])


def setup_fonts():
    reg = os.path.join(ASSETS, "DejaVuSans.ttf")
    bold = os.path.join(ASSETS, "DejaVuSans-Bold.ttf")
    if os.path.exists(reg):
        LabelBase.register(name="Roboto", fn_regular=reg,
                           fn_bold=bold if os.path.exists(bold) else reg)


# ---------------------------------------------------------------- helpers
def fp(x):
    if x is None:
        return "-"
    ax = abs(x)
    if ax >= 100:
        return "{:,.2f}".format(x)
    if ax >= 1:
        return "%.4f" % x
    return "%.6f" % x


def fm(x):
    return "{:+,.2f}".format(x)


def flabel(text="", size=13, color=TEXT, bold=False, halign="left", **kw):
    """Label chiều cao cố định, căn giữa theo chiều dọc."""
    lb = Label(text=text, font_size=sp(size), color=color, bold=bold, halign=halign,
               valign="middle", markup=True, **kw)
    lb.bind(size=lambda w, s: setattr(w, "text_size", s))
    return lb


def wlabel(text="", size=13, color=TEXT, bold=False, **kw):
    """Label tự xuống dòng, tự cao theo nội dung (đừng nhét văn bản quá dài)."""
    lb = Label(text=text, font_size=sp(size), color=color, bold=bold, markup=True,
               halign="left", valign="top", size_hint_y=None, **kw)
    lb.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
    lb.bind(texture_size=lambda w, s: setattr(w, "height", s[1] + dp(2)))
    return lb


def mkbtn(text, bg=BLUE, h=MIN_TOUCH, on_release=None, size=14, **kw):
    dim = tuple(v * 0.7 for v in bg[:3]) + (1,)
    b = Button(text=text, font_size=sp(size), background_normal="", background_down="",
               background_color=bg, color=(1, 1, 1, 1), size_hint_y=None, height=dp(h), **kw)
    b.bind(state=lambda w, st: setattr(w, "background_color", dim if st == "down" else bg))
    if on_release:
        b.bind(on_release=on_release)
    return b


def mkchip(text, color, active, on_toggle):
    """Nút bật/tắt dạng chip (dùng để ẩn/hiện đường chỉ báo...). on_toggle(active:bool)."""
    from kivy.uix.togglebutton import ToggleButton
    on_bg = tuple(v * 0.55 for v in color[:3]) + (1,)
    b = ToggleButton(text=text, font_size=sp(11), size_hint=(None, None), height=dp(36), halign="center",
                     background_normal="", background_down="", color=TEXT if active else MUTED,
                     background_color=on_bg if active else PANEL2, state="down" if active else "normal")
    b.bind(texture_size=lambda w, ts: setattr(w, "width", ts[0] + dp(22)))

    def _chg(w, st):
        a = st == "down"
        w.background_color = on_bg if a else PANEL2
        w.color = TEXT if a else MUTED
        on_toggle(a)
    b.bind(state=_chg)
    return b


def vscroll(content):
    sv = ScrollView(do_scroll_x=False, bar_width=dp(4))
    sv.add_widget(content)
    return sv


def vbox(**kw):
    """BoxLayout dọc, chiều cao = tổng con (dùng trong ScrollView)."""
    b = BoxLayout(orientation="vertical", size_hint_y=None, **kw)
    b.bind(minimum_height=b.setter("height"))
    return b


def section(text):
    return flabel(text, 13, AMBER, bold=True, size_hint_y=None, height=dp(34))


class Panel(BoxLayout):
    def __init__(self, bg=PANEL, radius=8, **kw):
        super().__init__(**kw)
        with self.canvas.before:
            self._col = Color(*bg)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(radius)])
        self.bind(pos=self._upd, size=self._upd)

    def _upd(self, *_):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def set_bg(self, bg):
        self._col.rgba = bg


# ---------------------------------------------------------------- popup
def popup(title, message, buttons=None, size=(0.92, 0.6), color=TEXT):
    """buttons: [(text, color, callback)] ; callback(popup) -> đóng nếu trả về != False."""
    content = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8))
    body = vbox(padding=dp(2))
    body.add_widget(wlabel(message, 13, color))
    content.add_widget(vscroll(body))
    row = BoxLayout(size_hint_y=None, height=dp(MIN_TOUCH), spacing=dp(8))
    pop = Popup(title=title, content=content, size_hint=size, auto_dismiss=False,
                separator_color=BLUE, background="")
    for text, bg, cb in (buttons or [("Đóng", BLUE, None)]):
        def _go(_w, cb=cb):
            if cb is None or cb(pop) is not False:
                pop.dismiss()
        row.add_widget(mkbtn(text, bg, on_release=_go))
    content.add_widget(row)
    pop.open()
    return pop


def confirm(title, message, on_yes, yes_text="Đồng ý", yes_color=RED):
    return popup(title, message, [("Huỷ", PANEL2, None),
                                  (yes_text, yes_color, lambda p: on_yes())], size=(0.9, 0.45))


# ---------------------------------------------------------------- bảng
class Table(GridLayout):
    def __init__(self, headers, weights, row_h=28, **kw):
        super().__init__(cols=len(headers), size_hint_y=None, row_default_height=dp(row_h),
                         row_force_default=True, spacing=(dp(2), dp(1)), **kw)
        self.bind(minimum_height=self.setter("height"))
        self.headers = headers
        self.weights = weights
        self.row_h = row_h
        self.set_rows([])

    def _cell(self, text, color, bold, w):
        lb = Label(text=str(text), font_size=sp(11), color=color, bold=bold, size_hint_x=w,
                   size_hint_y=None, height=dp(self.row_h), halign="center", valign="middle",
                   shorten=True, shorten_from="right")
        lb.bind(size=lambda wd, s: setattr(wd, "text_size", s))
        return lb

    def set_rows(self, rows):
        """rows: list các list; mỗi ô là text hoặc (text, color)."""
        self.clear_widgets()
        for h, w in zip(self.headers, self.weights):
            self.add_widget(self._cell(h, MUTED, True, w))
        for row in rows:
            for item, w in zip(row, self.weights):
                text, color = item if isinstance(item, tuple) else (item, TEXT)
                self.add_widget(self._cell(text, color, False, w))


class StatBox(Panel):
    def __init__(self, title, **kw):
        super().__init__(orientation="vertical", padding=[dp(8), dp(4)], spacing=0, **kw)
        self.t = flabel(title, 10, MUTED)
        self.v = flabel("-", 15, TEXT, bold=True)
        self.add_widget(self.t)
        self.add_widget(self.v)

    def set(self, text, color=TEXT):
        self.v.text = text
        self.v.color = color


# ---------------------------------------------------------------- biểu đồ
class CandleChart(Widget):
    """Biểu đồ nến kiểu MT5: lưới + trục giá/thời gian, đường chỉ báo (ẩn/hiện được), chấm vào/ra lệnh
    (▲ mua, ▼ bán, ● thoát, ◆ ghi chú) nối bằng đường nét đứt; CHẠM vào chấm -> on_tap(event)."""
    RM = 54      # dp lề phải (nhãn giá)
    BM = 16      # dp lề dưới (nhãn giờ)

    def __init__(self, on_tap=None, **kw):
        super().__init__(**kw)
        self.on_tap = on_tap
        self.candles, self.plots, self.events, self.hlines = [], {}, [], []
        self.hidden = set()
        self.bars, self.offset = 60, 0
        self.show_markers = self.show_lines = self.show_grid = True
        self._hits = []
        self._tex = {}
        self.bind(pos=self.redraw, size=self.redraw)

    def update(self, candles, plots=None, events=None, hlines=None):
        self.candles = candles or []
        self.plots = plots or {}
        self.events = events or []
        self.hlines = hlines or []
        self.redraw()

    def _label(self, text, size=10, color=MUTED):
        key = (text, size, color)
        t = self._tex.get(key)
        if t is None:
            if len(self._tex) > 300:
                self._tex.clear()
            lb = CoreLabel(text=text, font_size=sp(size), color=color, font_name="Roboto")
            lb.refresh()
            t = self._tex[key] = lb.texture
        return t

    def _text(self, text, x, y, size=10, color=MUTED, anchor="left"):
        t = self._label(text, size, color)
        if t is None:
            return
        w, h = t.size
        Color(1, 1, 1, 1)
        Rectangle(texture=t, pos=(x - (w if anchor == "right" else w / 2 if anchor == "center" else 0), y - h / 2), size=(w, h))

    def redraw(self, *_):
        self.canvas.clear()
        self._hits = []
        with self.canvas:
            Color(*BG2)
            Rectangle(pos=self.pos, size=self.size)
            n_all = len(self.candles)
            if n_all < 2 or self.width < dp(80) or self.height < dp(60):
                return
            end = max(2, n_all - self.offset)
            vis = self.candles[max(0, end - self.bars):end]
            n = len(vis)
            x0, y0 = self.x, self.y + dp(self.BM)
            pw, ph = self.width - dp(self.RM), self.height - dp(self.BM) - dp(6)
            hi = max(c.high for c in vis)
            lo = min(c.low for c in vis)
            if hi <= lo:
                hi, lo = lo + 1e-9, lo - 1e-9
            pad = (hi - lo) * 0.08
            hi, lo = hi + pad, lo - pad

            def Y(p):
                return y0 + max(0.0, min(1.0, (p - lo) / (hi - lo))) * ph
            bw = pw / n
            xs = [x0 + (i + 0.5) * bw for i in range(n)]
            times = [c.time for c in vis]
            step = (times[-1] - times[-2]) if n >= 2 else 60.0
            # --- lưới + nhãn giá
            for k in range(5):
                p = lo + (hi - lo) * k / 4.0
                y = Y(p)
                if self.show_grid:
                    Color(1, 1, 1, 0.06)
                    Line(points=[x0, y, x0 + pw, y], width=1)
                self._text(fp(p), x0 + pw + dp(3), y, 9, MUTED)
            span = times[-1] - times[0]
            fmt = "%d/%m" if step >= 86400 else ("%d/%m %H:%M" if span > 86400 else "%H:%M")
            for i in (0, n // 3, 2 * n // 3, n - 1):
                if self.show_grid:
                    Color(1, 1, 1, 0.04)
                    Line(points=[xs[i], y0, xs[i], y0 + ph], width=1)
                self._text(time.strftime(fmt, time.localtime(times[i])), xs[i], self.y + dp(self.BM) / 2, 9, MUTED, "center")
            # --- nến
            body = max(dp(1), bw * 0.65)
            for i, c in enumerate(vis):
                Color(*(UP if c.close >= c.open else DOWN))
                Line(points=[xs[i], Y(c.low), xs[i], Y(c.high)], width=1)
                yo, yc = Y(c.open), Y(c.close)
                Rectangle(pos=(xs[i] - body / 2, min(yo, yc)), size=(body, max(abs(yc - yo), dp(1))))
            # --- đường chỉ báo
            idx = {t: i for i, t in enumerate(times)}
            for k, (name, pts) in enumerate(self.plots.items()):
                if name in self.hidden:
                    continue
                co = []
                for t, v in pts:
                    i = idx.get(t)
                    if i is not None:
                        co += [xs[i], Y(v)]
                if len(co) >= 4:
                    Color(*PALETTE[k % len(PALETTE)])
                    Line(points=co, width=dp(1.1))
            # --- đường giá vào của lệnh đang mở
            if self.show_lines:
                for price, col in self.hlines:
                    if lo <= price <= hi:
                        Color(*col)
                        Line(points=[x0, Y(price), x0 + pw, Y(price)], width=1, dash_length=dp(4), dash_offset=dp(3))
            # --- giá hiện tại
            if self.offset == 0:
                last = vis[-1].close
                Color(*BLUE)
                Line(points=[x0, Y(last), x0 + pw, Y(last)], width=1, dash_length=dp(2), dash_offset=dp(2))
                Rectangle(pos=(x0 + pw, Y(last) - dp(7)), size=(dp(self.RM), dp(14)))
                self._text(fp(last), x0 + pw + dp(3), Y(last), 9, (1, 1, 1, 1))
            # --- chấm vào/ra lệnh
            if self.show_markers and self.events:
                self._markers(vis, times, xs, Y, step)

    def _markers(self, vis, times, xs, Y, step):
        r = dp(6)
        pos = {}
        marks = []
        for ev in self.events:
            if ev.time >= times[-1] + step and self.offset > 0:
                continue
            i = bisect_right(times, ev.time) - 1
            if i < 0:
                continue
            marks.append((ev, xs[i], Y(ev.price)))
            if ev.pos_id:
                pos.setdefault(ev.pos_id, {})[ev.kind] = (xs[i], Y(ev.price), ev)
        # đường nối vào -> ra
        for d in pos.values():
            if "open" in d and "close" in d:
                ox, oy, _ = d["open"]
                cx, cy, ce = d["close"]
                lc = UP if ce.profit >= 0 else DOWN
                Color(lc[0], lc[1], lc[2], 0.85)
                Line(points=[ox, oy, cx, cy], width=1, dash_length=dp(3), dash_offset=dp(3))
        for ev, x, y in marks:
            if ev.kind == "open":
                col = UP if ev.side == "buy" else DOWN
                dy = -2 * r if ev.side == "buy" else 2 * r
                pts = [x - r, y + dy, x + r, y + dy, x, y]
                Color(*col)
                Triangle(points=pts)
                Color(1, 1, 1, 0.9)
                Line(points=pts, close=True, width=1)
            elif ev.kind == "close":
                Color(*(UP if ev.profit >= 0 else DOWN))
                Ellipse(pos=(x - r * 0.8, y - r * 0.8), size=(r * 1.6, r * 1.6))
                Color(1, 1, 1, 0.9)
                Line(circle=(x, y, r * 0.8), width=1)
            else:
                Color(0.75, 0.78, 0.84, 1)
                Quad(points=[x, y + r * 0.8, x + r * 0.8, y, x, y - r * 0.8, x - r * 0.8, y])
            self._hits.append((x, y, ev))

    # ---- chạm vào chấm
    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            touch.grab(self)
            touch.ud["pyea_start"] = touch.pos
        return super().on_touch_down(touch)

    def on_touch_up(self, touch):
        if touch.grab_current is self:
            touch.ungrab(self)
            sx, sy = touch.ud.get("pyea_start", touch.pos)
            if abs(touch.x - sx) < dp(12) and abs(touch.y - sy) < dp(12):
                self._tap(touch.x, touch.y)
            return True
        return super().on_touch_up(touch)

    def _tap(self, x, y):
        best, bd = None, (dp(28)) ** 2
        for hx, hy, ev in self._hits:
            d = (hx - x) ** 2 + (hy - y) ** 2
            if d <= bd:
                best, bd = ev, d
        if best is not None and self.on_tap:
            self.on_tap(best)


class LineChart(Widget):
    def __init__(self, color=BLUE, **kw):
        super().__init__(**kw)
        self.values, self.base, self.color = [], None, color
        self.bind(pos=self.redraw, size=self.redraw)

    def update(self, values, base=None):
        self.values = values or []
        self.base = base
        self.redraw()

    def redraw(self, *_):
        self.canvas.clear()
        with self.canvas:
            Color(*BG2)
            Rectangle(pos=self.pos, size=self.size)
            v = self.values[-300:]
            x0, y0 = self.pos
            w, h = self.size
            if len(v) < 2 or w < 20 or h < 20:
                return
            hi, lo = max(v), min(v)
            if self.base is not None:
                hi, lo = max(hi, self.base), min(lo, self.base)
            if hi <= lo:
                hi, lo = lo + 1e-9, lo - 1e-9
            m = dp(6)

            def Y(p):
                return y0 + m + (p - lo) / (hi - lo) * (h - 2 * m)
            step = w / (len(v) - 1)
            if self.base is not None:
                Color(*MUTED)
                Line(points=[x0, Y(self.base), x0 + w, Y(self.base)], width=1, dash_length=dp(4), dash_offset=dp(3))
            Color(*(UP if v[-1] >= v[0] else DOWN))
            Line(points=[c for i, p in enumerate(v) for c in (x0 + i * step, Y(p))], width=dp(1.2))


# ---------------------------------------------------------------- form tham số
class ParamForm(BoxLayout):
    """Sinh form nhập tham số từ dict[str, Input]."""

    def __init__(self, inputs, values=None, **kw):
        super().__init__(orientation="vertical", size_hint_y=None, spacing=dp(4), **kw)
        self.bind(minimum_height=self.setter("height"))
        self.inputs = inputs
        self.ctrl = {}
        values = values or {}
        prev = object()
        for key, inp in inputs.items():
            if inp.group != prev:
                prev = inp.group
                if inp.group:
                    self.add_widget(flabel(inp.group, 12, AMBER, bold=True, size_hint_y=None, height=dp(30)))
            self.add_widget(self._row(key, inp, values.get(key, inp.default)))

    def _row(self, key, inp, value):
        h = 70 if inp.help else 56
        row = Panel(bg=PANEL, size_hint_y=None, height=dp(h), padding=[dp(8), dp(4)], spacing=dp(8))
        title = "[b]%s[/b]" % escape_markup(inp.label or key)
        if inp.help:
            title += "\n[size=10sp][color=%s]%s[/color][/size]" % (hexc(MUTED), escape_markup(inp.help))
        row.add_widget(flabel(title, 13, TEXT, size_hint_x=0.58))
        if inp.kind == "bool":
            c = Switch(active=bool(value), size_hint_x=0.42)
        elif inp.kind == "choice":
            c = Spinner(text=str(value), values=[str(x) for x in inp.choices], size_hint_x=0.42,
                        font_size=sp(13), background_normal="", background_color=PANEL2, color=TEXT)
        else:
            c = TextInput(text=str(inp.display(value)), multiline=False, write_tab=False, size_hint_x=0.42,
                          font_size=sp(14), background_color=PANEL2, foreground_color=TEXT,
                          cursor_color=TEXT, hint_text_color=MUTED, password=bool(inp.secret),
                          padding=[dp(8), dp(12), dp(8), dp(6)])
        self.ctrl[key] = c
        row.add_widget(c)
        return row

    @staticmethod
    def _raw(c):
        if isinstance(c, Switch):
            return c.active
        return c.text

    def read(self):
        """Trả về (values, errors)."""
        vals, errs = {}, []
        for key, inp in self.inputs.items():
            try:
                vals[key] = inp.coerce(self._raw(self.ctrl[key]))
            except ValueError as e:
                errs.append("%s: %s" % (inp.label or key, e))
        return vals, errs

    def set_values(self, values):
        for key, inp in self.inputs.items():
            c = self.ctrl[key]
            v = values.get(key, inp.default)
            if isinstance(c, Switch):
                c.active = bool(v)
            elif isinstance(c, Spinner):
                c.text = str(v)
            else:
                c.text = str(inp.display(v))

    def reset(self):
        self.set_values({})
