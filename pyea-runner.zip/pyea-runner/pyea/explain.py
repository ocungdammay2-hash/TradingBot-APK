"""Giải thích 1 điểm vào/ra lệnh (TradeEvent) thành các mục văn bản để hiện trong popup.
Không phụ thuộc Kivy -> test được."""
import time

SOURCE_LABEL = {
    "bot": "Thuật toán của bot", "ai": "Tín hiệu từ AI (qua bot)", "sl": "Stop Loss (tự động)",
    "tp": "Take Profit (tự động)", "manual": "Người dùng (thủ công)",
    "risk": "Quản lý rủi ro (ngưỡng lỗ tối đa)", "stop": "Dừng bot",
}
KIND_LABEL = {"open": "VÀO LỆNH", "close": "THOÁT LỆNH", "note": "TÍN HIỆU / GHI CHÚ", "pending": "ĐẶT LỆNH CHỜ", "cancel": "HUỶ / HẾT HẠN LỆNH CHỜ"}


def _num(v):
    if isinstance(v, bool):
        return "có" if v else "không"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if abs(v) >= 1000:
            return "{:,.2f}".format(v)
        return "%.6g" % v
    return str(v)


def _kv(d, indent="  "):
    if not d:
        return indent + "(không có)"
    return "\n".join("%s%s: %s" % (indent, k, _num(v)) for k, v in d.items())


def _t(ts):
    try:
        return time.strftime("%H:%M:%S %d/%m", time.localtime(ts))
    except (OverflowError, OSError, ValueError, TypeError):
        return "?"


def event_title(ev):
    side = {"buy": "MUA", "sell": "BÁN"}.get(ev.side, "")
    if ev.kind == "note":
        return "Tín hiệu @ %s" % _num(ev.price)
    return "%s %s @ %s" % (KIND_LABEL.get(ev.kind, ev.kind), side, _num(ev.price))


def find_open_event(ev, events):
    for e in events or []:
        if e.kind == "open" and e.pos_id == ev.pos_id and e.pos_id:
            return e
    return None


def describe_event(ev, events=None):
    """Trả về list (tiêu đề mục, nội dung)."""
    out = []
    head = "%s\nThời điểm thị trường: %s" % (event_title(ev), _t(ev.time))
    if ev.volume:
        head += "\nKhối lượng: %s" % _num(ev.volume)
    if ev.kind == "close":
        head += "\nLãi/lỗ: %+.4f" % ev.profit
    out.append(("Tóm tắt", head))
    out.append(("Nguồn quyết định", SOURCE_LABEL.get(ev.source, ev.source)))
    out.append(("Lý do", ev.reason or "(bot không ghi lý do)"))
    out.append(("Điều kiện / thông số kích hoạt", _kv(ev.details)))

    if ev.ai:
        a = ev.ai
        lines = ["Tín hiệu AI #%s - chốt bởi: %s | cách chốt: %s" % (a.get("id", "?"), a.get("by", "?"), a.get("mode", "?")),
                 "Quyết định: %s | tin cậy %s%% | SL %s%% | TP %s%%" % (
                     str(a.get("action", "?")).upper(), _num((a.get("confidence") or 0) * 100),
                     _num(a.get("sl_pct") or 0), _num(a.get("tp_pct") or 0)),
                 "Lý do tổng hợp: %s" % (a.get("reason") or "-")]
        for v in a.get("votes") or []:
            lines.append("  • %s (model %s): %s %s%% - %s" % (
                v.get("agent", "?"), v.get("model", "?"), str(v.get("action", "?")).upper(),
                _num((v.get("confidence") or 0) * 100), v.get("reason", "")))
        out.append(("AI đã đưa ra quyết định như thế nào", "\n".join(lines)))
        disc = a.get("discussion") or []
        if disc:
            out.append(("Trích thảo luận của các AI", "\n\n".join("[%s] %s" % (d.get("agent"), d.get("text")) for d in disc)))

    c = ev.context or {}
    snap = ["Callback: %s | bid %s ask %s" % (c.get("callback", "?"), _num(c.get("bid")), _num(c.get("ask")))]
    lc = c.get("last_closed")
    if lc:
        snap.append("Nến đóng gần nhất: O %s H %s L %s C %s" % (_num(lc["open"]), _num(lc["high"]), _num(lc["low"]), _num(lc["close"])))
    snap.append("Số dư %s | equity %s | lệnh đang mở %s" % (_num(c.get("balance")), _num(c.get("equity")), c.get("open_positions", 0)))
    out.append(("Ảnh chụp thị trường lúc đó", "\n".join(snap)))
    if c.get("indicators"):
        out.append(("Giá trị các đường chỉ báo lúc đó", _kv(c["indicators"])))
    if c.get("params"):
        out.append(("Tham số bot", _kv(c["params"])))

    if ev.kind == "close":
        op = find_open_event(ev, events)
        if op:
            dur = max(0.0, ev.time - op.time)
            out.append(("Lệnh này đã được mở thế nào",
                        "%s @ %s lúc %s (giữ %d phút)\nLý do vào: %s" % (
                            {"buy": "MUA", "sell": "BÁN"}.get(op.side, op.side), _num(op.price), _t(op.time),
                            dur // 60, op.reason or "-")))
    return out


def describe_text(ev, events=None):
    return "\n\n".join("[%s]\n%s" % (t, b) for t, b in describe_event(ev, events))
