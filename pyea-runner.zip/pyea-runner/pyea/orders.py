"""
OrderMixin - toàn bộ xử lý LỆNH của vỏ (gắn vào TradingSession). Bot/giao diện chỉ thấy một giao diện thống nhất,
còn mọi khác biệt giữa các sàn (SL/TP có sẵn hay giả lập, lệnh chờ, bán khống, gộp vị thế...) được vỏ che đi:

  send_order      lệnh thị trường: kiểm tra TRƯỚC khi gửi (chỉ-xem, kill switch, chế độ mã, khối lượng, SL/TP, giá cũ, ký quỹ...)
                  rồi gửi sàn (tuần tự qua một "trade context" như MT5) -> OrderResult có retcode chuẩn hoá
  place_pending   lệnh chờ limit/stop/stop_limit: vỏ tự theo dõi giá (giả lập trong vỏ nên chạy giống nhau trên MỌI sàn)
  close_position  đóng toàn bộ hoặc MỘT PHẦN · modify_position / modify_order / cancel_order
  kill_switch     dừng mọi bot -> huỷ lệnh chờ -> đóng mọi vị thế -> chặn lệnh mới
  cảnh báo giá, margin call / stop-out, sự kiện on_trade cho bot
Quy ước id: lệnh chờ và vị thế dùng CHUNG bộ đếm; khi lệnh chờ khớp, vị thế GIỮ id của lệnh chờ.
"""
import math
import time
import traceback
from dataclasses import replace

from .broker import BrokerError
from .feeds import FeedError
from .sdk import (AccountInfo, OrderResult, PendingOrder, Position, Ret, SymbolInfo, TradeUpdate)
from .shell import (mode_allows, resolve_spec, validate_stops, validate_volume)

SRC_EXTRA = {"kill": "Kill switch", "stopout": "Stop-out", "expired": "Hết hạn"}


class OrderMixin:
    # ------------------------------------------------------------------ tra cứu (bot và giao diện dùng chung)
    def spec(self, symbol):
        return resolve_spec(self.settings, symbol, self.feed, self.broker)

    def symbol_info(self, symbol):
        sym = symbol.strip().upper()
        spec = self.spec(sym)
        t = self.ticks.get(sym)
        if t is None:
            try:
                t = self.get_tick(sym)
            except (FeedError, KeyError, AttributeError):
                t = None
        bid, ask = (t.bid, t.ask) if t else (0.0, 0.0)
        px = (bid + ask) / 2.0 if t else 0.0
        lev = self.account.leverage if self.account else 1.0
        return SymbolInfo(symbol=sym, bid=bid, ask=ask, spread=(ask - bid), digits=spec.digits, tick_size=spec.tick_size,
                          contract_size=spec.contract_size, volume_min=spec.volume_min, volume_max=spec.volume_max,
                          volume_step=spec.volume_step, stops_level=spec.stops_level(px), trade_mode=spec.trade_mode,
                          market_open=bool(t.tradeable) if t else True,
                          leverage=lev, margin_per_unit=(px / lev) if lev else px)

    def account_info(self):
        acc = self.account
        if acc is None:
            return AccountInfo()
        with self.lock:
            eq, used, res = acc.equity(), acc.margin_used(), acc.reserved_margin()
            lvl = acc.margin_level()
            s = self.settings
            return AccountInfo(balance=acc.balance, equity=eq, margin=used, reserved=res, free_margin=eq - used - res,
                               margin_level=lvl or 0.0, leverage=acc.leverage, currency="USD", mode=s["mode"],
                               demo=(s["mode"] != "live") or bool(s.get("testnet")),
                               netting=bool(getattr(self.broker, "netting", False)),
                               trade_allowed=not (self.halted or s.get("read_only")), read_only=bool(s.get("read_only")),
                               halted=self.halted, server_time=self._now())

    def _now(self):
        """Giờ 'server' = giờ của tick gần nhất (giờ thị trường); chưa có tick thì giờ máy."""
        if self.ticks:
            return max(t.time for t in self.ticks.values())
        return time.time()

    def time_info(self):
        now = time.time()
        server = self._now()
        return {"utc": now, "server": server, "skew_s": server - now, "local_offset_s": -time.timezone}

    # ------------------------------------------------------------------ kiểm tra chung
    def _gate(self, symbol, side, closing=False):
        """Điều kiện chặn chung trước khi gửi/đặt lệnh MỚI. -> (retcode, message) hoặc None."""
        s = self.settings
        if self.halted:
            return Ret.TRADE_DISABLED, "Kill switch đang bật - mọi lệnh mới bị chặn (bấm 'Mở lại giao dịch' để tiếp tục)"
        if s.get("read_only") and not closing:
            return Ret.TRADE_DISABLED, "Chế độ CHỈ-XEM (read-only): vỏ không gửi lệnh mới"
        err = mode_allows(self.spec(symbol), side, closing)
        if err:
            return Ret.SYMBOL_MODE, err
        return None

    def _quote(self, symbol):
        """Giá để đặt lệnh. -> (tick, retcode|None, message)."""
        try:
            tick = self.get_tick(symbol)
        except (FeedError, KeyError, AttributeError) as e:
            return None, Ret.NO_QUOTES, "Chưa có giá %s: %s" % (symbol, e)
        if not self.sync:
            stale = float(self.settings.get("stale_after") or 0)
            w = self._tick_wall.get(symbol)
            if stale > 0 and w is not None and time.time() - w > stale:
                return tick, Ret.NO_QUOTES, "Giá %s đã cũ %.0f giây (> %.0f giây) - có thể mất kết nối giá" % (symbol, time.time() - w, stale)
        return tick, None, ""

    def _fail(self, retcode, msg, owner="", symbol="", side="", volume=0.0, price=0.0, request_id="", log=True):
        res = OrderResult(ok=False, retcode=retcode, message=msg, requested_volume=float(volume or 0.0), request_id=request_id)
        if log:
            self.log("Từ chối lệnh %s %s: %s [%s]" % (side or "?", symbol or "?", msg, retcode), "WARN")
        if owner and owner != "manual":
            self._emit(TradeUpdate(kind="order_rejected", symbol=symbol, side=side, volume=float(volume or 0.0), price=price,
                                   source="bot", reason=msg, retcode=retcode, time=self._now(), owner=owner))
        return res

    def _emit(self, upd):
        """Gửi sự kiện cho on_trade của bot chủ lệnh."""
        inst = self.instances.get(upd.owner) if upd.owner else None
        if inst is not None:
            try:
                inst.notify_trade(upd)
            except Exception:
                pass

    # ------------------------------------------------------------------ lệnh thị trường
    def send_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", owner="manual", reason="", details=None, ai=None,
                   ctx=None, request_id="", _pos_id=None, _validate=True, _pending=None):
        symbol = str(symbol).strip().upper()
        side = "buy" if str(side).lower() == "buy" else "sell"
        rid = str(request_id or "")
        if rid:
            hit = self._req_cache.get((owner, rid))
            if hit is not None and time.time() - hit[0] < 120:
                res = replace(hit[1])
                res.message = (res.message + " (request_id trùng - trả lại kết quả cũ, không gửi lại)").strip()
                return res
        res = self._send_market(symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx, rid, _pos_id, _validate, _pending)
        if rid:
            self._req_cache[(owner, rid)] = (time.time(), res)
            for k in [k for k, v in self._req_cache.items() if time.time() - v[0] > 300]:
                self._req_cache.pop(k, None)
        return res

    def _send_market(self, symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx, rid, pos_id, validate, pending):
        try:
            sl, tp = float(sl or 0.0), float(tp or 0.0)
            req_vol = float(volume)
        except (TypeError, ValueError):
            return self._fail(Ret.INVALID_VOLUME, "Khối lượng/SL/TP không phải số", owner, symbol, side, 0.0, 0.0, rid)
        if validate:
            g = self._gate(symbol, side)
            if g:
                return self._fail(g[0], g[1], owner, symbol, side, req_vol, 0.0, rid)
        spec = self.spec(symbol)
        volume, err = validate_volume(spec, req_vol)
        if err:
            return self._fail(Ret.INVALID_VOLUME, err, owner, symbol, side, req_vol, 0.0, rid)
        tick, rc, msg = self._quote(symbol)
        if rc:
            return self._fail(rc, msg, owner, symbol, side, volume, 0.0, rid)
        if not tick.tradeable:
            return self._fail(Ret.MARKET_CLOSED, "Thị trường %s đang đóng cửa (sàn báo không giao dịch được)" % symbol, owner, symbol, side, volume, 0.0, rid)
        ref = tick.ask if side == "buy" else tick.bid
        if validate:
            err = validate_stops(spec, side, ref, sl, tp)
            if err:
                return self._fail(Ret.INVALID_STOPS, err, owner, symbol, side, volume, ref, rid)
        with self.lock:
            free = self.account.equity() - self.account.margin_used() - self.account.reserved_margin()
            need = volume * ref / self.account.leverage
            if need > free + 1e-9:
                return self._fail(Ret.INSUFFICIENT_MARGIN, "Không đủ ký quỹ: cần %.4f, khả dụng %.4f (đòn bẩy x%g)" % (
                    need, free, self.account.leverage), owner, symbol, side, volume, ref, rid)
            opposite = any(p.symbol == symbol and p.side != side for p in self.account.positions.values())
        b = self.broker
        if b is not None:
            if side == "sell" and not b.supports_short:
                return self._fail(Ret.NOT_SUPPORTED, "LIVE spot không hỗ trợ bán khống (dùng binance_futures hoặc oanda)", owner, symbol, side, volume, ref, rid)
            if getattr(b, "netting", False) and opposite:
                return self._fail(Ret.HEDGE_NOT_ALLOWED, "Sàn gộp vị thế 1 chiều/mã: không giữ đồng thời mua và bán %s" % symbol,
                                  owner, symbol, side, volume, ref, rid)
        price = ref
        with self._trade_lock:                                  # 1 "trade context": mọi lệnh gửi sàn xếp hàng tuần tự
            if b is not None:
                try:
                    fill = b.market_order(symbol, side, volume)
                    self._order_fail = 0
                except BrokerError as e:
                    self.reconcile_due(2.0)                          # kết quả có thể không rõ (timeout) -> đối chiếu với sàn sớm
                    self._order_failed("Đặt lệnh %s %s thất bại: %s" % (side, symbol, e))
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối/lỗi: %s" % e, requested_volume=volume,
                                       request_id=rid)
                price, volume = fill.price, fill.qty
            with self.lock:
                pos = self.account.open(symbol, side, volume, price, sl, tp, comment, tick.time, owner, pos_id=pos_id)
        slip = abs(price - ref) / ref * 100.0 if ref else 0.0
        mx = float(self.settings.get("max_slippage_pct") or 0.0)
        if b is not None and mx > 0 and slip > mx:
            self.alarm("Trượt giá lớn %s" % symbol, "Khớp %.8g so với giá lúc gửi %.8g (%.3f%% > %.3f%%)" % (price, ref, slip, mx))
        src = "manual" if owner == "manual" else ("ai" if ai else "bot")
        auto = reason or (comment and "Vào lệnh: %s" % comment) or (
            "Đặt lệnh thủ công" if owner == "manual" else "Bot gửi lệnh %s (bot không ghi lý do)" % side)
        d = dict(details or {})
        d.setdefault("SL", sl or "không đặt")
        d.setdefault("TP", tp or "không đặt")
        if pending is not None:
            d.setdefault("lệnh chờ", "%s #%d @ %.8g" % (pending.kind, pending.id, pending.price))
        if slip:
            d.setdefault("trượt giá %", round(slip, 5))
        self.add_event("open", symbol, price, side, volume, pos.id, src, auto, d, ai, 0.0, ctx, owner)
        self.log("MỞ #%d %s %s %.8g @ %.8g | SL=%.8g TP=%.8g | %s [%s]" % (pos.id, side.upper(), symbol, volume, price, sl, tp, auto, owner))
        self.notify("Mở lệnh %s %s" % (side.upper(), symbol), "%.8g @ %.8g · %s" % (volume, price, auto))
        self._emit(TradeUpdate(kind="position_opened", id=pos.id, symbol=symbol, side=side, volume=volume, price=price, sl=sl, tp=tp,
                               source=src, reason=auto, retcode=Ret.OK, time=tick.time, owner=owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã khớp %s %.8g %s @ %.8g" % (side, volume, symbol, price),
                           position=replace(pos), price=price, volume=volume, requested_volume=req_vol, slippage=slip, request_id=rid)

    def open_position(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", owner="manual", reason="", details=None, ai=None, ctx=None):
        """Tương thích cũ: trả về OrderResult (đúng = khớp; dùng như Position nhờ __getattr__)."""
        return self.send_order(symbol, side, volume, sl, tp, comment, owner, reason, details, ai, ctx)

    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", request_id=""):
        """Đặt lệnh THỦ CÔNG từ giao diện (thị trường)."""
        return self.send_order(symbol, side, volume, sl, tp, comment, "manual", "Đặt lệnh thủ công từ ứng dụng",
                               {"nguồn": "người dùng"}, None, None, request_id)

    # ------------------------------------------------------------------ lệnh chờ
    def _validate_pending(self, symbol, side, kind, price, stop_price, tick):
        ask, bid = tick.ask, tick.bid
        if kind == "limit":
            if side == "buy" and price >= ask:
                return "Buy limit phải ĐẶT DƯỚI giá ask %.8g (đang đặt %.8g)" % (ask, price)
            if side == "sell" and price <= bid:
                return "Sell limit phải ĐẶT TRÊN giá bid %.8g (đang đặt %.8g)" % (bid, price)
        elif kind == "stop":
            if side == "buy" and price <= ask:
                return "Buy stop phải ĐẶT TRÊN giá ask %.8g (đang đặt %.8g)" % (ask, price)
            if side == "sell" and price >= bid:
                return "Sell stop phải ĐẶT DƯỚI giá bid %.8g (đang đặt %.8g)" % (bid, price)
        elif kind == "stop_limit":
            if stop_price <= 0:
                return "Stop-limit cần giá kích hoạt (stop_price)"
            if side == "buy":
                if stop_price <= ask:
                    return "Buy stop-limit: giá kích hoạt %.8g phải TRÊN ask %.8g" % (stop_price, ask)
                if price > stop_price:
                    return "Buy stop-limit: giá limit %.8g không được cao hơn giá kích hoạt %.8g" % (price, stop_price)
            else:
                if stop_price >= bid:
                    return "Sell stop-limit: giá kích hoạt %.8g phải DƯỚI bid %.8g" % (stop_price, bid)
                if price < stop_price:
                    return "Sell stop-limit: giá limit %.8g không được thấp hơn giá kích hoạt %.8g" % (price, stop_price)
        else:
            return "Loại lệnh chờ không hợp lệ: %s" % kind
        return None

    def place_pending(self, symbol, side, kind, volume, price, stop_price=0.0, sl=0.0, tp=0.0, comment="", owner="manual",
                      expiration=0.0, reason="", details=None, ai=None, ctx=None):
        symbol = str(symbol).strip().upper()
        side = "buy" if str(side).lower() == "buy" else "sell"
        try:
            price, stop_price = float(price), float(stop_price or 0.0)
            sl, tp, expiration = float(sl or 0.0), float(tp or 0.0), float(expiration or 0.0)
            req_vol = float(volume)
        except (TypeError, ValueError):
            return self._fail(Ret.INVALID_PRICE, "Giá/khối lượng không phải số", owner, symbol, side, 0.0)
        g = self._gate(symbol, side)
        if g:
            return self._fail(g[0], g[1], owner, symbol, side, req_vol, price)
        spec = self.spec(symbol)
        vol, err = validate_volume(spec, req_vol)
        if err:
            return self._fail(Ret.INVALID_VOLUME, err, owner, symbol, side, req_vol, price)
        if not math.isfinite(price) or price <= 0:
            return self._fail(Ret.INVALID_PRICE, "Giá đặt phải > 0", owner, symbol, side, vol, price)
        tick, rc, msg = self._quote(symbol)
        if tick is None:
            return self._fail(rc, msg, owner, symbol, side, vol, price)
        err = self._validate_pending(symbol, side, kind, price, stop_price, tick)
        if err:
            return self._fail(Ret.INVALID_PRICE, err, owner, symbol, side, vol, price)
        if expiration and expiration <= tick.time:
            return self._fail(Ret.INVALID_EXPIRATION, "Thời hạn lệnh chờ đã qua", owner, symbol, side, vol, price)
        err = validate_stops(spec, side, price, sl, tp)
        if err:
            return self._fail(Ret.INVALID_STOPS, err, owner, symbol, side, vol, price)
        with self.lock:
            acc = self.account
            free = acc.equity() - acc.margin_used() - acc.reserved_margin()
            need = vol * price / acc.leverage
            if need > free + 1e-9:
                return self._fail(Ret.INSUFFICIENT_MARGIN, "Không đủ ký quỹ để giữ chỗ cho lệnh chờ: cần %.4f, khả dụng %.4f" % (need, free),
                                  owner, symbol, side, vol, price)
            order = acc.add_pending(PendingOrder(id=0, symbol=symbol, side=side, kind=kind, volume=vol, price=price,
                                                 stop_price=stop_price, sl=sl, tp=tp, comment=comment, owner=owner,
                                                 created=tick.time, expiration=expiration, reason=reason))
        label = {"limit": "Limit", "stop": "Stop", "stop_limit": "Stop-limit"}[kind]
        txt = reason or "Đặt lệnh chờ %s %s" % (side.upper(), label)
        d = dict(details or {})
        d.update({"loại": "%s %s" % (side, kind), "giá đặt": price, "SL": sl or "không đặt", "TP": tp or "không đặt",
                  "hết hạn": ("%s" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(expiration))) if expiration else "đến khi huỷ"})
        if kind == "stop_limit":
            d["giá kích hoạt"] = stop_price
        self.add_event("pending", symbol, price, side, vol, order.id, "manual" if owner == "manual" else ("ai" if ai else "bot"),
                       txt, d, ai, 0.0, ctx, owner)
        self.log("LỆNH CHỜ #%d %s %s %s %.8g @ %.8g%s | %s [%s]" % (order.id, side.upper(), label, symbol, vol, price,
                 (" (kích hoạt %.8g)" % stop_price) if kind == "stop_limit" else "", txt, owner))
        self._emit(TradeUpdate(kind="order_placed", id=order.id, symbol=symbol, side=side, volume=vol, price=price, sl=sl, tp=tp,
                               source="bot" if owner != "manual" else "manual", reason=txt, retcode=Ret.PLACED, time=tick.time, owner=owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.PLACED, message="Đã đặt lệnh chờ #%d" % order.id, order=replace(order), price=price,
                           volume=vol, requested_volume=req_vol)

    def cancel_order(self, order_id, source="manual", reason="", ctx=None):
        with self.lock:
            o = self.account.pending.pop(int(order_id), None)
        if o is None:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s" % order_id)
        label = SRC_EXTRA.get(source) or {"manual": "Thủ công", "bot": "Bot"}.get(source, source)
        why = reason or "Huỷ lệnh chờ (%s)" % label
        self.add_event("cancel", o.symbol, o.price, o.side, o.volume, o.id, source if source in ("manual", "bot", "ai") else "manual",
                       why, {"loại": "%s %s" % (o.side, o.kind), "giá đặt": o.price}, None, 0.0, ctx, o.owner)
        self.log("HUỶ lệnh chờ #%d %s %s %s | %s" % (o.id, o.side.upper(), o.kind, o.symbol, why))
        self._emit(TradeUpdate(kind="order_expired" if source == "expired" else "order_cancelled", id=o.id, symbol=o.symbol, side=o.side,
                               volume=o.volume, price=o.price, source=source, reason=why, time=self._now(), owner=o.owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã huỷ lệnh chờ #%d" % o.id, order=o, price=o.price, volume=o.volume)

    def cancel_all_orders(self, source="manual", reason="", owner=None, symbol=None):
        with self.lock:
            ids = [o.id for o in self.account.pending.values()
                   if (owner is None or o.owner == owner) and (symbol is None or o.symbol == symbol)]
        return sum(1 for i in ids if self.cancel_order(i, source, reason).ok)

    def modify_order(self, order_id, price=None, sl=None, tp=None, expiration=None, stop_price=None):
        with self.lock:
            o = self.account.pending.get(int(order_id))
            if o is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có lệnh chờ #%s" % order_id)
            o2 = replace(o)
        try:
            if price is not None:
                o2.price = float(price)
            if stop_price is not None:
                o2.stop_price = float(stop_price)
            if sl is not None:
                o2.sl = float(sl or 0.0)
            if tp is not None:
                o2.tp = float(tp or 0.0)
            if expiration is not None:
                o2.expiration = float(expiration or 0.0)
        except (TypeError, ValueError):
            return OrderResult(ok=False, retcode=Ret.INVALID_PRICE, message="Giá trị không phải số")
        tick, rc, msg = self._quote(o.symbol)
        if tick is None:
            return OrderResult(ok=False, retcode=rc, message=msg)
        err = None if o2.armed else self._validate_pending(o.symbol, o.side, o.kind, o2.price, o2.stop_price, tick)
        rc = Ret.INVALID_PRICE
        if err is None:
            err = validate_stops(self.spec(o.symbol), o.side, o2.price, o2.sl, o2.tp)
            rc = Ret.INVALID_STOPS
        if err is None and o2.expiration and o2.expiration <= tick.time:
            err, rc = "Thời hạn lệnh chờ đã qua", Ret.INVALID_EXPIRATION
        if err:
            self.log("Từ chối sửa lệnh chờ #%d: %s" % (o.id, err), "WARN")
            return OrderResult(ok=False, retcode=rc, message=err)
        with self.lock:
            cur = self.account.pending.get(o.id)
            if cur is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Lệnh chờ #%d vừa khớp/bị huỷ" % o.id)
            cur.price, cur.stop_price, cur.sl, cur.tp, cur.expiration = o2.price, o2.stop_price, o2.sl, o2.tp, o2.expiration
        self.log("Sửa lệnh chờ #%d: giá=%.8g SL=%.8g TP=%.8g" % (o.id, o2.price, o2.sl, o2.tp))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã sửa lệnh chờ #%d" % o.id, order=replace(o2), price=o2.price, volume=o2.volume)

    def _check_pending(self, tick):
        """Gọi mỗi tick (sau khi mark): hết hạn -> huỷ; chạm giá -> khớp (limit/stop) hoặc kích hoạt (stop_limit)."""
        with self.lock:
            orders = [o for o in self.account.pending.values() if o.symbol == tick.symbol]
        for o in orders:
            if o.expiration and tick.time >= o.expiration:
                self.cancel_order(o.id, "expired", "Lệnh chờ hết hạn (hết hạn lúc %s)" % time.strftime("%H:%M:%S %d/%m", time.gmtime(o.expiration)))
                continue
            ask, bid = tick.ask, tick.bid
            if o.kind == "stop_limit" and not o.armed:
                if (o.side == "buy" and ask >= o.stop_price) or (o.side == "sell" and bid <= o.stop_price):
                    with self.lock:
                        o.armed = True
                    self.log("Lệnh chờ #%d: giá kích hoạt %.8g đã chạm -> chuyển thành limit @ %.8g" % (o.id, o.stop_price, o.price))
                continue
            if o.kind in ("limit", "stop_limit"):
                hit = (o.side == "buy" and ask <= o.price) or (o.side == "sell" and bid >= o.price)
            else:
                hit = (o.side == "buy" and ask >= o.price) or (o.side == "sell" and bid <= o.price)
            if hit:
                self._fill_pending(o, tick)

    def _fill_pending(self, o, tick):
        with self.lock:
            if self.account.pending.pop(o.id, None) is None:
                return
        inst = self.instances.get(o.owner)
        ctx = inst._context() if inst is not None else None
        why = o.reason or "Lệnh chờ %s %s #%d khớp" % (o.side, o.kind, o.id)
        px = tick.ask if o.side == "buy" else tick.bid
        res = self.send_order(o.symbol, o.side, o.volume, o.sl, o.tp, o.comment, o.owner,
                              "%s (giá %.8g, đặt @ %.8g)" % (why, px, o.price),
                              {"lệnh chờ": "%s #%d" % (o.kind, o.id), "giá đặt": o.price}, None, ctx, _pos_id=o.id, _validate=False,
                              _pending=o)
        if not res.ok:
            self.add_event("cancel", o.symbol, o.price, o.side, o.volume, o.id, "manual" if o.owner == "manual" else "bot",
                           "Lệnh chờ không khớp được: %s" % res.message, {"retcode": res.retcode}, None, 0.0, ctx, o.owner)
            self.log("Lệnh chờ #%d bị huỷ khi khớp: %s" % (o.id, res.message), "WARN")
            return
        self._emit(TradeUpdate(kind="order_filled", id=o.id, symbol=o.symbol, side=o.side, volume=res.volume, price=res.price,
                               sl=o.sl, tp=o.tp, source="bot" if o.owner != "manual" else "manual", reason=why, retcode=Ret.OK,
                               time=tick.time, owner=o.owner))

    # ------------------------------------------------------------------ đóng / sửa vị thế
    def close_position(self, pos_id, source="bot", reason="", details=None, ai=None, ctx=None, volume=None):
        """Đóng toàn bộ hoặc MỘT PHẦN (volume < khối lượng vị thế). Trả về OrderResult (đúng = đã đóng)."""
        with self.lock:
            pos = self.account.positions.get(pos_id)
        if pos is None:
            return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s" % pos_id)
        g = self._gate(pos.symbol, "sell" if pos.side == "buy" else "buy", closing=True)
        if g and g[0] == Ret.SYMBOL_MODE and self.spec(pos.symbol).trade_mode == "disabled":
            return OrderResult(ok=False, retcode=g[0], message=g[1])
        try:
            tick = self.get_tick(pos.symbol)
        except (FeedError, KeyError):
            return OrderResult(ok=False, retcode=Ret.NO_QUOTES, message="Chưa có giá %s" % pos.symbol)
        if time.time() < self._close_retry.get(pos_id, 0):
            return OrderResult(ok=False, retcode=Ret.REJECTED, message="Đang chờ thử lại sau lỗi đóng lệnh trước")
        vol = pos.volume
        if volume is not None:
            vol, err = validate_volume(self.spec(pos.symbol), volume)
            if err and vol <= 0:
                return OrderResult(ok=False, retcode=Ret.INVALID_VOLUME, message=err)
            vol = min(vol, pos.volume)
        partial = vol < pos.volume - 1e-12
        price = tick.bid if pos.side == "buy" else tick.ask
        with self._trade_lock:
            if self.broker is not None:
                try:
                    price = self.broker.market_order(pos.symbol, "sell" if pos.side == "buy" else "buy", vol, reduce_only=True).price
                    self._order_fail = 0
                except BrokerError as e:
                    self.reconcile_due(2.0)
                    self._close_retry[pos_id] = time.time() + 10
                    self._order_failed("Đóng lệnh #%d thất bại: %s (thử lại sau 10s)" % (pos_id, e))
                    return OrderResult(ok=False, retcode=Ret.REJECTED, message="Sàn từ chối/lỗi: %s" % e)
            with self.lock:
                if pos_id not in self.account.positions:          # luồng khác đã đóng
                    return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Vị thế #%s vừa được đóng" % pos_id)
                tr = self.account.reduce(pos_id, vol, price, tick.time, source) if partial else self.account.close(pos_id, price, tick.time, source)
        from .engine import SRC_LABEL
        label = SRC_LABEL.get(source) or SRC_EXTRA.get(source) or source
        tr.reason = label
        d = dict(details or {})
        d.setdefault("giá vào", pos.open_price)
        d.setdefault("giá ra", price)
        if partial:
            d.setdefault("đóng một phần", "%.8g / %.8g" % (vol, pos.volume))
        self.add_event("close", pos.symbol, price, pos.side, vol, pos.id, "ai" if (ai and source == "bot") else source,
                       reason or ("Bot đóng lệnh (bot không ghi lý do)" if source == "bot" else label), d, ai, tr.profit, ctx, pos.owner)
        self.log("%s #%d %s %s %.8g @ %.8g | %s | P/L %+.4f | %s" % ("ĐÓNG MỘT PHẦN" if partial else "ĐÓNG", tr.id, tr.side.upper(), pos.symbol,
                                                                       vol, price, label, tr.profit, reason or "-"))
        self.notify("Đóng lệnh %s %s (%s)" % (tr.side.upper(), pos.symbol, label), "P/L %+.4f @ %.8g" % (tr.profit, price))
        self._emit(TradeUpdate(kind="position_reduced" if partial else "position_closed", id=pos.id, symbol=pos.symbol, side=pos.side,
                               volume=vol, price=price, profit=tr.profit, source=source, reason=reason or label, retcode=Ret.OK,
                               time=tick.time, owner=pos.owner))
        self._save_trade(tr)
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã đóng %s%.8g @ %.8g" % ("một phần " if partial else "", vol, price),
                           price=price, volume=vol, profit=tr.profit)

    def close_all(self, source, reason, symbol=None, owner=None):
        with self.lock:
            ids = [p.id for p in self.account.positions.values()
                   if (symbol is None or p.symbol == symbol) and (owner is None or p.owner == owner)]
        return sum(1 for pid in ids if self.close_position(pid, source, reason).ok)

    def modify_position(self, pos_id, sl=None, tp=None):
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Không có vị thế #%s" % pos_id)
            t = self.ticks.get(p.symbol)
            price = (t.bid if p.side == "buy" else t.ask) if t else p.open_price
            try:
                nsl = p.sl if sl is None else float(sl or 0.0)
                ntp = p.tp if tp is None else float(tp or 0.0)
            except (TypeError, ValueError):
                return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message="SL/TP không phải số")
            side = p.side
        err = validate_stops(self.spec(p.symbol), side, price, nsl, ntp)
        if err:
            self.log("Từ chối sửa #%d: %s" % (pos_id, err), "WARN")
            return OrderResult(ok=False, retcode=Ret.INVALID_STOPS, message=err)
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return OrderResult(ok=False, retcode=Ret.NOT_FOUND, message="Vị thế #%s vừa đóng" % pos_id)
            p.sl, p.tp = nsl, ntp
        self.log("Sửa #%d: SL=%.8g TP=%.8g" % (pos_id, nsl, ntp))
        self._emit(TradeUpdate(kind="position_modified", id=pos_id, symbol=p.symbol, side=p.side, volume=p.volume, price=price,
                               sl=nsl, tp=ntp, source="bot" if p.owner != "manual" else "manual", retcode=Ret.OK, time=self._now(),
                               owner=p.owner))
        self._save_state()
        return OrderResult(ok=True, retcode=Ret.OK, message="Đã sửa SL/TP", price=price, volume=p.volume)

    # ------------------------------------------------------------------ an toàn
    def request_kill(self, reason="Người dùng bấm Kill switch"):
        self._cmds.put(("kill", reason))

    def kill_switch(self, reason="Kill switch"):
        """Thoát hiểm: chặn lệnh mới -> dừng mọi bot (để không mở lại) -> huỷ lệnh chờ -> đóng mọi vị thế."""
        self.halted = True
        self.log("KILL SWITCH: %s" % reason, "ERROR")
        for inst in list(self.instances.values()):
            inst.request_stop()
        n_o = self.cancel_all_orders("kill", "Kill switch: " + reason)
        n_p = self.close_all("kill", "Kill switch: " + reason)
        self.alarm("KILL SWITCH đã chạy", "Đã dừng mọi bot, huỷ %d lệnh chờ, đóng %d vị thế. Giao dịch bị khoá tới khi bạn mở lại." % (n_o, n_p))
        self._save_state()
        return n_p, n_o

    def resume_trading(self):
        if self.halted:
            self.halted = False
            self.log("Đã MỞ LẠI giao dịch sau Kill switch (các bot đã dừng cần bật lại thủ công)", "WARN")
        return True

    def reset_paper(self, balance=None):
        """Đặt lại tài khoản GIẢ LẬP về số dư ban đầu (xoá vị thế, lệnh chờ, lịch sử). Không dùng cho live."""
        if self.settings["mode"] == "live":
            return False
        from .engine import Account
        s = self.settings
        with self.lock:
            self.account = Account(float(balance or s["initial_balance"]), s["commission_pct"], s["leverage"])
            self.equity_hist.clear()
        self.log("ĐẶT LẠI tài khoản giả lập: số dư %.2f" % self.account.balance, "WARN")
        self._save_state()
        return True

    def _check_margin(self):
        """Margin call (cảnh báo) và stop-out (tự đóng vị thế lỗ nặng nhất)."""
        acc = self.account
        if acc is None:
            return
        with self.lock:
            lvl = acc.margin_level()
        if lvl is None:
            self._margin_alerted = False
            return
        s = self.settings
        mc, so = float(s.get("margin_call_level") or 0), float(s.get("stop_out_level") or 0)
        if so > 0 and lvl <= so:
            with self.lock:
                worst = min(acc.positions.values(), key=lambda p: p.profit, default=None)
            if worst is not None:
                self.close_position(worst.id, "stopout", "Stop-out: mức ký quỹ %.1f%% ≤ %.1f%% - đóng vị thế lỗ nặng nhất (#%d, %+.4f)" % (
                    lvl, so, worst.id, worst.profit))
            return
        if mc > 0 and lvl <= mc:
            if not self._margin_alerted:
                self._margin_alerted = True
                self.alarm("Margin call", "Mức ký quỹ %.1f%% ≤ %.1f%%. Hãy giảm vị thế hoặc nạp thêm vốn." % (lvl, mc))
        elif lvl > mc * 1.1:
            self._margin_alerted = False

    # ------------------------------------------------------------------ cảnh báo giá (tab Alerts của MT5)
    def _check_alerts(self, tick):
        if self.alerts is None:
            return
        for al, text in self.alerts.check(tick):
            self.log(text, "WARN")
            self.add_event("note", tick.symbol, tick.mid, "", 0.0, 0, "manual", text,
                           {"cảnh báo": al.describe(), "giá": tick.mid}, None, 0.0, None, "alert")
            self.alarm("Cảnh báo giá %s" % tick.symbol, text)

    def alert_add(self, symbol, kind, value, note="", repeat=False):
        sym = symbol.strip().upper()
        ref = 0.0
        if kind == "pct":
            try:
                ref = self.get_tick(sym).mid
            except (FeedError, KeyError, AttributeError):
                raise ValueError("Cảnh báo %% cần có giá hiện tại của %s" % sym)
        a = self.alerts.add(sym, kind, value, ref, note, repeat)
        self.log("Đặt cảnh báo giá #%d: %s" % (a.id, a.describe()))
        return a

    def alert_remove(self, alert_id):
        return self.alerts.remove(alert_id)

    # ------------------------------------------------------------------ chống treo / sức khoẻ
    def _check_hung(self):
        lim = float(self.settings.get("bot_callback_timeout") or 0)
        if lim <= 0:
            return
        now = time.monotonic()
        for inst in list(self.instances.values()):
            if inst.status == "running" and inst.cb_started and not inst.hung and now - inst.cb_started > lim:
                inst.mark_hung(now - inst.cb_started)

    def health(self):
        from .shell import connection_health
        h = connection_health(self.needed_symbols() if self.account is not None else [], self._feed_fail, self._tick_wall,
                              float(self.settings.get("stale_after") or 0))
        h["failing_total"] = sum(1 for v in self._feed_fail.values() if v > 0)
        return h
