"""
Engine kiểu MT5: MỘT phiên giao dịch (TradingSession) có tài khoản chung, nhiều tài sản và nhiều bot.

  TradingSession : tài khoản chung (paper hoặc live), vòng lấy giá cho mọi mã cần thiết (Market Watch +
                   bot + vị thế + biểu đồ), kiểm tra SL/TP/ngưỡng lỗ, đặt/đóng/sửa lệnh (thủ công hoặc từ bot),
                   ghi sự kiện kèm lý do, lưu/khôi phục sổ lệnh.
  BotRunner      : 1 "bot gắn vào tài sản" (như EA gắn vào chart): chạy bot cho đúng 1 mã + khung giờ, nhận
                   tick từ session. Dùng đứng riêng (BotRunner(path, settings, params)) sẽ tự tạo session riêng.
Mọi vào/ra lệnh sinh TradeEvent kèm LÝ DO để hiện khi chạm vào chấm trên biểu đồ.
"""
import csv
import json
import math
import os
import queue
import threading
import time
import traceback
from collections import OrderedDict, deque
from dataclasses import fields, replace

from .broker import BrokerError, make_broker
from .feeds import FeedError, make_feed, tf_seconds
from .loader import BotLoadError, build_params, collect_inputs, load_bot_class
from .sdk import Candle, Position, Trade, TradeEvent, jsonable

STATUS_TEXT = {
    "idle": "Chưa chạy", "starting": "Đang khởi động...", "running": "Đang chạy",
    "stopping": "Đang dừng...", "stopped": "Đã dừng", "error": "Lỗi",
}
SRC_LABEL = {"sl": "Stop Loss", "tp": "Take Profit", "manual": "Thủ công", "risk": "Ngưỡng lỗ", "stop": "Dừng bot",
             "bot": "Bot", "ai": "AI"}


class _Halt(Exception):
    """Dừng có chủ đích (error=True nếu là lỗi)."""

    def __init__(self, msg, error=False, reason="error"):
        super().__init__(msg)
        self.error = error
        self.reason = reason


def _mk(cls, d):
    names = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in d.items() if k in names})


def _atomic_write(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def parse_watchlist(text):
    out = []
    for x in str(text or "").replace(";", ",").replace("\n", ",").replace(" ", ",").split(","):
        x = x.strip().upper()
        if x and x not in out:
            out.append(x)
    return out


# --------------------------------------------------------------------------
# Sổ lệnh / tài khoản
# --------------------------------------------------------------------------
class Account:
    def __init__(self, balance, commission_pct=0.0, leverage=1.0):
        self.start_balance = float(balance)
        self.balance = float(balance)
        self.fee_rate = max(0.0, float(commission_pct)) / 100.0
        self.leverage = max(1.0, float(leverage))
        self.positions = OrderedDict()
        self.trades = []
        self._next_id = 1
        self.peak_equity = self.balance
        self.max_drawdown = 0.0

    def floating(self):
        return sum(p.profit for p in self.positions.values())

    def equity(self):
        return self.balance + self.floating()

    def margin_used(self):
        return sum(p.volume * p.open_price for p in self.positions.values()) / self.leverage

    def can_open(self, volume, price):
        return self.margin_used() + volume * price / self.leverage <= self.equity() + 1e-9

    @staticmethod
    def _gross(pos, price):
        if pos.side == "buy":
            return (price - pos.open_price) * pos.volume
        return (pos.open_price - price) * pos.volume

    def mark(self, tick):
        """Cập nhật lãi/lỗ thả nổi của các vị thế CÙNG MÃ với tick."""
        for p in self.positions.values():
            if p.symbol == tick.symbol:
                price = tick.bid if p.side == "buy" else tick.ask
                p.profit = self._gross(p, price) - p.fee
        eq = self.equity()
        self.peak_equity = max(self.peak_equity, eq)
        if self.peak_equity > 0:
            self.max_drawdown = max(self.max_drawdown, (self.peak_equity - eq) / self.peak_equity * 100.0)

    def open(self, symbol, side, volume, price, sl, tp, comment, t, owner=""):
        pos = Position(id=self._next_id, symbol=symbol, side=side, volume=volume,
                       open_price=price, open_time=t, sl=sl, tp=tp, comment=comment,
                       fee=volume * price * self.fee_rate, owner=owner)
        pos.profit = -pos.fee
        self._next_id += 1
        self.positions[pos.id] = pos
        return pos

    def close(self, pos_id, price, t, reason):
        pos = self.positions.pop(pos_id)
        gross = self._gross(pos, price)
        profit = gross - pos.fee - pos.volume * price * self.fee_rate
        self.balance += profit
        tr = Trade(id=pos.id, symbol=pos.symbol, side=pos.side, volume=pos.volume,
                   open_price=pos.open_price, close_price=price, open_time=pos.open_time,
                   close_time=t, profit=profit, reason=reason, comment=pos.comment, owner=pos.owner)
        self.trades.append(tr)
        return tr

    def to_dict(self):
        return {"start_balance": self.start_balance, "balance": self.balance, "next_id": self._next_id,
                "peak": self.peak_equity, "max_dd": self.max_drawdown,
                "positions": [jsonable(p) for p in self.positions.values()],
                "trades": [jsonable(t) for t in self.trades[-300:]]}

    def restore(self, d):
        self.start_balance = float(d.get("start_balance", self.start_balance))
        self.balance = float(d.get("balance", self.balance))
        self._next_id = int(d.get("next_id", 1))
        self.peak_equity = float(d.get("peak", self.balance))
        self.max_drawdown = float(d.get("max_dd", 0.0))
        self.positions = OrderedDict((p["id"], _mk(Position, p)) for p in d.get("positions", []))
        self.trades = [_mk(Trade, t) for t in d.get("trades", [])]


# --------------------------------------------------------------------------
# Ghép tick thành nến
# --------------------------------------------------------------------------
class CandleBuilder:
    def __init__(self, step, max_len=3000):
        self.step = step
        self.closed = deque(maxlen=max_len)
        self.current = None

    def seed(self, hist, now):
        cur_open = int(now // self.step) * self.step
        for c in hist:
            if c.time < cur_open:
                self.closed.append(c)
            elif c.time == cur_open:
                self.current = replace(c)

    def update(self, t, price):
        """Trả về nến vừa đóng (nếu có)."""
        open_t = int(t // self.step) * self.step
        done = None
        if self.current is None:
            self.current = Candle(open_t, price, price, price, price)
        elif open_t > self.current.time:
            done = self.current
            self.closed.append(done)
            self.current = Candle(open_t, price, price, price, price)
        else:
            c = self.current
            c.high = max(c.high, price)
            c.low = min(c.low, price)
            c.close = price
        return done


# --------------------------------------------------------------------------
# API đưa cho bot (self.api)
# --------------------------------------------------------------------------
class BotContext:
    """Đối tượng `self.api` trong bot. Bot chỉ thấy/chỉnh được LỆNH CỦA CHÍNH NÓ."""

    def __init__(self, runner):
        self._r = runner

    # thông tin
    @property
    def symbol(self):
        return self._r.symbol

    @property
    def timeframe(self):
        return self._r.tf

    @property
    def mode(self):
        return self._r.session.settings["mode"]

    @property
    def tick(self):
        return self._r.last_tick

    @property
    def ai_signal(self):
        """Tín hiệu mới nhất từ nhóm AI (dict) hoặc None. Khoá: id, action(buy|sell|hold|close_all),
        confidence, sl_pct, tp_pct, reason, by, votes, age"""
        hub = self._r.session.ai_hub
        return hub.get_signal() if hub is not None else None

    @property
    def balance(self):
        return self._r.session.account.balance

    @property
    def equity(self):
        return self._r.session.account.equity()

    # dữ liệu nến
    def candles(self, count=100, include_current=False):
        """List Candle (cũ -> mới). Mặc định chỉ nến ĐÃ ĐÓNG. Không sửa các object này."""
        b = self._r.builder
        data = list(b.closed)
        if include_current and b.current is not None:
            data.append(replace(b.current))
        return data[-int(count):] if count else data

    def closes(self, count=100, include_current=False):
        return [c.close for c in self.candles(count, include_current)]

    # giao dịch (reason/details/ai hiện khi chạm vào chấm vào/ra lệnh trên biểu đồ)
    def buy(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None):
        return self._r._open("buy", volume, sl, tp, comment, reason, details, ai)

    def sell(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None):
        return self._r._open("sell", volume, sl, tp, comment, reason, details, ai)

    def positions(self, side=None):
        return self._r.own_positions(side)

    def close(self, position, reason="", details=None, ai=None):
        pid = position if isinstance(position, int) else position.id
        if pid not in [p.id for p in self._r.own_positions()]:
            return False
        return self._r._close_position(pid, "bot", reason, details, ai)

    def close_all(self, side=None, reason="", details=None, ai=None):
        n = 0
        for p in self.positions(side):
            if self._r._close_position(p.id, "bot", reason, details, ai):
                n += 1
        return n

    def modify(self, position, sl=None, tp=None):
        pid = position if isinstance(position, int) else position.id
        if pid not in [p.id for p in self._r.own_positions()]:
            return False
        return self._r.session.modify_position(pid, sl, tp)

    # hiển thị
    def plot(self, name, value, time=None):
        """Vẽ 1 đường chỉ báo lên biểu đồ nến. time=None -> nến hiện tại."""
        self._r._plot(name, value, time)

    def status(self, text):
        """Dòng 'bot đang nghĩ gì' hiện ở tab Biểu đồ."""
        self._r.bot_status = str(text)[:300]

    def signal(self, text, price=None, side="", details=None):
        """Đánh dấu 1 tín hiệu KHÔNG vào lệnh (vd bị lọc) lên biểu đồ; chạm vào để xem."""
        self._r._note(text, price, side, details)

    def log(self, *args):
        self._r.log(" ".join(str(a) for a in args), "BOT")


# --------------------------------------------------------------------------
# Phiên giao dịch (tài khoản chung)
# --------------------------------------------------------------------------
class TradingSession:
    def __init__(self, settings, log_file=None, trades_csv=None, state_file=None, events_file=None,
                 resume=False, alarm_cb=None, notify_cb=None, ai_hub=None, feed=None, sync=False):
        self.settings = settings
        self.log_file, self.trades_csv = log_file, trades_csv
        self.state_file, self.events_file = state_file, events_file
        self.resume = resume
        self.alarm_cb, self.notify_cb = alarm_cb, notify_cb
        self.ai_hub = ai_hub
        self.feed = feed
        self.sync = sync                    # True: chạy đồng bộ từng tick (backtest), không thread
        self.lock = threading.RLock()
        self.logs, self._log_id = deque(maxlen=800), 0
        self.events, self._event_id = deque(maxlen=800), 0
        self.account, self.broker = None, None
        self.ticks = {}
        self.builders = {}
        self.instances = OrderedDict()
        self.watch = parse_watchlist(settings.get("watchlist"))
        self.status, self.message = "idle", ""
        self.equity_hist = deque(maxlen=600)
        self.tick_count = 0
        self.started_at = None
        self.interval_override = None
        self.ready = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._cmds = queue.Queue()
        self._close_retry = {}
        self._order_fail = 0
        self._last_save = 0.0
        self._feed_fail = {}
        self._chart_symbols = set()
        self.chart_req = None
        self._finished = False

    # ---------------- nhật ký / cảnh báo ----------------
    def log(self, msg, level="INFO"):
        ts = time.time()
        with self.lock:
            self._log_id += 1
            self.logs.append((self._log_id, ts, level, str(msg)))
        if self.log_file:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write("%s [%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)), level, msg))
            except OSError:
                pass

    def get_logs(self, after=0):
        with self.lock:
            return [x for x in self.logs if x[0] > after]

    def alarm(self, title, text):
        self.log("CẢNH BÁO: %s - %s" % (title, text), "ERROR")
        if self.alarm_cb:
            try:
                self.alarm_cb(title, text[:240])
            except Exception:
                pass

    def notify(self, title, text):
        if self.notify_cb and self.settings.get("notify_trades"):
            try:
                self.notify_cb(title, text)
            except Exception:
                pass

    # ---------------- vòng đời ----------------
    def is_alive(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self.is_alive():
            return
        self.status = "starting"
        self._stop.clear()
        self.ready.clear()
        self._finished = False
        self._thread = threading.Thread(target=self._run, name="pyea-session", daemon=True)
        self._thread.start()

    def stop(self, wait=False, timeout=15):
        if self.is_alive() and self.status in ("starting", "running"):
            self.status = "stopping"
        self._stop.set()
        if wait and self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout)

    def request_close_all(self, symbol=None):
        self._cmds.put(("close_all", symbol))

    def set_chart(self, symbol, tf):
        self.chart_req = (symbol, tf)
        self._cmds.put(("chart", symbol, tf))

    def set_watch(self, symbols):
        with self.lock:
            self.watch = list(symbols)

    def setup(self):
        s = self.settings
        live = s["mode"] == "live"
        ex = s["exchange"]
        syms = self.needed_symbols()
        if live:
            if ex == "simulated":
                raise _Halt("Chế độ live cần chọn sàn thật (không phải 'simulated')", error=True, reason="config")
            if not s.get("live_confirm"):
                raise _Halt("Chưa tick xác nhận rủi ro giao dịch thật", error=True, reason="config")
            try:
                self.broker = make_broker(s)
                balance = self.broker.prepare(syms[0] if syms else "BTCUSDT", s["leverage"])
            except BrokerError as e:
                raise _Halt("Kết nối sàn thất bại: %s" % e, error=True, reason="broker")
            self.log("LIVE %s%s: kết nối OK, số dư khả dụng = %.4f" % (ex, " (TESTNET/DEMO)" if s.get("testnet") else "", balance), "WARN")
        else:
            balance = float(s["initial_balance"])
        if self.feed is None:
            try:
                self.feed = make_feed(ex, s)
            except FeedError as e:
                raise _Halt(str(e), error=True, reason="feed")
        lev = s["leverage"] if (not live or ex != "binance_spot") else 1.0
        self.account = Account(balance, s["commission_pct"], lev)
        if self.resume:
            self._load_state()

    def _run(self):
        try:
            self.setup()
            self.status = "running"
            self.started_at = time.time()
            self.ready.set()
            base = float(self.settings["tick_interval"])
            while not self._stop.is_set():
                interval = max(base, float(self.interval_override or 0))
                t0 = time.monotonic()
                self.poll_once()
                self._handle_commands()
                if time.time() - self._last_save > 20:
                    self._save_state()
                self._stop.wait(max(0.0, interval - (time.monotonic() - t0)))
        except _Halt as h:
            self.message = str(h)
            self.log(str(h), "ERROR" if h.error else "WARN")
            self.status = "error" if h.error else "stopped"
            if h.error or h.reason == "max_loss":
                self.alarm("Phiên dừng: " + ("lỗi" if h.error else "đạt ngưỡng lỗ tối đa"), str(h).strip().splitlines()[0])
        except Exception:
            self.message = "Lỗi engine"
            self.log("Lỗi engine:\n" + traceback.format_exc(limit=6), "ERROR")
            self.status = "error"
            self.alarm("Phiên dừng vì lỗi engine", traceback.format_exc(limit=1).strip().splitlines()[-1])
        finally:
            self._finish()

    def _finish(self):
        if self._finished:
            return
        self._finished = True
        try:
            for inst in list(self.instances.values()):
                inst.request_stop()
            if self.account is not None and self.settings.get("close_on_stop") and self.account.positions:
                self.log("Đóng các lệnh còn mở khi dừng")
                self.close_all("stop", "Đóng lệnh còn mở khi dừng phiên")
        except Exception:
            self.log("Lỗi khi dừng:\n" + traceback.format_exc(limit=4), "ERROR")
        if self.status not in ("error", "stopped"):
            self.status = "stopped"
        self._save_state()
        self.log("Phiên đã dừng")
        self.ready.set()
        if self.feed is not None:
            try:
                self.feed.close()
            except Exception:
                pass

    # ---------------- giá ----------------
    def needed_symbols(self):
        with self.lock:
            out = list(self.watch)
            for inst in self.instances.values():
                out.append(inst.symbol)
            out += [sym for sym, _ in self.builders]
            if self.account is not None:
                out += [p.symbol for p in self.account.positions.values()]
            if self.chart_req:
                out.append(self.chart_req[0])
        seen, uniq = set(), []
        for x in out:
            if x and x not in seen:
                seen.add(x)
                uniq.append(x)
        return uniq

    def get_tick(self, symbol):
        t = self.ticks.get(symbol)
        if t is not None:
            return t
        t = self.feed.tick(symbol)
        with self.lock:
            self.ticks[symbol] = t
        return t

    def get_builder(self, symbol, tf):
        """Builder nến (đã nạp lịch sử) dùng chung cho biểu đồ và bot cùng (mã, khung)."""
        key = (symbol, tf)
        b = self.builders.get(key)
        if b is not None:
            return b
        first = self.get_tick(symbol)
        hist = self.feed.history(symbol, tf, int(self.settings["history_bars"]))
        b = CandleBuilder(tf_seconds(tf))
        b.seed(hist, first.time)
        with self.lock:
            self.builders.setdefault(key, b)
            return self.builders[key]

    def poll_once(self):
        for sym in self.needed_symbols():
            try:
                tick = self.feed.tick(sym)
                self._feed_fail[sym] = 0
            except FeedError as e:
                n = self._feed_fail[sym] = self._feed_fail.get(sym, 0) + 1
                if n in (1, 5, 20):
                    self.log("Không lấy được giá %s (%d lần): %s" % (sym, n, e), "WARN")
                if n == 20:
                    self.alarm("Mất kết nối giá " + sym, "20 lần liên tiếp không lấy được giá. Vẫn đang thử lại.")
                if n >= 120 and self._has_exposure(sym):
                    raise _Halt("Mất kết nối giá %s quá lâu" % sym, error=True, reason="feed")
                continue
            self.process_tick(tick)
        self._check_max_loss()
        with self.lock:
            self.equity_hist.append(self.account.equity())

    def _has_exposure(self, sym):
        return any(p.symbol == sym for p in self.account.positions.values()) or any(
            i.symbol == sym for i in self.instances.values())

    def process_tick(self, tick):
        """Xử lý 1 tick (thread session hoặc backtest đồng bộ): ghép nến, mark, SL/TP, phát cho bot."""
        closed = {}
        with self.lock:
            self.ticks[tick.symbol] = tick
            self.tick_count += 1
            self.account.mark(tick)
            for (sym, tf), b in list(self.builders.items()):
                if sym == tick.symbol:
                    closed[tf] = b.update(tick.time, tick.mid)
        self._check_sl_tp(tick)
        for inst in list(self.instances.values()):
            if inst.symbol == tick.symbol:
                inst.deliver(tick, closed.get(inst.tf))

    def _check_sl_tp(self, tick):
        with self.lock:
            plist = [p for p in self.account.positions.values() if p.symbol == tick.symbol]
        for p in plist:
            hit = None
            px = tick.bid if p.side == "buy" else tick.ask
            if p.side == "buy":
                hit = "sl" if (p.sl and px <= p.sl) else "tp" if (p.tp and px >= p.tp) else None
            else:
                hit = "sl" if (p.sl and px >= p.sl) else "tp" if (p.tp and px <= p.tp) else None
            if hit:
                name = "Stop Loss" if hit == "sl" else "Take Profit"
                level = p.sl if hit == "sl" else p.tp
                self.close_position(p.id, hit, "Giá chạm %s: %s %.8g so với mức đặt %.8g" % (
                    name, "bid" if p.side == "buy" else "ask", px, level),
                    {"mức đặt": level, "giá hiện tại": px, "bid": tick.bid, "ask": tick.ask})

    def _check_max_loss(self):
        pct = float(self.settings["max_loss_pct"])
        if pct <= 0 or self.account is None:
            return
        acc = self.account
        if acc.equity() <= acc.start_balance * (1 - pct / 100.0):
            self.log("Equity giảm quá %.1f%% -> đóng hết lệnh và dừng phiên" % pct, "WARN")
            self.close_all("risk", "Equity giảm quá %.1f%% so với vốn ban đầu %.2f (hiện %.2f)" % (
                pct, acc.start_balance, acc.equity()))
            raise _Halt("Đạt ngưỡng lỗ tối đa %.1f%%" % pct, reason="max_loss")

    def _handle_commands(self):
        while True:
            try:
                cmd = self._cmds.get_nowait()
            except queue.Empty:
                return
            try:
                if cmd[0] == "close_all":
                    self.log("Đóng tất cả lệnh%s (thủ công)" % ((" " + cmd[1]) if cmd[1] else ""))
                    self.close_all("manual", "Người dùng bấm 'Đóng tất cả'", symbol=cmd[1])
                elif cmd[0] == "chart":
                    self.get_builder(cmd[1], cmd[2])
            except Exception as e:
                self.log("Lệnh nội bộ lỗi: %s" % e, "WARN")

    # ---------------- sự kiện / lý do ----------------
    def base_context(self, symbol):
        t = self.ticks.get(symbol)
        acc = self.account
        return {"bid": t.bid if t else None, "ask": t.ask if t else None, "symbol": symbol,
                "balance": acc.balance if acc else None, "equity": acc.equity() if acc else None,
                "open_positions": len(acc.positions) if acc else 0, "mode": self.settings["mode"]}

    def add_event(self, kind, symbol, price, side="", volume=0.0, pos_id=0, source="bot", reason="",
                  details=None, ai=None, profit=0.0, ctx=None, owner=""):
        t = self.ticks[symbol].time if symbol in self.ticks else time.time()
        with self.lock:
            self._event_id += 1
            ev = TradeEvent(id=self._event_id, kind=kind, time=t, price=price, side=side, volume=volume,
                            pos_id=pos_id, source=source, reason=str(reason or ""), details=jsonable(details or {}),
                            context=jsonable(ctx or self.base_context(symbol)), ai=self._ai_info(ai),
                            profit=profit, wall_time=time.time(), symbol=symbol, owner=owner)
            self.events.append(ev)
        if self.events_file:
            try:
                with open(self.events_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(jsonable(ev), ensure_ascii=False) + "\n")
            except OSError:
                pass
        return ev

    def _ai_info(self, ai):
        if ai is True:
            ai = self.ai_hub.get_signal() if self.ai_hub is not None else None
        if not isinstance(ai, dict):
            return None
        return jsonable({k: ai.get(k) for k in ("id", "by", "model", "action", "confidence", "sl_pct", "tp_pct",
                                                "reason", "age", "votes", "discussion", "mode") if k in ai})

    # ---------------- giao dịch ----------------
    def open_position(self, symbol, side, volume, sl=0.0, tp=0.0, comment="", owner="manual", reason="",
                      details=None, ai=None, ctx=None):
        """Mở lệnh thị trường (paper: khớp ở ask/bid; live: gửi sàn). Trả về bản sao Position hoặc None."""
        try:
            tick = self.get_tick(symbol)
            volume, sl, tp = float(volume), float(sl or 0.0), float(tp or 0.0)
        except (FeedError, TypeError, ValueError, KeyError) as e:
            self.log("Không đặt được lệnh %s: %s" % (symbol, e), "WARN")
            return None
        if volume <= 0 or math.isnan(volume):
            self.log("Khối lượng phải > 0", "WARN")
            return None
        price = tick.ask if side == "buy" else tick.bid
        bad = ((sl and sl >= price) or (tp and tp <= price)) if side == "buy" else ((sl and sl <= price) or (tp and tp >= price))
        if bad:
            self.log("Từ chối lệnh %s %s: SL/TP sai phía so với giá %.8g (SL=%.8g TP=%.8g)" % (side, symbol, price, sl, tp), "WARN")
            return None
        with self.lock:
            if not self.account.can_open(volume, price):
                self.log("Từ chối lệnh %s %s: không đủ vốn/ký quỹ" % (side, symbol), "WARN")
                return None
            opposite = any(p.symbol == symbol and p.side != side for p in self.account.positions.values())
        if self.broker is not None:
            if side == "sell" and not self.broker.supports_short:
                self.log("LIVE spot không hỗ trợ bán khống -> bỏ lệnh sell (dùng binance_futures hoặc oanda)", "WARN")
                return None
            if getattr(self.broker, "netting", False) and opposite:
                self.log("Sàn gộp vị thế 1 chiều/mã: không giữ đồng thời mua và bán %s -> bỏ lệnh %s" % (symbol, side), "WARN")
                return None
            try:
                fill = self.broker.market_order(symbol, side, volume)
                self._order_fail = 0
            except BrokerError as e:
                self._order_failed("Đặt lệnh %s %s thất bại: %s" % (side, symbol, e))
                return None
            price, volume = fill.price, fill.qty
        with self.lock:
            pos = self.account.open(symbol, side, volume, price, sl, tp, comment, tick.time, owner)
        src = "manual" if owner == "manual" else ("ai" if ai else "bot")
        auto = reason or (comment and "Vào lệnh: %s" % comment) or (
            "Đặt lệnh thủ công" if owner == "manual" else "Bot gửi lệnh %s (bot không ghi lý do)" % side)
        d = dict(details or {})
        d.setdefault("SL", sl or "không đặt")
        d.setdefault("TP", tp or "không đặt")
        self.add_event("open", symbol, price, side, volume, pos.id, src, auto, d, ai, 0.0, ctx, owner)
        self.log("MỞ #%d %s %s %.8g @ %.8g | SL=%.8g TP=%.8g | %s [%s]" % (pos.id, side.upper(), symbol, volume, price, sl, tp, auto, owner))
        self.notify("Mở lệnh %s %s" % (side.upper(), symbol), "%.8g @ %.8g · %s" % (volume, price, auto))
        self._save_state()
        return replace(pos)

    def _order_failed(self, msg):
        self._order_fail += 1
        self.log(msg, "ERROR")
        if self._order_fail == 3:
            self.alarm("Đặt lệnh thất bại liên tiếp", msg)

    def close_position(self, pos_id, source="bot", reason="", details=None, ai=None, ctx=None):
        with self.lock:
            pos = self.account.positions.get(pos_id)
        if pos is None:
            return False
        try:
            tick = self.get_tick(pos.symbol)
        except FeedError:
            return False
        if time.time() < self._close_retry.get(pos_id, 0):
            return False
        price = tick.bid if pos.side == "buy" else tick.ask
        if self.broker is not None:
            try:
                price = self.broker.market_order(pos.symbol, "sell" if pos.side == "buy" else "buy", pos.volume,
                                                 reduce_only=True).price
                self._order_fail = 0
            except BrokerError as e:
                self._close_retry[pos_id] = time.time() + 10
                self._order_failed("Đóng lệnh #%d thất bại: %s (thử lại sau 10s)" % (pos_id, e))
                return False
        with self.lock:
            if pos_id not in self.account.positions:          # luồng khác đã đóng
                return False
            tr = self.account.close(pos_id, price, tick.time, source)
        label = SRC_LABEL.get(source, source)
        tr.reason = label
        d = dict(details or {})
        d.setdefault("giá vào", pos.open_price)
        d.setdefault("giá ra", price)
        self.add_event("close", pos.symbol, price, pos.side, pos.volume, pos.id,
                       "ai" if (ai and source == "bot") else source, reason or "Bot đóng lệnh (bot không ghi lý do)",
                       d, ai, tr.profit, ctx, pos.owner)
        self.log("ĐÓNG #%d %s %s @ %.8g | %s | P/L %+.4f | %s" % (tr.id, tr.side.upper(), pos.symbol, price, label, tr.profit, reason or "-"))
        self.notify("Đóng lệnh %s %s (%s)" % (tr.side.upper(), pos.symbol, label), "P/L %+.4f @ %.8g" % (tr.profit, price))
        self._save_trade(tr)
        self._save_state()
        return True

    def close_all(self, source, reason, symbol=None, owner=None):
        with self.lock:
            ids = [p.id for p in self.account.positions.values()
                   if (symbol is None or p.symbol == symbol) and (owner is None or p.owner == owner)]
        n = 0
        for pid in ids:
            if self.close_position(pid, source, reason):
                n += 1
        return n

    def modify_position(self, pos_id, sl=None, tp=None):
        with self.lock:
            p = self.account.positions.get(pos_id)
            if p is None:
                return False
            t = self.ticks.get(p.symbol)
            price = (t.bid if p.side == "buy" else t.ask) if t else p.open_price
            nsl = p.sl if sl is None else float(sl or 0.0)
            ntp = p.tp if tp is None else float(tp or 0.0)
            bad = ((nsl and nsl >= price) or (ntp and ntp <= price)) if p.side == "buy" else ((nsl and nsl <= price) or (ntp and ntp >= price))
            if bad:
                self.log("Từ chối sửa #%d: SL/TP sai phía so với giá %.8g" % (pos_id, price), "WARN")
                return False
            p.sl, p.tp = nsl, ntp
        self.log("Sửa #%d: SL=%.8g TP=%.8g" % (pos_id, nsl, ntp))
        self._save_state()
        return True

    def place_order(self, symbol, side, volume, sl=0.0, tp=0.0, comment=""):
        """Đặt lệnh THỦ CÔNG từ giao diện."""
        return self.open_position(symbol.strip().upper(), side, volume, sl, tp, comment, "manual",
                                  "Đặt lệnh thủ công từ ứng dụng", {"nguồn": "người dùng"}, None, None)

    def _save_trade(self, tr):
        if not self.trades_csv:
            return
        try:
            new = not os.path.exists(self.trades_csv)
            with open(self.trades_csv, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["owner", "id", "symbol", "side", "volume", "open_price", "close_price",
                                "open_time", "close_time", "profit", "reason"])
                w.writerow([tr.owner, tr.id, tr.symbol, tr.side, tr.volume, tr.open_price, tr.close_price,
                            tr.open_time, tr.close_time, round(tr.profit, 8), tr.reason])
        except OSError:
            pass

    # ---------------- lưu / khôi phục ----------------
    def _save_state(self):
        self._last_save = time.time()
        if not self.state_file or self.account is None:
            return
        try:
            with self.lock:
                data = {"mode": self.settings["mode"], "exchange": self.settings["exchange"], "saved_at": time.time(),
                        "account": self.account.to_dict(), "event_id": self._event_id}
            _atomic_write(self.state_file, json.dumps(data, ensure_ascii=False))
        except Exception:
            pass

    def _load_state(self):
        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            return
        if d.get("mode") != self.settings["mode"] or d.get("exchange") != self.settings["exchange"]:
            self.log("Bỏ qua phiên đã lưu (khác chế độ/sàn)", "WARN")
            return
        self.account.restore(d.get("account", {}))
        self._event_id = int(d.get("event_id", 0))
        if self.events_file and os.path.exists(self.events_file):
            try:
                with open(self.events_file, "r", encoding="utf-8") as f:
                    for line in f.readlines()[-500:]:
                        self.events.append(_mk(TradeEvent, json.loads(line)))
                if self.events:
                    self._event_id = max(self._event_id, max(e.id for e in self.events))
            except Exception:
                pass
        self.log("KHÔI PHỤC phiên: %d lệnh mở, %d lệnh đã đóng, số dư %.4f" % (
            len(self.account.positions), len(self.account.trades), self.account.balance), "WARN")

    # ---------------- bot gắn vào tài sản ----------------
    def attach(self, bot_path, symbol, tf, params=None, iid=None):
        symbol = symbol.strip().upper()
        if iid is None:
            base = os.path.splitext(os.path.basename(bot_path))[0]
            n = 1
            while "%s-%s-%d" % (base, symbol, n) in self.instances:
                n += 1
            iid = "%s-%s-%d" % (base, symbol, n)
        inst = BotRunner(bot_path, self.settings, params or {}, session=self, symbol=symbol, tf=tf, iid=iid)
        with self.lock:
            self.instances[iid] = inst
        return inst

    def detach(self, iid):
        inst = self.instances.get(iid)
        if inst is not None:
            inst.stop()
            with self.lock:
                self.instances.pop(iid, None)

    # ---------------- ảnh chụp cho giao diện ----------------
    def snapshot(self):
        base = {"status": self.status, "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message,
                "mode": self.settings["mode"], "exchange": self.settings["exchange"], "ready": False,
                "watch": {}, "instances": [], "positions": [], "trades": [], "equity_curve": []}
        with self.lock:
            acc = self.account
            base["instances"] = [i.summary() for i in self.instances.values()]
            if acc is None:
                return base
            tr = acc.trades
            wins = sum(1 for t in tr if t.profit > 0)
            eq = acc.equity()
            base.update({
                "ready": True, "balance": acc.balance, "equity": eq, "floating": acc.floating(),
                "margin": acc.margin_used(), "start_balance": acc.start_balance, "pnl": eq - acc.start_balance,
                "pnl_pct": (eq - acc.start_balance) / acc.start_balance * 100.0 if acc.start_balance else 0.0,
                "max_dd": acc.max_drawdown, "n_trades": len(tr), "wins": wins,
                "win_rate": (wins / len(tr) * 100.0) if tr else 0.0,
                "uptime": (time.time() - self.started_at) if self.started_at else 0.0, "ticks": self.tick_count,
                "positions": [replace(p) for p in acc.positions.values()],
                "trades": [replace(t) for t in tr[-40:]][::-1],
                "equity_curve": list(self.equity_hist)[-200:],
                "watch": {s: {"bid": t.bid, "ask": t.ask, "time": t.time} for s, t in self.ticks.items()
                          if s in set(self.watch) | {i.symbol for i in self.instances.values()}
                          | {p.symbol for p in acc.positions.values()}},
            })
        return base

    def chart(self, symbol, tf, bars=160, max_events=300):
        b = self.builders.get((symbol, tf))
        if b is None:
            return None
        with self.lock:
            candles = list(b.closed)[-bars:]
            if b.current is not None:
                candles.append(replace(b.current))
            times = {c.time for c in candles}
            plots = {}
            for inst in self.instances.values():
                if inst.symbol == symbol and inst.tf == tf:
                    for n, ser in inst.plots.items():
                        pts = [(t, v) for t, v in ser.items() if t in times]
                        plots[n if len(self.instances) <= 1 else "%s·%s" % (inst.iid, n)] = pts
            evs = [replace(e) for e in self.events if e.symbol == symbol][-max_events:]
            t = self.ticks.get(symbol)
            status = {i.iid: i.bot_status for i in self.instances.values() if i.symbol == symbol and i.bot_status}
        return {"symbol": symbol, "timeframe": tf, "candles": candles, "plots": plots, "events": evs,
                "bid": t.bid if t else None, "ask": t.ask if t else None, "bot_status": status,
                "positions": [replace(p) for p in self.account.positions.values() if p.symbol == symbol]
                if self.account else []}


# --------------------------------------------------------------------------
# Bot gắn vào 1 tài sản (như EA gắn vào chart)
# --------------------------------------------------------------------------
class BotRunner:
    def __init__(self, bot_path, settings, params, log_file=None, trades_csv=None, ai_hub=None, state_file=None,
                 events_file=None, resume=False, alarm_cb=None, notify_cb=None, session=None, symbol=None,
                 tf=None, iid=None):
        self.own_session = session is None
        if session is None:
            session = TradingSession(settings, log_file, trades_csv, state_file, events_file, resume,
                                     alarm_cb, notify_cb, ai_hub)
        self.session = session
        self.bot_path = bot_path
        self.params = params
        wl = parse_watchlist(settings.get("watchlist"))
        self.symbol = (symbol or settings.get("symbol") or (wl[0] if wl else "BTCUSD")).strip().upper()
        self.tf = tf or settings.get("timeframe") or "1m"
        self.iid = iid or os.path.splitext(os.path.basename(bot_path))[0]
        if self.own_session:
            session.instances[self.iid] = self
            if self.symbol in session.watch:
                session.watch.remove(self.symbol)
            session.watch.insert(0, self.symbol)
        self.status, self.message = "idle", ""
        self.bot_name = os.path.basename(bot_path)
        self.bot, self.bot_params, self.builder = None, {}, None
        self.bot_inputs = {}
        self.params_msg = ""
        self.plots = {}
        self.plot_cap = 3000
        self.bot_status = ""
        self._cb_name = ""
        self.started_at = None
        self._q = queue.Queue()
        self._stop = threading.Event()
        self._thread = None

    # ---- tiện ích truy cập (tương thích API cũ) ----
    @property
    def account(self):
        return self.session.account

    @property
    def events(self):
        return self.session.events

    @property
    def logs(self):
        return self.session.logs

    @property
    def lock(self):
        return self.session.lock

    @property
    def settings(self):
        return self.session.settings

    @property
    def last_tick(self):
        return self.session.ticks.get(self.symbol)

    @property
    def ai_hub(self):
        return self.session.ai_hub

    @property
    def interval_override(self):
        return self.session.interval_override

    @interval_override.setter
    def interval_override(self, v):
        self.session.interval_override = v

    def log(self, msg, level="INFO"):
        self.session.log("[%s] %s" % (self.iid, msg) if not self.own_session else msg, level)

    def get_logs(self, after=0):
        return self.session.get_logs(after)

    def own_positions(self, side=None):
        with self.session.lock:
            return [replace(p) for p in self.session.account.positions.values()
                    if p.owner == self.iid and (side is None or p.side == side)]

    # ---- điều khiển ----
    def is_alive(self):
        if self.own_session:
            return (self._thread is not None and self._thread.is_alive()) or self.session.is_alive()
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self.status = "starting"
        self._stop.clear()
        if self.own_session:
            self.session.start()
        elif self.session.sync:
            self._setup()
            self.status = "running"
            return
        self._thread = threading.Thread(target=self._run, name="pyea-bot-" + self.iid, daemon=True)
        self._thread.start()

    def stop(self):
        if self._thread is not None and self._thread.is_alive() and self.status in ("starting", "running"):
            self.status = "stopping"
        self._stop.set()
        if self.own_session:
            self.session.stop()

    def request_stop(self):
        self._stop.set()

    def request_close_all(self):
        self.session.request_close_all()

    def deliver(self, tick, closed):
        if self.session.sync:
            if self.status == "running":
                self._on_tick(tick, closed)
        elif self.status in ("starting", "running"):
            self._q.put((tick, closed))

    # ---- chạy ----
    def _setup(self):
        s = self.session
        if not s.sync:
            s.ready.wait(120)
            if s.status in ("error",) or s.account is None:
                raise _Halt("Phiên giao dịch chưa sẵn sàng: %s" % (s.message or s.status), error=True, reason="session")
        try:
            cls, _ = load_bot_class(self.bot_path)
        except BotLoadError as e:
            raise _Halt(str(e), error=True, reason="load")
        self.bot_name = cls.name or cls.__name__
        self.bot_inputs = collect_inputs(cls, self.bot_path)        # nhận dạng tham số như MT5 nhận dạng `input`
        self.bot_params = build_params(self.bot_inputs, self.params)
        try:
            self.builder = s.builders.get((self.symbol, self.tf)) or s.get_builder(self.symbol, self.tf)
        except FeedError as e:
            raise _Halt("Không lấy được dữ liệu %s %s: %s" % (self.symbol, self.tf, e), error=True, reason="feed")
        self.bot = cls(BotContext(self), self.bot_params)
        self.log("Đã nạp bot %s cho %s %s (%d nến lịch sử). Tham số: %s" % (
            self.bot_name, self.symbol, self.tf, len(self.builder.closed), self.bot_params))
        ok = self._call("on_init", self.bot.on_init)
        if ok is False:
            raise _Halt("Bot trả về False trong on_init -> huỷ chạy", reason="init_failed")

    def _run(self):
        reason = "user"
        try:
            self._setup()
            self.status = "running"
            self.started_at = time.time()
            self.log("Bot bắt đầu chạy: %s | %s %s | chế độ %s" % (self.bot_name, self.symbol, self.tf, self.settings["mode"]))
            while not self._stop.is_set():
                try:
                    item = self._q.get(timeout=0.5)
                except queue.Empty:
                    if self.session._finished or self.session.status in ("error", "stopped"):
                        break
                    continue
                if item[0] == "__params__":
                    self._apply_params_now(item[1])
                    continue
                self._on_tick(item[0], item[1])
        except _Halt as h:
            reason = h.reason
            self.message = str(h)
            self.log(str(h), "ERROR" if h.error else "WARN")
            self.status = "error" if h.error else "stopped"
            if h.error:
                self.session.alarm("Bot %s dừng vì lỗi" % self.iid, str(h).strip().splitlines()[0])
        except Exception:
            reason = "error"
            self.message = "Lỗi engine"
            self.log("Lỗi engine:\n" + traceback.format_exc(limit=6), "ERROR")
            self.status = "error"
            self.session.alarm("Bot %s dừng vì lỗi engine" % self.iid, traceback.format_exc(limit=1).strip().splitlines()[-1])
        finally:
            self._shutdown(reason)

    def _call(self, name, fn, *args):
        self._cb_name = name
        try:
            return fn(*args)
        except _Halt:
            raise
        except Exception:
            raise _Halt("Lỗi trong bot %s (%s):\n%s" % (self.iid, name, traceback.format_exc(limit=6)),
                        error=True, reason="error")
        finally:
            self._cb_name = ""

    # ---- đổi tham số khi bot đang chạy (giống MT5: OnDeinit(REASON_PARAMETERS) rồi OnInit; lệnh đang mở giữ nguyên) ----
    def apply_params(self, values):
        """Gọi từ bất kỳ thread. Bot chưa chạy: chỉ ghi nhận cho lần chạy sau. Đang chạy: thực hiện trong thread của bot."""
        self.params = dict(values or {})
        if self.bot is None or self.status not in ("running", "starting") or self.session.sync:
            return
        self._q.put(("__params__", dict(values or {})))

    def _apply_params_now(self, values):
        old = dict(self.bot_params)
        new = build_params(self.bot_inputs, values)
        changed = {k: (old.get(k), new[k]) for k in new if old.get(k) != new[k]}
        if not changed:
            self.params_msg = "Tham số không thay đổi"
            return
        desc = ", ".join("%s: %s → %s" % (k, a, b) for k, (a, b) in changed.items())
        self.log("Đổi tham số (%s) - gọi on_deinit('params') rồi on_init() lại, lệnh đang mở giữ nguyên" % desc)
        try:
            self._cb_name = "on_deinit"
            self.bot.on_deinit("params")
        except Exception:
            self.log("Lỗi trong on_deinit('params'):\n" + traceback.format_exc(limit=4), "ERROR")
        self.bot_params = new
        self.bot._set_params(new)
        ok = self._call("on_init", self.bot.on_init)
        if ok is False:                                           # như INIT_PARAMETERS_INCORRECT: từ chối, quay lại tham số cũ
            self.bot_params = old
            self.bot._set_params(old)
            self._call("on_init", self.bot.on_init)
            self.params = dict(old)
            self.params_msg = "Tham số bị bot từ chối (on_init trả về False) - giữ tham số cũ: " + desc
            self.log(self.params_msg, "WARN")
            self.session.alarm("Tham số bị từ chối: " + self.iid, "Bot trả về False trong on_init với tham số mới -> đã quay lại tham số cũ.")
            return
        self.params_msg = "Đã áp dụng: " + desc
        t = self.last_tick
        if t is not None:
            self.session.add_event("note", self.symbol, t.mid, "", 0.0, 0, "bot", "Đổi tham số: " + desc,
                                   {k: "%s → %s" % v for k, v in changed.items()}, None, 0.0, self._context(), self.iid)

    def _on_tick(self, tick, closed):
        if closed is not None:
            self._call("on_bar", self.bot.on_bar, closed)
        self._call("on_tick", self.bot.on_tick, tick)

    def _shutdown(self, reason):
        if self.bot is not None:
            try:
                self._cb_name = "on_deinit"
                self.bot.on_deinit(reason)
            except Exception:
                self.log("Lỗi trong on_deinit:\n" + traceback.format_exc(limit=4), "ERROR")
        if self.own_session:
            self.session.stop(wait=True)
            self.message = self.message or self.session.message
            if self.session.status == "error":
                self.status = "error"
        if self.status not in ("error", "stopped"):
            self.status = "stopped"
        self.log("Bot đã dừng (%s)" % reason)

    # ---- giao dịch cho bot ----
    def _context(self):
        s = self.session
        t = self.last_tick
        b = self.builder
        ind = {}
        with s.lock:
            for name, ser in self.plots.items():
                if ser:
                    ind[name] = next(reversed(ser.values()))

            def cd(c):
                return None if c is None else {"time": c.time, "open": c.open, "high": c.high, "low": c.low, "close": c.close}
            return jsonable({
                "callback": self._cb_name or "(ngoài callback)", "instance": self.iid, "bid": t.bid if t else None,
                "ask": t.ask if t else None, "last_closed": cd(b.closed[-1] if b and b.closed else None),
                "current": cd(b.current if b else None), "indicators": ind, "params": self.bot_params,
                "balance": s.account.balance, "equity": s.account.equity(), "open_positions": len(s.account.positions),
                "mode": s.settings["mode"], "symbol": self.symbol, "timeframe": self.tf})

    def _open(self, side, volume, sl, tp, comment, reason="", details=None, ai=None):
        return self.session.open_position(self.symbol, side, volume, sl, tp, comment, self.iid, reason, details, ai,
                                          self._context())

    def _close_position(self, pos_id, source="bot", reason="", details=None, ai=None):
        return self.session.close_position(pos_id, source, reason, details, ai, self._context())

    def _note(self, text, price, side, details):
        t = self.last_tick
        if t is None:
            return
        self.session.add_event("note", self.symbol, float(price) if price else t.mid, side or "", 0.0, 0, "bot",
                               str(text)[:400], details, None, 0.0, self._context(), self.iid)

    def _plot(self, name, value, t):
        if value is None:
            return
        if t is None:
            if self.builder is None or self.builder.current is None:
                return
            t = self.builder.current.time
        with self.session.lock:
            series = self.plots.setdefault(str(name), OrderedDict())
            series[t] = float(value)
            while len(series) > self.plot_cap:
                series.popitem(last=False)

    # ---- thông tin ----
    def summary(self):
        s = self.session
        with s.lock:
            pos = [p for p in s.account.positions.values() if p.owner == self.iid] if s.account else []
            closed = [t for t in (s.account.trades if s.account else []) if t.owner == self.iid]
            return {"iid": self.iid, "bot": self.bot_name, "bot_path": self.bot_path, "symbol": self.symbol, "tf": self.tf,
                    "status": self.status, "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message,
                    "bot_status": self.bot_status, "params_msg": self.params_msg, "open": len(pos),
                    "profit": sum(p.profit for p in pos) + sum(t.profit for t in closed), "trades": len(closed)}

    def snapshot(self, chart_bars=240, max_trades=30, max_events=250):
        """Ảnh chụp kiểu cũ: phiên + biểu đồ của mã/khung của bot này (dùng cho AI market_context, test)."""
        snap = self.session.snapshot()
        snap.update({"bot": self.bot_name, "symbol": self.symbol, "timeframe": self.tf, "bot_status": self.bot_status,
                     "status": self.status if self.own_session or self.status in ("error",) else snap["status"],
                     "status_text": STATUS_TEXT.get(self.status, self.status), "message": self.message or snap["message"],
                     "candles": [], "plots": {}, "events": []})
        t = self.last_tick
        if t is not None:
            snap.update({"bid": t.bid, "ask": t.ask, "tick_time": t.time})
        ch = self.session.chart(self.symbol, self.tf, chart_bars, max_events)
        if ch:
            snap["candles"] = ch["candles"]
            snap["events"] = ch["events"]
            with self.session.lock:
                times = {c.time for c in ch["candles"]}
                snap["plots"] = {n: [(a, v) for a, v in s.items() if a in times] for n, s in self.plots.items()}
        snap["ready"] = bool(snap.get("ready") and t is not None and ch)
        return snap
