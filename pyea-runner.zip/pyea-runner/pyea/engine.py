"""
Engine chạy bot: vòng lặp lấy giá -> cập nhật tài khoản -> gọi hàm của bot.
Bot chạy trong 1 thread riêng; giao diện đọc trạng thái qua BotRunner.snapshot().

Mỗi lệnh vào/ra đều sinh 1 TradeEvent (điểm trên biểu đồ) kèm LÝ DO: bot tự ghi (reason/details)
hoặc engine tự chụp ngữ cảnh (chỉ báo, tham số, nến...). Sổ lệnh được lưu ra file để khôi phục
sau sự cố (crash/bị hệ thống giết).
"""
import csv
import json
import math
import os
import queue
import threading
import time
import traceback
from collections import OrderedDict, deque
from dataclasses import fields, replace

from .broker import BrokerError, make_broker
from .feeds import FeedError, make_feed, tf_seconds
from .loader import BotLoadError, build_params, load_bot_class
from .sdk import Candle, Position, Trade, TradeEvent, jsonable

STATUS_TEXT = {
    "idle": "Chưa chạy", "starting": "Đang khởi động...", "running": "Đang chạy",
    "stopping": "Đang dừng...", "stopped": "Đã dừng", "error": "Lỗi",
}


class _Halt(Exception):
    """Dừng bot có chủ đích (error=True nếu là lỗi)."""

    def __init__(self, msg, error=False, reason="error"):
        super().__init__(msg)
        self.error = error
        self.reason = reason


def _mk(cls, d):
    names = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in d.items() if k in names})


def _atomic_write(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


# --------------------------------------------------------------------------
# Sổ lệnh / tài khoản
# --------------------------------------------------------------------------
class Account:
    def __init__(self, balance, commission_pct=0.0, leverage=1.0):
        self.start_balance = float(balance)
        self.balance = float(balance)
        self.fee_rate = max(0.0, float(commission_pct)) / 100.0
        self.leverage = max(1.0, float(leverage))
        self.positions = OrderedDict()
        self.trades = []
        self._next_id = 1
        self.peak_equity = self.balance
        self.max_drawdown = 0.0

    def floating(self):
        return sum(p.profit for p in self.positions.values())

    def equity(self):
        return self.balance + self.floating()

    def margin_used(self):
        return sum(p.volume * p.open_price for p in self.positions.values()) / self.leverage

    def can_open(self, volume, price):
        return self.margin_used() + volume * price / self.leverage <= self.equity() + 1e-9

    @staticmethod
    def _gross(pos, price):
        if pos.side == "buy":
            return (price - pos.open_price) * pos.volume
        return (pos.open_price - price) * pos.volume

    def mark(self, tick):
        for p in self.positions.values():
            price = tick.bid if p.side == "buy" else tick.ask
            p.profit = self._gross(p, price) - p.fee
        eq = self.equity()
        self.peak_equity = max(self.peak_equity, eq)
        if self.peak_equity > 0:
            self.max_drawdown = max(self.max_drawdown, (self.peak_equity - eq) / self.peak_equity * 100.0)

    def open(self, symbol, side, volume, price, sl, tp, comment, t):
        pos = Position(id=self._next_id, symbol=symbol, side=side, volume=volume,
                       open_price=price, open_time=t, sl=sl, tp=tp, comment=comment,
                       fee=volume * price * self.fee_rate)
        pos.profit = -pos.fee
        self._next_id += 1
        self.positions[pos.id] = pos
        return pos

    def close(self, pos_id, price, t, reason):
        pos = self.positions.pop(pos_id)
        gross = self._gross(pos, price)
        profit = gross - pos.fee - pos.volume * price * self.fee_rate
        self.balance += profit
        tr = Trade(id=pos.id, symbol=pos.symbol, side=pos.side, volume=pos.volume,
                   open_price=pos.open_price, close_price=price, open_time=pos.open_time,
                   close_time=t, profit=profit, reason=reason, comment=pos.comment)
        self.trades.append(tr)
        return tr

    def to_dict(self):
        return {"start_balance": self.start_balance, "balance": self.balance, "next_id": self._next_id,
                "peak": self.peak_equity, "max_dd": self.max_drawdown,
                "positions": [jsonable(p) for p in self.positions.values()],
                "trades": [jsonable(t) for t in self.trades[-200:]]}

    def restore(self, d):
        self.start_balance = float(d.get("start_balance", self.start_balance))
        self.balance = float(d.get("balance", self.balance))
        self._next_id = int(d.get("next_id", 1))
        self.peak_equity = float(d.get("peak", self.balance))
        self.max_drawdown = float(d.get("max_dd", 0.0))
        self.positions = OrderedDict((p["id"], _mk(Position, p)) for p in d.get("positions", []))
        self.trades = [_mk(Trade, t) for t in d.get("trades", [])]


# --------------------------------------------------------------------------
# Ghép tick thành nến
# --------------------------------------------------------------------------
class CandleBuilder:
    def __init__(self, step, max_len=1500):
        self.step = step
        self.closed = deque(maxlen=max_len)
        self.current = None

    def seed(self, hist, now):
        cur_open = int(now // self.step) * self.step
        for c in hist:
            if c.time < cur_open:
                self.closed.append(c)
            elif c.time == cur_open:
                self.current = replace(c)

    def update(self, t, price):
        """Trả về nến vừa đóng (nếu có)."""
        open_t = int(t // self.step) * self.step
        done = None
        if self.current is None:
            self.current = Candle(open_t, price, price, price, price)
        elif open_t > self.current.time:
            done = self.current
            self.closed.append(done)
            self.current = Candle(open_t, price, price, price, price)
        else:
            c = self.current
            c.high = max(c.high, price)
            c.low = min(c.low, price)
            c.close = price
        return done


# --------------------------------------------------------------------------
# API đưa cho bot (self.api)
# --------------------------------------------------------------------------
class BotContext:
    """Đối tượng `self.api` trong bot."""

    def __init__(self, runner):
        self._r = runner

    # thông tin
    @property
    def symbol(self):
        return self._r.symbol

    @property
    def timeframe(self):
        return self._r.tf

    @property
    def mode(self):
        return self._r.settings["mode"]

    @property
    def tick(self):
        return self._r.last_tick

    @property
    def ai_signal(self):
        """Tín hiệu mới nhất từ nhóm AI (dict) hoặc None nếu chưa có / đã hết hạn.
        Khoá: id, action(buy|sell|hold|close_all), confidence, sl_pct, tp_pct, reason, by, votes, age"""
        hub = self._r.ai_hub
        return hub.get_signal() if hub is not None else None

    @property
    def balance(self):
        return self._r.account.balance

    @property
    def equity(self):
        return self._r.account.equity()

    # dữ liệu nến
    def candles(self, count=100, include_current=False):
        """List Candle (cũ -> mới). Mặc định chỉ nến ĐÃ ĐÓNG. Không sửa các object này."""
        r = self._r
        data = list(r.builder.closed)
        if include_current and r.builder.current is not None:
            data.append(replace(r.builder.current))
        return data[-int(count):] if count else data

    def closes(self, count=100, include_current=False):
        return [c.close for c in self.candles(count, include_current)]

    # giao dịch. reason/details/ai: lý do hiển thị khi người dùng chạm vào điểm vào/ra lệnh trên biểu đồ
    def buy(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None):
        return self._r._open("buy", volume, sl, tp, comment, reason, details, ai)

    def sell(self, volume, sl=0.0, tp=0.0, comment="", reason="", details=None, ai=None):
        return self._r._open("sell", volume, sl, tp, comment, reason, details, ai)

    def positions(self, side=None):
        with self._r.lock:
            return [replace(p) for p in self._r.account.positions.values()
                    if side is None or p.side == side]

    def close(self, position, reason="", details=None, ai=None):
        pid = position if isinstance(position, int) else position.id
        return self._r._close_position(pid, "bot", reason, details, ai)

    def close_all(self, side=None, reason="", details=None, ai=None):
        n = 0
        for p in self.positions(side):
            if self._r._close_position(p.id, "bot", reason, details, ai):
                n += 1
        return n

    def modify(self, position, sl=None, tp=None):
        pid = position if isinstance(position, int) else position.id
        with self._r.lock:
            p = self._r.account.positions.get(pid)
            if p is None:
                return False
            if sl is not None:
                p.sl = float(sl)
            if tp is not None:
                p.tp = float(tp)
        return True

    # hiển thị
    def plot(self, name, value, time=None):
        """Vẽ 1 đường chỉ báo lên biểu đồ nến. time=None -> nến hiện tại."""
        self._r._plot(name, value, time)

    def status(self, text):
        """Dòng 'bot đang nghĩ gì' hiện ở tab Giám sát."""
        self._r.bot_status = str(text)[:300]

    def signal(self, text, price=None, side="", details=None):
        """Đánh dấu 1 tín hiệu KHÔNG vào lệnh (vd bị lọc) lên biểu đồ; chạm vào để xem."""
        self._r._note(text, price, side, details)

    def log(self, *args):
        self._r.log(" ".join(str(a) for a in args), "BOT")


# --------------------------------------------------------------------------
# Runner
# --------------------------------------------------------------------------
class BotRunner:
    def __init__(self, bot_path, settings, params, log_file=None, trades_csv=None, ai_hub=None,
                 state_file=None, events_file=None, resume=False, alarm_cb=None, notify_cb=None):
        self.bot_path = bot_path
        self.ai_hub = ai_hub
        self.settings = settings
        self.params = params
        self.log_file = log_file
        self.trades_csv = trades_csv
        self.state_file = state_file
        self.events_file = events_file
        self.resume = resume
        self.alarm_cb = alarm_cb          # (title, text) - sự cố nghiêm trọng
        self.notify_cb = notify_cb        # (title, text) - thông tin thường (mở/đóng lệnh)

        self.lock = threading.RLock()
        self._stop = threading.Event()
        self._cmds = queue.Queue()
        self._thread = None

        self.status = "idle"
        self.message = ""
        self.bot_name = os.path.basename(bot_path)
        self.symbol = str(settings["symbol"]).strip().upper()
        self.tf = settings["timeframe"]

        self.logs = deque(maxlen=800)
        self._log_id = 0
        self.account = None
        self.builder = None
        self.feed = None
        self.broker = None
        self.bot = None
        self.bot_params = {}
        self.last_tick = None
        self.plots = {}
        self.events = deque(maxlen=400)
        self._event_id = 0
        self.bot_status = ""
        self._cb_name = ""
        self.equity_hist = deque(maxlen=600)
        self.ticks = 0
        self.started_at = None
        self._close_retry = {}
        self._order_fail = 0
        self._last_save = 0.0
        self.interval_override = None     # service nâng chu kỳ khi chạy nền (chế độ tiết kiệm pin)

    # ---------------- điều khiển ----------------
    def is_alive(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        if self.is_alive():
            return
        self.status = "starting"
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="pyea-bot", daemon=True)
        self._thread.start()

    def stop(self):
        if self.is_alive() and self.status in ("starting", "running"):
            self.status = "stopping"
        self._stop.set()

    def request_close_all(self):
        self._cmds.put("close_all")

    # ---------------- nhật ký / cảnh báo ----------------
    def log(self, msg, level="INFO"):
        ts = time.time()
        with self.lock:
            self._log_id += 1
            self.logs.append((self._log_id, ts, level, str(msg)))
        if self.log_file:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write("%s [%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)), level, msg))
            except OSError:
                pass

    def get_logs(self, after=0):
        with self.lock:
            return [x for x in self.logs if x[0] > after]

    def _alarm(self, title, text):
        self.log("CẢNH BÁO: %s - %s" % (title, text), "ERROR")
        if self.alarm_cb:
            try:
                self.alarm_cb(title, text[:240])
            except Exception:
                pass

    def _notify(self, title, text):
        if self.notify_cb and self.settings.get("notify_trades"):
            try:
                self.notify_cb(title, text)
            except Exception:
                pass

    # ---------------- vòng chạy ----------------
    def _run(self):
        reason = "user"
        try:
            self._setup()
            ok = self._call("on_init", self.bot.on_init)
            if ok is False:
                raise _Halt("Bot trả về False trong on_init -> huỷ chạy", reason="init_failed")
            self.status = "running"
            self.started_at = time.time()
            self.log("Bot bắt đầu chạy: %s | %s %s | chế độ %s"
                     % (self.bot_name, self.symbol, self.tf, self.settings["mode"]))
            base_interval = float(self.settings["tick_interval"])
            fail = 0
            while not self._stop.is_set():
                interval = max(base_interval, float(self.interval_override or 0))
                t0 = time.monotonic()
                try:
                    tick = self.feed.tick(self.symbol)
                    fail = 0
                except FeedError as e:
                    fail += 1
                    if fail in (1, 5, 20):
                        self.log("Không lấy được giá (%d lần): %s" % (fail, e), "WARN")
                    if fail == 20:
                        self._alarm("Mất kết nối giá", "Đã 20 lần liên tiếp không lấy được giá. Bot vẫn đang thử lại.")
                    if fail >= 120:
                        raise _Halt("Mất kết nối giá quá lâu", error=True, reason="feed")
                    self._stop.wait(min(interval * 2, 5.0))
                    continue
                self._on_tick(tick)
                self._handle_commands()
                if time.time() - self._last_save > 20:
                    self._save_state()
                self._stop.wait(max(0.0, interval - (time.monotonic() - t0)))
        except _Halt as h:
            reason = h.reason
            self.message = str(h)
            self.log(str(h), "ERROR" if h.error else "WARN")
            self.status = "error" if h.error else "stopped"
            if h.error or h.reason == "max_loss":
                self._alarm("Bot dừng: " + ("lỗi" if h.error else "đạt ngưỡng lỗ tối đa"), str(h).strip().splitlines()[0])
        except Exception:
            reason = "error"
            self.message = "Lỗi engine"
            self.log("Lỗi engine:\n" + traceback.format_exc(limit=6), "ERROR")
            self.status = "error"
            self._alarm("Bot dừng vì lỗi engine", traceback.format_exc(limit=1).strip().splitlines()[-1])
        finally:
            self._shutdown(reason)

    def _setup(self):
        s = self.settings
        self.log("Đang nạp bot: %s" % os.path.basename(self.bot_path))
        try:
            cls, _ = load_bot_class(self.bot_path)
        except BotLoadError as e:
            raise _Halt(str(e), error=True, reason="load")
        self.bot_name = cls.name or cls.__name__
        self.bot_params = build_params(getattr(cls, "inputs", {}) or {}, self.params)

        step = tf_seconds(self.tf)
        live = s["mode"] == "live"
        futures = s.get("exchange") == "binance_futures"
        if live:
            if not s.get("live_confirm"):
                raise _Halt("Chưa tick xác nhận rủi ro giao dịch thật", error=True, reason="config")
            try:
                self.broker = make_broker(s)
                balance = self.broker.prepare(self.symbol, s["leverage"])
            except BrokerError as e:
                raise _Halt("Kết nối sàn thất bại: %s" % e, error=True, reason="broker")
            self.log("LIVE %s%s: kết nối OK, số dư khả dụng = %.4f" % (
                s.get("exchange"), " (TESTNET)" if s.get("testnet") else "", balance), "WARN")
            self.feed = make_feed("binance_futures" if futures else "binance", s)
        else:
            balance = float(s["initial_balance"])
            self.feed = make_feed(s["feed"], s)

        lev = s["leverage"] if (not live or futures) else 1.0
        self.account = Account(balance, s["commission_pct"], lev)
        try:
            first = self.feed.tick(self.symbol)
            hist = self.feed.history(self.symbol, self.tf, int(s["history_bars"]))
        except FeedError as e:
            raise _Halt("Không lấy được dữ liệu ban đầu: %s" % e, error=True, reason="feed")
        self.builder = CandleBuilder(step)
        self.builder.seed(hist, first.time)
        self.last_tick = first
        if self.resume:
            self._load_state()
        self.account.mark(first)
        self.bot = cls(BotContext(self), self.bot_params)
        self.log("Đã nạp %d nến lịch sử. Tham số: %s" % (len(self.builder.closed), self.bot_params))

    def _call(self, name, fn, *args):
        self._cb_name = name
        try:
            return fn(*args)
        except _Halt:
            raise
        except Exception:
            raise _Halt("Lỗi trong bot (%s):\n%s" % (name, traceback.format_exc(limit=6)),
                        error=True, reason="error")
        finally:
            self._cb_name = ""

    def _on_tick(self, tick):
        self.ticks += 1
        closed = self.builder.update(tick.time, tick.mid)
        with self.lock:
            self.last_tick = tick
            self.account.mark(tick)
            self.equity_hist.append(self.account.equity())
        self._check_sl_tp(tick)
        self._check_max_loss()
        if closed is not None:
            self._call("on_bar", self.bot.on_bar, closed)
        self._call("on_tick", self.bot.on_tick, tick)

    def _check_sl_tp(self, tick):
        with self.lock:
            plist = list(self.account.positions.values())
        for p in plist:
            hit = None
            if p.side == "buy":
                px = tick.bid
                if p.sl and px <= p.sl:
                    hit = "sl"
                elif p.tp and px >= p.tp:
                    hit = "tp"
            else:
                px = tick.ask
                if p.sl and px >= p.sl:
                    hit = "sl"
                elif p.tp and px <= p.tp:
                    hit = "tp"
            if hit:
                name = "Stop Loss" if hit == "sl" else "Take Profit"
                level = p.sl if hit == "sl" else p.tp
                self._close_position(p.id, hit, "Giá chạm %s: %s %.8g so với mức đặt %.8g" % (
                    name, "bid" if p.side == "buy" else "ask", px, level),
                    {"mức đặt": level, "giá hiện tại": px, "bid": tick.bid, "ask": tick.ask})

    def _check_max_loss(self):
        pct = float(self.settings["max_loss_pct"])
        if pct <= 0:
            return
        acc = self.account
        if acc.equity() <= acc.start_balance * (1 - pct / 100.0):
            self.log("Equity giảm quá %.1f%% -> đóng hết lệnh và dừng bot" % pct, "WARN")
            self._close_all("risk", "Equity giảm quá %.1f%% so với vốn ban đầu %.2f (hiện %.2f)" % (
                pct, acc.start_balance, acc.equity()))
            raise _Halt("Đạt ngưỡng lỗ tối đa %.1f%%" % pct, reason="max_loss")

    def _handle_commands(self):
        while True:
            try:
                cmd = self._cmds.get_nowait()
            except queue.Empty:
                return
            if cmd == "close_all":
                self.log("Đóng tất cả lệnh (thủ công)")
                self._close_all("manual", "Người dùng bấm 'Đóng tất cả'")

    def _close_all(self, source, reason):
        with self.lock:
            ids = list(self.account.positions.keys())
        for pid in ids:
            self._close_position(pid, source, reason)

    def _shutdown(self, reason):
        try:
            if self.bot is not None:
                try:
                    self._cb_name = "on_deinit"
                    self.bot.on_deinit(reason)
                except Exception:
                    self.log("Lỗi trong on_deinit:\n" + traceback.format_exc(limit=4), "ERROR")
            if self.account is not None and self.settings.get("close_on_stop"):
                if self.account.positions:
                    self.log("Đóng các lệnh còn mở khi dừng bot")
                    self._close_all("stop", "Đóng lệnh còn mở khi dừng bot")
        except Exception:
            self.log("Lỗi khi dừng:\n" + traceback.format_exc(limit=4), "ERROR")
        if self.status not in ("error", "stopped"):
            self.status = "stopped"
        self._save_state()
        self.log("Bot đã dừng (%s)" % reason)
        if self.feed is not None:
            try:
                self.feed.close()
            except Exception:
                pass

    # ---------------- sự kiện / lý do ----------------
    def _ai_info(self, ai):
        if ai is True:
            hub = self.ai_hub
            ai = hub.get_signal() if hub is not None else None
        if not isinstance(ai, dict):
            return None
        return jsonable({k: ai.get(k) for k in ("id", "by", "model", "action", "confidence", "sl_pct", "tp_pct",
                                                "reason", "age", "votes", "discussion", "mode") if k in ai})

    def _context(self):
        tick, b = self.last_tick, self.builder
        ind = {}
        with self.lock:
            for name, ser in self.plots.items():
                if ser:
                    ind[name] = next(reversed(ser.values()))

            def cd(c):
                return None if c is None else {"time": c.time, "open": c.open, "high": c.high, "low": c.low, "close": c.close}
            return jsonable({
                "callback": self._cb_name or "(ngoài callback)", "bid": tick.bid if tick else None,
                "ask": tick.ask if tick else None, "last_closed": cd(b.closed[-1] if b and b.closed else None),
                "current": cd(b.current if b else None), "indicators": ind, "params": self.bot_params,
                "balance": self.account.balance if self.account else None,
                "equity": self.account.equity() if self.account else None,
                "open_positions": len(self.account.positions) if self.account else 0,
                "mode": self.settings["mode"], "symbol": self.symbol, "timeframe": self.tf})

    def _add_event(self, kind, price, side="", volume=0.0, pos_id=0, source="bot", reason="",
                   details=None, ai=None, profit=0.0):
        t = self.last_tick.time if self.last_tick else time.time()
        ev_ctx = self._context()
        with self.lock:
            self._event_id += 1
            ev = TradeEvent(id=self._event_id, kind=kind, time=t, price=price, side=side, volume=volume,
                            pos_id=pos_id, source=source, reason=str(reason or ""),
                            details=jsonable(details or {}), context=ev_ctx, ai=self._ai_info(ai),
                            profit=profit, wall_time=time.time())
            self.events.append(ev)
        if self.events_file:
            try:
                with open(self.events_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(jsonable(ev), ensure_ascii=False) + "\n")
            except OSError:
                pass
        return ev

    def _note(self, text, price, side, details):
        if self.last_tick is None:
            return
        price = float(price) if price else self.last_tick.mid
        self._add_event("note", price, side or "", 0.0, 0, "bot", str(text)[:400], details)

    # ---------------- lưu / khôi phục phiên ----------------
    def _save_state(self):
        self._last_save = time.time()
        if not self.state_file or self.account is None:
            return
        try:
            with self.lock:
                data = {"bot_path": self.bot_path, "symbol": self.symbol, "mode": self.settings["mode"],
                        "saved_at": time.time(), "account": self.account.to_dict(),
                        "event_id": self._event_id}
            _atomic_write(self.state_file, json.dumps(data, ensure_ascii=False))
        except Exception:
            pass

    def _load_state(self):
        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            return
        if d.get("bot_path") != self.bot_path or d.get("symbol") != self.symbol or d.get("mode") != self.settings["mode"]:
            self.log("Bỏ qua phiên đã lưu (khác bot/cặp/chế độ)", "WARN")
            return
        self.account.restore(d.get("account", {}))
        self._event_id = int(d.get("event_id", 0))
        if self.events_file and os.path.exists(self.events_file):
            try:
                with open(self.events_file, "r", encoding="utf-8") as f:
                    for line in f.readlines()[-300:]:
                        self.events.append(_mk(TradeEvent, json.loads(line)))
                if self.events:
                    self._event_id = max(self._event_id, max(e.id for e in self.events))
            except Exception:
                pass
        self.log("KHÔI PHỤC phiên: %d lệnh mở, %d lệnh đã đóng, số dư %.4f" % (
            len(self.account.positions), len(self.account.trades), self.account.balance), "WARN")

    # ---------------- giao dịch ----------------
    def _open(self, side, volume, sl, tp, comment, reason="", details=None, ai=None):
        tick = self.last_tick
        if tick is None:
            return None
        try:
            volume = float(volume)
            sl = float(sl or 0.0)
            tp = float(tp or 0.0)
        except (TypeError, ValueError):
            self.log("Tham số lệnh không hợp lệ", "WARN")
            return None
        if volume <= 0 or math.isnan(volume):
            self.log("Khối lượng phải > 0", "WARN")
            return None
        price = tick.ask if side == "buy" else tick.bid
        if side == "buy":
            bad = (sl and sl >= price) or (tp and tp <= price)
        else:
            bad = (sl and sl <= price) or (tp and tp >= price)
        if bad:
            self.log("Từ chối lệnh %s: SL/TP sai phía so với giá %.8g (SL=%.8g TP=%.8g)"
                     % (side, price, sl, tp), "WARN")
            return None
        with self.lock:
            if not self.account.can_open(volume, price):
                self.log("Từ chối lệnh %s: không đủ vốn/ký quỹ" % side, "WARN")
                return None
            opposite = any(p.side != side for p in self.account.positions.values())
        if self.broker is not None:
            if side == "sell" and not self.broker.supports_short:
                self.log("LIVE spot không hỗ trợ bán khống -> bỏ lệnh sell (dùng exchange=binance_futures)", "WARN")
                return None
            if self.broker.supports_short and opposite:
                self.log("LIVE futures (one-way) không giữ đồng thời lệnh mua và bán -> bỏ lệnh %s" % side, "WARN")
                return None
            try:
                fill = self.broker.market_order(self.symbol, side, volume)
                self._order_fail = 0
            except BrokerError as e:
                self._order_failed("Đặt lệnh %s thất bại: %s" % (side, e))
                return None
            price, volume = fill.price, fill.qty
        with self.lock:
            pos = self.account.open(self.symbol, side, volume, price, sl, tp, comment, tick.time)
        auto = reason or (comment and "Bot vào lệnh: %s" % comment) or "Bot gửi lệnh %s (bot không ghi lý do)" % side
        src = "ai" if ai else "bot"
        d = dict(details or {})
        d.setdefault("SL", sl or "không đặt")
        d.setdefault("TP", tp or "không đặt")
        self._add_event("open", price, side, volume, pos.id, src, auto, d, ai)
        self.log("MỞ #%d %s %.8g @ %.8g | SL=%.8g TP=%.8g | %s" % (pos.id, side.upper(), volume, price, sl, tp, auto))
        self._notify("Mở lệnh %s %s" % (side.upper(), self.symbol), "%.8g @ %.8g · %s" % (volume, price, auto))
        self._save_state()
        return replace(pos)

    def _order_failed(self, msg):
        self._order_fail += 1
        self.log(msg, "ERROR")
        if self._order_fail == 3:
            self._alarm("Đặt lệnh thất bại liên tiếp", msg)

    def _close_position(self, pos_id, source="bot", reason="", details=None, ai=None):
        tick = self.last_tick
        with self.lock:
            pos = self.account.positions.get(pos_id)
        if pos is None or tick is None:
            return False
        if time.time() < self._close_retry.get(pos_id, 0):
            return False
        price = tick.bid if pos.side == "buy" else tick.ask
        if self.broker is not None:
            close_side = "sell" if pos.side == "buy" else "buy"
            try:
                price = self.broker.market_order(self.symbol, close_side, pos.volume, reduce_only=True).price
                self._order_fail = 0
            except BrokerError as e:
                self._close_retry[pos_id] = time.time() + 10
                self._order_failed("Đóng lệnh #%d thất bại: %s (thử lại sau 10s)" % (pos_id, e))
                return False
        with self.lock:
            tr = self.account.close(pos_id, price, tick.time, source)
        label = {"sl": "Stop Loss", "tp": "Take Profit", "manual": "Thủ công", "risk": "Ngưỡng lỗ", "stop": "Dừng bot",
                 "bot": "Bot", "ai": "AI"}.get(source, source)
        tr.reason = label
        auto = reason or "Bot đóng lệnh (bot không ghi lý do)"
        d = dict(details or {})
        d.setdefault("giá vào", pos.open_price)
        d.setdefault("giá ra", price)
        self._add_event("close", price, pos.side, pos.volume, pos.id, "ai" if (ai and source == "bot") else source,
                        auto, d, ai, tr.profit)
        self.log("ĐÓNG #%d %s @ %.8g | %s | P/L %+.4f | %s" % (tr.id, tr.side.upper(), price, label, tr.profit, auto))
        self._notify("Đóng lệnh %s %s (%s)" % (tr.side.upper(), self.symbol, label), "P/L %+.4f @ %.8g" % (tr.profit, price))
        self._save_trade(tr)
        self._save_state()
        return True

    def _save_trade(self, tr):
        if not self.trades_csv:
            return
        try:
            new = not os.path.exists(self.trades_csv)
            with open(self.trades_csv, "a", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["bot", "id", "symbol", "side", "volume", "open_price", "close_price",
                                "open_time", "close_time", "profit", "reason"])
                w.writerow([self.bot_name, tr.id, tr.symbol, tr.side, tr.volume, tr.open_price,
                            tr.close_price, tr.open_time, tr.close_time, round(tr.profit, 8), tr.reason])
        except OSError:
            pass

    def _plot(self, name, value, t):
        if value is None:
            return
        if t is None:
            if self.builder is None or self.builder.current is None:
                return
            t = self.builder.current.time
        with self.lock:
            series = self.plots.setdefault(str(name), OrderedDict())
            series[t] = float(value)
            while len(series) > 1500:
                series.popitem(last=False)

    # ---------------- ảnh chụp cho giao diện ----------------
    def snapshot(self, chart_bars=240, max_trades=30, max_events=250):
        base = {"status": self.status, "status_text": STATUS_TEXT.get(self.status, self.status),
                "message": self.message, "bot": self.bot_name, "symbol": self.symbol,
                "timeframe": self.tf, "mode": self.settings["mode"], "ready": False,
                "bot_status": self.bot_status, "events": []}
        with self.lock:
            acc = self.account
            if acc is None or self.last_tick is None:
                return base
            tr = acc.trades
            wins = sum(1 for t in tr if t.profit > 0)
            candles = list(self.builder.closed)[-chart_bars:]
            if self.builder.current is not None:
                candles.append(replace(self.builder.current))
            times = {c.time for c in candles}
            plots = {n: [(t, v) for t, v in s.items() if t in times] for n, s in self.plots.items()}
            eq = acc.equity()
            base.update({
                "ready": True,
                "bid": self.last_tick.bid, "ask": self.last_tick.ask, "tick_time": self.last_tick.time,
                "ticks": self.ticks,
                "uptime": (time.time() - self.started_at) if self.started_at else 0.0,
                "balance": acc.balance, "equity": eq, "floating": acc.floating(),
                "start_balance": acc.start_balance,
                "pnl": eq - acc.start_balance,
                "pnl_pct": (eq - acc.start_balance) / acc.start_balance * 100.0 if acc.start_balance else 0.0,
                "max_dd": acc.max_drawdown,
                "n_trades": len(tr), "wins": wins,
                "win_rate": (wins / len(tr) * 100.0) if tr else 0.0,
                "positions": [replace(p) for p in acc.positions.values()],
                "trades": [replace(t) for t in tr[-max_trades:]][::-1],
                "candles": candles, "plots": plots,
                "equity_curve": list(self.equity_hist)[-200:],
                "events": [replace(e) for e in list(self.events)[-max_events:]],
            })
        return base
