"""Điểm vào của app (buildozer yêu cầu main.py ở thư mục gốc)."""
import threading
import traceback

from pyea.ui import PyEAApp


def _run():
    app = PyEAApp()
    # lỗi trong thread nền của UI: ghi nhật ký, không làm sập app
    threading.excepthook = lambda a: app.note_ui_error("".join(traceback.format_exception(a.exc_type, a.exc_value, a.exc_traceback)))
    try:
        app.run()
    except Exception:
        # sắp crash: ghi file + báo động (bot nền, nếu đang chạy, vẫn sống vì ở tiến trình riêng)
        app.report_fatal(traceback.format_exc())
        raise


if __name__ == "__main__":
    _run()
