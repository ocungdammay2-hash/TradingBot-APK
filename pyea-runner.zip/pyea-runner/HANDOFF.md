# PyEA Runner — HANDOFF (đọc file này trước, ~5 phút)
Cập nhật: 2026-10-15 · Trạng thái: **code đầy đủ; lõi + logic UI test được (43 test); build APK, hiển thị Kivy thật, Android API CHƯA chạy thử thật**.

## 1. Yêu cầu của người dùng (nguồn sự thật)
1. APK Android (build bằng GitHub Actions từ zip) **chạy file Python giao dịch tự động**, nạp file như MT5 nạp .mq5 (EA).
2. GUI hiển thị bot chạy thế nào + **bảng thông số trực quan** để nhập tham số.
3. **Chat AI** nhiều API model: đọc file bot, **giải thích thuật toán**, **sửa file bot** theo ý người dùng.
4. Chế độ chat: 1 model · nhóm model + người dùng · nhóm model **tự thảo luận** thị trường để ra quyết định cho bot (không người dùng). Người dùng chọn.
5. Model **ưu tiên miễn phí** hoặc **chuyên biệt tài chính**.
6. **Không hardcode thiết bị**, **tối ưu cho "cats52" (Cat S52)**.
7. **Biểu đồ kiểu MT5**: chấm vào/ra lệnh; **chạm vào chấm → popup lý do** (thuật toán bot: điều kiện + thông số kích hoạt; hoặc AI: model nào, lý do gì); **ẩn/hiện đường chỉ báo**; thấy cách bot hoạt động trên đồ thị.
8. Phần mềm giao dịch tự động ⇒ **tối ưu cực mạnh chạy nền**, **thông báo trên thanh trạng thái** khi bot chạy, **báo động nếu app/bot crash**.
9. UI/ngôn ngữ người dùng: **tiếng Việt**. Zip build được trên GitHub; tài liệu này để người/AI khác làm tiếp, không làm lại từ đầu.

## 2. Cat S52 (đã tra cứu)
5.65" 720×1440 · 4GB RAM · **Android 9** (nguồn nói nâng được 10) · **MediaTek Helio P35** (một nguồn ghi nhầm Snapdragon 630) · 3100mAh · dùng được tay ướt/găng.
Áp dụng (không check tên máy): minapi 24 · build **arm64-v8a + armeabi-v7a** (chưa biết ROM 32/64-bit; bỏ v7a để build nhanh gấp đôi nếu chắc 64-bit) · vùng chạm ≥48dp + **danh sách "điểm vào/ra gần đây" bấm được** (chấm trên biểu đồ nhỏ khó bấm) · tab chia đều `Window.width/5` · `ui_refresh`, `power_mode=saver` (≥3s/tick khi UI ở nền), publish 10s khi UI ẩn · dịch vụ nền không cần giữ màn hình sáng.

## 3. Kiến trúc
**Kivy 2.3.0 + python-for-android (buildozer 1.5.0)**, chỉ thư viện thuần Python (`certifi`, `pyjnius`, `android`); HTTP `urllib`+certifi. Core **không import Kivy** (test được).
```
main.py → pyea/ui.py (Bot|Thông số|Giám sát|AI|Nhật ký) + ui_widgets.py (CandleChart có trục/chấm/chạm, ParamForm, Table, chip)
service_main.py → pyea/ipc.py ServiceHost  (DỊCH VỤ NỀN foreground+sticky, tiến trình riêng)
sdk.py        Tick/Candle/Position/Trade/TradeEvent, Input, BaseBot, jsonable
engine.py     Account · CandleBuilder · BotContext(=self.api) · BotRunner(thread): sự kiện+lý do, lưu/khôi phục sổ lệnh, alarm_cb
feeds.py      SimFeed · BinanceFeed(spot/futures, public) · resolve_base(testnet)   broker.py  BinanceBroker(spot) · BinanceFuturesBroker(long/short, reduceOnly) · make_broker
ai.py         PRESETS · chat_completion · AIHub (1 AI / nhóm / tự thảo luận; chốt "decider" hoặc "majority") · tally_votes · market_context
ipc.py        file-IPC: cmd/*.json (UI→host), state.json (host→UI), events.jsonl, host.hb, ui.hb, desired.json (khôi phục sau crash) · ServiceClient/ServiceHandle(UI)/ServiceHost
explain.py    TradeEvent → các mục popup (nguồn, lý do, điều kiện, chỉ báo lúc đó, tham số, AI + từng model, trích thảo luận)
android_native.py  pyjnius không Kivy: start_service, set_service_notification, notify_alarm, wakelock+wifilock, xin bỏ tối ưu pin, device_info
android_utils.py   SAF picker, keep-awake, nút Back · diagnostics.py báo cáo "Kiểm tra hệ thống" · storage.py (ChatLog jsonl dùng chung) · settings.py GLOBAL_INPUTS
pyea/examples/*.py.txt  ma_cross, rsi_reversion, ai_follow, template_bot (đã dùng reason/details/status/signal)
```
**API bot** (như MQ5): `on_init/on_tick/on_bar/on_deinit`; `inputs={...Input}`; `self.p.x`; `self.api`: `buy/sell(volume,sl,tp,comment,reason,details,ai)`, `close/close_all(...,reason,details,ai)`, `positions/modify`, `candles/closes`, `plot`, **`status(text)`**, **`signal(text,price,side,details)`** (chấm xám "tín hiệu bị bỏ qua"), `ai_signal`, `log`. Cheat-sheet: `ai.SDK_CHEATSHEET`. Bot không ghi lý do ⇒ engine tự chụp ngữ cảnh (callback, bid/ask, nến, giá trị mọi đường `plot`, tham số, vốn).

## 4. Pipeline
**Runner**: `_setup`(nạp bot, feed, history, Account, tuỳ chọn `_load_state`) → `on_init` → mỗi `tick_interval`: feed.tick → CandleBuilder → Account.mark → SL/TP → max_loss → on_bar → on_tick → lệnh UI → lưu `session_state.json` (mỗi lệnh + 20s). Mỗi vào/ra/note ⇒ `TradeEvent` (+`events.jsonl`).
**Chạy nền (Android)**: UI ghi `cmd/start` → `native.start_service` → `ServiceHost.run` (0.25s/vòng): nhận lệnh, chạy BotRunner + AIHub riêng, `touch host.hb`, publish `state.json` (1s UI mở / 10s UI ẩn), cập nhật thông báo foreground mỗi 12s (`PyEA • bot • SYMBOL • Equity • lệnh mở`), tự thoát sau khi bot xong. UI mở lại ⇒ `ServiceHandle.attach`. Thoát app **không** dừng bot (có hộp thoại chọn).
**Báo động**: dịch vụ gọi `notify_alarm` khi bot lỗi/đạt max_loss/mất giá 20 lần/đặt lệnh lỗi 3 lần/dịch vụ crash-restart; **watchdog UI**: `host.hb` quá 8s khi bot đang chạy ⇒ báo động + khởi động lại dịch vụ (tối đa 3 lần/10 phút); **tự khôi phục**: host khởi động mà `desired.json.running=true` ⇒ chạy lại bot với `resume=True` (khôi phục sổ lệnh + sự kiện), chặn vòng lặp (≥3 lần/5 phút ⇒ dừng + báo động); `service_main` bọc vòng lặp bắt exception, ghi `service_crash.log`; UI: `CrashHandler` giữ app sống + `crash.log` + popup lần mở sau; `report_fatal` báo động khi app sắp crash.
**Fallback**: dịch vụ không khởi động/không phản hồi 25s ⇒ chạy trực tiếp trong app (dừng khi thoát app).
**AI**: chat lưu `chat.jsonl` (UI và dịch vụ cùng ghi, UI poll theo offset). Tự thảo luận chạy ở nơi chứa bot (dịch vụ khi chạy nền). Tín hiệu `{id,action,confidence,sl_pct,tp_pct,reason,by,model,mode,votes[],discussion[]}` TTL `ai_signal_ttl`; bot dùng `ai=sig` khi đặt lệnh ⇒ popup hiện từng model + lý do. **AI chỉ tư vấn, bot quyết định cuối.** Sửa bot: khối ```python → `check_bot_code` (ast, không exec) → diff → lưu bản mới/ghi đè+.bak.
**Live**: Binance Spot (không short) hoặc **Futures USDT-M** (long/short, one-way, `reduceOnly` khi đóng, không giữ đồng thời mua+bán, đòn bẩy), **Testnet**, popup xác nhận, `live_confirm`.
**Build**: push → `.github/workflows/build-apk.yml` (ubuntu-22.04, JDK17, buildozer 1.5.0, cython 0.29.37, p4a v2024.01.21, NDK 25b, API 33) → artifact `pyearunner-apk` (+Release nếu tag `v*`). `buildozer.spec`: `services = Botservice:service_main.py:foreground:sticky`, `android.no-byte-compile-python=True`, `allow_backup=False`.

## 5. Trạng thái
✅ **43 test pass** (`python -m unittest discover -s tests`): lõi; sự kiện+lý do+explain; khôi phục sổ lệnh; ServiceHost/Handle qua file-IPC, crash-recovery, chống restart-storm; Binance spot/futures với **sàn giả cục bộ** (kiểm tra chữ ký HMAC, short, reduceOnly, hedge-mode, lỗi lệnh→alarm); biểu quyết AI; ChatLog 2 writer; chẩn đoán; **logic UI bằng Kivy GIẢ** (`tests/kivy_stub.py`): dựng UI, form↔lưu, chạy bot, nhận sự kiện, hit-test chạm chấm→popup chứa lý do, chip ẩn/hiện, zoom/pan, chế độ dịch vụ end-to-end, fallback, AI tab, crash log.
❌ **CHƯA chạy thật**: Kivy thật (vẽ/layout/cảm ứng), `buildozer` build, mọi API Android (service, notification, wakelock, SAF, pin), HTTP thật tới Binance/nhà cung cấp AI, live thật.
**Việc tiếp theo**: (1) push GitHub, chạy workflow, sửa lỗi build; (2) trên Cat S52: Nhật ký → **Kiểm tra hệ thống** → dán báo cáo; (3) chạy bot paper, thoát app, kiểm tra thông báo + bot còn chạy, mở lại xem gắn lại; (4) thử chạm chấm; (5) thêm 1 AI miễn phí + thử "tự thảo luận"; (6) live **Testnet** trước; (7) backtest, đa symbol, lệnh chờ, mã hoá API key (Android Keystore).

## 6. Điều cần tránh / rủi ro đã biết
- Sandbox: `/bin/sh` không nở `{a,b}`; không mạng ⇒ không cài được Kivy ⇒ UI chỉ test bằng stub (không bắt được lỗi layout/vẽ).
- **Font Kivy thiếu dấu Việt** ⇒ nạp DejaVu đè tên `Roboto`; **không emoji**. **Label texture ≲4096px** ⇒ log/code/popup dài chia nhiều Label (`add_text_block`), chat cắt 3000 ký tự. `Popup(background="")` ⇒ hộp trắng. Số phập phồng: dùng TextInput text, `coerce` nhận dấu `,`.
- **p4a có thể xoá .py khi byte-compile** ⇒ ví dụ lưu `*.py.txt` + `android.no-byte-compile-python=True` (tên khoá chưa kiểm chứng).
- **Điểm tôi KHÔNG chắc về p4a/Android (kiểm tra đầu tiên khi build)**: tên lớp dịch vụ `<package>.ServiceBotservice`; chữ ký `Service*.start(ctx,"icon",title,text,arg)` (có fallback `start(ctx,arg)`); `sticky` restart có thể không kèm argument ⇒ đã thiết kế host đọc `desired.json`; `startForeground(7001,…)` đổi thông báo của p4a (nếu lỗi: thông báo mặc định của p4a vẫn hiện); icon nhỏ dùng icon app (có thể thành ô trắng); Android 13+ cần quyền `POST_NOTIFICATIONS` (đã xin lúc mở app); Android 14+ cần `foregroundServiceType` nếu nâng target API ≥34.
- Back mặc định thoát app ⇒ `moveTaskToBack`. SAF picker callback không ở main thread ⇒ `@mainthread`. HTTPS cần `certifi`. Binance có thể bị chặn vùng ⇒ `base_url`/`simulated`; đã đồng bộ giờ server. Futures: tài khoản phải **One-way mode**; `/fapi/v2/balance` có thể đổi sang v3 (đã thử cả hai).
- Build: ghim p4a/NDK/API/buildozer/cython như §4; **ubuntu-22.04 (libtinfo5)**. Upload web GitHub bỏ qua thư mục ẩn `.github` ⇒ dùng `git push` hoặc tạo tay (`docs/build-apk.yml`).
- Không thể bắt "app bị vuốt đóng" vs "crash" ⇒ báo động crash chỉ khi Python bắt được lỗi / dịch vụ chết (watchdog khi UI còn). Nếu CẢ HAI tiến trình chết đột ngột (OOM) thì chỉ có sticky-restart của Android lo; không có AlarmManager watchdog.
- LLM giao dịch **không đáng tin** ⇒ chỉ tín hiệu có TTL; nên `majority`; luôn thử paper → testnet → live nhỏ. API key lưu **plaintext** trong `user_data_dir` (backup đã tắt, chưa mã hoá). Free tier/tên model đổi liên tục (PRESETS chỉ là ví dụ); OpenRouter ToS cấm bán lại; model tài chính (Fin-R1, FinGPT) thường phải tự host.
- Bot do người dùng/AI viết chạy toàn quyền Python ⇒ chỉ nạp file tin cậy. Ghi đĩa state.json mỗi giây khi UI mở (hao flash) — đã giảm còn 10s khi ẩn.

## 7. Quy ước
Comment/UI tiếng Việt; định danh tiếng Anh; core không import Kivy; thread nền → UI qua `@mainthread`; mọi thay đổi core phải chạy `tests/`; thêm khả năng mới cho bot ⇒ cập nhật `ai.SDK_CHEATSHEET` + ví dụ + README.
