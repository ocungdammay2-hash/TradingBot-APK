# PyEA Runner — HANDOFF (đọc trước, ~6 phút)
Cập nhật: 2026-10-16 · **68 test pass** (lõi + logic UI bằng Kivy giả). **Chưa chạy**: Kivy thật, `buildozer` build, API Android, HTTP thật tới sàn/AI, live thật.

## 1. Yêu cầu của người dùng (nguồn sự thật)
1. APK Android build bằng GitHub Actions từ zip; **chạy file Python giao dịch tự động** (nạp như MT5 nạp .mq5).
2. GUI giám sát + **bảng thông số trực quan**.
3. **Giống MT5**: nhiều loại tài sản (Market Watch); **gắn bot vào tài sản** để tự giao dịch; **đặt lệnh thủ công**; **backtest (Strategy Tester)**.
4. **Biểu đồ kiểu MT5**: chấm vào/ra, **chạm → popup lý do** (bot: điều kiện + thông số kích hoạt; AI: model nào/lý do gì), **ẩn/hiện chỉ báo**.
5. **Chat AI** nhiều API model: giải thích thuật toán, **sửa bot**; chế độ 1 AI / nhóm+người dùng / nhóm tự thảo luận ra quyết định cho bot; ưu tiên model miễn phí hoặc chuyên tài chính.
6. **Chạy nền cực mạnh**, thông báo thanh trạng thái, **báo động khi crash**.
7. **Không hardcode thiết bị**, **tối ưu cho "cats52" (Cat S52)**. UI tiếng Việt. Tài liệu để người/AI khác làm tiếp không lặp lỗi cũ.

## 2. Cat S52 (đã tra cứu)
5.65" 720×1440 · 4GB · **Android 9** (có thể 10) · **MediaTek Helio P35** (1 nguồn ghi nhầm Snapdragon 630) · 3100mAh · tay ướt/găng. Áp dụng không check tên máy: minapi 24; build **arm64-v8a + armeabi-v7a** (chưa biết ROM 32/64-bit); vùng chạm ≥48dp + **danh sách điểm vào/ra bấm được** (chấm nhỏ khó bấm); **8 tab, thanh tab cuộn ngang** (tab ≥78dp); `ui_refresh`, `power_mode=saver`, publish 10s khi UI ẩn; dịch vụ nền không cần sáng màn hình.

## 3. Kiến trúc (Kivy 2.3.0 + python-for-android, thuần Python; core KHÔNG import Kivy)
```
main.py → pyea/ui.py (8 tab) + ui_widgets.py (CandleChart: trục/chấm/chạm; ParamForm; Table; chip)
service_main.py → ipc.ServiceHost  (dịch vụ nền foreground+sticky, tiến trình riêng)
engine.py   TradingSession = MỘT tài khoản chung (paper/live) + vòng lấy giá cho mọi mã cần (watchlist+bot+vị thế+chart)
            + SL/TP + ngưỡng lỗ + open/close/modify_position (thủ công hoặc bot) + sự kiện/lý do + lưu/khôi phục sổ lệnh
            BotRunner = 1 bot GẮN vào (mã, khung) (thread, nhận tick từ session; chỉ thấy lệnh của mình qua owner=iid)
            BotRunner(path, settings, params) đứng riêng tự tạo session riêng (API cũ, dùng trong test)
feeds.py    SimFeed (8 tài sản giả) · BinanceFeed (spot/futures) · OandaFeed · fetch_history (phân trang) · resolve_base
broker.py   BinanceBroker(spot) · BinanceFuturesBroker(short, reduceOnly, đòn bẩy theo mã) · OandaBroker · make_broker
            (netting=True ⇒ không giữ đồng thời mua+bán cùng mã)
backtest.py run_backtest (chạy ĐỒNG BỘ trên chính TradingSession(sync=True): SL/TP/phí/ký quỹ/sự kiện y như thật),
            compute_report, optimize (quét lưới); mô phỏng tick: ohlc(4 tick/nến) | open
controller.py LocalController  ⇄  ipc.ServiceHandle  (CÙNG giao diện cho UI: snapshot/chart/events/place_order/close/modify/attach/...)
ipc.py      file-IPC: cmd/*.json, state.json, events.jsonl, host.hb, ui.hb, desired.json (khôi phục sau crash)
ai.py       PRESETS, chat_completion, AIHub (1 AI/nhóm/tự thảo luận; decider|majority), tally_votes, market_context
explain.py  TradeEvent → popup  ·  codeedit.py (AI sửa bot) · diagnostics.py · android_native.py (pyjnius, không Kivy)
sdk.py (BaseBot: tham số = self.p.x = self.x; _set_params) settings.py (GLOBAL_INPUTS, EXCHANGE_WATCH) storage.py (ChatLog jsonl, instances.json, prefs) loader.py (collect_inputs: nhận dạng tham số 3 dạng; chọn lớp bot 'lá') indicators.py
```
**8 tab**: Thị trường (Market Watch + KẾT NỐI) · Giao dịch (vị thế mọi mã, Lệnh mới, Sửa/Đóng) · Bot (gắn bot vào mã+khung, thư viện .py) · Biểu đồ · Backtest · AI · Cài đặt · Nhật ký.
**API bot**: `on_init/on_tick/on_bar/on_deinit`; `inputs`; `self.p`; `self.api`: `symbol,timeframe,tick,balance,equity,ai_signal`, `buy/sell(volume,sl,tp,comment,reason,details,ai)`, `close/close_all/modify/positions` (chỉ lệnh của bot), `candles/closes`, `plot`, `status`, `signal`, `log`. Cheat-sheet: `ai.SDK_CHEATSHEET`.

## 4. Luồng
**Session thread** (mỗi `tick_interval`): `poll_once` → mỗi mã cần: `feed.tick` → `process_tick` (ghép nến mọi builder của mã, `Account.mark` chỉ vị thế cùng mã, SL/TP cho MỌI vị thế kể cả thủ công, phát (tick, nến đóng) vào queue từng bot gắn mã đó) → `_check_max_loss` (dừng cả phiên). **Bot thread**: lấy tick → `on_bar` (nếu nến đóng) → `on_tick`; lỗi bot ⇒ chỉ bot đó `error` + alarm. Builder nến dùng chung (mã,khung) cho bot và biểu đồ. Sổ lệnh lưu `session_state.json` (mỗi lệnh + 20s), sự kiện `events.jsonl`.
**Chạy nền**: UI `cmd/session_start{settings, instances[]}` → `native.start_service` → `ServiceHost.run` (0.25s/vòng): nhận lệnh (order/close/modify/attach/detach/inst_start/inst_stop/watch/chart/ai_auto), `touch host.hb`, publish `state.json` (snapshot + chart của mã đang xem; 1s UI mở / 10s UI ẩn), cập nhật thông báo foreground 12s. UI mở lại ⇒ `ServiceHandle.attach_running`. Thoát app không dừng phiên (hộp thoại chọn).
**Báo động**: `notify_alarm` khi bot/phiên lỗi, đạt max_loss, mất giá 20 lần, đặt lệnh lỗi 3 lần, dịch vụ crash/restart; watchdog UI (`host.hb` >8s khi phiên đang chạy ⇒ báo + khởi động lại dịch vụ, ≤3 lần/10 phút); host khởi động mà `desired.running` ⇒ **resume** (khôi phục sổ lệnh + gắn lại bot, cùng iid), chặn restart-storm; `service_main` bọc vòng lặp + `service_crash.log`; UI `CrashHandler` giữ app sống + `crash.log` + popup lần sau + `report_fatal`. Dịch vụ không phản hồi 25s ⇒ chạy trực tiếp trong app.
**AI**: chat `chat.jsonl` (UI và dịch vụ cùng ghi, UI poll offset). Tự thảo luận chạy nơi chứa phiên; tín hiệu có `votes[]`,`discussion[]`; bot đặt lệnh với `ai=sig` ⇒ popup hiện từng model + lý do. AI chỉ tư vấn.
**Build**: `.github/workflows/build-apk.yml` tự dò thư mục chứa `buildozer.spec`; nếu repo chỉ có **file .zip** (người dùng đã upload nguyên zip - GitHub không tự giải nén; đây là lỗi thật đã gặp, repo có `pyea-runner.zip` ở gốc và trong `.github/workflows/`) thì **tự giải nén** zip chứa `buildozer.spec` vào `_src/` rồi build.

## 4b. Tham số: nhận dạng + đồng bộ (như MT5)
`loader.collect_inputs(cls, path)`: (1) `inputs={...}` + (2) thuộc tính lớp `= Input(...)` (gộp qua kế thừa); (3) chỉ khi trống: `ast` đọc thuộc tính có chú thích kiểu + literal (`lot: float = 0.01  # nhãn [a|b|c]`, `# == Nhóm ==`). → `ParamForm` tự sinh form; giá trị lưu theo từng instance (`instances.json`, `desired.json`) + mặc định theo file bot (`params/`) + bộ có tên (`presets/`). **Đổi tham số lúc đang chạy** (`BotRunner.apply_params`, trong thread của bot): `on_deinit("params")` → `bot._set_params(new)` → `on_init()`; lệnh giữ nguyên; `on_init()==False` ⇒ hoàn tác về tham số cũ + alarm (bot không chết); ghi chấm ◆ "Đổi tham số" lên biểu đồ. IPC: lệnh `params` (host cập nhật cả `desired` để resume dùng tham số mới). MT5 tham chiếu: OnDeinit(REASON_PARAMETERS) rồi OnInit, EA giữ nguyên trong bộ nhớ; OnInit trả INIT_PARAMETERS_INCORRECT ⇒ từ chối (đã tra cứu tài liệu MQL5).

## 5. Đã xác minh bằng tài liệu chính thức (không còn là phỏng đoán)
- p4a services: cú pháp `services = tên:file.py:foreground:sticky` ✓; `Service<Tên capitalize>`; `start(ctx,"icon",title,text,arg)` và `start(ctx,arg)` ✓; sticky restart có thể không kèm argument ✓ ⇒ `service_main` dùng `getFilesDir()` (cũng là data_dir của UI) + `desired.json`.
- OANDA v20: host practice/live; `pricing`, `instruments`, `candles`(granularity/count/to/price=M), `orders` MARKET FOK `units` âm = bán, `positionFill REDUCE_ONLY`, `summary` ✓.
- Binance: `positionSide/dual`, `leverage`, `order` (reduceOnly), futures `v2/v3 balance` (thử cả hai).
**Còn KHÔNG chắc / chưa kiểm chứng**: khoá `android.no-byte-compile-python` (buildozer bỏ qua khoá lạ; ví dụ đã lưu `.py.txt` nên vẫn an toàn); `startForeground(7001,…)` thay thông báo của p4a (lỗi ⇒ vẫn còn thông báo mặc định); icon nhỏ dùng icon app; Android 13+ cần `POST_NOTIFICATIONS` (đã xin), Android 14+ cần `foregroundServiceType` nếu nâng target API ≥34; URL Cerebras/NVIDIA/Gemini-compat; hành vi OANDA thật (netting, units tối thiểu, margin) mới thử với sàn giả.

## 6. Trạng thái & việc tiếp theo
✅ 68 test: lõi, sự kiện/lý do, khôi phục, session nhiều tài sản + 2 bot + lệnh thủ công + SL/TP lệnh tay, backtest (khớp sổ lệnh, tất định, lỗi bot, ngưỡng lỗ, dừng, tối ưu), Binance spot/futures + OANDA bằng **sàn giả cục bộ** (chữ ký HMAC, short, reduceOnly, hedge-mode, netting), dịch vụ nền qua IPC (lệnh thủ công, attach/detach, crash-recovery, storm guard), AI vote, ChatLog, **logic UI bằng `tests/kivy_stub.py`** (dựng 8 tab, kết nối, đặt/sửa/đóng lệnh, gắn bot, chạm chấm→popup, backtest end-to-end, chế độ dịch vụ, fallback).
❌ Chưa chạy thật. **Việc tiếp**: (1) push GitHub, chạy workflow, sửa lỗi build; (2) trên Cat S52: Nhật ký → **Kiểm tra hệ thống**; (3) kết nối `simulated`, thử Market Watch, đặt lệnh tay, gắn bot, thoát app xem thông báo + bot còn chạy, backtest; (4) nguồn thật paper (Binance/OANDA demo) rồi **Testnet/Demo** trước live; (5) bổ sung: lệnh chờ (limit/stop), nhiều sàn cùng lúc, mã hoá API key (Android Keystore), AlarmManager watchdog, backtest nhiều mã/walk-forward, đa tiền tệ tài khoản.

## 7. Điều cần tránh
- Sandbox: `/bin/sh` không nở `{a,b}`; không mạng ⇒ không cài Kivy ⇒ UI chỉ test bằng stub (không bắt lỗi layout/vẽ/cảm ứng). **Kivy `children` lưu ĐẢO NGƯỢC** (thêm sau ở index 0) — test phải đảo lại khi tìm theo thứ tự thêm.
- **Font Kivy thiếu dấu Việt** ⇒ nạp DejaVu đè `Roboto`; không emoji. **Label texture ≲4096px** ⇒ văn bản dài chia nhiều Label (`add_text_block`), log mỗi dòng 1 Label. `Popup(background="")` ⇒ hộp trắng. Số: TextInput text, `coerce` nhận `,`.
- p4a có thể xoá `.py` khi byte-compile ⇒ ví dụ `*.py.txt` + `android.no-byte-compile-python=True`.
- Back thoát app ⇒ `moveTaskToBack`. SAF picker callback ngoài main thread ⇒ `@mainthread`. HTTPS cần `certifi`. Binance bị chặn vùng ⇒ `base_url`/simulated. Futures phải **One-way mode**; OANDA gộp vị thế ⇒ không giữ mua+bán cùng mã.
- **Build trên GitHub cần JDK 17 ĐẶT QUA `actions/setup-java@v4` (temurin 17)**: runner ubuntu-22.04 mặc định JAVA_HOME = Temurin 11 (log buildozer: `javac found at .../temurin-11-jdk...`); `apt install openjdk-17-jdk` KHÔNG đổi JAVA_HOME nên không đủ. CI chính thức của buildozer cũng dùng setup-java 17. Workflow còn: `tee build.log` + bước 'Show error summary' (grep lỗi + 80 dòng cuối vào Summary) + artifact `buildozer-log` + `actions/cache/save` chạy `if: always()` (build 15 phút mà lỗi thì lần sau không làm lại từ đầu). Log GitHub UI hay bị cắt - đừng chẩn đoán từ log cụt.
- Build: ghim p4a v2024.01.21 / NDK 25b / API 33 / buildozer 1.5.0 / cython 0.29.37 / **ubuntu-22.04 (libtinfo5)**; GitHub web upload bỏ thư mục ẩn `.github` ⇒ dùng git hoặc tạo tay (`docs/build-apk.yml`).
- Chọn lớp bot trong file: ưu tiên lớp 'lá' (không là cha của lớp bot khác); trước đây chọn lớp khai báo đầu tiên ⇒ sai khi có lớp cha. Dạng 3 (thuộc tính có kiểu) bỏ qua biểu thức không phải literal và các tên `name/version/author/description/inputs`.
- Test dùng thời gian thật ⇒ thỉnh thoảng flaky khi máy chậm (tăng timeout trước khi nghi ngờ code). Ký quỹ test: paper leverage=1 ⇒ nhớ đặt `initial_balance` đủ lớn.
- Không phân biệt được "vuốt đóng app" với crash; nếu cả UI lẫn dịch vụ chết đột ngột chỉ có sticky-restart của Android lo (chưa có AlarmManager).
- LLM giao dịch không đáng tin ⇒ tín hiệu TTL, nên `majority`; luôn paper → testnet/demo → live nhỏ. API key lưu plaintext (backup tắt). Free tier/tên model đổi liên tục; model tài chính thường phải tự host.
- Bot người dùng/AI chạy toàn quyền Python ⇒ chỉ nạp file tin cậy. Ghi `state.json` mỗi giây khi UI mở (hao flash) ⇒ 10s khi ẩn.

## 8. Quy ước
Comment/UI tiếng Việt; định danh tiếng Anh; core không import Kivy; thread nền → UI qua `@mainthread`; mọi thay đổi core chạy `tests/`; khả năng mới cho bot ⇒ cập nhật `ai.SDK_CHEATSHEET` + ví dụ + README.
