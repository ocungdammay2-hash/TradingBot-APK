"""Chạy:  python -m unittest discover -s tests -v   (không cần Kivy)"""
import os, sys, tempfile, time, unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import Input, ta
from pyea import ai, codeedit
from pyea.engine import BotRunner, CandleBuilder, Account
from pyea.feeds import SimFeed
from pyea.loader import inspect_bot, build_params
from pyea.sdk import Candle, Tick
from pyea.settings import default_settings, clean_settings
from pyea.storage import Store

_TMP = tempfile.mkdtemp()
_STORE = Store(_TMP)
_STORE.seed_examples()
EXAMPLES_DIR = _STORE.bots_dir


class TestIndicators(unittest.TestCase):
    def test_sma_ema_rsi(self):
        v = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        self.assertEqual(ta.sma(v, 5), 8.0)
        self.assertIsNone(ta.sma(v, 20))
        self.assertAlmostEqual(ta.ema(v, 3), 9.0, places=6)
        self.assertEqual(ta.rsi(list(range(1, 40)), 14), 100.0)
        self.assertAlmostEqual(ta.rsi([5.0] * 30, 14), 50.0)
        self.assertTrue(0 < ta.rsi([1, 3, 2, 4, 3, 5, 4, 6, 5, 4, 3, 5, 6, 5, 4, 6], 14) < 100)

    def test_atr_boll_macd(self):
        cs = [Candle(i, 10, 11, 9, 10) for i in range(30)]
        self.assertAlmostEqual(ta.atr(cs, 14), 2.0)
        m, up, lo = ta.bollinger([1.0, 2.0, 3.0, 4.0, 5.0] * 6, 5)
        self.assertAlmostEqual(m, 3.0)
        self.assertGreater(up, m)
        self.assertIsNotNone(ta.macd([float(i % 7) for i in range(80)]))
        self.assertTrue(ta.crossed_up(1, 2, 3, 2))
        self.assertTrue(ta.crossed_down(3, 2, 1, 2))


class TestInput(unittest.TestCase):
    def test_coerce(self):
        self.assertEqual(Input(10, min=2, max=20).coerce("12"), 12)
        self.assertEqual(Input(1.0).coerce("1,5"), 1.5)
        self.assertTrue(Input(False).coerce("true"))
        self.assertEqual(Input("a", choices=["a", "b"]).coerce("b"), "b")
        for bad in ("abc", "1.5"):
            with self.assertRaises(ValueError):
                Input(10).coerce(bad)
        with self.assertRaises(ValueError):
            Input(10, min=2).coerce("1")
        with self.assertRaises(ValueError):
            Input("a", choices=["a"]).coerce("z")

    def test_settings(self):
        d = default_settings()
        self.assertEqual(clean_settings({"symbol": "ETHUSDT", "leverage": "abc"})["leverage"], d["leverage"])


class TestLoader(unittest.TestCase):
    def test_examples_load(self):
        for n in os.listdir(EXAMPLES_DIR):
            if n.endswith(".py"):
                info = inspect_bot(os.path.join(EXAMPLES_DIR, n))
                self.assertTrue(info.ok, "%s: %s" % (n, info.error))
                p = build_params(info.inputs, {})
                self.assertEqual(set(p), set(info.inputs))

    def test_bad_files(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "bad.py")
            open(p, "w").write("def (:\n")
            self.assertFalse(inspect_bot(p).ok)
            p2 = os.path.join(d, "nocls.py")
            open(p2, "w").write("x = 1\n")
            self.assertIn("BaseBot", inspect_bot(p2).error)


class TestCandles(unittest.TestCase):
    def test_builder(self):
        b = CandleBuilder(60)
        self.assertIsNone(b.update(0, 10))
        self.assertIsNone(b.update(30, 12))
        done = b.update(61, 11)
        self.assertEqual((done.open, done.high, done.low, done.close), (10, 12, 10, 12))
        self.assertEqual(b.current.time, 60)

    def test_account_pnl(self):
        a = Account(1000, 0.1, 1)
        pos = a.open("X", "buy", 1.0, 100.0, 0, 0, "", 0)
        a.mark(Tick("X", 1, 110.0, 110.2))
        self.assertAlmostEqual(pos.profit, 10.0 - 0.1, places=6)
        tr = a.close(pos.id, 110.0, 2, "Bot")
        self.assertAlmostEqual(tr.profit, 10.0 - 0.1 - 0.11, places=6)
        self.assertAlmostEqual(a.balance, 1000 + tr.profit)


class TestEngine(unittest.TestCase):
    def _run(self, bot, seconds=4.0, **over):
        s = default_settings()
        s.update(tick_interval=0.2, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=True)
        s.update(over)
        r = BotRunner(os.path.join(EXAMPLES_DIR, bot), s, {"fast": 3, "slow": 8} if bot == "ma_cross.py" else {})
        r.start()
        time.sleep(seconds)
        snap_mid = r.snapshot()
        r.stop()
        r._thread.join(5)
        return r, snap_mid

    def test_ma_cross_trades(self):
        r, snap = self._run("ma_cross.py", 6.0)
        self.assertEqual(r.status, "stopped", r.message)
        self.assertTrue(snap["ready"])
        self.assertGreater(len(snap["candles"]), 20)
        self.assertTrue(snap["plots"])
        self.assertGreater(r.account.balance + 0, 0)
        self.assertGreater(len(r.account.trades), 0, [l[3] for l in r.logs][-10:])
        self.assertEqual(len(r.account.positions), 0)   # đóng hết khi dừng

    def test_rsi_bot_runs(self):
        r, snap = self._run("rsi_reversion.py", 4.0)
        self.assertEqual(r.status, "stopped", r.message)

    def test_bot_exception_stops_with_error(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "boom.py")
            open(p, "w").write("from pyea import BaseBot\nclass B(BaseBot):\n    def on_tick(self, t):\n        1/0\n")
            s = default_settings(); s.update(tick_interval=0.2, history_bars=60)
            r = BotRunner(p, s, {}); r.start(); r._thread.join(8)
            self.assertEqual(r.status, "error")
            self.assertIn("ZeroDivisionError", "\n".join(l[3] for l in r.logs))

    def test_max_loss_halts(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "yolo.py")
            open(p, "w").write(
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_tick(self, t):\n"
                "        if not self.api.positions(): self.api.buy(0.0332, comment='x')\n")
            s = default_settings(); s.update(tick_interval=0.1, sim_speed=3000.0, history_bars=60,
                                             max_loss_pct=0.05, commission_pct=0.5)
            r = BotRunner(p, s, {}); r.start(); r._thread.join(15)
            self.assertEqual(r.status, "stopped")
            self.assertIn("lỗ tối đa", r.message)

    def test_ai_signal_reaches_bot(self):
        class Hub:
            def get_signal(self):
                return {"id": 1, "action": "buy", "confidence": 0.9, "sl_pct": 1.0, "tp_pct": 2.0, "reason": "t", "age": 0}
        s = default_settings(); s.update(tick_interval=0.1, sim_speed=50.0, history_bars=60, max_loss_pct=0.0)
        r = BotRunner(os.path.join(EXAMPLES_DIR, "ai_follow.py"), s, {}, ai_hub=Hub())
        r.start(); time.sleep(1.5); n = len(r.account.positions) + len(r.account.trades); r.stop(); r._thread.join(5)
        self.assertGreaterEqual(n, 1)

    def test_sl_tp_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "v.py")
            open(p, "w").write("from pyea import BaseBot\nclass B(BaseBot):\n    pass\n")
            s = default_settings(); s.update(tick_interval=0.1, history_bars=60)
            r = BotRunner(p, s, {}); r.start(); time.sleep(0.8)
            t = r.last_tick
            self.assertIsNone(r._open("buy", 0.01, t.ask + 10, 0, ""))      # SL trên giá khi mua
            self.assertIsNone(r._open("buy", 1e9, 0, 0, ""))               # quá vốn
            self.assertIsNotNone(r._open("buy", 0.01, 0, 0, ""))
            r.stop(); r._thread.join(5)


class TestAI(unittest.TestCase):
    def test_parse_decision(self):
        d = ai.parse_decision('Ok.\n```json\n{"action":"BUY","confidence":1.7,"sl_pct":-3,"tp_pct":2,"reason":"x"}\n```')
        self.assertEqual((d["action"], d["confidence"], d["sl_pct"], d["tp_pct"]), ("buy", 1.0, 0.0, 2.0))
        self.assertIsNone(ai.parse_decision("không có json"))
        self.assertIsNone(ai.parse_decision('{"action":"yolo"}'))

    def test_build_messages_merges(self):
        tr = [{"who": "user", "text": "hi", "kind": "chat"}, {"who": "A", "text": "x", "kind": "chat"},
              {"who": "B", "text": "y", "kind": "chat"}, {"who": "hệ thống", "text": "lỗi", "kind": "notice"},
              {"who": "C", "text": "z", "kind": "chat"}]
        m = ai.build_messages("sys", tr, "A", True)
        self.assertEqual([x["role"] for x in m], ["system", "user", "assistant", "user"])
        self.assertIn("[B]: y", m[-1]["content"])
        m2 = ai.build_messages("sys", [{"who": "A", "text": "x", "kind": "chat"}], "A", True)
        self.assertEqual(m2[-1]["role"], "user")

    def test_hub_flow_with_fake_model(self):
        calls = []

        def fake(agent, messages, max_tokens=800, timeout=90):
            calls.append((agent["name"], messages[-1]["content"][:30]))
            if "QUYẾT ĐỊNH CUỐI" in messages[-1]["content"]:
                return '{"action":"sell","confidence":0.8,"sl_pct":1,"tp_pct":2,"reason":"r"}'
            return "ý kiến của " + agent["name"]
        orig = ai.chat_completion
        ai.chat_completion = fake
        try:
            with tempfile.TemporaryDirectory() as d:
                store = Store(d)
                store.seed_examples()
                snap = {"ready": False}
                hub = ai.AIHub(store, lambda: snap, lambda: ("b", "src", {}), lambda: default_settings())
                hub.set_agents([dict(ai.default_agent(1), name="A"), dict(ai.default_agent(2), name="B", decider=True)])
                msgs = []
                hub.on_message = msgs.append
                self.assertTrue(hub.ask_group("xin chào", rounds=1))
                for _ in range(50):
                    if not hub.busy: break
                    time.sleep(0.1)
                self.assertEqual([m["who"] for m in msgs], ["user", "A", "B"])
                # auto mode cần snapshot ready
                snap.update(self._fake_snap())
                hub._auto_session()
                self.assertEqual(hub.get_signal()["action"], "sell")
                self.assertTrue(Store(d).chat.tail(10))
        finally:
            ai.chat_completion = orig

    @staticmethod
    def _fake_snap():
        cs = [Candle(i * 60, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(60)]
        return {"ready": True, "candles": cs, "symbol": "X", "timeframe": "1m", "mode": "paper", "bid": 160, "ask": 160.1,
                "balance": 1000, "equity": 1000, "pnl_pct": 0, "max_dd": 0, "n_trades": 0, "win_rate": 0,
                "positions": [], "trades": [], "plots": {}}

    def test_market_context(self):
        txt = ai.market_context(self._fake_snap())
        self.assertIn("RSI14", txt)
        self.assertIn("SMA20", txt)


class TestCodeEdit(unittest.TestCase):
    CODE = "from pyea import BaseBot\nclass X(BaseBot):\n    pass\n"

    def test_extract_check_diff(self):
        txt = "Đây:\n```python\n%s```\nxong" % self.CODE
        code = codeedit.extract_bot_code(txt)
        self.assertEqual(code, self.CODE)
        self.assertTrue(codeedit.check_bot_code(code)[0])
        self.assertFalse(codeedit.check_bot_code("def (:")[0])
        self.assertFalse(codeedit.check_bot_code("x=1\n")[0])
        self.assertTrue(codeedit.make_diff("a\n", "b\n"))

    def test_save(self):
        with tempfile.TemporaryDirectory() as d:
            p1 = codeedit.save_new_version(d, os.path.join(d, "ma.py"), self.CODE)
            p2 = codeedit.save_new_version(d, p1, self.CODE)
            self.assertTrue(p1.endswith("ma_ai.py") and p2.endswith("ma_ai2.py"))
            codeedit.overwrite_with_backup(p1, "# new\n")
            self.assertTrue(os.path.exists(p1 + ".bak"))


if __name__ == "__main__":
    unittest.main()
