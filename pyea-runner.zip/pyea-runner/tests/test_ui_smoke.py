"""Chạy LOGIC giao diện bằng Kivy giả (không kiểm tra hiển thị thật): tạo UI, chạy bot, nhận sự kiện,
chạm vào chấm -> popup lý do, chế độ dịch vụ nền qua IPC, AI tab, chẩn đoán."""
import os, sys, tempfile, threading, time, unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub
kivy_stub.install()

from pyea import android_native as native                      # noqa: E402
from pyea.ipc import ServiceHandle, ServiceHost                 # noqa: E402
import pyea.ui as ui                                            # noqa: E402

BOT = (
    "from pyea import BaseBot, Input\n"
    "class HoldBot(BaseBot):\n"
    "    name = 'Hold test'\n"
    "    inputs = {'lot': Input(0.01, 'Khối lượng', min=0.0)}\n"
    "    def on_init(self):\n        self.k = 0\n"
    "    def on_tick(self, t):\n"
    "        self.k += 1\n"
    "        self.api.plot('MID', t.mid)\n"
    "        self.api.status('tick %d' % self.k)\n"
    "        if self.k == 3:\n"
    "            self.api.buy(self.p.lot, reason='vào thử A', details={'k': self.k})\n"
    "        if self.k == 8:\n"
    "            self.api.close_all(reason='ra thử B')\n"
)


def texts(w):
    out = [str(getattr(w, "text", ""))]
    for c in getattr(w, "children", []):
        out += texts(c)
    return out


def wait(cond, timeout=12.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.05)
    return False


def make_app():
    tmp = tempfile.mkdtemp()
    app = ui.PyEAApp()
    app.user_data_dir = tmp
    app.build()
    path = app.store.install_bot_text("hold_test.py", BOT)
    app.refresh_bots(select=path)
    app.select_bot(path)
    g = app.params_tab.gform.ctrl
    g["tick_interval"].text = "0.2"
    g["sim_speed"].text = "200"
    g["history_bars"].text = "200"
    g["max_loss_pct"].text = "0"
    return app, path


class TestUISmoke(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def _drive(self, app, cond, timeout=15.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.1)
        return False

    def test_build_forms_and_save(self):
        app, path = make_app()
        self.assertIn("lot", app.params_tab.bform.ctrl)
        app.params_tab.bform.ctrl["lot"].text = "0.02"
        self.assertTrue(app.save_forms())
        self.assertEqual(app.store.load_params(path)["lot"], 0.02)
        self.assertEqual(app.settings["tick_interval"], 0.2)
        app.params_tab.bform.ctrl["lot"].text = "abc"
        self.assertFalse(app.save_forms())                      # popup lỗi
        self.assertTrue(kivy_stub.OPEN_POPUPS)

    def test_local_run_events_markers_and_tap(self):
        app, path = make_app()
        app.settings["background_service"] = False
        app.params_tab.bform.ctrl["lot"].text = "0.01"
        app.start_bot()
        self.assertTrue(self._drive(app, lambda: len(app.dash_tab.chart.events) >= 2), "không có điểm vào/ra trên biểu đồ")
        chart = app.dash_tab.chart
        chart.redraw()
        kinds = {h[2].kind for h in chart._hits}
        self.assertTrue({"open", "close"} <= kinds, kinds)
        # chấm vào lệnh phải có mặt trong danh sách hit; chạm gần đó -> popup lý do
        x, y, ev = next(h for h in chart._hits if h[2].kind == "open")
        n0 = len(kivy_stub.OPEN_POPUPS)
        chart._tap(x + 3, y + 2)
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        pop = kivy_stub.OPEN_POPUPS[-1]
        self.assertIn("VÀO LỆNH", pop.title)
        blob = "\n".join(texts(pop.content))
        self.assertIn("vào thử A", blob); self.assertIn("k: 3", blob); self.assertIn("Thuật toán của bot", blob)
        # chạm xa mọi chấm -> không popup
        chart._tap(-500, -500)
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        # chip ẩn/hiện chỉ báo
        self.assertEqual(app.dash_tab._chip_sig, ("MID",))
        self.assertGreaterEqual(len(app.dash_tab.chip_box.children), 4)
        app.dash_tab._plot_toggle("MID")(False)
        self.assertIn("MID", chart.hidden)
        self.assertIn("MID", app.store.load_prefs()["hidden_plots"])
        app.dash_tab._flag("show_markers")(False)
        chart.redraw(); self.assertEqual(chart._hits, [])
        # zoom / pan
        b = chart.bars; app.dash_tab.zoom(+1); self.assertGreater(chart.bars, b)
        app.dash_tab.pan(+1); self.assertGreater(chart.offset, 0); app.dash_tab.pan(0); self.assertEqual(chart.offset, 0)
        self.assertIn("Bot đang nghĩ", app.dash_tab.thinking.text)
        app.stop_bot()
        self.assertTrue(self._drive(app, lambda: not app.runner.is_alive()))
        self.assertEqual(app.runner.status, "stopped")

    def test_service_mode_end_to_end(self):
        app, path = make_app()
        app.settings["background_service"] = True
        host_box = {}
        orig_native = (native.IS_ANDROID, native.start_service)

        def fake_start_service(arg, title="", text=""):
            host = ServiceHost(app.user_data_dir, sleep=0.05, exit_grace=0.5, idle_exit=5)
            host_box["host"] = host
            threading.Thread(target=host.run, daemon=True).start()
            return True, ""
        native.IS_ANDROID, native.start_service = True, fake_start_service
        try:
            app.start_bot()
            self.assertIsInstance(app.runner, ServiceHandle)
            self.assertTrue(self._drive(app, lambda: len(app.dash_tab.chart.events) >= 2), "dịch vụ không đẩy sự kiện lên UI")
            self.assertTrue(app.last_snap["ready"])
            ev = app.dash_tab.chart.events[0]
            n0 = len(kivy_stub.OPEN_POPUPS)
            app.show_event(ev)
            self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
            blob = "\n".join(texts(kivy_stub.OPEN_POPUPS[-1].content))
            self.assertIn("vào thử A", blob) if ev.kind == "open" else self.assertIn("ra thử B", blob)
            self.assertIn("Nguồn quyết định", blob)
            self.assertTrue(app.log_tab.lines)
            # đóng UI mà không dừng bot: gắn lại
            app.on_stop()
            self.assertTrue(app.runner.is_alive())
            h2 = ServiceHandle.attach(app.client, app.store.events_path)
            self.assertIsNotNone(h2)
            app.stop_bot()
            self.assertTrue(self._drive(app, lambda: not app.runner.is_alive(), 15))
            fin = app.runner.finished_state()
            self.assertEqual(fin[0], "stopped")
            host_box["host"]._exit = True
        finally:
            native.IS_ANDROID, native.start_service = orig_native

    def test_service_start_failure_falls_back_to_local(self):
        app, path = make_app()
        app.settings["background_service"] = True
        orig = (native.IS_ANDROID, native.start_service)
        native.IS_ANDROID, native.start_service = True, (lambda *a, **k: (False, "boom"))
        try:
            app.start_bot()
            self.assertNotIsInstance(app.runner, ServiceHandle)       # đã chạy trực tiếp
            self.assertTrue(any("chạy trực tiếp" in l for l in app.log_tab.lines))
            app.stop_bot(); wait(lambda: not app.runner.is_alive())
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_ai_tab_and_diagnostics(self):
        app, path = make_app()
        app.hub.add_message("user", "xin chào")
        app.hub.add_message("AI 1", "```python\nfrom pyea import BaseBot\nclass X(BaseBot):\n    pass\n```")
        n = len(app.ai_tab.chat_box.children)
        app.ai_tab.update()
        self.assertEqual(len(app.ai_tab.chat_box.children), n + 2)
        self.assertEqual(app.ai_tab.sig_label.text.split(":")[0], "Tín hiệu")
        app.toggle_ai_auto(); self.assertTrue(app.hub.auto_on); app.toggle_ai_auto(); self.assertFalse(app.hub.auto_on)
        app.run_diagnostics()
        self.assertTrue(wait(lambda: any(p.title == "Kiểm tra hệ thống" for p in kivy_stub.OPEN_POPUPS), 20))
        self.assertTrue(os.path.exists(os.path.join(app.user_data_dir, "diagnostics.txt")))

    def test_crash_log_prompt(self):
        app, path = make_app()
        app.note_ui_error("Traceback...\nValueError: x")
        self.assertTrue(os.path.exists(app.store.crash_path))
        app._after_start(0)
        self.assertTrue(any("bị lỗi" in p.title for p in kivy_stub.OPEN_POPUPS))
        app.report_fatal("Traceback\nRuntimeError: y")
        self.assertTrue(os.path.exists(app.store.crash_path))


if __name__ == "__main__":
    unittest.main()
