"""Chạy LOGIC giao diện bằng Kivy giả (không kiểm tra hiển thị thật): dựng 8 tab, kết nối phiên, Market Watch,
đặt lệnh thủ công, gắn bot, biểu đồ + chạm chấm -> popup lý do, backtest, chế độ dịch vụ nền, AI, chẩn đoán."""
import os, sys, tempfile, threading, time, unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kivy_stub
kivy_stub.install()

from kivy.uix.textinput import TextInput                         # noqa: E402  (stub)
from pyea import android_native as native                        # noqa: E402
from pyea.ipc import ServiceHandle, ServiceHost                  # noqa: E402
import pyea.ui as ui                                             # noqa: E402


def walk(w):
    yield w
    for c in getattr(w, "children", []):
        yield from walk(c)


def texts(w):
    return "\n".join(str(getattr(x, "text", "")) for x in walk(w))


def find(root, pred):
    return [x for x in walk(root) if pred(x)]


def inputs_of(root):
    """TextInput theo THỨ TỰ THÊM VÀO (children của Kivy được lưu đảo ngược)."""
    return list(reversed(find(root, lambda x: isinstance(x, TextInput))))


def press(root, label):
    """Bấm nút có text == label trong cây widget (gọi callback on_release)."""
    for x in walk(root):
        if getattr(x, "text", None) == label and x._binds.get("on_release"):
            for cb in x._binds["on_release"]:
                cb(x)
            return True
    raise AssertionError("không thấy nút %r" % label)


def wait(cond, timeout=15.0):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:
            pass
        time.sleep(0.05)
    return False


def make_app(**settings):
    tmp = tempfile.mkdtemp()
    app = ui.PyEAApp()
    app.user_data_dir = tmp
    app.build()
    g = app.settings_tab.gform.ctrl
    g["tick_interval"].text = "0.2"
    g["sim_speed"].text = "200"
    g["history_bars"].text = "200"
    g["initial_balance"].text = "100000"
    g["max_loss_pct"].text = "0"
    g["background_service"].active = False
    for k, v in settings.items():
        g[k].text = v
    return app


class TestUISmoke(unittest.TestCase):
    def tearDown(self):
        kivy_stub.OPEN_POPUPS.clear()

    def drive(self, app, cond, timeout=15.0):
        end = time.time() + timeout
        while time.time() < end:
            app.refresh(0)
            if cond():
                return True
            time.sleep(0.1)
        return False

    def test_build_tabs_and_seed(self):
        app = make_app()
        self.assertEqual(list(app.tabs), ["market", "trade", "bots", "chart", "bt", "ai", "settings", "log"])
        self.assertEqual(len(app.attach_cfgs), 1)
        self.assertEqual(app.attach_cfgs[0]["symbol"], "BTCUSD")
        self.assertTrue(app.save_forms())
        self.assertEqual(app.settings["tick_interval"], 0.2)
        app.settings_tab.gform.ctrl["tick_interval"].text = "abc"
        self.assertFalse(app.save_forms())
        self.assertTrue(kivy_stub.OPEN_POPUPS)

    def test_connect_market_watch_manual_order_and_chart_tap(self):
        app = make_app()
        app.start_session()
        self.assertTrue(app.is_connected())
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and len(app.last_snap["watch"]) >= 4))
        self.assertGreaterEqual(len(app.market_tab.rows), 6)
        self.assertIn("EURUSD", app.market_tab.rows)
        self.assertIn("/", app.market_tab.rows["EURUSD"].text)                      # có bid / ask
        # --- đặt lệnh thủ công qua hộp thoại
        app.open_order_dialog("XAUUSD")
        dlg = kivy_stub.OPEN_POPUPS[-1]
        inputs = inputs_of(dlg.content)
        inputs[0].text = "0.5"
        press(dlg.content, "MUA")
        press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")                 # mặc định có bước xác nhận (confirm_trades)
        self.assertTrue(any("Đã MUA" in texts(p.content) for p in kivy_stub.OPEN_POPUPS), [texts(p.content)[:80] for p in kivy_stub.OPEN_POPUPS])
        self.assertTrue(self.drive(app, lambda: any(p.symbol == "XAUUSD" for p in app.last_snap["positions"])))
        pos = next(p for p in app.last_snap["positions"] if p.symbol == "XAUUSD")
        self.assertEqual(pos.owner, "manual")
        self.assertEqual(len(app.trade_tab._rows), len(app.last_snap["positions"]))
        # --- sửa SL/TP
        app.open_modify_dialog(pos.id)
        dlg = kivy_stub.OPEN_POPUPS[-1]
        ins = inputs_of(dlg.content)
        t = app.last_snap["watch"]["XAUUSD"]
        ins[0].text, ins[1].text = "%.2f" % (t["bid"] * 0.5), "%.2f" % (t["bid"] * 1.5)
        press(dlg.content, "Lưu")
        self.assertTrue(self.drive(app, lambda: next(p for p in app.last_snap["positions"] if p.id == pos.id).sl > 0))
        # --- biểu đồ XAUUSD: chấm lệnh thủ công, chạm -> popup lý do
        app.set_chart("XAUUSD", "5m")
        self.assertTrue(self.drive(app, lambda: app.chart_tab.panel.chart.candles and app.chart_tab.panel.chart.events))
        ch = app.chart_tab.panel.chart
        ch.redraw()
        x, y, ev = next(h for h in ch._hits if h[2].kind == "open")
        n0 = len(kivy_stub.OPEN_POPUPS)
        ch._tap(x + 2, y + 2)
        self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
        blob = texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("thủ công", blob); self.assertIn("Nguồn quyết định", blob)
        # --- đóng lệnh: xác nhận
        app.close_one(pos.id)
        press(kivy_stub.OPEN_POPUPS[-1].content, "Đóng")
        self.assertTrue(self.drive(app, lambda: not any(p.id == pos.id for p in app.last_snap["positions"])))
        self.assertTrue(any(t.owner == "manual" for t in app.last_snap["trades"]))
        # --- ngắt phiên
        app.stop_session()
        self.assertTrue(self.drive(app, lambda: not app.is_connected(), 20))

    def test_attach_bot_to_other_asset_and_toggle_remove(self):
        app = make_app()
        app.start_session()
        self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready")))
        app.chart_sym = "EURUSD"
        app.open_attach_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        press(dlg.content, "Gắn bot")
        self.assertEqual(len(app.attach_cfgs), 2)
        new = app.attach_cfgs[-1]
        self.assertEqual(new["symbol"], "EURUSD")
        self.assertTrue(self.drive(app, lambda: len(app.last_snap["instances"]) == 2 and
                                   all(i["status"] == "running" for i in app.last_snap["instances"]), 20))
        self.assertIn(new["iid"], app.attach_tab._att)
        l1, l2, l3, tog, _l4 = app.attach_tab._att[new["iid"]]
        self.assertIn("EURUSD", l1.text); self.assertEqual(tog.text, "Dừng")
        app.toggle_instance(new["iid"])
        self.assertTrue(self.drive(app, lambda: next(i for i in app.last_snap["instances"] if i["iid"] == new["iid"])["status"] in ("stopped", "stopping")))
        app.remove_attachment(new["iid"])
        press(kivy_stub.OPEN_POPUPS[-1].content, "Gỡ")
        self.assertEqual(len(app.attach_cfgs), 1)
        self.assertTrue(self.drive(app, lambda: len(app.last_snap["instances"]) == 1))
        app.stop_session()

    def test_backtest_tab_end_to_end(self):
        app = make_app()
        bt = app.bt_tab
        c = bt.form.ctrl
        c["symbol"].text, c["timeframe"].text, c["bars"].text, c["warmup"].text = "ETHUSD", "5m", "1500", "100"
        c["initial_balance"].text = "50000"
        bt.bot.text = "ma_cross.py"
        bt.run()
        self.assertTrue(wait(lambda: bt.res is not None, 30), bt.prog.text)
        self.assertTrue(bt.res.ok, bt.res.error)
        self.assertGreater(len(bt.res.trades), 5)
        self.assertNotEqual(bt.s["Tổng số lệnh"].v.text, "-")
        ch = bt.panel.chart
        ch.bars = 400; ch.redraw()
        self.assertTrue(ch._hits)
        x, y, ev = next(h for h in ch._hits if h[2].kind == "open")
        ch._tap(x, y)
        blob = texts(kivy_stub.OPEN_POPUPS[-1].content)
        self.assertIn("cắt", blob); self.assertIn("SMA10", blob); self.assertIn("Điều kiện / thông số kích hoạt", blob)
        bt.full_report()
        self.assertIn("Profit factor", texts(kivy_stub.OPEN_POPUPS[-1].content))
        self.assertGreater(len(bt.tr.children), 7)

    def test_service_mode_end_to_end(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        host_box = {}
        orig = (native.IS_ANDROID, native.start_service)

        def fake_start_service(arg, title="", text=""):
            host = ServiceHost(app.data_dir, sleep=0.05, exit_grace=0.5, idle_exit=5)
            host_box["host"] = host
            threading.Thread(target=host.run, daemon=True).start()
            return True, ""
        native.IS_ANDROID, native.start_service = True, fake_start_service
        try:
            app.start_session()
            self.assertIsInstance(app.ctl, ServiceHandle)
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready") and "BTCUSD" in app.last_snap["watch"], 20))
            # lệnh thủ công qua IPC
            app.open_order_dialog("EURUSD")
            dlg = kivy_stub.OPEN_POPUPS[-1]
            inputs_of(dlg.content)[0].text = "1000"
            press(dlg.content, "MUA")
            press(kivy_stub.OPEN_POPUPS[-1].content, "Đặt lệnh")
            self.assertTrue(any("dịch vụ nền" in texts(p.content) for p in kivy_stub.OPEN_POPUPS))
            self.assertTrue(self.drive(app, lambda: any(p.symbol == "EURUSD" for p in app.last_snap["positions"]), 20))
            # biểu đồ + chấm từ dịch vụ
            app.set_chart("EURUSD", "5m")
            self.assertTrue(self.drive(app, lambda: app.chart_tab.panel.chart.candles and any(e.symbol == "EURUSD" for e in app.chart_tab.panel.chart.events), 20))
            ch = app.chart_tab.panel.chart; ch.redraw()
            x, y, ev = next(h for h in ch._hits if h[2].symbol == "EURUSD")
            n0 = len(kivy_stub.OPEN_POPUPS); ch._tap(x, y)
            self.assertEqual(len(kivy_stub.OPEN_POPUPS), n0 + 1)
            # đóng UI không dừng phiên -> gắn lại
            app.on_stop()
            self.assertTrue(app.is_connected())
            self.assertIsNotNone(ServiceHandle.attach_running(app.client, app.store.events_path))
            app.stop_session()
            self.assertTrue(self.drive(app, lambda: not app.is_connected(), 25))
            host_box["host"]._exit = True
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_service_start_failure_falls_back_to_local(self):
        app = make_app()
        app.settings_tab.gform.ctrl["background_service"].active = True
        orig = (native.IS_ANDROID, native.start_service)
        native.IS_ANDROID, native.start_service = True, (lambda *a, **k: (False, "boom"))
        try:
            app.start_session()
            self.assertNotIsInstance(app.ctl, ServiceHandle)
            self.assertTrue(any("chạy trực tiếp" in l for l in app.log_tab.lines))
            self.assertTrue(self.drive(app, lambda: (app.last_snap or {}).get("ready")))
            app.stop_session()
        finally:
            native.IS_ANDROID, native.start_service = orig

    def test_watchlist_add_remove_and_ai_diag_crash(self):
        app = make_app()
        app.add_symbol_dialog()
        dlg = kivy_stub.OPEN_POPUPS[-1]
        inputs_of(dlg.content)[0].text = "usoil, gbpusd"
        press(dlg.content, "Thêm")
        self.assertIn("USOIL", app.settings["watchlist"])
        app.refresh(0)
        self.assertIn("USOIL", app.market_tab.rows)
        app.symbol_menu("USOIL")
        press(kivy_stub.OPEN_POPUPS[-1].content, "Xoá khỏi danh sách theo dõi")
        self.assertNotIn("USOIL", app.settings["watchlist"])
        # AI tab
        app.hub.add_message("user", "xin chào")
        n = len(app.ai_tab.chat_box.children); app.ai_tab.update()
        self.assertEqual(len(app.ai_tab.chat_box.children), n + 1)
        app.toggle_ai_auto(); self.assertTrue(app.hub.auto_on); app.toggle_ai_auto(); self.assertFalse(app.hub.auto_on)
        # chẩn đoán
        app.run_diagnostics()
        self.assertTrue(wait(lambda: any(p.title == "Kiểm tra hệ thống" for p in kivy_stub.OPEN_POPUPS), 20))
        # crash log
        app.note_ui_error("Traceback...\nValueError: x")
        app._after_start(0)
        self.assertTrue(any("bị lỗi" in p.title for p in kivy_stub.OPEN_POPUPS))


if __name__ == "__main__":
    unittest.main()
