"""Test phần chạy nền / sự kiện / broker (sàn giả cục bộ) / biểu quyết AI.  Không cần Kivy."""
import hashlib, hmac, http.server, json, os, sys, tempfile, threading, time, unittest, urllib.parse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from pyea import ai, explain
from pyea.engine import BotRunner
from pyea.ipc import ServiceClient, ServiceHandle, ServiceHost, snapshot_from_json, snapshot_to_json, notification_text
from pyea.settings import default_settings
from pyea.storage import Store, ChatLog
from pyea import diagnostics

TMP = tempfile.mkdtemp()
STORE = Store(TMP)
STORE.seed_examples()
BOTS = STORE.bots_dir


def fast_settings(**over):
    s = default_settings()
    s.update(tick_interval=0.1, sim_speed=300.0, history_bars=200, max_loss_pct=0.0, close_on_stop=True)
    s.update(over)
    return s


def write_bot(d, name, body):
    p = os.path.join(d, name)
    with open(p, "w", encoding="utf-8") as f:
        f.write(body)
    return p


def wait(cond, timeout=10.0, step=0.05):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(step)
    return False


class TestEvents(unittest.TestCase):
    def test_reason_details_context_and_sl(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "ev.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    inputs = {}\n"
                "    def on_init(self):\n        self.done = False\n"
                "    def on_bar(self, c):\n"
                "        self.api.plot('X', c.close)\n"
                "        if not self.done:\n"
                "            self.done = True\n"
                "            t = self.api.tick\n"
                "            self.api.buy(0.01, sl=t.ask*0.9999, reason='điều kiện A thoả', details={'a': 1.5, 'b': 'x'})\n"
                "            self.api.signal('bị lọc bởi B', details={'rsi': 70})\n"
                "            self.api.status('đang giữ lệnh')\n"))
            s = fast_settings(sim_speed=600.0)
            r = BotRunner(p, s, {}, events_file=os.path.join(d, "ev.jsonl"), state_file=os.path.join(d, "st.json"))
            r.start()
            self.assertTrue(wait(lambda: any(e.kind == "close" for e in r.events), 15), "SL chưa kích hoạt")
            r.stop(); r._thread.join(5)
            ev = list(r.events)
            op = next(e for e in ev if e.kind == "open")
            self.assertEqual(op.reason, "điều kiện A thoả")
            self.assertEqual(op.details["a"], 1.5)
            self.assertEqual(op.context["callback"], "on_bar")
            self.assertIn("X", op.context["indicators"])
            self.assertTrue(any(e.kind == "note" and "bị lọc" in e.reason for e in ev))
            cl = next(e for e in ev if e.kind == "close")
            self.assertIn(cl.source, ("sl", "stop"))
            self.assertEqual(cl.pos_id, op.pos_id)
            self.assertEqual(r.bot_status, "đang giữ lệnh")
            # đã ghi ra file jsonl
            with open(os.path.join(d, "ev.jsonl"), encoding="utf-8") as f:
                self.assertGreaterEqual(len(f.readlines()), 3)
            # explain
            text = explain.describe_text(op, ev)
            self.assertIn("điều kiện A thoả", text)
            self.assertIn("a: 1.5", text)
            self.assertIn("Lý do vào", explain.describe_text(cl, ev))

    def test_ai_origin_event(self):
        sig = {"id": 7, "by": "Biểu quyết", "action": "buy", "confidence": 0.8, "sl_pct": 1, "tp_pct": 2,
               "reason": "2/3 đồng ý", "mode": "đa số", "age": 1.0,
               "votes": [{"agent": "A", "model": "m1", "action": "buy", "confidence": 0.9, "reason": "RSI thấp"}],
               "discussion": [{"agent": "A", "text": "xu hướng tăng"}]}

        class Hub:
            def get_signal(self): return dict(sig)
        s = fast_settings(sim_speed=50.0)
        r = BotRunner(os.path.join(BOTS, "ai_follow.py"), s, {}, ai_hub=Hub())
        r.start()
        self.assertTrue(wait(lambda: any(e.kind == "open" for e in r.events), 8))
        r.stop(); r._thread.join(5)
        op = next(e for e in r.events if e.kind == "open")
        self.assertEqual(op.source, "ai")
        self.assertEqual(op.ai["votes"][0]["model"], "m1")
        text = explain.describe_text(op, list(r.events))
        self.assertIn("RSI thấp", text)
        self.assertIn("xu hướng tăng", text)


class TestResume(unittest.TestCase):
    def test_state_restored(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "hold.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_init(self): self.n = 0\n"
                "    def on_tick(self, t):\n"
                "        if not self.api.positions(): self.api.buy(0.01, reason='mở để test')\n"))
            st, evf = os.path.join(d, "st.json"), os.path.join(d, "ev.jsonl")
            s = fast_settings(close_on_stop=False)
            r1 = BotRunner(p, s, {}, state_file=st, events_file=evf); r1.start()
            self.assertTrue(wait(lambda: r1.account is not None and r1.account.positions, 8))
            bal, pid = r1.account.balance, list(r1.account.positions)[0]
            r1.stop(); r1._thread.join(5)
            r2 = BotRunner(p, s, {}, state_file=st, events_file=evf, resume=True); r2.start()
            self.assertTrue(wait(lambda: r2.status == "running", 8))
            self.assertIn(pid, r2.account.positions)
            self.assertAlmostEqual(r2.account.balance, bal, places=6)
            self.assertTrue(any(e.kind == "open" and e.pos_id == pid for e in r2.events))
            r2.stop(); r2._thread.join(5)


class TestIPCHost(unittest.TestCase):
    def _config(self, bot="ma_cross.py", **over):
        return {"bot_path": os.path.join(BOTS, bot), "settings": fast_settings(**over),
                "params": {"fast": 3, "slow": 8}, "log_file": None, "trades_csv": None}

    def test_roundtrip_and_commands(self):
        with tempfile.TemporaryDirectory() as d:
            alarms, notes = [], []
            host = ServiceHost(d, alarm=lambda t, x: alarms.append(t), set_notification=lambda t, x: notes.append((t, x)),
                               sleep=0.05, exit_grace=0.5, idle_exit=5)
            th = threading.Thread(target=host.run, daemon=True); th.start()
            client = ServiceClient(d)
            h = ServiceHandle(client, host.store.events_path)
            h.start(self._config())
            self.assertTrue(h.is_alive())                       # pending
            self.assertTrue(wait(lambda: (h.snapshot() or {}).get("ready"), 15), "không nhận được snapshot")
            snap = h.snapshot()
            self.assertGreater(len(snap["candles"]), 20)
            self.assertEqual(snap["status"], "running")
            self.assertTrue(client.host_alive())
            self.assertTrue(wait(lambda: notes, 5), "dịch vụ phải đăng thông báo trạng thái")
            self.assertTrue(all("PyEA" in t for t, _ in notes))
            self.assertTrue(wait(lambda: len(h.events()) > 0, 20), "không có sự kiện nào")
            h.request_close_all()
            h.stop()
            self.assertTrue(wait(lambda: not h.is_alive(), 15))
            fin = h.finished_state()
            self.assertEqual(fin[0], "stopped")
            self.assertTrue(wait(lambda: not client.host_alive(), 5), "host phải tự thoát")
            self.assertFalse(client.read_desired()["running"])
            th.join(5)

    def test_snapshot_json_roundtrip(self):
        s = fast_settings()
        r = BotRunner(os.path.join(BOTS, "ma_cross.py"), s, {"fast": 3, "slow": 8}); r.start()
        self.assertTrue(wait(lambda: r.snapshot().get("ready"), 8)); time.sleep(1.0)
        snap = r.snapshot(); r.stop(); r._thread.join(5)
        back = snapshot_from_json(json.loads(json.dumps(snapshot_to_json(snap))))
        self.assertEqual(len(back["candles"]), len(snap["candles"]))
        self.assertEqual(back["candles"][-1].close, snap["candles"][-1].close)
        self.assertEqual(set(back["plots"]), set(snap["plots"]))
        t, x = notification_text(back)
        self.assertIn("MA Cross", t); self.assertIn("Equity", x)

    def test_crash_recovery_resumes_with_alarm(self):
        with tempfile.TemporaryDirectory() as d:
            alarms = []
            p = write_bot(d, "hold.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_tick(self, t):\n"
                "        if not self.api.positions(): self.api.buy(0.01, reason='giữ')\n"))
            cfg = {"bot_path": p, "settings": fast_settings(close_on_stop=False), "params": {}, "token": "tok1"}
            h1 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
            h1.start_session(cfg)
            self.assertTrue(wait(lambda: h1.runner.account is not None and h1.runner.account.positions, 8))
            pid = list(h1.runner.account.positions)[0]
            # mô phỏng crash: dừng runner "ngầm" (không qua host) và bỏ host cũ; desired.running vẫn True
            h1.runner.stop(); h1.runner._thread.join(5)
            ServiceClient(d).write_desired({"running": True, "config": cfg})
            # host mới khởi động lại -> tự resume
            h2 = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, exit_grace=0.2)
            th = threading.Thread(target=h2.run, daemon=True); th.start()
            self.assertTrue(wait(lambda: h2.runner is not None and h2.runner.account is not None and h2.runner.status == "running", 8))
            self.assertIn(pid, h2.runner.account.positions)
            self.assertTrue(any("khôi phục" in a for a in alarms), alarms)
            h2.runner.stop(); th.join(10)

    def test_restart_storm_guard(self):
        with tempfile.TemporaryDirectory() as d:
            alarms = []
            cfg = {"bot_path": os.path.join(BOTS, "ma_cross.py"), "settings": fast_settings(), "params": {}, "token": "t"}
            ServiceClient(d).write_desired({"running": True, "config": cfg, "restarts": [time.time()] * 3})
            h = ServiceHost(d, alarm=lambda t, x: alarms.append(t), sleep=0.05, idle_exit=0.3)
            h.run()
            self.assertIsNone(h.runner)
            self.assertTrue(any("crash liên tục" in a for a in alarms))


# ----------------------------------------------------------------------------- sàn Binance giả
class FakeBinance(http.server.BaseHTTPRequestHandler):
    secret = b"sekret"
    orders, leverage_calls = [], []
    price = 100.0
    dual = False

    def log_message(self, *a): pass

    def _send(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def _check_sig(self, qs, raw_query):
        if "signature" not in qs: return False
        base = raw_query.rsplit("&signature=", 1)[0]
        good = hmac.new(self.secret, base.encode(), hashlib.sha256).hexdigest()
        return good == qs["signature"][0] and self.headers.get("X-MBX-APIKEY") == "key123"

    def _handle(self, method):
        u = urllib.parse.urlparse(self.path); qs = urllib.parse.parse_qs(u.query); p = u.path
        cls = FakeBinance
        if p.endswith("/time"): return self._send({"serverTime": int(time.time() * 1000)})
        if p.endswith("/ticker/bookTicker"):
            return self._send({"symbol": "BTCUSDT", "bidPrice": "%.2f" % (cls.price - 0.05), "askPrice": "%.2f" % (cls.price + 0.05)})
        if p.endswith("/klines"):
            n = int(qs["limit"][0]); now = int(time.time() // 60) * 60
            return self._send([[(now - (n - i) * 60) * 1000, "100", "101", "99", "100", "1", 0] for i in range(n)])
        if p.endswith("/exchangeInfo"):
            filt = [{"filterType": "LOT_SIZE", "stepSize": "0.001", "minQty": "0.001"},
                    {"filterType": "MARKET_LOT_SIZE", "stepSize": "0.001", "minQty": "0.001"}]
            return self._send({"symbols": [{"symbol": "BTCUSDT", "baseAsset": "BTC", "quoteAsset": "USDT", "filters": filt}]})
        # ---- có chữ ký ----
        if not self._check_sig(qs, u.query): return self._send({"code": -1022, "msg": "bad signature"}, 400)
        if p == "/api/v3/account": return self._send({"balances": [{"asset": "USDT", "free": "5000", "locked": "0"}]})
        if p == "/fapi/v2/balance": return self._send([{"asset": "USDT", "balance": "5000", "availableBalance": "4800"}])
        if p == "/fapi/v1/positionSide/dual": return self._send({"dualSidePosition": cls.dual})
        if p == "/fapi/v1/leverage":
            cls.leverage_calls.append(qs["leverage"][0]); return self._send({"leverage": int(qs["leverage"][0])})
        if p in ("/api/v3/order", "/fapi/v1/order") and method == "POST":
            o = {k: v[0] for k, v in qs.items()}; cls.orders.append((p, o))
            q = float(o["quantity"])
            if p.startswith("/fapi"):
                return self._send({"status": "FILLED", "executedQty": o["quantity"], "avgPrice": "%.2f" % cls.price,
                                   "cumQuote": "%.4f" % (q * cls.price)})
            fills = [{"price": "%.2f" % cls.price, "qty": o["quantity"], "commission": "%.6f" % (q * 0.001), "commissionAsset": "BTC"}]
            return self._send({"executedQty": o["quantity"], "cummulativeQuoteQty": "%.4f" % (q * cls.price), "fills": fills})
        return self._send({"code": -2015, "msg": "unknown " + p}, 404)

    def do_GET(self): self._handle("GET")
    def do_POST(self): self._handle("POST")


class TestBrokers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), FakeBinance)
        cls.url = "http://127.0.0.1:%d" % cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        FakeBinance.orders.clear(); FakeBinance.leverage_calls.clear(); FakeBinance.dual = False

    def test_spot_buy_net_of_fee(self):
        from pyea.broker import BinanceBroker
        b = BinanceBroker("key123", "sekret", self.url)
        self.assertEqual(b.prepare("BTCUSDT"), 5000.0)
        f = b.market_order("BTCUSDT", "buy", 0.0105)
        self.assertEqual(FakeBinance.orders[-1][1]["quantity"], "0.010")
        self.assertAlmostEqual(f.qty, 0.010 - 0.010 * 0.001, places=9)
        self.assertAlmostEqual(f.price, 100.0)

    def test_bad_signature_rejected(self):
        from pyea.broker import BinanceBroker, BrokerError
        with self.assertRaises(BrokerError):
            BinanceBroker("key123", "WRONG", self.url).prepare("BTCUSDT")

    def test_futures_short_and_reduce_only(self):
        from pyea.broker import BinanceFuturesBroker, BrokerError
        b = BinanceFuturesBroker("key123", "sekret", self.url)
        self.assertEqual(b.prepare("BTCUSDT", 3), 4800.0)
        self.assertEqual(FakeBinance.leverage_calls[-1], "3")
        f = b.market_order("BTCUSDT", "sell", 0.01)
        self.assertEqual(f.qty, 0.01)
        b.market_order("BTCUSDT", "buy", 0.01, reduce_only=True)
        self.assertEqual(FakeBinance.orders[-1][1]["reduceOnly"], "true")
        with self.assertRaises(BrokerError):
            b.market_order("BTCUSDT", "sell", 0.0001)          # dưới minQty
        FakeBinance.dual = True
        with self.assertRaises(BrokerError):
            BinanceFuturesBroker("key123", "sekret", self.url).prepare("BTCUSDT")

    def test_engine_live_futures_short_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "short.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_init(self): self.k = 0\n"
                "    def on_tick(self, t):\n"
                "        self.k += 1\n"
                "        if self.k == 3: self.api.sell(0.01, reason='thử short')\n"
                "        if self.k == 6: self.api.close_all(reason='thử đóng')\n"))
            s = fast_settings(mode="live", exchange="binance_futures", base_url=self.url, api_key="key123",
                              api_secret="sekret", live_confirm=True, leverage=2.0, tick_interval=0.1, sim_speed=1.0)
            r = BotRunner(p, s, {}); r.start()
            self.assertTrue(wait(lambda: len(r.account.trades) == 1 if r.account else False, 10), [l[3] for l in r.logs][-6:])
            r.stop(); r._thread.join(5)
            sides = [(o["side"], o.get("reduceOnly")) for _, o in FakeBinance.orders]
            self.assertEqual(sides, [("SELL", None), ("BUY", "true")])
            self.assertEqual(r.account.trades[0].side, "sell")
            self.assertEqual(r.status, "stopped", r.message)

    def test_engine_live_spot_rejects_short(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "short.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_tick(self, t):\n        self.api.sell(0.01)\n"))
            s = fast_settings(mode="live", exchange="binance_spot", base_url=self.url, api_key="key123",
                              api_secret="sekret", live_confirm=True, tick_interval=0.1, sim_speed=1.0)
            r = BotRunner(p, s, {}); r.start(); time.sleep(1.2); r.stop(); r._thread.join(5)
            self.assertEqual(FakeBinance.orders, [])
            self.assertIn("không hỗ trợ bán khống", "\n".join(l[3] for l in r.logs))

    def test_order_failures_raise_alarm(self):
        with tempfile.TemporaryDirectory() as d:
            p = write_bot(d, "tiny.py", (
                "from pyea import BaseBot\nclass B(BaseBot):\n"
                "    def on_tick(self, t):\n        self.api.buy(0.0001)\n"))       # dưới minQty -> lỗi mỗi lần
            alarms = []
            s = fast_settings(mode="live", exchange="binance_spot", base_url=self.url, api_key="key123",
                              api_secret="sekret", live_confirm=True, tick_interval=0.1, sim_speed=1.0)
            r = BotRunner(p, s, {}, alarm_cb=lambda t, x: alarms.append(t)); r.start()
            self.assertTrue(wait(lambda: alarms, 8)); r.stop(); r._thread.join(5)
            self.assertIn("thất bại liên tiếp", alarms[0])


class TestVotesAndChat(unittest.TestCase):
    def V(self, agent, action, conf=0.8, sl=1.0, tp=2.0):
        return {"agent": agent, "model": "m-" + agent, "action": action, "confidence": conf, "sl_pct": sl, "tp_pct": tp, "reason": "r-" + agent}

    def test_tally(self):
        r = ai.tally_votes([self.V("A", "buy", 0.9), self.V("B", "buy", 0.7), self.V("C", "sell")])
        self.assertEqual(r["action"], "buy"); self.assertAlmostEqual(r["confidence"], 0.8)
        r = ai.tally_votes([self.V("A", "buy"), self.V("B", "sell"), self.V("C", "hold")])
        self.assertEqual(r["action"], "hold"); self.assertEqual(r["confidence"], 0.0)
        r = ai.tally_votes([self.V("A", "sell"), self.V("B", "sell")])
        self.assertEqual(r["action"], "sell")
        self.assertEqual(ai.tally_votes([self.V("A", "buy")])["action"], "buy")      # 1 AI duy nhất
        self.assertIsNone(ai.tally_votes([]))

    def test_majority_session_with_fake_models(self):
        def fake(agent, messages, max_tokens=800, timeout=90):
            if "QUYẾT ĐỊNH CUỐI" in messages[-1]["content"]:
                act = "buy" if agent["name"] != "C" else "sell"
                return json.dumps({"action": act, "confidence": 0.8, "sl_pct": 1, "tp_pct": 2, "reason": "lý do " + agent["name"]})
            return "ý kiến " + agent["name"]
        orig = ai.chat_completion; ai.chat_completion = fake
        try:
            with tempfile.TemporaryDirectory() as d:
                store = Store(d)
                hub = ai.AIHub(store, lambda: TestAI_snap(), lambda: ("b", "src", {}), lambda: dict(default_settings(), ai_decision_mode="majority", ai_rounds=1))
                hub.set_agents([dict(ai.default_agent(i), name=n) for i, n in enumerate("ABC", 1)])
                hub._auto_session()
                sig = hub.get_signal()
                self.assertEqual(sig["action"], "buy"); self.assertEqual(sig["mode"], "đa số")
                self.assertEqual(len(sig["votes"]), 3); self.assertTrue(sig["discussion"])
                self.assertTrue(any(m["kind"] == "decision" for m in store.chat.tail(50)))
        finally:
            ai.chat_completion = orig

    def test_chatlog_two_writers_and_offsets(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "c.jsonl")
            a, b = ChatLog(p), ChatLog(p)
            a.append({"id": a.new_id(), "who": "A"}); b.append({"id": b.new_id(), "who": "B"})
            msgs, pos = a.read_from(0)
            self.assertEqual([m["who"] for m in msgs], ["A", "B"])
            b.append({"id": b.new_id(), "who": "C"})
            msgs2, pos2 = a.read_from(pos)
            self.assertEqual([m["who"] for m in msgs2], ["C"]); self.assertGreater(pos2, pos)
            a.clear()
            msgs3, pos3 = a.read_from(pos2)
            self.assertEqual((msgs3, pos3), ([], 0))
            self.assertNotEqual(a.new_id(), a.new_id())


def TestAI_snap():
    from pyea.sdk import Candle
    cs = [Candle(i * 60, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(60)]
    return {"ready": True, "candles": cs, "symbol": "X", "timeframe": "1m", "mode": "paper", "bid": 160, "ask": 160.1,
            "balance": 1000, "equity": 1000, "pnl_pct": 0, "max_dd": 0, "n_trades": 0, "win_rate": 0,
            "positions": [], "trades": [], "plots": {}}


class TestDiagnostics(unittest.TestCase):
    def test_report(self):
        with tempfile.TemporaryDirectory() as d:
            rs = diagnostics.run_checks(d, default_settings(), Store(d), network=False)
            names = [r["name"] for r in rs]
            self.assertIn("Thư mục dữ liệu ghi được", names)
            txt = diagnostics.format_report(rs)
            self.assertIn("Font tiếng Việt", txt)


if __name__ == "__main__":
    unittest.main()
